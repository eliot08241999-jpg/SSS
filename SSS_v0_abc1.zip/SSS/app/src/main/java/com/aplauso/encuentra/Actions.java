package com.aplauso.encuentra;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Build;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.Settings;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Órdenes del asistente SSS+ (v0.9.2): antes de preguntarle a Gemini, mira si lo que dijiste es una orden
 * para el teléfono: poner música en YouTube, llamar, mandar un WhatsApp o un SMS, abrir una app, poner una
 * alarma o un temporizador, ir a un sitio con el mapa, buscar en Google o encender la linterna.
 */
public class Actions {
    /** Lo que se hizo (para decirlo en voz alta) y, si hay que abrir algo, el intent. */
    static final class Result {
        final String say; final Intent intent;
        Result(String say, Intent intent) { this.say = say; this.intent = intent; }
    }

    static String norm(String s) {
        String n = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.replaceAll("[¿?¡!.,;]", " ").replaceAll("\\s+", " ").trim();
    }

    static Matcher m(String re, String s) { Matcher k = Pattern.compile(re).matcher(s); return k.find() ? k : null; }

    /** Devuelve null si no es una orden (entonces se le pregunta a Gemini). */
    static Result parse(Context c, String said) {
        String s = norm(said);
        Matcher k;
        Result ph = phone(c, s);                  // v1.1: volumen, música, batería, brillo, cámara, paneles
        if (ph != null) return ph;
        // ---- música / vídeos ----
        if ((k = m("^(?:reproduce|reproducir|pon(?:me)?|poner|escuchar|quiero escuchar|quiero ver|play)\\s+(.+?)\\s+(?:en|por)\\s+youtube(?: music)?$", s)) != null
                || (k = m("^(?:busca|buscar|abre|abrir)\\s+(.+?)\\s+en\\s+youtube$", s)) != null) {
            String q = k.group(1);
            boolean music = s.contains("youtube music");
            return new Result(L.t("Pongo ") + q + L.t(" en YouTube."), youtube(c, q, music));
        }
        if ((k = m("^(?:reproduce|reproducir|pon(?:me)?|escuchar|quiero escuchar)\\s+(?:la cancion |el video |musica de |a )?(.+)$", s)) != null
                && !s.contains("alarma") && !s.contains("temporizador") && !s.contains("linterna") && !s.contains("molestar")) {
            return new Result(L.t("Pongo ") + k.group(1) + L.t(" en YouTube."), youtube(c, k.group(1), false));
        }
        // ---- llamar ----
        if ((k = m("^(?:llama|llamar|llamame|marca|telefonea)(?: a| al)?\\s+(.+)$", s)) != null) {
            String who = k.group(1);
            String num = who.replaceAll("[^0-9+]", "");
            if (num.length() < 3) num = phoneOf(c, who);
            if (num == null) return new Result(L.t("No encuentro a ") + who + L.t(" en tus contactos. Si quieres, dame permiso de contactos en la pantalla del asistente."), null);
            boolean canCall = c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
            Intent i = new Intent(canCall ? Intent.ACTION_CALL : Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)));
            return new Result(L.t("Llamando a ") + who + ".", i);
        }
        // ---- WhatsApp / SMS ----
        if ((k = m("^(?:manda|mandale|envia|enviale|escribe|escribele)(?: un)? (whatsapp|wasap|mensaje|sms)(?: a| al)? (.+?)(?: (?:diciendo|que diga|que dice|que)\\s+(.*))?$", s)) != null) {
            String kind = k.group(1), who = k.group(2), text = k.group(3) == null ? "" : k.group(3);
            String num = phoneOf(c, who);
            if (num == null) return new Result(L.t("No encuentro a ") + who + L.t(" en tus contactos."), null);
            Intent i;
            if (kind.startsWith("wh") || kind.startsWith("wa")) {
                i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + num.replaceAll("[^0-9]", "") + (text.isEmpty() ? "" : "?text=" + Uri.encode(text))));
            } else {
                i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num)));
                if (!text.isEmpty()) i.putExtra("sms_body", text);
            }
            return new Result(L.t("Te dejo el mensaje para ") + who + L.t(" listo: solo pulsa enviar."), i);
        }
        // ---- alarma ----
        if ((k = m("(?:pon|ponme|crea|programa)(?: una)? alarma (?:a las |para las |a la |para la )?(\\d{1,2})(?:[: ](\\d{2}))?(?: (?:de la )?(manana|tarde|noche|am|pm))?", s)) != null) {
            int h = Integer.parseInt(k.group(1)), mi = k.group(2) == null ? 0 : Integer.parseInt(k.group(2));
            String pm = k.group(3);
            if (pm != null && (pm.equals("tarde") || pm.equals("noche") || pm.equals("pm")) && h < 12) h += 12;
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h % 24).putExtra(AlarmClock.EXTRA_MINUTES, mi)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true).putExtra(AlarmClock.EXTRA_MESSAGE, "SSS+");
            return new Result(L.t("Alarma puesta a las ") + String.format(Locale.US, "%d:%02d", h % 24, mi) + ".", i);
        }
        // ---- temporizador ----
        if ((k = m("(?:temporizador|cronometro|cuenta atras|avisame en|timer)(?: de| en)? (\\d+) (segundo|minuto|hora)s?", s)) != null) {
            int n = Integer.parseInt(k.group(1));
            int secs = k.group(2).startsWith("seg") ? n : k.group(2).startsWith("min") ? n * 60 : n * 3600;
            Intent i = new Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true).putExtra(AlarmClock.EXTRA_MESSAGE, "SSS+");
            return new Result(L.t("Temporizador de ") + n + " " + k.group(2) + (n == 1 ? "" : "s") + ".", i);
        }
        // ---- mapas ----
        if ((k = m("^(?:llevame|como llego|navega|ir|vamos|ruta)(?: a| al| hasta| hacia)? (.+)$", s)) != null) {
            return new Result(L.t("Vamos a ") + k.group(1) + ".", new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(k.group(1)))));
        }
        if ((k = m("^(?:donde esta|muestrame en el mapa|busca en el mapa|mapa de) (.+)$", s)) != null) {
            return new Result(L.t("Te enseño ") + k.group(1) + L.t(" en el mapa."), new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(k.group(1)))));
        }
        // ---- linterna ----
        if (s.matches(".*\\b(enciende|prende|activa|pon)( la)? linterna.*")) return torch(c, true);
        if (s.matches(".*\\b(apaga|desactiva|quita)( la)? linterna.*")) return torch(c, false);
        // ---- abrir app ----
        if ((k = m("^(?:abre|abrir|abreme|inicia|lanza)(?: la app| la aplicacion| el| la)? (.+)$", s)) != null) {
            String name = k.group(1);
            Intent i = appIntent(c, name);
            if (i == null) return new Result(L.t("No encuentro ninguna app que se llame ") + name + ".", null);
            return new Result(L.t("Abro ") + name + ".", i);
        }
        // ---- buscar en Google ----
        if ((k = m("^(?:busca|buscar|buscame|abre)(?: en google) (.+)$", s)) != null && !s.contains("youtube")) {
            return new Result(L.t("Busco ") + k.group(1) + ".", new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(k.group(1)))));
        }
        return null;
    }

    // ================= v1.1: funciones del teléfono =================
    static Result phone(Context c, String s) {
        Matcher k;
        android.media.AudioManager am = c.getSystemService(android.media.AudioManager.class);
        int st = android.media.AudioManager.STREAM_MUSIC;
        // ---- volumen ----
        if ((k = m("\\b(?:volumen|volume)\\b.*?\\b(?:al?|a un|to)\\s+(\\d{1,3})", s)) != null || (k = m("^(?:pon|ponme)? ?el volumen (?:al?|en) (\\d{1,3})", s)) != null) {
            int pc = Math.max(0, Math.min(100, Integer.parseInt(k.group(1))));
            am.setStreamVolume(st, Math.round(am.getStreamMaxVolume(st) * pc / 100f), android.media.AudioManager.FLAG_SHOW_UI);
            return new Result(L.t("Volumen al ") + pc + " %.", null);
        }
        if (m("\\b(?:sube|subir|subele|mas alto|mas fuerte|aumenta)\\b.*\\b(?:volumen|musica|sonido)\\b|^(?:sube|subele|mas alto|mas fuerte)$|volume up", s) != null) {
            for (int i = 0; i < 2; i++) am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_RAISE, i == 1 ? android.media.AudioManager.FLAG_SHOW_UI : 0);
            return new Result(L.t("Subo el volumen."), null);
        }
        if (m("\\b(?:baja|bajar|bajale|mas bajo|mas flojo|disminuye)\\b.*\\b(?:volumen|musica|sonido)\\b|^(?:baja|bajale|mas bajo|mas flojo)$|volume down", s) != null) {
            for (int i = 0; i < 2; i++) am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_LOWER, i == 1 ? android.media.AudioManager.FLAG_SHOW_UI : 0);
            return new Result(L.t("Bajo el volumen."), null);
        }
        if (m("^(?:silencio|silencia(?:lo)?|mute|quita el sonido|sin sonido)$", s) != null) {
            am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_MUTE, android.media.AudioManager.FLAG_SHOW_UI);
            return new Result(L.t("Silencio."), null);
        }
        // ---- música: pausa, sigue, siguiente, anterior ----
        if (m("^(?:pausa|pausar|para|deten|detén|stop|para la musica|pausa la musica|deten la musica|para el video|pausa el video)$", s) != null)
            return media(c, android.view.KeyEvent.KEYCODE_MEDIA_PAUSE, L.t("Pausado."));
        if (m("^(?:sigue|continua|reanuda|play|dale play|sigue la musica|continua la musica|reanuda la musica)$", s) != null)
            return media(c, android.view.KeyEvent.KEYCODE_MEDIA_PLAY, L.t("Sigo."));
        if (m("^(?:siguiente|salta|pasa|next)(?: cancion| tema| video)?$|^(?:pon |pasa a )?la siguiente(?: cancion)?$", s) != null)
            return media(c, android.view.KeyEvent.KEYCODE_MEDIA_NEXT, L.t("Siguiente."));
        if (m("^(?:anterior|atras|previous)(?: cancion| tema)?$|^(?:pon )?la (?:cancion )?anterior$|^cancion anterior$", s) != null)
            return media(c, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS, L.t("La anterior."));
        // ---- Spotify ----
        if ((k = m("^(?:reproduce|reproducir|pon(?:me)?|poner|escuchar|quiero escuchar|play)\\s+(.+?)\\s+(?:en|por|con)\\s+spotify$", s)) != null)
            return new Result(L.t("Pongo ") + k.group(1) + L.t(" en Spotify."), spotify(c, k.group(1)));
        if (m("^(?:abre|abrir|pon|ponme) spotify$", s) != null) return null;   // lo hace "abrir app"
        // ---- batería ----
        if (m("\\b(?:bateria|carga|battery)\\b", s) != null && m("\\b(?:cuanta|cuanto|que|como|nivel|tengo|queda|how much|level)\\b", s) != null) {
            android.os.BatteryManager bm = c.getSystemService(android.os.BatteryManager.class);
            int pc = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY);
            boolean ch = bm.isCharging();
            return new Result(L.t("Tienes un ") + pc + L.t(" % de batería") + (ch ? L.t(" y se está cargando.") : pc < 20 ? L.t(". Conviene cargarlo pronto.") : "."), null);
        }
        // ---- brillo ----
        if ((k = m("\\bbrillo\\b.*?(?:al?|en) (\\d{1,3})", s)) != null || m("\\b(?:sube|baja|aumenta|disminuye|mas|menos)\\b.*\\bbrillo\\b", s) != null) {
            if (!Settings.System.canWrite(c))
                return new Result(L.t("Para cambiar el brillo necesito permiso: actívalo y vuelve a pedírmelo."),
                        new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.getPackageName())));
            int cur = Settings.System.getInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128);
            int v;
            if (k != null) v = Math.round(Math.max(1, Math.min(100, Integer.parseInt(k.group(1)))) * 2.55f);
            else v = s.matches(".*\\b(?:sube|aumenta|mas)\\b.*") ? Math.min(255, cur + 60) : Math.max(5, cur - 60);
            Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, v);
            return new Result(L.t("Brillo al ") + Math.round(v / 2.55f) + " %.", null);
        }
        // ---- cámara ----
        if (m("^(?:abre|abrir|pon) (?:la )?camara$|^(?:hazme|haz|saca|toma) una (?:foto|selfie)$", s) != null)
            return new Result(L.t("Abro la cámara."), new Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
        if (m("^(?:graba|grabar|grabame) (?:un )?video$", s) != null)
            return new Result(L.t("Abro la cámara de vídeo."), new Intent(android.provider.MediaStore.INTENT_ACTION_VIDEO_CAMERA));
        // ---- wifi / bluetooth / modo avión: Android solo deja abrir el panel ----
        if (m("\\b(?:wifi|wi fi|internet)\\b", s) != null && m("\\b(?:activa|desactiva|enciende|apaga|quita|pon|conecta|abre)\\b", s) != null)
            return new Result(L.t("Te abro el wifi: toca para cambiarlo."), new Intent(Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_WIFI : Settings.ACTION_WIFI_SETTINGS));
        if (m("\\bbluetooth\\b", s) != null)
            return new Result(L.t("Te abro el Bluetooth: toca para cambiarlo."), new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        if (m("\\bmodo avion\\b", s) != null)
            return new Result(L.t("Te abro el modo avión: toca para cambiarlo."), new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS));
        return null;
    }

    static Result media(Context c, int code, String say) {
        android.media.AudioManager am = c.getSystemService(android.media.AudioManager.class);
        am.dispatchMediaKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code));
        return new Result(say, null);
    }

    static Intent spotify(Context c, String q) {
        PackageManager pm = c.getPackageManager();
        Intent play = new Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).setPackage("com.spotify.music")
                .putExtra(android.app.SearchManager.QUERY, q).putExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*");
        if (play.resolveActivity(pm) != null) return play;
        Intent search = new Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q)));
        if (search.resolveActivity(pm) != null) return search;
        return new Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/" + Uri.encode(q)));
    }

    static Intent youtube(Context c, String q, boolean music) {
        PackageManager pm = c.getPackageManager();
        String pkg = music ? "com.google.android.apps.youtube.music" : "com.google.android.youtube";
        // "reproducir desde búsqueda": YouTube empieza a reproducir el primer resultado
        Intent play = new Intent("android.media.action.MEDIA_PLAY_FROM_SEARCH").setPackage(pkg)
                .putExtra("query", q).putExtra("android.intent.extra.focus", "vnd.android.cursor.item/*");
        if (play.resolveActivity(pm) != null) return play;
        Intent search = new Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q);
        if (search.resolveActivity(pm) != null) return search;
        return new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)));
    }

    /** Número de teléfono de un contacto por su nombre (o null). */
    static String phoneOf(Context c, String who) {
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null;
        String w = norm(who);
        String best = null;
        int bestScore = 0;
        try (Cursor k = c.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null)) {
            if (k == null) return null;
            while (k.moveToNext()) {
                String name = k.getString(0), num = k.getString(1);
                if (name == null || num == null) continue;
                String n = norm(name);
                int score = n.equals(w) ? 3 : n.startsWith(w) ? 2 : (n.contains(w) || w.contains(n)) ? 1 : 0;
                if (score > bestScore) { bestScore = score; best = num; }
            }
        } catch (Exception ignored) {}
        return best;
    }

    /** La app instalada cuyo nombre se parece más a lo que dijiste. */
    static Intent appIntent(Context c, String name) {
        PackageManager pm = c.getPackageManager();
        String w = norm(name);
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        ResolveInfo best = null;
        int bestScore = 0;
        for (ResolveInfo r : apps) {
            String label = norm(String.valueOf(r.loadLabel(pm)));
            int score = label.equals(w) ? 3 : label.startsWith(w) ? 2 : (label.contains(w) || w.contains(label)) ? 1 : 0;
            if (score > bestScore) { bestScore = score; best = r; }
        }
        if (best == null) return null;
        return pm.getLaunchIntentForPackage(best.activityInfo.packageName);
    }

    static Result torch(Context c, boolean on) {
        try {
            CameraManager cm = c.getSystemService(CameraManager.class);
            for (String id : cm.getCameraIdList()) {
                Boolean f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (f != null && f) { cm.setTorchMode(id, on); return new Result(on ? L.t("Linterna encendida.") : L.t("Linterna apagada."), null); }
            }
        } catch (Exception ignored) {}
        return new Result(L.t("No puedo usar la linterna en este teléfono."), null);
    }

    /** ¿Se pueden abrir apps cuando hablas con la palabra clave y la pantalla de SSS+ no está delante? */
    static boolean canOpenFromBackground(Context c) { return Settings.canDrawOverlays(c); }

    /** Ejecuta el resultado. Devuelve false si Android no dejó abrir nada. */
    static boolean run(Context c, Result r) {
        if (r.intent == null) return true;
        try {
            r.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(r.intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
