package com.aplauso.encuentra;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

/**
 * Rutinas del asistente (v0.9.3).
 * «Buenos días»: te saluda por tu nombre, te dice la hora, el tiempo de hoy, un chiste y «que te vaya bien»
 * (y quita el No molestar si lo había puesto SSS+).
 * «Buenas noches»: pone el teléfono en No molestar (las alarmas siguen sonando) para que duermas tranquilo.
 * El tiempo viene de Open-Meteo (gratis, sin clave). Bloquea: llamar desde un hilo.
 */
public class Routines {
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    /** Devuelve lo que hay que decir, o null si no es una rutina. */
    static String handle(Context c, String said) {
        String s = Actions.norm(said);
        if (s.matches("^(?:hola )?(?:buenos dias|buen dia|good morning|morning|buongiorno)\\b.*")) return morning(c);
        if (s.matches("^(?:buenas noches|good night|goodnight|buonanotte|buona notte)\\b.*")) return night(c);
        if (s.matches(".*\\b(?:que hora es|que horas son|dime la hora|what time is it|che ore sono)\\b.*")) return time();
        if (s.matches(".*\\b(?:tiempo|clima|lluvia|llovera|weather|rain|meteo|pioggia)\\b.*")
                && s.matches(".*\\b(?:que|como|va a|hace|hoy|manana|dime|what|how|che|come)\\b.*")) return weather(c);
        if (s.matches(".*\\b(?:cuentame|dime|hazme|cuenta)\\b.*\\b(?:chiste|broma)\\b.*|.*\\b(?:tell me a joke|joke|barzelletta)\\b.*")) return joke();
        if (s.matches(".*\\b(?:quita|desactiva|apaga)\\b.*\\bno molestar\\b.*")) return dnd(c, false);
        if (s.matches(".*\\b(?:pon|activa|enciende)\\b.*\\bno molestar\\b.*")) return dnd(c, true);
        return null;
    }

    static String name(Context c) { return prefs(c).getString("ai_name", "").trim(); }

    static String morning(Context c) {
        StringBuilder b = new StringBuilder();
        String n = name(c);
        b.append(L.t("¡Buenos días")).append(n.isEmpty() ? "" : ", " + n).append("! ");
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        b.append(h < 7 ? L.t("Qué madrugador. ") : h >= 12 ? L.t("Aunque ya es casi mediodía. ") : L.t("Espero que hayas dormido bien. "));
        b.append(time()).append(' ');
        if (prefs(c).getBoolean("dnd_by_sss", false)) { String d = dnd(c, false); if (d != null) b.append(d).append(' '); }
        b.append(weather(c)).append(' ');
        b.append(L.t("Y para empezar con una sonrisa: ")).append(joke()).append(' ');
        b.append(L.t("¡Que te vaya muy bien hoy!"));
        return b.toString();
    }

    static String night(Context c) {
        String n = name(c);
        String d = dnd(c, true);
        return L.t("Buenas noches") + (n.isEmpty() ? "" : ", " + n) + ". " + d + " " + L.t("Que descanses.");
    }

    static String time() {
        Calendar k = Calendar.getInstance();
        return L.t("Son las") + " " + String.format(Locale.US, "%d:%02d", k.get(Calendar.HOUR_OF_DAY), k.get(Calendar.MINUTE)) + ".";
    }

    /** No molestar. Necesita el permiso «Acceso a No molestar» (se da en la pantalla del asistente). */
    static String dnd(Context c, boolean on) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || !nm.isNotificationPolicyAccessGranted())
            return L.t("No puedo poner el No molestar: dame permiso en la pantalla del asistente, botón NO MOLESTAR.");
        try {
            nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_PRIORITY : NotificationManager.INTERRUPTION_FILTER_ALL);
            prefs(c).edit().putBoolean("dnd_by_sss", on).apply();
            return on ? L.t("He puesto el No molestar; las alarmas sí sonarán.") : L.t("He quitado el No molestar.");
        } catch (Exception e) {
            return L.t("El teléfono no me deja cambiar el No molestar.");
        }
    }

    static final String[] JOKES_ES = {
            "¿Qué le dice una oveja a otra? Nos vemos en el baaaar.",
            "¿Por qué el libro de matemáticas estaba triste? Porque tenía demasiados problemas.",
            "¿Qué hace una abeja en el gimnasio? Zum-ba.",
            "Le dije a mi teléfono que necesitaba un descanso, y me puso el modo avión.",
            "¿Cómo se despiden los químicos? Ácido un placer.",
            "¿Qué le dice un semáforo a otro? No me mires, que me estoy cambiando.",
            "¿Por qué los pájaros no usan Facebook? Porque ya tienen Twitter.",
            "Mi despertador y yo tenemos una relación complicada: él me quiere despierto y yo a él apagado.",
            "¿Qué le dice el café al azúcar? Sin ti mi vida es amarga.",
            "¿Cuál es el colmo de un electricista? Que su mujer se llame Luz y sus hijos le sigan la corriente.",
    };
    static final String[] JOKES_EN = {
            "What do you call a sleeping sheep? A baa-d dreamer.",
            "Why did the math book look sad? It had too many problems.",
            "I told my phone I needed a break, so it switched to airplane mode.",
            "Why don't eggs tell jokes? They'd crack each other up.",
            "What does coffee say to sugar? Life is bitter without you.",
    };
    static final String[] JOKES_IT = {
            "Cosa dice una pecora all'altra? Ci vediamo al beeeeh-r.",
            "Perché il libro di matematica è triste? Perché ha troppi problemi.",
            "Ho detto al telefono che avevo bisogno di una pausa, e si è messo in modalità aereo.",
            "Cosa dice il caffè allo zucchero? Senza di te la vita è amara.",
    };

    static String joke() {
        String[] j = "en".equals(L.lang) ? JOKES_EN : "it".equals(L.lang) ? JOKES_IT : JOKES_ES;
        return j[new Random().nextInt(j.length)];
    }

    // ---------- tiempo ----------
    static String weather(Context c) {
        try {
            double[] ll = where(c);
            if (ll == null) return L.t("Para decirte el tiempo, escribe tu ciudad en la pantalla del asistente o dame permiso de ubicación.");
            String url = String.format(Locale.US, "https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f"
                    + "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code"
                    + "&timezone=auto&forecast_days=1", ll[0], ll[1]);
            JSONObject o = new JSONObject(get(url));
            JSONObject cur = o.getJSONObject("current"), d = o.getJSONObject("daily");
            int now = (int) Math.round(cur.getDouble("temperature_2m"));
            int max = (int) Math.round(d.getJSONArray("temperature_2m_max").getDouble(0));
            int min = (int) Math.round(d.getJSONArray("temperature_2m_min").getDouble(0));
            int rain = d.getJSONArray("precipitation_probability_max").optInt(0, 0);
            String sky = sky(d.getJSONArray("weather_code").getInt(0));
            String city = prefs(c).getString("ai_city_name", "");
            StringBuilder b = new StringBuilder(L.t("Hoy")).append(city.isEmpty() ? "" : " " + L.t("en") + " " + city).append(": ").append(sky)
                    .append(", ").append(L.t("ahora hace")).append(' ').append(now).append(L.t(" grados, con máxima de ")).append(max)
                    .append(L.t(" y mínima de ")).append(min).append('.');
            if (rain >= 50) b.append(' ').append(L.t("Hay")).append(' ').append(rain).append(L.t(" % de probabilidad de lluvia: llévate paraguas."));
            else if (rain >= 20) b.append(' ').append(L.t("Puede que llueva un poco."));
            return b.toString();
        } catch (java.net.UnknownHostException e) {
            return L.t("No tengo internet para mirar el tiempo.");
        } catch (Exception e) {
            return L.t("No he podido mirar el tiempo ahora.");
        }
    }

    /** Latitud y longitud: la ciudad escrita en el asistente o, si no hay, la última ubicación conocida. */
    static double[] where(Context c) throws Exception {
        SharedPreferences p = prefs(c);
        String city = p.getString("ai_city", "").trim();
        if (!city.isEmpty()) {
            if (city.equals(p.getString("ai_city_geo", "")) && p.contains("ai_city_lat"))
                return new double[]{p.getFloat("ai_city_lat", 0), p.getFloat("ai_city_lon", 0)};
            JSONObject o = new JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=" + Wake.lang()
                    + "&name=" + URLEncoder.encode(city, "UTF-8")));
            JSONArray r = o.optJSONArray("results");
            if (r != null && r.length() > 0) {
                JSONObject g = r.getJSONObject(0);
                double la = g.getDouble("latitude"), lo = g.getDouble("longitude");
                p.edit().putString("ai_city_geo", city).putFloat("ai_city_lat", (float) la).putFloat("ai_city_lon", (float) lo)
                        .putString("ai_city_name", g.optString("name", city)).apply();
                return new double[]{la, lo};
            }
        }
        if (c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            LocationManager lm = c.getSystemService(LocationManager.class);
            Location best = null;
            for (String pr : lm.getProviders(true)) {
                try {
                    Location l = lm.getLastKnownLocation(pr);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (SecurityException ignored) {}
            }
            if (best != null) { p.edit().putString("ai_city_name", "").apply(); return new double[]{best.getLatitude(), best.getLongitude()}; }
        }
        return null;
    }

    static String sky(int code) {
        if (code == 0) return L.t("despejado");
        if (code <= 2) return L.t("algo de nubes");
        if (code == 3) return L.t("nublado");
        if (code == 45 || code == 48) return L.t("con niebla");
        if (code >= 51 && code <= 57) return L.t("con llovizna");
        if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return L.t("con lluvia");
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) return L.t("con nieve");
        if (code >= 95) return L.t("con tormenta");
        return L.t("variable");
    }

    static String get(String u) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(u).openConnection();
        con.setConnectTimeout(10000);
        con.setReadTimeout(15000);
        try { return Brain.read(con.getInputStream()); } finally { con.disconnect(); }
    }
}
