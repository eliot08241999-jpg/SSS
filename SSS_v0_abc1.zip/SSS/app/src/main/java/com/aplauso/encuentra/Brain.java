package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * El "cerebro" del asistente de SSS+ (v0.9.2): le pregunta a Gemini por la API de Google AI Studio.
 * La clave la pone el usuario en Ajustes (es suya y se queda solo en el teléfono).
 */
public class Brain {
    static final String DEFAULT_MODEL = "gemini-flash-lite-latest";   // v1.0.2: el "lite" tiene muchas más preguntas gratis al día
    static final String DEFAULT_NAME = "Chloe";
    static final String DEFAULT_PERSONA = "Eres simpática y con un punto sarcástico. Hablas claro y corto, como una amiga lista, "
            + "y de vez en cuando sueltas una broma.";
    static final String DEFAULT_PC_MODEL = "qwen2.5:7b";

    /** Conversación reciente (para que recuerde de qué se hablaba). */
    static final List<String[]> history = new ArrayList<>();      // {"user"|"model", texto}

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    /**
     * La clave limpia: si se pegó un trozo de código o con saltos de línea, busca dentro algo con forma
     * de clave de Google (empieza por "AIza") y se queda solo con eso.
     */
    static String key(Context c) { return cleanKey(prefs(c).getString("ai_key", "")); }
    static String cleanKey(String raw) {
        if (raw == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("AIza[0-9A-Za-z_\\-]{30,}").matcher(raw);
        if (m.find()) return m.group();
        return raw.replaceAll("\\s+", "");
    }
    static boolean keyLooksOk(String k) { return k.startsWith("AIza") && k.length() >= 35; }
    static String model(Context c) { String m = prefs(c).getString("ai_model", "").trim(); return m.isEmpty() ? DEFAULT_MODEL : m; }
    static String persona(Context c) { String s = prefs(c).getString("ai_persona", "").trim(); return s.isEmpty() ? DEFAULT_PERSONA : s; }
    static boolean search(Context c) { return prefs(c).getBoolean("ai_search", true); }
    static String botName(Context c) { String s = prefs(c).getString("ai_bot_name", "").trim(); return s.isEmpty() ? DEFAULT_NAME : s; }
    /** "auto" (portátil si responde, si no Gemini), "pc" o "gemini". */
    static String brain(Context c) { return prefs(c).getString("ai_brain", "auto"); }
    static String pcModel(Context c) { String m = prefs(c).getString("ai_pc_model", "").trim(); return m.isEmpty() ? DEFAULT_PC_MODEL : m; }
    static String pcUrl(Context c) {
        String u = prefs(c).getString("ai_pc_url", "").trim();
        if (u.isEmpty()) return "";
        if (!u.startsWith("http")) u = "http://" + u;
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        if (!u.substring(u.indexOf("//") + 2).contains(":")) u += ":11434";
        return u;
    }

    /** Si un modelo dice "demasiadas preguntas", se prueba con estos (los "lite" tienen más preguntas gratis al día). */
    static final String[] FALLBACK = {"gemini-flash-latest", "gemini-2.5-flash-lite", "gemini-2.5-flash"};

    /** Último error completo de Google (se muestra escrito en la pantalla del asistente). */
    static volatile String lastError = "";
    /** v1.0: si Google dice "demasiadas preguntas", no se le vuelve a preguntar hasta esta hora (no gastar más cupo). */
    static volatile long coolUntil;

    static final class Fail extends Exception {
        final int code; final String msg;
        Fail(int code, String msg) { super(msg); this.code = code; this.msg = msg; }
    }

    // ================= v1.1: cerebro propio con los pies en la tierra =================
    static String system(Context c) {
        String lang = "es".equals(L.lang) ? "español" : "it".equals(L.lang) ? "italiano" : "English";
        return "Te llamas " + botName(c) + " y eres el asistente de voz de la app SSS+, creada por BLORP.eoac. " + persona(c) + "\n"
                + "Responde siempre en " + lang + ". Tus respuestas se leen en voz alta: frases cortas, sin listas, sin asteriscos ni símbolos, "
                + "y como mucho unas 4 frases salvo que te pidan más.\n"
                + "REGLAS (más importantes que tu personalidad):\n"
                + "1. No inventes nunca datos. Tu personalidad está en CÓMO hablas, no en lo que afirmas.\n"
                + "2. Si te preguntan por hechos, noticias, precios, fechas, resultados, personas, lugares o cualquier cosa que no sepas con "
                + "seguridad o que pueda haber cambiado, y NO tienes RESULTADOS DE INTERNET, no respondas: escribe SOLO [[buscar: consulta corta]].\n"
                + "3. Si tienes RESULTADOS DE INTERNET, básate en ellos, di de dónde sale (por ejemplo «según Wikipedia») y si no aparece la respuesta, dilo claramente.\n"
                + "4. Si te piden hacer algo en el teléfono, contesta con una frase corta y añade al final [[cmd: orden]] usando UNA de estas órdenes exactas: "
                + "pon <canción o artista> en youtube | pon <canción o artista> en spotify | sube el volumen | baja el volumen | volumen al <número> | silencio | "
                + "pausa | sigue | siguiente | anterior | cuanta bateria me queda | brillo al <número> | sube el brillo | baja el brillo | abre la camara | "
                + "enciende la linterna | apaga la linterna | llama a <nombre> | alarma a las <hora> | temporizador de <número> minutos | abre <app> | "
                + "llevame a <lugar> | activa el wifi | bluetooth | modo avion | pon el no molestar | quita el no molestar. "
                + "Ejemplo: «está muy alto» → «Vale, lo bajo. [[cmd: baja el volumen]]».\n"
                + "5. Si el usuario te cuenta algo de sí mismo y te pide que no lo olvides, añade al final [[recordar: el dato en una frase]].\n"
                + "6. Nunca digas que has hecho algo en el teléfono si no has puesto su [[cmd: …]]."
                + Memory.forPrompt(c);
    }

    static final Pattern TAG = Pattern.compile("\\[\\[\\s*(cmd|buscar|recordar)\\s*:\\s*(.*?)\\]\\]", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    /** La orden para el teléfono que pidió el cerebro (o null). */
    static String cmdOf(String a) {
        if (a == null) return null;
        Matcher m = TAG.matcher(a);
        while (m.find()) if (m.group(1).equalsIgnoreCase("cmd")) return m.group(2).trim();
        return null;
    }
    /** Lo que se dice en voz alta (sin las etiquetas). */
    static String speech(String a) { return a == null ? "" : TAG.matcher(a).replaceAll("").replaceAll("\\s+", " ").trim(); }

    /** Preguntas de datos: se busca en internet ANTES de contestar, para no inventar. */
    static boolean looksFactual(String q) {
        String s = Actions.norm(q);
        return s.matches(".*\\b(?:quien|quienes|cuando|donde|cuanto|cuanta|cuantos|cuantas|cual|cuales|que es|que son|que significa|que paso|"
                + "por que|porque|como se|como funciona|precio|cuesta|vale|noticias|ultim[oa]s?|hoy|ayer|resultado|gano|perdio|murio|nacio|"
                + "estreno|sale|salio|horario|busca|buscame|investiga|informacion|who|when|where|how much|what is|news|latest|chi|quando|dove|quanto|cos e)\\b.*")
                && !s.matches("^(?:como estas|que tal|quien eres|como te llamas|que haces|que puedes hacer).*");
    }

    /** Pregunta (bloquea: llamar desde un hilo aparte). Devuelve la respuesta (puede llevar [[cmd: …]]). */
    static String ask(Context c, String question) {
        lastError = "";
        String rt = Memory.handle(c, question);           // «recuerda que…», «olvida…», «¿qué recuerdas?»
        if (rt == null) rt = Routines.handle(c, question); // buenos días, buenas noches, la hora, el tiempo, un chiste…
        if (rt != null) return rt;
        String ctx = "";
        if (search(c) && looksFactual(question)) ctx = Web.research(question);
        String ans = generate(c, question, ctx);
        if (ans == null) return failMessage(c);
        Matcher m = TAG.matcher(ans);
        String wanted = null;
        while (m.find()) if (m.group(1).equalsIgnoreCase("buscar")) wanted = m.group(2).trim();
        if (wanted != null) {
            if (!search(c)) ans = L.t("Para eso tendría que buscar en internet, y la búsqueda está apagada en los ajustes del asistente.");
            else {
                String more = Web.research(wanted.isEmpty() ? question : wanted);
                if (more.isEmpty()) ans = L.t("He buscado en internet y no he encontrado nada fiable sobre eso.");
                else {
                    String again = generate(c, question, ctx + more);
                    ans = again == null ? failMessage(c) : again.replaceAll("\\[\\[\\s*buscar[^\\]]*\\]\\]", "");
                }
            }
        }
        Matcher rm = TAG.matcher(ans);
        while (rm.find()) if (rm.group(1).equalsIgnoreCase("recordar")) Memory.add(c, rm.group(2));
        if (speech(ans).isEmpty() && cmdOf(ans) == null) ans = L.t("No se me ocurre qué responder.");
        synchronized (history) {
            history.add(new String[]{"user", question});
            history.add(new String[]{"model", ans});
            while (history.size() > 12) history.remove(0);
        }
        return ans;
    }

    static Fail lastFail;

    /** Una respuesta del cerebro elegido (portátil y/o Gemini). null si ninguno pudo. */
    static String generate(Context c, String question, String webCtx) {
        String user = webCtx.isEmpty() ? question
                : question + "\n\nRESULTADOS DE INTERNET (buscados ahora mismo):\n" + webCtx + "\nResponde a mi pregunta usando estos resultados.";
        String sys = system(c);
        String b = brain(c);
        lastFail = null;
        if (!b.equals("gemini") && !pcUrl(c).isEmpty()) {
            try { return ollama(c, sys, user); }
            catch (Exception e) {
                lastError = L.t("Portátil: ") + e.getMessage();
                if (b.equals("pc")) { lastFail = new Fail(-2, String.valueOf(e.getMessage())); return null; }
            }
        }
        if (b.equals("pc")) { lastFail = new Fail(-3, "sin dirección"); return null; }
        return gemini(c, sys, user);
    }

    static String failMessage(Context c) {
        Fail last = lastFail;
        if (last != null && last.code == -2) return L.t("No consigo hablar con tu portátil. ¿Está encendido, con Ollama abierto y en el mismo wifi?");
        if (last != null && last.code == -3) return L.t("Aún no me has dicho la dirección de tu portátil. Ponla en la pantalla del asistente.");
        if (last != null && last.code == -1) return last.msg;
        if (last == null) return L.t("No tengo cerebro todavía: conecta tu portátil o pon una clave de Gemini en la pantalla del asistente.");
        String low = last.msg.toLowerCase(java.util.Locale.ROOT);
        if (last.code == 400 && low.contains("api key")) return L.t("Google dice que la clave no es válida. Cópiala otra vez desde AI Studio.");
        if (last.code == 403) return L.t("Google no deja usar Gemini con esta clave o en este proyecto. Mira el mensaje escrito abajo.");
        if (last.code == 429) {
            if (low.contains("limit: 0")) return L.t("Tu clave de Gemini tiene 0 preguntas gratis disponibles ahora mismo. Mira el mensaje escrito abajo.");
            if (low.contains("per day") || low.contains("perday")) return L.t("Se han acabado las preguntas gratis de hoy. Mañana se renuevan.");
            return L.t("Gemini dice que has hecho demasiadas preguntas seguidas. Espera un minuto.");
        }
        return L.t("Gemini no ha podido responder") + " (" + last.code + ").";
    }

    /** Gemini con modelos de reserva. null si falla (el motivo queda en lastFail). */
    static String gemini(Context c, String sys, String user) {
        long wait = coolUntil - System.currentTimeMillis();
        if (wait > 0) { lastFail = new Fail(-1, L.t("Google me ha pedido que espere. Vuelve a preguntarme en") + " " + (wait / 1000 + 1) + " " + L.t("segundos.")); return null; }
        String k = key(c);
        if (k.isEmpty()) { lastFail = null; return null; }
        if (!keyLooksOk(k)) { lastFail = new Fail(-1, L.t("Eso no parece una clave de Gemini. La clave empieza por AIza y es una sola línea larga: cópiala con el botón de copiar que hay junto a ella.")); return null; }
        String first = prefs(c).getString("ai_model_ok", "");
        if (!prefs(c).getString("ai_model", "").trim().isEmpty() || first.isEmpty()) first = model(c);
        List<String> tries = new ArrayList<>();
        tries.add(first);
        for (String f : FALLBACK) if (!f.equals(first)) tries.add(f);
        for (String t : tries) {
            try {
                String ans = call(c, k, t, sys, user);
                if (!t.equals(prefs(c).getString("ai_model_ok", ""))) prefs(c).edit().putString("ai_model_ok", t).apply();
                return ans;
            } catch (Fail f) {
                lastFail = f;
                lastError = t + " → " + f.code + ": " + f.msg;
                if (f.code != 429 && f.code != 404 && f.code != 503 && f.code != 500) break;
            } catch (java.net.UnknownHostException e) {
                lastFail = new Fail(-1, L.t("No tengo internet ahora mismo."));
                return null;
            } catch (Exception e) {
                lastError = String.valueOf(e.getMessage());
                lastFail = new Fail(-1, L.t("Algo ha fallado al hablar con Gemini: ") + e.getMessage());
                return null;
            }
        }
        if (lastFail != null && lastFail.code == 429) {
            String low = lastFail.msg.toLowerCase(java.util.Locale.ROOT);
            coolUntil = System.currentTimeMillis() + (low.contains("per day") || low.contains("limit: 0") ? 15 * 60_000 : 60_000);
        }
        return null;
    }

    /** Cerebro en el portátil con Ollama (http://IP:11434). */
    static String ollama(Context c, String sys, String user) throws Exception {
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", sys));
        synchronized (history) {
            for (String[] h : history) msgs.put(new JSONObject().put("role", h[0].equals("model") ? "assistant" : "user").put("content", h[1]));
        }
        msgs.put(new JSONObject().put("role", "user").put("content", user));
        JSONObject body = new JSONObject().put("model", pcModel(c)).put("messages", msgs).put("stream", false).put("keep_alive", "30m")
                .put("options", new JSONObject().put("temperature", 0.7));
        HttpURLConnection con = (HttpURLConnection) new URL(pcUrl(c) + "/api/chat").openConnection();
        con.setRequestMethod("POST");
        con.setConnectTimeout(4000);
        con.setReadTimeout(120000);
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        try (OutputStream os = con.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = con.getResponseCode();
        String resp = read(code >= 400 ? con.getErrorStream() : con.getInputStream());
        con.disconnect();
        if (code >= 400) {
            String msg = resp;
            try { msg = new JSONObject(resp).getString("error"); } catch (Exception ignored) {}
            if (msg.contains("not found")) msg = L.t("el modelo ") + pcModel(c) + L.t(" no está instalado en el portátil (ollama pull ") + pcModel(c) + ")";
            throw new Exception(msg);
        }
        String ans = new JSONObject(resp).getJSONObject("message").optString("content", "");
        ans = ans.replaceAll("(?s)<think>.*?</think>", "");
        return clean(ans);
    }

    /** Prueba la conexión con el portátil: devuelve los modelos instalados o lanza el error. */
    static String pcTest(Context c) throws Exception {
        if (pcUrl(c).isEmpty()) throw new Exception(L.t("escribe primero la dirección"));
        HttpURLConnection con = (HttpURLConnection) new URL(pcUrl(c) + "/api/tags").openConnection();
        con.setConnectTimeout(4000);
        con.setReadTimeout(8000);
        String resp = read(con.getInputStream());
        con.disconnect();
        JSONArray m = new JSONObject(resp).getJSONArray("models");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < m.length(); i++) b.append(i == 0 ? "" : ", ").append(m.getJSONObject(i).getString("name"));
        return b.toString();
    }

    /** Una llamada a Gemini. Lanza Fail con el código y el mensaje de Google si no sale bien. */
    static String call(Context c, String k, String model, String sys, String question) throws Exception {
        JSONObject body = new JSONObject();
        body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", sys))));
        JSONArray contents = new JSONArray();
        synchronized (history) {
            for (String[] h : history)
                contents.put(new JSONObject().put("role", h[0]).put("parts", new JSONArray().put(new JSONObject().put("text", h[1]))));
        }
        contents.put(new JSONObject().put("role", "user").put("parts", new JSONArray().put(new JSONObject().put("text", question))));
        body.put("contents", contents);

        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setConnectTimeout(15000);
        con.setReadTimeout(60000);
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        con.setRequestProperty("x-goog-api-key", k);
        try (OutputStream os = con.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = con.getResponseCode();
        String resp = read(code >= 400 ? con.getErrorStream() : con.getInputStream());
        con.disconnect();
        if (code >= 400) {
            String msg = resp;
            try { msg = new JSONObject(resp).getJSONObject("error").getString("message"); } catch (Exception ignored) {}
            if (msg.length() > 400) msg = msg.substring(0, 400) + "…";
            throw new Fail(code, msg);
        }
        JSONObject o = new JSONObject(resp);
        JSONArray parts = o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length(); i++) {
            JSONObject pt = parts.getJSONObject(i);
            if (pt.has("text") && !pt.optBoolean("thought", false)) sb.append(pt.getString("text"));
        }
        String ans = clean(sb.toString());
        return ans.isEmpty() ? L.t("No se me ocurre qué responder.") : ans;
    }

    /** Quita símbolos de formato para que la voz no los lea. */
    static String clean(String s) {
        return s.replaceAll("[*#_`>]+", "").replaceAll("\\[(.*?)\\]\\(.*?\\)", "$1").replaceAll("\\s+", " ").trim();
    }

    static String read(InputStream in) throws java.io.IOException {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }
}
