package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Configuración: detección, sonido, Skin (color, opacidad, fondo, color cambiante) y batería. */
public class SettingsActivity extends NeonActivity {
    static final int[] PRESETS = {
            Color.rgb(0, 229, 255),   // cian
            Color.rgb(255, 45, 170),  // rosa
            Color.rgb(57, 255, 20),   // verde
            Color.rgb(170, 70, 255),  // morado
            Color.rgb(255, 140, 0),   // naranja
            Color.rgb(255, 230, 0),   // amarillo
    };

    TextView soundLbl;
    View swatch;
    SeekBar rBar, gBar, bBar;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(18), dpi(18), dpi(18), dpi(28));

        // --- Barra superior ---
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(circleButton("←", v -> finish()), new LinearLayout.LayoutParams(dpi(46), dpi(46)));
        TextView title = neonText("  AJUSTES", 24);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        col.addView(top, gapBelow(16));

        // --- Idioma ---
        LinearLayout lang = panel("◢ IDIOMA · LANGUAGE · LINGUA");
        LinearLayout langRow = new LinearLayout(this);
        for (int i = 0; i < L.CODES.length; i++) {
            final String code = L.CODES[i];
            TextView lb = button((L.CODES[i].equals(L.lang) ? "● " : "") + L.NAMES[i], v -> {
                L.set(this, code);
                Intent restart = new Intent(this, MainActivity.class).setAction(Intent.ACTION_MAIN);
                restart.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(restart);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i > 0) lp.leftMargin = dpi(8);
            langRow.addView(lb, lp);
        }
        lang.addView(langRow);
        col.addView(lang, gapBelow(14));

        // --- Detección ---
        LinearLayout det = panel("◢ DETECCIÓN");
        slider(det, "Aplausos necesarios", "claps", 5, 2, 8, "", null);
        slider(det, "Sensibilidad", "sens", 6, 1, 10, "", null);
        TextView tip = text("Consejo: en la pantalla principal, la línea blanca del medidor "
                + "marca desde dónde cuenta un aplauso.", 12);
        tip.setPadding(0, dpi(6), 0, 0);
        det.addView(tip);
        col.addView(det, gapBelow(14));

        // --- Sonido ---
        LinearLayout snd = panel("◢ SONIDO");
        soundLbl = text("", 15);
        snd.addView(soundLbl);
        slider(snd, "Volumen", "volume", 100, 10, 100, " %", null);
        snd.addView(spaced(button("♪ ELEGIR MI SONIDO", v -> pickSound())));
        snd.addView(spaced(button("↺ SONIDO POR DEFECTO", v -> {
            p.edit().remove("sound_uri").remove("sound_name").apply();
            onSoundChanged();
        })));
        snd.addView(spaced(button("▶ PROBAR / PARAR", v -> {
            if (SoundPlayer.isPlaying()) SoundPlayer.stop(this);
            else SoundPlayer.play(this, null);
        })));
        col.addView(snd, gapBelow(14));

        // --- Skin ---
        LinearLayout skin = panel("◢ SKIN");
        skin.addView(text("Color de los marcos", 14));
        LinearLayout chips = new LinearLayout(this);
        chips.setPadding(0, dpi(8), 0, dpi(4));
        for (int c : PRESETS) {
            View chip = new View(this);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(c);
            d.setStroke(dpi(2), Color.WHITE);
            chip.setBackground(d);
            chip.setOnClickListener(v -> setColor(c));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpi(34), dpi(34));
            lp.rightMargin = dpi(10);
            chips.addView(chip, lp);
        }
        skin.addView(chips);

        LinearLayout rgbRow = new LinearLayout(this);
        rgbRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout rgb = new LinearLayout(this);
        rgb.setOrientation(LinearLayout.VERTICAL);
        int cur = p.getInt("neon", Neon.DEFAULT_COLOR);
        p.edit().putInt("r", Color.red(cur)).putInt("g", Color.green(cur)).putInt("b", Color.blue(cur)).apply();
        rBar = slider(rgb, "R", "r", Color.red(cur), 0, 255, "", v -> rgbChanged());
        gBar = slider(rgb, "G", "g", Color.green(cur), 0, 255, "", v -> rgbChanged());
        bBar = slider(rgb, "B", "b", Color.blue(cur), 0, 255, "", v -> rgbChanged());
        rgbRow.addView(rgb, new LinearLayout.LayoutParams(0, -2, 1));
        swatch = new View(this);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(dpi(56), dpi(56));
        sl.leftMargin = dpi(12);
        rgbRow.addView(swatch, sl);
        updateSwatch(cur);
        skin.addView(rgbRow);

        slider(skin, "Opacidad de paneles y botones", "opacity", 70, 0, 100, " %", null);

        Switch cycle = neonSwitch("Color cambiante (arcoíris)");
        cycle.setChecked(p.getBoolean("cycle", false));
        cycle.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("cycle", on).apply());
        skin.addView(cycle);
        slider(skin, "Velocidad del cambio", "cycle_speed", 4, 1, 10, "", null);

        TextView bgLbl = text("Fondo de pantalla", 14);
        bgLbl.setPadding(0, dpi(10), 0, 0);
        skin.addView(bgLbl);
        LinearLayout bgRow = new LinearLayout(this);
        TextView pick = button("🖼 ELEGIR", v -> pickBackground());
        TextView clear = button("✕ QUITAR", v -> {
            p.edit().remove("bg_uri").apply();
            loadBackground();
        });
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, -2, 1);
        lp1.rightMargin = dpi(8);
        lp1.topMargin = dpi(8);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, -2, 1);
        lp2.topMargin = dpi(8);
        bgRow.addView(pick, lp1);
        bgRow.addView(clear, lp2);
        skin.addView(bgRow);
        col.addView(skin, gapBelow(14));

        // --- v0.9.1: Escudo anti-«Ok Google» ---
        LinearLayout sh = panel("◢ SILENCIAR «OK GOOGLE»");
        sh.addView(text("Mientras estás en el horario, SSS+ ocupa el micrófono en modo privado y el Asistente de Google "
                + "no puede oír «Ok Google» en este teléfono. No se graba ni se guarda nada. "
                + "Si otra app necesita el micrófono (una llamada, una nota de voz), el escudo se aparta solo.", 13));
        Switch shOn = neonSwitch("Activar el escudo");
        shOn.setChecked(ShieldService.enabled(this));
        sh.addView(shOn);
        LinearLayout times = new LinearLayout(this);
        times.setOrientation(LinearLayout.HORIZONTAL);
        TextView fromB = button("Desde " + ShieldService.hhmm(ShieldService.from(this)), null);
        TextView toB = button("Hasta " + ShieldService.hhmm(ShieldService.to(this)), null);
        fromB.setOnClickListener(v -> pickTime("shield_from", ShieldService.from(this), m -> fromB.setText(L.t("Desde ") + ShieldService.hhmm(m))));
        toB.setOnClickListener(v -> pickTime("shield_to", ShieldService.to(this), m -> toB.setText(L.t("Hasta ") + ShieldService.hhmm(m))));
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1);
        tl.rightMargin = dpi(6);
        times.addView(fromB, tl);
        times.addView(toB, new LinearLayout.LayoutParams(0, -2, 1));
        sh.addView(spaced(times));
        shieldLbl = text("", 13);
        sh.addView(spaced(shieldLbl));
        sh.addView(spaced(button("⏸ PAUSAR 1 HORA", v -> { ShieldService.pause(this, 60); refreshShield(); })));
        sh.addView(spaced(button("⏹ DETENER POR HOY", v -> { ShieldService.stopToday(this); refreshShield(); })));
        sh.addView(spaced(button("▶ REANUDAR AHORA", v -> { ShieldService.resume(this); refreshShield(); })));
        sh.addView(spaced(button("⏻ APAGAR DEL TODO", v -> { shOn.setChecked(false); })));
        sh.addView(spaced(button("🐑 ASISTENTE SSS+ (GEMINI, VOCES, PALABRA CLAVE)", v -> startActivity(new Intent(this, AssistActivity.class)))));
        sh.addView(text("También puedes pausarlo, detenerlo o apagarlo desde su notificación. "
                + "Si reinicias el teléfono, abre SSS+ una vez para que vuelva a funcionar.", 11));
        shOn.setOnCheckedChangeListener((v, on) -> {
            if (on && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            }
            p.edit().putBoolean("shield_on", on).putLong("shield_pause", 0).apply();
            if (on) ShieldService.start(this); else if (!ShieldService.needed(this)) ShieldService.stopAll(this);
            refreshShield();
        });
        col.addView(sh, gapBelow(14));
        if (p.getBoolean("shield_failed", false)) {
            p.edit().remove("shield_failed").apply();
            toast(L.t("El escudo se apagó solo porque el micrófono no respondía."));
        }

        // --- Batería ---
        LinearLayout bat = panel("◢ BATERÍA");
        bat.addView(text("Si tu teléfono cierra SSS+ en segundo plano, ponla en "
                + "\"Sin restricciones\".", 13));
        bat.addView(spaced(button("⚡ AJUSTES DE BATERÍA", v ->
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)))));
        col.addView(bat, gapBelow(14));

        // --- v1.6: notificaciones ---
        LinearLayout nt = panel("◢ NOTIFICACIONES");
        Switch nq = neonSwitch("Notificaciones discretas");
        nq.setChecked(Notif.quiet(this));
        nq.setOnCheckedChangeListener((v, on) -> {
            p.edit().putBoolean("notif_quiet", on).apply();
            toast(L.t("Se aplica la próxima vez que se encienda cada función (o reinicia SSS+)."));
        });
        nt.addView(nq);
        nt.addView(spaced(text("Las fijas (aplausos, «hola Chloe», descargas, vídeo, grabación) pasan a mínimas: sin icono arriba, sin sonido y plegadas al final. "
                + "Android obliga a que haya una mientras SSS+ escucha en segundo plano; así casi no se ve.", 12)));
        nt.addView(spaced(button("🔔 AJUSTES DE NOTIFICACIONES DE ANDROID", v -> {
            try { startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())); } catch (Exception ignored) {}
        })));
        col.addView(nt, gapBelow(14));

        // --- v1.7: registro de errores ---
        LinearLayout er = panel("◢ ÚLTIMO ERROR");
        String crash = SssApp.last(this);
        er.addView(text(crash == null ? "No hay ningún error apuntado. Si SSS+ se cierra de golpe, aquí quedará qué pasó (solo en tu teléfono)."
                : "SSS+ se cerró por un error. Cópialo y pásaselo a quien te ayuda con la app:", 13));
        if (crash != null) {
            TextView ct = text("", 11);
            ct.setText(crash.length() > 1500 ? crash.substring(0, 1500) + "…" : crash);
            ct.setTextIsSelectable(true);
            er.addView(spaced(ct));
            LinearLayout erow = new LinearLayout(this);
            erow.addView(button("📋 COPIAR", v -> {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("SSS+ error", crash));
                toast(L.t("Copiado ✓"));
            }), new LinearLayout.LayoutParams(0, -2, 1));
            erow.addView(button("🗑 BORRAR", v -> { SssApp.clear(this); toast(L.t("Borrado ✓")); recreate(); }), new LinearLayout.LayoutParams(0, -2, 1));
            er.addView(spaced(erow));
        }
        col.addView(er, gapBelow(14));

        // --- Carpeta y copias de seguridad ---
        LinearLayout bk = panel("◢ CARPETA SSS+ Y COPIAS");
        bk.addView(text("Todo lo que creas se guarda ordenado en la carpeta SSS+ (Fotos, Videos, Audios, Documentos, 3D, Copias). "
                + "La copia de seguridad guarda tus partidas, récords y ajustes en SSS+/Copias para pasarlos a otro teléfono.", 13));
        bk.addView(spaced(button("💾 HACER COPIA DE SEGURIDAD", v -> {
            try {
                android.net.Uri u = Media.saveBytes(this, Backup.export(this), Media.SUB_BACKUP, "SSS_copia_" + Media.stamp() + ".json", "application/json");
                toast(u != null ? L.t("Copia guardada en " + Media.where(this, Media.SUB_BACKUP) + " ✓") : L.t("No se pudo guardar"));
            } catch (Exception e) { toast(L.t("No se pudo guardar")); }
        })));
        bk.addView(spaced(button("♻ RESTAURAR UNA COPIA", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_RESTORE);
        })));
        if (Media.appDir(this) == null)
            bk.addView(spaced(button("🔓 PERMITIR LA CARPETA SSS+", v -> Media.requestAllFiles(this))));
        col.addView(bk, gapBelow(14));

        // --- Créditos y licencias ---
        LinearLayout cr = panel("◢ CRÉDITOS Y LICENCIAS");
        cr.addView(text("SSS+ es una app de BLORP.eoac. Código, juegos, música y arte propios; usa dos librerías libres de otros autores.", 13));
        cr.addView(spaced(button("📜 VER CRÉDITOS Y LICENCIAS", v -> new android.app.AlertDialog.Builder(this)
                .setTitle(L.t("📜 Créditos y licencias"))
                .setMessage(L.t(CREDITS))
                .setPositiveButton(L.t("Listo"), null).show())));
        col.addView(cr, gapBelow(14));

        TextView ver = text("Chloe Nova v1.7.2 · por BLORP.eoac", 12);
        ver.setGravity(Gravity.CENTER);
        col.addView(ver);

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(makeRoot(sv));
        onSoundChanged();
    }

    static final int REQ_RESTORE = 91, REQ_MIC = 92;
    TextView shieldLbl;

    interface OnMinutes { void set(int m); }

    private void pickTime(String key, int cur, OnMinutes done) {
        new android.app.TimePickerDialog(this, (tp, h, m) -> {
            int v = h * 60 + m;
            p.edit().putInt(key, v).apply();
            done.set(v);
            refreshShield();
        }, cur / 60, cur % 60, true).show();
    }

    private void refreshShield() {
        if (shieldLbl == null) return;
        String s;
        if (!ShieldService.enabled(this)) s = "Escudo apagado.";
        else if (!ShieldService.inWindow(this)) s = "En espera: se activa a las " + ShieldService.hhmm(ShieldService.from(this)) + ".";
        else if (System.currentTimeMillis() < ShieldService.pausedUntil(this)) s = "En pausa.";
        else s = "🔇 Activo: «Ok Google» bloqueado hasta las " + ShieldService.hhmm(ShieldService.to(this)) + ".";
        shieldLbl.setText(L.t(s));
        if (ShieldService.enabled(this)) ShieldService.start(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshShield();
    }

    static final String CREDITS =
            "SSS+ © 2026 BLORP.eoac. Todos los derechos reservados.\n"
            + "Idea, diseño, personajes, jefes y carátula de El Pastor de Ecos: BLORP.eoac.\n\n"
            + "LIBRERÍAS DE TERCEROS\n\n"
            + "• PdfBox-Android (lectura y creación de PDF)\n"
            + "Copyright Tom Roush y The Apache Software Foundation.\n"
            + "Licencia Apache 2.0: apache.org/licenses/LICENSE-2.0\n\n"
            + "• junrar (descomprimir archivos RAR)\n"
            + "Basado en el código de UnRAR de Alexander L. Roshal.\n"
            + "Licencia de UnRAR: se permite usarlo para descomprimir; no se puede usar para crear un compresor RAR. "
            + "SSS+ solo descomprime.\n"
            + "github.com/junrar/junrar\n\n"
            + "• Vosk y sus modelos pequeños de voz (palabra clave del asistente, sin internet)\n"
            + "Copyright Alpha Cephei Inc. Licencia Apache 2.0. alphacephei.com/vosk\n\n"
            + "• MediaPipe LLM Inference (cerebro de Chloe en el teléfono)\n"
            + "Copyright Google LLC. Licencia Apache 2.0. github.com/google-ai-edge/mediapipe\n\n"
            + "• Qwen2.5-1.5B-Instruct (modelo del cerebro, se descarga aparte)\n"
            + "Copyright Alibaba Cloud (Qwen). Licencia Apache 2.0. huggingface.co/litert-community\n\n"
            + "• Kokoro-82M (voz propia de Chloe) y kokoro-onnx\n"
            + "Copyright hexgrad / thewh1teagle. Licencia Apache 2.0 / MIT. github.com/thewh1teagle/kokoro-onnx\n\n"
            + "• Real-ESRGAN (ampliar vídeos e imágenes)\n"
            + "Copyright Xintao Wang. Licencia BSD-3. github.com/xinntao/Real-ESRGAN\n\n"
            + "• three.js (Chloe en 3D)\n"
            + "Copyright three.js authors. Licencia MIT. github.com/mrdoob/three.js\n\n"
            + "• ML Kit Translation (traductor de documentos)\n"
            + "Copyright Google LLC. Términos de ML Kit. developers.google.com/ml-kit";

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_RESTORE) {
            if (res != RESULT_OK || data == null || data.getData() == null) return;
            try (java.io.InputStream in = getContentResolver().openInputStream(data.getData())) {
                int n = Backup.restore(this, DocIO.readAll(in));
                new android.app.AlertDialog.Builder(this).setTitle(L.t("♻ Copia restaurada"))
                        .setMessage(L.t("Se recuperaron " + n + " datos (partidas, récords y ajustes)."))
                        .setPositiveButton(L.t("Listo"), (d, w) -> recreate()).show();
            } catch (Exception e) {
                toast(L.t("No se pudo restaurar: ") + e.getMessage());
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    private View spaced(View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dpi(8);
        v.setLayoutParams(lp);
        return v;
    }

    private void rgbChanged() {
        int c = Color.rgb(p.getInt("r", 0), p.getInt("g", 229), p.getInt("b", 255));
        p.edit().putInt("neon", c).apply();
        updateSwatch(c);
    }

    private void setColor(int c) {
        p.edit().putInt("neon", c).putInt("r", Color.red(c)).putInt("g", Color.green(c))
                .putInt("b", Color.blue(c)).putBoolean("cycle", false).apply();
        rBar.setProgress(Color.red(c));
        gBar.setProgress(Color.green(c));
        bBar.setProgress(Color.blue(c));
        updateSwatch(c);
        recreate(); // refresca también el interruptor de color cambiante
    }

    private void updateSwatch(int c) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(dp(12));
        d.setColor(c);
        d.setStroke(dpi(2), Color.WHITE);
        swatch.setBackground(d);
    }

    @Override
    protected void onSoundChanged() {
        if (soundLbl != null) soundLbl.setText(L.t("Actual: " + soundName()));
    }
}
