package com.aplauso.encuentra;

/** Canciones originales de SSS+ (todas compuestas para la app). Cada compás = 8 corcheas. */
public class Songs {

    // ---------------- TORRE ARRIBA: valiente, alegre, con energía (Do mayor, 125) ----------------
    static final String TOWER_LEAD =
            "C5 - E5 G5 C6 - B5 G5 " +
            "A5 - G5 E5 F5 - E5 D5 " +
            "E5 - G5 C6 D6 - C6 B5 " +
            "C6 - - - G5 - - - " +
            "A5 - C6 A5 G5 - E5 C5 " +
            "F5 - A5 F5 E5 - C5 E5 " +
            "D5 - F5 A5 G5 - B5 D6 " +
            "C6 - - - . . G5 - ";
    static final String TOWER_HARM =
            "E4 - - - G4 - - - " +
            "F4 - - - G4 - - - " +
            "E4 - - - D4 - - - " +
            "E4 - - - D4 - - - " +
            "E4 - - - E4 - - - " +
            "F4 - - - E4 - - - " +
            "F4 - - - D4 - - - " +
            "E4 - - - . . . . ";
    static final String TOWER_BASS =
            "C3 . C4 . C3 . C4 . " +
            "F2 . F3 . G2 . G3 . " +
            "C3 . C4 . G2 . G3 . " +
            "C3 . C4 . G2 . B2 . " +
            "A2 . A3 . C3 . C4 . " +
            "F2 . F3 . C3 . C4 . " +
            "D3 . D4 . G2 . G3 . " +
            "C3 . C4 . G2 . G3 . ";
    static final String TOWER_DRUMS = "k . h . s . h . k . h k s . h .";

    static final Chip.Song TOWER = new Chip.Song(125, TOWER_LEAD, TOWER_HARM, TOWER_BASS, TOWER_DRUMS);

    // ---------------- Jefe: tenso y rápido (La menor, 150) ----------------
    static final Chip.Song BOSS = new Chip.Song(150,
            "A4 A4 C5 A4 E5 A4 D5 C5 " +
            "A4 A4 C5 A4 G5 F5 E5 D5 " +
            "F4 F4 A4 F4 C5 F4 B4 A4 " +
            "E4 E4 G#4 E4 B4 E4 D5 B4 ",
            "C4 - - - E4 - - - C4 - - - E4 - - - A3 - - - C4 - - - G#3 - - - B3 - - - ",
            "A2 A3 A2 A3 A2 A3 A2 A3 A2 A3 A2 A3 A2 A3 A2 A3 " +
            "F2 F3 F2 F3 F2 F3 F2 F3 E2 E3 E2 E3 E2 E3 E2 E3 ",
            "k h s h k k s h");

    // ---------------- Guardián: épico (Re menor, 110) ----------------
    static final Chip.Song GUARDIAN = new Chip.Song(110,
            "D5 - - A4 D5 - F5 - " +
            "E5 - - C5 A4 - - - " +
            "Bb4 - - F4 Bb4 - D5 - " +
            "C5 - - G4 C5 - E5 - " +
            "D5 - F5 - A5 - - - " +
            "G5 - F5 - E5 - D5 - " +
            "C#5 - E5 - A5 - G5 - " +
            "A5 - - - - - - - ",
            "F4 - - - F4 - - - E4 - - - C#4 - - - D4 - - - F4 - - - E4 - - - G4 - - - " +
            "F4 - - - F4 - - - Bb4 - - - A4 - - - E4 - - - C#4 - - - E4 - - - C#4 - - - ",
            "D2 - D3 - D2 - D3 - A2 - A3 - A2 - A3 - Bb2 - Bb3 - Bb2 - Bb3 - C3 - C4 - C3 - C4 - " +
            "D2 - D3 - D2 - D3 - G2 - G3 - G2 - G3 - A2 - A3 - A2 - A3 - A2 - A3 - A2 - A3 - ",
            "k . s . k k s .");

    // ---------------- Final del piso 1000: el tema principal como caja de música ----------------
    static final Chip.Song ENDING = new Chip.Song(70, TOWER_LEAD, "", TOWER_BASS, "").box().vols(0.2f, 0, 0.12f, 0);

    // ---------------- GATO RUNNER: juguetón (Fa mayor, 140) ----------------
    static final Chip.Song RUNNER = new Chip.Song(140,
            "F5 . A5 . C6 . A5 . " +
            "Bb5 . G5 . E5 . C5 . " +
            "F5 . A5 . C6 . F6 . " +
            "E6 . C6 . G5 - - . " +
            "D6 . Bb5 . F5 . D5 . " +
            "C6 . A5 . F5 . C5 . " +
            "G5 . A5 . Bb5 . C6 . " +
            "F6 - - . . . . . ",
            "",
            "F3 . C3 . F3 . C3 . " +
            "C3 . G2 . C3 . G2 . " +
            "F3 . C3 . F3 . C3 . " +
            "C3 . G2 . C3 . E3 . " +
            "Bb2 . F3 . Bb2 . F3 . " +
            "F3 . C3 . F3 . C3 . " +
            "C3 . G2 . C3 . E3 . " +
            "F3 . C3 . F2 . . . ",
            "k h s h k h s h");

    // ---------------- EL PASTOR DE ECOS ----------------
    // Pradera Hundida: pastoral (Sol mayor, 100)
    static final Chip.Song PRADERA = new Chip.Song(100,
            "G5 - - B5 D6 - B5 - " +
            "C6 - - A5 F#5 - D5 - " +
            "G5 - - B5 D6 - G6 - " +
            "F#6 - E6 - D6 - - - " +
            "E6 - - D6 C6 - B5 - " +
            "A5 - - G5 F#5 - D5 - " +
            "E5 - F#5 - G5 - A5 - " +
            "G5 - - - - - - - ",
            "B4 - - - B4 - - - A4 - - - F#4 - - - B4 - - - B4 - - - A4 - - - F#4 - - - " +
            "G4 - - - E4 - - - F#4 - - - D4 - - - G4 - - - F#4 - - - B4 - - - - - - - ",
            "G2 - D3 - G2 - D3 - D3 - A2 - D3 - A2 - G2 - D3 - G2 - D3 - D3 - A2 - D3 - A2 - " +
            "C3 - G2 - C3 - G2 - D3 - A2 - D3 - A2 - C3 - G2 - D3 - A2 - G2 - D3 - G2 - - - ",
            "k . h . . . h .").vols(0.13f, 0.05f, 0.17f, 0.08f);

    // Eco Hondo (el pueblo): acogedor, como una nana
    static final Chip.Song PUEBLO = new Chip.Song(84,
            "E5 - - G5 - - C6 - " +
            "B5 - - G5 - - D5 - " +
            "C5 - - E5 - - A5 - " +
            "G5 - - - - - - - " +
            "F5 - - A5 - - C6 - " +
            "E5 - - G5 - - C6 - " +
            "D5 - - F5 - - B5 - " +
            "C6 - - - - - - - ",
            "",
            "C3 - - - G3 - - - G2 - - - D3 - - - A2 - - - E3 - - - G2 - - - D3 - - - " +
            "F2 - - - C3 - - - C3 - - - G3 - - - G2 - - - D3 - - - C3 - - - G2 - - - ",
            "").box();

    // Minas de Cobre: misteriosa (Mi menor, 96)
    static final Chip.Song MINAS = new Chip.Song(96,
            "E4 - . G4 . B4 - . " +
            "C5 - - - B4 - . . " +
            "A4 - . C5 . E5 - . " +
            "D#5 - - - B4 - . . " +
            "E5 . . D5 . . B4 . " +
            "C5 - - A4 - - F#4 - " +
            "G4 - A4 - B4 - D#5 - " +
            "E5 - - - - - . . ",
            "",
            "E2 - - - - - - - C2 - - - - - - - A2 - - - - - - - B2 - - - - - - - " +
            "E2 - - - - - - - A2 - - - - - - - B2 - - - - - - - E2 - - - - - - - ",
            "k . . . . . h .").vols(0.14f, 0, 0.22f, 0.09f);
}
