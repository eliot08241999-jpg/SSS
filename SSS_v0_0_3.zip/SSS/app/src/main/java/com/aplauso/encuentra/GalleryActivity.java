package com.aplauso.encuentra;

import android.content.ContentUris;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Galería automática con pestañas Fotos / Videos / Audios; tocar abre el editor. */
public class GalleryActivity extends NeonActivity {
    static final int REQ_MEDIA = 30, REQ_PICK = 31;

    int type = Media.TYPE_IMAGE;
    List<Media.Item> items = new ArrayList<>();
    GridView grid;
    ListView list;
    TextView info, tabImg, tabVid, tabAud;
    View recordBtn;
    LinearLayout limitedBox;
    final ExecutorService pool = Executors.newFixedThreadPool(3);
    final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    final Adapter adapter = new Adapter();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(14), dpi(18), dpi(14), dpi(8));
        col.addView(topBar("EDITORES"), gapBelow(12));

        LinearLayout tabs = new LinearLayout(this);
        tabImg = button("🖼 FOTOS", v -> load(Media.TYPE_IMAGE));
        tabVid = button("🎬 VIDEOS", v -> load(Media.TYPE_VIDEO));
        tabAud = button("🎵 AUDIOS", v -> load(Media.TYPE_AUDIO));
        tabs.addView(tabImg, weight(true));
        tabs.addView(tabVid, weight(true));
        tabs.addView(tabAud, weight(false));
        col.addView(tabs, gapBelow(8));

        recordBtn = button("🎙 GRABAR SONIDO NUEVO", v ->
                startActivity(new Intent(this, AudioEditorActivity.class).putExtra("record", true)));
        col.addView(recordBtn, gapBelow(8));

        // Aviso de acceso limitado ("Seleccionar fotos")
        limitedBox = panel("⚠ ACCESO LIMITADO");
        limitedBox.addView(text("Android solo deja a SSS+ ver las fotos/videos que elegiste. "
                + "Para ver toda tu galería, permite el acceso a todas.", 13));
        TextView allow = button("✓ PERMITIR TODAS", v -> openAppSettings());
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2);
        alp.topMargin = dpi(8);
        limitedBox.addView(allow, alp);
        limitedBox.setVisibility(View.GONE);
        col.addView(limitedBox, gapBelow(8));

        col.addView(button("📂 ABRIR DESDE EL TELÉFONO", v -> pickFromPhone()), gapBelow(8));

        info = text("", 13);
        info.setGravity(Gravity.CENTER);
        col.addView(info, gapBelow(6));

        FrameLayout area = new FrameLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dpi(4));
        grid.setVerticalSpacing(dpi(4));
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(this::open);
        list = new ListView(this);
        list.setAdapter(adapter);
        list.setOnItemClickListener(this::open);
        list.setDividerHeight(dpi(6));
        area.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        area.addView(list, new FrameLayout.LayoutParams(-1, -1));
        col.addView(area, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(makeRoot(col));

        load(type);
    }

    private void openAppSettings() {
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    android.net.Uri.fromParts("package", getPackageName(), null)));
            toast("Permisos → Fotos y videos → Permitir todo");
        } catch (Exception e) {
            toast("Ábrelo en Ajustes → Apps → SSS+ → Permisos");
        }
    }

    /** Selector del sistema: funciona siempre, aunque el permiso esté limitado. */
    private void pickFromPhone() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type == Media.TYPE_VIDEO ? "video/*" : type == Media.TYPE_AUDIO ? "audio/*" : "image/*");
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_PICK) {
            if (res != RESULT_OK || data == null || data.getData() == null) return;
            android.net.Uri u = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            Class<?> target = type == Media.TYPE_VIDEO ? VideoEditorActivity.class
                    : type == Media.TYPE_AUDIO ? AudioEditorActivity.class : PhotoEditorActivity.class;
            startActivity(new Intent(this, target).setData(u));
            return;
        }
        super.onActivityResult(req, res, data);
    }

    private LinearLayout.LayoutParams weight(boolean gap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        if (gap) lp.rightMargin = dpi(6);
        return lp;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code != REQ_MEDIA) return;
        load(type);
    }

    boolean asked = false;

    @Override
    protected void onResume() {
        super.onResume();
        load(type); // por si guardaste algo nuevo o cambiaste el permiso
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
    }

    void load(int t) {
        type = t;
        tabImg.setAlpha(t == Media.TYPE_IMAGE ? 1f : 0.45f);
        tabVid.setAlpha(t == Media.TYPE_VIDEO ? 1f : 0.45f);
        tabAud.setAlpha(t == Media.TYPE_AUDIO ? 1f : 0.45f);
        recordBtn.setVisibility(t == Media.TYPE_AUDIO ? View.VISIBLE : View.GONE);
        int acc = Media.access(this, t);
        limitedBox.setVisibility(acc == Media.ACCESS_PARTIAL ? View.VISIBLE : View.GONE);
        if (acc == Media.ACCESS_NONE) {
            items = new ArrayList<>();
            adapter.notifyDataSetChanged();
            if (!asked) { asked = true; Media.request(this, REQ_MEDIA); info.setText("Esperando permiso…"); }
            else {
                info.setText("Sin permiso no puedo mostrar tu galería. Toca aquí para abrir los permisos, "
                        + "o usa \"Abrir desde el teléfono\".");
                info.setOnClickListener(v -> openAppSettings());
            }
            return;
        }
        info.setOnClickListener(null);
        info.setText("Cargando…");
        pool.execute(() -> {
            List<Media.Item> got = Media.query(this, t, null, null, 800);
            runOnUiThread(() -> {
                if (t != type) return;
                items = got;
                grid.setVisibility(t == Media.TYPE_AUDIO ? View.GONE : View.VISIBLE);
                list.setVisibility(t == Media.TYPE_AUDIO ? View.VISIBLE : View.GONE);
                adapter.notifyDataSetChanged();
                String err = Media.lastError;
                if (err != null) info.setText("Error al leer la galería: " + err);
                else if (items.isEmpty()) info.setText(acc == Media.ACCESS_PARTIAL
                        ? "No has elegido ninguno todavía. Pulsa \"Permitir todas\"."
                        : "No hay archivos");
                else info.setText(items.size() + " archivos · toca uno para editarlo");
            });
        });
    }

    void open(AdapterView<?> parent, View v, int pos, long id) {
        Media.Item it = items.get(pos);
        Class<?> target = it.type == Media.TYPE_VIDEO ? VideoEditorActivity.class
                : it.type == Media.TYPE_AUDIO ? AudioEditorActivity.class : PhotoEditorActivity.class;
        startActivity(new Intent(this, target).setData(it.uri).putExtra("name", it.name));
    }

    static String time(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    Bitmap thumb(Media.Item it) {
        try {
            if (Build.VERSION.SDK_INT >= 29)
                return getContentResolver().loadThumbnail(it.uri, new Size(300, 300), null);
            long id = ContentUris.parseId(it.uri);
            if (it.type == Media.TYPE_VIDEO)
                return MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), id, MediaStore.Video.Thumbnails.MINI_KIND, null);
            return MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), id, MediaStore.Images.Thumbnails.MINI_KIND, null);
        } catch (Exception e) {
            return null;
        }
    }

    class Adapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            Media.Item it = items.get(pos);
            if (it.type == Media.TYPE_AUDIO) {
                TextView t = convert instanceof TextView ? (TextView) convert : button("", null);
                t.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                t.setClickable(false);
                t.setText("🎵  " + it.name + "\n      " + time(it.durationMs) + " · " + SysInfo.bytes(it.size));
                return t;
            }
            FrameLayout cell;
            ImageView img;
            TextView dur;
            if (convert instanceof FrameLayout) {
                cell = (FrameLayout) convert;
                img = (ImageView) cell.getChildAt(0);
                dur = (TextView) cell.getChildAt(1);
            } else {
                cell = new FrameLayout(GalleryActivity.this);
                int size = (grid.getWidth() > 0 ? grid.getWidth() : getResources().getDisplayMetrics().widthPixels) / 3 - dpi(4);
                cell.setLayoutParams(new GridView.LayoutParams(-1, size));
                img = new ImageView(GalleryActivity.this);
                img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                img.setBackgroundColor(Color.argb(60, 255, 255, 255));
                cell.addView(img, new FrameLayout.LayoutParams(-1, -1));
                dur = text("", 11);
                dur.setBackgroundColor(Color.argb(150, 0, 0, 0));
                dur.setPadding(dpi(4), dpi(1), dpi(4), dpi(1));
                cell.addView(dur, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END));
            }
            dur.setVisibility(it.type == Media.TYPE_VIDEO ? View.VISIBLE : View.GONE);
            dur.setText("▶ " + time(it.durationMs));
            String key = it.uri.toString();
            img.setTag(key);
            Bitmap cached = cache.get(key);
            img.setImageBitmap(cached);
            if (cached == null) {
                final ImageView target = img;
                pool.execute(() -> {
                    Bitmap bm = thumb(it);
                    if (bm == null) return;
                    cache.put(key, bm);
                    runOnUiThread(() -> { if (key.equals(target.getTag())) target.setImageBitmap(bm); });
                });
            }
            return cell;
        }
    }
}
