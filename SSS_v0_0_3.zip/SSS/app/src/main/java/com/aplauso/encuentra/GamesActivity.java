package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Menú de minijuegos y pantalla de juego. */
public class GamesActivity extends NeonActivity {
    static final String[][] GAMES = {
            {"eco", "🔔 EL PASTOR DE ECOS", "Aventura: baja a las cuevas con Bee y recupera los Ecos robados. Fase 1."},
            {"tower", "🗼 TORRE ARRIBA", "Roguelike: sube pisos, sube de nivel y llega al piso 1000. Si caes, desde cero."},
            {"runner", "🐈 GATO RUNNER", "Salta ovillos, agáchate ante chanclas. Cada 250 puntos: NIGHTMARE MODE."},
            {"snake", "🐍 CULEBRITA", "Desliza (o toca a un lado) para girar. Come y crece."},
            {"blocks", "🧱 BLOQUES", "Arrastra para mover, toca para girar, desliza abajo para soltar. También hay botones."},
            {"breakout", "🏓 ROMPELADRILLOS", "Arrastra el dedo para mover la barra. Rompe todos los ladrillos."},
            {"mines", "💣 BUSCAMINAS", "Toca para descubrir, mantén pulsado para poner bandera."},
    };
    TextView[] bests = new TextView[GAMES.length];

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("JUEGOS");
        for (int i = 0; i < GAMES.length; i++) {
            String[] g = GAMES[i];
            LinearLayout card = panel(null);
            TextView name = neonText(g[1], 20);
            card.addView(name);
            TextView desc = text(g[2], 13);
            desc.setTextColor(Color.rgb(170, 180, 200));
            desc.setPadding(0, dpi(4), 0, dpi(4));
            card.addView(desc);
            bests[i] = text("", 13);
            card.addView(bests[i]);
            card.setClickable(true);
            boolean arcade = g[0].equals("eco") || g[0].equals("tower") || g[0].equals("runner");
            card.setOnClickListener(v -> startActivity(new Intent(this, arcade ? ArcadeActivity.class : Play.class)
                    .putExtra("game", g[0]).putExtra("title", g[1])));
            col.addView(card, gapBelow(14));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (int i = 0; i < GAMES.length; i++) {
            String id = GAMES[i][0];
            if (id.equals("tower"))
                bests[i].setText("🏆 Récord: piso " + p.getInt("best_tower", 0) + (p.getBoolean("tower_won", false) ? "   🗡 ¡Torre completada!" : ""));
            else if (id.equals("eco")) bests[i].setText(ecoProgress());
            else bests[i].setText("🏆 Récord: " + p.getInt("best_" + id, 0));
        }
    }

    String ecoProgress() {
        String s = p.getString("eco_save", null);
        if (s == null) return "✦ Nueva aventura";
        try {
            org.json.JSONObject o = new org.json.JSONObject(s);
            return "✦ Ecos " + o.getInt("ecos") + "/3 · 🐑 Corderitos " + o.getInt("lambs") + "/5 · 🔔 " + o.getInt("bells");
        } catch (Exception e) {
            return "✦ Partida guardada";
        }
    }

    /** Pantalla de una partida. */
    public static class Play extends NeonActivity {
        Games.Base game;
        TextView score;

        @Override
        protected void onCreate(Bundle b) {
            super.onCreate(b);
            String id = getIntent().getStringExtra("game");
            if ("blocks".equals(id)) game = new Games.Blocks(this);
            else if ("breakout".equals(id)) game = new Games.Breakout(this);
            else if ("mines".equals(id)) game = new Games.Mines(this);
            else game = new Games.Snake(this);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dpi(12), dpi(18), dpi(12), dpi(12));
            String title = getIntent().getStringExtra("title");
            col.addView(topBar(title == null ? "JUEGO" : title), gapBelow(6));
            score = neonText("", 15);
            score.setGravity(Gravity.CENTER);
            col.addView(score, gapBelow(6));
            col.addView(game, new LinearLayout.LayoutParams(-1, 0, 1));
            setContentView(makeRoot(col));
        }

        @Override
        protected void onResume() {
            super.onResume();
            game.startLoop();
        }

        @Override
        protected void onPause() {
            super.onPause();
            game.stopLoop();
        }

        @Override
        protected void onTick() {
            game.color = Neon.color(this);
            score.setText("PUNTOS " + game.score + "   ·   RÉCORD " + game.best());
        }
    }
}
