package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * EL PASTOR DE ECOS — aventura metroidvania (fase 1).
 * Bee, una ovejita con un cencerro mágico, baja a las cuevas a recuperar los Ecos robados por la Polilla Gris.
 */
public class EcoView extends GameKit.GameView implements ArcadeActivity.Backable {

    // ---------------- física (en casillas) ----------------
    static final float GRAV = 52, JUMP = 19, DJUMP = 17, SPEED = 7, MAXFALL = 20;

    // ---------------- modos ----------------
    static final int M_TITLE = 0, M_INTRO = 1, M_PLAY = 2, M_DIALOG = 3, M_SHOP = 4, M_FORGE = 5, M_MAP = 6,
            M_PAUSE = 7, M_BEAST = 8, M_AMULET = 9, M_DEAD = 10, M_MAPSHOP = 11;
    int mode = M_TITLE;

    static class Body {
        float x, y, w, h, vx, vy;
        boolean onGround, hitWall;
        Body(float w, float h) { this.w = w; this.h = h; }
    }

    static class Enemy {
        char type;
        Body b;
        float hp, maxHp, t, cd, cd2, flash, dir = 1, homeX, homeY;
        int state, role, dmg = 1, bellsMin, bellsMax, cycle;
        boolean boss, hidden, dead, phase2, enraged;
        Enemy partner;
    }

    static final int SH_WAVE = 0, SH_FLAME = 1, SH_PEBBLE = 2, SH_RING = 3, SH_ROCK = 4, SH_GHOSTFIRE = 5;

    static class Shot {
        float x, y, vx, vy, w, h, dmg, life, grav;
        int kind, bounces;
        boolean mine, pierce, dead;
        final List<Enemy> hit = new ArrayList<>();
    }

    static class Pick {
        float x, y, vy;
        char type;          // '$' cascabel, 'c' cofre, 'o' mineral, 'k' corderito, 'w' trompeta, 'j' botas, 'D' tus cascabeles perdidos
        int value;
        String flag;
        boolean dead, settled;
    }

    static class Npc {
        char ch;
        float x, y;
    }

    static class Mov {
        float x, y, w = 3, vx = 2.2f, minX, maxX;
    }

    static class Fx {
        float x, y, t, life = 0.8f;
        String s;
        int color;
    }

    // ---------------- mundo ----------------
    EcoWorld.Room room;
    float T, ox, oy;
    Bitmap roomBmp;
    final Random rnd = new Random();

    // ---------------- jugador ----------------
    final Body pl = new Body(0.8f, 0.85f);
    boolean facingR = true, usedDouble;
    int hp, lana, weapon;
    float invul, knockT, healHold, shootCd, flameCd, coyote, walk;

    // ---------------- progreso (se guarda) ----------------
    int bells, ore, cLvl = 1, branch, ecos, lambs;
    boolean hasDJ, hasTromp;
    Set<String> flags = new HashSet<>(), visited = new HashSet<>(), owned = new HashSet<>();
    List<String> equipped = new ArrayList<>();
    Map<String, Integer> kills = new HashMap<>();
    String saveRoom = "0_0";
    float saveX = 5, saveY = 14;
    String dropRoom;
    float dropX, dropY;
    int dropBells;
    float playTime;

    // ---------------- entidades de la sala ----------------
    final List<Enemy> enemies = new ArrayList<>();
    final List<Shot> shots = new ArrayList<>();
    final List<Pick> picks = new ArrayList<>();
    final List<Npc> npcs = new ArrayList<>();
    final List<Mov> movs = new ArrayList<>();
    final List<Fx> fx = new ArrayList<>();
    boolean fightActive;

    // ---------------- interfaz ----------------
    String[] dlg;
    int dlgIdx;
    float dlgChars;
    String dlgName;
    Bitmap dlgFace;
    Runnable dlgDone;
    String banner;
    float bannerT, deadT, roomNameT;
    int beastSel, introIdx;
    Npc nearNpc;

    GameKit.Btn bL, bR, bUse, bJump, bShoot, bHeal, bSwap, bPause, bMap;

    // ---------------- sprites ----------------
    Bitmap sBee, sBeeRun, sBeeJump, sBeeL, sBeeRunL, sBeeJumpL;
    Bitmap sTopo, sSabio, sMapache, sSapo, sHerrera, sFantasma, sFardo;
    Bitmap sBabosa, sBat, sBat2, sBeetle, sMinero, sBatCu, sBatCu2;
    Bitmap sReyTopo, sVagoneta, sGemelo, sGemelo2;
    Bitmap sChest, sOre, sLamb, sTromp, sBoots, sBell, sDrop;

    EcoView(Context c) {
        super(c);
        buildSprites();
    }

    // =====================================================================
    // Tamaño y botones
    // =====================================================================
    @Override
    void computeScale(int w, int h) {
        scale = h / 360f;
        vh = 360;
        vw = w / scale;
        T = Math.min(vw / EcoWorld.W, vh / EcoWorld.H);
        ox = (vw - EcoWorld.W * T) / 2;
        oy = (vh - EcoWorld.H * T) / 2;
    }

    @Override
    void layout() {
        bL = pad.add("◀", 8, 272, 76, 352, 28);
        bR = pad.add("▶", 84, 272, 152, 352, 28);
        bUse = pad.add("▲", 46, 206, 114, 262, 18);
        bJump = pad.add("⬆", vw - 86, 268, vw - 8, 352, 28);
        bJump.round = true;
        bShoot = pad.add("🔔", vw - 168, 280, vw - 96, 352, 24);
        bShoot.round = true;
        bHeal = pad.add("🧶", vw - 78, 196, vw - 14, 256, 20);
        bHeal.round = true;
        bSwap = pad.add("⇄", vw - 152, 212, vw - 100, 262, 18);
        bPause = pad.add("⏸", vw - 46, 6, vw - 8, 40, 16);
        bMap = pad.add("🗺", vw - 92, 6, vw - 54, 40, 16);
        showPad(mode == M_PLAY);
    }

    void showPad(boolean v) {
        for (GameKit.Btn b : pad.btns) b.visible = v;
        if (v && bSwap != null) bSwap.visible = hasTromp;
    }

    // =====================================================================
    // Guardar / cargar
    // =====================================================================
    boolean hasSave() { return prefs().getString("eco_save", null) != null; }

    void saveGame(boolean atFardo) {
        try {
            JSONObject o = new JSONObject();
            if (atFardo && room != null) { saveRoom = room.key(); saveX = pl.x; saveY = pl.y; }
            o.put("room", saveRoom); o.put("sx", (double) saveX); o.put("sy", (double) saveY);
            o.put("bells", bells); o.put("ore", ore); o.put("lvl", cLvl); o.put("branch", branch);
            o.put("ecos", ecos); o.put("lambs", lambs); o.put("dj", hasDJ); o.put("tromp", hasTromp);
            o.put("time", (double) playTime);
            o.put("flags", new JSONArray(flags));
            o.put("visited", new JSONArray(visited));
            o.put("owned", new JSONArray(owned));
            o.put("equipped", new JSONArray(equipped));
            JSONObject k = new JSONObject();
            for (Map.Entry<String, Integer> e : kills.entrySet()) k.put(e.getKey(), e.getValue());
            o.put("kills", k);
            if (dropRoom != null) { o.put("dropRoom", dropRoom); o.put("dropX", (double) dropX); o.put("dropY", (double) dropY); o.put("dropBells", dropBells); }
            prefs().edit().putString("eco_save", o.toString()).apply();
        } catch (Exception ignored) {}
    }

    boolean loadGame() {
        try {
            JSONObject o = new JSONObject(prefs().getString("eco_save", "{}"));
            saveRoom = o.getString("room");
            saveX = (float) o.getDouble("sx"); saveY = (float) o.getDouble("sy");
            bells = o.getInt("bells"); ore = o.getInt("ore"); cLvl = o.getInt("lvl"); branch = o.getInt("branch");
            ecos = o.getInt("ecos"); lambs = o.getInt("lambs"); hasDJ = o.getBoolean("dj"); hasTromp = o.getBoolean("tromp");
            playTime = (float) o.optDouble("time", 0);
            flags = toSet(o.getJSONArray("flags"));
            visited = toSet(o.getJSONArray("visited"));
            owned = toSet(o.getJSONArray("owned"));
            equipped = new ArrayList<>(toSet(o.getJSONArray("equipped")));
            kills = new HashMap<>();
            JSONObject k = o.getJSONObject("kills");
            Iterator<String> it = k.keys();
            while (it.hasNext()) { String key = it.next(); kills.put(key, k.getInt(key)); }
            dropRoom = o.has("dropRoom") ? o.getString("dropRoom") : null;
            if (dropRoom != null) { dropX = (float) o.getDouble("dropX"); dropY = (float) o.getDouble("dropY"); dropBells = o.getInt("dropBells"); }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static Set<String> toSet(JSONArray a) throws Exception {
        Set<String> s = new HashSet<>();
        for (int i = 0; i < a.length(); i++) s.add(a.getString(i));
        return s;
    }

    void newGame() {
        bells = 0; ore = 0; cLvl = 1; branch = 0; ecos = 0; lambs = 0; hasDJ = false; hasTromp = false; weapon = 0;
        flags = new HashSet<>(); visited = new HashSet<>(); owned = new HashSet<>(); equipped = new ArrayList<>(); kills = new HashMap<>();
        dropRoom = null; playTime = 0;
        saveRoom = "0_0"; saveX = 2; saveY = 14 + 1 - pl.h;
        prefs().edit().remove("eco_save").apply();
        introIdx = 0;
        mode = M_INTRO;
        chip.play(Songs.PUEBLO);
    }

    void continueGame() {
        if (!loadGame()) { newGame(); return; }
        respawn();
    }

    void respawn() {
        String[] k = saveRoom.split("_");
        EcoWorld.Room r = EcoWorld.at(Integer.parseInt(k[0]), Integer.parseInt(k[1]));
        if (r == null) r = EcoWorld.at(0, 0);
        hp = maxHp();
        invul = 1.5f;
        pl.vx = pl.vy = 0;
        enterRoom(r);
        pl.x = saveX; pl.y = saveY;
        mode = M_PLAY;
        showPad(true);
    }

    @Override
    void onPauseGame() {
        if (mode == M_PLAY) { mode = M_PAUSE; showPad(false); }
        if (room != null && mode != M_TITLE && mode != M_INTRO) saveGame(false);
    }

    @Override
    void onResumeGame() {
        if (mode == M_TITLE || mode == M_INTRO) chip.play(Songs.PUEBLO);
        else if (room != null) playRoomMusic();
    }

    @Override
    public boolean onBack() {
        if (mode == M_PLAY) { mode = M_PAUSE; showPad(false); return true; }
        if (mode == M_PAUSE) { mode = M_PLAY; showPad(true); return true; }
        if (mode == M_MAP || mode == M_BEAST || mode == M_AMULET) { mode = M_PAUSE; return true; }
        if (mode == M_SHOP || mode == M_FORGE || mode == M_MAPSHOP) { mode = M_PLAY; showPad(true); return true; }
        return false;
    }

    // =====================================================================
    // Estadísticas
    // =====================================================================
    boolean eq(String id) { return equipped.contains(id); }
    int maxHp() { return 5 + (eq("corazon") ? 2 : 0); }
    float waveDmg() { return (10 + 6 * (cLvl - 1)) * (eq("garra") ? 1.2f : 1f); }
    float flameDmg() { return (5 + 2 * (cLvl - 1)) * (eq("garra") ? 1.2f : 1f); }
    float jumpV() { return JUMP * (eq("pezuna") ? 1.05f : 1f); }
    boolean flag(String f) { return f != null && !f.isEmpty() && flags.contains(f); }

    // =====================================================================
    // Salas
    // =====================================================================
    void enterRoom(EcoWorld.Room r) {
        room = r;
        enemies.clear(); shots.clear(); picks.clear(); npcs.clear(); movs.clear(); fx.clear();
        fightActive = false;
        boolean firstVisit = visited.add(r.key());
        roomNameT = firstVisit ? 3f : 1.6f;
        for (EcoWorld.Spawn s : r.spawns) {
            float x = s.x, y = s.y;
            String f = "it_" + r.key() + "_" + s.idx;
            switch (s.ch) {
                case 's': case 'b': case 'e': case 'm': case 'z': case 'v':
                    if (!r.safe) spawnEnemy(s.ch, x, y);
                    break;
                case '1': if (!flag("boss1")) spawnBoss('1', x, y); break;
                case '2': if (!flag("boss2")) spawnBoss('2', x, y); break;
                case '3':
                    if (!flag("boss3")) {
                        Enemy a = spawnBoss('3', x - 4, y), b = spawnBoss('3', x + 4, y);
                        a.role = 0; b.role = 1; a.partner = b; b.partner = a;
                    }
                    break;
                case 'c': case 'o': case 'k':
                    if (!flag(f)) pick(s.ch, x + 0.1f, y + 0.2f, s.ch == 'c' ? 40 + rnd.nextInt(41) : 1, f);
                    break;
                case 'w': if (!hasTromp) pick('w', x + 0.1f, y + 0.2f, 0, f); break;
                case 'j': if (!hasDJ) pick('j', x + 0.1f, y + 0.2f, 0, f); break;
                case '~': {
                    Mov m = new Mov();
                    m.x = x; m.y = y; m.minX = Math.max(1, x - 4); m.maxX = Math.min(EcoWorld.W - 4, x + 4);
                    movs.add(m);
                    break;
                }
                case '@': break;
                default: {
                    Npc n = new Npc();
                    n.ch = s.ch; n.x = x; n.y = y;
                    npcs.add(n);
                }
            }
        }
        if (dropRoom != null && dropRoom.equals(r.key())) {
            Pick d = pick('D', dropX, dropY, dropBells, null);
            d.settled = true;
        }
        buildRoomBitmap();
        playRoomMusic();
    }

    boolean bossAlive() {
        for (Enemy e : enemies) if (e.boss && !e.dead) return true;
        return false;
    }

    void playRoomMusic() {
        if (room == null) return;
        if (room.boss) {
            if (bossAlive() && fightActive) chip.play(Songs.BOSS);
            else if (bossAlive()) chip.silence();
            else chip.play(room.zone == EcoWorld.Z_MINAS ? Songs.MINAS : Songs.PRADERA);
        } else chip.play(room.music);
    }

    void go(int dx, int dy) {
        EcoWorld.Room n = EcoWorld.at(room.gx + dx, room.gy + dy);
        if (n == null) {   // no debería pasar: se queda dentro
            pl.x = GameKit.clamp(pl.x, 0.1f, EcoWorld.W - pl.w - 0.1f);
            pl.y = GameKit.clamp(pl.y, 0.1f, EcoWorld.H - pl.h - 0.1f);
            return;
        }
        float vy = pl.vy;
        enterRoom(n);
        if (dx < 0) pl.x = EcoWorld.W - pl.w - 0.15f;
        if (dx > 0) pl.x = 0.15f;
        if (dy < 0) { pl.y = EcoWorld.H - pl.h - 0.05f; pl.vy = Math.min(vy, -17); }
        if (dy > 0) pl.y = 0.05f;
        unstick();
    }

    /** Si al entrar quedamos dentro de un muro, busca el hueco libre más cercano. */
    void unstick() {
        if (!boxSolid(pl.x, pl.y, pl.w, pl.h)) return;
        for (int r = 1; r < 6; r++) {
            float[][] tries = {{0, -r}, {0, r}, {-r, 0}, {r, 0}, {-r, -r}, {r, -r}};
            for (float[] t : tries) {
                if (!boxSolid(pl.x + t[0], pl.y + t[1], pl.w, pl.h)) { pl.x += t[0]; pl.y += t[1]; return; }
            }
        }
    }

    // ---------------- casillas ----------------
    boolean solid(int tx, int ty) {
        if (tx < 0 || tx >= EcoWorld.W || ty < 0 || ty >= EcoWorld.H) return false;
        char c = room.t[ty][tx];
        if (c == '#') return true;
        if (c == 'G') return !flag(room.gateFlag);
        if (c == 'B') return fightActive;
        return false;
    }

    boolean oneWay(int tx, int ty) {
        if (tx < 0 || tx >= EcoWorld.W || ty < 0 || ty >= EcoWorld.H) return false;
        return room.t[ty][tx] == '=';
    }

    char tileAt(float x, float y) {
        int tx = (int) Math.floor(x), ty = (int) Math.floor(y);
        if (tx < 0 || tx >= EcoWorld.W || ty < 0 || ty >= EcoWorld.H) return '.';
        return room.t[ty][tx];
    }

    boolean boxSolid(float x, float y, float w, float h) {
        for (int ty = (int) Math.floor(y); ty <= (int) Math.floor(y + h - 0.001f); ty++)
            for (int tx = (int) Math.floor(x); tx <= (int) Math.floor(x + w - 0.001f); tx++)
                if (solid(tx, ty)) return true;
        return false;
    }

    void moveBody(Body b, float dt, boolean useOneWay) {
        b.hitWall = false;
        b.x += b.vx * dt;
        int y0 = (int) Math.floor(b.y), y1 = (int) Math.floor(b.y + b.h - 0.001f);
        if (b.vx > 0) {
            int tx = (int) Math.floor(b.x + b.w);
            for (int ty = y0; ty <= y1; ty++) if (solid(tx, ty)) { b.x = tx - b.w - 0.001f; b.vx = 0; b.hitWall = true; break; }
        } else if (b.vx < 0) {
            int tx = (int) Math.floor(b.x);
            for (int ty = y0; ty <= y1; ty++) if (solid(tx, ty)) { b.x = tx + 1.001f; b.vx = 0; b.hitWall = true; break; }
        }
        float prevBottom = b.y + b.h;
        b.y += b.vy * dt;
        b.onGround = false;
        int x0 = (int) Math.floor(b.x), x1 = (int) Math.floor(b.x + b.w - 0.001f);
        if (b.vy > 0) {
            int ty = (int) Math.floor(b.y + b.h);
            for (int tx = x0; tx <= x1; tx++) {
                if (solid(tx, ty) || (useOneWay && oneWay(tx, ty) && prevBottom <= ty + 0.01f)) {
                    b.y = ty - b.h; b.vy = 0; b.onGround = true; break;
                }
            }
        } else if (b.vy < 0) {
            int ty = (int) Math.floor(b.y);
            for (int tx = x0; tx <= x1; tx++) if (solid(tx, ty)) { b.y = ty + 1; b.vy = 0; break; }
        }
    }

    // =====================================================================
    // Creación de enemigos y objetos
    // =====================================================================
    Enemy spawnEnemy(char t, float x, float y) {
        Enemy e = new Enemy();
        e.type = t;
        switch (t) {
            case 's': e.b = new Body(0.9f, 0.6f); e.hp = 20; e.bellsMin = 2; e.bellsMax = 4; break;
            case 'b': e.b = new Body(0.9f, 0.6f); e.hp = 15; e.bellsMin = 2; e.bellsMax = 4; break;
            case 'e': e.b = new Body(0.95f, 0.7f); e.hp = 30; e.bellsMin = 4; e.bellsMax = 7; e.cd = 1.5f; break;
            case 'm': e.b = new Body(1.0f, 0.8f); e.hp = 40; e.bellsMin = 5; e.bellsMax = 9; break;
            case 'z': e.b = new Body(0.7f, 0.7f); e.hp = 25; e.bellsMin = 4; e.bellsMax = 7; break;
            default: e.b = new Body(0.9f, 0.6f); e.hp = 25; e.bellsMin = 3; e.bellsMax = 6; break; // 'v'
        }
        e.maxHp = e.hp;
        e.b.x = x + (1 - e.b.w) / 2;
        e.b.y = y + 1 - e.b.h;
        e.homeX = e.b.x; e.homeY = e.b.y;
        e.dir = rnd.nextBoolean() ? 1 : -1;
        e.t = rnd.nextFloat() * 5;
        enemies.add(e);
        return e;
    }

    Enemy spawnBoss(char t, float x, float y) {
        Enemy e = new Enemy();
        e.type = t;
        e.boss = true;
        switch (t) {
            case '1': e.b = new Body(1.8f, 1.6f); e.hp = 260; e.bellsMin = 150; e.bellsMax = 150; break;
            case '2': e.b = new Body(2.4f, 1.4f); e.hp = 320; e.bellsMin = 250; e.bellsMax = 250; break;
            default: e.b = new Body(1.4f, 1.0f); e.hp = 150; e.bellsMin = 100; e.bellsMax = 100; break;
        }
        e.maxHp = e.hp;
        e.b.x = x;
        e.b.y = y + 1 - e.b.h;
        e.homeX = x; e.homeY = e.b.y;
        e.cd = 1.5f;
        enemies.add(e);
        return e;
    }

    Pick pick(char type, float x, float y, int value, String f) {
        Pick p0 = new Pick();
        p0.type = type; p0.x = x; p0.y = y; p0.value = value; p0.flag = f;
        picks.add(p0);
        return p0;
    }

    void dropBellsAt(float x, float y, int total) {
        int n = Math.min(4, Math.max(1, total / 3));
        int left = total;
        for (int i = 0; i < n; i++) {
            int v = i == n - 1 ? left : total / n;
            left -= v;
            Pick c = pick('$', x + (rnd.nextFloat() - 0.5f) * 0.8f, y, v, null);
            c.vy = -6 - rnd.nextFloat() * 4;
        }
    }

    void float_(String s, float x, float y, int color) {
        Fx f = new Fx();
        f.s = s; f.x = x; f.y = y; f.color = color;
        fx.add(f);
    }

    void say(String s) {
        banner = s;
        bannerT = 3f;
    }

    // =====================================================================
    // Diálogos
    // =====================================================================
    void dialog(String name, Bitmap face, String[] lines, Runnable done) {
        dlg = lines; dlgIdx = 0; dlgChars = 0; dlgName = name; dlgFace = face; dlgDone = done;
        mode = M_DIALOG;
        showPad(false);
    }

    void advanceDialog() {
        String cur = dlg[dlgIdx];
        if (dlgChars < cur.length()) { dlgChars = cur.length(); return; }
        dlgIdx++;
        dlgChars = 0;
        if (dlgIdx >= dlg.length) {
            mode = M_PLAY;
            showPad(true);
            pad.releaseAll();
            Runnable r = dlgDone;
            dlgDone = null;
            if (r != null) r.run();
        }
    }

    void interact(Npc n) {
        switch (n.ch) {
            case 'S':
                hp = maxHp();
                saveGame(true);
                chip.sfx(Chip.SFX_LEVEL);
                dialog("Fardo de heno", sFardo, EcoWorld.FARDO, null);
                break;
            case 'T':
                dialog("Topo Abuelo", sTopo, flag("boss1") ? EcoWorld.TOPO_2 : EcoWorld.TOPO_1, () -> flags.add("talk_topo"));
                break;
            case 'O': {
                final String zf = "sabio_" + room.zone;
                boolean told = flag(zf);
                dialog("Sabelotodo", sSabio, told ? EcoWorld.SABIO_AGAIN : (room.zone == 0 ? EcoWorld.SABIO_0 : EcoWorld.SABIO_1),
                        () -> flags.add(zf));
                break;
            }
            case 'M': dialog("Cartógrafa Mapache", sMapache, EcoWorld.MAPACHE, () -> { mode = M_MAPSHOP; showPad(false); }); break;
            case 'P': dialog("Sapo Mercader", sSapo, EcoWorld.SAPO, () -> { mode = M_SHOP; showPad(false); }); break;
            case 'H': dialog("Herrera Topo", sHerrera, EcoWorld.HERRERA, () -> { mode = M_FORGE; showPad(false); }); break;
            case 'Q': dialog("Fantasma triste", sFantasma, EcoWorld.FANTASMA, null); break;
        }
    }

    // =====================================================================
    // Bucle
    // =====================================================================
    @Override
    void update(float dt) {
        for (Iterator<Fx> it = fx.iterator(); it.hasNext(); ) {
            Fx f = it.next();
            f.t += dt; f.y -= dt * 0.8f;
            if (f.t > f.life) it.remove();
        }
        if (bannerT > 0) bannerT -= dt;
        if (roomNameT > 0) roomNameT -= dt;
        switch (mode) {
            case M_PLAY: play(dt); break;
            case M_DIALOG:
                dlgChars += dt * 45;
                if (tapped) { advanceDialog(); tapped = false; }   // el toque no pasa a la tienda que se abre después
                break;
            case M_DEAD:
                deadT += dt;
                if (deadT > 2.2f) respawn();
                break;
            case M_INTRO:
                if (tapped) {
                    tapped = false;
                    introIdx++;
                    if (introIdx >= EcoWorld.INTRO.length) {
                        hp = maxHp();
                        enterRoom(EcoWorld.at(0, 0));
                        pl.x = 2.1f; pl.y = 15 - pl.h;
                        saveRoom = "0_0"; saveX = pl.x; saveY = pl.y;
                        mode = M_PLAY;
                        showPad(true);
                        saveGame(false);
                    }
                }
                break;
        }
    }

    void play(float dt) {
        playTime += dt;
        if (bPause.pressed()) { mode = M_PAUSE; showPad(false); return; }
        if (bMap.pressed()) { mode = M_MAP; showPad(false); return; }
        if (bSwap.pressed() && hasTromp) { weapon = 1 - weapon; say(weapon == 0 ? "🔔 Cencerro" : "🔥 Trompeta de Brasas"); }

        // ---- curarse ----
        boolean healing = bHeal.down && pl.onGround && lana >= 3 && hp < maxHp();
        if (healing) {
            healHold += dt;
            if (healHold >= 0.8f) {
                healHold = 0; lana -= 3; hp++;
                chip.sfx(Chip.SFX_POWER);
                float_("+❤", pl.x + 0.4f, pl.y - 0.3f, Color.rgb(255, 120, 150));
            }
        } else healHold = 0;

        // ---- movimiento ----
        float move = 0;
        if (!healing) {
            if (bL.down) move -= 1;
            if (bR.down) move += 1;
        }
        if (move != 0) facingR = move > 0;
        if (knockT > 0) knockT -= dt;
        else pl.vx = move * SPEED;
        walk += Math.abs(move) * dt * 9;

        coyote -= dt;
        if (pl.onGround) { coyote = 0.1f; usedDouble = false; }
        if (bJump.pressed() && !healing) {
            if (coyote > 0) { pl.vy = -jumpV(); coyote = 0; chip.sfx(Chip.SFX_JUMP); }
            else if (hasDJ && !usedDouble) { pl.vy = -DJUMP; usedDouble = true; chip.sfx(Chip.SFX_JUMP); }
        }
        pl.vy += GRAV * dt;
        if (!bJump.down && pl.vy < -5) pl.vy += GRAV * dt * 1.4f;
        if (pl.vy > MAXFALL) pl.vy = MAXFALL;

        float prevBottom = pl.y + pl.h;
        moveBody(pl, dt, true);
        // plataformas móviles
        for (Mov m : movs) {
            m.x += m.vx * dt;
            if (m.x < m.minX) { m.x = m.minX; m.vx = Math.abs(m.vx); }
            if (m.x > m.maxX) { m.x = m.maxX; m.vx = -Math.abs(m.vx); }
            boolean ox0 = pl.x + pl.w > m.x && pl.x < m.x + m.w;
            if (ox0 && pl.vy >= 0 && prevBottom <= m.y + 0.05f && pl.y + pl.h >= m.y) {
                pl.y = m.y - pl.h; pl.vy = 0; pl.onGround = true;
                pl.x += m.vx * dt;
            }
        }
        // pinchos
        if (tileAt(pl.x + pl.w / 2, pl.y + pl.h - 0.1f) == '^') { hurt(1, pl.x - (facingR ? 1 : -1)); pl.vy = -13; }

        // ---- cambio de sala ----
        float cx = pl.x + pl.w / 2, cy = pl.y + pl.h / 2;
        if (cx < 0) { go(-1, 0); return; }
        if (cx > EcoWorld.W) { go(1, 0); return; }
        if (cy < 0) { go(0, -1); return; }
        if (cy > EcoWorld.H) { go(0, 1); return; }

        // ---- reja del lago ----
        if (room.gateFlag.equals("fase2") && pl.x + pl.w > EcoWorld.W - 1.6f && !flag("lago_msg")) {
            flags.add("lago_msg");
            dialog("", null, EcoWorld.LAGO, () -> flags.remove("lago_msg"));
            pl.x -= 1;
            return;
        }

        // ---- empezar pelea de jefe ----
        if (room.boss && !fightActive && bossAlive() && pl.x > 4) {
            fightActive = true;
            chip.sfx(Chip.SFX_DOOR);
            chip.play(Songs.BOSS);
            for (Enemy e : enemies) if (e.boss) say(bossName(e.type));
        }

        // ---- hablar / usar ----
        nearNpc = null;
        for (Npc n : npcs) if (Math.abs(n.x + 0.5f - cx) < 1.4f && Math.abs(n.y + 0.5f - cy) < 1.5f) nearNpc = n;
        bUse.label = nearNpc == null ? "▲" : (nearNpc.ch == 'S' ? "DESCANSAR" : "HABLAR");
        bUse.textSize = nearNpc == null ? 18 : 12;
        // Sabelotodo habla solo la primera vez que entras en su zona
        if (nearNpc == null) for (Npc n : npcs)
            if (n.ch == 'O' && !flag("sabio_" + room.zone) && Math.abs(n.x - cx) < 5) { interact(n); return; }
        if (bUse.pressed() && nearNpc != null) { interact(nearNpc); return; }

        // ---- disparar ----
        shootCd -= dt; flameCd -= dt;
        if (weapon == 0 && bShoot.pressed() && shootCd <= 0 && !healing) {
            shootCd = 0.3f;
            int n = eq("dobleeco") ? 2 : 1;
            for (int i = 0; i < n; i++) {
                Shot s = new Shot();
                s.mine = true; s.kind = SH_WAVE;
                s.w = 0.5f; s.h = branch == 1 ? 1.1f : 0.55f;
                s.x = facingR ? pl.x + pl.w : pl.x - s.w;
                s.y = pl.y + pl.h / 2 - s.h / 2 + (n == 2 ? (i == 0 ? -0.28f : 0.28f) : 0);
                s.vx = facingR ? 16 : -16;
                s.life = branch == 2 ? 0.9f : (branch == 3 ? 0.55f : 0.45f);
                s.bounces = branch == 2 ? 2 : 0;
                s.pierce = branch == 3;
                s.dmg = waveDmg();
                shots.add(s);
            }
            chip.sfx(Chip.SFX_SHOOT);
        }
        if (weapon == 1 && bShoot.down && flameCd <= 0 && !healing) {
            flameCd = 0.07f;
            Shot s = new Shot();
            s.mine = true; s.kind = SH_FLAME;
            s.w = 0.4f; s.h = 0.4f;
            s.x = facingR ? pl.x + pl.w : pl.x - s.w;
            s.y = pl.y + pl.h / 2 - 0.2f;
            s.vx = (facingR ? 9 : -9) + pl.vx * 0.5f;
            s.vy = (rnd.nextFloat() - 0.5f) * 4;
            s.life = 0.3f;
            s.dmg = flameDmg();
            shots.add(s);
            if (rnd.nextFloat() < 0.3f) chip.sfx(Chip.SFX_HIT);
        }

        // ---- enemigos ----
        if (invul > 0) invul -= dt;
        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);
            if (e.dead) continue;
            updateEnemy(e, dt);
            if (e.flash > 0) e.flash -= dt;
            if (!e.hidden && GameKit.overlap(pl.x + 0.1f, pl.y + 0.1f, pl.w - 0.2f, pl.h - 0.1f, e.b.x + 0.1f, e.b.y + 0.1f, e.b.w - 0.2f, e.b.h - 0.2f))
                hurt(e.dmg, e.b.x + e.b.w / 2);
        }

        // ---- disparos ----
        for (int i = 0; i < shots.size(); i++) {
            Shot s = shots.get(i);
            if (s.dead) continue;
            s.life -= dt;
            if (s.life <= 0) { s.dead = true; continue; }
            s.vy += s.grav * dt;
            s.x += s.vx * dt;
            s.y += s.vy * dt;
            if (boxSolid(s.x, s.y, s.w, s.h)) {
                if (s.bounces > 0) { s.bounces--; s.vx = -s.vx; s.x += s.vx * dt * 2; }
                else { s.dead = true; continue; }
            }
            if (s.mine) {
                for (Enemy e : enemies) {
                    if (e.dead || e.hidden || s.hit.contains(e)) continue;
                    if (GameKit.overlap(s.x, s.y, s.w, s.h, e.b.x, e.b.y, e.b.w, e.b.h)) {
                        damage(e, s.dmg);
                        s.hit.add(e);
                        if (!s.pierce) { s.dead = true; break; }
                    }
                }
            } else if (GameKit.overlap(pl.x + 0.1f, pl.y + 0.1f, pl.w - 0.2f, pl.h - 0.2f, s.x, s.y, s.w, s.h)) {
                hurt(1, s.x);
                s.dead = true;
            }
        }
        for (Iterator<Shot> it = shots.iterator(); it.hasNext(); ) if (it.next().dead) it.remove();

        // ---- objetos ----
        for (Pick k : picks) {
            if (k.dead) continue;
            if (!k.settled) {
                k.vy += GRAV * 0.6f * dt;
                k.y += k.vy * dt;
                int ty = (int) Math.floor(k.y + 0.5f);
                if (k.vy > 0 && (solid((int) Math.floor(k.x + 0.25f), ty) || oneWay((int) Math.floor(k.x + 0.25f), ty))) {
                    k.y = ty - 0.5f; k.vy = 0;
                    if (k.type != '$') k.settled = true;
                }
                if (k.y > EcoWorld.H) k.dead = true;
            }
            if (k.type == '$' && eq("iman")) {
                float dx = pl.x + pl.w / 2 - k.x, dy = pl.y + pl.h / 2 - k.y;
                float d = (float) Math.hypot(dx, dy);
                if (d < 4 && d > 0.1f) { k.x += dx / d * 8 * dt; k.y += dy / d * 8 * dt; }
            }
            float kw = k.type == '$' ? 0.5f : 0.8f;
            if (GameKit.overlap(pl.x, pl.y, pl.w, pl.h, k.x, k.y, kw, kw)) collect(k);
        }
        for (Iterator<Pick> it = picks.iterator(); it.hasNext(); ) if (it.next().dead) it.remove();
        for (Iterator<Enemy> it = enemies.iterator(); it.hasNext(); ) if (it.next().dead) it.remove();
    }

    String bossName(char t) {
        return t == '1' ? "👑 REY TOPO LOCO" : t == '2' ? "👻 VAGONETA FANTASMA" : "🦇 MURCIÉGALO GEMELO";
    }

    // =====================================================================
    // Enemigos
    // =====================================================================
    void updateEnemy(Enemy e, float dt) {
        e.t += dt;
        Body b = e.b;
        float px0 = pl.x + pl.w / 2, py0 = pl.y + pl.h / 2;
        float ex = b.x + b.w / 2, ey = b.y + b.h / 2;
        float dx = px0 - ex, dy = py0 - ey;
        switch (e.type) {
            case 's': walker(e, 1.5f, dt); break;
            case 'e': {
                e.cd -= dt;
                if (e.cd <= 0 && Math.abs(dx) < 9 && Math.abs(dy) < 5) {
                    e.cd = 2.5f;
                    e.dir = Math.signum(dx);
                    enemyShot(SH_PEBBLE, ex, b.y, GameKit.clamp(dx / 1.0f, -8, 8), -10, 25, 0.35f);
                } else if (e.cd > 0.6f) walker(e, 0.8f, dt);
                else { b.vx = 0; b.vy += GRAV * dt; moveBody(b, dt, true); }
                break;
            }
            case 'm': {
                if (e.state == 0) {
                    walker(e, 1.2f, dt);
                    if (Math.abs(dy) < 1.2f && Math.abs(dx) < 8 && Math.signum(dx) == e.dir) { e.state = 1; e.cd = 1.2f; }
                } else if (e.state == 1) {
                    b.vx = e.dir * 7;
                    b.vy += GRAV * dt;
                    moveBody(b, dt, true);
                    e.cd -= dt;
                    if (e.cd <= 0 || b.hitWall || edgeAhead(e)) { e.state = 2; e.cd = 0.8f; b.vx = 0; }
                } else {
                    e.cd -= dt;
                    b.vy += GRAV * dt;
                    b.vx = 0;
                    moveBody(b, dt, true);
                    if (e.cd <= 0) e.state = 0;
                }
                break;
            }
            case 'b': case 'v': {
                float sp = e.type == 'v' ? 4.5f : 3f;
                if (Math.hypot(dx, dy) < 7) {
                    float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                    b.x += dx / d * sp * dt;
                    b.y += (dy / d * sp + (float) Math.sin(e.t * 5) * 2) * dt;
                } else {
                    b.x = e.homeX + (float) Math.sin(e.t * 1.2f) * 2.5f;
                    b.y = e.homeY + (float) Math.sin(e.t * 2.1f) * 0.8f;
                }
                b.x = GameKit.clamp(b.x, 1, EcoWorld.W - 1 - b.w);
                b.y = GameKit.clamp(b.y, 1, EcoWorld.H - 1 - b.h);
                break;
            }
            case 'z': {
                float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                if (d < 10) {
                    b.x += (dx / d * 1.3f + (float) Math.cos(e.t * 3) * 1.2f) * dt;
                    b.y += (dy / d * 1.3f + (float) Math.sin(e.t * 3.7f) * 1.2f) * dt;
                } else b.y = e.homeY + (float) Math.sin(e.t * 2) * 0.6f;
                b.x = GameKit.clamp(b.x, 1, EcoWorld.W - 1 - b.w);
                b.y = GameKit.clamp(b.y, 1, EcoWorld.H - 1 - b.h);
                break;
            }
            case '1': reyTopo(e, dt, dx); break;
            case '2': vagoneta(e, dt); break;
            case '3': gemelo(e, dt, dx, dy); break;
        }
    }

    boolean edgeAhead(Enemy e) {
        Body b = e.b;
        float fx0 = e.dir > 0 ? b.x + b.w + 0.05f : b.x - 0.05f;
        int tx = (int) Math.floor(fx0), ty = (int) Math.floor(b.y + b.h + 0.1f);
        return !solid(tx, ty) && !oneWay(tx, ty);
    }

    void walker(Enemy e, float speed, float dt) {
        Body b = e.b;
        b.vx = e.dir * speed;
        b.vy += GRAV * dt;
        moveBody(b, dt, true);
        if (b.onGround && (b.hitWall || edgeAhead(e))) e.dir = -e.dir;
        if (b.x < 0.5f) e.dir = 1;
        if (b.x > EcoWorld.W - 1.5f) e.dir = -1;
    }

    void enemyShot(int kind, float x, float y, float vx, float vy, float grav, float size) {
        Shot s = new Shot();
        s.kind = kind; s.x = x - size / 2; s.y = y; s.vx = vx; s.vy = vy; s.grav = grav;
        s.w = size; s.h = size; s.life = 4; s.dmg = 1;
        shots.add(s);
    }

    // ---- REY TOPO LOCO ----
    void reyTopo(Enemy e, float dt, float dx) {
        Body b = e.b;
        if (!fightActive) { b.vy += GRAV * dt; moveBody(b, dt, false); return; }
        e.phase2 = e.hp < e.maxHp / 2;
        float k = e.phase2 ? 1.4f : 1f;
        e.cd -= dt;
        switch (e.state) {
            case 0: // caminar
                b.vx = Math.signum(dx) * 2.5f * k;
                b.vy += GRAV * dt;
                moveBody(b, dt, false);
                if (e.cd <= 0) {
                    e.cycle++;
                    if (e.cycle % 2 == 1) { e.state = 1; e.hidden = true; e.cd = 1.6f; chip.sfx(Chip.SFX_DUCK); }
                    else { e.state = 3; e.cd = 0.5f; b.vx = 0; }
                }
                break;
            case 1: // bajo tierra: el montículo te sigue
                b.vx = Math.signum(dx) * 5 * k;
                moveBody(b, dt, false);
                if (e.cd <= 0) {
                    e.state = 2; e.hidden = false; b.vy = -16;
                    chip.sfx(Chip.SFX_BOOM);
                    for (int i = 0; i < 4; i++) float_("·", b.x + rnd.nextFloat() * b.w, b.y + b.h, Color.rgb(160, 110, 60));
                }
                break;
            case 2: // salta desde la tierra
                b.vx = 0;
                b.vy += GRAV * dt;
                moveBody(b, dt, false);
                if (b.onGround) { e.state = 0; e.cd = 2.2f / k; }
                break;
            case 3: // lanza rocas
                b.vy += GRAV * dt;
                moveBody(b, dt, false);
                if (e.cd <= 0) {
                    int n = e.phase2 ? 5 : 3;
                    for (int i = 0; i < n; i++)
                        enemyShot(SH_ROCK, b.x + b.w / 2, b.y, (dx / 1.3f) + (i - (n - 1) / 2f) * 2.2f, -13, 26, 0.5f);
                    chip.sfx(Chip.SFX_SHOOT);
                    e.state = 0; e.cd = 2.2f / k;
                }
                break;
        }
    }

    // ---- VAGONETA FANTASMA ----
    void vagoneta(Enemy e, float dt) {
        Body b = e.b;
        b.vy += GRAV * dt;
        if (!fightActive) { moveBody(b, dt, false); return; }
        e.phase2 = e.hp < e.maxHp / 2;
        if (e.state == 0) {          // pausa: aquí es más fácil golpearla
            b.vx = 0;
            e.cd -= dt;
            if (e.cd <= 0) {
                e.state = 1;
                e.dir = b.x + b.w / 2 < EcoWorld.W / 2f ? 1 : -1;
                e.cd2 = 0.5f;
                chip.sfx(Chip.SFX_DOOR);
            }
        } else {
            b.vx = e.dir * (e.phase2 ? 14 : 11);
            e.cd2 -= dt;
            if (e.cd2 <= 0) {
                e.cd2 = e.phase2 ? 0.35f : 0.5f;
                enemyShot(SH_GHOSTFIRE, b.x + b.w / 2, b.y, (rnd.nextFloat() - 0.5f) * 6, -12, 25, 0.45f);
            }
        }
        moveBody(b, dt, false);
        if (e.state == 1 && b.hitWall) {
            e.cycle++;
            if (e.phase2 && e.cycle % 2 == 1) { e.dir = -e.dir; }
            else { e.state = 0; e.cd = 1.4f; }
            chip.sfx(Chip.SFX_BOOM);
        }
    }

    // ---- MURCIÉGALO GEMELO ----
    void gemelo(Enemy e, float dt, float dx, float dy) {
        Body b = e.b;
        if (!fightActive) { b.y = e.homeY - 4 + (float) Math.sin(e.t * 2) * 0.3f; return; }
        e.enraged = e.partner == null || e.partner.dead;
        float k = e.enraged ? 1.5f : 1f;
        // cambian de papel cada 6 s
        if (!e.enraged && ((int) (e.t / 6)) % 2 == 1) e.state = 1 - e.role; else if (!e.enraged) e.state = e.role;
        if (e.enraged) e.state = (((int) (e.t / 4)) % 2);
        e.cd -= dt;
        if (e.state == 0) {          // embiste
            if (e.cd2 > 0) {
                e.cd2 -= dt;
                b.x += b.vx * dt; b.y += b.vy * dt;
            } else {
                float tx = 6 + (float) Math.sin(e.t * 0.8f) * 4 + (e.role == 0 ? 0 : 16), ty = 4;
                b.x += (tx - b.x) * Math.min(1, dt * 2);
                b.y += (ty - b.y) * Math.min(1, dt * 2);
                if (e.cd <= 0) {
                    e.cd = 2.5f / k;
                    e.cd2 = 0.9f;
                    float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                    b.vx = dx / d * 9 * k; b.vy = dy / d * 9 * k;
                }
            }
        } else {                     // chilla: lanza anillos
            float tx = 15 + (float) Math.sin(e.t * 0.9f) * 9, ty = 2.5f + (float) Math.sin(e.t * 2) * 0.5f;
            b.x += (tx - b.x) * Math.min(1, dt * 2);
            b.y += (ty - b.y) * Math.min(1, dt * 2);
            if (e.cd <= 0) {
                e.cd = 1.6f / k;
                float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                enemyShot(SH_RING, b.x + b.w / 2, b.y + b.h / 2, dx / d * 6 * k, dy / d * 6 * k, 0, 0.55f);
                chip.sfx(Chip.SFX_TALK);
            }
        }
        b.x = GameKit.clamp(b.x, 1, EcoWorld.W - 1 - b.w);
        b.y = GameKit.clamp(b.y, 1, EcoWorld.H - 1 - b.h);
    }

    // =====================================================================
    // Daño, muerte y recompensas
    // =====================================================================
    void damage(Enemy e, float d) {
        if (e.boss && !fightActive) return;
        e.hp -= d;
        e.flash = 0.1f;
        lana = Math.min(9, lana + 1);
        chip.sfx(Chip.SFX_HIT);
        float_(String.valueOf(Math.round(d)), e.b.x + e.b.w / 2, e.b.y - 0.2f, Color.WHITE);
        if (!e.boss) e.b.x += (pl.x < e.b.x ? 0.25f : -0.25f);
        if (e.hp <= 0) kill(e);
    }

    void kill(Enemy e) {
        e.dead = true;
        String id = String.valueOf(e.type);
        kills.put(id, (kills.containsKey(id) ? kills.get(id) : 0) + 1);
        int n = kills.get(id);
        if (n == 10) say("📖 ¡Secreto desbloqueado en el Bestiario!");
        if (!e.boss) {
            dropBellsAt(e.b.x + e.b.w / 2, e.b.y, e.bellsMin + rnd.nextInt(e.bellsMax - e.bellsMin + 1));
            return;
        }
        chip.sfx(Chip.SFX_BOOM);
        if (e.type == '3' && e.partner != null && !e.partner.dead) {
            say("¡El otro murciélago se enfurece!");
            return;
        }
        for (Shot s : shots) if (!s.mine) s.dead = true;
        fightActive = false;
        playRoomMusic();
        switch (e.type) {
            case '1':
                flags.add("boss1"); ecos = Math.max(ecos, 1); bells += 150;
                dialog("", null, EcoWorld.BOSS1_WIN, () -> saveGame(false));
                break;
            case '2':
                flags.add("boss2"); ecos = Math.max(ecos, 2); bells += 250;
                dialog("", null, EcoWorld.BOSS2_WIN, () -> saveGame(false));
                break;
            default:
                flags.add("boss3"); bells += 200; lambs++; owned.add("garra");
                dialog("", null, EcoWorld.BOSS3_WIN, () -> saveGame(false));
        }
        chip.sfx(Chip.SFX_LEVEL);
    }

    void hurt(int n, float fromX) {
        if (invul > 0 || mode != M_PLAY) return;
        hp -= n;
        invul = 1.2f;
        knockT = 0.25f;
        pl.vx = (pl.x + pl.w / 2 < fromX ? -1 : 1) * 7;
        pl.vy = -9;
        chip.sfx(Chip.SFX_HURT);
        float_("-" + n + "❤", pl.x + 0.4f, pl.y - 0.3f, Color.rgb(255, 90, 90));
        if (hp <= 0) die();
    }

    void die() {
        mode = M_DEAD;
        deadT = 0;
        showPad(false);
        chip.silence();
        if (bells > 0) {        // tus cascabeles se quedan donde caíste (los anteriores se pierden)
            dropRoom = room.key();
            dropX = GameKit.clamp(pl.x, 1, EcoWorld.W - 2);
            dropY = GameKit.clamp(pl.y, 1, EcoWorld.H - 2);
            dropBells = bells;
            bells = 0;
        }
        saveGame(false);
    }

    void collect(Pick k) {
        k.dead = true;
        if (k.flag != null) flags.add(k.flag);
        switch (k.type) {
            case '$': bells += k.value; chip.sfx(Chip.SFX_COIN); break;
            case 'c': bells += k.value; chip.sfx(Chip.SFX_COIN); say("🎁 Cofre: +" + k.value + " cascabeles"); break;
            case 'o': ore++; chip.sfx(Chip.SFX_POWER); say("💎 ¡Mineral de Eco! Llévaselo a la Herrera"); break;
            case 'k': lambs++; chip.sfx(Chip.SFX_LEVEL); dialog("", sLamb, EcoWorld.CORDERITO, null); break;
            case 'w': hasTromp = true; weapon = 1; chip.sfx(Chip.SFX_LEVEL); dialog("", sTromp, EcoWorld.TROMPETA, () -> bSwap.visible = true); break;
            case 'j': hasDJ = true; chip.sfx(Chip.SFX_LEVEL); dialog("", sBoots, EcoWorld.BOTAS, null); break;
            case 'D':
                bells += k.value;
                dropRoom = null;
                chip.sfx(Chip.SFX_LEVEL);
                say("🧶 ¡Recuperaste tus " + k.value + " cascabeles!");
                break;
        }
    }

    // =====================================================================
    // Dibujo
    // =====================================================================
    @Override
    void render(Canvas c) {
        int neon = Neon.color(getContext());
        if (mode == M_TITLE) { drawTitle(c, neon); return; }
        if (mode == M_INTRO) { drawIntro(c, neon); return; }

        drawWorld(c);
        drawHud(c, neon);
        if (mode == M_PLAY) pad.draw(c, neon);
        if (bannerT > 0 && banner != null) {
            int a = (int) (255 * Math.min(1, bannerT));
            RectF r = new RectF(vw / 2 - 210, 52, vw / 2 + 210, 82);
            p.setColor(Color.argb(a * 3 / 4, 0, 0, 0));
            c.drawRoundRect(r, 10, 10, p);
            text(c, banner, vw / 2, 72, 14, Neon.withAlpha(Color.WHITE, a));
        }
        if (roomNameT > 0 && mode == M_PLAY) {
            int a = (int) (255 * Math.min(1, roomNameT));
            text(c, room.name, vw / 2, 108, 18, Neon.withAlpha(Color.rgb(255, 240, 200), a));
        }

        switch (mode) {
            case M_DIALOG: drawDialog(c, neon); break;
            case M_PAUSE: drawPause(c, neon); break;
            case M_MAP: drawMap(c, neon); break;
            case M_BEAST: drawBeast(c, neon); break;
            case M_AMULET: drawAmulets(c, neon); break;
            case M_SHOP: drawShop(c, neon); break;
            case M_MAPSHOP: drawMapShop(c, neon); break;
            case M_FORGE: drawForge(c, neon); break;
            case M_DEAD: {
                p.setColor(Color.argb((int) Math.min(220, deadT * 160), 0, 0, 0));
                c.drawRect(0, 0, vw, vh, p);
                text(c, "Te has desmayado...", vw / 2, vh / 2 - 10, 22, Color.WHITE);
                if (dropRoom != null) text(c, "Tus cascabeles se quedaron donde caíste 🧶", vw / 2, vh / 2 + 18, 13, Color.rgb(255, 220, 150));
                break;
            }
        }
    }

    void drawWorld(Canvas c) {
        int top, bot;
        if (room.zone == EcoWorld.Z_MINAS) { top = Color.rgb(40, 20, 12); bot = Color.rgb(10, 6, 4); }
        else if (room.safe) { top = Color.rgb(58, 42, 26); bot = Color.rgb(20, 14, 8); }
        else { top = Color.rgb(29, 59, 74); bot = Color.rgb(10, 22, 28); }
        p.setShader(new LinearGradient(0, 0, 0, vh, top, bot, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, vw, vh, p);
        p.setShader(null);

        c.save();
        c.translate(ox, oy);
        c.scale(T, T);
        // siluetas de fondo
        p.setColor(Color.argb(40, 255, 255, 255));
        for (int i = 0; i < 6; i++) {
            float x = (i * 5.3f + room.gx * 3) % 30;
            c.drawCircle(x, 13 + (i % 3), 3 + (i % 2), p);
        }
        GameKit.draw(c, roomBmp, 0, 0, EcoWorld.W, EcoWorld.H);
        // rejas y puertas
        for (int y = 0; y < EcoWorld.H; y++)
            for (int x = 0; x < EcoWorld.W; x++) {
                char ch = room.t[y][x];
                if ((ch == 'G' && !flag(room.gateFlag)) || (ch == 'B' && fightActive)) {
                    p.setColor(ch == 'B' ? Color.rgb(150, 30, 50) : Color.rgb(90, 90, 110));
                    c.drawRect(x, y, x + 1, y + 1, p);
                    p.setColor(ch == 'B' ? Color.rgb(255, 80, 100) : Color.rgb(170, 170, 200));
                    for (float k = 0.15f; k < 1; k += 0.35f) {
                        if (y == 0 || y == EcoWorld.H - 1) c.drawRect(x + k, y, x + k + 0.12f, y + 1, p);
                        else c.drawRect(x, y + k, x + 1, y + k + 0.12f, p);
                    }
                }
            }
        // plataformas móviles
        for (Mov m : movs) {
            p.setColor(Color.rgb(200, 130, 60));
            c.drawRect(m.x, m.y, m.x + m.w, m.y + 0.4f, p);
            p.setColor(Color.rgb(255, 200, 110));
            c.drawRect(m.x, m.y, m.x + m.w, m.y + 0.12f, p);
        }
        // PNJ
        for (Npc n : npcs) {
            Bitmap b = npcSprite(n.ch);
            float bob = n.ch == 'Q' ? (float) Math.sin(playTime * 2) * 0.15f : 0;
            if (b != null) GameKit.draw(c, b, n.x - 0.1f, n.y - 0.2f + bob, 1.2f, 1.2f);
            if (n == nearNpc) {
                p.setColor(Color.WHITE);
                c.drawRect(n.x + 0.4f, n.y - 0.8f, n.x + 0.6f, n.y - 0.4f, p);
                c.drawRect(n.x + 0.4f, n.y - 0.3f, n.x + 0.6f, n.y - 0.15f, p);
            }
        }
        // objetos
        for (Pick k : picks) {
            float bob = k.settled || k.type == '$' ? (float) Math.sin(playTime * 3 + k.x) * 0.08f : 0;
            Bitmap b;
            switch (k.type) {
                case '$': b = sBell; break;
                case 'c': b = sChest; break;
                case 'o': b = sOre; break;
                case 'k': b = sLamb; break;
                case 'w': b = sTromp; break;
                case 'j': b = sBoots; break;
                default: b = sDrop;
            }
            float s = k.type == '$' ? 0.5f : 0.8f;
            if (k.type == 'D') {
                p.setColor(Color.argb(70 + (int) (60 * Math.sin(playTime * 4)), 200, 220, 255));
                c.drawCircle(k.x + 0.4f, k.y + 0.4f, 0.7f, p);
            }
            GameKit.draw(c, b, k.x, k.y + bob, s, s);
        }
        // enemigos
        for (Enemy e : enemies) drawEnemy(c, e);
        // disparos
        for (Shot s : shots) drawShot(c, s);
        // jugadora
        drawBee(c);
        c.restore();

        // números flotantes (en coordenadas de pantalla)
        for (Fx f : fx) {
            int a = (int) (255 * Math.max(0, 1 - f.t / f.life));
            text(c, f.s, ox + f.x * T, oy + f.y * T, 13, Neon.withAlpha(f.color, a));
        }
        // barra de vida del jefe
        if (fightActive) {
            float total = 0, max = 0;
            String name = "";
            for (Enemy e : enemies) if (e.boss) { total += Math.max(0, e.hp); max += e.maxHp; name = bossName(e.type); }
            if (max > 0) {
                float bw = 320, bx = vw / 2 - bw / 2, by = vh - 26;
                p.setColor(Color.argb(180, 0, 0, 0));
                c.drawRoundRect(bx - 4, by - 18, bx + bw + 4, by + 10, 6, 6, p);
                p.setColor(Color.rgb(255, 70, 90));
                c.drawRect(bx, by, bx + bw * total / max, by + 6, p);
                text(c, name, vw / 2, by - 4, 12, Color.WHITE);
            }
        }
    }

    void drawBee(Canvas c) {
        if (invul > 0 && mode == M_PLAY && ((int) (invul * 15)) % 2 == 0) return;
        Bitmap b;
        if (!pl.onGround) b = facingR ? sBeeJump : sBeeJumpL;
        else if (Math.abs(pl.vx) > 0.5f && ((int) walk) % 2 == 0) b = facingR ? sBeeRun : sBeeRunL;
        else b = facingR ? sBee : sBeeL;
        GameKit.draw(c, b, pl.x - 0.15f, pl.y - 0.2f, pl.w + 0.3f, pl.h + 0.2f);
        if (healHold > 0) {
            p.setColor(Color.argb(160, 255, 150, 200));
            c.drawCircle(pl.x + pl.w / 2, pl.y + pl.h / 2, 0.3f + healHold, p);
        }
    }

    void drawEnemy(Canvas c, Enemy e) {
        if (e.dead) return;
        Body b = e.b;
        if (e.hidden) {   // montículo de tierra
            p.setColor(Color.rgb(120, 80, 40));
            float mx = b.x + b.w / 2;
            float floorY = b.y + b.h;
            c.drawOval(mx - 0.9f, floorY - 0.45f, mx + 0.9f, floorY + 0.15f, p);
            p.setColor(Color.rgb(160, 110, 60));
            c.drawCircle(mx + (float) Math.sin(e.t * 20) * 0.3f, floorY - 0.5f, 0.12f, p);
            return;
        }
        Bitmap s;
        switch (e.type) {
            case 's': s = sBabosa; break;
            case 'b': s = ((int) (e.t * 8)) % 2 == 0 ? sBat : sBat2; break;
            case 'v': s = ((int) (e.t * 10)) % 2 == 0 ? sBatCu : sBatCu2; break;
            case 'e': s = sBeetle; break;
            case 'm': s = sMinero; break;
            case '1': s = sReyTopo; break;
            case '2': s = sVagoneta; break;
            case '3': s = e.role == 0 ? sGemelo : sGemelo2; break;
            default: s = null;
        }
        if (e.type == 'z') {
            float cx = b.x + b.w / 2, cy = b.y + b.h / 2;
            p.setColor(Color.argb(120, 255, 160, 40));
            c.drawCircle(cx, cy, 0.45f + (float) Math.sin(e.t * 12) * 0.06f, p);
            p.setColor(e.flash > 0 ? Color.WHITE : Color.rgb(255, 230, 120));
            c.drawCircle(cx, cy, 0.22f, p);
        } else if (s != null) {
            boolean flip = (e.type == 's' || e.type == 'e' || e.type == 'm' || e.type == '1') && e.dir < 0;
            c.save();
            if (flip) c.scale(-1, 1, b.x + b.w / 2, 0);
            if (e.flash > 0) {
                Paint w = new Paint();
                w.setColorFilter(new android.graphics.PorterDuffColorFilter(Color.WHITE, android.graphics.PorterDuff.Mode.SRC_ATOP));
                GameKit.draw(c, s, b.x - 0.05f, b.y - 0.1f, b.w + 0.1f, b.h + 0.1f, w);
            } else GameKit.draw(c, s, b.x - 0.05f, b.y - 0.1f, b.w + 0.1f, b.h + 0.1f);
            c.restore();
        }
        if (e.type == 'm' && e.state == 2) {
            p.setColor(Color.YELLOW);
            c.drawCircle(b.x + b.w / 2 + (float) Math.sin(e.t * 15) * 0.3f, b.y - 0.15f, 0.08f, p);
        }
        if (!e.boss && e.hp < e.maxHp) {
            p.setColor(Color.argb(160, 0, 0, 0));
            c.drawRect(b.x, b.y - 0.25f, b.x + b.w, b.y - 0.15f, p);
            p.setColor(Color.rgb(255, 80, 80));
            c.drawRect(b.x, b.y - 0.25f, b.x + b.w * e.hp / e.maxHp, b.y - 0.15f, p);
        }
    }

    void drawShot(Canvas c, Shot s) {
        switch (s.kind) {
            case SH_WAVE: {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(0.09f);
                p.setColor(Color.rgb(255, 235, 140));
                float cx = s.x + s.w / 2, cy = s.y + s.h / 2;
                RectF r = new RectF(cx - s.w / 2, s.y, cx + s.w / 2, s.y + s.h);
                c.drawArc(r, s.vx > 0 ? -60 : 120, 120, false, p);
                RectF r2 = new RectF(cx - s.w / 2 - 0.15f, s.y - 0.1f, cx + s.w / 2 - 0.15f, s.y + s.h + 0.1f);
                if (s.vx < 0) r2.offset(0.3f, 0);
                p.setColor(Color.argb(140, 255, 235, 140));
                c.drawArc(r2, s.vx > 0 ? -60 : 120, 120, false, p);
                p.setStyle(Paint.Style.FILL);
                break;
            }
            case SH_FLAME:
                p.setColor(Color.argb(200, 255, 120 + rnd.nextInt(80), 30));
                c.drawCircle(s.x + 0.2f, s.y + 0.2f, 0.18f + (0.3f - s.life) * 0.6f, p);
                break;
            case SH_PEBBLE: case SH_ROCK:
                p.setColor(s.kind == SH_ROCK ? Color.rgb(140, 100, 60) : Color.rgb(120, 120, 130));
                c.drawRect(s.x, s.y, s.x + s.w, s.y + s.h, p);
                break;
            case SH_RING:
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(0.08f);
                p.setColor(Color.rgb(220, 120, 255));
                c.drawCircle(s.x + s.w / 2, s.y + s.h / 2, s.w / 2, p);
                p.setStyle(Paint.Style.FILL);
                break;
            case SH_GHOSTFIRE:
                p.setColor(Color.argb(210, 120, 200, 255));
                c.drawCircle(s.x + s.w / 2, s.y + s.h / 2, s.w / 2, p);
                p.setColor(Color.WHITE);
                c.drawCircle(s.x + s.w / 2, s.y + s.h / 2, s.w / 5, p);
                break;
        }
    }

    void drawHud(Canvas c, int neon) {
        // vida: ovillos de lana
        for (int i = 0; i < maxHp(); i++) {
            float x = 14 + i * 20, y = 18;
            p.setColor(i < hp ? Color.rgb(255, 245, 235) : Color.argb(90, 255, 255, 255));
            c.drawCircle(x, y, 8, p);
            if (i < hp) {
                p.setColor(Color.rgb(220, 200, 190));
                c.drawCircle(x - 2, y - 2, 3, p);
            }
        }
        // lana para curar
        for (int i = 0; i < 9; i++) {
            p.setColor(i < lana ? Color.rgb(255, 150, 200) : Color.argb(60, 255, 255, 255));
            c.drawRect(8 + i * 11, 32, 16 + i * 11, 38, p);
        }
        textLeft(c, "🔔 " + bells + "   💎 " + ore + "   ✦ Ecos " + ecos + "/3", 8, 56, 13, Color.WHITE);
        textLeft(c, (weapon == 0 ? "🔔 Cencerro nv" + cLvl + (branch > 0 ? " · " + EcoWorld.BRANCH_NAMES[branch] : "") : "🔥 Trompeta"), 8, 72, 11, Color.rgb(255, 230, 150));
    }

    // ---------------- pantallas ----------------
    void overlay(Canvas c, int alpha) {
        p.setColor(Color.argb(alpha, 0, 0, 0));
        c.drawRect(0, 0, vw, vh, p);
    }

    void drawTitle(Canvas c, int neon) {
        p.setShader(new LinearGradient(0, 0, 0, vh, Color.rgb(20, 30, 60), Color.rgb(5, 5, 15), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, vw, vh, p);
        p.setShader(null);
        p.setColor(Color.argb(160, 255, 255, 255));
        for (int i = 0; i < 50; i++) c.drawRect((i * 131) % vw, (i * 71) % (vh * 0.7f), (i * 131) % vw + 1.5f, (i * 71) % (vh * 0.7f) + 1.5f, p);
        text(c, "EL PASTOR", vw / 2, 70, 38, Color.rgb(255, 240, 200));
        text(c, "DE ECOS", vw / 2, 112, 38, Color.rgb(255, 240, 200));
        GameKit.draw(c, sBee, vw / 2 - 22, 128, 44, 44);
        float y = 190;
        if (hasSave()) {
            if (menuButton(c, new RectF(vw / 2 - 120, y, vw / 2 + 120, y + 40), "▶ CONTINUAR", neon)) { continueGame(); return; }
            y += 48;
        }
        if (menuButton(c, new RectF(vw / 2 - 120, y, vw / 2 + 120, y + 40), hasSave() ? "NUEVA PARTIDA" : "▶ EMPEZAR", neon)) { newGame(); return; }
        y += 48;
        if (menuButton(c, new RectF(vw / 2 - 120, y, vw / 2 + 120, y + 40), "SALIR", neon)) ((android.app.Activity) getContext()).finish();
        text(c, "Fase 1 de 3 · se guarda al descansar en los fardos 🌾", vw / 2, vh - 12, 11, Color.GRAY);
    }

    void drawIntro(Canvas c, int neon) {
        p.setColor(Color.rgb(8, 8, 16));
        c.drawRect(0, 0, vw, vh, p);
        if (introIdx < EcoWorld.INTRO.length)
            wrap(c, EcoWorld.INTRO[introIdx], vw / 2, vh / 2 - 20, vw * 0.7f, 17, Color.WHITE, true);
        text(c, "toca para continuar ▸", vw / 2, vh - 30, 12, Color.GRAY);
    }

    void drawDialog(Canvas c, int neon) {
        RectF r = new RectF(30, vh - 120, vw - 30, vh - 14);
        box(c, r, neon, 235);
        float tx = r.left + 16;
        if (dlgFace != null) {
            GameKit.draw(c, dlgFace, r.left + 12, r.top + 14, 64, 64);
            tx = r.left + 90;
        }
        if (dlgName != null && !dlgName.isEmpty()) textLeft(c, dlgName, tx, r.top + 22, 14, neon);
        String cur = dlg[dlgIdx];
        String shown = cur.substring(0, Math.min(cur.length(), (int) dlgChars));
        txt.setTextAlign(Paint.Align.LEFT);
        wrap(c, shown, tx, r.top + (dlgName != null && !dlgName.isEmpty() ? 44 : 30), r.right - tx - 16, 14, Color.WHITE, false);
        text(c, (dlgIdx + 1) + "/" + dlg.length + " ▸", r.right - 30, r.bottom - 8, 11, Color.GRAY);
    }

    void drawPause(Canvas c, int neon) {
        overlay(c, 200);
        text(c, "PAUSA", vw / 2, 44, 26, neon);
        textLeft(c, "Ecos " + ecos + "/3 · Corderitos " + lambs + "/5 · Tiempo " + SysInfo.duration((long) (playTime * 1000)), vw / 2 - 200, 66, 12, Color.LTGRAY);
        String[] labels = {"▶ CONTINUAR", "🗺 MAPA", "📖 BESTIARIO", "📿 AMULETOS",
                Chip.musicOn(getContext()) ? "🎵 Música: SÍ" : "🎵 Música: NO",
                Chip.sfxOn(getContext()) ? "🔊 Efectos: SÍ" : "🔊 Efectos: NO", "💾 SALIR"};
        for (int i = 0; i < labels.length; i++) {
            int col = i % 2, row = i / 2;
            RectF r = new RectF(vw / 2 - 210 + col * 215, 82 + row * 52, vw / 2 - 5 + col * 215, 122 + row * 52);
            if (i == labels.length - 1) r = new RectF(vw / 2 - 210 + 215, 82 + 3 * 52, vw / 2 + 210, 122 + 3 * 52);
            if (menuButton(c, r, labels[i], neon)) {
                switch (i) {
                    case 0: mode = M_PLAY; showPad(true); pad.releaseAll(); break;
                    case 1: mode = M_MAP; break;
                    case 2: mode = M_BEAST; break;
                    case 3: mode = M_AMULET; break;
                    case 4: chip.toggleMusic(); break;
                    case 5: chip.toggleSfx(); break;
                    case 6: saveGame(false); mode = M_TITLE; chip.play(Songs.PUEBLO); break;
                }
                return;
            }
        }
        text(c, "Tus objetos se guardan al salir; volverás al último fardo en que descansaste.", vw / 2, vh - 14, 10, Color.GRAY);
    }

    boolean zoneMap(int z) { return owned.contains("mapa" + z); }

    void drawMap(Canvas c, int neon) {
        overlay(c, 225);
        text(c, "MAPA DE LANARIA", vw / 2, 30, 20, neon);
        float cw = 84, ch = 52, gx0 = vw / 2 - cw * 3, gy0 = 48;
        boolean blink = ((int) (playTime * 3)) % 2 == 0;
        for (EcoWorld.Room r : EcoWorld.ROOMS) {
            boolean vis = visited.contains(r.key()), known = vis || zoneMap(r.zone);
            if (!known) continue;
            RectF rr = new RectF(gx0 + r.gx * cw + 3, gy0 + r.gy * ch + 3, gx0 + (r.gx + 1) * cw - 3, gy0 + (r.gy + 1) * ch - 3);
            int zc = r.zone == 0 ? Color.rgb(80, 160, 90) : Color.rgb(200, 120, 60);
            p.setColor(vis ? Neon.withAlpha(zc, 150) : Color.argb(40, 255, 255, 255));
            c.drawRoundRect(rr, 6, 6, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2);
            p.setColor(zc);
            c.drawRoundRect(rr, 6, 6, p);
            p.setStyle(Paint.Style.FILL);
            // salidas
            p.setColor(zc);
            if (r.exits[1] != '#') c.drawRect(rr.right, rr.centerY() + 6, rr.right + 6, rr.centerY() + 12, p);
            if (r.exits[3] != '#') c.drawRect(rr.centerX() - 3, rr.bottom, rr.centerX() + 3, rr.bottom + 6, p);
            String icon = "";
            if (r.has('S')) icon += "🌾";
            if (r.boss && !(r.has('1') && flag("boss1")) && !(r.has('2') && flag("boss2")) && !(r.has('3') && flag("boss3"))) icon += "💀";
            if (zoneMap(r.zone) && hasLoot(r)) icon += "?";
            if (r.has('M') || r.has('P') || r.has('H')) icon += "🏪";
            if (dropRoom != null && dropRoom.equals(r.key())) icon += "🧶";
            text(c, icon, rr.centerX(), rr.centerY() + 6, 14, Color.WHITE);
            if (room == r && blink) {
                p.setColor(Color.rgb(255, 255, 120));
                c.drawCircle(rr.left + (pl.x / EcoWorld.W) * rr.width(), rr.top + (pl.y / EcoWorld.H) * rr.height(), 5, p);
            }
        }
        String hint = (zoneMap(0) && zoneMap(1)) ? "" : "Compra mapas a la Cartógrafa 🦝 para ver salas sin visitar y secretos (?).";
        text(c, "🌾 fardo  💀 jefe  🏪 tienda  ? secreto  🧶 tus cascabeles. " + hint, vw / 2, vh - 34, 10, Color.LTGRAY);
        if (menuButton(c, new RectF(vw / 2 - 70, vh - 28, vw / 2 + 70, vh - 2), "CERRAR", neon)) {
            mode = M_PLAY; showPad(true); pad.releaseAll();
        }
    }

    boolean hasLoot(EcoWorld.Room r) {
        for (EcoWorld.Spawn s : r.spawns) {
            String f = "it_" + r.key() + "_" + s.idx;
            if ((s.ch == 'c' || s.ch == 'o' || s.ch == 'k') && !flag(f)) return true;
            if (s.ch == 'w' && !hasTromp) return true;
            if (s.ch == 'j' && !hasDJ) return true;
        }
        return false;
    }

    boolean beastKnown(int i) {
        String id = EcoWorld.BEAST_IDS[i];
        return kills.containsKey(id) || flag("sabio_" + EcoWorld.BEAST_ZONE[i]);
    }

    void drawBeast(Canvas c, int neon) {
        overlay(c, 230);
        text(c, "📖 BESTIARIO DE SABELOTODO", vw / 2, 28, 18, neon);
        float lx = vw / 2 - 300;
        for (int i = 0; i < EcoWorld.BEAST_IDS.length; i++) {
            RectF r = new RectF(lx, 42 + i * 32, lx + 210, 70 + i * 32);
            boolean known = beastKnown(i);
            int k = kills.containsKey(EcoWorld.BEAST_IDS[i]) ? kills.get(EcoWorld.BEAST_IDS[i]) : 0;
            box(c, r, i == beastSel ? neon : Color.DKGRAY, 200);
            textLeft(c, known ? EcoWorld.BEAST_NAMES[i] : "???", r.left + 8, r.centerY() + 5, 12, Color.WHITE);
            textLeft(c, "×" + k, r.right - 38, r.centerY() + 5, 11, Color.GRAY);
            if (tapIn(r)) beastSel = i;
        }
        RectF d = new RectF(lx + 225, 42, vw / 2 + 300, 42 + 9 * 32 - 4);
        box(c, d, neon, 200);
        int i = beastSel;
        boolean known = beastKnown(i);
        int k = kills.containsKey(EcoWorld.BEAST_IDS[i]) ? kills.get(EcoWorld.BEAST_IDS[i]) : 0;
        boolean isBoss = i >= 6;
        textLeft(c, known ? EcoWorld.BEAST_NAMES[i] : "???", d.left + 14, d.top + 28, 18, neon);
        textLeft(c, EcoWorld.ZONE_NAMES[EcoWorld.BEAST_ZONE[i]] + (isBoss ? " · JEFE" : ""), d.left + 14, d.top + 48, 11, Color.GRAY);
        float y = wrap(c, known ? EcoWorld.BEAST_DESC[i] : "Aún no sabes nada de este ser. Habla con Sabelotodo al entrar en su zona.",
                d.left + 14, d.top + 74, d.width() - 28, 13, Color.WHITE, false);
        boolean secret = isBoss ? k > 0 : k >= 10;
        wrap(c, secret ? EcoWorld.BEAST_TIP[i] : (isBoss ? "Derrótalo para descubrir su secreto." : "Derrota " + Math.max(0, 10 - k) + " más para descubrir su secreto."),
                d.left + 14, y + 10, d.width() - 28, 13, secret ? Color.rgb(255, 220, 120) : Color.GRAY, false);
        if (menuButton(c, new RectF(vw / 2 - 70, vh - 32, vw / 2 + 70, vh - 4), "VOLVER", neon)) mode = M_PAUSE;
    }

    void drawAmulets(Canvas c, int neon) {
        overlay(c, 230);
        text(c, "📿 AMULETOS (" + equipped.size() + "/3 equipados)", vw / 2, 30, 18, neon);
        float y = 50;
        boolean any = false;
        for (int i = 0; i < EcoWorld.AMULET_IDS.length; i++) {
            String id = EcoWorld.AMULET_IDS[i];
            if (!owned.contains(id)) continue;
            any = true;
            boolean on = equipped.contains(id);
            RectF r = new RectF(vw / 2 - 230, y, vw / 2 + 230, y + 40);
            box(c, r, on ? neon : Color.DKGRAY, 210);
            textLeft(c, (on ? "◉ " : "○ ") + EcoWorld.AMULET_NAMES[i], r.left + 12, r.centerY() + 5, 14, Color.WHITE);
            textLeft(c, EcoWorld.AMULET_DESC[i], r.left + 210, r.centerY() + 5, 11, Color.LTGRAY);
            if (tapIn(r)) {
                if (on) equipped.remove(id);
                else if (equipped.size() < 3) equipped.add(id);
                else say("Solo puedes llevar 3 amuletos");
                hp = Math.min(hp, maxHp());
                chip.sfx(Chip.SFX_COIN);
            }
            y += 46;
        }
        if (!any) text(c, "Aún no tienes amuletos. El Sapo Mercader de Eco Hondo vende algunos.", vw / 2, 120, 13, Color.LTGRAY);
        if (menuButton(c, new RectF(vw / 2 - 70, vh - 32, vw / 2 + 70, vh - 4), "VOLVER", neon)) mode = M_PAUSE;
    }

    void drawShop(Canvas c, int neon) {
        overlay(c, 215);
        GameKit.draw(c, sSapo, vw / 2 - 260, 20, 48, 48);
        text(c, "🐸 SAPO MERCADER", vw / 2, 42, 18, neon);
        text(c, "Tienes 🔔 " + bells, vw / 2, 62, 13, Color.WHITE);
        float y = 76;
        for (int i = 0; i < EcoWorld.AMULET_IDS.length; i++) {
            if (EcoWorld.AMULET_PRICE[i] == 0) continue;
            String id = EcoWorld.AMULET_IDS[i];
            boolean has = owned.contains(id);
            RectF r = new RectF(vw / 2 - 240, y, vw / 2 + 240, y + 42);
            box(c, r, has ? Color.DKGRAY : neon, 210);
            textLeft(c, EcoWorld.AMULET_NAMES[i], r.left + 12, r.top + 18, 14, Color.WHITE);
            textLeft(c, EcoWorld.AMULET_DESC[i], r.left + 12, r.top + 34, 11, Color.LTGRAY);
            textLeft(c, has ? "✓ tuyo" : "🔔 " + EcoWorld.AMULET_PRICE[i], r.right - 90, r.centerY() + 5, 13,
                    has ? Color.GRAY : (bells >= EcoWorld.AMULET_PRICE[i] ? Color.rgb(255, 230, 120) : Color.rgb(255, 100, 100)));
            if (!has && tapIn(r)) {
                if (bells >= EcoWorld.AMULET_PRICE[i]) {
                    bells -= EcoWorld.AMULET_PRICE[i];
                    owned.add(id);
                    if (equipped.size() < 3) equipped.add(id);
                    chip.sfx(Chip.SFX_LEVEL);
                    say("¡Comprado y equipado: " + EcoWorld.AMULET_NAMES[i] + "!");
                } else { chip.sfx(Chip.SFX_HURT); say("Croac. No tienes suficientes cascabeles."); }
            }
            y += 48;
        }
        if (menuButton(c, new RectF(vw / 2 - 70, vh - 34, vw / 2 + 70, vh - 6), "ADIÓS", neon)) { mode = M_PLAY; showPad(true); pad.releaseAll(); }
    }

    void drawMapShop(Canvas c, int neon) {
        overlay(c, 215);
        GameKit.draw(c, sMapache, vw / 2 - 260, 20, 48, 48);
        text(c, "🦝 CARTÓGRAFA MAPACHE", vw / 2, 42, 18, neon);
        text(c, "Tienes 🔔 " + bells, vw / 2, 62, 13, Color.WHITE);
        float y = 90;
        for (int i = 0; i < EcoWorld.MAP_NAMES.length; i++) {
            boolean has = zoneMap(i);
            RectF r = new RectF(vw / 2 - 220, y, vw / 2 + 220, y + 46);
            box(c, r, has ? Color.DKGRAY : neon, 210);
            textLeft(c, "🗺 " + EcoWorld.MAP_NAMES[i], r.left + 12, r.top + 20, 14, Color.WHITE);
            textLeft(c, "Muestra todas las salas y los secretos (?)", r.left + 12, r.top + 36, 11, Color.LTGRAY);
            textLeft(c, has ? "✓ tuyo" : "🔔 " + EcoWorld.MAP_PRICE[i], r.right - 90, r.centerY() + 5, 13, has ? Color.GRAY : Color.rgb(255, 230, 120));
            if (!has && tapIn(r)) {
                if (bells >= EcoWorld.MAP_PRICE[i]) {
                    bells -= EcoWorld.MAP_PRICE[i];
                    owned.add("mapa" + i);
                    chip.sfx(Chip.SFX_LEVEL);
                    say("¡Mapa comprado! Ábrelo con 🗺");
                } else { chip.sfx(Chip.SFX_HURT); say("Te faltan cascabeles, viajera."); }
            }
            y += 56;
        }
        if (menuButton(c, new RectF(vw / 2 - 70, vh - 34, vw / 2 + 70, vh - 6), "ADIÓS", neon)) { mode = M_PLAY; showPad(true); pad.releaseAll(); }
    }

    void drawForge(Canvas c, int neon) {
        overlay(c, 215);
        GameKit.draw(c, sHerrera, vw / 2 - 260, 20, 48, 48);
        text(c, "🔨 HERRERA TOPO", vw / 2, 42, 18, neon);
        text(c, "Tienes 🔔 " + bells + "  ·  💎 " + ore + " mineral", vw / 2, 62, 13, Color.WHITE);
        text(c, "Cencerro nivel " + cLvl + "/5 · daño " + Math.round(waveDmg()) + (branch > 0 ? " · " + EcoWorld.BRANCH_NAMES[branch] : ""), vw / 2, 90, 15, Color.rgb(255, 230, 150));
        if (cLvl >= 5) {
            text(c, "¡Tu cencerro ya suena al máximo!", vw / 2, 140, 15, Color.WHITE);
        } else {
            int needB = EcoWorld.FORGE_BELLS[cLvl], needO = EcoWorld.FORGE_ORE[cLvl];
            boolean can = bells >= needB && ore >= needO;
            text(c, "Para nivel " + (cLvl + 1) + ": 🔔 " + needB + (needO > 0 ? " + 💎 " + needO : ""), vw / 2, 118, 14, can ? Color.WHITE : Color.rgb(255, 120, 120));
            if (cLvl == 2) {
                text(c, "Al nivel 3 eliges una especialidad:", vw / 2, 142, 12, Color.LTGRAY);
                for (int i = 1; i <= 3; i++) {
                    RectF r = new RectF(vw / 2 - 300 + (i - 1) * 202, 154, vw / 2 - 104 + (i - 1) * 202, 214);
                    box(c, r, can ? neon : Color.DKGRAY, 210);
                    text(c, EcoWorld.BRANCH_NAMES[i], r.centerX(), r.top + 24, 14, Color.WHITE);
                    wrap(c, EcoWorld.BRANCH_DESC[i], r.centerX(), r.top + 42, r.width() - 12, 10, Color.LTGRAY, true);
                    if (can && tapIn(r)) { branch = i; forgeUp(needB, needO); }
                }
            } else {
                RectF r = new RectF(vw / 2 - 110, 140, vw / 2 + 110, 184);
                if (menuButton(c, r, "🔨 MEJORAR", can ? neon : Color.DKGRAY) && can) forgeUp(needB, needO);
            }
        }
        wrap(c, "El mineral de eco 💎 está escondido por la pradera y las minas. ¡Busca en lo alto!", vw / 2, vh - 60, vw * 0.7f, 11, Color.GRAY, true);
        if (menuButton(c, new RectF(vw / 2 - 70, vh - 34, vw / 2 + 70, vh - 6), "ADIÓS", neon)) { mode = M_PLAY; showPad(true); pad.releaseAll(); }
    }

    void forgeUp(int needB, int needO) {
        bells -= needB;
        ore -= needO;
        cLvl++;
        chip.sfx(Chip.SFX_LEVEL);
        say("¡Cencerro nivel " + cLvl + "!");
    }

    Bitmap npcSprite(char ch) {
        switch (ch) {
            case 'S': return sFardo;
            case 'T': return sTopo;
            case 'O': return sSabio;
            case 'M': return sMapache;
            case 'P': return sSapo;
            case 'H': return sHerrera;
            case 'Q': return sFantasma;
            default: return null;
        }
    }

    // =====================================================================
    // Bitmap de la sala (arte de píxeles 8×8 por casilla)
    // =====================================================================
    void buildRoomBitmap() {
        int S = 8;
        if (roomBmp == null) roomBmp = Bitmap.createBitmap(EcoWorld.W * S, EcoWorld.H * S, Bitmap.Config.ARGB_8888);
        roomBmp.eraseColor(Color.TRANSPARENT);
        Canvas bc = new Canvas(roomBmp);
        Paint q = new Paint();
        boolean mines = room.zone == EcoWorld.Z_MINAS;
        int rock = mines ? Color.rgb(106, 58, 36) : (room.safe ? Color.rgb(110, 82, 54) : Color.rgb(90, 61, 38));
        int dark = mines ? Color.rgb(64, 32, 15) : Color.rgb(62, 42, 26);
        int edge = mines ? Color.rgb(216, 138, 64) : (room.safe ? Color.rgb(200, 160, 90) : Color.rgb(88, 192, 72));
        Random r = new Random(room.gx * 31 + room.gy * 17);
        for (int y = 0; y < EcoWorld.H; y++)
            for (int x = 0; x < EcoWorld.W; x++) {
                char ch = room.t[y][x];
                int px0 = x * S, py0 = y * S;
                if (ch == '#' || ch == 'F') {
                    q.setColor(rock);
                    bc.drawRect(px0, py0, px0 + S, py0 + S, q);
                    q.setColor(dark);
                    for (int k = 0; k < 3; k++) {
                        int sx = r.nextInt(7), sy = r.nextInt(7);
                        bc.drawRect(px0 + sx, py0 + sy, px0 + sx + (ch == 'F' ? 1 : 2), py0 + sy + 1, q);
                    }
                    if (mines && r.nextFloat() < 0.15f) {
                        q.setColor(Color.rgb(230, 150, 70));
                        bc.drawRect(px0 + 2, py0 + 3, px0 + 4, py0 + 4, q);
                    }
                    boolean airAbove = y > 0 && room.t[y - 1][x] != '#' && room.t[y - 1][x] != 'F';
                    if (airAbove) {
                        q.setColor(edge);
                        bc.drawRect(px0, py0, px0 + S, py0 + 2, q);
                        if (!mines && !room.safe) bc.drawRect(px0 + r.nextInt(6), py0 - 1, px0 + r.nextInt(6) + 1, py0, q);
                    }
                } else if (ch == '=') {
                    q.setColor(Color.rgb(160, 112, 64));
                    bc.drawRect(px0, py0, px0 + S, py0 + 3, q);
                    q.setColor(Color.rgb(208, 160, 96));
                    bc.drawRect(px0, py0, px0 + S, py0 + 1, q);
                    q.setColor(Color.rgb(110, 76, 40));
                    if (x % 3 == 0) bc.drawRect(px0 + 3, py0 + 3, px0 + 5, py0 + 6, q);
                } else if (ch == '^') {
                    q.setColor(Color.rgb(200, 200, 215));
                    for (int k = 0; k < 4; k++) {
                        int bx = px0 + k * 2;
                        bc.drawRect(bx, py0 + 4, bx + 2, py0 + 8, q);
                        bc.drawRect(bx + 0.5f, py0 + 2, bx + 1.5f, py0 + 4, q);
                    }
                }
            }
        // farolillos en los refugios
        if (room.safe) {
            for (int x = 3; x < EcoWorld.W - 2; x += 7) {
                q.setColor(Color.argb(60, 255, 200, 100));
                bc.drawCircle(x * S + 4, 2 * S, 10, q);
                q.setColor(Color.rgb(255, 210, 120));
                bc.drawRect(x * S + 2, 2 * S - 2, x * S + 6, 2 * S + 3, q);
            }
        }
    }

    // =====================================================================
    // Sprites
    // =====================================================================
    void buildSprites() {
        String bk = "wWkey";
        int[] bc = {0xfffff6ea, 0xffd8ccc0, 0xff1c1c22, 0xffffffff, 0xffffcc30};
        String[] bee = {
                "....wwww....",
                "..wwwwwwww..",
                ".wwWwwwwwww.",
                ".wwwwwwkkkw.",
                "wwwwwwkkkkk.",
                "wwWwwwkekkk.",
                "wwwwwwkkkk..",
                ".wwwwwwyw...",
                ".wwWwwwwww..",
                "..wwwwwwww..",
                "..k.k..k.k..",
                "..k.k..k.k.."};
        String[] beeRun = bee.clone();
        beeRun[10] = ".k..k..k..k.";
        beeRun[11] = "k....kk....k";
        String[] beeJump = bee.clone();
        beeJump[10] = "..kk....kk..";
        beeJump[11] = "............";
        sBee = GameKit.sprite(bee, bk, bc);
        sBeeRun = GameKit.sprite(beeRun, bk, bc);
        sBeeJump = GameKit.sprite(beeJump, bk, bc);
        sBeeL = GameKit.flipH(sBee);
        sBeeRunL = GameKit.flipH(sBeeRun);
        sBeeJumpL = GameKit.flipH(sBeeJump);

        sTopo = GameKit.sprite(new String[]{
                "............",
                "....bbbb....",
                "...bbbbbb...",
                "..bgbbbbgb..",
                "..bggbbggb..",
                "..bbbppbbb..",
                "..bwwwwwwb..",
                "...wwwwww...",
                "..bbwwwwbb..",
                ".bbbbbbbbbb.",
                ".pp.bbbb.pp.",
                "....pp.pp..."}, "bgpw", new int[]{0xff6a4a30, 0xffc0d0e0, 0xffffa0a0, 0xffeeeeee});
        sHerrera = GameKit.sprite(new String[]{
                "..........hh",
                "....bbbb..hh",
                "...bbbbbb.s.",
                "..bkbbbbkbs.",
                "..bbbppbbbs.",
                "..rrrrrrrrs.",
                "..rrrrrrrr..",
                "..rrrrrrrr..",
                ".bbrrrrrrbb.",
                ".bbbbbbbbbb.",
                ".pp.bbbb.pp.",
                "....pp.pp..."}, "bkprhs", new int[]{0xff6a4a30, 0xff111111, 0xffffa0a0, 0xffc03030, 0xff9090a0, 0xff8a5a30});
        sSabio = GameKit.sprite(new String[]{
                "..o......o..",
                "..oo....oo..",
                "..oooooooo..",
                ".oggwooggwo.",
                ".ogkgooggko.",
                ".oggoyyoggo.",
                "..ooooyooo..",
                "..oLLLLLLo..",
                "..oLLLLLLo..",
                "...oLLLLo...",
                "....oooo....",
                "....y..y...."}, "ogwkyL", new int[]{0xff8a6a40, 0xffd0d0d0, 0xffffffff, 0xff111111, 0xffffb030, 0xffd8c0a0});
        sMapache = GameKit.sprite(new String[]{
                "..g......g..",
                "..gg....gg..",
                "..gggggggg..",
                ".gkkwggwkkg.",
                ".gkewggwekg.",
                "..wwwkkwww..",
                "...wwwwww...",
                "..ggggggggp.",
                "..gggggggpp.",
                "..ggggggg.p.",
                "...gg..gg...",
                "...kk..kk..."}, "gkwep", new int[]{0xff8a8a90, 0xff222226, 0xffeeeeee, 0xffffffff, 0xfff0e0b0});
        sSapo = GameKit.sprite(new String[]{
                "....hhhh....",
                "...hhhhhh...",
                ".hhhhhhhhhh.",
                "..gwkggwkg..",
                ".gggggggggg.",
                ".grrrrrrrrg.",
                ".gggggggggg.",
                "..gyyyyyyg..",
                "..gyyyyyyg..",
                ".gggg..gggg.",
                "gg........gg",
                "............"}, "hgwkry", new int[]{0xff6a3a8a, 0xff40a040, 0xffffffff, 0xff111111, 0xffd04040, 0xffd0e080});
        sFantasma = GameKit.sprite(new String[]{
                "....wwww....",
                "..wwwwwwww..",
                ".wwwwwwwwww.",
                ".wwkwwwwkww.",
                ".wwkwwwwkww.",
                ".wwwwwwwwww.",
                ".wwwwkkwwww.",
                ".wwwwwwwwww.",
                ".wwwwwwwwww.",
                ".wwwwwwwwww.",
                ".ww.www.www.",
                ".w...w...w.."}, "wk", new int[]{0xb0e8f0ff, 0xff304060});
        sFardo = GameKit.sprite(new String[]{
                "............",
                "............",
                "..y..y.y..y.",
                ".yyyyyyyyyy.",
                "yyYyyyyyYyyy",
                "yyyyrrrryyyy",
                "yYyyyyyyyyYy",
                "yyyyyyyyyyyy",
                "yyyyrrrryyyy",
                "yyYyyyyyyYyy",
                ".yyyyyyyyyy.",
                "............"}, "yYr", new int[]{0xffe8c860, 0xffb89030, 0xff9a5a30});

        sBabosa = GameKit.sprite(new String[]{
                "........gg..",
                ".......gkgg.",
                "......ggggg.",
                "...gggggggg.",
                ".gggggggggg.",
                "gllllllllll."}, "gkl", new int[]{0xff60c060, 0xff102010, 0xffb0f0b0});
        sBat = GameKit.sprite(new String[]{
                "v..........v",
                "vv...vv...vv",
                "vvv.vvvv.vvv",
                "vvvvvrrvvvvv",
                ".vvvvvvvvvv.",
                "...v....v..."}, "vr", new int[]{0xff6a50a0, 0xffff5050});
        sBat2 = GameKit.sprite(new String[]{
                "............",
                ".....vv.....",
                ".vvvvrrvvvv.",
                "vvvvvvvvvvvv",
                "vv..vvvv..vv",
                "v....vv....v"}, "vr", new int[]{0xff6a50a0, 0xffff5050});
        sBatCu = GameKit.sprite(new String[]{
                "c..........c",
                "cc...cc...cc",
                "ccc.cccc.ccc",
                "cccccyycccc.",
                ".cccccccccc.",
                "...c....c..."}, "cy", new int[]{0xffd07a30, 0xffffff60});
        sBatCu2 = GameKit.sprite(new String[]{
                "............",
                ".....cc.....",
                ".cccccyycccc",
                "cccccccccccc",
                "cc..cccc..cc",
                "c....cc....c"}, "cy", new int[]{0xffd07a30, 0xffffff60});
        sBeetle = GameKit.sprite(new String[]{
                "....bbbb....",
                "..bbBBBBbb..",
                ".bBBbBBbBBbk",
                ".bBBbBBbBBkk",
                "bbbbbbbbbbbk",
                ".k.k.k.k.k.."}, "bBk", new int[]{0xff2a3a70, 0xff4a6ac0, 0xff111111});
        sMinero = GameKit.sprite(new String[]{
                "...yyyy.....",
                "..ooooooL...",
                "..bbbbbb....",
                ".bbkbbbbbb..",
                ".bbbbbbbppb.",
                ".bbbbbbbbb..",
                ".bbbbbbbbb..",
                "..pp...pp..."}, "yoLbkp", new int[]{0xffffd040, 0xffc08030, 0xffffffa0, 0xff7a5030, 0xff111111, 0xffffa0a0});
        sReyTopo = GameKit.sprite(new String[]{
                "....y.y.y.y.....",
                "....yyyyyyy.....",
                "...bbbbbbbbb....",
                "..bbbbbbbbbbb...",
                "..bkbbbbbbbkb...",
                "..bbbbbpppbbbb..",
                ".bbbbbbpppbbbbb.",
                ".bbwwbbbbbbwwbb.",
                "bbbbbbbbbbbbbbbb",
                "bbbbbbbbbbbbbbbb",
                ".bbbbbbbbbbbbbb.",
                ".ppp.bbbbbb.ppp.",
                "pppp........pppp",
                "................"}, "ybkpw", new int[]{0xffffd040, 0xff5a3a20, 0xffff3030, 0xffffa0a0, 0xffffffff});
        sVagoneta = GameKit.sprite(new String[]{
                "......gggg..........",
                ".....gggggg.........",
                ".....gkggkg.........",
                ".....gggggg.........",
                "......gggg..........",
                "cccccccccccccccccccc",
                "cCCCCCCCCCCCCCCCCCCc",
                "cCccCCCCccCCCCCCccCc",
                "cCCCCCCCCCCCCCCCCCCc",
                "cccccccccccccccccccc",
                "..kkk..........kkk..",
                ".kkkkk........kkkkk.",
                "..kkk..........kkk..",
                "...................."}, "gkcC", new int[]{0xb0b0e0ff, 0xff203050, 0xff7a4a2a, 0xffb87040});
        sGemelo = GameKit.sprite(new String[]{
                "v..............v",
                "vv....vvvv....vv",
                "vvv..vvvvvv..vvv",
                "vvvvvvrvvrvvvvvv",
                ".vvvvvvvvvvvvvv.",
                "..vvvvwvvwvvvv..",
                "....v......v....",
                "................"}, "vrw", new int[]{0xff6030a0, 0xffff3060, 0xffffffff});
        sGemelo2 = GameKit.sprite(new String[]{
                "v..............v",
                "vv....vvvv....vv",
                "vvv..vvvvvv..vvv",
                "vvvvvvrvvrvvvvvv",
                ".vvvvvvvvvvvvvv.",
                "..vvvvwvvwvvvv..",
                "....v......v....",
                "................"}, "vrw", new int[]{0xff3060a0, 0xff30ffd0, 0xffffffff});

        sChest = GameKit.sprite(new String[]{
                ".bbbbbbbb.",
                "bBBBBBBBBb",
                "bBBBBBBBBb",
                "yyyyyyyyyy",
                "bBBByyBBBb",
                "bBBBBBBBBb",
                "bbbbbbbbbb"}, "bBy", new int[]{0xff6a3a1a, 0xffa0602a, 0xffffd040});
        sOre = GameKit.sprite(new String[]{
                "...cc...",
                "..cCCc..",
                ".cCwCCc.",
                "cCCCCCCc",
                ".cCCCCc.",
                "..cCCc..",
                "...cc..."}, "cCw", new int[]{0xff2090c0, 0xff60e0ff, 0xffffffff});
        sLamb = GameKit.sprite(new String[]{
                "..wwww....",
                ".wwwwwwkk.",
                "wwwwwwkekk",
                "wwwwwwkkk.",
                ".wwwwwww..",
                "..k.k.k.k."}, "wke", new int[]{0xfffff6ea, 0xff1c1c22, 0xffffffff});
        sTromp = GameKit.sprite(new String[]{
                "........yy",
                ".......yyy",
                "yyyyyyyyyy",
                "yryyyyyyyy",
                ".......yyy",
                "........yy"}, "yr", new int[]{0xffffc030, 0xffff6020});
        sBoots = GameKit.sprite(new String[]{
                ".rr...rr..",
                ".rr...rr..",
                ".rr...rr..",
                ".rrrr.rrrr",
                ".wwww.wwww"}, "rw", new int[]{0xffd03030, 0xffffffff});
        sBell = GameKit.sprite(new String[]{
                "..yy..",
                ".yyyy.",
                ".yyyy.",
                "yyyyyy",
                "..k..."}, "yk", new int[]{0xffffd040, 0xff805020});
        sDrop = GameKit.sprite(new String[]{
                "..gggg..",
                ".gGgggg.",
                "gggGgggg",
                "ggggGggg",
                "gggggGgg",
                ".ggggggg",
                "..gggg.g"}, "gG", new int[]{0xffc0c8e0, 0xff8890b0});
    }
}
