package com.aplauso.encuentra;

import java.util.ArrayList;
import java.util.List;

/**
 * El mundo de EL PASTOR DE ECOS (fase 1): salas, diálogos, bestiario y tiendas.
 *
 * Cada sala mide 30 x 16 casillas. Leyenda:
 *  # muro  . aire  = plataforma (se atraviesa desde abajo)  ^ pinchos  F pared falsa (secreto)
 *  @ inicio  S fardo (guardar)  T Topo Abuelo  O Sabelotodo  M Cartógrafa Mapache  P Sapo Mercader
 *  H Herrera Topo  Q Fantasma triste
 *  s babosa  b murciélago  e escarabajo roca  m topo minero  z chispa  v murciélago de cobre
 *  c cofre  o mineral de eco  k corderito  w Trompeta de Brasas  j botas de doble salto  ~ plataforma móvil
 *  1 Rey Topo Loco  2 Vagoneta Fantasma  3 Murciégalo Gemelo
 * Salidas (izquierda, derecha, arriba, abajo): '#' ninguna, '.' abierta, 'F' pared falsa,
 *  'G' reja (se abre con una bandera), 'B' puerta de jefe.
 */
public class EcoWorld {
    static final int W = 30, H = 16;
    static final int Z_PRADERA = 0, Z_MINAS = 1;
    static final String[] ZONE_NAMES = {"Pradera Hundida", "Minas de Cobre"};

    static class Spawn {
        char ch;
        int x, y, idx;
    }

    static class Room {
        int gx, gy, zone;
        String name, gateFlag = "";
        char[] exits;          // L R U D
        boolean safe, boss;
        Chip.Song music;
        char[][] t = new char[H][W];
        final List<Spawn> spawns = new ArrayList<>();

        String key() { return gx + "_" + gy; }
        boolean has(char c) { for (Spawn s : spawns) if (s.ch == c) return true; return false; }
    }

    static final List<Room> ROOMS = new ArrayList<>();

    static Room at(int gx, int gy) {
        for (Room r : ROOMS) if (r.gx == gx && r.gy == gy) return r;
        return null;
    }

    static Room room(int gx, int gy, int zone, String name, String exits, Chip.Song music, String... rows) {
        Room r = new Room();
        r.gx = gx; r.gy = gy; r.zone = zone; r.name = name; r.music = music;
        r.exits = exits.toCharArray();
        int idx = 0;
        for (int y = 0; y < H; y++) {
            String row = y < rows.length ? rows[y] : "";
            for (int x = 0; x < W; x++) {
                char ch = x < row.length() ? row.charAt(x) : '.';
                if (y == 0 || y == H - 1 || x == 0 || x == W - 1) ch = '#';
                if ("#.=^F".indexOf(ch) < 0) {
                    Spawn s = new Spawn();
                    s.ch = ch; s.x = x; s.y = y; s.idx = idx++;
                    r.spawns.add(s);
                    ch = '.';
                }
                r.t[y][x] = ch;
            }
        }
        // salidas
        carve(r, r.exits[0], 0, 12, 0, 14);
        carve(r, r.exits[1], W - 1, 12, W - 1, 14);
        carve(r, r.exits[2], 13, 0, 16, 0);
        carve(r, r.exits[3], 13, H - 1, 16, H - 1);
        ROOMS.add(r);
        return r;
    }

    private static void carve(Room r, char spec, int x0, int y0, int x1, int y1) {
        if (spec == '#') return;
        for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) r.t[y][x] = spec;
        if (spec == 'B') r.boss = true;
    }

    static final String FULL = "##############################";
    static final String OPEN = "#............................#";

    static {
        // ======================= PRADERA HUNDIDA =======================
        room(0, 0, Z_PRADERA, "Pradera Hundida · Inicio", "#.##", Songs.PRADERA,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#....................c.......#",
                "#..................=====.....#",
                OPEN, OPEN,
                "#.............=====..........#",
                OPEN,
                "#.@..S.....T............O....#",
                FULL);

        room(1, 0, Z_PRADERA, "Prados del Eco", "..#.", Songs.PRADERA,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#......b.....................#",
                OPEN,
                "#..........======............#",
                OPEN,
                "#....===..............===....#",
                OPEN,
                "#.........===....===.........#",
                "#...s................s.......#",
                FULL);

        room(2, 0, Z_PRADERA, "Colinas Calladas", "..##", Songs.PRADERA,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#..........b.................#",
                OPEN,
                "#.................=====......#",
                OPEN,
                "#..........=====.............#",
                "#.......................e....#",
                "#......................####..#",
                "#.....###..............####..#",
                "#.....###.....s........####..#",
                FULL);

        Room ref1 = room(3, 0, Z_PRADERA, "Refugio de la Pradera", ".##.", Songs.PUEBLO,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#.........===....===.........#",
                "#....S....................M..#",
                FULL);
        ref1.safe = true;

        room(0, 1, Z_PRADERA, "Cueva Secreta", "#.##", Songs.PRADERA,
                FULL, FULL, FULL, FULL, FULL, FULL, FULL,
                "#####......................###",
                "####........................##",
                "###..........................#",
                "##...........====............#",
                OPEN,
                "#.....k......................#",
                "#....###.....................#",
                "#....###..........c..........#",
                FULL);

        Room pueblo = room(1, 1, Z_PRADERA, "Eco Hondo (pueblo)", "F..G", Songs.PUEBLO,
                FULL, OPEN, OPEN,
                "#...........======...........#",
                OPEN, OPEN,
                "#.....=====..................#",
                OPEN, OPEN,
                "#.........====.......====....#",
                OPEN, OPEN,
                "#...=====..........=====.....#",
                "#.........===....===.........#",
                "#.S...P...H.............M....#",
                FULL);
        pueblo.safe = true;
        pueblo.gateFlag = "boss1";

        room(2, 1, Z_PRADERA, "Pozo de Raíces", "..##", Songs.PRADERA,
                FULL, OPEN,
                "#...........o................#",
                "#..........====..............#",
                OPEN, OPEN,
                "#.....====..........====.....#",
                OPEN,
                "#...b.......................b#",
                "#..........=====.............#",
                OPEN,
                "#...................e........#",
                "#....====...........=====....#",
                OPEN,
                "#..s......^^^^...........s...#",
                FULL);

        room(3, 1, Z_PRADERA, "Antesala del Topo", "...#", Songs.PRADERA,
                FULL, OPEN, OPEN,
                "#...........======...........#",
                OPEN, OPEN,
                "#....=====...................#",
                "#....................b.......#",
                OPEN,
                "#........=====.......=====...#",
                OPEN, OPEN,
                "#...=====..........=====.....#",
                OPEN,
                "#.......s.............e......#",
                FULL);

        room(4, 1, Z_PRADERA, "Guarida del Rey Topo", "B###", Songs.BOSS,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#.....====..........====.....#",
                OPEN,
                "#...................1........#",
                FULL);

        // ======================= MINAS DE COBRE =======================
        room(1, 2, Z_MINAS, "Entrada de las Minas", "#..#", Songs.MINAS,
                FULL, OPEN, OPEN,
                "#...........======...........#",
                OPEN, OPEN,
                "#.......=====................#",
                OPEN, OPEN,
                "#.............=====..........#",
                OPEN, OPEN,
                "#........=====...............#",
                OPEN,
                "#...O.........................",
                FULL);

        room(2, 2, Z_MINAS, "Galería de Cobre", "..#.", Songs.MINAS,
                FULL, OPEN, OPEN, OPEN, OPEN,
                "#.....v...............v......#",
                OPEN,
                "#...........~................#",
                OPEN,
                "#....=====...........=====...#",
                OPEN,
                "#...z..................z.....#",
                OPEN,
                "#.........===....===.........#",
                "#...m.................m......#",
                FULL);

        Room ref2 = room(3, 2, Z_MINAS, "Refugio Minero", "..##", Songs.PUEBLO,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#...=====............=====...#",
                OPEN,
                "#.....S.............M........#",
                FULL);
        ref2.safe = true;

        room(4, 2, Z_MINAS, "Pozo Minero", "..##", Songs.MINAS,
                FULL, OPEN,
                "#.............o..............#",
                "#............====............#",
                OPEN, OPEN,
                "#.......====.........====....#",
                OPEN, OPEN,
                "#...........=====............#",
                OPEN,
                "#....v..................v....#",
                "#...=====...........=====....#",
                OPEN,
                "#..m..........z..........m...#",
                FULL);

        room(5, 2, Z_MINAS, "Nido Gemelo", "B###", Songs.BOSS,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#..............3.............#",
                OPEN, OPEN,
                "#..........========..........#",
                OPEN, OPEN,
                "#....=====..........=====....#",
                OPEN, OPEN,
                FULL);

        room(2, 3, Z_MINAS, "Minas Profundas", "F..#", Songs.MINAS,
                FULL, OPEN, OPEN, OPEN,
                "#...........======...........#",
                OPEN, OPEN, OPEN,
                "#.....=====..........=====....#",
                OPEN,
                "#.......................z....#",
                OPEN,
                "#.........=====..............#",
                OPEN,
                "#..j......m..................#",
                FULL);

        room(1, 3, Z_MINAS, "Cámara de Brasas", "#.##", Songs.MINAS,
                FULL, FULL, FULL, FULL, FULL, FULL,
                "####......................####",
                "###........................###",
                "##..........................##",
                OPEN, OPEN,
                "#.........====...............#",
                OPEN, OPEN,
                "#.....w..........o...........#",
                FULL);

        room(3, 3, Z_MINAS, "Raíles Olvidados", "..##", Songs.MINAS,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#..............o.............#",
                "#............=====...........#",
                OPEN, OPEN,
                "#.....=====.........=====....#",
                "#....................z.......#",
                OPEN, OPEN,
                "#....Q........m..............#",
                FULL);

        Room vag = room(4, 3, Z_MINAS, "Túnel de la Vagoneta", "BG##", Songs.BOSS,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#......====........====......#",
                OPEN, OPEN,
                "#..............2.............#",
                FULL);
        vag.gateFlag = "fase2";

        // las salas de la izquierda/derecha de "Minas Profundas" y del pueblo usan paredes falsas
        // (F en la salida); su vecina tiene la salida abierta para poder volver.
    }

    // =====================================================================
    // Diálogos
    // =====================================================================
    static final String[] INTRO = {
            "En el valle de LANARIA todo hacía ruido: las campanas, los grillos, los balidos de las ovejas.",
            "Una noche bajó de la montaña LA POLILLA GRIS... y se comió todos los sonidos del mundo.",
            "Ahora el valle está en silencio. Solo un cencerro sigue sonando: el tuyo.",
            "Eres BEE, una ovejita pequeña. Baja a las cuevas, recupera los 3 ECOS robados y devuelve la voz a Lanaria."
    };

    static final String[] TOPO_1 = {
            "¡Bee! Menos mal que tu cencerro aún suena... Soy el Topo Abuelo.",
            "La Polilla Gris escondió los ECOS bajo tierra. El primero lo guarda el REY TOPO LOCO, al este, más allá del Pozo de Raíces.",
            "Toca 🔔 para lanzar ondas con tu cencerro. Si te hieren, mantén 🧶 para curarte con la lana que ganas al golpear.",
            "Los fardos de heno 🌾 son refugios: descansa en ellos para guardar la partida y recuperar la vida.",
            "Y si caes... tus cascabeles se quedarán donde caíste. Vuelve a por ellos. ¡Suerte, pequeña!"
    };
    static final String[] TOPO_2 = {
            "¡Recuperaste un Eco! ¿Oyes eso? Los grillos han vuelto a cantar un poquito.",
            "La reja de Eco Hondo se ha abierto. Las Minas de Cobre esperan abajo. Dicen que allí vive una vagoneta que corre sola..."
    };

    static final String[] SABIO_0 = {
            "¡Ujú! Soy Sabelotodo, y lo sé TODO de los bichos de cada zona.",
            "En la PRADERA HUNDIDA verás BABOSAS: lentas y torpes, pero no las toques.",
            "Los MURCIÉLAGOS vuelan en ondas. Dispara cuando bajen a tu altura.",
            "Los ESCARABAJOS ROCA lanzan piedras en arco. Acércate entre lanzamiento y lanzamiento.",
            "Al fondo vive el REY TOPO LOCO. Cuando se esconde bajo tierra, fíjate en el montículo que se mueve... y salta.",
            "Lo apunto todo en tu BESTIARIO (menú ⏸). Si derrotas 10 de un mismo bicho, te cuento su secreto."
    };
    static final String[] SABIO_1 = {
            "¡Ujú! Las MINAS DE COBRE. Aquí los bichos muerden más.",
            "Los TOPOS MINEROS embisten si te ven en línea recta. ¡Salta por encima!",
            "Las CHISPAS flotan y te persiguen despacio. Mejor de lejos.",
            "Los MURCIÉLAGOS DE COBRE son como los de la pradera, pero el doble de rápidos.",
            "Dicen que algunas paredes de las minas suenan... huecas. Ujú.",
            "Y en los raíles del fondo corre la VAGONETA FANTASMA. Cuando pase, salta. Cuando pare, ¡golpea!"
    };
    static final String[] SABIO_AGAIN = {"Ujú. Mira tu BESTIARIO en el menú ⏸: ahí está todo lo que sé."};

    static final String[] MAPACHE = {"¡Hola, viajera! Soy la Cartógrafa. Dibujo mapas de todo lo que hay bajo tierra. ¿Compras uno?"};
    static final String[] SAPO = {"Croac. Amuletos, amuletos. Te ayudan, pero solo puedes llevar 3 a la vez. Croac."};
    static final String[] HERRERA = {"Soy la Herrera. Dame cascabeles y MINERAL DE ECO y haré que tu cencerro suene más fuerte."};
    static final String[] FARDO = {"Descansas en el fardo de heno... Partida guardada. Vida recuperada."};
    static final String[] FANTASMA = {
            "...Hola. Nadie me oye desde que llegó la Polilla.",
            "Perdí mi nana favorita en el Lago Helado. Si algún día cruzas el hielo... ¿la buscarías por mí?",
            "(Esta misión continuará en la fase 2.)"
    };
    static final String[] TROMPETA = {
            "¡Has encontrado la TROMPETA DE BRASAS! 🔥",
            "Mantén 🔔 para soltar una llamarada de corto alcance. Cambia de arma con ⇄."
    };
    static final String[] BOTAS = {"¡BOTAS DE DOBLE SALTO! Pulsa ⬆ otra vez en el aire para saltar de nuevo."};
    static final String[] CORDERITO = {"¡Un CORDERITO perdido! Lo llevas de vuelta al rebaño. (Encuéntralos todos para el final verdadero.)"};
    static final String[] LAGO = {"El hielo bloquea el paso al LAGO HELADO.", "(Fase 2 — llegará en una próxima versión.)"};

    static final String[] BOSS1_WIN = {
            "¡El REY TOPO LOCO se rinde y suelta algo brillante!",
            "Has recuperado el ECO DE LAS CAMPANAS. 🔔 (1 de 3)",
            "A lo lejos, la reja de Eco Hondo se abre: el camino a las MINAS DE COBRE está libre."
    };
    static final String[] BOSS2_WIN = {
            "La VAGONETA FANTASMA se detiene para siempre...",
            "Has recuperado el ECO DEL COBRE. ⚙ (2 de 3)",
            "Más allá de los raíles, el LAGO HELADO sigue cerrado por el hielo.",
            "★ FIN DE LA FASE 1 ★  — CONTINUARÁ en la próxima versión.",
            "Puedes seguir explorando: aún quedan secretos, minerales y un jefe opcional en las minas."
    };
    static final String[] BOSS3_WIN = {
            "¡Los MURCIÉLAGOS GEMELOS caen a la vez!",
            "Entre sus plumas había un CORDERITO asustado y un amuleto: GARRA GEMELA (+20 % de daño)."
    };

    // =====================================================================
    // Bestiario
    // =====================================================================
    static final String[] BEAST_IDS = {"s", "b", "e", "m", "z", "v", "1", "2", "3"};
    static final String[] BEAST_NAMES = {"Babosa", "Murciélago", "Escarabajo Roca", "Topo Minero", "Chispa",
            "Murciélago de Cobre", "Rey Topo Loco", "Vagoneta Fantasma", "Murciégalo Gemelo"};
    static final int[] BEAST_ZONE = {0, 0, 0, 1, 1, 1, 0, 1, 1};
    static final String[] BEAST_DESC = {
            "Se arrastra de un lado a otro. Lenta, pegajosa y muy cabezota.",
            "Vuela en ondas cerca del techo y baja a por ti cuando te ve.",
            "Camina despacio y lanza piedras en arco cuando te tiene a tiro.",
            "Cava por las minas. Si te ve en línea recta, embiste a toda velocidad.",
            "Una chispa de cobre viva. Flota y te persigue sin prisa.",
            "Primo minero del murciélago. Más rápido y más resistente.",
            "Señor de la Pradera Hundida. Se esconde bajo tierra y sale disparado.",
            "Una vagoneta que corre sola por los raíles, guiada por un fantasma.",
            "Dos murciélagos que pelean como uno. Uno embiste, el otro chilla."
    };
    static final String[] BEAST_TIP = {
            "SECRETO: dale por la espalda; se gira tarde y no puede contraatacar.",
            "SECRETO: después de bajar en picado tarda un segundo en volver a subir. ¡Ahí!",
            "SECRETO: entre piedra y piedra pasan 2,5 segundos. Cuenta y acércate.",
            "SECRETO: tras embestir se queda aturdido un momento. Golpéalo entonces.",
            "SECRETO: la Trompeta de Brasas las apaga en un instante.",
            "SECRETO: si te quedas quieto en una esquina, pasan de largo.",
            "SECRETO: cuando sale de la tierra queda expuesto. Muévete en cuanto veas el montículo.",
            "SECRETO: en la segunda mitad pasa dos veces seguidas. Espera la pausa larga.",
            "SECRETO: si derribas a uno, el otro se enfurece. Bájalos parejos."
    };

    // =====================================================================
    // Tiendas
    // =====================================================================
    static final String[] AMULET_IDS = {"corazon", "iman", "dobleeco", "pezuna", "garra"};
    static final String[] AMULET_NAMES = {"Corazón de Lana", "Imán de Cascabeles", "Doble Eco", "Pezuña Ligera", "Garra Gemela"};
    static final String[] AMULET_DESC = {"+2 corazones de vida", "Atrae los cascabeles cercanos", "Disparas dos ondas a la vez",
            "Saltas un 10 % más alto", "+20 % de daño (premio de jefe)"};
    static final int[] AMULET_PRICE = {150, 120, 300, 200, 0};

    static final String[] MAP_NAMES = {"Mapa de la Pradera", "Mapa de las Minas"};
    static final int[] MAP_PRICE = {60, 120};

    static final int[] FORGE_BELLS = {0, 100, 250, 450, 700};   // para pasar al nivel 2..5
    static final int[] FORGE_ORE = {0, 0, 1, 1, 2};
    static final String[] BRANCH_NAMES = {"", "Onda Ancha", "Eco Rebotante", "Nota Aguda"};
    static final String[] BRANCH_DESC = {"", "Ondas más altas: golpean a varios", "Rebotan en las paredes 2 veces", "Atraviesan a los enemigos"};
}
