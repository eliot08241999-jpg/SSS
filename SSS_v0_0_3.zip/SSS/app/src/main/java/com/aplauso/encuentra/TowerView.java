package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * TORRE ARRIBA — roguelike vertical.
 * Sube piso a piso, gana XP, reparte puntos en 5 estadísticas y llega al piso 1000.
 * Si caes por debajo de la pantalla o te quedas sin vida, se reinicia todo.
 */
public class TowerView extends GameKit.GameView implements ArcadeActivity.Backable {

    // =====================================================================
    // EQUILIBRIO — todos los números del juego están aquí para ajustarlos fácil
    // =====================================================================
    static final float FLOOR_H = 300, ROW_GAP = 60;
    static final float GRAVITY = 1400, JUMP_V = 490, MOVE_V = 190;
    static final int START_HP = 50, HP_PER_PT = 25, MAX_HP = 1000;
    static final int VIDA_MAX_PTS = 38, DANO_MAX_PTS = 15, SALTO_MAX_PTS = 10, DEF_MAX_PTS = 15, ROBO_MAX_PTS = 18;
    static final int BASE_DMG = 10, DMG_PER_PT = 2;
    static final float JUMP_PER_PT = 0.04f;
    static final int DEF_PTS_PER_SHIELD = 5, MAX_SHIELDS = 3;
    static final float SHIELD_RECHARGE = 30f;
    static final float ROBO_BASE = 1f, ROBO_PER_PT = 0.5f;
    static final int PTS_PER_LEVEL = 4, BOSS_CHEST_PTS = 2;
    static final int ENEMY_HP = 30, ENEMY_DMG = 8;
    static final float BOSS_HP_MULT = 6, STRONG_HP_MULT = 12, GUARD_HP_MULT = 20;
    static final float BOSS_DMG_MULT = 2, GUARD_DMG_MULT = 3;
    static final int BOSS_XP = 50, STRONG_XP = 100, GUARD_XP = 200;
    static final int AMMO_MAX = 12, AMMO_PER_CRYSTAL = 3;
    static final float PISTOL_MULT = 0.6f;
    static final int FINAL_FLOOR = 1000;

    static int xpNeed(int lvl) { return 50 + 10 * (lvl - 1); }

    static float hpScale(int f) { return 1 + 0.04f * Math.min(f, 60) + 0.005f * Math.max(0, f - 60); }

    static float dmgScale(int f) {
        if (f <= 60) return 1 + 0.04f * f;
        return (float) (3.4 * Math.pow(1.003, f - 60));   // a ~piso 900 un Guardián quita ~1000
    }

    // =====================================================================
    // Entidades
    // =====================================================================
    static final int P_NORMAL = 0, P_MOVING = 1, P_BREAK = 2, P_SPRING = 3, P_CLOUD = 4, P_GROUND = 5, P_GATE = 6;

    static class Plat {
        float x, y, w, h = 10, vx, minX, maxX, timer = -1;
        int type, floor;
        boolean dead;
    }

    static final int E_SLUG = 0, E_BAT = 1, E_MAGE = 2,
            B_SLUG = 10, B_BAT = 11, B_MAGE = 12,
            G_GOLEM = 20, G_DRAGON = 21, G_KNIGHT = 22, G_EYE = 23;

    static class Enemy {
        int type, tier, floor, xp;   // tier: 0 normal, 1 jefe, 2 jefe fuerte, 3 guardián
        float x, y, w, h, vx, vy, hp, maxHp, dmg, t, cd, cd2, flash, baseX, baseY, dir = 1;
        int state, swingId = -1;
        Plat plat;
        boolean dead;
        float laserT = -1, laserPos; int laserMode;
        String name;
    }

    static final int S_PLAYER = 0, S_ORB = 1, S_WAVE = 2, S_ROCK = 3, S_FIRE = 4, S_SLASH = 5;

    static class Shot {
        float x, y, vx, vy, r, dmg, life;
        int kind;
        boolean mine, dead;
    }

    static final int I_CRYSTAL = 0, I_HEART = 1, I_WINGS = 2, I_SHIELD = 3, I_MAGNET = 4, I_POWER = 5, I_CHEST = 6;

    static class Item {
        float x, y, t;
        int type;
        boolean dead;
    }

    static class Fx {
        float x, y, t, life = 0.9f, vy = -40;
        String s;
        int color;
    }

    // =====================================================================
    // Estado
    // =====================================================================
    static final int ST_MENU = 0, ST_PLAY = 1, ST_PAUSE = 2, ST_DEAD = 3, ST_END = 4;
    int state = ST_MENU;

    final List<Plat> plats = new ArrayList<>();
    final List<Enemy> enemies = new ArrayList<>();
    final List<Shot> shots = new ArrayList<>();
    final List<Item> items = new ArrayList<>();
    final List<Fx> fx = new ArrayList<>();
    final Random rnd = new Random();

    long seed;
    int genTop;          // último piso generado
    float pathX = 180;
    float camY;
    float runTime;
    int maxFloor = 1, lastBossFloor = 0;

    // jugador
    float px, py, pvx, pvy, pw = 16, ph = 22;
    boolean onGround, facingRight = true;
    Plat groundPlat;
    float coyote, invul, swingT, swingCd, shotCd, walkAnim;
    int swingCounter;
    int lvl, xp, pts, pVida, pDano, pSalto, pDef, pRobo, ammo;
    float hp;
    final float[] shieldReady = new float[MAX_SHIELDS];
    float wingsT, magnetT, powerT;
    boolean tempShield;
    int kills;

    // final
    float endT;
    float princessX, knightX;

    // controles
    GameKit.Btn bLeft, bRight, bJump, bSword, bGun, bPause;

    // sprites
    Bitmap sKnight, sKnightRun, sKnightJump, sKnightL, sKnightRunL, sKnightJumpL, sPrincess, sPrincessL,
            sSlug, sBat, sBat2, sMage, sGolem, sDragon, sDKnight, sEye, sDoor, sDoorOpen, sSword, sCrown;

    TowerView(Context c) {
        super(c);
        buildSprites();
    }

    // =====================================================================
    // Tamaño y botones
    // =====================================================================
    @Override
    void computeScale(int w, int h) {
        scale = w / 360f;
        vw = 360;
        vh = h / scale;
    }

    @Override
    void layout() {
        float b = vh - 18;
        bLeft = pad.add("◀", 10, b - 74, 80, b, 30);
        bRight = pad.add("▶", 88, b - 74, 158, b, 30);
        bJump = pad.add("⬆", 282, b - 80, 352, b - 6, 30);
        bJump.round = true;
        bSword = pad.add("⚔", 208, b - 62, 270, b, 26);
        bSword.round = true;
        bGun = pad.add("🔫", 238, b - 140, 296, b - 82, 22);
        bGun.round = true;
        bPause = pad.add("⏸", 312, 8, 352, 44, 20);
        setPlayButtons(state == ST_PLAY || state == ST_PAUSE);
    }

    void setPlayButtons(boolean v) {
        for (GameKit.Btn b : pad.btns) b.visible = v;
    }

    // =====================================================================
    // Partida nueva / guardar / cargar
    // =====================================================================
    void newRun() {
        seed = System.nanoTime();
        lvl = 1; xp = 0; pts = 0;
        pVida = pDano = pSalto = pDef = pRobo = 0;
        hp = maxHp();
        ammo = AMMO_MAX;
        runTime = 0;
        lastBossFloor = 0;
        startAtFloor(1);
        clearSave();
    }

    void startAtFloor(int f) {
        plats.clear(); enemies.clear(); shots.clear(); items.clear(); fx.clear();
        maxFloor = f;
        genTop = f - 1;
        pathX = 180;
        float baseY = baseY(f);
        if (f > 1 && f % 15 != 0) {          // suelo seguro al continuar una partida
            Plat g = new Plat();
            g.type = P_GROUND; g.x = 0; g.w = 360; g.y = baseY + 40; g.floor = f;
            plats.add(g);
            py = g.y - ph;
        } else {
            py = baseY - ph;
        }
        px = 172;
        pvx = pvy = 0;
        camY = py - vh * 0.6f;
        for (int i = 0; i < 3; i++) genFloor(++genTop);
        wingsT = magnetT = powerT = 0;
        tempShield = false;
        for (int i = 0; i < MAX_SHIELDS; i++) shieldReady[i] = 0;
        invul = 1.5f;
        state = ST_PLAY;
        setPlayButtons(true);
        chip.play(Songs.TOWER);
    }

    void saveRun() {
        if (state != ST_PLAY && state != ST_PAUSE) return;
        try {
            JSONObject o = new JSONObject();
            o.put("seed", seed); o.put("floor", maxFloor); o.put("lvl", lvl); o.put("xp", xp); o.put("pts", pts);
            o.put("v", pVida); o.put("d", pDano); o.put("s", pSalto); o.put("df", pDef); o.put("r", pRobo);
            o.put("hp", (double) hp); o.put("ammo", ammo); o.put("time", (double) runTime); o.put("lastBoss", lastBossFloor);
            prefs().edit().putString("tower_run", o.toString()).apply();
        } catch (Exception ignored) {}
    }

    boolean loadRun() {
        String s = prefs().getString("tower_run", null);
        if (s == null) return false;
        try {
            JSONObject o = new JSONObject(s);
            seed = o.getLong("seed");
            lvl = o.getInt("lvl"); xp = o.getInt("xp"); pts = o.getInt("pts");
            pVida = o.getInt("v"); pDano = o.getInt("d"); pSalto = o.getInt("s"); pDef = o.getInt("df"); pRobo = o.getInt("r");
            hp = (float) o.getDouble("hp"); ammo = o.getInt("ammo"); runTime = (float) o.getDouble("time");
            lastBossFloor = o.getInt("lastBoss");
            startAtFloor(o.getInt("floor"));
            return true;
        } catch (Exception e) {
            clearSave();
            return false;
        }
    }

    int savedFloor() {
        String s = prefs().getString("tower_run", null);
        if (s == null) return 0;
        try { return new JSONObject(s).getInt("floor"); } catch (Exception e) { return 0; }
    }

    void clearSave() { prefs().edit().remove("tower_run").apply(); }

    @Override
    void onPauseGame() {
        if (state == ST_PLAY) { saveRun(); state = ST_PAUSE; }
        else if (state == ST_PAUSE) saveRun();
    }

    @Override
    void onResumeGame() {
        if (state == ST_MENU) chip.play(Songs.TOWER);
        else if (state == ST_END) chip.play(Songs.ENDING);
        else chip.play(currentSong());
    }

    @Override
    public boolean onBack() {
        if (state == ST_PLAY) { state = ST_PAUSE; saveRun(); return true; }
        if (state == ST_PAUSE) { state = ST_PLAY; return true; }
        return false;
    }

    // =====================================================================
    // Estadísticas
    // =====================================================================
    float maxHp() { return Math.min(MAX_HP, START_HP + HP_PER_PT * pVida); }
    float dmg() { return (BASE_DMG + DMG_PER_PT * pDano) * (powerT > 0 ? 2 : 1); }
    float jumpV() { return JUMP_V * (float) Math.sqrt(1 + JUMP_PER_PT * pSalto * 2); }
    int shields() { return Math.min(MAX_SHIELDS, pDef / DEF_PTS_PER_SHIELD); }
    float robo() { return ROBO_BASE + ROBO_PER_PT * pRobo; }

    static float baseY(int f) { return -(f - 1) * FLOOR_H; }

    int floorAt(float y) { return 1 + (int) Math.floor(-y / FLOOR_H + 0.001f); }

    // =====================================================================
    // Generación de pisos (cada partida es distinta)
    // =====================================================================
    void genFloor(int f) {
        if (f > FINAL_FLOOR) return;
        Random r = new Random(seed * 1000003L + f * 7919L);
        float base = baseY(f);

        if (f == FINAL_FLOOR) {
            Plat g = plat(P_GROUND, 0, base, 360, f);
            g.type = P_GROUND;
            return;
        }
        if (f % 15 == 0) { genBossFloor(f, base, r); return; }

        float w = Math.max(48, 80 - f * 0.03f);
        int rowsStart = f == 1 ? 1 : 0;
        if (f == 1) plat(P_GROUND, 0, 0, 360, 1);
        List<Plat> floorPlats = new ArrayList<>();
        for (int k = rowsStart; k < 5; k++) {
            float y = base - k * ROW_GAP;
            boolean afterBoss = (f - 1) % 15 == 0 && f > 1 && k == 0;
            // plataforma del camino (siempre alcanzable)
            float cx = afterBoss ? 180 : wrapX(pathX + (r.nextFloat() * 2 - 1) * 105);   // siempre alcanzable de un salto
            float pw0 = afterBoss ? 130 : w;
            int type = (f > 3 && r.nextFloat() < 0.2f && !afterBoss) ? P_MOVING : P_NORMAL;
            Plat main = plat(type, cx - pw0 / 2, y, pw0, f);
            if (type == P_MOVING) setMoving(main, r);
            floorPlats.add(main);
            pathX = cx;
            // plataformas extra
            int extra = f < 10 ? 1 : (r.nextFloat() < 0.55f ? 1 : 0);
            for (int e = 0; e < extra; e++) {
                float ex = wrapX(cx + 110 + r.nextFloat() * 140);
                float roll = r.nextFloat();
                int t = P_NORMAL;
                if (f > 5 && roll < 0.25f) t = P_BREAK;
                else if (roll < 0.35f) t = P_SPRING;
                else if (f > 8 && roll < 0.5f) t = P_CLOUD;
                Plat p2 = plat(t, ex - w / 2, y - r.nextFloat() * 18, w, f);
                floorPlats.add(p2);
            }
        }

        // cristales
        int crystals = 2 + r.nextInt(2);
        for (int i = 0; i < crystals; i++) {
            Plat p0 = floorPlats.get(r.nextInt(floorPlats.size()));
            item(I_CRYSTAL, p0.x + p0.w / 2, p0.y - 16);
        }
        // mejora temporal
        if (f > 2 && r.nextFloat() < 0.12f) {
            Plat p0 = floorPlats.get(r.nextInt(floorPlats.size()));
            int[] kinds = {I_WINGS, I_SHIELD, I_MAGNET, I_POWER};
            item(kinds[r.nextInt(4)], p0.x + p0.w / 2, p0.y - 18);
        }

        // enemigos
        int count = f == 1 ? 1 : 1 + r.nextInt(2) + (f >= 20 ? 1 : 0) + (f >= 100 ? 1 : 0);
        for (int i = 0; i < count; i++) {
            float roll = r.nextFloat();
            int type = f == 1 ? E_SLUG : (roll < 0.45f ? E_SLUG : (roll < 0.8f || f < 4 ? E_BAT : E_MAGE));
            if (type == E_BAT) {
                Enemy e = enemy(E_BAT, 0, f);
                e.baseX = 40 + r.nextFloat() * 280;
                e.baseY = base - 60 - r.nextFloat() * 180;
                e.x = e.baseX; e.y = e.baseY;
                e.t = r.nextFloat() * 6;
            } else {
                Plat p0 = null;
                for (int tries = 0; tries < 6; tries++) {
                    Plat c0 = floorPlats.get(r.nextInt(floorPlats.size()));
                    if ((c0.type == P_NORMAL || c0.type == P_MOVING) && c0.y < base - 10) { p0 = c0; break; }
                }
                if (p0 == null) continue;
                Enemy e = enemy(type, 0, f);
                e.plat = p0;
                e.x = p0.x + r.nextFloat() * Math.max(1, p0.w - e.w);
                e.y = p0.y - e.h;
                e.vx = type == E_SLUG ? 30 + Math.min(40, f * 0.2f) : 0;
            }
        }
    }

    void genBossFloor(int f, float base, Random r) {
        plat(P_GROUND, 0, base, 360, f);
        plat(P_NORMAL, 30, base - 75, 80, f);
        plat(P_NORMAL, 250, base - 75, 80, f);
        plat(P_NORMAL, 140, base - 150, 80, f);
        plat(P_NORMAL, 30, base - 225, 80, f);
        plat(P_NORMAL, 250, base - 225, 80, f);
        if (lastBossFloor >= f) return;           // ya derrotado en esta partida
        Plat gate = plat(P_GATE, 0, base - 268, 360, f);
        gate.h = 12;
        int tier = f % 60 == 0 ? 3 : (f % 30 == 0 ? 2 : 1);
        int type = tier == 3 ? G_GOLEM + ((f / 60 - 1) % 4) : B_SLUG + ((f / 15 - 1) % 3);
        Enemy b = enemy(type, tier, f);
        b.x = 180 - b.w / 2;
        b.y = base - b.h;
        b.baseY = base;
        if (type == B_BAT || type == G_DRAGON || type == G_EYE) b.y = base - 200;
        b.cd = 2f;
    }

    float wrapX(float x) {
        while (x < 40) x += 280;
        while (x > 320) x -= 280;
        return x;
    }

    Plat plat(int type, float x, float y, float w, int f) {
        Plat p0 = new Plat();
        p0.type = type; p0.x = x; p0.y = y; p0.w = w; p0.floor = f;
        plats.add(p0);
        return p0;
    }

    void setMoving(Plat p0, Random r) {
        p0.vx = (40 + r.nextFloat() * 40) * (r.nextBoolean() ? 1 : -1);
        p0.minX = Math.max(0, p0.x - 70);
        p0.maxX = Math.min(360 - p0.w, p0.x + 70);
    }

    Item item(int type, float x, float y) {
        Item i = new Item();
        i.type = type; i.x = x; i.y = y; i.t = rnd.nextFloat() * 6;
        items.add(i);
        return i;
    }

    Enemy enemy(int type, int tier, int f) {
        Enemy e = new Enemy();
        e.type = type; e.tier = tier; e.floor = f;
        float hpBase = ENEMY_HP * hpScale(f), dmgBase = ENEMY_DMG * dmgScale(f);
        switch (type) {
            case E_SLUG: e.w = 22; e.h = 14; e.hp = hpBase; e.dmg = dmgBase; e.xp = 1 + rnd.nextInt(2); e.name = "Babosa"; break;
            case E_BAT: e.w = 22; e.h = 14; e.hp = hpBase * 0.7f; e.dmg = dmgBase; e.xp = 2 + rnd.nextInt(2); e.name = "Murciélago"; break;
            case E_MAGE: e.w = 18; e.h = 24; e.hp = hpBase * 0.85f; e.dmg = dmgBase * 1.2f; e.xp = 3 + rnd.nextInt(3); e.name = "Mago"; e.cd = 1.5f; break;
            default: {
                boolean guard = tier == 3;
                float mult = guard ? GUARD_HP_MULT : (tier == 2 ? STRONG_HP_MULT : BOSS_HP_MULT);
                e.hp = hpBase * mult;
                e.dmg = dmgBase * (guard ? GUARD_DMG_MULT : BOSS_DMG_MULT);
                e.xp = guard ? GUARD_XP : (tier == 2 ? STRONG_XP : BOSS_XP);
                e.w = guard ? 64 : 44; e.h = guard ? 56 : 34;
                String[] names = {"Babosa Reina", "Murciélago Mayor", "Gran Mago"};
                String[] gnames = {"GÓLEM DE PIEDRA", "DRAGÓN CARMESÍ", "CABALLERO OSCURO", "OJO ARCANO"};
                e.name = guard ? gnames[type - G_GOLEM] : (tier == 2 ? "⚡ " : "") + names[type - B_SLUG];
                if (type == B_MAGE) { e.w = 30; e.h = 40; }
                if (type == G_KNIGHT) { e.w = 40; e.h = 52; }
            }
        }
        e.maxHp = e.hp;
        enemies.add(e);
        return e;
    }

    Chip.Song currentSong() {
        for (Enemy e : enemies) if (e.tier > 0 && !e.dead && Math.abs(e.floor - maxFloor) <= 1)
            return e.tier == 3 ? Songs.GUARDIAN : Songs.BOSS;
        return Songs.TOWER;
    }

    // =====================================================================
    // Actualización
    // =====================================================================
    @Override
    void update(float dt) {
        if (state == ST_PLAY) play(dt);
        else if (state == ST_END) ending(dt);
        for (Iterator<Fx> it = fx.iterator(); it.hasNext(); ) {
            Fx f = it.next();
            f.t += dt; f.y += f.vy * dt;
            if (f.t > f.life) it.remove();
        }
    }

    void play(float dt) {
        runTime += dt;
        if (bPause.pressed()) { state = ST_PAUSE; saveRun(); return; }

        // --- movimiento ---
        float move = 0;
        if (bLeft.down) move -= 1;
        if (bRight.down) move += 1;
        if (move != 0) facingRight = move > 0;
        pvx = move * MOVE_V;
        walkAnim += Math.abs(move) * dt * 10;

        if (wingsT > 0) {
            wingsT -= dt;
            pvy = -300;
        } else {
            pvy += GRAVITY * dt;
            if (pvy > 900) pvy = 900;
        }
        coyote -= dt;
        if (onGround) coyote = 0.1f;
        if (bJump.pressed() && coyote > 0) {
            pvy = -jumpV();
            coyote = 0;
            onGround = false;
            chip.sfx(Chip.SFX_JUMP);
        }
        if (!bJump.down && pvy < -200 && wingsT <= 0) pvy += GRAVITY * dt * 1.2f;   // salto corto si sueltas

        float prevBottom = py + ph, prevTop = py;
        if (onGround && groundPlat != null && groundPlat.type == P_MOVING) px += groundPlat.vx * dt;
        px += pvx * dt;
        py += pvy * dt;
        if (px + pw / 2 < 0) px += 360;
        if (px + pw / 2 > 360) px -= 360;

        // --- plataformas ---
        onGround = false;
        groundPlat = null;
        for (Plat pl : plats) {
            if (pl.dead) continue;
            if (pl.type == P_MOVING) {
                pl.x += pl.vx * dt;
                if (pl.x < pl.minX) { pl.x = pl.minX; pl.vx = Math.abs(pl.vx); }
                if (pl.x > pl.maxX) { pl.x = pl.maxX; pl.vx = -Math.abs(pl.vx); }
            }
            if (pl.timer >= 0) {
                pl.timer -= dt;
                if (pl.timer < 0) { pl.dead = true; continue; }
            }
            boolean overlapX = px + pw > pl.x && px < pl.x + pl.w;
            if (!overlapX) continue;
            if (pvy >= 0 && prevBottom <= pl.y + 2 && py + ph >= pl.y) {
                py = pl.y - ph;
                pvy = 0;
                onGround = true;
                groundPlat = pl;
                if (pl.type == P_BREAK && pl.timer < 0) pl.timer = 0.35f;
                if (pl.type == P_CLOUD && pl.timer < 0) pl.timer = 1.1f;
                if (pl.type == P_SPRING) {
                    pvy = -jumpV() * 1.65f;
                    onGround = false;
                    chip.sfx(Chip.SFX_SPRING);
                }
            } else if (pl.type == P_GATE && pvy < 0 && prevTop >= pl.y + pl.h - 2 && py <= pl.y + pl.h) {
                py = pl.y + pl.h;
                pvy = 0;
            }
        }

        // --- cámara y pisos ---
        float target = py - vh * 0.42f;
        if (target < camY) camY += (target - camY) * Math.min(1, dt * 6);
        int f = floorAt(py + ph - 1);
        if (f > maxFloor) {
            maxFloor = f;
            int stage = (maxFloor - 1) / 30;
            chip.intensity = Math.min(2, stage);
            if (maxFloor % 30 == 1 && maxFloor > 1) float_("ETAPA " + (stage + 1) + " · ENEMIGOS MÁS FUERTES", 180, py - 40, Color.rgb(255, 120, 80));
        }
        while (genTop < floorAt(camY) + 2) genFloor(++genTop);
        if (maxFloor >= FINAL_FLOOR) { startEnding(); return; }

        // --- buffs ---
        if (magnetT > 0) magnetT -= dt;
        if (powerT > 0) powerT -= dt;
        if (invul > 0) invul -= dt;

        // --- ataques ---
        swingCd -= dt; shotCd -= dt;
        if (swingT > 0) swingT -= dt;
        if (bSword.pressed() && swingCd <= 0) {
            swingT = 0.2f; swingCd = 0.32f; swingCounter++;
            chip.sfx(Chip.SFX_SWORD);
        }
        if (bGun.pressed() && shotCd <= 0) {
            if (ammo > 0) {
                ammo--;
                shotCd = 0.25f;
                Shot s = new Shot();
                s.mine = true; s.kind = S_PLAYER; s.r = 4;
                s.x = px + pw / 2; s.y = py + 9;
                s.vx = facingRight ? 420 : -420; s.life = 0.9f;
                s.dmg = dmg() * PISTOL_MULT;
                shots.add(s);
                chip.sfx(Chip.SFX_SHOOT);
            } else float_("SIN BALAS", px + 8, py - 10, Color.GRAY);
        }
        float hx = facingRight ? px + pw : px - 30, hy = py - 6;

        // --- enemigos ---
        for (int ei = 0; ei < enemies.size(); ei++) {   // por índice: los jefes pueden invocar enemigos
            Enemy e = enemies.get(ei);
            if (e.dead) continue;
            updateEnemy(e, dt);
            if (e.flash > 0) e.flash -= dt;
            if (swingT > 0.12f && e.swingId != swingCounter && GameKit.overlap(hx, hy, 30, ph + 10, e.x, e.y, e.w, e.h)) {
                e.swingId = swingCounter;
                hitEnemy(e, dmg());
            }
            if (!e.dead && GameKit.overlap(px + 2, py + 2, pw - 4, ph - 2, e.x + 3, e.y + 3, e.w - 6, e.h - 6))
                hurt(e.dmg);
        }
        chip.play(currentSong());

        // --- disparos ---
        for (int si = 0; si < shots.size(); si++) {
            Shot s = shots.get(si);
            if (s.dead) continue;
            s.life -= dt;
            if (s.kind == S_ROCK) s.vy += 600 * dt;
            s.x += s.vx * dt;
            s.y += s.vy * dt;
            if (s.life <= 0) { s.dead = true; continue; }
            if (s.mine) {
                for (Enemy e : enemies) {
                    if (e.dead) continue;
                    if (s.x > e.x && s.x < e.x + e.w && s.y > e.y && s.y < e.y + e.h) {
                        hitEnemy(e, s.dmg);
                        s.dead = true;
                        break;
                    }
                }
            } else {
                float r0 = s.r;
                if (s.kind == S_WAVE) {
                    if (GameKit.overlap(px, py, pw, ph, s.x - 8, s.y - 16, 16, 16)) { hurt(s.dmg); s.dead = true; }
                } else if (GameKit.overlap(px + 2, py + 2, pw - 4, ph - 4, s.x - r0, s.y - r0, r0 * 2, r0 * 2)) {
                    hurt(s.dmg);
                    s.dead = true;
                }
            }
        }

        // --- objetos ---
        for (Item it : items) {
            if (it.dead) continue;
            it.t += dt;
            if (magnetT > 0 && it.type == I_CRYSTAL) {
                float dx = px + pw / 2 - it.x, dy = py + ph / 2 - it.y;
                float d = (float) Math.hypot(dx, dy);
                if (d < 160 && d > 1) { it.x += dx / d * 260 * dt; it.y += dy / d * 260 * dt; }
            }
            if (GameKit.overlap(px, py, pw, ph, it.x - 8, it.y - 8, 16, 16)) pick(it);
        }

        // --- muerte por caída ---
        if (py > camY + vh + 10) { die("Caíste de la torre"); return; }

        // --- limpieza ---
        float cut = camY + vh + 300;
        removeBelow(cut);
    }

    void removeBelow(float cut) {
        for (Iterator<Plat> it = plats.iterator(); it.hasNext(); ) { Plat p0 = it.next(); if (p0.dead || p0.y > cut) it.remove(); }
        for (Iterator<Enemy> it = enemies.iterator(); it.hasNext(); ) { Enemy e = it.next(); if (e.dead || e.y > cut) it.remove(); }
        for (Iterator<Shot> it = shots.iterator(); it.hasNext(); ) { Shot s = it.next(); if (s.dead || s.y > cut) it.remove(); }
        for (Iterator<Item> it = items.iterator(); it.hasNext(); ) { Item i = it.next(); if (i.dead || i.y > cut) it.remove(); }
    }

    // ---------------- enemigos ----------------
    void updateEnemy(Enemy e, float dt) {
        e.t += dt;
        float cx = px + pw / 2, cy = py + ph / 2;
        float ex = e.x + e.w / 2, ey = e.y + e.h / 2;
        switch (e.type) {
            case E_SLUG: {
                if (e.plat == null || e.plat.dead) { e.vy += GRAVITY * dt; e.y += e.vy * dt; break; }
                if (e.plat.type == P_MOVING) e.x += e.plat.vx * dt;
                e.x += e.vx * dt;
                if (e.x < e.plat.x) { e.x = e.plat.x; e.vx = Math.abs(e.vx); }
                if (e.x + e.w > e.plat.x + e.plat.w) { e.x = e.plat.x + e.plat.w - e.w; e.vx = -Math.abs(e.vx); }
                e.y = e.plat.y - e.h;
                break;
            }
            case E_BAT: {
                float near = Math.abs(cy - e.baseY) < 200 ? 1 : 0;
                e.baseX += Math.signum(cx - e.baseX) * 20 * near * dt;
                e.x = e.baseX + (float) Math.sin(e.t * 1.6f) * 60 - e.w / 2;
                e.y = e.baseY + (float) Math.sin(e.t * 2.4f) * 22;
                break;
            }
            case E_MAGE: {
                if (e.plat != null && !e.plat.dead) {
                    if (e.plat.type == P_MOVING) e.x += e.plat.vx * dt;
                    e.y = e.plat.y - e.h;
                }
                e.cd -= dt;
                if (e.cd <= 0 && Math.abs(cy - ey) < 260) {
                    e.cd = 2.2f;
                    aim(e, 130, 0, S_ORB, e.dmg);
                }
                break;
            }
            case B_SLUG: {
                if (e.state == 1) {             // saltando (jefe fuerte)
                    e.vy += GRAVITY * dt;
                    e.y += e.vy * dt;
                    if (e.y + e.h >= e.baseY) { e.y = e.baseY - e.h; e.state = 0; waves(e); chip.sfx(Chip.SFX_BOOM); }
                } else {
                    e.x += Math.signum(cx - ex) * (40 + e.tier * 15) * dt;
                    e.y = e.baseY - e.h;
                }
                e.cd -= dt;
                if (e.cd <= 0) {
                    e.cd = 4.5f;
                    for (int i = 0; i < 2; i++) {
                        Enemy m = enemy(E_SLUG, 0, e.floor);
                        m.hp *= 0.6f; m.maxHp = m.hp;
                        m.x = e.x + (i == 0 ? -20 : e.w); m.y = e.baseY - m.h;
                        Plat ground = groundOf(e.floor);
                        m.plat = ground; m.vx = i == 0 ? -50 : 50;
                    }
                }
                if (e.tier >= 2) {
                    e.cd2 -= dt;
                    if (e.cd2 <= 0 && e.state == 0) { e.cd2 = 6; e.state = 1; e.vy = -520; }
                }
                break;
            }
            case B_BAT: {
                if (e.state == 0) {
                    e.x = 180 + (float) Math.sin(e.t * 0.9f) * 120 - e.w / 2;
                    e.y = e.baseY - 200 + (float) Math.sin(e.t * 2f) * 20;
                    e.cd -= dt;
                    if (e.cd <= 0) {
                        e.state = 1; e.cd2 = 0.8f;
                        float d = (float) Math.max(1, Math.hypot(cx - ex, cy - ey));
                        e.vx = (cx - ex) / d * 340; e.vy = (cy - ey) / d * 340;
                    }
                } else if (e.state == 1) {
                    e.x += e.vx * dt; e.y += e.vy * dt;
                    e.cd2 -= dt;
                    if (e.cd2 <= 0 || e.y + e.h > e.baseY) {
                        e.state = 2; e.cd2 = 1.0f;
                        if (e.tier >= 2) for (int i = -1; i <= 1; i++) aim(e, 150, i * 0.3f, S_ORB, e.dmg * 0.6f);
                    }
                } else {
                    float tx = 180 + (float) Math.sin(e.t * 0.9f) * 120 - e.w / 2, ty = e.baseY - 200;
                    e.x += (tx - e.x) * Math.min(1, dt * 3); e.y += (ty - e.y) * Math.min(1, dt * 3);
                    e.cd2 -= dt;
                    if (e.cd2 <= 0) { e.state = 0; e.cd = 2.6f - e.tier * 0.3f; }
                }
                break;
            }
            case B_MAGE: {
                e.cd -= dt;
                if (e.cd <= 0) {
                    e.cd = 3f - (e.tier - 1) * 0.6f;
                    float[][] spots = {{50, -75}, {270, -75}, {160, -150}, {50, -225}, {270, -225}, {160, 0}};
                    float[] s0 = spots[rnd.nextInt(spots.length)];
                    e.x = s0[0] + 20 - e.w / 2; e.y = e.baseY + s0[1] - e.h;
                    int n = e.tier >= 2 ? 5 : 3;
                    for (int i = 0; i < n; i++) aim(e, 140, (i - (n - 1) / 2f) * 0.22f, S_ORB, e.dmg * 0.7f);
                    float_("✦", ex, e.y, Color.rgb(200, 120, 255));
                }
                break;
            }
            case G_GOLEM: {
                e.x += Math.signum(cx - ex) * 32 * dt;
                e.y = e.baseY - e.h;
                e.cd -= dt;
                if (e.cd <= 0) { e.cd = 3.5f; waves(e); chip.sfx(Chip.SFX_BOOM); }
                e.cd2 -= dt;
                if (e.cd2 <= 0) {
                    e.cd2 = 1.6f;
                    Shot s = new Shot();
                    s.kind = S_ROCK; s.r = 9; s.dmg = e.dmg * 0.6f; s.life = 4;
                    s.x = 20 + rnd.nextFloat() * 320; s.y = e.baseY - 290; s.vy = 40;
                    shots.add(s);
                }
                break;
            }
            case G_DRAGON: {
                if (e.state == 0) {
                    e.x = 180 + (float) Math.sin(e.t * 0.7f) * 130 - e.w / 2;
                    e.y = e.baseY - 235 + (float) Math.sin(e.t * 1.7f) * 12;
                    e.cd -= dt;
                    if (e.cd <= 0) {
                        e.cd = 2.4f;
                        for (int i = 0; i < 5; i++) aim(e, 160, (i - 2) * 0.18f, S_FIRE, e.dmg * 0.5f);
                    }
                    e.cd2 -= dt;
                    if (e.cd2 <= 0) {
                        e.cd2 = 7; e.state = 1;
                        e.dir = cx > ex ? 1 : -1;
                        e.x = e.dir > 0 ? -e.w : 360;
                        e.y = e.baseY - e.h - 4;
                        float_("¡CUIDADO!", 180, e.baseY - 120, Color.rgb(255, 80, 60));
                    }
                } else {
                    e.x += e.dir * 300 * dt;
                    if (e.x > 380 || e.x < -e.w - 20) e.state = 0;
                }
                break;
            }
            case G_KNIGHT: {
                e.y = e.baseY - e.h;
                if (e.state == 1) {
                    e.x += e.dir * 360 * dt;
                    e.cd2 -= dt;
                    if (e.cd2 <= 0 || e.x < 0 || e.x + e.w > 360) e.state = 0;
                    e.x = GameKit.clamp(e.x, 0, 360 - e.w);
                } else {
                    e.x += Math.signum(cx - ex) * 45 * dt;
                    e.cd -= dt;
                    if (e.cd <= 0) {
                        e.cd = 2.2f;
                        if (rnd.nextBoolean()) {
                            e.state = 1; e.cd2 = 0.5f; e.dir = cx > ex ? 1 : -1;
                        } else {
                            Shot s = new Shot();
                            s.kind = S_SLASH; s.r = 10; s.dmg = e.dmg * 0.7f; s.life = 2.5f;
                            s.x = ex; s.y = Math.min(cy, e.baseY - 14);
                            s.vx = cx > ex ? 230 : -230;
                            shots.add(s);
                            chip.sfx(Chip.SFX_SWORD);
                        }
                    }
                }
                break;
            }
            case G_EYE: {
                e.x = 180 + (float) Math.sin(e.t * 0.5f) * 60 - e.w / 2;
                e.y = e.baseY - 170 - e.h / 2;
                // anillo de orbes (daño por contacto)
                for (int i = 0; i < 6; i++) {
                    double a = e.t * 1.6 + i * Math.PI / 3;
                    float ox = ex + (float) Math.cos(a) * 75, oy = ey + (float) Math.sin(a) * 75;
                    if (GameKit.overlap(px + 2, py + 2, pw - 4, ph - 4, ox - 7, oy - 7, 14, 14)) hurt(e.dmg * 0.5f);
                }
                if (e.laserT >= 0) {
                    e.laserT += dt;
                    if (e.laserT > 1.0f && e.laserT < 1.5f) {
                        boolean hit = e.laserMode == 0 ? Math.abs(cx - e.laserPos) < 16 : Math.abs(cy - e.laserPos) < 16;
                        if (hit) hurt(e.dmg);
                    }
                    if (e.laserT > 1.5f) { e.laserT = -1; e.cd = 3.5f; }
                } else {
                    e.cd -= dt;
                    if (e.cd <= 0) {
                        e.laserT = 0;
                        e.laserMode = rnd.nextInt(2);
                        e.laserPos = e.laserMode == 0 ? cx : cy;
                    }
                }
                break;
            }
        }
    }

    Plat groundOf(int f) {
        for (Plat p0 : plats) if (p0.type == P_GROUND && p0.floor == f) return p0;
        return null;
    }

    void waves(Enemy e) {
        for (int d = -1; d <= 1; d += 2) {
            Shot s = new Shot();
            s.kind = S_WAVE; s.dmg = e.dmg * 0.6f; s.life = 2.5f;
            s.x = e.x + e.w / 2; s.y = e.baseY; s.vx = d * 200;
            shots.add(s);
        }
    }

    void aim(Enemy e, float speed, float angleOffset, int kind, float dmg) {
        float ex = e.x + e.w / 2, ey = e.y + e.h / 2;
        double a = Math.atan2(py + ph / 2 - ey, px + pw / 2 - ex) + angleOffset;
        Shot s = new Shot();
        s.kind = kind; s.r = kind == S_FIRE ? 7 : 6; s.dmg = dmg; s.life = 5;
        s.x = ex; s.y = ey;
        s.vx = (float) Math.cos(a) * speed; s.vy = (float) Math.sin(a) * speed;
        shots.add(s);
    }

    void hitEnemy(Enemy e, float d) {
        e.hp -= d;
        e.flash = 0.12f;
        chip.sfx(Chip.SFX_HIT);
        float_(String.valueOf(Math.round(d)), e.x + e.w / 2, e.y - 4, Color.WHITE);
        float heal = d * robo() / 100f;
        if (heal > 0) hp = Math.min(maxHp(), hp + heal);
        if (e.tier == 0) e.x += (facingRight ? 6 : -6);
        if (e.hp <= 0) kill(e);
    }

    void kill(Enemy e) {
        e.dead = true;
        kills++;
        gainXp(e.xp);
        if (e.tier > 0) {
            chip.sfx(Chip.SFX_BOOM);
            lastBossFloor = Math.max(lastBossFloor, e.floor);
            for (Plat p0 : plats) if (p0.type == P_GATE && p0.floor == e.floor) p0.dead = true;
            hp = maxHp();
            Item chest = item(I_CHEST, e.x + e.w / 2, e.baseY - 16);
            chest.t = 0;
            float_("¡" + e.name + " DERROTADO!", 180, e.baseY - 140, Color.rgb(255, 220, 60));
            float_("Vida restaurada · el camino se abre", 180, e.baseY - 115, Color.WHITE);
            for (Shot s : shots) if (!s.mine) s.dead = true;
            saveRun();
        } else if (rnd.nextFloat() < 0.05f) {
            item(I_HEART, e.x + e.w / 2, e.y);
        }
    }

    void gainXp(int amount) {
        xp += amount;
        float_("+" + amount + " XP", px + pw / 2, py - 14, Color.rgb(120, 255, 160));
        while (xp >= xpNeed(lvl)) {
            xp -= xpNeed(lvl);
            lvl++;
            pts += PTS_PER_LEVEL;
            chip.sfx(Chip.SFX_LEVEL);
            float_("¡NIVEL " + lvl + "! +" + PTS_PER_LEVEL + " puntos (⏸)", 180, py - 50, Color.rgb(255, 230, 80));
        }
    }

    void pick(Item it) {
        it.dead = true;
        switch (it.type) {
            case I_CRYSTAL:
                ammo = Math.min(AMMO_MAX, ammo + AMMO_PER_CRYSTAL);
                chip.sfx(Chip.SFX_COIN);
                break;
            case I_HEART:
                hp = Math.min(maxHp(), hp + maxHp() * 0.2f);
                float_("+VIDA", it.x, it.y, Color.rgb(255, 90, 120));
                chip.sfx(Chip.SFX_POWER);
                break;
            case I_WINGS: wingsT = 5; float_("🪽 ¡ALITAS!", it.x, it.y, Color.WHITE); chip.sfx(Chip.SFX_POWER); break;
            case I_SHIELD: tempShield = true; float_("🛡 ESCUDO", it.x, it.y, Color.rgb(120, 200, 255)); chip.sfx(Chip.SFX_POWER); break;
            case I_MAGNET: magnetT = 10; float_("🧲 IMÁN", it.x, it.y, Color.WHITE); chip.sfx(Chip.SFX_POWER); break;
            case I_POWER: powerT = 10; float_("⚡ DOBLE DAÑO", it.x, it.y, Color.rgb(255, 230, 80)); chip.sfx(Chip.SFX_POWER); break;
            case I_CHEST:
                pts += BOSS_CHEST_PTS;
                float_("🎁 +" + BOSS_CHEST_PTS + " PUNTOS", it.x, it.y - 10, Color.rgb(255, 220, 60));
                chip.sfx(Chip.SFX_LEVEL);
                break;
        }
    }

    void hurt(float d) {
        if (invul > 0 || wingsT > 0) return;
        invul = 0.9f;
        if (tempShield) { tempShield = false; float_("¡BLOQUEADO!", px + 8, py - 8, Color.rgb(120, 200, 255)); chip.sfx(Chip.SFX_HIT); return; }
        int n = shields();
        for (int i = 0; i < n; i++) {
            if (runTime >= shieldReady[i]) {
                shieldReady[i] = runTime + SHIELD_RECHARGE;
                float_("🛡 BLOQUEADO", px + 8, py - 8, Color.rgb(120, 200, 255));
                chip.sfx(Chip.SFX_HIT);
                return;
            }
        }
        hp -= d;
        chip.sfx(Chip.SFX_HURT);
        float_("-" + Math.round(d), px + 8, py - 8, Color.rgb(255, 80, 80));
        if (hp <= 0) die("Derrotado en el piso " + maxFloor);
    }

    String deathMsg = "";

    void die(String msg) {
        state = ST_DEAD;
        deathMsg = msg;
        setPlayButtons(false);
        clearSave();
        int best = prefs().getInt("best_tower", 0);
        if (maxFloor > best) prefs().edit().putInt("best_tower", maxFloor).apply();
        chip.sfx(Chip.SFX_HURT);
        chip.silence();
    }

    void float_(String s, float x, float y, int color) {
        Fx f = new Fx();
        f.s = s; f.x = x; f.y = y; f.color = color;
        if (s.length() > 12) { f.life = 2.2f; f.vy = -15; }
        fx.add(f);
    }

    // =====================================================================
    // Final del piso 1000
    // =====================================================================
    void startEnding() {
        state = ST_END;
        endT = 0;
        setPlayButtons(false);
        clearSave();
        enemies.clear(); shots.clear(); items.clear();
        knightX = 40;
        princessX = 300;
        SharedPreferences.Editor ed = prefs().edit();
        ed.putBoolean("tower_won", true);
        ed.putInt("best_tower", FINAL_FLOOR);
        if (prefs().getFloat("tower_best_time", 0) == 0 || runTime < prefs().getFloat("tower_best_time", 0))
            ed.putFloat("tower_best_time", runTime);
        ed.apply();
        chip.play(Songs.ENDING);
    }

    void ending(float dt) {
        endT += dt;
        if (endT < 2.5f) knightX = Math.min(170, knightX + 60 * dt);
        if (endT > 4.5f && endT < 6.5f) princessX = Math.max(196, princessX - 55 * dt);
        if (endT > 7.5f && endT < 10.5f) {
            knightX += 40 * dt;
            princessX += 40 * dt;
        }
    }

    // =====================================================================
    // Dibujo
    // =====================================================================
    @Override
    void render(Canvas c) {
        int neon = Neon.color(getContext());
        drawBackground(c);
        if (state == ST_MENU) { drawMenu(c, neon); return; }
        if (state == ST_END) { drawEnding(c, neon); return; }

        c.save();
        c.translate(0, -camY);
        for (Plat pl : plats) drawPlat(c, pl);
        for (Item it : items) drawItem(c, it);
        for (Enemy e : enemies) drawEnemy(c, e);
        for (Shot s : shots) drawShot(c, s);
        drawPlayer(c);
        for (Fx f : fx) {
            int a = (int) (255 * Math.max(0, 1 - f.t / f.life));
            text(c, f.s, f.x, f.y, f.s.length() > 12 ? 12 : 13, Neon.withAlpha(f.color, a));
        }
        c.restore();

        drawHud(c, neon);
        pad.draw(c, neon);
        if (state == ST_PAUSE) drawPause(c, neon);
        if (state == ST_DEAD) drawDead(c, neon);
    }

    void drawBackground(Canvas c) {
        int stage = (maxFloor - 1) / 30;
        float[] hsv = {(230 + stage * 37) % 360, 0.6f, 0.22f};
        int top = Color.HSVToColor(hsv);
        hsv[2] = 0.07f;
        int bot = Color.HSVToColor(hsv);
        p.setShader(new LinearGradient(0, 0, 0, vh, top, bot, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, vw, vh, p);
        p.setShader(null);
        // ladrillos de la torre (paralaje)
        p.setColor(Color.argb(28, 255, 255, 255));
        float off = (-camY * 0.5f) % 40;
        for (float y = -40 + off; y < vh; y += 40) {
            c.drawRect(0, y, vw, y + 1.5f, p);
            float shift = (((int) Math.floor((y - off) / 40)) & 1) == 0 ? 0 : 30;
            for (float x = shift; x < vw; x += 60) c.drawRect(x, y, x + 1.5f, y + 40, p);
        }
        // estrellas
        p.setColor(Color.argb(90, 255, 255, 255));
        for (int i = 0; i < 30; i++) {
            float sx = (i * 97) % 360, sy = ((i * 61) - camY * 0.2f) % vh;
            if (sy < 0) sy += vh;
            c.drawRect(sx, sy, sx + 1.5f, sy + 1.5f, p);
        }
    }

    void drawPlat(Canvas c, Plat pl) {
        if (pl.dead) return;
        int body, top;
        switch (pl.type) {
            case P_MOVING: body = Color.rgb(30, 140, 170); top = Color.rgb(90, 230, 255); break;
            case P_BREAK: body = Color.rgb(110, 70, 40); top = Color.rgb(170, 120, 70); break;
            case P_SPRING: body = Color.rgb(70, 80, 100); top = Color.rgb(255, 220, 60); break;
            case P_CLOUD: body = Color.argb(150, 230, 240, 255); top = Color.argb(220, 255, 255, 255); break;
            case P_GROUND: body = Color.rgb(60, 60, 80); top = Color.rgb(130, 130, 160); break;
            case P_GATE: body = Color.rgb(140, 20, 40); top = Color.rgb(255, 60, 90); break;
            default: body = Color.rgb(80, 86, 110); top = Color.rgb(160, 170, 200);
        }
        if (pl.timer >= 0 && ((int) (pl.timer * 20)) % 2 == 0) body = Color.rgb(200, 200, 200);
        p.setColor(body);
        c.drawRect(pl.x, pl.y, pl.x + pl.w, pl.y + pl.h, p);
        p.setColor(top);
        c.drawRect(pl.x, pl.y, pl.x + pl.w, pl.y + 3, p);
        if (pl.type == P_BREAK) {
            p.setColor(Color.rgb(60, 35, 20));
            for (float x = pl.x + 10; x < pl.x + pl.w; x += 16) c.drawRect(x, pl.y + 3, x + 2, pl.y + pl.h, p);
        }
        if (pl.type == P_SPRING) {
            p.setColor(Color.rgb(255, 220, 60));
            float cx0 = pl.x + pl.w / 2;
            c.drawRect(cx0 - 8, pl.y - 6, cx0 + 8, pl.y - 3, p);
            p.setColor(Color.rgb(200, 200, 210));
            c.drawRect(cx0 - 5, pl.y - 3, cx0 + 5, pl.y, p);
        }
        if (pl.type == P_GATE) {
            p.setColor(Color.rgb(255, 60, 90));
            for (float x = 6; x < 360; x += 18) c.drawRect(x, pl.y - 10, x + 4, pl.y + pl.h, p);
            text(c, "🔒 DERROTA AL JEFE", 180, pl.y - 14, 11, Color.rgb(255, 120, 140));
        }
    }

    void drawItem(Canvas c, Item it) {
        if (it.dead) return;
        float bob = (float) Math.sin(it.t * 4) * 3;
        float x = it.x, y = it.y + bob;
        switch (it.type) {
            case I_CRYSTAL:
                p.setColor(Color.rgb(120, 230, 255));
                c.drawRect(x - 3, y - 6, x + 3, y + 6, p);
                c.drawRect(x - 6, y - 2, x + 6, y + 2, p);
                p.setColor(Color.WHITE);
                c.drawRect(x - 1, y - 4, x + 1, y - 1, p);
                break;
            case I_HEART: text(c, "❤", x, y + 6, 16, Color.rgb(255, 80, 110)); break;
            case I_WINGS: text(c, "🪽", x, y + 6, 18, Color.WHITE); break;
            case I_SHIELD: text(c, "🛡", x, y + 6, 18, Color.WHITE); break;
            case I_MAGNET: text(c, "🧲", x, y + 6, 18, Color.WHITE); break;
            case I_POWER: text(c, "⚡", x, y + 6, 18, Color.WHITE); break;
            case I_CHEST: text(c, "🎁", x, y + 8, 22, Color.WHITE); break;
        }
    }

    void drawEnemy(Canvas c, Enemy e) {
        if (e.dead) return;
        Bitmap b;
        switch (e.type) {
            case E_SLUG: case B_SLUG: b = sSlug; break;
            case E_BAT: case B_BAT: b = ((int) (e.t * 8)) % 2 == 0 ? sBat : sBat2; break;
            case E_MAGE: case B_MAGE: b = sMage; break;
            case G_GOLEM: b = sGolem; break;
            case G_DRAGON: b = sDragon; break;
            case G_KNIGHT: b = sDKnight; break;
            default: b = sEye;
        }
        Paint tint = null;
        if (e.flash > 0) {
            tint = new Paint();
            tint.setColorFilter(new android.graphics.PorterDuffColorFilter(Color.WHITE, android.graphics.PorterDuff.Mode.SRC_ATOP));
        } else if (e.tier == 2) {
            tint = new Paint();
            tint.setColorFilter(new android.graphics.LightingColorFilter(Color.rgb(255, 170, 170), Color.rgb(60, 0, 0)));
        }
        if (tint != null) GameKit.draw(c, b, e.x, e.y, e.w, e.h, tint);
        else GameKit.draw(c, b, e.x, e.y, e.w, e.h);
        if (e.tier > 0 && e.tier < 3) GameKit.draw(c, sCrown, e.x + e.w / 2 - 8, e.y - 10, 16, 10);

        if (e.type == G_EYE) {
            float ex = e.x + e.w / 2, ey = e.y + e.h / 2;
            p.setColor(Color.rgb(200, 120, 255));
            for (int i = 0; i < 6; i++) {
                double a = e.t * 1.6 + i * Math.PI / 3;
                c.drawCircle(ex + (float) Math.cos(a) * 75, ey + (float) Math.sin(a) * 75, 7, p);
            }
            if (e.laserT >= 0) {
                boolean firing = e.laserT > 1.0f;
                p.setColor(firing ? Color.argb(220, 255, 80, 200) : Color.argb(90, 255, 80, 200));
                float wdt = firing ? 14 : 2;
                if (e.laserMode == 0) c.drawRect(e.laserPos - wdt, e.baseY - 300, e.laserPos + wdt, e.baseY, p);
                else c.drawRect(0, e.laserPos - wdt, 360, e.laserPos + wdt, p);
            }
        }

        // barra de vida
        if (e.hp < e.maxHp || e.tier > 0) {
            float bw = e.tier > 0 ? Math.max(e.w, 80) : e.w;
            float bx = e.x + e.w / 2 - bw / 2, by = e.y - (e.tier > 0 ? 18 : 6);
            p.setColor(Color.argb(160, 0, 0, 0));
            c.drawRect(bx, by, bx + bw, by + 4, p);
            p.setColor(e.tier == 3 ? Color.rgb(255, 80, 200) : Color.rgb(255, 70, 70));
            c.drawRect(bx, by, bx + bw * Math.max(0, e.hp / e.maxHp), by + 4, p);
            if (e.tier > 0) text(c, e.name, e.x + e.w / 2, by - 4, 11, Color.WHITE);
        }
    }

    void drawShot(Canvas c, Shot s) {
        if (s.dead) return;
        switch (s.kind) {
            case S_PLAYER: p.setColor(Color.rgb(255, 240, 120)); c.drawRect(s.x - 5, s.y - 2, s.x + 5, s.y + 2, p); break;
            case S_ORB: p.setColor(Color.rgb(200, 110, 255)); c.drawCircle(s.x, s.y, s.r, p); p.setColor(Color.WHITE); c.drawCircle(s.x, s.y, s.r * 0.4f, p); break;
            case S_FIRE: p.setColor(Color.rgb(255, 120, 30)); c.drawCircle(s.x, s.y, s.r, p); p.setColor(Color.rgb(255, 230, 90)); c.drawCircle(s.x, s.y, s.r * 0.5f, p); break;
            case S_ROCK: p.setColor(Color.rgb(140, 130, 120)); c.drawRect(s.x - s.r, s.y - s.r, s.x + s.r, s.y + s.r, p); break;
            case S_WAVE: p.setColor(Color.rgb(255, 200, 80)); c.drawRect(s.x - 8, s.y - 16, s.x + 8, s.y, p); break;
            case S_SLASH: p.setColor(Color.argb(200, 255, 60, 60)); c.drawRect(s.x - 3, s.y - 14, s.x + 3, s.y + 14, p); break;
        }
    }

    void drawPlayer(Canvas c) {
        if (invul > 0 && ((int) (invul * 20)) % 2 == 0) return;
        Bitmap b;
        boolean air = !onGround;
        if (air) b = facingRight ? sKnightJump : sKnightJumpL;
        else if (Math.abs(pvx) > 1 && ((int) walkAnim) % 2 == 0) b = facingRight ? sKnightRun : sKnightRunL;
        else b = facingRight ? sKnight : sKnightL;
        GameKit.draw(c, b, px - 2, py - 2, pw + 4, ph + 2);
        if (wingsT > 0) text(c, "🪽", px + pw / 2, py + 6, 16, Color.WHITE);
        // espada
        if (swingT > 0) {
            float k = 1 - swingT / 0.2f;
            p.setColor(Color.argb(140, 255, 255, 255));
            float sx = facingRight ? px + pw : px - 30;
            c.drawRect(sx, py - 4 + k * 10, sx + 30, py + 2 + k * 10, p);
            GameKit.draw(c, sSword, facingRight ? px + pw - 2 : px - 10, py - 4, 12, 22);
        }
    }

    void drawHud(Canvas c, int neon) {
        float y = 14;
        // vida
        float bw = 150;
        p.setColor(Color.argb(170, 0, 0, 0));
        c.drawRoundRect(8, y - 4, 8 + bw + 4, y + 14, 6, 6, p);
        p.setColor(Color.rgb(255, 70, 90));
        c.drawRoundRect(10, y - 2, 10 + bw * Math.max(0, hp / maxHp()), y + 12, 5, 5, p);
        textLeft(c, "❤ " + Math.max(0, Math.round(hp)) + " / " + Math.round(maxHp()), 14, y + 9, 11, Color.WHITE);
        // escuditos
        int n = shields();
        for (int i = 0; i < n; i++) {
            boolean ready = runTime >= shieldReady[i];
            float sx = 166 + i * 18;
            p.setColor(ready ? Color.rgb(90, 180, 255) : Color.argb(90, 90, 180, 255));
            c.drawRoundRect(sx, y - 3, sx + 14, y + 13, 4, 4, p);
            if (!ready) {
                float frac = 1 - (shieldReady[i] - runTime) / SHIELD_RECHARGE;
                p.setColor(Color.rgb(90, 180, 255));
                c.drawRect(sx, y + 13 - 16 * frac, sx + 14, y + 13, p);
            }
        }
        if (tempShield) text(c, "🛡", 166 + n * 18 + 8, y + 10, 13, Color.WHITE);
        // XP
        y += 22;
        p.setColor(Color.argb(170, 0, 0, 0));
        c.drawRoundRect(8, y - 2, 162, y + 7, 4, 4, p);
        p.setColor(Color.rgb(120, 255, 160));
        c.drawRoundRect(9, y - 1, 9 + 152 * xp / (float) xpNeed(lvl), y + 6, 3, 3, p);
        textLeft(c, "NV " + lvl + (pts > 0 ? "  · " + pts + " pts (⏸)" : ""), 168, y + 7, 11, pts > 0 ? Color.rgb(255, 230, 80) : Color.WHITE);
        // piso y balas
        y += 22;
        textLeft(c, "PISO " + maxFloor, 10, y + 6, 16, neon);
        textLeft(c, "🔫 " + ammo, 110, y + 6, 13, Color.WHITE);
        float bx = 170;
        if (wingsT > 0) { textLeft(c, "🪽" + (int) Math.ceil(wingsT), bx, y + 6, 12, Color.WHITE); bx += 40; }
        if (magnetT > 0) { textLeft(c, "🧲" + (int) Math.ceil(magnetT), bx, y + 6, 12, Color.WHITE); bx += 40; }
        if (powerT > 0) { textLeft(c, "⚡" + (int) Math.ceil(powerT), bx, y + 6, 12, Color.WHITE); }
        if (pts > 0 && ((int) (runTime * 3)) % 2 == 0) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2);
            p.setColor(Color.rgb(255, 230, 80));
            c.drawRoundRect(bPause.r, 8, 8, p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    // ---------------- menús ----------------
    void drawMenu(Canvas c, int neon) {
        float cy = vh * 0.22f;
        text(c, "TORRE", 180, cy, 44, neon);
        text(c, "ARRIBA", 180, cy + 46, 44, neon);
        GameKit.draw(c, sKnight, 160, cy + 70, 40, 46);
        if (prefs().getBoolean("tower_won", false)) {
            GameKit.draw(c, sSword, 210, cy + 78, 14, 34);
            text(c, "🗡 Llegaste al piso 1000", 180, cy + 140, 13, Color.rgb(255, 220, 80));
        }
        text(c, "Récord: piso " + prefs().getInt("best_tower", 0), 180, cy + 162, 15, Color.WHITE);
        float y = cy + 190;
        int saved = savedFloor();
        if (saved > 0) {
            RectF r = new RectF(60, y, 300, y + 48);
            if (menuButton(c, r, "▶ CONTINUAR (piso " + saved + ")", neon) && loadRun()) return;
            y += 60;
        }
        RectF r2 = new RectF(60, y, 300, y + 48);
        if (menuButton(c, r2, saved > 0 ? "NUEVA PARTIDA" : "▶ JUGAR", neon)) { newRun(); return; }
        y += 60;
        RectF r3 = new RectF(60, y, 300, y + 48);
        if (menuButton(c, r3, "SALIR", neon)) { ((android.app.Activity) getContext()).finish(); return; }
        y += 70;
        wrap(c, "◀ ▶ moverte · ⬆ saltar · ⚔ espada · 🔫 pistola\n"
                + "Sube sin caerte. Cada 15 pisos un jefe, cada 30 uno fuerte y cada 60 un Guardián. "
                + "Si mueres, empiezas de cero.", 180, y, 320, 12, Color.argb(200, 255, 255, 255), true);
    }

    static final String[] STAT_NAMES = {"❤ Vida", "⚔ Daño", "🦘 Salto", "🛡 Defensa", "🩸 Robo vida"};

    void drawPause(Canvas c, int neon) {
        p.setColor(Color.argb(200, 0, 0, 0));
        c.drawRect(0, 0, vw, vh, p);
        RectF panel = new RectF(16, 60, 344, 60 + 430);
        box(c, panel, neon, 230);
        text(c, "PAUSA · NIVEL " + lvl, 180, 92, 20, neon);
        text(c, "Puntos para repartir: " + pts, 180, 116, 14, pts > 0 ? Color.rgb(255, 230, 80) : Color.WHITE);
        int[] cur = {pVida, pDano, pSalto, pDef, pRobo};
        int[] max = {VIDA_MAX_PTS, DANO_MAX_PTS, SALTO_MAX_PTS, DEF_MAX_PTS, ROBO_MAX_PTS};
        String[] val = {
                Math.round(maxHp()) + " vida",
                Math.round(BASE_DMG + DMG_PER_PT * pDano) + " daño",
                Math.round(100 + JUMP_PER_PT * 100 * pSalto) + " %",
                shields() + " escuditos",
                String.format(java.util.Locale.US, "%.1f %%", robo())};
        float y = 140;
        for (int i = 0; i < 5; i++) {
            textLeft(c, STAT_NAMES[i], 30, y + 20, 14, Color.WHITE);
            textLeft(c, val[i], 150, y + 20, 13, Color.rgb(180, 200, 230));
            textLeft(c, cur[i] + "/" + max[i], 245, y + 20, 11, Color.GRAY);
            RectF plus = new RectF(292, y + 2, 330, y + 30);
            boolean can = pts > 0 && cur[i] < max[i];
            box(c, plus, can ? neon : Color.DKGRAY, 200);
            text(c, "+", plus.centerX(), plus.centerY() + 7, 20, can ? Color.WHITE : Color.GRAY);
            if (can && tapIn(plus)) {
                pts--;
                switch (i) {
                    case 0: pVida++; hp = Math.min(maxHp(), hp + HP_PER_PT); break;
                    case 1: pDano++; break;
                    case 2: pSalto++; break;
                    case 3: pDef++; break;
                    case 4: pRobo++; break;
                }
                chip.sfx(Chip.SFX_COIN);
            }
            y += 38;
        }
        textLeft(c, "Cada 5 de defensa = 1 escudito (bloquea un golpe, se recarga en 30 s)", 26, y + 14, 9, Color.GRAY);
        y += 30;
        RectF mus = new RectF(30, y, 175, y + 40), sfx = new RectF(185, y, 330, y + 40);
        if (menuButton(c, mus, Chip.musicOn(getContext()) ? "🎵 Música: SÍ" : "🎵 Música: NO", neon)) { chip.toggleMusic(); }
        if (menuButton(c, sfx, Chip.sfxOn(getContext()) ? "🔊 Efectos: SÍ" : "🔊 Efectos: NO", neon)) { chip.toggleSfx(); }
        y += 52;
        RectF go = new RectF(30, y, 175, y + 46), quit = new RectF(185, y, 330, y + 46);
        if (menuButton(c, go, "▶ SEGUIR", neon)) { state = ST_PLAY; pad.releaseAll(); }
        if (menuButton(c, quit, "💾 SALIR", neon)) {
            saveRun();
            state = ST_MENU;
            setPlayButtons(false);
        }
        text(c, "Tiempo: " + SysInfo.duration((long) (runTime * 1000)) + " · Enemigos: " + kills, 180, panel.bottom + 22, 12, Color.GRAY);
    }

    void drawDead(Canvas c, int neon) {
        p.setColor(Color.argb(200, 0, 0, 0));
        c.drawRect(0, 0, vw, vh, p);
        text(c, "HAS CAÍDO", 180, vh * 0.3f, 34, Color.rgb(255, 80, 90));
        text(c, deathMsg, 180, vh * 0.3f + 34, 14, Color.WHITE);
        text(c, "Piso " + maxFloor + " · Nivel " + lvl + " · " + kills + " enemigos", 180, vh * 0.3f + 60, 13, Color.WHITE);
        text(c, "Récord: piso " + prefs().getInt("best_tower", 0), 180, vh * 0.3f + 84, 14, neon);
        RectF again = new RectF(60, vh * 0.3f + 110, 300, vh * 0.3f + 158);
        if (menuButton(c, again, "↻ OTRA VEZ", neon)) { newRun(); return; }
        RectF menu = new RectF(60, vh * 0.3f + 170, 300, vh * 0.3f + 218);
        if (menuButton(c, menu, "MENÚ", neon)) { state = ST_MENU; chip.play(Songs.TOWER); }
    }

    void drawEnding(Canvas c, int neon) {
        // cielo nocturno y luna
        p.setColor(Color.rgb(10, 12, 40));
        c.drawRect(0, 0, vw, vh, p);
        p.setColor(Color.argb(200, 255, 255, 255));
        for (int i = 0; i < 60; i++) c.drawRect((i * 97) % 360, (i * 53) % (vh * 0.6f), (i * 97) % 360 + 1.5f, (i * 53) % (vh * 0.6f) + 1.5f, p);
        p.setColor(Color.rgb(255, 250, 220));
        c.drawCircle(280, vh * 0.15f, 26, p);
        float ground = vh * 0.62f;
        p.setColor(Color.rgb(70, 70, 95));
        c.drawRect(0, ground, vw, vh, p);
        p.setColor(Color.rgb(140, 140, 170));
        c.drawRect(0, ground, vw, ground + 4, p);

        float t = endT;
        // puerta
        GameKit.draw(c, t > 4 ? sDoorOpen : sDoor, 290, ground - 64, 48, 64);
        // espada clavada
        if (t > 2.6f) GameKit.draw(c, sSword, 176, ground - 30, 14, 36);
        float fade = 1;
        if (t > 9.5f) fade = Math.max(0, 1 - (t - 9.5f));
        Paint a = new Paint();
        a.setAlpha((int) (255 * fade));
        if (fade > 0) {
            GameKit.draw(c, t < 2.6f && ((int) (t * 6)) % 2 == 0 ? sKnightRun : sKnight, knightX - 18, ground - 46, 36, 46, a);
            if (t > 4.5f) GameKit.draw(c, princessX > 200 && t < 6.5f ? sPrincessL : sPrincess, princessX - 18, ground - 46, 36, 46, a);
        }
        if (t > 6.8f && t < 9.5f) text(c, "❤", (knightX + princessX) / 2, ground - 56 - (t - 6.8f) * 6, 18, Color.rgb(255, 90, 130));
        if (t < 2.6f) text(c, "PISO 1000", 180, vh * 0.3f, 26, neon);
        if (t > 11) {
            text(c, "FIN", 180, vh * 0.32f, 54, Color.WHITE);
            text(c, "Tiempo: " + SysInfo.duration((long) (runTime * 1000)), 180, vh * 0.32f + 36, 15, Color.rgb(255, 230, 150));
            text(c, "La espada se queda aquí, para siempre.", 180, vh * 0.32f + 60, 12, Color.argb(200, 255, 255, 255));
            RectF r = new RectF(80, vh * 0.8f, 280, vh * 0.8f + 46);
            if (menuButton(c, r, "VOLVER", neon)) { state = ST_MENU; maxFloor = 1; chip.play(Songs.TOWER); }
        }
    }

    // =====================================================================
    // Sprites de píxeles
    // =====================================================================
    void buildSprites() {
        String k = "hdacbyw";
        int[] kc = {0xffc8d0e0, 0xff202838, 0xff3a6cf0, 0xffe03040, 0xff6a4020, 0xffffd040, 0xffffffff};
        String[] knight = {
                ".....yy.....",
                "....hhhh....",
                "...hhhhhh...",
                "...hddddh...",
                "...hhhhhh...",
                "....hhhh....",
                "..aaaaaaaa..",
                ".haaaccaaah.",
                ".haaaccaaah.",
                "..aaaaaaaa..",
                "..aaa..aaa..",
                "..aa....aa..",
                "..bb....bb..",
                ".bbb....bbb."};
        String[] knightRun = knight.clone();
        knightRun[10] = "..aaa..aa...";
        knightRun[11] = ".aa......aa.";
        knightRun[12] = ".bb......bb.";
        knightRun[13] = "bbb.......bb";
        String[] knightJump = knight.clone();
        knightJump[10] = "..aaaaaaaa..";
        knightJump[11] = "...aa..aa...";
        knightJump[12] = "...bb..bb...";
        knightJump[13] = "............";
        sKnight = GameKit.sprite(knight, k, kc);
        sKnightRun = GameKit.sprite(knightRun, k, kc);
        sKnightJump = GameKit.sprite(knightJump, k, kc);
        sKnightL = GameKit.flipH(sKnight);
        sKnightRunL = GameKit.flipH(sKnightRun);
        sKnightJumpL = GameKit.flipH(sKnightJump);

        sPrincess = GameKit.sprite(new String[]{
                "...y.y.y....",
                "...yyyyy....",
                "..ooooooo...",
                "..oFFFFFo...",
                "..oFdFdFo...",
                "..oFFFFFo...",
                "..ooFFFoo...",
                "...ppppp....",
                "..ppwppp....",
                "..ppppppp...",
                ".ppppppppp..",
                ".ppppppppp..",
                "pppppppppp..",
                "..bb..bb...."}, "yoFdpwb", new int[]{0xffffd040, 0xffff8a30, 0xffffd8b8, 0xff202020, 0xffff6fb0, 0xffffffff, 0xff8a4a2a});
        sPrincessL = GameKit.flipH(sPrincess);

        sSlug = GameKit.sprite(new String[]{
                "........gg..",
                ".......gddg.",
                "......ggggg.",
                "...gggggggg.",
                "..gggggggggg",
                ".gllllllllll",
                "gggggggggggg",
                ".g.g.g.g.g.."}, "gdl", new int[]{0xff4ad060, 0xff102010, 0xffa0f0a0});
        sBat = GameKit.sprite(new String[]{
                "v..........v",
                "vv...vv...vv",
                "vvv.vvvv.vvv",
                "vvvvvrrvvvvv",
                ".vvvvvvvvvv.",
                "..vv.vv.vv..",
                "...v....v...",
                "............"}, "vr", new int[]{0xff8040c0, 0xffff4040});
        sBat2 = GameKit.sprite(new String[]{
                "............",
                ".....vv.....",
                "....vvvv....",
                ".vvvvrrvvvv.",
                "vvvvvvvvvvvv",
                "vv..vvvv..vv",
                "v....vv....v",
                "............"}, "vr", new int[]{0xff8040c0, 0xffff4040});
        sMage = GameKit.sprite(new String[]{
                "....mm....",
                "...mmmm...",
                "..mmmmmm..",
                ".mmmmmmmm.",
                "...ffff...",
                "...fyfy...",
                "...ffff...",
                "..mmmmmm..",
                ".mmmmmmmms",
                ".mmmmmmm.s",
                ".mmmmmmm.s",
                "..mm..mm.s"}, "mfys", new int[]{0xff7a40d0, 0xffd8b8a0, 0xffffff60, 0xffc08040});
        sGolem = GameKit.sprite(new String[]{
                "....gggggg......",
                "...gggggggg.....",
                "...gyggggyg.....",
                "...gggggggg.....",
                ".gggggggggggg...",
                "gggggmmgggggggg.",
                "ggg.gggggggg.ggg",
                "ggg.gggggggg.ggg",
                "gg..gggggggg..gg",
                "....ggg..ggg....",
                "....ggg..ggg....",
                "...gggg..gggg...",
                "...gggg..gggg...",
                "..ddddd..ddddd.."}, "gymd", new int[]{0xff8a8a90, 0xffffa020, 0xff5a5a60, 0xff404048});
        sDragon = GameKit.sprite(new String[]{
                "..w.........w...",
                ".ww...rr...ww...",
                "www..rrrr.www...",
                "wwwwrrrrrrwww...",
                ".wwwrryrrrww....",
                "....rrrrrrrrr...",
                "...rrrrrrrrrrrr.",
                "..rrrrooorrr.rrr",
                ".rrr.ooooo.r...r",
                ".rr...rr.rr.....",
                "......r...r.....",
                "................"}, "wryo", new int[]{0xffa02020, 0xffe03030, 0xffffe040, 0xffffa040});
        sDKnight = GameKit.sprite(new String[]{
                "....kkkk....",
                "...kkkkkk...",
                "...krrrrk...",
                "...kkkkkk...",
                "..kkkkkkkk.s",
                ".kkkrrrrkkks",
                ".kkkkkkkkk.s",
                "..kkkkkkkk.s",
                "..kkk..kkk..",
                "..kk....kk..",
                "..kk....kk..",
                ".kkk....kkk."}, "krs", new int[]{0xff1a1a24, 0xffff2030, 0xffc0c0d0});
        sEye = GameKit.sprite(new String[]{
                "....pppppp....",
                "..pppppppppp..",
                ".pppwwwwwwppp.",
                ".ppwwwwwwwwpp.",
                "ppwwwwbbwwwwpp",
                "ppwwwbkkbwwwpp",
                "ppwwwbkkbwwwpp",
                "ppwwwwbbwwwwpp",
                ".ppwwwwwwwwpp.",
                ".pppwwwwwwppp.",
                "..pppppppppp..",
                "....pppppp....",
                "...p..p..p....",
                "..p...p...p..."}, "pwbk", new int[]{0xff9030d0, 0xfff0f0ff, 0xffff3080, 0xff100010});
        sDoor = GameKit.sprite(new String[]{
                "..ssssssss..",
                ".sbbbbbbbbs.",
                "sbbbbbbbbbbs",
                "sbbbbbbbbbbs",
                "sbbbbbbbbbbs",
                "sbbbbbbbbbbs",
                "sbbbbbbbbybs",
                "sbbbbbbbbbbs",
                "sbbbbbbbbbbs",
                "sbbbbbbbbbbs",
                "sbbbbbbbbbbs",
                "sbbbbbbbbbbs"}, "sby", new int[]{0xff606070, 0xff7a4a2a, 0xffffd040});
        sDoorOpen = GameKit.sprite(new String[]{
                "..ssssssss..",
                ".sllllllllb.",
                "sllllllllllb",
                "sllllllllllb",
                "sllllllllllb",
                "sllllllllllb",
                "sllllllllllb",
                "sllllllllllb",
                "sllllllllllb",
                "sllllllllllb",
                "sllllllllllb",
                "sllllllllllb"}, "slb", new int[]{0xff606070, 0xfffff2b0, 0xff7a4a2a});
        sSword = GameKit.sprite(new String[]{
                ".ss.",
                ".ss.",
                ".ss.",
                ".ss.",
                ".ss.",
                ".ss.",
                ".ss.",
                "gggg",
                ".bb.",
                ".bb.",
                ".gg."}, "sgb", new int[]{0xffe0e8f8, 0xffffd040, 0xff6a4020});
        sCrown = GameKit.sprite(new String[]{
                "y.y.y.y",
                "yyyyyyy",
                "yryyyry",
                "yyyyyyy"}, "yr", new int[]{0xffffd040, 0xffff3040});
    }
}
