package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Sección Adicionales: documentos, biblioteca, gestor de archivos y visor 3D. */
public class AdditionalActivity extends NeonActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("ADICIONALES");
        card(col, "📄 DOCUMENTOS", "Lee, edita y convierte PDF, EPUB, DOCX y TXT. Crea documentos nuevos.", DocsActivity.class);
        card(col, "📚 BIBLIOTECA", "Tus libros elegidos, con la página donde te quedaste y lectura en voz alta.", LibraryActivity.class);
        card(col, "🗂 GESTOR DE ARCHIVOS", "Explora tu teléfono: copia, mueve, renombra, borra, comprime y descomprime ZIP/RAR.", FilesActivity.class);
        // v1.7: aquí van ahora «buscar el móvil» y el grabador (la app se abre en el chat con Chloe)
        card(col, "👏 BUSCAR EL MÓVIL AL APLAUDIR", "Aplaude (2 a 8 veces) y suena aunque esté bloqueado o en silencio. Sonido, volumen y sensibilidad a tu gusto.",
                new Intent(this, MainActivity.class).putExtra(MainActivity.EXTRA_CLAP, true));
        card(col, "⏺ GRABAR PANTALLA", "Graba la pantalla con el sonido interno, el micrófono o los dos, cada uno con su volumen.", new Intent(this, ScreenRecActivity.class));
        card(col, "🧊 EDITOR 3D", "Abre, edita y convierte modelos 3D: STL, OBJ, FBX, GLB y VRM. Huesos, pesos, pintura de texturas y exportación a VRM.", Model3DActivity.class);
    }

    void card(LinearLayout col, String title, String desc, Class<?> target) { card(col, title, desc, new Intent(this, target)); }

    void card(LinearLayout col, String title, String desc, Intent target) {
        LinearLayout c = panel(null);
        c.addView(neonText(title, 19));
        TextView d = text(desc, 13);
        d.setTextColor(Color.rgb(170, 180, 200));
        d.setPadding(0, dpi(4), 0, 0);
        c.addView(d);
        c.setClickable(true);
        c.setOnClickListener(v -> startActivity(target));
        col.addView(c, gapBelow(14));
    }
}
