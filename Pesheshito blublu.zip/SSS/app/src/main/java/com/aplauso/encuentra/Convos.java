package com.aplauso.encuentra;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * v1.7 · CONVERSACIONES GUARDADAS (como el menú de Claude): cada charla con Chloe se guarda en el teléfono con su título;
 * puedes fijarla, renombrarla, borrarla o volver a abrirla y seguir donde lo dejasteis. Además, cuando hablas de algo que
 * ya salió en otra conversación, Chloe recibe esas líneas como recuerdo. Todo se queda en el teléfono.
 */
public class Convos {
    public static final class Convo {
        public String id, title = "";
        public boolean pinned;
        public long updated;
        public final List<String[]> msgs = new ArrayList<>();      // {"user"|"model", texto[, "p"]}
    }

    static Context app;
    static Convo cur;
    static final Object LOCK = new Object();

    static File dir() { File d = new File(app.getFilesDir(), "convos"); d.mkdirs(); return d; }
    static File file(String id) { return new File(dir(), id + ".json"); }

    /** Al abrir la app: la conversación en la que estabas vuelve (y Brain.history con sus últimos mensajes). */
    static void init(Context c) {
        app = c.getApplicationContext();
        synchronized (LOCK) {
            String id = c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("convo_cur", "");
            Convo k = id.isEmpty() ? null : load(id);
            cur = k != null ? k : fresh();
            syncHistory();
        }
    }

    static Convo fresh() {
        Convo k = new Convo();
        k.id = Long.toString(System.currentTimeMillis(), 36);
        k.updated = System.currentTimeMillis();
        if (app != null) app.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString("convo_cur", k.id).apply();
        return k;
    }

    static Convo current() { synchronized (LOCK) { if (cur == null) cur = fresh(); return cur; } }

    /** Se llama cada vez que Brain apunta algo en la conversación. */
    static void add(String role, String text, boolean priv) {
        if (app == null || text == null) return;
        synchronized (LOCK) {
            Convo k = current();
            k.msgs.add(priv ? new String[]{role, text, "p"} : new String[]{role, text});
            k.updated = System.currentTimeMillis();
            if (k.title.isEmpty() && role.equals("user")) k.title = titleOf(text);
            while (k.msgs.size() > 400) k.msgs.remove(0);
        }
        saveSoon();
    }

    static String titleOf(String q) {
        String t = q.replaceAll("\\s+", " ").trim();
        t = t.replaceFirst("(?i)^(oye|hola|chloe|eh|mira|bueno|vale|ok)[,!. ]+", "").trim();
        if (t.isEmpty()) t = q.trim();
        if (t.length() > 42) { int sp = t.lastIndexOf(' ', 42); t = t.substring(0, sp > 20 ? sp : 42) + "…"; }
        return t.isEmpty() ? "" : Character.toUpperCase(t.charAt(0)) + t.substring(1);
    }

    // ---------------- guardar ----------------
    static final android.os.Handler bg;
    static {
        android.os.HandlerThread t = new android.os.HandlerThread("convos");
        t.start();
        bg = new android.os.Handler(t.getLooper());
    }
    static final Runnable saver = () -> { try { saveNow(); } catch (Exception ignored) {} };

    static void saveSoon() { bg.removeCallbacks(saver); bg.postDelayed(saver, 600); }

    static void saveNow() throws Exception {
        JSONObject o;
        String id;
        synchronized (LOCK) {
            if (cur == null || cur.msgs.isEmpty()) return;
            o = toJson(cur);
            id = cur.id;
        }
        File f = file(id), tmp = new File(f.getPath() + ".tmp");
        java.nio.file.Files.write(tmp.toPath(), o.toString().getBytes(StandardCharsets.UTF_8));
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f); }
    }

    static JSONObject toJson(Convo k) throws Exception {
        JSONArray m = new JSONArray();
        for (String[] x : k.msgs) { JSONArray a = new JSONArray(); for (String s : x) a.put(s); m.put(a); }
        return new JSONObject().put("id", k.id).put("title", k.title).put("pinned", k.pinned).put("updated", k.updated).put("msgs", m);
    }

    static Convo load(String id) {
        try {
            JSONObject o = new JSONObject(new String(java.nio.file.Files.readAllBytes(file(id).toPath()), StandardCharsets.UTF_8));
            Convo k = new Convo();
            k.id = o.getString("id"); k.title = o.optString("title"); k.pinned = o.optBoolean("pinned"); k.updated = o.optLong("updated");
            JSONArray m = o.optJSONArray("msgs");
            if (m != null) for (int i = 0; i < m.length(); i++) {
                JSONArray a = m.getJSONArray(i);
                String[] x = new String[a.length()];
                for (int j = 0; j < x.length; j++) x[j] = a.getString(j);
                k.msgs.add(x);
            }
            return k;
        } catch (Exception e) { return null; }
    }

    /** Todas (sin los mensajes cargados del todo si no hace falta): fijadas primero, luego las más recientes. */
    static List<Convo> all() {
        try { saveNow(); } catch (Exception ignored) {}
        List<Convo> out = new ArrayList<>();
        File[] fs = dir().listFiles((d, n) -> n.endsWith(".json"));
        if (fs != null) for (File f : fs) { Convo k = load(f.getName().replace(".json", "")); if (k != null && !k.msgs.isEmpty()) out.add(k); }
        out.sort((a, b) -> a.pinned != b.pinned ? (a.pinned ? -1 : 1) : Long.compare(b.updated, a.updated));
        return out;
    }

    /** Brain.history = los últimos mensajes de la conversación actual (lo que el cerebro tiene en cuenta). */
    static void syncHistory() {
        synchronized (Brain.history) {
            Brain.history.clear();
            List<String[]> m = cur.msgs;
            for (int i = Math.max(0, m.size() - 20); i < m.size(); i++) Brain.history.add(m.get(i));
        }
    }

    /** Abre otra conversación para seguirla. */
    static void open(String id) {
        try { saveNow(); } catch (Exception ignored) {}
        synchronized (LOCK) {
            Convo k = load(id);
            if (k == null) return;
            cur = k;
            app.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString("convo_cur", k.id).apply();
            syncHistory();
        }
    }

    /** Empieza una nueva (la de ahora queda guardada). */
    static void newOne() {
        try { saveNow(); } catch (Exception ignored) {}
        synchronized (LOCK) { cur = fresh(); syncHistory(); }
    }

    static void rename(String id, String title) { edit(id, k -> k.title = title.trim()); }
    static void pin(String id, boolean on) { edit(id, k -> k.pinned = on); }

    interface Change { void apply(Convo k); }

    static void edit(String id, Change ch) {
        synchronized (LOCK) {
            if (cur != null && cur.id.equals(id)) { ch.apply(cur); }
            else {
                Convo k = load(id);
                if (k == null) return;
                ch.apply(k);
                try { java.nio.file.Files.write(file(id).toPath(), toJson(k).toString().getBytes(StandardCharsets.UTF_8)); } catch (Exception ignored) {}
                return;
            }
        }
        try { saveNow(); } catch (Exception ignored) {}
    }

    static void delete(String id) {
        file(id).delete();
        synchronized (LOCK) { if (cur != null && cur.id.equals(id)) { cur = fresh(); syncHistory(); } }
    }

    /** Las que contienen un texto (para el buscador del menú). */
    static List<Convo> search(String q) {
        String n = Actions.norm(q);
        List<Convo> out = new ArrayList<>();
        for (Convo k : all()) {
            boolean hit = Actions.norm(k.title).contains(n);
            if (!hit) for (String[] m : k.msgs) if (Actions.norm(m[1]).contains(n)) { hit = true; break; }
            if (hit) out.add(k);
        }
        return out;
    }

    /**
     * Recuerdos de OTRAS conversaciones que tienen que ver con la pregunta (palabras en común), para el cerebro.
     * Nunca incluye las del trabajo (marcadas «p»). Vacío si no hay nada.
     */
    static String related(String q, int maxChars) {
        if (app == null || q == null) return "";
        java.util.Set<String> words = new java.util.HashSet<>();
        for (String w : Actions.norm(q).split("\\W+")) if (w.length() >= 5) words.add(w);
        if (words.isEmpty()) return "";
        String curId;
        synchronized (LOCK) { curId = cur == null ? "" : cur.id; }
        StringBuilder b = new StringBuilder();
        int best = 0;
        for (Convo k : all()) {
            if (k.id.equals(curId)) continue;
            for (int i = 0; i + 1 < k.msgs.size(); i++) {
                String[] u = k.msgs.get(i), a = k.msgs.get(i + 1);
                if (!u[0].equals("user") || u.length > 2 || a.length > 2) continue;
                int hits = 0;
                for (String w : Actions.norm(u[1] + " " + a[1]).split("\\W+")) if (words.contains(w)) hits++;
                if (hits >= Math.max(1, Math.min(2, words.size()))) {
                    String line = "- «" + cut(u[1], 120) + "» → " + cut(Brain.speech(a[1]), 200) + "\n";
                    if (b.length() + line.length() > maxChars) return b.toString();
                    b.append(line);
                    best++;
                    if (best >= 4) return b.toString();
                }
            }
        }
        return b.toString();
    }

    static String cut(String s, int n) { return s.length() <= n ? s : s.substring(0, n) + "…"; }
}
