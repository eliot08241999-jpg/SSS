package com.aplauso.encuentra;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * v1.7 · EL LECTOR DE TEXTO SIN COMPRIMIR. Los modelos del Estudio vienen «cuantizados» en int8: también se comprime lo que
 * va pasando por dentro (las activaciones), y el lector de texto (CLIP) tiene valores internos muy grandes que así se pierden:
 * por eso solo hacía caso a las primeras palabras. Aquí se reescribe el grafo para que calcule en coma flotante
 * (los pesos siguen guardados igual, en int8): cada
 *   DynamicQuantizeLinear → MatMulInteger → Cast → Mul(escalas)
 * pasa a ser
 *   DequantizeLinear(pesos) → MatMul
 * y los pares QuantizeLinear → DequantizeLinear sobre activaciones se quitan. El lector de texto trabaja una vez por imagen:
 * no se nota en la velocidad. El resultado va a otro archivo (el original no se toca).
 */
public class OnnxFloat {
    static final class Node {
        final List<String> in = new ArrayList<>(), out = new ArrayList<>();
        String op = "", name = "", domain = "";
        byte[] raw;              // tal cual estaba (si no se toca)
        byte[] attrs;            // atributos ya codificados (para nodos nuevos)
        boolean dead;
    }

    /** Escribe en «out» la versión en coma flotante. Devuelve cuántas multiplicaciones cambió (0 = no hacía falta). */
    static int convert(File in, File out) throws Exception {
        byte[] b = java.nio.file.Files.readAllBytes(in.toPath());
        int[] graphPos = findGraph(b);
        if (graphPos == null) throw new Exception("modelo sin grafo");
        int gFrom = graphPos[0], gTo = graphPos[1];
        // nodos e inicializadores
        List<Node> nodes = new ArrayList<>();
        Map<String, OnnxPatch.Tensor> inits = new HashMap<>();
        OnnxPatch.Buf r = new OnnxPatch.Buf(b, gFrom);
        while (r.p < gTo) {
            int start = r.p;
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 1 && wt == 2) {
                int n = (int) r.varint();
                Node nd = parseNode(b, r.p, r.p + n);
                nd.raw = java.util.Arrays.copyOfRange(b, start, r.p + n);
                nodes.add(nd);
                r.p += n;
            } else if (f == 5 && wt == 2) {
                int n = (int) r.varint();
                OnnxPatch.Tensor t = OnnxPatch.tensor(b, r.p, r.p + n);
                inits.put(t.name, t);
                r.p += n;
            } else r.skip(wt);
        }
        Map<String, Node> producer = new HashMap<>();
        Map<String, List<Node>> consumers = new HashMap<>();
        for (Node n : nodes) {
            for (String o : n.out) producer.put(o, n);
            for (String i : n.in) if (!i.isEmpty()) consumers.computeIfAbsent(i, k -> new ArrayList<>()).add(n);
        }
        Map<Node, List<Node>> insertBefore = new HashMap<>();
        Map<Node, Node> replaceWith = new HashMap<>();
        int changed = 0, uid = 0;

        // 1) DynamicQuantizeLinear → MatMulInteger → Cast → Mul
        for (Node m : nodes) {
            if (!m.op.equals("MatMulInteger") || m.in.size() < 2) continue;
            List<Node> cs = consumers.getOrDefault(m.out.get(0), new ArrayList<>());
            if (cs.size() != 1 || !cs.get(0).op.equals("Cast")) continue;
            Node cast = cs.get(0);
            List<Node> cs2 = consumers.getOrDefault(cast.out.get(0), new ArrayList<>());
            if (cs2.size() != 1 || !cs2.get(0).op.equals("Mul")) continue;
            Node mulOut = cs2.get(0);
            String sName = mulOut.in.get(0).equals(cast.out.get(0)) ? mulOut.in.get(1) : mulOut.in.get(0);
            Node sMul = producer.get(sName);
            // escala de cada entrada
            String[] scale = new String[2], zp = new String[2], src = new String[2];
            boolean ok = true;
            for (int k = 0; k < 2 && ok; k++) {
                String x = m.in.get(k);
                Node d = producer.get(x);
                if (d != null && d.op.equals("DynamicQuantizeLinear") && d.out.get(0).equals(x)) {
                    src[k] = d.in.get(0);                         // la activación en coma flotante, antes de comprimirla
                    scale[k] = d.out.get(1);
                } else if (inits.containsKey(x)) {
                    src[k] = null;                               // peso: hay que descomprimirlo
                    zp[k] = m.in.size() > k + 2 ? m.in.get(k + 2) : "";
                } else ok = false;
            }
            if (!ok) continue;
            // la escala de los pesos es la otra entrada del Mul de escalas (o directamente la del Mul final si solo hay una)
            for (int k = 0; k < 2; k++) {
                if (src[k] != null) continue;
                String other = src[1 - k] != null ? scale[1 - k] : null;
                if (sMul != null && sMul.op.equals("Mul")) {
                    String a = sMul.in.get(0), c = sMul.in.get(1);
                    scale[k] = other == null ? null : a.equals(other) ? c : c.equals(other) ? a : null;
                } else if (inits.containsKey(sName) && other == null) scale[k] = sName;
                if (scale[k] == null || !inits.containsKey(scale[k])) ok = false;
            }
            if (!ok || (src[0] == null && src[1] == null)) continue;
            List<Node> pre = new ArrayList<>();
            String[] fIn = new String[2];
            for (int k = 0; k < 2; k++) {
                if (src[k] != null) { fIn[k] = src[k]; continue; }
                Node dq = new Node();
                dq.op = "DequantizeLinear";
                dq.name = "sssf_dq_" + (uid++);
                dq.in.add(m.in.get(k)); dq.in.add(scale[k]);
                if (zp[k] != null && !zp[k].isEmpty()) dq.in.add(zp[k]);
                String o = m.in.get(k) + "_sssf" + (uid++);
                dq.out.add(o);
                OnnxPatch.Tensor st = inits.get(scale[k]);
                long elems = 1; for (long dd : st.dims) elems *= dd;
                if (elems > 1) dq.attrs = attrInt("axis", k == 1 ? 1 : 0);      // por columnas (pesos [K,N])
                pre.add(dq);
                fIn[k] = o;
            }
            Node mm = new Node();
            mm.op = "MatMul";
            mm.name = "sssf_mm_" + (uid++);
            mm.in.add(fIn[0]); mm.in.add(fIn[1]);
            mm.out.add(mulOut.out.get(0));
            m.dead = true; cast.dead = true;
            insertBefore.put(mulOut, pre);
            replaceWith.put(mulOut, mm);
            if (sMul != null && consumers.getOrDefault(sName, new ArrayList<>()).size() == 1) sMul.dead = true;
            changed++;
        }
        // DynamicQuantizeLinear que ya nadie usa
        Set<String> live = new HashSet<>();
        for (Node n : nodes) {
            if (n.dead || n.op.equals("DynamicQuantizeLinear")) continue;
            Node rep = replaceWith.get(n);
            for (String i : (rep != null ? rep.in : n.in)) live.add(i);
            List<Node> pre = insertBefore.get(n);
            if (pre != null) for (Node p : pre) live.addAll(p.in);
        }
        for (Node n : nodes) if (n.op.equals("DynamicQuantizeLinear")) {
            boolean used = false;
            for (String o : n.out) if (live.contains(o)) used = true;
            if (!used) n.dead = true;
        }
        // 2) QuantizeLinear → DequantizeLinear sobre activaciones (formato QDQ): se quitan
        Map<String, String> rename = new HashMap<>();
        for (Node q : nodes) {
            if (!q.op.equals("QuantizeLinear") || inits.containsKey(q.in.get(0))) continue;
            List<Node> cs = consumers.getOrDefault(q.out.get(0), new ArrayList<>());
            boolean allDq = !cs.isEmpty();
            for (Node c : cs) if (!c.op.equals("DequantizeLinear")) allDq = false;
            if (!allDq) continue;
            for (Node c : cs) { rename.put(c.out.get(0), q.in.get(0)); c.dead = true; }
            q.dead = true;
            changed++;
        }
        if (changed == 0) return 0;

        // escribir el grafo nuevo
        ByteArrayOutputStream g = new ByteArrayOutputStream(gTo - gFrom + 4096);
        int ni = 0;
        r = new OnnxPatch.Buf(b, gFrom);
        while (r.p < gTo) {
            int start = r.p;
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 1 && wt == 2) {
                int n = (int) r.varint();
                r.p += n;
                Node nd = nodes.get(ni++);
                List<Node> pre = insertBefore.get(nd);
                if (pre != null) for (Node p : pre) writeNode(g, p, rename);
                Node rep = replaceWith.get(nd);
                if (rep != null) writeNode(g, rep, rename);
                else if (!nd.dead) {
                    if (rename.isEmpty() || !touches(nd, rename)) g.write(nd.raw, 0, nd.raw.length);
                    else writeNodeRenamed(g, b, nd, rename);
                }
            } else if (f == 13 && wt == 2) {                   // value_info: opcional; se quita (había nombres que ya no existen)
                r.skip(wt);
            } else if (f == 12 && wt == 2 && !rename.isEmpty()) {  // salidas del grafo: por si una salida era un DequantizeLinear quitado
                r.skip(wt);
                g.write(b, start, r.p - start);
            } else { r.skip(wt); g.write(b, start, r.p - start); }
        }
        byte[] graph = g.toByteArray();
        try (java.io.OutputStream os = new java.io.BufferedOutputStream(new java.io.FileOutputStream(out), 1 << 16)) {
            OnnxPatch.Buf m = new OnnxPatch.Buf(b, 0);
            while (m.p < b.length) {
                int start = m.p;
                long key = m.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
                if (f == 7 && wt == 2) {
                    int n = (int) m.varint();
                    m.p += n;
                    OnnxPatch.putVarint(os, key); OnnxPatch.putVarint(os, graph.length); os.write(graph);
                } else { m.skip(wt); os.write(b, start, m.p - start); }
            }
        }
        return changed;
    }

    static boolean touches(Node n, Map<String, String> rename) { for (String i : n.in) if (rename.containsKey(i)) return true; return false; }

    static int[] findGraph(byte[] b) {
        OnnxPatch.Buf m = new OnnxPatch.Buf(b, 0);
        while (m.p < b.length) {
            long key = m.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 7 && wt == 2) { int n = (int) m.varint(); return new int[]{m.p, m.p + n}; }
            m.skip(wt);
        }
        return null;
    }

    static Node parseNode(byte[] b, int from, int to) {
        Node n = new Node();
        OnnxPatch.Buf r = new OnnxPatch.Buf(b, from);
        while (r.p < to) {
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (wt == 2 && (f == 1 || f == 2 || f == 3 || f == 4 || f == 7)) {
                int len = (int) r.varint();
                String s = new String(b, r.p, len, StandardCharsets.UTF_8);
                r.p += len;
                if (f == 1) n.in.add(s); else if (f == 2) n.out.add(s); else if (f == 3) n.name = s; else if (f == 4) n.op = s; else n.domain = s;
            } else r.skip(wt);
        }
        return n;
    }

    // ---------------- escritura de nodos ----------------
    static void str(ByteArrayOutputStream o, int field, String s) {
        byte[] x = s.getBytes(StandardCharsets.UTF_8);
        OnnxPatch.putVarint(o, (field << 3) | 2); OnnxPatch.putVarint(o, x.length); o.write(x, 0, x.length);
    }

    static byte[] attrInt(String name, long v) {
        ByteArrayOutputStream a = new ByteArrayOutputStream();
        str(a, 1, name);
        OnnxPatch.putVarint(a, 3 << 3); OnnxPatch.putVarint(a, v);      // i
        OnnxPatch.putVarint(a, 20 << 3); OnnxPatch.putVarint(a, 2);      // type = INT
        return a.toByteArray();
    }

    static void writeNode(ByteArrayOutputStream g, Node n, Map<String, String> rename) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (String i : n.in) str(o, 1, rename.getOrDefault(i, i));
        for (String x : n.out) str(o, 2, x);
        str(o, 3, n.name);
        str(o, 4, n.op);
        if (n.attrs != null) { OnnxPatch.putVarint(o, (5 << 3) | 2); OnnxPatch.putVarint(o, n.attrs.length); o.write(n.attrs, 0, n.attrs.length); }
        byte[] x = o.toByteArray();
        OnnxPatch.putVarint(g, (1 << 3) | 2); OnnxPatch.putVarint(g, x.length); g.write(x, 0, x.length);
    }

    /** Un nodo original con alguna entrada renombrada (el resto de campos, tal cual). */
    static void writeNodeRenamed(ByteArrayOutputStream g, byte[] all, Node n, Map<String, String> rename) {
        byte[] b = n.raw;
        OnnxPatch.Buf r = new OnnxPatch.Buf(b, 0);
        r.varint();
        int len = (int) r.varint(), from = r.p, to = from + len;
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        while (r.p < to) {
            int start = r.p;
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 1 && wt == 2) {
                int l = (int) r.varint();
                String s = new String(b, r.p, l, StandardCharsets.UTF_8);
                r.p += l;
                str(o, 1, rename.getOrDefault(s, s));
            } else { r.skip(wt); o.write(b, start, r.p - start); }
        }
        byte[] x = o.toByteArray();
        OnnxPatch.putVarint(g, (1 << 3) | 2); OnnxPatch.putVarint(g, x.length); g.write(x, 0, x.length);
    }
}
