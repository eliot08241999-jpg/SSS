package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.View;

import java.util.Random;

/**
 * v1.7 · TIEMPO REAL EN EL FONDO: una capa transparente encima de la escena de Chloe con el tiempo que hace de verdad
 * donde estás: lluvia, tormenta con relámpagos, nieve, niebla, nubes, viento, calor (aire que tiembla) y frío (escarcha).
 * Por encima, un tono suave según la estación (más luminoso en verano, más frío en invierno).
 * No toca los efectos que ya tenía la escena: solo se suma encima. Se dibuja ~30 veces por segundo y se para fuera de pantalla.
 */
public class WeatherFx extends View {
    int kind = -1;               // Weather.CLEAR…STORM, -1 = nada
    float intensity = 0.6f;      // 0..1
    double wind, temp = 18;
    boolean day = true;
    final Random rnd = new Random();
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    float[] px = new float[0], py = new float[0], pv = new float[0], ps = new float[0];
    float flash;                 // relámpago (0..1)
    long lastT;
    boolean running;

    public WeatherFx(Context c) {
        super(c);
        setClickable(false);
        setFocusable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    /** Pone el tiempo de verdad (desde el hilo principal). */
    public void set(Weather.Fc f) {
        if (f == null) { kind = -1; invalidate(); return; }
        kind = Weather.kind(f.code);
        wind = f.wind;
        temp = f.temp;
        day = f.day;
        // intensidad: lluvia que cae ahora o el tipo de código (61 débil … 65 fuerte; 80-82 chubascos)
        int c = f.code;
        intensity = c == 61 || c == 51 || c == 71 || c == 80 ? 0.45f : c == 63 || c == 53 || c == 73 || c == 81 ? 0.7f : c >= 65 && c <= 67 || c == 75 || c == 82 || c >= 95 ? 1f : 0.6f;
        if (f.precip > 3) intensity = 1f;
        int n = kind == Weather.RAIN || kind == Weather.STORM ? (int) (90 + 160 * intensity) : kind == Weather.DRIZZLE ? 70
                : kind == Weather.SNOW ? (int) (60 + 90 * intensity) : kind == Weather.CLOUDS || kind == Weather.FOG ? 7 : wind >= 25 ? 14 : 0;
        px = new float[n]; py = new float[n]; pv = new float[n]; ps = new float[n];
        for (int i = 0; i < n; i++) { px[i] = rnd.nextFloat(); py[i] = rnd.nextFloat(); pv[i] = 0.6f + rnd.nextFloat() * 0.8f; ps[i] = rnd.nextFloat(); }
        invalidate();
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); running = true; lastT = 0; postInvalidateOnAnimation(); }
    @Override protected void onDetachedFromWindow() { running = false; super.onDetachedFromWindow(); }

    @Override protected void onDraw(Canvas cv) {
        if (kind < 0 && temp < 30 && temp > 2) { seasonTint(cv); return; }
        long now = android.os.SystemClock.uptimeMillis();
        float dt = lastT == 0 ? 0.016f : Math.min(0.05f, (now - lastT) / 1000f);
        lastT = now;
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) { if (running) postInvalidateOnAnimation(); return; }
        seasonTint(cv);
        float slant = (float) Math.min(0.45, wind / 90.0);      // cuánto se inclina la lluvia/nieve con el viento
        switch (kind) {
            case Weather.RAIN: case Weather.STORM: case Weather.DRIZZLE: rain(cv, w, h, dt, slant); break;
            case Weather.SNOW: snow(cv, w, h, dt, slant, now); break;
            case Weather.FOG: fog(cv, w, h, dt, now); break;
            case Weather.CLOUDS: clouds(cv, w, h, dt, 0.10f); break;
            default: if (px.length > 0) streaks(cv, w, h, dt);
        }
        if (kind == Weather.STORM) storm(cv, w, h, dt);
        if (temp >= 30) heat(cv, w, h, now);
        if (temp <= 2) frost(cv, w, h);
        if (running && (px.length > 0 || kind == Weather.STORM || temp >= 30)) postInvalidateOnAnimation();   // si no hay nada que mover, no gasta
    }

    /** Un tono suave según la estación y la hora. */
    void seasonTint(Canvas cv) {
        int m = java.util.Calendar.getInstance().get(java.util.Calendar.MONTH);   // 0 = enero
        int col;
        if (m >= 5 && m <= 7) col = Color.argb(day ? 22 : 10, 255, 220, 140);       // verano: más luz cálida
        else if (m == 11 || m <= 1) col = Color.argb(day ? 26 : 16, 150, 190, 255); // invierno: frío azulado
        else if (m >= 8 && m <= 10) col = Color.argb(18, 255, 170, 90);             // otoño: ámbar
        else col = Color.argb(14, 170, 255, 190);                                    // primavera: verde suave
        if (kind == Weather.RAIN || kind == Weather.STORM || kind == Weather.FOG) col = Color.argb(48, 40, 50, 70);   // día gris
        cv.drawColor(col);
    }

    void rain(Canvas cv, int w, int h, float dt, float slant) {
        boolean drizzle = kind == Weather.DRIZZLE;
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < px.length; i++) {
            float sp = (drizzle ? 0.9f : 1.6f + intensity) * pv[i];
            py[i] += sp * dt;
            px[i] += slant * sp * dt;
            if (py[i] > 1.05f) { py[i] = -0.05f; px[i] = rnd.nextFloat() * 1.2f - 0.2f; }
            if (px[i] > 1.05f) px[i] -= 1.1f;
            float len = (drizzle ? 0.012f : 0.03f + 0.02f * intensity) * h * pv[i];
            float x = px[i] * w, y = py[i] * h;
            p.setColor(Color.argb((int) (90 + 70 * ps[i]), 190, 210, 255));
            p.setStrokeWidth(drizzle ? 1.2f : 1.6f + ps[i]);
            cv.drawLine(x, y, x - slant * len, y - len, p);
        }
    }

    void snow(Canvas cv, int w, int h, float dt, float slant, long now) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < px.length; i++) {
            py[i] += 0.07f * pv[i] * dt * (1 + intensity);
            px[i] += (slant * 0.12f + (float) Math.sin(now / 900.0 + i) * 0.012f) * dt;
            if (py[i] > 1.03f) { py[i] = -0.03f; px[i] = rnd.nextFloat(); }
            if (px[i] > 1.03f) px[i] -= 1.06f; else if (px[i] < -0.03f) px[i] += 1.06f;
            p.setColor(Color.argb((int) (150 + 90 * ps[i]), 255, 255, 255));
            cv.drawCircle(px[i] * w, py[i] * h, 1.5f + 3.2f * ps[i] * pv[i], p);
        }
    }

    void clouds(Canvas cv, int w, int h, float dt, float alpha) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < px.length; i++) {
            px[i] += (0.006f + (float) wind / 4000f) * pv[i] * dt;
            if (px[i] > 1.4f) px[i] = -0.4f;
            float cx = px[i] * w, cy = (0.05f + py[i] * 0.3f) * h, r = (0.18f + ps[i] * 0.16f) * w;
            p.setColor(Color.argb((int) (255 * alpha * (0.6f + ps[i] * 0.4f)), day ? 235 : 160, day ? 240 : 170, day ? 250 : 190));
            cv.drawCircle(cx, cy, r * 0.6f, p);
            cv.drawCircle(cx + r * 0.5f, cy + r * 0.08f, r * 0.45f, p);
            cv.drawCircle(cx - r * 0.5f, cy + r * 0.12f, r * 0.4f, p);
        }
    }

    void fog(Canvas cv, int w, int h, float dt, long now) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < px.length; i++) {
            px[i] += 0.01f * pv[i] * dt;
            if (px[i] > 1.5f) px[i] = -0.5f;
            float y = (0.2f + py[i] * 0.8f) * h;
            p.setShader(new LinearGradient(0, y - h * 0.12f, 0, y + h * 0.12f, new int[]{0, Color.argb(70, 210, 215, 225), 0}, null, Shader.TileMode.CLAMP));
            cv.drawRect(-w * 0.2f + px[i] * w * 0.3f, y - h * 0.12f, w * 1.2f, y + h * 0.12f, p);
        }
        p.setShader(null);
    }

    /** Viento sin lluvia: líneas rápidas y finas. */
    void streaks(Canvas cv, int w, int h, float dt) {
        p.setStrokeWidth(1.4f);
        for (int i = 0; i < px.length; i++) {
            px[i] += (float) (wind / 40.0) * pv[i] * dt;
            if (px[i] > 1.2f) { px[i] = -0.2f; py[i] = rnd.nextFloat(); }
            float x = px[i] * w, y = py[i] * h * 0.9f, len = w * 0.08f * pv[i];
            p.setColor(Color.argb(60, 255, 255, 255));
            cv.drawLine(x, y, x - len, y + len * 0.04f, p);
        }
    }

    void storm(Canvas cv, int w, int h, float dt) {
        if (flash <= 0 && rnd.nextFloat() < dt * 0.12f) flash = 1f;          // un relámpago cada ~8 s
        if (flash > 0) {
            cv.drawColor(Color.argb((int) (150 * flash * (rnd.nextFloat() < 0.3f ? 0.4f : 1f)), 230, 235, 255));
            flash -= dt * 2.5f;
        }
    }

    /** Calor: el aire tiembla (bandas suaves que suben). */
    void heat(Canvas cv, int w, int h, long now) {
        p.setStyle(Paint.Style.FILL);
        for (int k = 0; k < 5; k++) {
            float y = (float) (h * (1 - ((now / 6000.0 + k * 0.2) % 1.0)));
            p.setColor(Color.argb(14, 255, 200, 120));
            cv.drawRect(0, y, w, y + h * 0.06f, p);
        }
    }

    /** Frío: escarcha en las esquinas. */
    void frost(Canvas cv, int w, int h) {
        p.setStyle(Paint.Style.FILL);
        float r = Math.min(w, h) * 0.45f;
        for (float[] c : new float[][]{{0, 0}, {w, 0}, {0, h}, {w, h}}) {
            p.setShader(new android.graphics.RadialGradient(c[0], c[1], r, Color.argb(70, 220, 240, 255), 0, Shader.TileMode.CLAMP));
            cv.drawCircle(c[0], c[1], r, p);
        }
        p.setShader(null);
    }
}
