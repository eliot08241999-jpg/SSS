package com.aplauso.encuentra;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * v1.4.7 · Pantalla de LIVE CON CHLOE: ella grande, qué está haciendo (escuchando, pensando, hablando),
 * lo último que oyó y dijo, y abajo SILENCIAR · COLGAR · CHAT. Puedes salir: la llamada sigue
 * (por ejemplo, mientras juegas) y la cuelgas desde la notificación.
 */
public class LiveActivity extends NeonActivity {
    static final int REQ_MIC = 91;
    Avatar av;
    WeatherFx fx;
    TextView status, timer, heard, said, muteB;
    int lastState = -1;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dpi(14), dpi(10), dpi(14), dpi(16));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(circleButton("⌄", v -> finish()), new LinearLayout.LayoutParams(dpi(42), dpi(42)));
        TextView t = neonText("  " + L.t("Live con Chloe"), 19);
        top.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
TextView lg = button("", null);
        Runnable lgl = () -> { String x = p.getString("listen_lang", "auto"); lg.setText("🌐 " + ("auto".equals(x) ? "AUTO" : x.toUpperCase(java.util.Locale.ROOT))); };
        lg.setOnClickListener(v -> {
            String[] cyc = {"auto", "es", "it", "en"};
            int i = java.util.Arrays.asList(cyc).indexOf(p.getString("listen_lang", "auto"));
            p.edit().putString("listen_lang", cyc[(i + 1) % cyc.length]).apply();
            lgl.run();
            toast(L.t("Idioma en el que te escucho. AUTO = el de la conversación."));
        });
        lgl.run();
        lg.setPadding(dpi(10), dpi(8), dpi(10), dpi(8));
        LinearLayout.LayoutParams lgp = new LinearLayout.LayoutParams(-2, -2); lgp.rightMargin = dpi(6);
        top.addView(lg, lgp);
        timer = text("0:00", 15);
        timer.setTextColor(Color.rgb(170, 180, 200));
        top.addView(timer);
        root.addView(top);

        av = Chloe3DView.make(this);
        av.setOnPoke(line -> { if (LiveService.state == LiveService.SPEAKING) LiveService.interrupt(this); });
        if (av instanceof Chloe3DView) root.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1));   // v1.6: escena 3D detrás
        else if (Weather.on(this)) {                       // v1.7: el tiempo de verdad encima de su escena
            fx = new WeatherFx(this);
            android.widget.FrameLayout af = new android.widget.FrameLayout(this);
            af.addView(av.view(), new android.widget.FrameLayout.LayoutParams(-1, -1));
            af.addView(fx, new android.widget.FrameLayout.LayoutParams(-1, -1));
            root.addView(af, new LinearLayout.LayoutParams(-1, 0, 1));
        } else root.addView(av.view(), new LinearLayout.LayoutParams(-1, 0, 1));

        status = neonText("", 20);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));
        heard = text("", 14);
        heard.setGravity(Gravity.CENTER);
        heard.setTextColor(Color.rgb(170, 180, 200));
        heard.setMaxLines(3);
        root.addView(heard, gapBelow(4));
        said = text("", 15);
        said.setGravity(Gravity.CENTER);
        said.setMaxLines(4);
        root.addView(said, gapBelow(12));

        TextView hint = text(L.t("Habla cuando quieras. Toca a Chloe para interrumpirla. Puedes salir de la app: la llamada sigue."), 11);
        hint.setGravity(Gravity.CENTER);
        hint.setTextColor(Color.rgb(130, 140, 160));
        root.addView(hint, gapBelow(10));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        muteB = button("🎤", v -> LiveService.toggleMute(this));
        TextView hang = button("📞 " + L.t("COLGAR"), v -> { LiveService.hangUp(this); finish(); });
        hang.setTextColor(Color.rgb(255, 110, 120));
        TextView chat = button("💬", v -> startActivity(new Intent(this, ChloeChatActivity.class)));
        LinearLayout.LayoutParams sq = new LinearLayout.LayoutParams(dpi(64), -2); sq.rightMargin = dpi(10);
        row.addView(muteB, sq);
        LinearLayout.LayoutParams wide = new LinearLayout.LayoutParams(0, -2, 1); wide.rightMargin = dpi(10);
        row.addView(hang, wide);
        row.addView(chat, new LinearLayout.LayoutParams(dpi(64), -2));
        root.addView(row);

        android.widget.FrameLayout fr = makeRoot(root);
        if (av instanceof Chloe3DView) {
            fr.addView(av.view(), 2, new android.widget.FrameLayout.LayoutParams(-1, -1));
            if (Weather.on(this)) { fx = new WeatherFx(this); fr.addView(fx, 3, new android.widget.FrameLayout.LayoutParams(-1, -1)); }
        }
        setContentView(fr);
        if (fx != null) new Thread(() -> {
            Weather.Fc f;
            try { f = Weather.here(this); } catch (Exception e) { f = null; }
            final Weather.Fc ff = f;
            runOnUiThread(() -> { if (fx != null) fx.set(ff); });
        }, "tiempo").start();

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        else if (!LiveService.on()) LiveService.start(this);
        h.post(tick);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] p, int[] r) {
        super.onRequestPermissionsResult(req, p, r);
        if (req == REQ_MIC) {
            if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) LiveService.start(this);
            else { toast(L.t("Necesito el micrófono para hablar contigo.")); finish(); }
        }
    }

    final Runnable tick = new Runnable() {
        public void run() {
            if (isFinishing()) return;
            int s = LiveService.state;
            if (s != lastState) {
                lastState = s;
                av.setState(s == LiveService.LISTENING ? AvatarArt.LISTEN : s == LiveService.THINKING ? AvatarArt.THINK : AvatarArt.IDLE);
                if (s == LiveService.OFF && LiveService.startedAt > 0) { status.setText(L.t("Llamada terminada")); }
            }
            status.setText(s == LiveService.LISTENING ? L.t("Escuchando…") : s == LiveService.THINKING ? L.t("Pensando…")
                    : s == LiveService.SPEAKING ? L.t("Hablando…") : s == LiveService.MUTED ? L.t("Micrófono silenciado") : L.t("Llamada terminada"));
            String hp = LiveService.partial.isEmpty() ? LiveService.heard : LiveService.partial;
            heard.setText(hp.isEmpty() ? "" : "🗣 " + hp);
            said.setText(LiveService.said);
            muteB.setText(LiveService.muted ? "🔇" : "🎤");
            if (LiveService.on()) {
                long sec = (SystemClock.elapsedRealtime() - LiveService.startedAt) / 1000;
                timer.setText(sec / 60 + ":" + String.format(java.util.Locale.ROOT, "%02d", sec % 60));
            }
            h.postDelayed(this, 200);
        }
    };

    @Override protected void onDestroy() { h.removeCallbacks(tick); super.onDestroy(); }
}
