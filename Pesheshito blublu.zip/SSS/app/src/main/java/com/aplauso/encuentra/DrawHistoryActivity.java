package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * v1.7.4 · HISTORIAL DE DIBUJOS: lo que has dibujado en las últimas 24 h. 💾 a la galería, 📌 fijar para que no se borre,
 * 🗑 borrar, 🔁 volver a usar la descripción. Lo que no guardes ni fijes desaparece a las 24 h.
 */
public class DrawHistoryActivity extends NeonActivity {
    LinearLayout grid;
    TextView head;
    static final String EXTRA_REUSE = "reuse_prompt", EXTRA_REUSE_SEED = "reuse_seed";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🕘 HISTORIAL");
        head = text("", 13);
        head.setTextColor(Color.rgb(170, 180, 200));
        col.addView(head, gapBelow(10));
        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        col.addView(grid);
    }

    @Override protected void onResume() {
        super.onResume();
        DrawHistory.reconcile(this);                       // v1.7.6: lo que Android cortó queda «a medias» con ↻
        fill();
        h.postDelayed(tickR, 2000);
    }

    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tickR); }

    String sig = "";
    /** Mientras haya algo dibujándose o en cola, se actualiza solo. */
    final Runnable tickR = new Runnable() { public void run() {
        StringBuilder b = new StringBuilder();
        for (DrawHistory.Item it : DrawHistory.all(DrawHistoryActivity.this)) b.append(it.id).append(it.status).append(DrawService.current == it ? DrawService.percent / 5 : 0);
        if (!b.toString().equals(sig)) fill();
        h.postDelayed(this, 2000);
    } };

    void fill() {
        grid.removeAllViews();
        List<DrawHistory.Item> l = DrawHistory.all(this);
        StringBuilder sb = new StringBuilder();
        for (DrawHistory.Item it : l) sb.append(it.id).append(it.status).append(DrawService.current == it ? DrawService.percent / 5 : 0);
        sig = sb.toString();
        int broken = DrawHistory.count(this, DrawHistory.FAILED) + DrawHistory.count(this, DrawHistory.STOPPED);
        if (broken > 0 && !DrawService.running) grid.addView(button("↻ " + L.t("REINTENTAR LO QUE QUEDÓ A MEDIAS") + " (" + broken + ")", v -> {
            DrawHistory.retryAll(this); DrawService.kick(this); fill();
        }), gapBelow(8));
        head.setText(L.t("Tus dibujos se guardan aquí 24 horas. Si no los guardas en la galería (💾) ni los fijas (📌), se borran solos. Toca uno para verlo."));
        if (l.isEmpty()) { grid.addView(text(L.t("Aún no hay dibujos en las últimas 24 horas."), 14)); return; }
        int cols = 3, size = (getResources().getDisplayMetrics().widthPixels - dpi(36) - dpi(6) * (cols - 1)) / cols;
        LinearLayout row = null;
        for (int i = 0; i < l.size(); i++) {
            if (i % cols == 0) { row = new LinearLayout(this); grid.addView(row, gapBelow(6)); }
            DrawHistory.Item it = l.get(i);
            FrameLayout cell = new FrameLayout(this);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(frame(10));
            iv.setPadding(dpi(2), dpi(2), dpi(2), dpi(2));
            cell.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            TextView tag = new TextView(this);
            tag.setText(DrawHistory.leftText(this, it) + (it.saved ? " 💾" : ""));
            if (!it.done()) {                                  // aún sin imagen: tarjeta con su estado y lo que se pidió
                TextView ph = new TextView(this);
                ph.setText(it.prompt.length() > 60 ? it.prompt.substring(0, 60) + "…" : it.prompt);
                ph.setTextSize(10);
                ph.setTextColor(Color.rgb(160, 170, 195));
                ph.setPadding(dpi(6), dpi(6), dpi(6), dpi(6));
                cell.addView(ph, new FrameLayout.LayoutParams(-1, -1));
            }
            tag.setTextSize(11);
            tag.setTextColor(Color.WHITE);
            tag.setBackgroundColor(Color.argb(150, 0, 0, 0));
            tag.setPadding(dpi(5), dpi(2), dpi(5), dpi(2));
            cell.addView(tag, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START));
            cell.setOnClickListener(v -> open(it));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            if (i % cols < cols - 1) lp.rightMargin = dpi(6);
            row.addView(cell, lp);
            new Thread(() -> { Bitmap bm = DrawHistory.load(this, it, size); runOnUiThread(() -> iv.setImageBitmap(bm)); }).start();
        }
    }

    void open(DrawHistory.Item it) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dpi(12), dpi(12), dpi(12), dpi(4));
        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setImageBitmap(DrawHistory.load(this, it, 1024));
        box.addView(iv, new LinearLayout.LayoutParams(-1, dpi(320)));
        TextView pr = text(it.prompt, 12);
        pr.setTextIsSelectable(true);
        pr.setPadding(0, dpi(8), 0, dpi(4));
        box.addView(pr);
        TextView meta = text(L.t("Semilla") + " " + it.seed + " · " + DrawHistory.leftText(this, it) + (it.error.isEmpty() ? "" : "\n" + it.error), 11);
        meta.setTextColor(Color.GRAY);
        box.addView(meta);
        android.app.AlertDialog[] dlg = new android.app.AlertDialog[1];
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this);
        if (!it.done()) {                                 // v1.7.6: a medias / en cola
            boolean broken = DrawHistory.FAILED.equals(it.status) || DrawHistory.STOPPED.equals(it.status);
            if (broken) r1.addView(button("↻ " + L.t("REINTENTAR"), v -> { DrawHistory.retry(this, it); DrawService.kick(this); dlg[0].dismiss(); fill(); }), new LinearLayout.LayoutParams(0, -2, 1));
        } else
        r1.addView(button("💾 " + L.t("GALERÍA"), v -> { toast(DrawHistory.toGallery(this, it) ? L.t("Guardada en Imágenes/SSS+") : L.t("No se pudo guardar")); dlg[0].dismiss(); fill(); }), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(button(it.pinned ? "📌 " + L.t("SOLTAR") : "📌 " + L.t("FIJAR"), v -> {
            DrawHistory.pin(this, it, !it.pinned);
            toast(it.pinned ? L.t("Fijada: no se borrará.") : L.t("Ya no está fijada: se borrará a las 24 h."));
            dlg[0].dismiss(); fill();
        }), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(button("🔁 " + L.t("REPETIR"), v -> {
            setResult(RESULT_OK, new Intent().putExtra(EXTRA_REUSE, it.prompt).putExtra(EXTRA_REUSE_SEED, it.seed));
            dlg[0].dismiss();
            finish();
        }), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(button("🗑 " + L.t("BORRAR"), v -> { DrawHistory.delete(this, it); dlg[0].dismiss(); fill(); }), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2); rl.topMargin = dpi(8);
        box.addView(r1, rl);
        box.addView(r2, new LinearLayout.LayoutParams(-1, -2));
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(box);
        dlg[0] = new android.app.AlertDialog.Builder(this).setView(sv).setNegativeButton(L.t("Cerrar"), null).show();
    }
}
