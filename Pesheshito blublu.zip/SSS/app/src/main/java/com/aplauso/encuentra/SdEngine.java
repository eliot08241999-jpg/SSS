package com.aplauso.encuentra;

import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;

import ai.onnxruntime.NodeInfo;
import ai.onnxruntime.OnnxJavaType;
import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OnnxValue;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;

import java.io.File;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.Random;

/**
 * v1.3 · ESTUDIO DE DIBUJO: Stable Diffusion 1.5 DENTRO del teléfono, sin internet y sin cupos.
 * Modelos int8 en formato ONNX (≈1,3 GB cada uno, de latentdivergence en Hugging Face, licencia CreativeML OpenRAIL-M)
 * que funcionan con ONNX Runtime en el procesador. Muestreador DPM++ 2M Karras (o LCM para el modelo rápido).
 * Bloquea: llamar desde un hilo.
 */
public class SdEngine {
    // id, nombre, descripción, repositorio, ¿LCM?
    static final String[][] MODELS = {
            {"anything5", "Anime · Anything V5", "Estilo anime e ilustración (como YoDayo).", "latentdivergence/anything-v5-int8-onnx", "0"},
            {"dreamshaper8", "Todoterreno · DreamShaper 8", "Fantasía, retratos, paisajes: un poco de todo.", "latentdivergence/dreamshaper-8-int8-onnx", "0"},
            {"epicrealism", "Fotos · epiCRealism", "Imágenes que parecen fotos de verdad.", "latentdivergence/epicrealism-int8-onnx", "0"},
            {"lcm", "⚡ Rápido · LCM DreamShaper", "En 4-8 pasos: 4-5 veces más rápido, algo menos de detalle. No usa «lo que NO quieres».", "latentdivergence/lcm-dreamshaper-int8-onnx", "1"},
    };
    /** Archivos fijos de cada modelo. Los pesos grandes van aparte y su nombre se lee de dentro del .onnx (fase 2). */
    static final String[] FILES = {"unet/model.onnx", "text_encoder/model.onnx",
            "vae_decoder/model.onnx", "vae_encoder/model.onnx", "tokenizer/vocab.json", "tokenizer/merges.txt"};
    static final String[] GRAPHS = {"unet/model.onnx", "text_encoder/model.onnx", "vae_decoder/model.onnx", "vae_encoder/model.onnx"};
    static final String DEFAULT_NEG = "nsfw, lowres, bad anatomy, bad hands, extra fingers, missing fingers, text, watermark, signature, blurry, worst quality, low quality, jpeg artifacts, deformed";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static String[] model(String id) { for (String[] m : MODELS) if (m[0].equals(id)) return m; return MODELS[0]; }
    static File dir(Context c, String id) { return new File(c.getExternalFilesDir(null), "sd/" + id); }
    static boolean isLcm(String id) { return "1".equals(model(id)[4]); }

    /**
     * v1.3.1: los pesos de la UNet y del codificador de texto no van dentro del .onnx sino en archivos aparte
     * («model.onnx_data», «model.onnx.data» o varios). El .onnx dice cómo se llaman (campo «location»): los leemos de ahí.
     */
    static java.util.List<String> externals(File onnx) {
        java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
        if (!onnx.exists() || onnx.length() > 400_000_000L) return new java.util.ArrayList<>(out);
        try {
            byte[] b = java.nio.file.Files.readAllBytes(onnx.toPath());
            byte[] key = "location".getBytes(java.nio.charset.StandardCharsets.US_ASCII);
            outer:
            for (int i = 2; i + key.length + 2 < b.length; i++) {
                if (b[i - 2] != 0x0a || b[i - 1] != 0x08) continue;
                for (int k = 0; k < key.length; k++) if (b[i + k] != key[k]) continue outer;
                int p = i + key.length;
                if (b[p] != 0x12) continue;
                p++;
                int len = 0, shift = 0;
                while (p < b.length) { int v = b[p++] & 0xff; len |= (v & 0x7f) << shift; if ((v & 0x80) == 0) break; shift += 7; }
                if (len <= 0 || len > 300 || p + len > b.length) continue;
                String name = new String(b, p, len, java.nio.charset.StandardCharsets.UTF_8);
                if (name.contains("..") || name.startsWith("/") || !name.matches("[\\w.\\-/ ]+")) continue;
                out.add(name);
            }
        } catch (Throwable ignored) {}
        return new java.util.ArrayList<>(out);
    }

    /** Todo lo que hace falta: los archivos fijos y los pesos aparte que piden los .onnx ya bajados. */
    static java.util.List<String> needed(Context c, String id) {
        java.util.List<String> all = new java.util.ArrayList<>(java.util.Arrays.asList(FILES));
        File d = dir(c, id);
        for (String g : GRAPHS) {
            String folder = g.substring(0, g.indexOf('/') + 1);
            for (String x : externals(new File(d, g))) if (!all.contains(folder + x)) all.add(folder + x);
        }
        return all;
    }

    static boolean ready(Context c, String id) {
        if (status(c, id) != null) return false;
        return filesReady(c, id);
    }

    /** ¿Están todos los archivos? (sin mirar si hay una descarga en marcha) */
    static boolean filesReady(Context c, String id) {
        String ok = prefs(c).getString("sd_ok_" + id, "");
        File d = dir(c, id);
        if (!ok.isEmpty()) {                                  // comprobado antes: basta con mirar que siguen ahí
            for (String f : ok.split("\\|")) if (!new File(d, f).exists()) { prefs(c).edit().remove("sd_ok_" + id).apply(); return false; }
            return true;
        }
        java.util.List<String> need = needed(c, id);
        long size = 0;
        for (String f : need) { File x = new File(d, f); if (!x.exists() || x.length() == 0) return false; if (f.startsWith("unet/")) size += x.length(); }
        if (size < 300_000_000L) return false;                // la UNet sola pesa cientos de MB
        prefs(c).edit().putString("sd_ok_" + id, String.join("|", need)).apply();
        return true;
    }

    // ---------------- descarga rápida (v1.3.2: varias conexiones a la vez, ver FastDownload) ----------------
    static void startDownload(Context c, String id) {
        legacyCancel(c, id);
        prefs(c).edit().remove("sd_ok_" + id).apply();
        FastDownload.start(c, id);
    }

    static void cancel(Context c, String id) {
        legacyCancel(c, id);
        if (FastDownload.running(id)) FastDownload.stop();
    }

    /** Las descargas de la v1.3/1.3.1 (gestor de Android, lentas): se cancelan. */
    static void legacyCancel(Context c, String id) {
        String s = prefs(c).getString("sd_dl_" + id, "");
        prefs(c).edit().remove("sd_dl_" + id).remove("sd_files_" + id).apply();
        if (s.isEmpty()) return;
        DownloadManager dm = c.getSystemService(DownloadManager.class);
        for (String x : s.split(",")) try { dm.remove(Long.parseLong(x)); } catch (Exception ignored) {}
    }

    static void delete(Context c, String id) {
        cancel(c, id);
        prefs(c).edit().remove("sd_ok_" + id).apply();
        if (id.equals(loadedId)) unload();
        Wake.deleteAll(dir(c, id));
    }

    /** {estado, MB bajados, MB totales} mientras se descarga; null si no hay descarga en marcha. */
    static long[] status(Context c, String id) {
        if (!prefs(c).getString("sd_dl_" + id, "").isEmpty()) legacyCancel(c, id);
        if (FastDownload.running(id)) return new long[]{DownloadManager.STATUS_RUNNING, FastDownload.got.get() >> 20, FastDownload.total >> 20};
        if (id.equals(FastDownload.lastId) && !FastDownload.error.isEmpty()) {
            if (filesReady(c, id)) { FastDownload.error = ""; return null; }
            return new long[]{DownloadManager.STATUS_FAILED, 0, 0};
        }
        return null;
    }

    static String progress(Context c, String id) {
        long[] st = status(c, id);
        if (st == null) {
            if (ready(c, id)) return L.t("✓ Descargado");
            return new File(dir(c, id), "unet/model.onnx").exists() ? L.t("Faltan archivos: pulsa DESCARGAR para completarlo (no empieza de cero).")
                    : L.t("Sin descargar · ≈1,3 GB");
        }
        if (st[0] == DownloadManager.STATUS_FAILED)
            return L.t("La descarga falló") + " (" + FastDownload.error + "). " + L.t("Pulsa DESCARGAR: sigue donde se quedó.");
        if (st[2] <= 0) return L.t("Preparando la descarga…");
        return L.t("Descargando…") + " " + st[1] + " / " + st[2] + " MB · " + String.format(java.util.Locale.ROOT, "%.1f MB/s", FastDownload.speed());
    }

    // ---------------- motor ----------------
    static OrtEnvironment env;
    static OrtSession textEnc, unet, vaeDec, vaeEnc;
    static SdTokenizer tok;
    static String loadedId;

    static synchronized void unload() {
        for (OrtSession s : new OrtSession[]{textEnc, unet, vaeDec, vaeEnc}) if (s != null) try { s.close(); } catch (Exception ignored) {}
        textEnc = unet = vaeDec = vaeEnc = null;
        tok = null;
        loadedId = null;
    }

    static OrtSession open(File f) throws Exception { return open(f, false); }

    /** «basic»: sin las fusiones que volverían a comprimir lo que va pasando por dentro (para el lector de texto en coma flotante). */
    static OrtSession open(File f, boolean basic) throws Exception {
        OrtSession.SessionOptions o = new OrtSession.SessionOptions();
        o.setIntraOpNumThreads(threads);
        o.setOptimizationLevel(basic ? OrtSession.SessionOptions.OptLevel.BASIC_OPT : OrtSession.SessionOptions.OptLevel.ALL_OPT);
        return env.createSession(f.getAbsolutePath(), o);
    }

    // ---------------- v1.7: modo fresco ----------------
    static int threads = defaultThreads();
    static int defaultThreads() { int cores = Runtime.getRuntime().availableProcessors(); return Math.max(2, Math.min(6, cores - 2)); }
    /** Modo fresco: menos núcleos y pausas cuando el teléfono se calienta. */
    static boolean cool(Context c) { return prefs(c).getBoolean("sd_cool", false); }
    static int threadsFor(Context c) { return cool(c) ? 2 : defaultThreads(); }
    /** v1.7: lector de texto preciso (en coma flotante). Se puede apagar para comparar. */
    static boolean preciseText(Context c) { return prefs(c).getBoolean("sd_te_float", true); }
    static volatile String textMode = "";
    static int maxChunks = 1;

    static synchronized void load(Context c, String id, Progress p) throws Exception {
        boolean precise = preciseText(c);
        int th = threadsFor(c);
        if (id.equals(loadedId) && unet != null && th == threads && textMode.equals(precise ? "f" : "q")) return;
        unload();
        threads = th;
        KokoroVoice.unload();                                   // v1.5: dibujar necesita toda la memoria
        if (env == null) env = OrtEnvironment.getEnvironment();
        File d = dir(c, id);
        p.at(-1, L.t("Cargando el modelo (la primera vez tarda un poco)…"), null);
        tok = new SdTokenizer(new File(d, "tokenizer/vocab.json"), new File(d, "tokenizer/merges.txt"));
        // v1.3.3: los pesos int8 de las convoluciones → uint8 (lo que sabe hacer ONNX Runtime). Solo la primera vez.
        for (String g : GRAPHS) {
            File f = new File(d, g);
            if (!f.exists() || new File(f.getParentFile(), ".u8ok").exists()) continue;
            p.at(-1, L.t("Preparando el modelo para tu móvil (solo la primera vez, puede tardar un minuto)…"), null);
            OnnxPatch.fixConvInteger(f);
        }
        // v1.4: personajes importados → tabla de palabras del codificador de texto
        if (!SdChars.all(c).isEmpty() || new File(d, "text_encoder/.chars").exists()) {
            p.at(-1, L.t("Preparando tus personajes…"), null);
            SdChars.apply(c, new File(d, "text_encoder/model.onnx"));
        }
        tok.chars = SdChars.tokens(c);
        File te = new File(d, "text_encoder/model.onnx");
        textEnc = null;
        textMode = "q";
        if (precise) {                                            // v1.7: el lector de texto sin comprimir (lee todo el prompt)
            try {
                File tf = new File(d, "text_encoder/model_f.onnx"), mk = new File(d, "text_encoder/.f_ok");
                String want = te.length() + ":" + te.lastModified() + ":v1";
                String have = mk.exists() ? new String(java.nio.file.Files.readAllBytes(mk.toPath()), java.nio.charset.StandardCharsets.UTF_8) : "";
                if (!have.startsWith(want)) {
                    p.at(-1, L.t("Preparando el lector de texto preciso (solo la primera vez)…"), null);
                    tf.delete();
                    int n = OnnxFloat.convert(te, tf);
                    java.nio.file.Files.write(mk.toPath(), (want + (n == 0 ? ":none" : ":" + n)).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    have = want + (n == 0 ? ":none" : ":" + n);
                }
                if (!have.endsWith(":none") && tf.exists()) { textEnc = open(tf, true); textMode = "f"; }
            } catch (Throwable e) {
                SssApp.note(c, "lector de texto preciso", e);
                textEnc = null;
            }
        }
        if (textEnc == null) textEnc = open(te);
        if (!precise) textMode = "q";
        else if (textMode.equals("q")) textMode = "q!";           // pedido pero no se pudo: se usa el de siempre
        unet = open(new File(d, "unet/model.onnx"));
        // v1.7: ¿la UNet acepta más de 77 fichas? (casi todas; si no, se queda con el primer trozo)
        long[] es = shapeOf(input(unet, "encoder_hidden_states"));
        maxChunks = es.length >= 2 && es[1] == 77 ? 1 : 4;
        vaeDec = open(new File(d, "vae_decoder/model.onnx"));
        loadedId = id;
    }

    interface Progress { void at(int step, String msg, Bitmap preview); }

    static final class Job {
        String model = "anything5", prompt = "", negative = DEFAULT_NEG;
        int width = 512, height = 512, steps = 20;
        float cfg = 7f, strength = 0.6f;
        long seed = -1;
        Bitmap init;               // img2img: la imagen de partida (o null)
        volatile boolean cancel;
        File ckpt;                 // v1.7.6: dónde apuntar cada paso (para seguir donde se quedó si se corta)
        int resumedAt;             // v1.7.6: en qué paso siguió (0 = desde el principio)
    }

    // ---------------- v1.7.6: puntos de guardado de cada paso ----------------
    static final int CK_MAGIC = 0x53534B31;   // «SSK1»

    static String ckKey(Job j, boolean lcm) {
        return j.model + "|" + j.prompt + "|" + j.negative + "|" + j.width + "x" + j.height + "|" + j.steps + "|" + j.cfg + "|" + j.strength + "|" + j.seed + "|" + lcm + "|" + (j.init != null);
    }

    /** Guarda el estado tras un paso: siguiente paso, la imagen latente, el paso anterior (DPM++) y el azar. */
    static void ckSave(Job j, boolean lcm, int next, float[] x, float[] old, Random rnd) {
        if (j.ckpt == null) return;
        File tmp = new File(j.ckpt.getPath() + ".tmp");
        try (java.io.DataOutputStream o = new java.io.DataOutputStream(new java.io.BufferedOutputStream(new java.io.FileOutputStream(tmp), 1 << 16))) {
            o.writeInt(CK_MAGIC);
            o.writeUTF(ckKey(j, lcm).length() > 20000 ? ckKey(j, lcm).substring(0, 20000) : ckKey(j, lcm));
            o.writeInt(next);
            o.writeInt(x.length);
            for (float v : x) o.writeFloat(v);
            o.writeBoolean(old != null);
            if (old != null) for (float v : old) o.writeFloat(v);
            java.io.ByteArrayOutputStream rb = new java.io.ByteArrayOutputStream();
            try (java.io.ObjectOutputStream oo = new java.io.ObjectOutputStream(rb)) { oo.writeObject(rnd); }
            byte[] r = rb.toByteArray();
            o.writeInt(r.length);
            o.write(r);
        } catch (Exception e) { tmp.delete(); return; }
        if (!tmp.renameTo(j.ckpt)) { j.ckpt.delete(); tmp.renameTo(j.ckpt); }
    }

    /** Lee el punto de guardado: {siguiente paso, x, old (o null), Random} o null si no hay o no es de este dibujo. */
    static Object[] ckLoad(Job j, boolean lcm, int n) {
        if (j.ckpt == null || !j.ckpt.exists()) return null;
        try (java.io.DataInputStream in = new java.io.DataInputStream(new java.io.BufferedInputStream(new java.io.FileInputStream(j.ckpt), 1 << 16))) {
            if (in.readInt() != CK_MAGIC) return null;
            String k = ckKey(j, lcm);
            if (!in.readUTF().equals(k.length() > 20000 ? k.substring(0, 20000) : k)) return null;
            int next = in.readInt();
            if (in.readInt() != n) return null;
            float[] x = new float[n];
            for (int i = 0; i < n; i++) x[i] = in.readFloat();
            float[] old = null;
            if (in.readBoolean()) { old = new float[n]; for (int i = 0; i < n; i++) old[i] = in.readFloat(); }
            byte[] r = new byte[in.readInt()];
            in.readFully(r);
            Random rnd;
            try (java.io.ObjectInputStream oi = new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(r))) { rnd = (Random) oi.readObject(); }
            return new Object[]{next, x, old, rnd};
        } catch (Exception e) { return null; }
    }

    // --- tabla de ruido de SD 1.5 (scaled_linear, 1000 pasos) ---
    static final double[] AC = new double[1000];
    static final double[] LOG_SIGMA = new double[1000];
    static {
        double a = Math.sqrt(0.00085), b = Math.sqrt(0.012), prod = 1;
        for (int i = 0; i < 1000; i++) {
            double beta = Math.pow(a + (b - a) * i / 999.0, 2);
            prod *= 1 - beta;
            AC[i] = prod;
            LOG_SIGMA[i] = Math.log(Math.sqrt((1 - prod) / prod));
        }
    }

    /** Sigmas de Karras (ρ = 7) para «n» pasos, terminando en 0. */
    static double[] karras(int n) {
        double smin = Math.exp(LOG_SIGMA[0]), smax = Math.exp(LOG_SIGMA[999]), rho = 7;
        double[] s = new double[n + 1];
        double minI = Math.pow(smin, 1 / rho), maxI = Math.pow(smax, 1 / rho);
        for (int i = 0; i < n; i++) {
            double r = n == 1 ? 0 : (double) i / (n - 1);
            s[i] = Math.pow(maxI + r * (minI - maxI), rho);
        }
        s[n] = 0;
        return s;
    }

    /** De sigma a paso de tiempo (con decimales), interpolando en log-sigma. */
    static double sigmaToT(double sigma) {
        double ls = Math.log(Math.max(sigma, 1e-10));
        if (ls <= LOG_SIGMA[0]) return 0;
        if (ls >= LOG_SIGMA[999]) return 999;
        int lo = 0, hi = 999;
        while (hi - lo > 1) { int mid = (lo + hi) >>> 1; if (LOG_SIGMA[mid] <= ls) lo = mid; else hi = mid; }
        return lo + (ls - LOG_SIGMA[lo]) / (LOG_SIGMA[hi] - LOG_SIGMA[lo]);
    }

    /** Pasos del muestreador LCM (sobre 50 pasos originales). */
    static int[] lcmTimesteps(int n, float strength) {
        int orig = 50, k = 1000 / orig;
        int count = Math.max(1, (int) (orig * strength));
        int[] origin = new int[count];
        for (int i = 0; i < count; i++) origin[i] = (i + 1) * k - 1;
        int[] rev = new int[count];
        for (int i = 0; i < count; i++) rev[i] = origin[count - 1 - i];
        n = Math.min(n, count);
        int[] ts = new int[n];
        for (int i = 0; i < n; i++) ts[i] = rev[(int) Math.floor((double) i * count / n)];
        return ts;
    }

    static NodeInfo input(OrtSession s, String... names) throws Exception {
        Map<String, NodeInfo> in = s.getInputInfo();
        for (String n : names) if (in.containsKey(n)) return in.get(n);
        return null;
    }

    static OnnxJavaType typeOf(NodeInfo n) {
        return n != null && n.getInfo() instanceof TensorInfo ? ((TensorInfo) n.getInfo()).type : OnnxJavaType.FLOAT;
    }

    static long[] shapeOf(NodeInfo n) {
        return n != null && n.getInfo() instanceof TensorInfo ? ((TensorInfo) n.getInfo()).getShape() : new long[0];
    }

    static float[] floats(OnnxValue v) {
        OnnxTensor t = (OnnxTensor) v;
        FloatBuffer fb = t.getFloatBuffer();
        if (fb != null) { float[] a = new float[fb.remaining()]; fb.get(a); return a; }
        java.nio.ShortBuffer sb = t.getShortBuffer();        // por si el modelo devuelve float16
        float[] a = new float[sb.remaining()];
        for (int i = 0; i < a.length; i++) a[i] = half(sb.get());
        return a;
    }

    static final int HID = 768;

    static float[] padTo(float[] a, int len, float[] empty) {
        float[] o = java.util.Arrays.copyOf(a, len);
        for (int at = a.length; at < len; at += empty.length) System.arraycopy(empty, 0, o, at, Math.min(empty.length, len - at));
        return o;
    }

    static float half(short h) {
        int s = (h >> 15) & 1, e = (h >> 10) & 0x1f, m = h & 0x3ff;
        float v = e == 0 ? (m / 1024f) * (float) Math.pow(2, -14) : e == 31 ? Float.POSITIVE_INFINITY : (1 + m / 1024f) * (float) Math.pow(2, e - 15);
        return s == 1 ? -v : v;
    }

    /** v1.7: texto → [1, 77·trozos, 768]: cada trozo de 75 fichas por separado y luego juntos. */
    static float[] encodeText(String text) throws Exception {
        List<int[]> chunks = tok.encodeChunks(text, maxChunks);
        List<float[]> ws = new java.util.ArrayList<>(tok.chunkWeights);
        float[][] parts = new float[chunks.size()][];
        int total = 0;
        for (int i = 0; i < chunks.size(); i++) { parts[i] = encodeChunk(chunks.get(i), ws.get(i)); total += parts[i].length; }
        float[] out = new float[total];
        int at = 0;
        for (float[] x : parts) { System.arraycopy(x, 0, out, at, x.length); at += x.length; }
        return out;
    }

    /** Un trozo de 77 fichas → [77, 768]. */
    static float[] encodeChunk(int[] ids, float[] tw) throws Exception {
        NodeInfo ni = input(textEnc, "input_ids");
        String name = ni != null ? ni.getName() : textEnc.getInputInfo().keySet().iterator().next();
        OnnxTensor t;
        if (typeOf(ni) == OnnxJavaType.INT64) {
            long[] l = new long[ids.length];
            for (int i = 0; i < ids.length; i++) l[i] = ids[i];
            t = OnnxTensor.createTensor(env, LongBuffer.wrap(l), new long[]{1, ids.length});
        } else t = OnnxTensor.createTensor(env, IntBuffer.wrap(ids), new long[]{1, ids.length});
        Map<String, OnnxTensor> m = new HashMap<>();
        m.put(name, t);
        try (OrtSession.Result r = textEnc.run(m)) {
            java.util.Optional<OnnxValue> h = r.get("last_hidden_state");
            return applyWeights(floats(h != null && h.isPresent() ? h.get() : r.get(0)), tw);
        } finally { t.close(); }
    }

    /** Pesos de las palabras (como A1111): multiplica cada ficha y luego devuelve la media a su nivel. */
    static float[] applyWeights(float[] h, float[] w) {
        boolean any = false;
        for (float x : w) if (x != 1f) { any = true; break; }
        if (!any) return h;
        int dim = h.length / w.length;
        double before = 0, after = 0;
        for (float x : h) before += x;
        for (int i = 0; i < w.length; i++) for (int k = 0; k < dim; k++) h[i * dim + k] *= w[i];
        for (float x : h) after += x;
        if (after != 0) { float sc = (float) (before / after); for (int i = 0; i < h.length; i++) h[i] *= sc; }
        return h;
    }

    /** Una pasada de la UNet: devuelve el ruido estimado (con CFG si hay texto negativo). */
    static float[] unetEps(float[] x, double t, float[] condUncond, int batch, int lh, int lw, float[] wEmb) throws Exception {
        int n = 4 * lh * lw;
        float[] in = new float[n * batch];
        for (int b = 0; b < batch; b++) System.arraycopy(x, 0, in, b * n, n);
        Map<String, OnnxTensor> m = new HashMap<>();
        java.util.List<OnnxTensor> all = new java.util.ArrayList<>();
        try {
            OnnxTensor s = OnnxTensor.createTensor(env, FloatBuffer.wrap(in), new long[]{batch, 4, lh, lw});
            all.add(s); m.put(name(unet, "sample"), s);
            NodeInfo tn = input(unet, "timestep", "timesteps", "t");
            long[] tsh = shapeOf(tn);
            long[] shape = tsh.length == 0 ? new long[0] : new long[]{tsh.length == 1 && tsh[0] == 1 ? 1 : batch};
            int cnt = shape.length == 0 ? 1 : (int) shape[0];
            OnnxTensor tt;
            if (typeOf(tn) == OnnxJavaType.INT64) { long[] v = new long[cnt]; java.util.Arrays.fill(v, Math.round(t)); tt = OnnxTensor.createTensor(env, LongBuffer.wrap(v), shape); }
            else if (typeOf(tn) == OnnxJavaType.INT32) { int[] v = new int[cnt]; java.util.Arrays.fill(v, (int) Math.round(t)); tt = OnnxTensor.createTensor(env, IntBuffer.wrap(v), shape); }
            else { float[] v = new float[cnt]; java.util.Arrays.fill(v, (float) t); tt = OnnxTensor.createTensor(env, FloatBuffer.wrap(v), shape); }
            all.add(tt); m.put(tn != null ? tn.getName() : "timestep", tt);
            OnnxTensor e = OnnxTensor.createTensor(env, FloatBuffer.wrap(condUncond), new long[]{batch, condUncond.length / HID / batch, HID});
            all.add(e); m.put(name(unet, "encoder_hidden_states"), e);
            if (wEmb != null) {
                NodeInfo wn = input(unet, "timestep_cond");
                if (wn != null) {
                    float[] w = new float[wEmb.length * batch];
                    for (int b = 0; b < batch; b++) System.arraycopy(wEmb, 0, w, b * wEmb.length, wEmb.length);
                    OnnxTensor wt = OnnxTensor.createTensor(env, FloatBuffer.wrap(w), new long[]{batch, wEmb.length});
                    all.add(wt); m.put(wn.getName(), wt);
                }
            }
            try (OrtSession.Result r = unet.run(m)) { return floats(r.get(0)); }
        } finally { for (OnnxTensor o : all) o.close(); }
    }

    static String name(OrtSession s, String want) throws Exception {
        NodeInfo n = input(s, want);
        if (n != null) return n.getName();
        for (String k : s.getInputInfo().keySet()) if (k.toLowerCase(java.util.Locale.ROOT).contains(want.substring(0, 4))) return k;
        return want;
    }

    /** Incrustación de la «fuerza» para LCM (timestep_cond). */
    static float[] guidanceEmbedding(float w, int dim) {
        w *= 1000f;
        int half = dim / 2;
        double emb = Math.log(10000.0) / (half - 1);
        float[] out = new float[dim];
        for (int i = 0; i < half; i++) {
            double v = w * Math.exp(i * -emb);
            out[i] = (float) Math.sin(v);
            out[half + i] = (float) Math.cos(v);
        }
        return out;
    }

    /** Genera la imagen. Devuelve null si se canceló. */
    static Bitmap generate(Context c, Job j, Progress p) throws Exception {
        load(c, j.model, p);
        boolean lcm = isLcm(j.model);
        int lh = j.height / 8, lw = j.width / 8, n = 4 * lh * lw;
        long seed = j.seed < 0 ? new Random().nextInt(Integer.MAX_VALUE) : j.seed;
        j.seed = seed;
        Random rnd = new Random(seed);

        p.at(-1, L.t("Leyendo lo que quieres dibujar…"), null);
        float[] cond = encodeText(j.prompt);
        boolean useCfg = !lcm && j.cfg > 1.01f;
        float[] ctx;
        int batch;
        if (useCfg) {
            float[] unc = encodeText(j.negative == null ? "" : j.negative);
            // v1.7: los dos del mismo largo (se rellena con trozos vacíos, como A1111)
            if (unc.length != cond.length) {
                float[] empty = encodeText("");
                if (unc.length < cond.length) unc = padTo(unc, cond.length, empty); else cond = padTo(cond, unc.length, empty);
            }
            ctx = new float[unc.length + cond.length];
            System.arraycopy(unc, 0, ctx, 0, unc.length);
            System.arraycopy(cond, 0, ctx, unc.length, cond.length);
            batch = 2;
        } else { ctx = cond; batch = 1; }

        float[] init = null;
        if (j.init != null) {
            p.at(-1, L.t("Mirando tu imagen de partida…"), null);
            init = encodeImage(c, j.init, j.width, j.height);
        }
        if (j.cancel) return null;

        float[] x = new float[n];
        long t0 = System.currentTimeMillis();
        if (lcm) {
            float strength = init != null ? j.strength : 1f;
            int[] ts = lcmTimesteps(j.steps, strength);
            NodeInfo wn = input(unet, "timestep_cond");
            long[] wsh = shapeOf(wn);
            float[] wEmb = wn != null ? guidanceEmbedding(Math.max(1f, j.cfg) - 1f, wsh.length == 2 && wsh[1] > 0 ? (int) wsh[1] : 256) : null;
            if (init != null) {
                double a = AC[ts[0]];
                for (int i = 0; i < n; i++) x[i] = (float) (Math.sqrt(a) * init[i] + Math.sqrt(1 - a) * rnd.nextGaussian());
            } else for (int i = 0; i < n; i++) x[i] = (float) rnd.nextGaussian();
            int from = 0;
            Object[] ck = ckLoad(j, true, n);                 // v1.7.6: ¿se cortó a medias? sigue desde ahí
            if (ck != null && (Integer) ck[0] < ts.length) { from = (Integer) ck[0]; x = (float[]) ck[1]; rnd = (Random) ck[3]; j.resumedAt = from; }
            for (int s = from; s < ts.length; s++) {
                if (j.cancel) return null;
                Thermal.breathe(c, () -> j.cancel, m -> p.at(-1, m, null));      // v1.7: modo fresco
                int t = ts[s];
                float[] eps = unetEps(x, t, ctx, 1, lh, lw, wEmb);
                double a = AC[t], bt = 1 - a;
                double st = t * 10.0, cSkip = 0.25 / (st * st + 0.25), cOut = st / Math.sqrt(st * st + 0.25);
                boolean last = s == ts.length - 1;
                double aPrev = last ? 1.0 : AC[ts[s + 1]];
                for (int i = 0; i < n; i++) {
                    double x0 = (x[i] - Math.sqrt(bt) * eps[i]) / Math.sqrt(a);
                    double den = cOut * x0 + cSkip * x[i];
                    x[i] = (float) (last ? den : Math.sqrt(aPrev) * den + Math.sqrt(1 - aPrev) * rnd.nextGaussian());
                }
                if (!last) ckSave(j, true, s + 1, x, null, rnd);
                report(p, s + 1, ts.length, t0, x, lh, lw);
            }
        } else {
            double[] sig = karras(j.steps);
            int start = 0;
            if (init != null) start = Math.max(0, Math.min(j.steps - 1, j.steps - Math.round(j.steps * j.strength)));
            for (int i = 0; i < n; i++) {
                double z = rnd.nextGaussian();
                x[i] = (float) (init != null ? init[i] + z * sig[start] : z * sig[0]);
            }
            float[] old = null;
            int from = start;
            Object[] ck = ckLoad(j, false, n);                // v1.7.6: ¿se cortó a medias? sigue desde ahí
            if (ck != null && (Integer) ck[0] > start && (Integer) ck[0] < j.steps) {
                from = (Integer) ck[0]; x = (float[]) ck[1]; old = (float[]) ck[2]; rnd = (Random) ck[3]; j.resumedAt = from - start;
            }
            for (int s = from; s < j.steps; s++) {
                if (j.cancel) return null;
                Thermal.breathe(c, () -> j.cancel, m -> p.at(-1, m, null));      // v1.7: modo fresco
                double sg = sig[s], cin = 1 / Math.sqrt(sg * sg + 1);
                float[] xin = new float[n];
                for (int i = 0; i < n; i++) xin[i] = (float) (x[i] * cin);
                float[] out = unetEps(xin, sigmaToT(sg), ctx, batch, lh, lw, null);
                float[] den = new float[n];
                for (int i = 0; i < n; i++) {
                    double e = batch == 2 ? out[i] + j.cfg * (out[n + i] - out[i]) : out[i];
                    den[i] = (float) (x[i] - sg * e);
                }
                // DPM++ 2M
                double sNext = sig[s + 1];
                if (sNext == 0) { System.arraycopy(den, 0, x, 0, n); }
                else {
                    double tt = -Math.log(sg), tn = -Math.log(sNext), h = tn - tt;
                    double ratio = sNext / sg, k = -Math.expm1(-h);
                    if (old == null || s == start) {
                        for (int i = 0; i < n; i++) x[i] = (float) (ratio * x[i] + k * den[i]);
                    } else {
                        double hLast = tt - (-Math.log(sig[s - 1])), r = hLast / h;
                        for (int i = 0; i < n; i++) {
                            double d = (1 + 1 / (2 * r)) * den[i] - (1 / (2 * r)) * old[i];
                            x[i] = (float) (ratio * x[i] + k * d);
                        }
                    }
                }
                old = den;
                if (s + 1 < j.steps) ckSave(j, false, s + 1, x, old, rnd);
                report(p, s + 1 - start, j.steps - start, t0, x, lh, lw);
            }
        }
        if (j.cancel) return null;
        p.at(-1, L.t("Revelando la imagen…"), null);
        return decode(x, lh, lw);
    }

    static void report(Progress p, int done, int total, long t0, float[] x, int lh, int lw) {
        long el = System.currentTimeMillis() - t0;
        long left = done == 0 ? 0 : el * (total - done) / done / 1000;
        p.at(done, L.t("Dibujando… paso") + " " + done + "/" + total + (done < total ? " · " + L.t("quedan") + " ≈" + left + " s" : ""), preview(x, lh, lw));
    }

    /** Vista previa barata: de la imagen latente a colores aproximados (sin pasar por el VAE). */
    static Bitmap preview(float[] x, int lh, int lw) {
        float[][] f = {{0.3512f, 0.2297f, 0.3227f}, {0.3250f, 0.4974f, 0.2350f}, {-0.2829f, 0.1762f, 0.2721f}, {-0.2120f, -0.2616f, -0.7177f}};
        int n = lh * lw;
        int[] px = new int[n];
        for (int i = 0; i < n; i++) {
            float r = 0, g = 0, b = 0;
            for (int ch = 0; ch < 4; ch++) { float v = x[ch * n + i] / 1.5f; r += v * f[ch][0]; g += v * f[ch][1]; b += v * f[ch][2]; }
            px[i] = 0xff000000 | (clamp((r + 1) * 127.5f) << 16) | (clamp((g + 1) * 127.5f) << 8) | clamp((b + 1) * 127.5f);
        }
        return Bitmap.createBitmap(px, lw, lh, Bitmap.Config.ARGB_8888);
    }

    static int clamp(float v) { return v < 0 ? 0 : v > 255 ? 255 : (int) v; }

    static Bitmap decode(float[] lat, int lh, int lw) throws Exception {
        float[] z = new float[lat.length];
        for (int i = 0; i < z.length; i++) z[i] = lat[i] / 0.18215f;
        OnnxTensor t = OnnxTensor.createTensor(env, FloatBuffer.wrap(z), new long[]{1, 4, lh, lw});
        Map<String, OnnxTensor> m = new HashMap<>();
        m.put(name(vaeDec, "latent_sample"), t);
        float[] img;
        try (OrtSession.Result r = vaeDec.run(m)) { img = floats(r.get(0)); } finally { t.close(); }
        int h = lh * 8, w = lw * 8, n = h * w;
        int[] px = new int[n];
        for (int i = 0; i < n; i++)
            px[i] = 0xff000000 | (clamp((img[i] + 1) * 127.5f) << 16) | (clamp((img[n + i] + 1) * 127.5f) << 8) | clamp((img[2 * n + i] + 1) * 127.5f);
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
    }

    /** img2img: tu imagen → imagen latente (×0,18215). */
    static float[] encodeImage(Context c, Bitmap src, int w, int h) throws Exception {
        if (vaeEnc == null) vaeEnc = open(new File(dir(c, loadedId), "vae_encoder/model.onnx"));
        Bitmap b = cover(src, w, h);
        int n = w * h;
        int[] px = new int[n];
        b.getPixels(px, 0, w, 0, 0, w, h);
        float[] in = new float[3 * n];
        for (int i = 0; i < n; i++) {
            in[i] = ((px[i] >> 16) & 0xff) / 127.5f - 1;
            in[n + i] = ((px[i] >> 8) & 0xff) / 127.5f - 1;
            in[2 * n + i] = (px[i] & 0xff) / 127.5f - 1;
        }
        OnnxTensor t = OnnxTensor.createTensor(env, FloatBuffer.wrap(in), new long[]{1, 3, h, w});
        Map<String, OnnxTensor> m = new HashMap<>();
        m.put(name(vaeEnc, "sample"), t);
        float[] lat;
        try (OrtSession.Result r = vaeEnc.run(m)) { lat = floats(r.get(0)); } finally { t.close(); }
        int ln = 4 * (h / 8) * (w / 8);
        float[] out = new float[ln];
        for (int i = 0; i < ln; i++) out[i] = lat[i] * 0.18215f;     // si devuelve media y varianza (8 canales), se queda con la media
        return out;
    }

    /** Recorta y escala para llenar w×h sin deformar. */
    static Bitmap cover(Bitmap s, int w, int h) {
        float sc = Math.max((float) w / s.getWidth(), (float) h / s.getHeight());
        int cw = Math.round(w / sc), ch = Math.round(h / sc);
        int x = (s.getWidth() - cw) / 2, y = (s.getHeight() - ch) / 2;
        Bitmap crop = Bitmap.createBitmap(s, Math.max(0, x), Math.max(0, y), Math.min(cw, s.getWidth()), Math.min(ch, s.getHeight()));
        return Bitmap.createScaledBitmap(crop, w, h, true);
    }
}
