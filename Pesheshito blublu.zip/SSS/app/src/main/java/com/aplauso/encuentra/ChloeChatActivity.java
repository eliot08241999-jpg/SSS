package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * v1.4.5 · Chloe a pantalla completa, como un chatbot: ella grande arriba (se puede tocar) y la conversación
 * en burbujas debajo. Comparte la conversación con la pantalla del asistente.
 */
public class ChloeChatActivity extends NeonActivity {
    static final int REQ_SPEAK = 81;
    Avatar av;
    LinearLayout bubbles;
    ScrollView scroll;
    EditText in;
    boolean busy;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Voice.init(this, null);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dpi(12), dpi(10), dpi(12), dpi(10));

        // barra de arriba: volver, nombre y aspecto
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(circleButton("☰", v -> drawer(true)), new LinearLayout.LayoutParams(dpi(42), dpi(42)));   // v1.7: el menú (como el de Claude)
        TextView name = neonText("  " + Brain.botName(this), 20);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        TextView skin = button("🎨", v -> {
            String[] cyc = {"auto", "autumn", "winter", "spring", "summer"};
            int i = java.util.Arrays.asList(cyc).indexOf(p.getString("avatar_outfit", "auto"));
            String nx = cyc[(i + 1) % cyc.length];
            p.edit().putString("avatar_outfit", nx).putString("avatar_skin", "bunny").apply();
            av.refreshOutfit();
            int k = java.util.Arrays.asList(Outfit.ALL).indexOf(Outfit.now(this));
            toast(("auto".equals(nx) ? L.t("Auto: ") : "") + L.t(Outfit.LABEL[Math.max(0, k)]));
        });
TextView lg = button("", null);
        Runnable lgl = () -> { String x = p.getString("listen_lang", "auto"); lg.setText("🌐 " + ("auto".equals(x) ? "AUTO" : x.toUpperCase(java.util.Locale.ROOT))); };
        lg.setOnClickListener(v -> {
            String[] cyc = {"auto", "es", "it", "en"};
            int i = java.util.Arrays.asList(cyc).indexOf(p.getString("listen_lang", "auto"));
            p.edit().putString("listen_lang", cyc[(i + 1) % cyc.length]).apply();
            lgl.run();
            toast(L.t("Idioma en el que te escucho. AUTO = el de la conversación."));
        });
        lgl.run();
        lg.setPadding(dpi(10), dpi(8), dpi(10), dpi(8));
        LinearLayout.LayoutParams lgp = new LinearLayout.LayoutParams(-2, -2); lgp.rightMargin = dpi(6);
        top.addView(lg, lgp);
        TextView live = button("🎙", v -> startActivity(new Intent(this, LiveActivity.class)));
        live.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        LinearLayout.LayoutParams lvp = new LinearLayout.LayoutParams(-2, -2); lvp.rightMargin = dpi(6);
        top.addView(live, lvp);
        skin.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        top.addView(skin, new LinearLayout.LayoutParams(-2, -2));
        root.addView(top);

        // Chloe grande
        av = Chloe3DView.make(this);
        av.setOnPoke(line -> { bubble(false, line); Voice.say(this, line); });
        boolean is3d = av instanceof Chloe3DView;
        if (is3d) root.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1.3f));   // v1.6: la escena 3D va detrás, a pantalla completa
        else if (Weather.on(this)) {                       // v1.7: el tiempo de verdad encima de su escena
            fx = new WeatherFx(this);
            android.widget.FrameLayout af = new android.widget.FrameLayout(this);
            af.addView(av.view(), new android.widget.FrameLayout.LayoutParams(-1, -1));
            af.addView(fx, new android.widget.FrameLayout.LayoutParams(-1, -1));
            root.addView(af, new LinearLayout.LayoutParams(-1, 0, 1.15f));
        } else root.addView(av.view(), new LinearLayout.LayoutParams(-1, 0, 1.15f));

        // v1.7: la tarjeta del tiempo de la semana
        if (Weather.on(this)) { wxCard = weatherCard(); root.addView(wxCard, gapBelow(4)); }

        // conversación
        scroll = new ScrollView(this);
        bubbles = new LinearLayout(this);
        bubbles.setOrientation(LinearLayout.VERTICAL);
        bubbles.setPadding(0, dpi(6), 0, dpi(6));
        scroll.addView(bubbles);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        // v1.6: respuestas rápidas
        android.widget.HorizontalScrollView chs = new android.widget.HorizontalScrollView(this);
        chs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        String[][] quick = {
                {"❓ Pregúntame algo", "Hazme tú una pregunta sobre mí o sobre lo que hemos hablado. Solo la pregunta, corta y con tu personalidad."},
                {"🔀 Cambia de tema", "Cambia de tema: elige tú uno nuevo e interesante y empieza a contarme algo sobre él."},
                {"💬 Di algo", "Di tú algo: un dato curioso, una idea o lo que se te ocurra ahora, con tu personalidad. Sin preguntarme qué quiero."},
                {"😂 Un chiste", "cuéntame un chiste"}};
        for (String[] qk : quick) {
            TextView c = button(qk[0], v -> { if (!busy) askAs(L.t(qk[0]), qk[1]); });
            c.setTextSize(12);
            c.setPadding(dpi(12), dpi(6), dpi(12), dpi(6));
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
            cl.rightMargin = dpi(6);
            chips.addView(c, cl);
        }
        chs.addView(chips);
        LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(-1, -2);
        chp.bottomMargin = dpi(6);
        root.addView(chs, chp);

        // escribir / hablar
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        in = new EditText(this);
        in.setHint(L.t("Escribe tu pregunta…"));
        in.setTextColor(Color.WHITE);
        in.setHintTextColor(Color.GRAY);
        in.setTextSize(15);
        in.setSingleLine(true);
        in.setImeOptions(EditorInfo.IME_ACTION_SEND);
        in.setBackground(frame(22));
        in.setPadding(dpi(16), dpi(10), dpi(16), dpi(10));
        in.setOnEditorActionListener((v, id, e) -> { send(); return true; });
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, -2, 1);
        ip.rightMargin = dpi(6);
        row.addView(in, ip);
        TextView mic = circleButton("🎤", v -> listen());
        row.addView(mic, new LinearLayout.LayoutParams(dpi(48), dpi(48)));
        TextView go = circleButton("➤", v -> send());
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dpi(48), dpi(48));
        gp.leftMargin = dpi(6);
        row.addView(go, gp);
        root.addView(row);

        android.widget.FrameLayout fr = makeRoot(root);
        if (is3d) {
            fr.addView(av.view(), 2, new android.widget.FrameLayout.LayoutParams(-1, -1));
            if (Weather.on(this)) { fx = new WeatherFx(this); fr.addView(fx, 3, new android.widget.FrameLayout.LayoutParams(-1, -1)); }
            // cuerpo entero o de cerca
            TextView fb = button("🧍", v -> {
                String f = "full".equals(p.getString("avatar_3d_frame", "bust")) ? "bust" : "full";
                ((Chloe3DView) av).setFrame(f);
            });
            fb.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
            LinearLayout.LayoutParams fbp = new LinearLayout.LayoutParams(-2, -2); fbp.rightMargin = dpi(6);
            top.addView(fb, 1, fbp);
        }
        buildDrawer(fr);
        setContentView(fr);

        // lo que ya hablasteis (v1.7: la conversación guardada entera)
        showConvo();
        av.react(AvatarArt.HAPPY, 1500);
    }

    @Override protected void onPause() { super.onPause(); Voice.stop(); h.removeCallbacks(wxTick); }

    // ------------------------------------------------------------------ v1.7: el tiempo
    WeatherFx fx;
    LinearLayout wxCard, wxDays;
    TextView wxNow, wxAlert;
    final Runnable wxTick = new Runnable() { public void run() { loadWeather(); h.postDelayed(this, 20 * 60_000L); } };

    LinearLayout weatherCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(frame(14));
        card.setPadding(dpi(10), dpi(6), dpi(10), dpi(6));
        wxNow = text(L.t("🌦 Mirando el tiempo…"), 13);
        wxNow.setOnClickListener(v -> {
            boolean open = !p.getBoolean("wx_card_open", true);
            p.edit().putBoolean("wx_card_open", open).apply();
            if (wxDays != null) ((View) wxDays.getParent()).setVisibility(open ? View.VISIBLE : View.GONE);
        });
        card.addView(wxNow);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        wxDays = new LinearLayout(this);
        hs.addView(wxDays);
        hs.setVisibility(p.getBoolean("wx_card_open", true) ? View.VISIBLE : View.GONE);
        card.addView(hs);
        wxAlert = text("", 12);
        wxAlert.setTextColor(Color.rgb(255, 200, 120));
        wxAlert.setVisibility(View.GONE);
        card.addView(wxAlert);
        return card;
    }

    void loadWeather() {
        new Thread(() -> {
            Weather.Fc f;
            try { f = Weather.here(this); } catch (Exception e) { f = null; }
            final Weather.Fc ff = f;
            runOnUiThread(() -> showWeather(ff));
        }, "tiempo").start();
    }

    void showWeather(Weather.Fc f) {
        if (fx != null) fx.set(f);
        if (wxCard == null) return;
        if (f == null) { wxNow.setText(L.t("🌦 No puedo mirar el tiempo: pon tu ciudad en el asistente o activa la ubicación.")); return; }
        wxNow.setText(Weather.icon(f.code) + " " + (f.place.isEmpty() ? L.t("Ahora") : f.place) + " · " + Math.round(f.temp) + "°"
                + (Math.abs(f.feels - f.temp) >= 2 ? " (" + L.t("sensación") + " " + Math.round(f.feels) + "°)" : "")
                + " · 💨 " + Math.round(f.wind) + " km/h · ☔ " + f.rain[0] + "%  ▾");
        wxDays.removeAllViews();
        String[] dn = {L.t("Dom"), L.t("Lun"), L.t("Mar"), L.t("Mié"), L.t("Jue"), L.t("Vie"), L.t("Sáb")};
        java.util.Calendar k = java.util.Calendar.getInstance();
        for (int i = 0; i < 7; i++) {
            final int day = i;
            String label = i == 0 ? L.t("Hoy") : i == 1 ? L.t("Mañana") : dn[k.get(java.util.Calendar.DAY_OF_WEEK) - 1];
            k.add(java.util.Calendar.DAY_OF_YEAR, 1);
            TextView d = text(label + "\n" + Weather.icon(f.codes[i]) + "\n" + Math.round(f.max[i]) + "° / " + Math.round(f.min[i]) + "°\n☔ " + f.rain[i] + "%", 12);
            d.setGravity(Gravity.CENTER);
            d.setPadding(dpi(10), dpi(6), dpi(10), dpi(6));
            d.setBackground(frame(12));
            d.setOnClickListener(v -> {                     // tócalo y te lo cuenta
                new Thread(() -> {
                    String say = Routines.weather(this, day);
                    runOnUiThread(() -> { bubble(false, say); Voice.say(this, say); av.react(AvatarArt.HAPPY, 1200); });
                }).start();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dpi(6);
            lp.topMargin = dpi(4);
            wxDays.addView(d, lp);
        }
        String al = Weather.alerts(f);
        wxAlert.setText(al);
        wxAlert.setVisibility(al.isEmpty() ? View.GONE : View.VISIBLE);
    }

    /** v1.7: el chat es la pantalla de inicio; el menú (juegos, editores, ajustes…) está debajo. */
    void openMenu() {
        if (isTaskRoot()) startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    @Override public void onBackPressed() { if (drawerOpen) drawer(false); else openMenu(); }

    // ------------------------------------------------------------------ v1.7: menú lateral con las conversaciones
    android.widget.FrameLayout drawerDim;
    LinearLayout drawerPanel, drawerList;
    EditText drawerSearch;
    boolean drawerOpen;

    void showConvo() {
        bubbles.removeAllViews();
        List<String[]> h;
        synchronized (Convos.LOCK) { h = new ArrayList<>(Convos.current().msgs); }
        for (String[] m : h) bubble(m[0].equals("user"), m[0].equals("user") ? m[1] : Brain.speech(m[1]));
        if (h.isEmpty()) bubble(false, L.t("¡Aquí estoy! Escríbeme o pulsa 🎤 para hablarme. Y si me tocas, reacciono. 😊"));
    }

    void buildDrawer(android.widget.FrameLayout fr) {
        drawerDim = new android.widget.FrameLayout(this);
        drawerDim.setBackgroundColor(Color.argb(150, 0, 0, 0));
        drawerDim.setVisibility(View.GONE);
        drawerDim.setOnClickListener(v -> drawer(false));
        drawerPanel = new LinearLayout(this);
        drawerPanel.setOrientation(LinearLayout.VERTICAL);
        drawerPanel.setClickable(true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(12, 14, 28));
        bg.setStroke(dpi(1), Color.argb(120, Color.red(Neon.color(this)), Color.green(Neon.color(this)), Color.blue(Neon.color(this))));
        drawerPanel.setBackground(bg);
        drawerPanel.setPadding(dpi(16), dpi(18), dpi(16), dpi(14));
        // cabecera: icono + nombre + buscar
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        android.widget.ImageView ic = new android.widget.ImageView(this);
        try (java.io.InputStream in = getAssets().open("nova_icon.webp")) { ic.setImageBitmap(android.graphics.BitmapFactory.decodeStream(in)); } catch (Exception ignored) {}
        ic.setClipToOutline(true);
        GradientDrawable icbg = new GradientDrawable(); icbg.setCornerRadius(dpi(10)); ic.setBackground(icbg);
        head.addView(ic, new LinearLayout.LayoutParams(dpi(40), dpi(40)));
        TextView ttl = neonText("  Chloe Nova", 20);
        head.addView(ttl, new LinearLayout.LayoutParams(0, -2, 1));
        TextView sb = circleButton("🔍", v -> {
            drawerSearch.setVisibility(drawerSearch.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            if (drawerSearch.getVisibility() == View.GONE) { drawerSearch.setText(""); fillDrawer(); }
            else drawerSearch.requestFocus();
        });
        head.addView(sb, new LinearLayout.LayoutParams(dpi(40), dpi(40)));
        drawerPanel.addView(head);
        drawerSearch = new EditText(this);
        drawerSearch.setHint(L.t("Buscar en tus conversaciones…"));
        drawerSearch.setTextColor(Color.WHITE);
        drawerSearch.setHintTextColor(Color.GRAY);
        drawerSearch.setTextSize(14);
        drawerSearch.setSingleLine(true);
        drawerSearch.setBackground(frame(14));
        drawerSearch.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        drawerSearch.setVisibility(View.GONE);
        drawerSearch.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence a, int b, int c, int d) {}
            public void onTextChanged(CharSequence a, int b, int c, int d) {}
            public void afterTextChanged(android.text.Editable e) { fillDrawer(); }
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2); slp.topMargin = dpi(10);
        drawerPanel.addView(drawerSearch, slp);
        ScrollView sv = new ScrollView(this);
        drawerList = new LinearLayout(this);
        drawerList.setOrientation(LinearLayout.VERTICAL);
        sv.addView(drawerList);
        drawerPanel.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        // abajo: tú + nueva conversación
        LinearLayout foot = new LinearLayout(this);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        String nm = p.getString("ai_name", "").trim();
        TextView me = circleButton(nm.isEmpty() ? "👤" : nm.substring(0, 1).toUpperCase(java.util.Locale.ROOT),
                v -> { drawer(false); startActivity(new Intent(this, AssistActivity.class)); });
        foot.addView(me, new LinearLayout.LayoutParams(dpi(46), dpi(46)));
        foot.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        TextView nw = button("＋ " + L.t("Nueva conversación"), v -> {
            if (busy) return;
            Convos.newOne();
            showConvo();
            drawer(false);
        });
        foot.addView(nw, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2); flp.topMargin = dpi(8);
        drawerPanel.addView(foot, flp);
        int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.86f);
        drawerDim.addView(drawerPanel, new android.widget.FrameLayout.LayoutParams(w, -1, Gravity.START));
        fr.addView(drawerDim, new android.widget.FrameLayout.LayoutParams(-1, -1));
    }

    void drawer(boolean open) {
        if (drawerDim == null) return;
        drawerOpen = open;
        if (open) {
            fillDrawer();
            drawerDim.setVisibility(View.VISIBLE);
            drawerDim.setAlpha(0f);
            drawerDim.animate().alpha(1f).setDuration(160).start();
            drawerPanel.setTranslationX(-drawerPanel.getLayoutParams().width);
            drawerPanel.animate().translationX(0).setDuration(220).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            android.view.inputmethod.InputMethodManager im = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (im != null) im.hideSoftInputFromWindow(in.getWindowToken(), 0);
        } else {
            drawerPanel.animate().translationX(-drawerPanel.getLayoutParams().width).setDuration(180).start();
            drawerDim.animate().alpha(0f).setDuration(180).withEndAction(() -> drawerDim.setVisibility(View.GONE)).start();
        }
    }

    TextView drawerItem(String label, View.OnClickListener l) {
        TextView t = text(label, 16);
        t.setTextColor(Color.rgb(225, 230, 245));
        t.setPadding(dpi(6), dpi(11), dpi(6), dpi(11));
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setOnClickListener(l);
        t.setBackgroundResource(android.R.drawable.list_selector_background);
        return t;
    }

    void go(Class<?> c) { drawer(false); startActivity(new Intent(this, c)); }

    void fillDrawer() {
        drawerList.removeAllViews();
        String q = drawerSearch.getText().toString().trim();
        if (q.isEmpty()) {
            // las secciones de la app (lo que antes estaba en la pantalla principal)
            Object[][] sec = {{"🎮  " + L.t("Juegos"), GamesActivity.class}, {"✂  " + L.t("Editores"), GalleryActivity.class},
                    {"🎨  " + L.t("Estudio de dibujo"), DrawStudioActivity.class}, {"➕  " + L.t("Adicionales"), AdditionalActivity.class},
                    {"🔍  " + L.t("Ampliar imágenes"), UpscaleActivity.class}, {"🎬  " + L.t("Ampliar vídeos"), VideoUpscaleActivity.class},
                    {"🐑  " + L.t("Asistente Chloe"), AssistActivity.class}, {"🎙  " + L.t("Hablar en directo"), LiveActivity.class},
                    {"⚙  " + L.t("Ajustes"), SettingsActivity.class}};
            for (Object[] s : sec) { Class<?> c = (Class<?>) s[1]; drawerList.addView(drawerItem((String) s[0], v -> go(c))); }
            drawerList.addView(drawerItem("⊞  " + L.t("Menú completo"), v -> { drawer(false); openMenu(); }));
            View sep = new View(this);
            sep.setBackgroundColor(Color.argb(60, 255, 255, 255));
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dpi(1)); sp.topMargin = dpi(10); sp.bottomMargin = dpi(6);
            drawerList.addView(sep, sp);
        }
        List<Convos.Convo> all = q.isEmpty() ? Convos.all() : Convos.search(q);
        String curId = Convos.current().id;
        boolean anyPinned = false;
        for (Convos.Convo k : all) if (k.pinned) anyPinned = true;
        boolean recentShown = false;
        if (anyPinned) drawerList.addView(drawerHeader(L.t("Fijadas")));
        for (Convos.Convo k : all) {
            if (!k.pinned && !recentShown) { drawerList.addView(drawerHeader(q.isEmpty() ? L.t("Recientes") : L.t("Resultados"))); recentShown = true; }
            String title = k.title.isEmpty() ? L.t("Conversación") : k.title;
            TextView t = drawerItem("💬  " + title, v -> {
                if (busy) return;
                Convos.open(k.id);
                showConvo();
                drawer(false);
            });
            if (k.id.equals(curId)) { GradientDrawable g = new GradientDrawable(); g.setColor(Color.argb(40, 255, 255, 255)); g.setCornerRadius(dpi(10)); t.setBackground(g); }
            t.setOnLongClickListener(v -> { convoOptions(k); return true; });
            drawerList.addView(t);
        }
        if (all.isEmpty()) {
            TextView e = text(q.isEmpty() ? L.t("Aún no hay conversaciones guardadas.") : L.t("No encuentro nada con eso."), 13);
            e.setTextColor(Color.GRAY);
            e.setPadding(dpi(6), dpi(10), dpi(6), dpi(10));
            drawerList.addView(e);
        } else {
            TextView tip = text(L.t("Mantén pulsada una conversación para fijarla, renombrarla o borrarla."), 11);
            tip.setTextColor(Color.GRAY);
            tip.setPadding(dpi(6), dpi(12), dpi(6), dpi(6));
            drawerList.addView(tip);
        }
    }

    TextView drawerHeader(String s) {
        TextView t = text(s, 13);
        t.setTextColor(Color.rgb(140, 150, 175));
        t.setPadding(dpi(6), dpi(12), dpi(6), dpi(4));
        return t;
    }

    void convoOptions(Convos.Convo k) {
        String[] opts = {k.pinned ? L.t("📌 Quitar de fijadas") : L.t("📌 Fijar"), L.t("✏ Cambiar el nombre"), L.t("🗑 Borrar")};
        new android.app.AlertDialog.Builder(this).setTitle(k.title.isEmpty() ? L.t("Conversación") : k.title).setItems(opts, (d, w) -> {
            if (w == 0) { Convos.pin(k.id, !k.pinned); fillDrawer(); }
            else if (w == 1) {
                EditText e = new EditText(this);
                e.setText(k.title);
                e.setSelectAllOnFocus(true);
                new android.app.AlertDialog.Builder(this).setTitle(L.t("Nombre de la conversación")).setView(e)
                        .setPositiveButton(L.t("Guardar"), (d2, w2) -> { Convos.rename(k.id, e.getText().toString()); fillDrawer(); })
                        .setNegativeButton(L.t("Cancelar"), null).show();
            } else {
                new android.app.AlertDialog.Builder(this).setMessage(L.t("¿Borrar esta conversación? No se puede deshacer."))
                        .setPositiveButton(L.t("🗑 Borrar"), (d2, w2) -> {
                            boolean wasCur = k.id.equals(Convos.current().id);
                            Convos.delete(k.id);
                            if (wasCur) showConvo();
                            fillDrawer();
                        }).setNegativeButton(L.t("Cancelar"), null).show();
            }
        }).show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (p.getBoolean("crash_new", false)) {               // v1.7: si la última vez se cerró de golpe
            p.edit().remove("crash_new").apply();
            new android.app.AlertDialog.Builder(this)
                    .setTitle(L.t("Chloe Nova se cerró por un error"))
                    .setMessage(L.t("He apuntado qué pasó. Lo puedes ver y copiar en Ajustes → «Último error»."))
                    .setPositiveButton(L.t("VER"), (d, w) -> startActivity(new Intent(this, SettingsActivity.class)))
                    .setNegativeButton(L.t("Ahora no"), null).show();
        }
        if (Weather.on(this)) { h.removeCallbacks(wxTick); h.post(wxTick); }
    }

    // ------------------------------------------------------------------ burbujas
    TextView last;

    /** v1.7: los *gestos* del modo personaje, en cursiva y más suaves. */
    static CharSequence styled(String s) {
        if (s == null || s.indexOf('*') < 0) return s;
        android.text.SpannableStringBuilder b = new android.text.SpannableStringBuilder();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\*([^*\\n]{1,120})\\*").matcher(s);
        int last = 0;
        while (m.find()) {
            b.append(s, last, m.start());
            int st = b.length();
            b.append(m.group(1));
            b.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.ITALIC), st, b.length(), 0);
            b.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(170, 185, 215)), st, b.length(), 0);
            last = m.end();
        }
        b.append(s.substring(last));
        return b;
    }

    TextView bubble(boolean user, String text) {
        TextView t = new TextView(this);
        t.setText(styled(text));
        t.setTextSize(15);
        t.setTextColor(user ? Color.WHITE : Color.rgb(235, 240, 255));
        t.setPadding(dpi(14), dpi(9), dpi(14), dpi(9));
        GradientDrawable g = new GradientDrawable();
        int neon = Neon.color(this);
        float r = dpi(18), s = dpi(4);
        g.setCornerRadii(user ? new float[]{r, r, s, s, r, r, r, r} : new float[]{s, s, r, r, r, r, r, r});
        if (user) { g.setColor(Color.argb(70, Color.red(neon), Color.green(neon), Color.blue(neon))); g.setStroke(dpi(1), neon); }
        else { g.setColor(Color.rgb(26, 30, 56)); g.setStroke(dpi(1), Color.argb(90, 255, 255, 255)); }
        t.setBackground(g);
        t.setTextIsSelectable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.gravity = user ? Gravity.END : Gravity.START;
        lp.topMargin = dpi(6);
        if (user) lp.leftMargin = dpi(48); else lp.rightMargin = dpi(48);
        bubbles.addView(t, lp);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        last = t;
        return t;
    }

    // ------------------------------------------------------------------ preguntar
    void send() {
        String q = in.getText().toString().trim();
        if (q.isEmpty()) return;
        in.setText("");
        ask(q);
    }

    void ask(String q) { askAs(q, q); }

    /** v1.6: «shown» es lo que se ve en tu burbuja; «q» lo que se le pide de verdad. */
    void askAs(String label, String q) {
        if (busy) { toast(L.t("Espera, que aún estoy pensando…")); return; }
        bubble(true, label);
        Actions.Result r = Actions.parse(this, q);
        if (r != null) {
            boolean ok = Actions.run(this, r);
            String msg = ok ? r.say : L.t("No he podido abrirlo en este teléfono.");
            bubble(false, msg);
            Voice.say(this, msg);
            av.react(ok ? AvatarArt.HAPPY : AvatarArt.SAD, 1800);
            return;
        }
        if (Mood.nonsense(q)) { String m = Mood.confused(); bubble(false, m); Voice.say(this, m); av.react(AvatarArt.CONFUSED, 4000); return; }
        busy = true;
        av.setState(AvatarArt.THINK);
        TextView think = bubble(false, "…");
        h.post(new Runnable() {                                 // puntitos mientras piensa
            int n;
            public void run() { if (!busy) return; think.setText(new String[]{"·", "· ·", "· · ·"}[n++ % 3]); h.postDelayed(this, 400); }
        });
        final Voice.Streamer vs = new Voice.Streamer(this);     // v1.6: se ve y se oye según escribe
        final long[] lastUi = {0};
        new Thread(() -> {
            String raw = Brain.ask(this, q, so -> {
                String t = vs.partial(so);
                long now = System.currentTimeMillis();
                if (now - lastUi[0] > 120 && !t.isEmpty()) { lastUi[0] = now; runOnUiThread(() -> { if (busy) { think.setText(styled(t)); av.setState(AvatarArt.TALK); } }); }
            });
            String cmd = Brain.cmdOf(raw);
            String ans = Brain.speech(raw);
            String src = sources();
            runOnUiThread(() -> {
                busy = false;
                StringBuilder shown = new StringBuilder(ans);
                if (!src.isEmpty()) shown.append("\n").append(src);
                if (cmd != null) {
                    Actions.Result rc = Actions.parse(this, cmd);
                    if (rc != null && rc.intent != null && !Actions.run(this, rc)) shown.append("\n⚠ ").append(L.t("No he podido abrirlo en este teléfono."));
                    if (rc == null) shown.append("\n⚠ ").append(L.t("No sé hacer: ")).append(cmd);
                }
                String err = Brain.lastError;
                if (!err.isEmpty()) shown.append("\n⚠ ").append(err);
                think.setText(styled(shown.toString()));
                scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
                vs.finish(ans);
                av.setState(AvatarArt.IDLE);
                if (!err.isEmpty()) av.react(AvatarArt.SAD, 3000);
                else if (ans.matches("(?s).*\\?\\s*$") && ans.length() < 140) av.react(AvatarArt.CONFUSED, 1500);
            });
        }, "cerebro").start();
    }

    /** v1.6: «🔎 He buscado en internet · El País · Infobae» (o «☁ Gemini»). */
    static String sources() {
        StringBuilder b = new StringBuilder();
        synchronized (Brain.lastSources) {
            java.util.LinkedHashSet<String> names = new java.util.LinkedHashSet<>();
            for (String[] x : Brain.lastSources) if (x[0] != null && !x[0].isEmpty()) names.add(x[0]);
            if (Brain.lastSearched || !names.isEmpty()) {
                b.append("🔎 ").append(L.t("He buscado en internet"));
                int k = 0;
                for (String n : names) { if (k++ >= 4) break; b.append(k == 1 ? ": " : " · ").append(n); }
            }
        }
        if (Brain.lastCloud) b.append(b.length() > 0 ? "  " : "").append("☁ Gemini");
        return b.toString();
    }

    void listen() {
        Voice.stop();
        av.setState(AvatarArt.LISTEN);
        ShieldService.yieldMic = true;
        h.postDelayed(() -> ShieldService.yieldMic = false, 30000);
        h.postDelayed(() -> {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Brain.listenTag(this));
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, L.t("Te escucho…"));
            try { startActivityForResult(i, REQ_SPEAK); }
            catch (Exception e) { av.setState(AvatarArt.IDLE); toast(L.t("Este teléfono no tiene reconocimiento de voz. Escribe tu pregunta.")); }
        }, 300);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_SPEAK) {
            ShieldService.yieldMic = false;
            av.setState(AvatarArt.IDLE);
            if (res == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) ask(r.get(0));
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }
}
