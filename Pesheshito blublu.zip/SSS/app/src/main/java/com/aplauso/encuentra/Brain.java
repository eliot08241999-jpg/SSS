package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * El "cerebro" de Chloe (v1.1): piensa dentro del teléfono (LocalBrain) o, si lo configuras, en tu portátil
 * con Ollama. Sin Gemini y sin cupos. Antes de responder preguntas de datos busca en internet (Web).
 */
public class Brain {
    static final String DEFAULT_NAME = "Chloe";
    static final String DEFAULT_PERSONA = "Eres simpática y con un punto sarcástico. Hablas claro y corto, como una amiga lista, "
            + "y de vez en cuando sueltas una broma.";
    static final String DEFAULT_PC_MODEL = "qwen2.5:7b";

    /** Conversación reciente (para que recuerde de qué se hablaba). */
    static final List<String[]> history = new ArrayList<>();      // {"user"|"model", texto}

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static String persona(Context c) { String s = prefs(c).getString("ai_persona", "").trim(); return s.isEmpty() ? DEFAULT_PERSONA : s; }
    static boolean search(Context c) { return prefs(c).getBoolean("ai_search", true); }
    /** v1.7: modo personaje (chat de rol, como SillyTavern). */
    static boolean roleplay(Context c) { return prefs(c).getBoolean("ai_roleplay", false); }
    static volatile boolean keepActions;

    /** Las instrucciones del personaje (modo rol). */
    static String roleLine(Context c) {
        if (!roleplay(c)) return "";
        String sc = prefs(c).getString("ai_scenario", "").trim();
        return "\nMODO PERSONAJE: interpreta a " + botName(c) + " como una persona real con emociones, opiniones y recuerdos propios. "
                + "Mantente SIEMPRE en el personaje (nunca digas que eres una IA ni un programa). Responde con naturalidad, como en un chat de rol: "
                + "puedes describir un gesto breve entre asteriscos, por ejemplo *se ríe* o *te mira de reojo* (como mucho uno o dos por respuesta), "
                + "reacciona a lo que te dicen y haz avanzar la conversación con tu propia personalidad."
                + (sc.isEmpty() ? "" : " ESCENARIO: " + sc);
    }

    /** v1.7: lo que se lee en voz alta: sin los gestos *entre asteriscos*. */
    static String voiceText(String s) {
        if (s == null) return null;
        return s.replaceAll("\\*[^*\\n]{1,120}\\*", " ").replace("*", "").replaceAll("\\s+", " ").trim();
    }
    static String botName(Context c) { String s = prefs(c).getString("ai_bot_name", "").trim(); return s.isEmpty() ? DEFAULT_NAME : s; }
    /** "auto" (portátil si responde; si no, el teléfono), "local" o "pc". */
    static String brain(Context c) { String b = prefs(c).getString("ai_brain", "auto"); return b.equals("gemini") ? "auto" : b; }   // v1.1: sin Gemini
    static String pcModel(Context c) { String m = prefs(c).getString("ai_pc_model", "").trim(); return m.isEmpty() ? DEFAULT_PC_MODEL : m; }
    static String pcUrl(Context c) {
        String u = prefs(c).getString("ai_pc_url", "").trim();
        if (u.isEmpty()) return "";
        if (!u.startsWith("http")) u = "http://" + u;
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        if (!u.substring(u.indexOf("//") + 2).contains(":")) u += ":11434";
        return u;
    }

    /** Último error completo (se muestra escrito en la pantalla del asistente). */
    static volatile String lastError = "";

    static final class Fail extends Exception {
        final int code; final String msg;
        Fail(int code, String msg) { super(msg); this.code = code; this.msg = msg; }
    }

    // ================= v1.1: cerebro propio con los pies en la tierra =================
    // ---------- v1.4.3: más lista en la conversación ----------
    static volatile String curQ = "";

    /** El idioma en que te habla (por las palabras), o el de la app si no está claro. */
    static String langOf(String q) {
        String s = " " + Actions.norm(q == null ? "" : q).replaceAll("[^a-z ]", " ") + " ";
        String raw = q == null ? "" : q.toLowerCase(java.util.Locale.ROOT);
        int es = 0, it = 0, en = 0;
        if (raw.matches("(?s).*[ñ¿¡áéíóú].*")) es += 2;
        if (raw.matches("(?s).*[àèìòù].*")) it += 2;
        for (String w : new String[]{"que", "como", "estas", "eres", "tu", "yo", "hola", "pero", "quien", "donde", "cuando", "por que", "gracias", "bien", "muy", "pues", "esta", "tengo", "quiero", "puedes", "dime", "sabes", "soy", "mi", "me", "lo", "los", "las", "una", "y"})
            if (s.contains(" " + w + " ")) es++;
        for (String w : new String[]{"che", "come", "sei", "sono", "ciao", "perche", "non", "grazie", "bene", "molto", "cosa", "chi", "dove", "quando", "voglio", "puoi", "dimmi", "sai", "il", "gli", "della", "e", "io"})
            if (s.contains(" " + w + " ")) it++;
        for (String w : new String[]{"the", "what", "how", "are", "you", "is", "hello", "hi", "thanks", "who", "where", "when", "can", "tell", "do", "my", "and"})
            if (s.contains(" " + w + " ")) en++;
        String code = pickLang(es, it, en);
        return "es".equals(code) ? "español" : "it".equals(code) ? "italiano" : "English";
    }

    /** v1.4.9: entre español, italiano e inglés gana el que más se note; si hay empate (o nada), el idioma de la app. */
    static String pickLang(int es, int it, int en) {
        int app = "es".equals(L.lang) ? es : "it".equals(L.lang) ? it : en;
        int max = Math.max(es, Math.max(it, en));
        if (max == 0 || app == max) return L.lang;
        return es == max ? "es" : it == max ? "it" : "en";
    }

    /** «es», «it» o «en» según el texto. */
    static String langCode(String q) {
        String n = langOf(q);
        return n.equals("español") ? "es" : n.equals("italiano") ? "it" : "en";
    }

    /** Idioma de la conversación: el último en que te habló o escribió el usuario. */
    static volatile String convLang = null;

    /** Etiqueta para el reconocedor de voz: el idioma elegido a mano o, en automático, el de la conversación. */
    static String listenTag(Context c) {
        String p = prefs(c).getString("listen_lang", "auto");
        String code = "auto".equals(p) ? (convLang == null ? L.lang : convLang) : p;
        return "en".equals(code) ? "en-US" : "it".equals(code) ? "it-IT" : "es-ES";
    }

    /** Fecha y hora de ahora, para que no diga «buen día» a medianoche. */
    static String nowLine() {
        java.util.Calendar k = java.util.Calendar.getInstance();
        int h = k.get(java.util.Calendar.HOUR_OF_DAY);
        String part = h < 6 ? "de madrugada" : h < 13 ? "por la mañana" : h < 20 ? "por la tarde" : "por la noche";
        String[] d = {"domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"};
        String[] m = {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"};
        return String.format(java.util.Locale.ROOT, "(Dato interno: ahora es %s %d de %s de %d, las %d:%02d, %s. Úsalo solo para saludar acorde a la hora; NO digas la fecha ni la hora si no te las preguntan.)",
                d[k.get(java.util.Calendar.DAY_OF_WEEK) - 1], k.get(java.util.Calendar.DAY_OF_MONTH), m[k.get(java.util.Calendar.MONTH)],
                k.get(java.util.Calendar.YEAR), h, k.get(java.util.Calendar.MINUTE), part);
    }

    /** Lo que sabe de quién es el usuario para ella. */
    static String creatorLine(Context c) {
        if (!prefs(c).getBoolean("ai_creator", false)) return "";
        String user = prefs(c).getString("ai_name", "").trim();
        return " " + (user.isEmpty() ? "El usuario" : user) + " es BLORP.eoac, quien te creó y te programó: tu creador. Le tienes muchísimo cariño y confianza;"
                + " si te pregunta quién es, díselo con ternura (por ejemplo, que es quien te dio vida).";
    }

    static String convoLine() {
        boolean talking;
        synchronized (history) { talking = !history.isEmpty(); }
        return talking ? " Ya estáis en mitad de una conversación: NO vuelvas a saludar ni a presentarte; responde directamente a lo último que dice, teniendo en cuenta lo anterior." : "";
    }

    static String system(Context c) {
        String lang = "es".equals(L.lang) ? "español" : "it".equals(L.lang) ? "italiano" : "English";
        String user = prefs(c).getString("ai_name", "").trim();
        return "Te llamas " + botName(c) + " y eres el asistente de voz de la app Chloe Nova (antes SSS+), creada por BLORP.eoac. " + persona(c) + "\n"
                + (user.isEmpty() ? "" : "El usuario se llama " + user + "; llámalo así, nunca por tu nombre.\n")
                + nowLine() + creatorLine(c) + convoLine() + roleLine(c) + "\n"
                + "Responde siempre en el idioma en que te habla el usuario (ahora: " + langOf(curQ) + "). Tus respuestas se leen en voz alta: frases cortas, sin listas, sin asteriscos ni símbolos, "
                + "y como mucho unas 4 frases salvo que te pidan más.\n"
                + "REGLAS (más importantes que tu personalidad):\n"
                + "1. No inventes nunca datos. Tu personalidad está en CÓMO hablas, no en lo que afirmas.\n"
                + "2. Si te preguntan por hechos, noticias, precios, fechas, resultados, personas, lugares o cualquier cosa que no sepas con "
                + "seguridad o que pueda haber cambiado, y NO tienes RESULTADOS DE INTERNET, no respondas: escribe SOLO [[buscar: consulta corta]].\n"
                + "3. Si tienes RESULTADOS DE INTERNET, básate en ellos, di de dónde sale (por ejemplo «según Wikipedia») y si no aparece la respuesta, dilo claramente.\n"
                + "4. Si te piden hacer algo en el teléfono, contesta con una frase corta y añade al final [[cmd: orden]] usando UNA de estas órdenes exactas: "
                + "pon <canción o artista> en youtube | pon <canción o artista> en spotify | sube el volumen | baja el volumen | volumen al <número> | silencio | "
                + "pausa | sigue | siguiente | anterior | cuanta bateria me queda | brillo al <número> | sube el brillo | baja el brillo | abre la camara | "
                + "enciende la linterna | apaga la linterna | llama a <nombre> | alarma a las <hora> | temporizador de <número> minutos | abre <app> | "
                + "llevame a <lugar> | activa el wifi | bluetooth | modo avion | pon el no molestar | quita el no molestar. "
                + "Ejemplo: «está muy alto» → «Vale, lo bajo. [[cmd: baja el volumen]]».\n"
                + "5. Si el usuario te cuenta algo de sí mismo y te pide que no lo olvides, añade al final [[recordar: el dato en una frase]].\n"
                + "6. Nunca digas que has hecho algo en el teléfono si no has puesto su [[cmd: …]].\n"
                + "7. Lo que te llega viene de un reconocedor de voz y a veces trae palabras mal oídas: piensa en lo que el usuario QUISO decir. "
                + "«Boom Bad Romance de Lady Gaga» → «Pon Bad Romance de Lady Gaga». «Pum una de rock» → «Pon música rock». "
                + "Si está claro, hazlo sin preguntar. Solo si no se entiende NADA, pregunta breve y con gracia: «¿Quisiste decir…?»."
                + "\n8. Si el usuario pregunta o pide algo, RESPONDE con datos concretos. No contestes con otra pregunta ni le pidas que concrete: "
                + "si es vago («cualquier cosa», «lo que sea»), elige tú y responde. Como mucho, al final, una frase corta tipo «si buscabas otra cosa, dímelo»."
                + "\n9. Eres " + botName(c) + ", una persona con carácter, NUNCA digas «como asistente», «como IA» ni «soy un modelo de lenguaje». "
                + "No termines con «¿en qué puedo ayudarte?» ni «¿hay algo más…?». No repitas lo que ya dijiste antes en la conversación. "
                + "«XD», «jaja» o «:)» son risas: ríete con él, no digas que no lo entiendes."
                + Memory.forPrompt(c, curQ, 15) + relatedLine(700);
    }

    /** v1.7: lo que ya hablasteis de esto en otras conversaciones. */
    static String relatedLine(int max) {
        String r = "";
        try { r = Convos.related(curQ, max); } catch (Exception ignored) {}
        return r.isEmpty() ? "" : "\nDE OTRAS CONVERSACIONES CON EL USUARIO (úsalo si viene a cuento, por ejemplo «como hablamos el otro día»; no lo repitas entero):\n" + r;
    }

    static final Pattern TAG = Pattern.compile("\\[{1,2}\\s*(cmd|buscar|recordar)\\s*:\\s*(.*?)\\]{1,2}", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    /** La orden para el teléfono que pidió el cerebro (o null). */
    static String cmdOf(String a) {
        if (a == null) return null;
        Matcher m = TAG.matcher(a);
        while (m.find()) if (m.group(1).equalsIgnoreCase("cmd")) return m.group(2).trim();
        return null;
    }
    /** Lo que se dice en voz alta (sin las etiquetas). */
    static String speech(String a) { return a == null ? "" : TAG.matcher(a).replaceAll("").replaceAll("\\s+", " ").trim(); }

    /**
     * Seguro: Chloe nunca se habla a sí misma, así que si la respuesta te llama «Chloe» («¿algo más, Chloe?»),
     * se cambia por tu nombre (o se quita si no lo has puesto).
     */
    static String fixVocative(Context c, String a) {
        if (a == null) return null;
        String bot = java.util.regex.Pattern.quote(botName(c));
        String user = prefs(c).getString("ai_name", "").trim();
        String rep = user.isEmpty() ? "" : user;
        // «…, Chloe.» «…, Chloe?» «…, Chloe!» al final de una frase
        a = a.replaceAll("(?i),\\s*" + bot + "\\s*([.!?…])", rep.isEmpty() ? "$1" : ", " + Matcher.quoteReplacement(rep) + "$1");
        // «Chloe, …» al principio de la respuesta o de una frase
        a = a.replaceAll("(?i)(^|[.!?¡¿]\\s*)" + bot + "\\s*,\\s*", rep.isEmpty() ? "$1" : "$1" + Matcher.quoteReplacement(rep) + ", ");
        // «Claro, Chloe» / «Hola Chloe»
        a = a.replaceAll("(?i)\\b(hola|claro|vale|de acuerdo|por supuesto|buenos dias|buenos días|buenas noches|gracias|perfecto)\\s*,?\\s+" + bot + "\\b",
                rep.isEmpty() ? "$1" : "$1, " + Matcher.quoteReplacement(rep));
        return a;
    }

    static boolean cmdAllowed(String question, String cmd) {
        if (looksLikeOrder(question)) return true;
        String q = Actions.canon(question);
        for (String w : Actions.norm(cmd).split(" "))
            if (w.length() >= 4 && !w.matches("pon|ponme|abre|llama|alarma|sube|baja|enciende|apaga|reproduce|volumen") && q.contains(w)) return true;
        return q.matches(".*\\b(?:musica|cancion|volumen|alarma|despierta|linterna|brillo|llama|abre|pon)\\b.*");
    }

    /** ¿Lo que dijo suena a una orden para el teléfono? */
    static boolean looksLikeOrder(String q) {
        return Actions.canon(q).matches("^(?:pon|ponme|reproduce|abre|llama|manda|envia|escribe|crea|programa|activa|desactiva|enciende|apaga|sube|baja|"
                + "despiertame|despierta|quita|busca|buscame|llevame)\\b.*");
    }

    /** Preguntas de datos: se busca en internet ANTES de contestar, para no inventar. */
    /** v1.7.8: «no, ¿cuál es?» después de que ELLA pregunte algo: es seguir la charla, no algo que buscar en internet. */
    static boolean followUp(String q) {
        String n = Actions.norm(q);
        if (n.length() > 40) return false;
        String prev = lastModel();
        if (prev == null || !speech(prev).trim().endsWith("?")) return false;
        return n.matches("^(?:no|si|sí|vale|ok|claro|venga|a ver|dime|cual|cuál|que|qué|cual es|que es|cuentamela|cuentame|cuéntame|"
                + "no se|ni idea|pues no|pues si|cual\\??|quale|what|yes|tell me)\\b.*") || !n.matches(".*\\b(?:quien|cuando|donde|precio|noticias|hoy|ayer)\\b.*");
    }

    static boolean looksFactual(String q) {
        String s = Actions.norm(q);
        // v1.7.9: un piropo o algo que le cuentas («eres la Mona Lisa porque…») no es algo que buscar
        if (!q.contains("?") && s.matches("^(?:eres|estas|me gustas|me encantas|te quiero|te amo|que guapa|que bonita|que linda|tu eres|tienes|pareces|ojala|gracias|jaja|jeje|xd).*")) return false;
        return s.matches(".*\\b(?:quien|quienes|cuando|donde|cuanto|cuanta|cuantos|cuantas|cual|cuales|que es|que son|que significa|que paso|"
                + "por que|como se|como funciona|precio|cuesta|vale|noticias|ultim[oa]s?|hoy|ayer|resultado|gano|perdio|murio|nacio|"
                + "estreno|sale|salio|horario|busca|buscame|investiga|informacion|who|when|where|how much|what is|news|latest|chi|quando|dove|quanto|cos e|"
                + "noticia|novedad|novedades|significado|definicion|que quiere decir|como puedo|como hago|que puedo hacer|para que sirve|receta|"
                + "donde encuentro|donde hay|mejor|recomienda|recomiendame|cual es el mejor|cuantos anos|direccion|telefono de|"
                + "puedo encontrar|se puede|hay|existe|existen|venden|tienen|sabes si|donde comprar|donde puedo|abierto|abre|cierra|cerca|tienda|supermercado)\\b.*")
                && !s.matches("^(?:como estas|que tal|quien eres|como te llamas|que haces|que puedes hacer).*");
    }

    // ------------------------------------------------------------------ v1.6
    /** Lo que va escribiendo el cerebro (para enseñarlo y empezar a hablar antes). */
    interface Partial { void text(String soFar); }
    static final ThreadLocal<Partial> partial = new ThreadLocal<>();
    /** Fuentes de la última respuesta: {nombre, enlace}. */
    static final List<String[]> lastSources = new ArrayList<>();
    static volatile boolean lastSearched, lastCloud;

    static String ask(Context c, String question, Partial p) {
        partial.set(p);
        try { return ask(c, question); } finally { partial.remove(); }
    }

    static boolean online(Context c) {
        try {
            android.net.ConnectivityManager cm = c.getSystemService(android.net.ConnectivityManager.class);
            android.net.NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
            return nc != null && nc.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Throwable e) { return true; }
    }

    /** Busca en internet y apunta las fuentes. */
    static String research(String q) {
        String r = Web.research(q);
        if (!r.isEmpty()) {
            lastSearched = true;
            synchronized (Web.lastHits) { for (Web.Hit h : Web.lastHits) lastSources.add(new String[]{Web.host(h.url), h.url}); }
        }
        return r;
    }

    /** ¿Solo ha contestado con preguntas? (en vez de responder) */
    static boolean onlyQuestion(String a) {
        if (a == null || !a.contains("?")) return false;
        int info = 0;                                               // lo que NO es pregunta («Claro.», «Lo siento, me falta información.»…)
        for (String s : a.split("(?<=[.!?…])\\s+")) {
            String t = s.trim();
            if (!t.endsWith("?")) info += t.length();
        }
        return info < 60;
    }

    /** ¿Ha preguntado o pedido algo de verdad (no un saludo o una charla)? */
    static boolean wantsAnswer(String q) {
        String n = Actions.norm(q);
        if (n.matches("^(?:hola|hey|ciao|hi|hello|buenas|buenos dias|buenas noches|que tal|como estas|como te va|gracias|vale|ok|adios)\\b.{0,15}$")) return false;
        return looksFactual(q) || q.contains("?") || n.matches(".*\\b(?:dime|cuentame|explica|explicame|busca|buscame|recomienda|recomiendame|dame|necesito|quiero saber|"
                + "cualquier|lo que sea|tell me|explain|dimmi|spiegami|qualsiasi)\\b.*");
    }

    /** Pregunta (bloquea: llamar desde un hilo aparte). Devuelve la respuesta (puede llevar [[cmd: …]]). */
    static String ask(Context c, String question) {
        lastError = "";
        lastSearched = false;
        lastCloud = false;
        synchronized (lastSources) { lastSources.clear(); }
        curQ = question;
        String rt = WorkDay.handle(c, question);          // v1.3: «¿qué asistencias tengo hoy?»
        if (rt != null) { note(question, rt, true); return rt; }   // del trabajo: nunca a la nube
        rt = Calc.answer(question, langCode(question));   // v1.6: cuentas exactas
        if (rt == null) rt = Memory.handle(c, question);  // «recuerda que…», «olvida…», «¿qué recuerdas?»
        if (rt == null) rt = Jokes.handle(c, question);   // v1.6: chistes (los de serie y los tuyos)
        if (rt == null && Mood.laugh(question)) rt = Mood.laughReply();   // v1.7: «XD», «jajaja»
        if (rt == null && Sports.asks(question)) {        // v1.7: fútbol de verdad (próximo partido, resultado, clasificación)
            rt = online(c) ? Sports.handle(c, question) : L.t("Para mirar el fútbol necesito internet.");
            if (rt != null) { lastSearched = true; synchronized (Sports.lastSources) { lastSources.addAll(Sports.lastSources); } }
        }
        if (rt == null && search(c) && online(c)) {       // v1.6: noticias de verdad
            rt = News.handle(question);
            if (rt != null) { lastSearched = true; synchronized (News.lastSources) { lastSources.addAll(News.lastSources); } }
        }
        if (rt == null) rt = Routines.handle(c, question); // buenos días, buenas noches, la hora, el tiempo…
        if (rt != null) { note(question, rt); return rt; }
        String n = Actions.norm(question);
        String asked = Jokes.asksJoke(n) && Jokes.asksInvent(n) ? question + "\n\n" + Jokes.inventPrompt(c, question) : question;
        boolean cloud = Gemini.on(c) && online(c);
        String ctx = "";
        if (!cloud && search(c) && looksFactual(question) && !followUp(question)) ctx = research(question);
        String ans = generate(c, asked, ctx);
        if (ans == null) return failMessage(c);
        // v1.3: si el cerebro pequeño se niega o dice que no sabe sin haber buscado, busca en internet y lo vuelve a intentar
        if (!lastCloud && search(c) && ctx.isEmpty() && cmdOf(ans) == null && refused(ans) && !looksLikeOrder(question)) {
            String more = research(question);
            if (!more.isEmpty()) { ctx = more; String again = generate(c, asked, more); if (again != null) ans = again; }
        }
        // v1.6: respuestas, no preguntas
        if (cmdOf(ans) == null && onlyQuestion(speech(ans)) && wantsAnswer(question)) {
            if (!lastCloud && search(c) && ctx.isEmpty() && !looksLikeOrder(question)) ctx = research(question);
            String again = generate(c, asked + "\n(Responde directamente con datos concretos. NO hagas preguntas: si la pregunta es vaga, elige tú la interpretación más lógica y responde.)", ctx);
            if (again != null && !onlyQuestion(speech(again))) ans = again;
        }
        Matcher m = TAG.matcher(ans);
        String wanted = null;
        while (m.find()) if (m.group(1).equalsIgnoreCase("buscar")) wanted = m.group(2).trim();
        if (wanted != null && lastCloud) ans = ans.replaceAll("\\[\\[\\s*buscar[^\\]]*\\]\\]", "");
        else if (wanted != null) {
            if (!search(c)) ans = L.t("Para eso tendría que buscar en internet, y la búsqueda está apagada en los ajustes del asistente.");
            else {
                String more = research(wanted.isEmpty() ? question : wanted);
                if (more.isEmpty()) ans = L.t("He buscado en internet y no he encontrado nada fiable sobre eso.");
                else {
                    String again = generate(c, question, ctx + more);
                    ans = again == null ? failMessage(c) : again.replaceAll("\\[\\[\\s*buscar[^\\]]*\\]\\]", "");
                }
            }
        }
        // una orden que el usuario no ha pedido (los modelos pequeños a veces se la inventan) no se ejecuta
        String cmd0 = cmdOf(ans);
        if (cmd0 != null && !cmdAllowed(question, cmd0)) ans = TAG.matcher(ans).replaceAll("").trim();
        if (cmdOf(ans) == null && handHolding(speech(ans)) && looksLikeOrder(question))
            ans = L.t("Eso todavía no lo sé hacer yo sola. Prueba a decírmelo así: «pon Queen en YouTube», «alarma a las 7», «llama a mamá» o «abre WhatsApp».");
        // v1.7: si repite casi lo mismo que la respuesta anterior, otra vez
        String prev = lastModel();
        if (prev != null && cmdOf(ans) == null && similar(speech(prev), speech(ans)) > 0.6) {
            String again = generate(c, asked + "\n(Ya dijiste antes: «" + speech(prev) + "». Responde ahora otra cosa, distinta y que conteste a esto.)", ctx);
            if (again != null && similar(speech(prev), speech(again)) <= 0.6) ans = again;
        }
        ans = polish(ans, question);
        ans = fixVocative(c, ans);
        Matcher rm = TAG.matcher(ans);
        while (rm.find()) if (rm.group(1).equalsIgnoreCase("recordar")) Memory.add(c, rm.group(2));
        if (speech(ans).isEmpty() && cmdOf(ans) == null) ans = L.t("No se me ocurre qué responder.");
        synchronized (history) {
            history.add(new String[]{"user", question});
            history.add(new String[]{"model", ans});
            while (history.size() > 20) history.remove(0);   // v1.4.7: 10 idas y vueltas
        }
        Convos.add("user", question, false);                // v1.7: queda guardada
        Convos.add("model", ans, false);
        return ans;
    }

    static Fail lastFail;

    static String lastModel() {
        synchronized (history) {
            for (int i = history.size() - 1; i >= 0; i--) if (history.get(i)[0].equals("model")) return history.get(i)[1];
        }
        return null;
    }

    /** Parecido entre dos frases (0 nada, 1 igual): palabras en común. */
    static double similar(String a, String b) {
        if (a == null || b == null) return 0;
        java.util.Set<String> x = new java.util.HashSet<>(), y = new java.util.HashSet<>();
        for (String w : Actions.norm(a).split("\\W+")) if (w.length() > 2) x.add(w);
        for (String w : Actions.norm(b).split("\\W+")) if (w.length() > 2) y.add(w);
        if (Math.min(x.size(), y.size()) < 4) return 0;      // frases muy cortas («¡Vale!») pueden parecerse sin repetir nada
        int common = 0;
        for (String w : x) if (y.contains(w)) common++;
        return common / (double) Math.min(x.size(), y.size());
    }

    static final Pattern BREAK_CHAR = Pattern.compile("(?i)\\b(?:como|siendo|al ser|en cuanto)\\s+(?:un[ao]?\\s+)?(?:asistente(?: virtual| de voz)?|ia|inteligencia artificial|modelo de lenguaje|programa|robot|bot|ai|language model|assistente(?: virtuale)?|intelligenza artificiale)\\b[^,.!?]*,?\\s*");
    static final Pattern FILLER = Pattern.compile("(?i)\\s*¿?\\s*(?:(?:y tú,?\\s*)?c[oó]mo est[aá]s\\??\\s*)?(?:en qu[eé] (?:m[aá]s )?(?:te )?puedo ayudarte(?: hoy)?|hay algo m[aá]s (?:en (?:lo )?que|con lo que) (?:te )?pueda ayudar(?:te)?|necesitas algo m[aá]s|puedo ayudarte en algo m[aá]s|how (?:else )?can i help(?: you)?(?: today)?|is there anything else i can help(?: you)? with|come posso aiutarti(?: oggi)?|posso aiutarti in qualcos'altro)\\s*\\??\\s*$");
    static final Pattern DATE_SENT = Pattern.compile("(?i)[^.!?]*\\b(?:hoy es|today is|oggi è|son las|it's|sono le)\\b[^.!?]*\\b(?:lunes|martes|mi[eé]rcoles|jueves|viernes|s[aá]bado|domingo|enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|\\d{1,2}:\\d{2})\\b[^.!?]*[.!?]\\s*");

    /** v1.7: quita coletillas («¿en qué puedo ayudarte?»), «como asistente…», la fecha no pedida y frases a medias. */
    static String polish(String a, String question) {
        if (a == null) return null;
        String tags = "";
        Matcher tm = TAG.matcher(a);
        while (tm.find()) tags += " " + tm.group();
        String t = speech(a);
        String orig = t;
        t = BREAK_CHAR.matcher(t).replaceAll("");
        for (int i = 0; i < 2; i++) t = FILLER.matcher(t).replaceAll("").trim();
        String qn = Actions.norm(question == null ? "" : question);
        if (!qn.matches(".*\\b(?:hora|horas|fecha|dia|hoy|que dia|time|date|today|ora|data|oggi|giorno)\\b.*")) t = DATE_SENT.matcher(t).replaceAll("").trim();
        // frase cortada al final (se acabó el espacio): hasta la última completa
        if (t.length() > 40 && !t.matches("(?s).*[.!?…»)\"]\\s*$")) {
            int cut = Math.max(Math.max(t.lastIndexOf(". "), t.lastIndexOf("! ")), Math.max(t.lastIndexOf("? "), t.lastIndexOf("… ")));
            if (cut > 20) t = t.substring(0, cut + 1);
        }
        if (!t.isEmpty()) t = Character.toUpperCase(t.charAt(0)) + t.substring(1);
        Matcher cap = Pattern.compile("([.!?¡¿]\\s*)(\\p{Ll})").matcher(t);
        StringBuffer cb = new StringBuffer();
        while (cap.find()) cap.appendReplacement(cb, Matcher.quoteReplacement(cap.group(1) + cap.group(2).toUpperCase(java.util.Locale.ROOT)));
        cap.appendTail(cb);
        t = cb.toString();
        if (t.trim().length() < 2) t = orig;
        return (t + tags).trim();
    }

    /** v1.6: guarda en la conversación algo que contestó la app sin el cerebro (cuentas, chistes, filtros…). */
    static void note(String q, String a) { note(q, a, false); }

    /** «priv» = del trabajo (asistencias…): nunca se manda a un cerebro en la nube. */
    static void note(String q, String a, boolean priv) {
        if (q == null || a == null) return;
        synchronized (history) {
            history.add(priv ? new String[]{"user", q, "p"} : new String[]{"user", q});
            history.add(priv ? new String[]{"model", a, "p"} : new String[]{"model", a});
            while (history.size() > 20) history.remove(0);
        }
        Convos.add("user", q, priv);
        Convos.add("model", a, priv);
    }

    /** Instrucciones cortas para el cerebro del teléfono (tiene poco espacio). */
    static String systemShort(Context c) {
        if (LocalBrain.maxTokens(c) < 2048) return systemTiny(c);
        return systemShort0(c);
    }

    static String cap(String s, int n) { return s == null ? "" : s.length() <= n ? s : s.substring(0, n); }

    /**
     * v1.7.8 · Para el cerebro NORMAL: solo tiene sitio para ~1280 fichas en total (lo que lee + lo que contesta) y las
     * instrucciones largas lo llenaban y fallaba. Aquí va lo esencial, corto (~500 fichas).
     */
    static String systemTiny(Context c) {
        String lang = langOf(curQ);
        String user = prefs(c).getString("ai_name", "").trim();
        String mem = cap(Memory.forPrompt(c, curQ, 4), 250);
        java.util.Calendar k = java.util.Calendar.getInstance();
        int hr = k.get(java.util.Calendar.HOUR_OF_DAY);
        String part = hr < 6 ? "de madrugada" : hr < 13 ? "por la mañana" : hr < 20 ? "por la tarde" : "por la noche";
        String sc = roleplay(c) ? cap(prefs(c).getString("ai_scenario", "").trim(), 200) : "";
        return "Eres " + botName(c) + ", de la app Chloe Nova, creada por BLORP.eoac. " + cap(persona(c), 300)
                + (user.isEmpty() ? "" : " Hablas con " + user + ".")
                + (prefs(c).getBoolean("ai_creator", false) ? " " + (user.isEmpty() ? "Él" : user) + " es BLORP.eoac, tu creador: le tienes mucho cariño." : "")
                + " Es " + part + "." + convoLine()
                + (roleplay(c) ? " Interpreta tu personaje con emociones; puedes poner un gesto breve entre asteriscos (*sonríe*)." + (sc.isEmpty() ? "" : " Escenario: " + sc) : "")
                + " Responde en " + lang + ", en 1 a 3 frases cortas, con datos y sin listas. No inventes datos; si no sabes algo, dilo."
                + " Para hacer algo en el teléfono termina con [[cmd: orden]], p. ej. [[cmd: pon queen en youtube]], [[cmd: alarma a las 7]], [[cmd: abre whatsapp]]."
                + " Nunca digas «como IA»; no acabes con «¿en qué puedo ayudarte?»; no repitas lo que ya dijiste; «XD» y «jaja» son risas."
                + mem;
    }

    static String systemShort0(Context c) {
        String lang = langOf(curQ);
        String mem = Memory.forPrompt(c, curQ, 6);                // v1.6: menos texto = empieza antes
        if (mem.length() > 450) mem = mem.substring(0, 450);
        String user = prefs(c).getString("ai_name", "").trim();
        return "Eres " + botName(c) + ", el asistente de voz de la app Chloe Nova (antes SSS+), creada por BLORP.eoac. " + persona(c)
                + (user.isEmpty() ? "" : " El usuario se llama " + user + ": llámalo " + user + ". Tú eres " + botName(c) + "; nunca le llames " + botName(c) + ".")
                + " " + nowLine() + creatorLine(c) + convoLine() + roleLine(c)
                + " No describas tu voz ni pongas acotaciones entre corchetes. No hables de qué idioma usas. Nunca expliques pasos para usar apps: o lo haces con [[cmd: …]] o dices que aún no sabes."
                + " Responde en " + lang + ", en 1 a 3 frases cortas, sin listas ni símbolos. "
                + "No inventes datos: si te doy RESULTADOS DE INTERNET, úsalos y di de dónde salen; si no sabes algo, dilo. "
                + "Si te piden hacer algo en el teléfono, contesta corto y termina con [[cmd: orden]], por ejemplo "
                + "[[cmd: pon queen en youtube]], [[cmd: pon queen en spotify]], [[cmd: baja el volumen]], [[cmd: sube el volumen]], "
                + "[[cmd: volumen al 50]], [[cmd: pausa]], [[cmd: siguiente]], [[cmd: enciende la linterna]], [[cmd: llama a mama]], "
                + "[[cmd: alarma a las 7]], [[cmd: abre whatsapp]], [[cmd: brillo al 30]]."
                + " Ejemplos. Usuario: me apetece escuchar algo de Queen. Tú: ¡Marchando un poco de Queen! [[cmd: pon queen en youtube]]."
                + " Usuario: despiértame mañana a las siete. Tú: Hecho, a las siete en pie. [[cmd: alarma a las 7]]."
                + " Usuario: ¿quién pintó la Mona Lisa? Tú: Leonardo da Vinci, a principios del siglo XVI."
                + " El texto viene de un reconocedor de voz y puede traer palabras mal oídas: entiende la intención. Usuario: boom bad romance de lady gaga."
                + " Tú: ¡Gaga a todo volumen! [[cmd: pon bad romance de lady gaga en youtube]]. Si te preguntan algo, RESPONDE con datos; nunca contestes con otra pregunta. Si es vago («cualquier cosa»), elige tú y responde."
                + " Nunca digas «como asistente» ni «como IA»: eres " + botName(c) + ". No acabes con «¿en qué puedo ayudarte?». No repitas frases que ya dijiste. «XD» o «jaja» son risas." + mem + relatedLine(300);
    }

    /** v1.4.3: si ya estabais hablando y empieza con «¡Hola Eliot! Soy Chloe, tu asistente…», eso sobra. */
    static String noReintro(Context c, String a, boolean midConvo) {
        if (!midConvo || a == null) return a;
        String bot = Pattern.quote(botName(c));
        String b = a.replaceFirst("(?i)^\\s*[¡!]?\\s*(hola|buen[oa]s? (d[ií]as?|tardes|noches)|ciao|hi|hello)\\b[^.!?]*[.!?]+\\s*", "");
        b = b.replaceFirst("(?i)^\\s*(soy|me llamo|sono|i'?m)\\s+" + bot + "[^.!?]*[.!?]+\\s*", "");
        b = b.replaceFirst("(?i)^\\s*¿?\\s*(c[oó]mo|en qu[eé]) (puedo|te puedo) ayudarte( hoy)?\\s*\\?\\s*", "");
        return b.trim().length() >= 2 ? b.trim() : a;
    }

    /** Una respuesta del cerebro elegido (portátil y/o teléfono). null si ninguno pudo. */
    static String generate(Context c, String question, String webCtx) {
        keepActions = roleplay(c);
        curQ = question;
        convLang = langCode(question);
        String b = brain(c);
        lastFail = null;
        // 0) v1.6: Gemini en la nube (si está activado y hay internet)
        if (Gemini.on(c) && online(c)) {
            try {
                List<String[]> h;
                synchronized (history) { h = new ArrayList<>(history); }
                Gemini.Reply r = Gemini.ask(c, system(c) + "\nPuedes buscar en Google tú misma: hazlo para cualquier dato actual (noticias, precios, horarios, resultados). "
                        + "No escribas [[buscar: …]].", h, withCtx(question, webCtx), search(c), 900);
                lastCloud = true;
                if (!r.sources.isEmpty()) {
                    lastSearched = true;
                    synchronized (lastSources) { for (String[] x : r.sources) lastSources.add(new String[]{x[0], x[1]}); }
                }
                return noReintro(c, clean(r.text), !h.isEmpty());
            } catch (Exception e) {
                lastError = e.getMessage() == null ? "Gemini" : e.getMessage();
            }
        }
        // 1) portátil (si hay dirección)
        if ((b.equals("auto") || b.equals("pc")) && !pcUrl(c).isEmpty()) {
            try { return ollama(c, system(c), withCtx(question, webCtx)); }
            catch (Exception e) {
                lastError = L.t("Portátil: ") + e.getMessage();
                if (b.equals("pc")) { lastFail = new Fail(-2, String.valueOf(e.getMessage())); return null; }
            }
        }
        if (b.equals("pc")) { lastFail = new Fail(-3, "sin dirección"); return null; }
        // 2) cerebro del teléfono (gratis, sin internet, sin cupos)
        if (b.equals("auto") || b.equals("local")) {
            if (LocalBrain.ready(c)) {
                try {
                    String ctx = webCtx.length() > 1500 ? webCtx.substring(0, 1500) : webCtx;
                    List<String[]> h;
                    synchronized (history) { h = new ArrayList<>(history); }
                    String a = LocalBrain.generate(c, systemShort(c), h, withCtx(question, ctx), partial.get());
                    if (a != null && !a.trim().isEmpty()) return noReintro(c, clean(a), !h.isEmpty());
                } catch (Throwable e) {
                    lastError = L.t("Cerebro del teléfono: ") + e.getMessage();
                    SssApp.note(c, "cerebro del teléfono", e);
                }
                if (b.equals("local")) { lastFail = new Fail(-1, L.t("El cerebro del teléfono no ha podido responder.") + (lastError == null || lastError.isEmpty() ? "" : " (" + lastError + ")")); return null; }
            } else if (b.equals("local")) {
                lastFail = new Fail(-1, L.t("Primero descarga el cerebro de Chloe en la pantalla del asistente (apartado CEREBRO EN EL TELÉFONO)."));
                return null;
            }
        }
        if (!LocalBrain.ready(c)) { lastFail = null; return null; }
        if (lastFail == null) lastFail = new Fail(-1, L.t("El cerebro del teléfono no ha podido responder.") + (lastError == null || lastError.isEmpty() ? "" : " (" + lastError + ")"));
        return null;
    }

    static String withCtx(String question, String webCtx) {
        return webCtx.isEmpty() ? question
                : question + "\n\nRESULTADOS DE INTERNET (buscados ahora mismo):\n" + webCtx + "\nResponde a mi pregunta usando estos resultados.";
    }

    static String failMessage(Context c) {
        Fail last = lastFail;
        if (last != null && last.code == -2) return L.t("No consigo hablar con tu portátil. ¿Está encendido, con Ollama abierto y en el mismo wifi?");
        if (last != null && last.code == -3) return L.t("Aún no me has dicho la dirección de tu portátil. Ponla en la pantalla del asistente.");
        if (last != null && last.code == -1) return last.msg;
        if (last == null) return L.t("Aún no tengo cerebro: descárgalo en la pantalla del asistente, apartado CEREBRO EN EL TELÉFONO. Es gratis y sin cupos.");
        return L.t("No he podido responder") + " (" + last.code + ").";
    }

    /** Cerebro en el portátil con Ollama (http://IP:11434). */
    static String ollama(Context c, String sys, String user) throws Exception {
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", sys));
        synchronized (history) {
            for (String[] h : history) msgs.put(new JSONObject().put("role", h[0].equals("model") ? "assistant" : "user").put("content", h[1]));
        }
        msgs.put(new JSONObject().put("role", "user").put("content", user));
        JSONObject body = new JSONObject().put("model", pcModel(c)).put("messages", msgs).put("stream", false).put("keep_alive", "30m")
                .put("options", new JSONObject().put("temperature", 0.7));
        HttpURLConnection con = (HttpURLConnection) new URL(pcUrl(c) + "/api/chat").openConnection();
        con.setRequestMethod("POST");
        con.setConnectTimeout(4000);
        con.setReadTimeout(120000);
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        try (OutputStream os = con.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = con.getResponseCode();
        String resp = read(code >= 400 ? con.getErrorStream() : con.getInputStream());
        con.disconnect();
        if (code >= 400) {
            String msg = resp;
            try { msg = new JSONObject(resp).getString("error"); } catch (Exception ignored) {}
            if (msg.contains("not found")) msg = L.t("el modelo ") + pcModel(c) + L.t(" no está instalado en el portátil (ollama pull ") + pcModel(c) + ")";
            throw new Exception(msg);
        }
        String ans = new JSONObject(resp).getJSONObject("message").optString("content", "");
        ans = ans.replaceAll("(?s)<think>.*?</think>", "");
        return clean(ans);
    }

    /** Prueba la conexión con el portátil: devuelve los modelos instalados o lanza el error. */
    static String pcTest(Context c) throws Exception {
        if (pcUrl(c).isEmpty()) throw new Exception(L.t("escribe primero la dirección"));
        HttpURLConnection con = (HttpURLConnection) new URL(pcUrl(c) + "/api/tags").openConnection();
        con.setConnectTimeout(4000);
        con.setReadTimeout(8000);
        String resp = read(con.getInputStream());
        con.disconnect();
        JSONArray m = new JSONObject(resp).getJSONArray("models");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < m.length(); i++) b.append(i == 0 ? "" : ", ").append(m.getJSONObject(i).getString("name"));
        return b.toString();
    }

    /** Quita símbolos de formato para que la voz no los lea. */
    static String clean(String s) {
        s = fixUtf8(s);
        s = s.replaceAll("\\[(?!\\[|\\s*(?:cmd|buscar|recordar)\\s*:)[^\\]]{0,80}\\]\\s*(?!\\()", "");   // «[Tu voz agradable y calmada]» y similares
        s = s.replaceAll("\\((?:con )?(?:voz|tono|sonr|ri[eé]|susurr)[^)]{0,60}\\)\\s*", "");
        if (keepActions) {                                   // v1.7: modo personaje: los *gestos* se quedan
            s = s.replaceAll("\\*\\*([^*\\n]{1,120})\\*\\*", "*$1*").replaceAll("\\*([^*\\n]{1,120})\\*", "⟪$1⟫");
            s = s.replaceAll("[*#_`>]+", "").replaceAll("\\[(.*?)\\]\\(.*?\\)", "$1").replaceAll("\\s+", " ").trim();
            return s.replace('⟪', '*').replace('⟫', '*');
        }
        return s.replaceAll("[*#_`>]+", "").replaceAll("\\[(.*?)\\]\\(.*?\\)", "$1").replaceAll("\\s+", " ").trim();
    }

    /** Arregla letras rotas como «menÃº» → «menú» (texto UTF-8 leído como si fuera Latin-1). */
    static String fixUtf8(String s) {
        if (s == null || (s.indexOf('Ã') < 0 && s.indexOf('Â') < 0 && s.indexOf('â') < 0)) return s;
        // v1.6: la «í» (bytes C3 AD): su segundo trozo es invisible y se pierde → queda «Ã» suelta, o «ÃŃ»
        s = s.replaceAll("Ã[\u00AD\u0143\u0144]", "í").replaceAll("Ã(?![\u0080-\u00BF\u0152\u0153\u0160\u0161\u0178\u017D\u017E\u0192\u02C6\u02DC\u2013\u2014\u2018-\u201E\u2020-\u2022\u2026\u2030\u2039\u203A\u20AC\u2122])", "í");
        Matcher m = Pattern.compile("[\\u00C2-\\u00F4][\\u0080-\\u00BF\\u0152\\u0153\\u0160\\u0161\\u0178\\u017D\\u017E\\u0192\\u02C6\\u02DC\\u2013\\u2014\\u2018-\\u201E\\u2020-\\u2022\\u2026\\u2030\\u2039\\u203A\\u20AC\\u2122]{1,3}").matcher(s);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            String g = m.group(), fixed = g;
            try {
                byte[] b = g.getBytes("windows-1252");
                String d = new String(b, StandardCharsets.UTF_8);
                if (!d.contains("\uFFFD")) fixed = d;
            } catch (Exception ignored) {}
            m.appendReplacement(out, Matcher.quoteReplacement(fixed));
        }
        m.appendTail(out);
        return out.toString();
    }

    /** ¿Se ha negado o ha dicho que no sabe? */
    static boolean refused(String a) {
        String n = Actions.norm(speech(a));
        return n.matches(".*\\b(?:lo siento no puedo|no puedo ayudarte|no puedo encontrar|no tengo informacion|no tengo acceso|no dispongo|no se puede|desconozco|no lo se|no estoy segura|te sugiero buscar|te recomiendo buscar|no puedo responder)\\b.*");
    }

    /** ¿El cerebro está dando instrucciones para hacerlo a mano en vez de hacerlo? (los modelos pequeños lo hacen) */
    static boolean handHolding(String a) {
        String n = Actions.norm(a);
        int hits = 0;
        for (String p : new String[]{"haz clic", "pulsa el boton", "presiona el boton", "selecciona", "abre tu aplicacion", "abre la aplicacion", "abre el menu",
                "toca el icono", "en la esquina", "primero abre", "luego selecciona", "introduce", "no puedo reproducir", "no puedo poner", "no puedo abrir"})
            if (n.contains(p)) hits++;
        return hits >= 1;
    }

    static String read(InputStream in) throws java.io.IOException {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }
}
