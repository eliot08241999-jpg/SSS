package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * v1.7.4 · HISTORIAL DEL ESTUDIO: cada dibujo se guarda dentro de la app 24 horas. Si no lo guardas en la galería
 * ni lo fijas (📌), a las 24 h se borra solo. También puedes borrarlo antes.
 *
 * v1.7.6 · Y ES TAMBIÉN LA COLA: en cuanto pides un dibujo, entra aquí («en cola») con todo lo necesario para hacerlo
 * (descripción, estilo, tamaño, pasos, semilla…). El servicio los va dibujando de uno en uno. Si algo se corta
 * (Android cierra la app, falta memoria, lo paras), no se pierde: queda con un botón ↻ para volver a hacerlo.
 */
public class DrawHistory {
    static final long TTL = 24L * 3600 * 1000;
    public static final String QUEUED = "queued", DRAWING = "drawing", DONE = "done", FAILED = "failed", STOPPED = "stopped";

    public static final class Item {
        public String id, prompt = "", negative = "", model = "", status = DONE, error = "", init = "";
        public long seed = -1, created, batch;
        public int w = 512, h = 512, steps = 20;
        public float cfg = 7, strength = 0.6f;
        public boolean pinned, saved;
        File png(Context c) { return new File(dir(c), id + ".png"); }
        File meta(Context c) { return new File(dir(c), id + ".json"); }
        /** v1.7.6: el progreso guardado paso a paso (para seguir donde se cortó). */
        File ckpt(Context c) { return new File(dir(c), id + ".ckpt"); }
        boolean done() { return DONE.equals(status); }
        boolean unfinished() { return !DONE.equals(status); }
        /** Milisegundos que le quedan (o -1 si está fijado). */
        long left() { return pinned ? -1 : Math.max(0, created + TTL - System.currentTimeMillis()); }

        SdEngine.Job job(Context c) {
            SdEngine.Job j = new SdEngine.Job();
            j.model = model; j.prompt = prompt; j.negative = negative; j.width = w; j.height = h; j.steps = steps; j.cfg = cfg; j.strength = strength; j.seed = seed;
            if (!init.isEmpty()) { File f = new File(dir(c), init); if (f.exists()) j.init = BitmapFactory.decodeFile(f.getPath()); }
            return j;
        }
    }

    static File dir(Context c) { File d = new File(c.getFilesDir(), "draw_history"); d.mkdirs(); return d; }

    // ---------------- en memoria (se lee del disco una vez) ----------------
    static List<Item> cache;

    static synchronized List<Item> items(Context c) {
        if (cache != null) return cache;
        cache = new ArrayList<>();
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".json"));
        if (fs != null) for (File f : fs) {
            try {
                JSONObject o = new JSONObject(new String(java.nio.file.Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
                Item it = new Item();
                it.id = o.getString("id"); it.prompt = o.optString("prompt"); it.negative = o.optString("negative"); it.model = o.optString("model");
                it.seed = o.optLong("seed", -1); it.created = o.optLong("created"); it.batch = o.optLong("batch");
                it.pinned = o.optBoolean("pinned"); it.saved = o.optBoolean("saved");
                it.status = o.optString("status", DONE); it.error = o.optString("error"); it.init = o.optString("init");
                it.w = o.optInt("w", 512); it.h = o.optInt("h", 512); it.steps = o.optInt("steps", 20);
                it.cfg = (float) o.optDouble("cfg", 7); it.strength = (float) o.optDouble("strength", 0.6);
                if (it.done() && !it.png(c).exists()) { f.delete(); continue; }
                cache.add(it);
            } catch (Exception e) { f.delete(); }
        }
        return cache;
    }

    static void write(Context c, Item it) {
        try {
            JSONObject o = new JSONObject().put("id", it.id).put("prompt", it.prompt).put("negative", it.negative).put("model", it.model)
                    .put("seed", it.seed).put("created", it.created).put("batch", it.batch).put("pinned", it.pinned).put("saved", it.saved)
                    .put("status", it.status).put("error", it.error).put("init", it.init)
                    .put("w", it.w).put("h", it.h).put("steps", it.steps).put("cfg", (double) it.cfg).put("strength", (double) it.strength);
            File tmp = new File(dir(c), it.id + ".json.tmp");
            java.nio.file.Files.write(tmp.toPath(), o.toString().getBytes(StandardCharsets.UTF_8));
            if (!tmp.renameTo(it.meta(c))) { it.meta(c).delete(); tmp.renameTo(it.meta(c)); }
        } catch (Exception ignored) {}
    }

    // ---------------- la cola ----------------
    /** Mete «n» dibujos en la cola (con semilla fija: semilla, +1, +2…). Devuelve el número de tanda. */
    static synchronized long enqueue(Context c, SdEngine.Job t, int n) {
        long batch = System.currentTimeMillis();
        String init = "";
        if (t.init != null) {
            init = "init_" + Long.toString(batch, 36) + ".png";
            try (FileOutputStream os = new FileOutputStream(new File(dir(c), init))) { t.init.compress(Bitmap.CompressFormat.PNG, 100, os); } catch (Exception e) { init = ""; }
        }
        for (int i = 0; i < n; i++) {
            Item it = new Item();
            it.created = batch + i;                 // en orden
            it.batch = batch;
            it.id = Long.toString(it.created, 36) + Integer.toString((int) (Math.random() * 1296), 36);
            it.prompt = t.prompt; it.negative = t.negative == null ? "" : t.negative; it.model = t.model;
            it.w = t.width; it.h = t.height; it.steps = t.steps; it.cfg = t.cfg; it.strength = t.strength;
            it.seed = t.seed >= 0 ? t.seed + i : -1;
            it.init = init;
            it.status = QUEUED;
            items(c).add(it);
            write(c, it);
        }
        return batch;
    }

    /** El siguiente que hay que dibujar (el más antiguo en cola), ya marcado como «dibujando». */
    static synchronized Item takeNext(Context c) {
        Item best = null;
        for (Item it : items(c)) if (QUEUED.equals(it.status) && (best == null || it.created < best.created)) best = it;
        if (best != null) { best.status = DRAWING; best.error = ""; write(c, best); }
        return best;
    }

    static synchronized int count(Context c, String status) {
        int n = 0;
        for (Item it : items(c)) if (status.equals(it.status)) n++;
        return n;
    }

    static synchronized void finish(Context c, Item it, Bitmap b, long seed) {
        try (FileOutputStream os = new FileOutputStream(it.png(c))) { b.compress(Bitmap.CompressFormat.PNG, 100, os); }
        catch (Exception e) { fail(c, it, FAILED, L.t("no se pudo guardar")); return; }
        it.status = DONE;
        it.seed = seed;
        it.error = "";
        it.created = System.currentTimeMillis();       // las 24 h cuentan desde que está hecho
        write(c, it);
    }

    static synchronized void fail(Context c, Item it, String status, String why) {
        it.status = status;
        it.error = why == null ? "" : why;
        write(c, it);
    }

    /** Vuelve a ponerlo en la cola (botón ↻). */
    static synchronized void retry(Context c, Item it) {
        it.status = QUEUED;
        it.error = "";
        write(c, it);
    }

    /** ↻ todos los que no se terminaron. */
    static synchronized int retryAll(Context c) {
        int n = 0;
        for (Item it : items(c)) if (FAILED.equals(it.status) || STOPPED.equals(it.status)) { retry(c, it); n++; }
        return n;
    }

    /** Lo que quedaba en cola cuando se para todo. */
    static synchronized void stopQueued(Context c) {
        for (Item it : items(c)) if (QUEUED.equals(it.status)) fail(c, it, STOPPED, L.t("parado"));
    }

    /**
     * Si el servicio NO está dibujando, lo que figuraba «dibujando» o «en cola» se quedó a medias (Android cerró la app):
     * pasa a «parado» con su botón ↻. Lo llama la pantalla al abrirse.
     */
    static synchronized int reconcile(Context c) {
        if (DrawService.running) return 0;
        int n = 0;
        for (Item it : items(c))
            if (DRAWING.equals(it.status) || QUEUED.equals(it.status)) { fail(c, it, STOPPED, L.t("se cortó a medias")); n++; }
        return n;
    }

    // ---------------- historial ----------------
    /** Todos (los más nuevos primero), borrando antes los caducados. */
    static synchronized List<Item> all(Context c) {
        cleanup(c);
        List<Item> out = new ArrayList<>(items(c));
        out.sort((a, b) -> Long.compare(b.created, a.created));
        return out;
    }

    /** Los de una tanda, en orden. */
    static synchronized List<Item> batch(Context c, long batch) {
        List<Item> out = new ArrayList<>();
        for (Item it : items(c)) if (it.batch == batch) out.add(it);
        out.sort((a, b) -> Long.compare(a.batch == b.batch ? a.id.compareTo(b.id) : 0, 0));
        out.sort((a, b) -> a.id.compareTo(b.id));
        return out;
    }

    /** Borra lo terminado (o fallido) que lleva más de 24 h sin fijar. Lo que está en cola no caduca. */
    static synchronized int cleanup(Context c) {
        int n = 0;
        java.util.Iterator<Item> i = items(c).iterator();
        while (i.hasNext()) {
            Item it = i.next();
            if (it.pinned || QUEUED.equals(it.status) || DRAWING.equals(it.status)) continue;
            if (System.currentTimeMillis() - it.created > TTL) { it.png(c).delete(); it.meta(c).delete(); it.ckpt(c).delete(); i.remove(); n++; }
        }
        cleanInits(c);
        return n;
    }

    /** Las imágenes de partida que ya no usa nadie. */
    static void cleanInits(Context c) {
        File[] fs = dir(c).listFiles((d, n) -> n.startsWith("init_"));
        if (fs == null) return;
        java.util.Set<String> used = new java.util.HashSet<>();
        for (Item it : items(c)) if (!it.init.isEmpty()) used.add(it.init);
        for (File f : fs) if (!used.contains(f.getName())) f.delete();
    }

    static Bitmap load(Context c, Item it, int maxSide) {
        if (!it.done()) return null;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            if (maxSide > 0) {
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(it.png(c).getPath(), o);
                int s = 1;
                while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2;
                o = new BitmapFactory.Options();
                o.inSampleSize = s;
            }
            return BitmapFactory.decodeFile(it.png(c).getPath(), o);
        } catch (Throwable e) { return null; }
    }

    static synchronized void delete(Context c, Item it) {
        if (DrawService.current == it) DrawService.cancelCurrent();
        it.png(c).delete(); it.meta(c).delete(); it.ckpt(c).delete();
        items(c).remove(it);
    }

    static synchronized void pin(Context c, Item it, boolean on) { it.pinned = on; write(c, it); }

    /** A la galería (Imágenes/SSS+). */
    static boolean toGallery(Context c, Item it) {
        Bitmap b = load(c, it, 0);
        if (b == null) return false;
        boolean ok = DrawService.saveToGallery(c, b);
        if (ok) { it.saved = true; write(c, it); }
        return ok;
    }

    /** v1.7.6: ¿en qué paso se quedó? (lee solo la cabecera del punto de guardado) -1 si no hay */
    static int reached(Context c, Item it) {
        File f = it.ckpt(c);
        if (!f.exists()) return -1;
        try (java.io.DataInputStream in = new java.io.DataInputStream(new java.io.FileInputStream(f))) {
            if (in.readInt() != SdEngine.CK_MAGIC) return -1;
            in.readUTF();
            return in.readInt();
        } catch (Exception e) { return -1; }
    }

    /** La etiqueta pequeña de cada dibujo. */
    static String leftText(Context c, Item it) {
        switch (it.status) {
            case QUEUED: { int r = reached(c, it); return "⏸ " + L.t("en cola") + (r > 0 ? " · " + r + "/" + it.steps : ""); }
            case DRAWING: return "🎨 " + (DrawService.current == it ? DrawService.percent + "%" : L.t("dibujando"));
            case FAILED: case STOPPED: {
                int r = reached(c, it);
                return (FAILED.equals(it.status) ? "⚠ " + L.t("falló") : "⏹ " + L.t("a medias")) + (r > 0 ? " · " + r + "/" + it.steps + " 💾" : "") + " ↻";
            }
        }
        if (it.pinned) return "📌";
        long ms = it.left();
        long h = ms / 3_600_000L, m = (ms / 60_000L) % 60;
        return "⏳ " + (h > 0 ? h + " h" : m + " min");
    }
}
