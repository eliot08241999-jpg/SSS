package com.aplauso.encuentra;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v1.3 · Estudio de dibujo: convierte el texto en las "fichas" que entiende Stable Diffusion
 * (el tokenizador BPE de CLIP, con vocab.json y merges.txt del propio modelo). 77 fichas como máximo.
 */
public class SdTokenizer {
    static final int BOS = 49406, EOS = 49407, LEN = 77;
    static final Pattern PAT = Pattern.compile(
            "<\\|startoftext\\|>|<\\|endoftext\\|>|'s|'t|'re|'ve|'m|'ll|'d|[\\p{L}]+|[\\p{N}]|[^\\s\\p{L}\\p{N}]+",
            Pattern.CASE_INSENSITIVE);

    final Map<String, Integer> vocab = new HashMap<>();
    final Map<String, Integer> ranks = new HashMap<>();
    final Map<String, String> cache = new HashMap<>();
    final String[] byteChar = new String[256];
    int bos = BOS, eos = EOS, pad = EOS;

    SdTokenizer(File vocabJson, File mergesTxt) throws Exception {
        this(read(vocabJson), read(mergesTxt));
    }

    SdTokenizer(String vocabJson, String merges) throws Exception {
        JSONObject v = new JSONObject(vocabJson);
        for (Iterator<String> it = v.keys(); it.hasNext(); ) { String k = it.next(); vocab.put(k, v.getInt(k)); }
        int r = 0;
        for (String line : merges.split("\n")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#version")) continue;
            String[] ab = line.split(" ");
            if (ab.length != 2) continue;
            ranks.put(ab[0] + " " + ab[1], r++);
        }
        Integer b = vocab.get("<|startoftext|>"), e = vocab.get("<|endoftext|>");
        if (b != null) bos = b;
        if (e != null) { eos = e; pad = e; }
        // bytes_to_unicode de GPT-2/CLIP
        List<Integer> bs = new ArrayList<>();
        for (int i = '!'; i <= '~'; i++) bs.add(i);
        for (int i = 0xA1; i <= 0xAC; i++) bs.add(i);
        for (int i = 0xAE; i <= 0xFF; i++) bs.add(i);
        int n = 0;
        for (int i = 0; i < 256; i++) {
            if (bs.contains(i)) byteChar[i] = String.valueOf((char) i);
            else byteChar[i] = String.valueOf((char) (256 + n++));
        }
    }

    static String read(File f) throws Exception {
        StringBuilder b = new StringBuilder((int) Math.min(Integer.MAX_VALUE, f.length() + 16));
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            char[] buf = new char[65536];
            int k;
            while ((k = r.read(buf)) > 0) b.append(buf, 0, k);
        }
        return b.toString();
    }

    /**
     * v1.3.6 · Pesos como en YoDayo/A1111: «(tulip:1.5)» = 1,5 veces más importante, «(hada)» = ×1,1,
     * «((hada))» = ×1,21, «[fondo]» = ÷1,1. Devuelve los trozos de texto con su peso.
     */
    static List<Object[]> weights(String text) {
        List<Object[]> out = new ArrayList<>();
        List<Integer> round = new ArrayList<>(), square = new ArrayList<>();
        List<Object[]> res = new ArrayList<>();             // {StringBuilder texto, double peso}
        StringBuilder cur = new StringBuilder();
        java.util.function.DoubleSupplier mult = null;
        // pila de multiplicadores
        java.util.ArrayDeque<Double> stack = new java.util.ArrayDeque<>();
        double w = 1;
        Matcher m = Pattern.compile("\\\\[()\\[\\]]|\\(|\\[|:\\s*([+-]?\\d*\\.?\\d+)\\s*\\)|\\)|\\]|[^\\\\()\\[\\]:]+|:").matcher(text == null ? "" : text);
        while (m.find()) {
            String tk = m.group();
            if (tk.startsWith("\\")) { add(out, tk.substring(1), w); continue; }
            switch (tk.charAt(0)) {
                case '(': stack.push(1.1); w *= 1.1; break;
                case '[': stack.push(1 / 1.1); w /= 1.1; break;
                case ')': case ']':
                    if (!stack.isEmpty()) w /= stack.pop();
                    break;
                case ':':
                    if (m.group(1) != null && !stack.isEmpty()) {
                        // «(texto:1.5)»: lo último que entró en este paréntesis va con ese peso
                        double inner = w;
                        double base = w / stack.pop();
                        double nw = base * Double.parseDouble(m.group(1));
                        for (int i = out.size() - 1; i >= 0; i--) {
                            Object[] o = out.get(i);
                            if (Math.abs((double) o[1] - inner) > 1e-9) break;
                            o[1] = nw;
                        }
                        w = base;
                    } else add(out, ":", w);
                    break;
                default: add(out, tk, w);
            }
        }
        return out;
    }

    static void add(List<Object[]> out, String s, double w) {
        if (s.isEmpty()) return;
        if (!out.isEmpty() && Math.abs((double) out.get(out.size() - 1)[1] - w) < 1e-9) out.get(out.size() - 1)[0] = out.get(out.size() - 1)[0] + s;
        else out.add(new Object[]{s, w});
    }

    /** Fichas y su peso (77 cada una). */
    float[] lastWeights = new float[LEN];

    int[] encodeWeighted(String text) {
        List<Integer> ids = new ArrayList<>();
        List<Float> ws = new ArrayList<>();
        for (Object[] part : weights(text)) {
            int before = ids.size();
            ids.addAll(pieces((String) part[0]));
            for (int i = before; i < ids.size(); i++) ws.add((float) (double) (Double) part[1]);
        }
        int[] out = new int[LEN];
        float[] w = new float[LEN];
        java.util.Arrays.fill(out, pad);
        java.util.Arrays.fill(w, 1f);
        out[0] = bos;
        int n = Math.min(ids.size(), LEN - 2);
        for (int i = 0; i < n; i++) { out[i + 1] = ids.get(i); w[i + 1] = ws.get(i); }
        out[n + 1] = eos;
        lastWeights = w;
        return out;
    }

    /**
     * v1.7 · PROMPTS LARGOS (como AUTOMATIC1111): el texto se parte en trozos de 75 fichas (si puede, por una coma cercana;
     * «BREAK» fuerza un trozo nuevo). Cada trozo se lee por separado y luego se juntan, así no se pierde nada.
     * Devuelve los trozos de 77 (inicio + 75 + fin/relleno); «chunkWeights» trae los pesos de cada uno.
     */
    final List<float[]> chunkWeights = new ArrayList<>();

    List<int[]> encodeChunks(String text, int maxChunks) {
        List<int[]> out = new ArrayList<>();
        chunkWeights.clear();
        Integer comma = vocab.get(",</w>");
        String[] parts = (text == null ? "" : text).split("\\bBREAK\\b");
        List<Integer> ids = new ArrayList<>();
        List<Float> ws = new ArrayList<>();
        for (String part : parts) {
            List<Integer> pi = new ArrayList<>();
            List<Float> pw = new ArrayList<>();
            for (Object[] seg : weights(part)) {
                int before = pi.size();
                pi.addAll(pieces((String) seg[0]));
                for (int i = before; i < pi.size(); i++) pw.add((float) (double) (Double) seg[1]);
            }
            int i = 0;
            while (i < pi.size() || (pi.isEmpty() && i == 0)) {
                int end = Math.min(pi.size(), i + 75);
                if (end < pi.size() && comma != null) {           // cortar en una coma de las últimas 20 fichas
                    for (int k = end - 1; k > end - 20 && k > i; k--) if (pi.get(k).equals(comma)) { end = k + 1; break; }
                }
                int[] ch = new int[LEN];
                float[] w = new float[LEN];
                java.util.Arrays.fill(ch, pad);
                java.util.Arrays.fill(w, 1f);
                ch[0] = bos;
                int n = end - i;
                for (int k = 0; k < n; k++) { ch[k + 1] = pi.get(i + k); w[k + 1] = pw.get(i + k); }
                ch[n + 1] = eos;
                out.add(ch);
                chunkWeights.add(w);
                if (pi.isEmpty()) break;
                i = end;
                if (out.size() >= maxChunks) return out;
            }
            if (out.size() >= maxChunks) return out;
        }
        return out;
    }

    /** Fichas totales del texto (para el contador). */
    int countAll(String text) {
        int n = 0;
        for (String part : (text == null ? "" : text).split("\\bBREAK\\b"))
            for (Object[] seg : weights(part)) n += pieces((String) seg[0]).size();
        return n;
    }

    /** v1.4: personajes importados (nombre en minúsculas → sus fichas reservadas). */
    java.util.Map<String, int[]> chars = new java.util.HashMap<>();

    List<Integer> pieces(String text) {
        List<Integer> ids = new ArrayList<>();
        if (!chars.isEmpty()) {
            // el nombre más largo primero; solo palabras enteras
            List<String> names = new ArrayList<>(chars.keySet());
            names.sort((a, b) -> b.length() - a.length());
            StringBuilder alt = new StringBuilder();
            for (String n : names) alt.append(alt.length() == 0 ? "" : "|").append(Pattern.quote(n));
            Matcher cm = Pattern.compile("(?i)(?<![\\p{L}\\p{N}])(" + alt + ")(?![\\p{L}\\p{N}])").matcher(text);
            int last = 0;
            while (cm.find()) {
                ids.addAll(plain(text.substring(last, cm.start())));
                for (int id : chars.get(cm.group(1).toLowerCase(java.util.Locale.ROOT))) ids.add(id);
                last = cm.end();
            }
            ids.addAll(plain(text.substring(last)));
            return ids;
        }
        return plain(text);
    }

    List<Integer> plain(String text) {
        List<Integer> ids = new ArrayList<>();
        String t = text.replaceAll("\\s+", " ").trim().toLowerCase(java.util.Locale.ROOT);
        Matcher m = PAT.matcher(t);
        while (m.find()) {
            String tok = m.group();
            StringBuilder u = new StringBuilder();
            for (byte by : tok.getBytes(StandardCharsets.UTF_8)) u.append(byteChar[by & 0xff]);
            for (String piece : bpe(u.toString()).split(" ")) {
                Integer id = vocab.get(piece);
                if (id != null) ids.add(id);
            }
        }
        return ids;
    }

    /** Las 77 fichas (inicio, texto, fin y relleno). Lo que no cabe se corta. */
    int[] encode(String text) {
        List<Integer> ids = new ArrayList<>();
        String t = text == null ? "" : text.replaceAll("\\s+", " ").trim().toLowerCase(java.util.Locale.ROOT);
        Matcher m = PAT.matcher(t);
        while (m.find()) {
            String tok = m.group();
            StringBuilder u = new StringBuilder();
            for (byte by : tok.getBytes(StandardCharsets.UTF_8)) u.append(byteChar[by & 0xff]);
            for (String piece : bpe(u.toString()).split(" ")) {
                Integer id = vocab.get(piece);
                if (id != null) ids.add(id);
            }
        }
        int[] out = new int[LEN];
        java.util.Arrays.fill(out, pad);
        out[0] = bos;
        int n = Math.min(ids.size(), LEN - 2);
        for (int i = 0; i < n; i++) out[i + 1] = ids.get(i);
        out[n + 1] = eos;
        return out;
    }

    /** Cuántas palabras-ficha ocupa el texto (para avisar si es demasiado largo). */
    int count(String text) {
        int[] e = encode(text);
        int n = 0;
        for (int i = 1; i < LEN && e[i] != eos; i++) n++;
        return n;
    }

    String bpe(String token) {
        String c = cache.get(token);
        if (c != null) return c;
        List<String> word = new ArrayList<>();
        int len = token.length();
        for (int i = 0; i < len; i++) word.add(i == len - 1 ? token.charAt(i) + "</w>" : String.valueOf(token.charAt(i)));
        if (word.isEmpty()) return "";
        while (word.size() > 1) {
            int best = Integer.MAX_VALUE, at = -1;
            for (int i = 0; i < word.size() - 1; i++) {
                Integer r = ranks.get(word.get(i) + " " + word.get(i + 1));
                if (r != null && r < best) { best = r; at = i; }
            }
            if (at < 0) break;
            String a = word.get(at), b = word.get(at + 1);
            List<String> nw = new ArrayList<>();
            int i = 0;
            while (i < word.size()) {
                if (i < word.size() - 1 && word.get(i).equals(a) && word.get(i + 1).equals(b)) { nw.add(a + b); i += 2; }
                else { nw.add(word.get(i)); i++; }
            }
            word = nw;
        }
        String r = String.join(" ", word);
        if (cache.size() < 5000) cache.put(token, r);
        return r;
    }
}
