package com.aplauso.encuentra;

import android.app.Application;
import android.content.Context;
import android.os.Build;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * v1.7 · REGISTRO DE ERRORES. Si la app se cierra de golpe, antes de cerrarse apunta qué pasó en «crash.txt»
 * (solo en el teléfono, nunca se envía a ningún sitio). En Ajustes → «Último error» lo puedes ver y copiar.
 */
public class SssApp extends Application {
    static final int MAX = 60_000;

    @Override public void onCreate() {
        super.onCreate();
        try { Convos.init(this); } catch (Throwable ignored) {}      // v1.7: la conversación en la que estabas
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        final Context app = getApplicationContext();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try { write(app, t, e); } catch (Throwable ignored) {}
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    static File file(Context c) { return new File(c.getFilesDir(), "crash.txt"); }

    static void write(Context c, Thread t, Throwable e) throws Exception {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        String ver = "?";
        try { ver = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; } catch (Exception ignored) {}
        pw.println("SSS+ " + ver + " · " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(new Date()));
        pw.println(Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        Runtime rt = Runtime.getRuntime();
        pw.println("Memoria Java: " + (rt.totalMemory() - rt.freeMemory()) / 1048576 + " / " + rt.maxMemory() / 1048576 + " MB");
        pw.println("Hilo: " + (t == null ? "?" : t.getName()));
        e.printStackTrace(pw);
        pw.flush();
        String s = sw.toString();
        if (s.length() > MAX) s = s.substring(0, MAX);
        try (FileWriter w = new FileWriter(file(c), false)) { w.write(s); }
        c.getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("crash_new", true).commit();
    }

    /** El último error apuntado, o null. */
    static String last(Context c) {
        File f = file(c);
        if (!f.exists()) return null;
        try { return new String(java.nio.file.Files.readAllBytes(f.toPath()), java.nio.charset.StandardCharsets.UTF_8); }
        catch (Exception e) { return null; }
    }

    static void clear(Context c) {
        file(c).delete();
        c.getSharedPreferences("cfg", MODE_PRIVATE).edit().remove("crash_new").apply();
    }

    /** Para errores que atrapamos nosotros pero conviene ver (no cierra la app). */
    static void note(Context c, String where, Throwable e) {
        try { write(c, Thread.currentThread(), new RuntimeException(where, e)); } catch (Throwable ignored) {}
    }
}
