package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.MediaStore;

import java.io.OutputStream;

/**
 * v1.7.3 · DIBUJAR EN SEGUNDO PLANO: aunque salgas de la app o apagues la pantalla, con notificación de progreso y un
 * aviso al acabar.
 *
 * v1.7.6 · Trabaja con la COLA del historial (DrawHistory): cada dibujo pedido ya está guardado ahí antes de empezar.
 * Este servicio coge el siguiente «en cola», lo dibuja y lo deja hecho. Si pides más mientras dibuja, se suman a la
 * cola. Si algo falla, ese dibujo queda con su botón ↻ y sigue con los demás.
 */
public class DrawService extends Service {
    public interface Listener { void update(); }

    static volatile boolean running, stopAll;
    static volatile DrawHistory.Item current;
    static volatile SdEngine.Job job;
    static volatile int percent;
    static volatile String status = "";
    static volatile Bitmap preview;
    static Listener listener;

    static String ch, chDone;
    NotificationManager nm;
    PowerManager.WakeLock wl;

    /** Que se ponga a dibujar lo que haya en cola (si ya está en ello, lo coge solo). */
    static void kick(Context c) {
        synchronized (DrawHistory.class) {
            if (running) return;
            if (DrawHistory.count(c, DrawHistory.QUEUED) == 0) return;
            running = true;
            stopAll = false;
        }
        status = L.t("Preparando…");
        Intent i = new Intent(c, DrawService.class);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception e) { running = false; }
    }

    /** ⏹ Parar: el que se está dibujando y todo lo que esperaba (quedan con ↻). */
    static void stop(Context c) {
        stopAll = true;
        DrawHistory.stopQueued(c);
        cancelCurrent();
    }

    static void cancelCurrent() { SdEngine.Job j = job; if (j != null) j.cancel = true; }

    static void tell() { Listener l = listener; if (l != null) try { l.update(); } catch (Exception ignored) {} }

    @Override public IBinder onBind(Intent i) { return null; }

    Notification progress(String text, int pc, int left) {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, DrawStudioActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, ch);
        return b.setSmallIcon(android.R.drawable.ic_menu_gallery)
                .setContentTitle(L.t("Dibujando") + (left > 0 ? " · " + L.t("quedan") + " " + left : "") + " · Chloe Nova")
                .setContentText(text).setProgress(100, Math.max(0, pc), pc < 0).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi).build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        nm = getSystemService(NotificationManager.class);
        ch = Notif.ch(this, "draw", L.t("Estudio de dibujo"), NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(new android.app.NotificationChannel("draw_done", L.t("Dibujos terminados"), NotificationManager.IMPORTANCE_DEFAULT));
        chDone = "draw_done";
        // relanzado por Android tras cerrar la app: lo que quedó «dibujando» vuelve a la cola
        if (intent == null) {
            synchronized (DrawHistory.class) {
                for (DrawHistory.Item it : DrawHistory.items(this)) if (DrawHistory.DRAWING.equals(it.status)) DrawHistory.retry(this, it);
                running = DrawHistory.count(this, DrawHistory.QUEUED) > 0;
            }
        }
        try {
            Notification n = progress(L.t("Preparando…"), -1, 0);
            if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(61, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(61, n);
        } catch (Exception e) {                    // Android no deja empezar desde segundo plano: queda en cola con ↻
            running = false; stopSelf(); return START_NOT_STICKY;
        }
        if (worker != null && worker.isAlive()) return START_STICKY;
        if (!running) { stopSelf(); return START_NOT_STICKY; }
        wl = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sss:draw");
        wl.acquire(6L * 3600 * 1000);
        worker = new Thread(this::work, "dibujar");
        worker.start();
        return START_STICKY;                       // si Android la cierra, que la vuelva a abrir y siga con la cola
    }

    static Thread worker;

    void work() {
        int done = 0, failed = 0;
        Bitmap last = null;
        String lastErr = "";
        try {
            while (!stopAll) {
                DrawHistory.Item it;
                synchronized (DrawHistory.class) {
                    it = DrawHistory.takeNext(this);
                    if (it == null) { running = false; break; }      // cola vacía (dentro del candado: no se pierde ninguno nuevo)
                }
                current = it;
                percent = 0;
                preview = null;
                // v1.7.6: semilla fija desde el principio (si no, al seguir tras un corte saldría otra imagen)
                if (it.seed < 0) { it.seed = new java.util.Random().nextInt(Integer.MAX_VALUE); DrawHistory.write(this, it); }
                SdEngine.Job j = it.job(this);
                j.ckpt = it.ckpt(this);                   // cada paso queda apuntado
                job = j;
                tell();
                final long[] lastN = {0};
                try {
                    Bitmap out = SdEngine.generate(this, j, (step, msg, prev) -> {
                        percent = step < 0 ? 0 : (int) (100L * step / Math.max(1, j.steps));
                        status = msg;
                        if (prev != null) preview = prev;
                        long now = System.currentTimeMillis();
                        if (now - lastN[0] > 1500) {
                            lastN[0] = now;
                            nm.notify(61, progress(msg, step < 0 ? -1 : percent, DrawHistory.count(this, DrawHistory.QUEUED)));
                        }
                        tell();
                    });
                    if (out == null) {
                        // parado (o borrado mientras se dibujaba)
                        if (DrawHistory.items(this).contains(it)) DrawHistory.fail(this, it, DrawHistory.STOPPED, L.t("parado"));
                    } else {
                        DrawHistory.finish(this, it, out, j.seed);
                        it.ckpt(this).delete();
                        done++;
                        last = out;
                    }
                } catch (OutOfMemoryError e) {
                    SdEngine.unload();
                    lastErr = L.t("No hay memoria suficiente: cierra otras apps o usa el tamaño «Rápida».");
                    DrawHistory.fail(this, it, DrawHistory.FAILED, lastErr);
                    failed++;
                } catch (Throwable e) {
                    SdEngine.unload();
                    lastErr = L.t("No he podido dibujar: ") + e.getMessage();
                    DrawHistory.fail(this, it, DrawHistory.FAILED, lastErr);
                    failed++;
                }
                current = null;
                job = null;
                tell();
            }
        } finally {
            running = false;
            current = null;
            job = null;
            if (wl != null && wl.isHeld()) wl.release();
            stopForeground(true);
            status = stopAll ? L.t("Parado.") : done > 0 ? (done > 1 ? L.t("¡Hechas!") + " " + done + " " + L.t("imágenes en el historial (24 h).")
                    : L.t("¡Hecho! Está en el historial 24 h: pulsa GUARDAR o 📌 para quedártela.")) : lastErr;
            if (done > 0 || failed > 0) {
                PendingIntent pi = PendingIntent.getActivity(this, 1, new Intent(this, DrawHistoryActivity.class), PendingIntent.FLAG_IMMUTABLE);
                String title = done > 0 ? "✨ " + (done > 1 ? done + " " + L.t("dibujos listos") : L.t("Tu dibujo está listo")) : L.t("Estudio de dibujo");
                String text = (done > 0 ? L.t("Toca para verlos. Están en el historial 24 h: guarda o fija los que quieras.") : "")
                        + (failed > 0 ? (done > 0 ? " " : "") + "⚠ " + failed + " " + L.t("no se pudieron hacer: tócalos en el historial para reintentar.") : "");
                Notification.Builder b = new Notification.Builder(this, chDone).setSmallIcon(android.R.drawable.ic_menu_gallery)
                        .setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text))
                        .setAutoCancel(true).setContentIntent(pi);
                if (last != null) b.setLargeIcon(last).setStyle(new Notification.BigPictureStyle().bigPicture(last).setSummaryText(text));
                nm.notify(62, b.build());
            }
            tell();
            stopSelf();
        }
    }

    static boolean saveToGallery(Context c, Bitmap b) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "SSS_dibujo_" + System.currentTimeMillis() + ".png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (android.os.Build.VERSION.SDK_INT >= 29) v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SSS+");
            Uri u = c.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            try (OutputStream os = c.getContentResolver().openOutputStream(u)) { b.compress(Bitmap.CompressFormat.PNG, 100, os); }
            return true;
        } catch (Exception e) { return false; }
    }
}
