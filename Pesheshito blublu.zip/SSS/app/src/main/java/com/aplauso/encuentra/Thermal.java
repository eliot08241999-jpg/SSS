package com.aplauso.encuentra;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;

/**
 * v1.7 · MODO FRESCO: tardar más para no calentar el teléfono. Entre paso y paso descansa un poco y, si la batería
 * pasa de ~40 °C o Android avisa de que se está calentando, se para hasta que baje de ~36 °C y sigue donde lo dejó.
 */
public class Thermal {
    public static final float HOT = 40f, OK = 36f;

    public static boolean on(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("sd_cool", false); }

    /** Temperatura de la batería en °C (o NaN si no se sabe). */
    public static float battery(Context c) {
        try {
            Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int t = i == null ? Integer.MIN_VALUE : i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            return t == Integer.MIN_VALUE ? Float.NaN : t / 10f;
        } catch (Exception e) { return Float.NaN; }
    }

    /** ¿Android dice que va caliente? (moderado o peor) */
    public static boolean throttling(Context c) {
        if (Build.VERSION.SDK_INT < 29) return false;
        try {
            PowerManager pm = c.getSystemService(PowerManager.class);
            if (pm.getCurrentThermalStatus() >= PowerManager.THERMAL_STATUS_MODERATE) return true;
            if (Build.VERSION.SDK_INT >= 30) { float h = pm.getThermalHeadroom(10); return !Float.isNaN(h) && h >= 0.95f; }
        } catch (Throwable ignored) {}
        return false;
    }

    public interface Status { void at(String msg); }
    public interface Cancel { boolean cancelled(); }

    /** Llamar entre paso y paso. Con el modo fresco: descansa y, si hace falta, espera a que se enfríe. */
    public static void breathe(Context c, Cancel cancel, Status st) {
        if (!on(c)) return;
        sleep(250);                                              // un respiro en cada paso
        float tb = battery(c);
        if (!(tb >= HOT) && !throttling(c)) return;
        long until = System.currentTimeMillis() + 15 * 60_000L;  // como mucho 15 min de espera seguida
        while (System.currentTimeMillis() < until && !cancel.cancelled()) {
            tb = battery(c);
            if (st != null) st.at("🌡 " + L.t("Enfriando el teléfono…") + (Float.isNaN(tb) ? "" : " " + Math.round(tb) + " °C → " + Math.round(OK) + " °C"));
            if ((Float.isNaN(tb) || tb <= OK) && !throttling(c)) return;
            sleep(5000);
        }
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }
}
