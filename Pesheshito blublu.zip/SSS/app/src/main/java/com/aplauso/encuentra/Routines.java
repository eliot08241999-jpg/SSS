package com.aplauso.encuentra;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

/**
 * Rutinas del asistente (v0.9.3).
 * «Buenos días»: te saluda por tu nombre, te dice la hora, el tiempo de hoy, un chiste y «que te vaya bien»
 * (y quita el No molestar si lo había puesto SSS+).
 * «Buenas noches»: pone el teléfono en No molestar (las alarmas siguen sonando) para que duermas tranquilo.
 * El tiempo viene de Open-Meteo (gratis, sin clave). Bloquea: llamar desde un hilo.
 */
public class Routines {
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    /** Devuelve lo que hay que decir, o null si no es una rutina. */
    static String handle(Context c, String said) {
        String s = Actions.norm(said);
        // v1.1: tu nombre: solo lo sabe si lo escribes en la pantalla del asistente (cada persona pone el suyo)
        if (s.matches(".*\\b(?:cual es mi nombre|como me llamo|sabes mi nombre|sabes como me llamo|quien soy yo|quien soy|what s my name|whats my name|come mi chiamo)\\b.*")) {
            String n = name(c);
            return n.isEmpty() ? L.t("No tengo tu nombre. Escríbelo en la pantalla del asistente, en la casilla «Tu nombre», y a partir de ahí te llamaré así.")
                    : L.t("Te llamas") + " " + n + ".";
        }
        if (s.matches("^(?:me llamo|mi nombre es|llamame|my name is|mi chiamo)\\s+.+")) {
            String n = name(c);
            return L.t("Encantada. Para que lo recuerde, escríbelo en la pantalla del asistente, en la casilla «Tu nombre».")
                    + (n.isEmpty() ? "" : " " + L.t("Ahora mismo tengo apuntado") + " " + n + ".");
        }
        if (s.matches("^(?:hola )?(?:buenos dias|buen dia|good morning|morning|buongiorno)\\b.*")) return morning(c);
        if (s.matches("^(?:buenas noches|good night|goodnight|buonanotte|buona notte)\\b.*")) return night(c);
        if (s.matches(".*\\b(?:que hora es|que horas son|dime la hora|what time is it|che ore sono)\\b.*")) return time();
        // «estoy en Roma» / «vivo en Roma»: se apunta como tu ciudad para el tiempo
        java.util.regex.Matcher cm = java.util.regex.Pattern.compile("\\b(?:estoy|vivo|me encuentro) en ([a-z]+(?: (?!(?:y|quiero|pero|ahora|hoy|dime|que|como|estoy|para|y)\\b)[a-z]+)?)").matcher(s);
        String cityNote = "", found = null;
        while (cm.find()) {           // la última que diga en positivo («no estoy en España, estoy en Roma» → Roma)
            int st0 = cm.start();
            if (st0 >= 3 && s.substring(Math.max(0, st0 - 3), st0).equals("no ")) continue;
            found = cm.group(1);
        }
        if (found != null) {
            String city = found.trim();
            if (!city.matches("(?:casa|el trabajo|la calle|clase|el coche|la cama).*")) {
                city = Character.toUpperCase(city.charAt(0)) + city.substring(1);
                prefs(c).edit().putString("ai_city", city).remove("ai_city_geo").apply();
                cityNote = L.t("Apuntado: estás en") + " " + city + ". ";
            }
        }
        // v1.7: palabras claras del tiempo (basta con ellas) y palabras que solo cuentan si es una pregunta
        boolean strong = s.matches(".*\\b(?:el tiempo|que tiempo|clima|pronostico|weather|forecast|meteo|previsioni|previsione|che tempo|il tempo)\\b.*")
                && !s.matches(".*\\b(?:quanto tempo|cuanto tiempo|how long|hace mucho tiempo|el tiempo libre|a tiempo|al mismo tiempo|nel tempo|in tempo|el tiempo que)\\b.*");
        boolean weak = s.matches(".*\\b(?:lluvia|llueve|llover|llovera|llovio|lloviendo|ha llovido|paraguas|nieve|nevara|nieva|tormenta|viento|temperatura|grados|calor|frio|"
                + "soleado|nublado|umbrella|rain|raining|snow|temperature|sunny|windy|pioggia|piove|piovera|nevica|nevichera|neve|temporale|ombrello|caldo|freddo|gradi|vento)\\b.*")
                && s.matches(".*\\b(?:que|como|cual|cuanto|cuantos|va a|hara|habra|hace|sera|estara|hoy|manana|dime|what|how|will|is it|che|come|quanto|fara|sara|fa|oggi|domani|"
                + "lunes|martes|miercoles|jueves|viernes|sabado|domingo|lunedi|martedi|mercoledi|giovedi|venerdi|sabato|domenica|monday|tuesday|wednesday|thursday|friday|saturday|sunday|"
                + "semana|settimana|week)\\b.*")
                && !s.matches("^(?:tengo|ho|i am|i'm|estoy) .*");
        boolean wx = strong || weak;
        int day = dayOf(s);
        // «no, mañana» / «¿y el sábado?» justo después de preguntar por el tiempo
        boolean follow = !wx && day >= 0 && System.currentTimeMillis() - lastWeather < 120_000 && s.split(" ").length <= 6;
        if (wx || follow) {
            lastWeather = System.currentTimeMillis();
            String other = cityNote.isEmpty() ? otherCity(s) : null;           // v1.7: «¿qué tiempo hará en Milán?»
            if (s.matches(".*\\b(?:semana|settimana|week|proximos dias|prossimi giorni|next days)\\b.*")) return cityNote + week(c, other);
            return cityNote + weather(c, Math.max(0, day), other);
        }
        if (!cityNote.isEmpty() && s.split(" ").length <= 6) return cityNote.trim();
        if (s.matches(".*\\b(?:cuentame|dime|hazme|cuenta)\\b.*\\b(?:chiste|broma)\\b.*|.*\\b(?:tell me a joke|joke|barzelletta)\\b.*")) return joke();
        if (s.matches(".*\\b(?:quita|desactiva|apaga)\\b.*\\bno molestar\\b.*")) return dnd(c, false);
        if (s.matches(".*\\b(?:pon|activa|enciende)\\b.*\\bno molestar\\b.*")) return dnd(c, true);
        return null;
    }

    static long lastWeather;

    /** Qué día pide: 0 hoy, 1 mañana, 2 pasado mañana, o el próximo lunes, martes…; -1 si no dice ninguno. */
    static int dayOf(String s) {
        if (s.matches(".*\\b(?:pasado manana|day after tomorrow|dopodomani)\\b.*")) return 2;
        if (s.matches(".*\\b(?:manana|tomorrow|domani)\\b.*") && !s.matches(".*\\b(?:esta|por la|en la|de la|this) (?:manana|morning)\\b.*")) return 1;
        String[][] days = {{"lunes", "monday", "lunedi"}, {"martes", "tuesday", "martedi"}, {"miercoles", "wednesday", "mercoledi"},
                {"jueves", "thursday", "giovedi"}, {"viernes", "friday", "venerdi"}, {"sabado", "saturday", "sabato"}, {"domingo", "sunday", "domenica"}};
        int today = (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) + 5) % 7;     // 0 = lunes
        for (int d = 0; d < 7; d++) for (String w : days[d])
            if (s.matches(".*\\b" + w + "\\b.*")) return (d - today + 7) % 7;
        if (s.matches(".*\\b(?:hoy|ahora|today|now|oggi|adesso)\\b.*")) return 0;
        return -1;
    }

    static String name(Context c) { return prefs(c).getString("ai_name", "").trim(); }

    static String morning(Context c) {
        StringBuilder b = new StringBuilder();
        String n = name(c);
        b.append(L.t("¡Buenos días")).append(n.isEmpty() ? "" : ", " + n).append("! ");
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        b.append(h < 7 ? L.t("Qué madrugador. ") : h >= 12 ? L.t("Aunque ya es casi mediodía. ") : L.t("Espero que hayas dormido bien. "));
        b.append(time()).append(' ');
        if (prefs(c).getBoolean("dnd_by_sss", false)) { String d = dnd(c, false); if (d != null) b.append(d).append(' '); }
        b.append(weather(c)).append(' ');
        b.append(L.t("Y para empezar con una sonrisa: ")).append(joke()).append(' ');
        b.append(L.t("¡Que te vaya muy bien hoy!"));
        return b.toString();
    }

    static String night(Context c) {
        String n = name(c);
        String d = dnd(c, true);
        return L.t("Buenas noches") + (n.isEmpty() ? "" : ", " + n) + ". " + d + " " + L.t("Que descanses.");
    }

    static String time() {
        Calendar k = Calendar.getInstance();
        return L.t("Son las") + " " + String.format(Locale.US, "%d:%02d", k.get(Calendar.HOUR_OF_DAY), k.get(Calendar.MINUTE)) + ".";
    }

    /** No molestar. Necesita el permiso «Acceso a No molestar» (se da en la pantalla del asistente). */
    static String dnd(Context c, boolean on) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || !nm.isNotificationPolicyAccessGranted())
            return L.t("No puedo poner el No molestar: dame permiso en la pantalla del asistente, botón NO MOLESTAR.");
        try {
            nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_PRIORITY : NotificationManager.INTERRUPTION_FILTER_ALL);
            prefs(c).edit().putBoolean("dnd_by_sss", on).apply();
            return on ? L.t("He puesto el No molestar; las alarmas sí sonarán.") : L.t("He quitado el No molestar.");
        } catch (Exception e) {
            return L.t("El teléfono no me deja cambiar el No molestar.");
        }
    }

    static final String[] JOKES_ES = {
            "¿Qué le dice una oveja a otra? Nos vemos en el baaaar.",
            "¿Por qué el libro de matemáticas estaba triste? Porque tenía demasiados problemas.",
            "¿Qué hace una abeja en el gimnasio? Zum-ba.",
            "Le dije a mi teléfono que necesitaba un descanso, y me puso el modo avión.",
            "¿Cómo se despiden los químicos? Ácido un placer.",
            "¿Qué le dice un semáforo a otro? No me mires, que me estoy cambiando.",
            "¿Por qué los pájaros no usan Facebook? Porque ya tienen Twitter.",
            "Mi despertador y yo tenemos una relación complicada: él me quiere despierto y yo a él apagado.",
            "¿Qué le dice el café al azúcar? Sin ti mi vida es amarga.",
            "¿Cuál es el colmo de un electricista? Que su mujer se llame Luz y sus hijos le sigan la corriente.",
    };
    static final String[] JOKES_EN = {
            "What do you call a sleeping sheep? A baa-d dreamer.",
            "Why did the math book look sad? It had too many problems.",
            "I told my phone I needed a break, so it switched to airplane mode.",
            "Why don't eggs tell jokes? They'd crack each other up.",
            "What does coffee say to sugar? Life is bitter without you.",
    };
    static final String[] JOKES_IT = {
            "Cosa dice una pecora all'altra? Ci vediamo al beeeeh-r.",
            "Perché il libro di matematica è triste? Perché ha troppi problemi.",
            "Ho detto al telefono che avevo bisogno di una pausa, e si è messo in modalità aereo.",
            "Cosa dice il caffè allo zucchero? Senza di te la vita è amara.",
    };

    static String joke() {
        String[] j = "en".equals(L.lang) ? JOKES_EN : "it".equals(L.lang) ? JOKES_IT : JOKES_ES;
        return j[new Random().nextInt(j.length)];
    }

    // ---------- tiempo ----------
    static String weather(Context c) { return weather(c, 0, null); }
    static String weather(Context c, int day) { return weather(c, day, null); }

    /** v1.7: la ciudad que nombra («en Milán», «a Milano», «in London»), si no es la tuya. */
    static String otherCity(String s) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\b(?:en|in|a|para|per|at|di|de)\\s+((?!(?:la|el|los|las|il|lo|casa|mi|tu|su|la tarde|la noche|la manana|"
                + "hoy|manana|oggi|domani|today|tomorrow|esta|este|questo|questa|the|serata|mattina|pomeriggio|semana|settimana|week|grados|gradi|que|che)\\b)[a-z]{3,}(?: (?!(?:hoy|manana|oggi|domani|today|tomorrow|el|la|il|este|esta|questo|questa|y|e|and|por|per|de|di|a|en|in)\\b)[a-z]{3,})?)").matcher(s);
        String found = null;
        while (m.find()) found = m.group(1);
        if (found == null) return null;
        if (found.matches("(?:llover|nevar|hacer|ser|estar|piovere|nevicare|fare|rain|snow|be|salir|uscire|go)\\b.*")) return null;
        if (found.matches("(?:lluvia|paraguas|nieve|calor|frio|tiempo|clima|meteo|pioggia|neve|caldo|freddo|tempo|weather|rain|snow|temperatura|celsius|"
                + "lunes|martes|miercoles|jueves|viernes|sabado|domingo|lunedi|martedi|mercoledi|giovedi|venerdi|sabato|domenica|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\\b.*")) return null;
        return found;
    }

    /** El tiempo de toda la semana, corto. */
    static String week(Context c, String other) {
        try {
            Weather.Fc f = other != null ? Weather.city(other) : Weather.here(c);
            if (f == null) return other != null ? L.t("No encuentro esa ciudad.") : L.t("Para decirte el tiempo, escribe tu ciudad en la pantalla del asistente o dame permiso de ubicación.");
            StringBuilder b = new StringBuilder(L.t("Esta semana") + (f.place.isEmpty() ? "" : " " + L.t("en") + " " + f.place) + ": ");
            for (int i = 0; i < 7; i++) {
                String when = i == 0 ? L.t("hoy") : i == 1 ? L.t("mañana") : dayName(i).replaceFirst("^El ", "el ");
                b.append(when).append(" ").append(sky(f.codes[i])).append(", ").append(Math.round(f.max[i])).append(L.t(" de máxima"));
                if (f.rain[i] >= 40) b.append(" (").append(f.rain[i]).append(L.t(" % de lluvia")).append(")");
                b.append(i < 6 ? "; " : ".");
            }
            String al = Weather.alerts(f);
            if (!al.isEmpty()) b.append(' ').append(al.replace("⚠ ", "").replace("🔥 ", "").replace("🧊 ", "").replace("💨 ", "")).append('.');
            return b.toString();
        } catch (java.net.UnknownHostException e) { return L.t("No tengo internet para mirar el tiempo."); }
        catch (Exception e) { return L.t("No he podido mirar el tiempo ahora."); }
    }

    /** El tiempo de hoy (0), mañana (1)… hasta dentro de 6 días. */
    static String weather(Context c, int day, String other) {
        day = Math.max(0, Math.min(6, day));
        try {
            Weather.Fc f = other != null ? Weather.city(other) : Weather.here(c);
            if (f == null && other != null) return L.t("No encuentro esa ciudad.");
            if (f == null) return L.t("Para decirte el tiempo, escribe tu ciudad en la pantalla del asistente o dame permiso de ubicación.");
            int now = (int) Math.round(f.temp);
            int max = (int) Math.round(f.max[day]);
            int min = (int) Math.round(f.min[day]);
            int rain = f.rain[day];
            String sky = sky(f.codes[day]);
            String city = f.place;
            String when = day == 0 ? L.t("Hoy") : day == 1 ? L.t("Mañana") : day == 2 ? L.t("Pasado mañana") : dayName(day);
            StringBuilder b = new StringBuilder(when).append(city.isEmpty() ? "" : " " + L.t("en") + " " + city).append(": ").append(sky);
            if (day == 0) b.append(", ").append(L.t("ahora hace")).append(' ').append(now).append(L.t(" grados, con máxima de ")).append(max)
                    .append(L.t(" y mínima de ")).append(min).append('.');
            else b.append(", ").append(L.t("con máxima de ")).append(max).append(L.t(" y mínima de ")).append(min).append(L.t(" grados.")); 
            if (day == 0 && Math.abs(f.feels - f.temp) >= 3) b.append(' ').append(L.t("La sensación es de")).append(' ').append(Math.round(f.feels)).append(L.t(" grados."));
            if (day == 0 && f.precip > 0.05) b.append(' ').append(L.t("Ahora mismo está lloviendo."));
            double wind = day == 0 ? f.wind : f.windMax[day];
            if (wind >= 40) b.append(' ').append(L.t("Va a hacer mucho viento:")).append(' ').append(Math.round(wind)).append(" km/h.");
            if (rain >= 50) b.append(' ').append(L.t("Hay")).append(' ').append(rain).append(L.t(" % de probabilidad de lluvia: llévate paraguas."));
            else if (rain >= 20) b.append(' ').append(L.t("Puede que llueva un poco."));
            return b.toString();
        } catch (java.net.UnknownHostException e) {
            return L.t("No tengo internet para mirar el tiempo.");
        } catch (Exception e) {
            return L.t("No he podido mirar el tiempo ahora.");
        }
    }

    /** Latitud y longitud: la ciudad escrita en el asistente o, si no hay, la última ubicación conocida. */
    static double[] where(Context c) throws Exception {
        SharedPreferences p = prefs(c);
        String city = p.getString("ai_city", "").trim();
        if (!city.isEmpty()) {
            if (city.equals(p.getString("ai_city_geo", "")) && p.contains("ai_city_lat"))
                return new double[]{p.getFloat("ai_city_lat", 0), p.getFloat("ai_city_lon", 0)};
            JSONObject o = new JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=" + Wake.lang()
                    + "&name=" + URLEncoder.encode(city, "UTF-8")));
            JSONArray r = o.optJSONArray("results");
            if (r != null && r.length() > 0) {
                JSONObject g = r.getJSONObject(0);
                double la = g.getDouble("latitude"), lo = g.getDouble("longitude");
                p.edit().putString("ai_city_geo", city).putFloat("ai_city_lat", (float) la).putFloat("ai_city_lon", (float) lo)
                        .putString("ai_city_name", g.optString("name", city)).apply();
                return new double[]{la, lo};
            }
        }
        if (c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            LocationManager lm = c.getSystemService(LocationManager.class);
            Location best = null;
            for (String pr : lm.getProviders(true)) {
                try {
                    Location l = lm.getLastKnownLocation(pr);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (SecurityException ignored) {}
            }
            if (best != null) { p.edit().putString("ai_city_name", "").apply(); return new double[]{best.getLatitude(), best.getLongitude()}; }
        }
        return null;
    }

    static String dayName(int offset) {
        Calendar k = Calendar.getInstance();
        k.add(Calendar.DAY_OF_YEAR, offset);
        String[] es = {"El domingo", "El lunes", "El martes", "El miércoles", "El jueves", "El viernes", "El sábado"};
        return L.t(es[k.get(Calendar.DAY_OF_WEEK) - 1]);
    }

    static String sky(int code) {
        if (code == 0) return L.t("despejado");
        if (code <= 2) return L.t("algo de nubes");
        if (code == 3) return L.t("nublado");
        if (code == 45 || code == 48) return L.t("con niebla");
        if (code >= 51 && code <= 57) return L.t("con llovizna");
        if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return L.t("con lluvia");
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) return L.t("con nieve");
        if (code >= 95) return L.t("con tormenta");
        return L.t("variable");
    }

    static String get(String u) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(u).openConnection();
        con.setConnectTimeout(10000);
        con.setReadTimeout(15000);
        try { return Brain.read(con.getInputStream()); } finally { con.disconnect(); }
    }
}
