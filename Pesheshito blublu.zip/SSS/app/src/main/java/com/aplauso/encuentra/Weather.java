package com.aplauso.encuentra;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.Locale;

/**
 * v1.7 · EL TIEMPO (Open-Meteo, gratis y sin clave): lo comparten las respuestas de Chloe, la tarjeta de la semana
 * y el «tiempo real en el fondo». Se guarda 20 minutos para no preguntar a cada rato.
 */
public class Weather {
    public static final class Fc {
        public double temp, feels, wind, precip;
        public int code, cloud;
        public boolean day = true;
        public double[] max = new double[7], min = new double[7], windMax = new double[7];
        public int[] rain = new int[7], codes = new int[7];
        public String[] dates = new String[7];
        public String place = "";
        public long at;
    }

    static Fc cached;
    static String cachedKey = "";

    /** «tiempo real en el fondo» activado. */
    public static boolean on(Context c) { return Brain.prefs(c).getBoolean("wx_live", false); }

    /** El pronóstico de donde estás (ciudad del asistente o ubicación). Bloquea: fuera del hilo principal. */
    public static Fc here(Context c) throws Exception {
        double[] ll = Routines.where(c);
        if (ll == null) return null;
        String name = Brain.prefs(c).getString("ai_city_name", "");
        return at(ll[0], ll[1], name);
    }

    /** El pronóstico de otra ciudad («¿qué tiempo hará en Milán?»). null si no la encuentra. */
    public static Fc city(String city) throws Exception {
        JSONObject o = new JSONObject(Routines.get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=" + Wake.lang()
                + "&name=" + URLEncoder.encode(city, "UTF-8")));
        JSONArray r = o.optJSONArray("results");
        if (r == null || r.length() == 0) return null;
        JSONObject g = r.getJSONObject(0);
        return at(g.getDouble("latitude"), g.getDouble("longitude"), g.optString("name", city));
    }

    public static synchronized Fc at(double lat, double lon, String place) throws Exception {
        String key = String.format(Locale.US, "%.2f,%.2f", lat, lon);
        if (cached != null && key.equals(cachedKey) && System.currentTimeMillis() - cached.at < 20 * 60_000L) return cached;
        String url = String.format(Locale.US, "https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f"
                + "&current=temperature_2m,apparent_temperature,weather_code,precipitation,wind_speed_10m,cloud_cover,is_day"
                + "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code,wind_speed_10m_max"
                + "&timezone=auto&forecast_days=7", lat, lon);
        JSONObject o = new JSONObject(Routines.get(url));
        JSONObject cur = o.getJSONObject("current"), d = o.getJSONObject("daily");
        Fc f = new Fc();
        f.temp = cur.optDouble("temperature_2m", 0);
        f.feels = cur.optDouble("apparent_temperature", f.temp);
        f.code = cur.optInt("weather_code", 0);
        f.precip = cur.optDouble("precipitation", 0);
        f.wind = cur.optDouble("wind_speed_10m", 0);
        f.cloud = cur.optInt("cloud_cover", 0);
        f.day = cur.optInt("is_day", 1) == 1;
        JSONArray mx = d.getJSONArray("temperature_2m_max"), mn = d.getJSONArray("temperature_2m_min"), rp = d.optJSONArray("precipitation_probability_max"),
                wc = d.getJSONArray("weather_code"), wm = d.optJSONArray("wind_speed_10m_max"), tm = d.getJSONArray("time");
        for (int i = 0; i < 7 && i < mx.length(); i++) {
            f.max[i] = mx.optDouble(i, 0); f.min[i] = mn.optDouble(i, 0);
            f.rain[i] = rp == null ? 0 : rp.optInt(i, 0);
            f.codes[i] = wc.optInt(i, 0);
            f.windMax[i] = wm == null ? 0 : wm.optDouble(i, 0);
            f.dates[i] = tm.optString(i, "");
        }
        f.place = place == null ? "" : place;
        f.at = System.currentTimeMillis();
        cached = f; cachedKey = key;
        return f;
    }

    // ------------------------------------------------------------- qué escena toca
    public static final int CLEAR = 0, CLOUDS = 1, FOG = 2, DRIZZLE = 3, RAIN = 4, SNOW = 5, STORM = 6;

    public static int kind(int code) {
        if (code == 0 || code == 1) return CLEAR;
        if (code == 2 || code == 3) return CLOUDS;
        if (code == 45 || code == 48) return FOG;
        if (code >= 51 && code <= 57) return DRIZZLE;
        if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return RAIN;
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) return SNOW;
        if (code >= 95) return STORM;
        return CLOUDS;
    }

    public static String icon(int code) {
        switch (kind(code)) {
            case CLEAR: return "☀";
            case CLOUDS: return code == 2 ? "⛅" : "☁";
            case FOG: return "🌫";
            case DRIZZLE: return "🌦";
            case RAIN: return "🌧";
            case SNOW: return "❄";
            case STORM: return "⛈";
        }
        return "☁";
    }

    /** Avisos sencillos (Open-Meteo no da alertas oficiales): calor, helada, viento, tormenta, lluvia fuerte. */
    public static String alerts(Fc f) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            String when = i == 0 ? L.t("hoy") : i == 1 ? L.t("mañana") : L.t("pasado mañana");
            if (f.codes[i] >= 95) add(b, "⚠ " + L.t("Tormenta") + " " + when);
            else if (f.rain[i] >= 80 && kind(f.codes[i]) == RAIN) add(b, "⚠ " + L.t("Lluvia fuerte") + " " + when);
            if (f.max[i] >= 35) add(b, "🔥 " + L.t("Mucho calor") + " " + when + " (" + Math.round(f.max[i]) + "°)");
            if (f.min[i] <= 0) add(b, "🧊 " + L.t("Helada") + " " + when + " (" + Math.round(f.min[i]) + "°)");
            if (f.windMax[i] >= 50) add(b, "💨 " + L.t("Viento fuerte") + " " + when + " (" + Math.round(f.windMax[i]) + " km/h)");
        }
        return b.toString();
    }

    static void add(StringBuilder b, String s) { if (b.length() > 0) b.append(" · "); b.append(s); }
}
