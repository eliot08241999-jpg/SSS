package com.aplauso.encuentra;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/**
 * v1.7 · FÚTBOL DE VERDAD: «¿cuándo juega la Roma?», «¿cómo quedó el Madrid?», «clasificación de la Serie A».
 * Datos públicos de ESPN (gratis, sin clave). Si no encuentra el equipo, lo dice; nunca se inventa un partido.
 * «Mi equipo es la Roma» lo apunta para «¿cuándo juega mi equipo?».
 */
public class Sports {
    static final String BASE = "https://site.api.espn.com/apis/site/v2/sports/soccer/";
    /** Ligas donde buscar equipos (y su nombre para decirlo). */
    static final String[][] LEAGUES = {
            {"ita.1", "Serie A"}, {"esp.1", "LaLiga"}, {"eng.1", "Premier League"}, {"ger.1", "Bundesliga"}, {"fra.1", "Ligue 1"},
            {"por.1", "Liga Portugal"}, {"ned.1", "Eredivisie"}, {"ita.2", "Serie B"}, {"esp.2", "LaLiga 2"},
            {"mex.1", "Liga MX"}, {"arg.1", "Liga Argentina"}, {"usa.1", "MLS"}, {"bra.1", "Brasileirão"},
    };
    /** Copas que también se miran para el próximo partido. */
    static final String[][] CUPS = {
            {"uefa.champions", "Champions League"}, {"uefa.europa", "Europa League"}, {"uefa.europa.conf", "Conference League"},
            {"ita.coppa_italia", "Coppa Italia"}, {"esp.copa_del_rey", "Copa del Rey"}, {"eng.fa", "FA Cup"},
    };
    /** Nombres de andar por casa → lo que hay que buscar. */
    static final Map<String, String> ALIAS = new LinkedHashMap<>();
    static {
        String[][] a = {
                {"roma|la roma|as roma", "roma"}, {"lazio", "lazio"}, {"juve|juventus|la juve", "juventus"}, {"inter|internazionale|el inter|l inter", "internazionale"},
                {"milan|el milan|ac milan", "ac milan"}, {"napoli|el napoles|napoles", "napoli"}, {"atalanta", "atalanta"}, {"fiorentina|la fiore", "fiorentina"},
                {"torino|el torino", "torino"}, {"bologna|bolonia", "bologna"}, {"genoa", "genoa"}, {"udinese", "udinese"}, {"como", "como"},
                {"real madrid|el madrid|madrid", "real madrid"}, {"barcelona|el barca|barca|el barcelona", "barcelona"}, {"atletico|atleti|atletico de madrid|el atleti", "atlético madrid"},
                {"sevilla|el sevilla", "sevilla"}, {"betis|real betis", "real betis"}, {"valencia", "valencia"}, {"villarreal", "villarreal"},
                {"athletic|athletic club|athletic de bilbao|bilbao", "athletic club"}, {"real sociedad|la real", "real sociedad"},
                {"manchester united|united|el united|man united", "manchester united"}, {"manchester city|city|el city|man city", "manchester city"},
                {"liverpool", "liverpool"}, {"arsenal", "arsenal"}, {"chelsea", "chelsea"}, {"tottenham|spurs", "tottenham"},
                {"bayern|bayern munich|el bayern", "bayern munich"}, {"dortmund|borussia dortmund|el dortmund", "borussia dortmund"},
                {"psg|paris saint germain|paris|el psg", "paris saint-germain"}, {"marsella|marseille|olympique de marsella", "marseille"},
                {"benfica", "benfica"}, {"oporto|porto", "porto"}, {"sporting|sporting de lisboa", "sporting cp"}, {"ajax", "ajax"},
                {"america|club america|el america", "américa"}, {"chivas|guadalajara", "guadalajara"}, {"boca|boca juniors", "boca juniors"}, {"river|river plate", "river plate"},
        };
        for (String[] x : a) ALIAS.put(x[0], x[1]);
    }

    static final List<String[]> lastSources = new ArrayList<>();

    // ---------------------------------------------------------------- ¿de qué va la pregunta?
    static final String FOOT = "juega|jugara|juegan|jugaran|partido|partidos|gano|perdio|empato|resultado|marcador|clasificacion|tabla|"
            + "gol|goles|quedo|como quedo|como ha quedado|como fue|liga|gioca|giochera|partita|partite|risultato|classifica|ha vinto|ha perso|"
            + "pareggiato|come e finita|com e andata|plays|play|match|game|score|standings|won|lost|win|wins|beat|playing|next game|table|derbi|derby|calcio|futbol|football|soccer";

    static boolean asks(String q) {
        String n = Actions.norm(q);
        if (n.matches("^(?:mi equipo es|mi equipo favorito es|soy del|soy de la|soy hincha del|soy hincha de la|tifo per|tifo la|tifo il|my team is)\\b.*")) return true;
        if (!n.matches(".*\\b(?:" + FOOT + ")\\b.*")) return false;
        if (n.matches(".*\\b(?:mi equipo|my team|la mia squadra)\\b.*")) return true;
        if (n.matches(".*\\b(?:clasificacion|classifica|standings|tabla)\\b.*") && league(n) != null) return true;
        return team(n) != null || (guess(n) != null && (n.matches(".*\\b(?:juega|jugara|gioca|giochera|play|plays) (?:el|il|lo|the) [a-z].*") || n.matches(".*\\b(?:partido|partidos|partita|partite|match|futbol|calcio|football|soccer|liga|resultado|risultato|gol|goles|clasificacion|classifica)\\b.*")));
    }

    /** El equipo que se nombra (texto para buscar), o null. */
    static String team(String n) {
        String best = null; int len = 0;
        for (Map.Entry<String, String> e : ALIAS.entrySet())
            for (String al : e.getKey().split("\\|")) {
                if (al.length() > len && n.matches(".*\\b" + java.util.regex.Pattern.quote(al) + "\\b.*")) {
                    // «madrid» suelto con «atletico» delante es el Atleti, «como» es demasiado común: solo «el como»
                    if (al.equals("como") && !n.matches(".*\\b(?:el|il|del|al|contra el|vs) como\\b.*")) continue;
                    if (al.equals("city") && !n.matches(".*\\b(?:el|il|del|al|the) city\\b.*")) continue;
                    if (al.equals("madrid") && n.contains("atletico")) continue;
                    if (al.equals("paris") && !n.matches(".*\\b(?:el|il|del) paris\\b.*")) continue;
                    best = e.getValue(); len = al.length();
                }
            }
        return best;
    }

    /** Un equipo que no está en la lista corta: «¿cuándo juega el Getafe?» / «partido del Lecce». */
    static String guess(String n) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\b(?:juega|jugara|juegan|gano|perdio|empato|quedo|partido de|partido del|partido de la|"
                + "gioca|giochera|partita del|partita della|partita di|ha vinto|ha perso|do|does|did)\\s+(?:el |la |los |las |il |lo |la |the )?([a-z][a-z ]{2,24}?)(?:\\s+(?:hoy|manana|ayer|el|este|esta|contra|en|oggi|domani|ieri|today|tomorrow|yesterday|play|win|lose)\\b|\\s*$)").matcher(n);
        if (m.find()) {
            String t = m.group(1).trim();
            if (!t.matches("(?:mi equipo|my team|la mia squadra|el|la|que|hoy|bien|mal|algo|a|un|una|fuera|en casa)")) return t;
        }
        return null;
    }

    static String[] league(String n) {
        if (n.matches(".*\\b(?:serie a|liga italiana|calcio)\\b.*")) return LEAGUES[0];
        if (n.matches(".*\\b(?:laliga|la liga|liga espanola|liga santander|primera division)\\b.*")) return LEAGUES[1];
        if (n.matches(".*\\b(?:premier|liga inglesa)\\b.*")) return LEAGUES[2];
        if (n.matches(".*\\b(?:bundesliga|liga alemana)\\b.*")) return LEAGUES[3];
        if (n.matches(".*\\b(?:ligue 1|liga francesa)\\b.*")) return LEAGUES[4];
        if (n.matches(".*\\b(?:serie b)\\b.*")) return LEAGUES[7];
        if (n.matches(".*\\b(?:liga mx|liga mexicana)\\b.*")) return LEAGUES[9];
        return null;
    }

    // ---------------------------------------------------------------- respuesta
    static String handle(Context c, String q) {
        String n = Actions.norm(q);
        String lang = Brain.langCode(q);
        synchronized (lastSources) { lastSources.clear(); }
        // «mi equipo es la Roma»
        java.util.regex.Matcher fav = java.util.regex.Pattern.compile("^(?:mi equipo es|mi equipo favorito es|soy del|soy de la|soy hincha del|soy hincha de la|tifo per|tifo la|tifo il|my team is)\\s+(?:el |la |il |the )?(.+)$").matcher(n);
        if (fav.find()) {
            String want = team(fav.group(1)) != null ? team(fav.group(1)) : fav.group(1).trim();
            try {
                Team t = find(c, want);
                if (t == null) return say(lang, "No encuentro ese equipo. Dímelo con su nombre completo, por ejemplo «mi equipo es la Roma».",
                        "Non trovo quella squadra. Dimmi il nome completo, per esempio «la mia squadra è la Roma».", "I can't find that team. Try its full name.");
                Brain.prefs(c).edit().putString("sports_team", t.name).apply();
                return say(lang, "¡Apuntado! Tu equipo es el " + t.name + ". Pregúntame «¿cuándo juega mi equipo?» cuando quieras.",
                        "Segnato! La tua squadra è " + t.name + ". Chiedimi «quando gioca la mia squadra?».", "Got it! Your team is " + t.name + ".");
            } catch (Exception e) { return noNet(lang); }
        }
        String want = n.matches(".*\\b(?:mi equipo|my team|la mia squadra)\\b.*") ? Brain.prefs(c).getString("sports_team", "") : (team(n) != null ? team(n) : guess(n));
        if (want != null && want.isEmpty())
            return say(lang, "Aún no sé cuál es tu equipo. Dime, por ejemplo, «mi equipo es la Roma».", "Non so ancora qual è la tua squadra. Dimmi «la mia squadra è la Roma».",
                    "I don't know your team yet. Say «my team is Roma».");
        boolean table = n.matches(".*\\b(?:clasificacion|classifica|standings|tabla|posicion|puesto|lider|primero|primeros|capolista)\\b.*");
        boolean past = n.matches(".*\\b(?:gano|perdio|empato|quedo|como quedo|ha quedado|resultado|marcador|como fue|ultimo partido|ayer|anoche|ha vinto|ha perso|"
                + "pareggiato|risultato|come e finita|com e andata|ieri|won|lost|did|result|score|last match|yesterday)\\b.*");
        try {
            if (want == null) {                                   // «clasificación de la Serie A»
                String[] lg = league(n);
                return lg == null ? null : standings(lg, null, lang);
            }
            Team t = find(c, want);
            if (t == null) return say(lang, "No encuentro a ese equipo en las ligas que conozco.", "Non trovo quella squadra nei campionati che conosco.",
                    "I can't find that team in the leagues I know.");
            if (table) return standings(new String[]{t.league, t.leagueName}, t, lang);
            Ev last = lastMatch(t), next = nextMatch(t);
            StringBuilder b = new StringBuilder();
            if (past) {
                if (last != null) b.append(resultLine(t, last, lang));
                else b.append(say(lang, "No encuentro su último resultado.", "Non trovo il suo ultimo risultato.", "I can't find its last result."));
                if (next != null) b.append(" ").append(nextLine(t, next, lang, true));
            } else {
                if (next != null) b.append(nextLine(t, next, lang, false));
                else b.append(say(lang, "No encuentro ningún partido programado del " + t.name + " ahora mismo.", "Non trovo partite in programma per " + t.name + ".",
                        "I can't find any scheduled match for " + t.name + "."));
                if (last != null) b.append(" ").append(resultLine(t, last, lang));
            }
            synchronized (lastSources) { lastSources.add(new String[]{"ESPN", "https://www.espn.com/soccer/team/_/id/" + t.id}); }
            return b.toString().trim();
        } catch (Exception e) { return noNet(lang); }
    }

    static String noNet(String lang) {
        return say(lang, "No he podido mirar el fútbol ahora (¿hay internet?).", "Non riesco a guardare il calcio adesso (c'è internet?).", "I couldn't check football right now (is there internet?).");
    }

    // ---------------------------------------------------------------- equipos
    static final class Team { String id, name, league, leagueName; }

    static Team find(Context c, String want) throws Exception {
        String w = Actions.norm(want);
        Team best = null; int bestScore = 0;
        for (String[] lg : LEAGUES) {
            JSONArray teams = teams(c, lg[0]);
            for (int i = 0; i < teams.length(); i++) {
                JSONObject t = teams.getJSONObject(i).optJSONObject("team");
                if (t == null) continue;
                int sc = score(w, t);
                if (sc > bestScore) {
                    bestScore = sc;
                    best = new Team();
                    best.id = t.optString("id"); best.name = t.optString("displayName"); best.league = lg[0]; best.leagueName = lg[1];
                }
            }
            if (bestScore >= 100) break;                     // exacto: no hace falta mirar más ligas
        }
        return bestScore >= 40 ? best : null;
    }

    static int score(String w, JSONObject t) {
        int best = 0;
        for (String k : new String[]{"displayName", "shortDisplayName", "name", "nickname", "location", "abbreviation"}) {
            String v = Actions.norm(t.optString(k)).replace("-", " ");
            if (v.isEmpty()) continue;
            if (v.equals(w)) best = Math.max(best, 100);
            else if (v.matches(".*\\b" + java.util.regex.Pattern.quote(w) + "\\b.*")) best = Math.max(best, 70 - Math.min(30, v.length() - w.length()));
            else if (w.matches(".*\\b" + java.util.regex.Pattern.quote(v) + "\\b.*") && v.length() >= 4) best = Math.max(best, 50);
        }
        return best;
    }

    /** La lista de equipos de una liga (guardada 7 días). */
    static JSONArray teams(Context c, String league) throws Exception {
        String key = "sports_teams_" + league;
        String cached = Brain.prefs(c).getString(key, "");
        try {
            if (!cached.isEmpty()) {
                JSONObject o = new JSONObject(cached);
                if (System.currentTimeMillis() - o.optLong("t") < 7L * 86_400_000L) return o.getJSONArray("teams");
            }
        } catch (Exception ignored) {}
        JSONObject j = new JSONObject(Web.get(BASE + league + "/teams"));
        JSONArray teams = j.getJSONArray("sports").getJSONObject(0).getJSONArray("leagues").getJSONObject(0).getJSONArray("teams");
        // solo lo que hace falta
        JSONArray slim = new JSONArray();
        for (int i = 0; i < teams.length(); i++) {
            JSONObject t = teams.getJSONObject(i).optJSONObject("team");
            if (t == null) continue;
            JSONObject s = new JSONObject();
            for (String k : new String[]{"id", "displayName", "shortDisplayName", "name", "nickname", "location", "abbreviation"}) s.put(k, t.optString(k));
            slim.put(new JSONObject().put("team", s));
        }
        Brain.prefs(c).edit().putString(key, new JSONObject().put("t", System.currentTimeMillis()).put("teams", slim).toString()).apply();
        return slim;
    }

    // ---------------------------------------------------------------- partidos
    static final class Ev { long when; String home, away, homeScore, awayScore, comp, state, venue; boolean homeIsUs; }

    static List<Ev> schedule(String league, String compName, String teamId, boolean fixtures) {
        List<Ev> out = new ArrayList<>();
        try {
            JSONObject j = new JSONObject(Web.get(BASE + league + "/teams/" + teamId + "/schedule" + (fixtures ? "?fixture=true" : "")));
            JSONArray ev = j.optJSONArray("events");
            if (ev == null) return out;
            for (int i = 0; i < ev.length(); i++) {
                JSONObject e = ev.getJSONObject(i);
                JSONObject comp = e.optJSONArray("competitions") != null && e.getJSONArray("competitions").length() > 0 ? e.getJSONArray("competitions").getJSONObject(0) : null;
                if (comp == null) continue;
                Ev x = new Ev();
                x.when = iso(comp.optString("date", e.optString("date")));
                x.comp = compName;
                JSONObject st = comp.optJSONObject("status");
                if (st == null) st = e.optJSONObject("status");
                x.state = st != null && st.optJSONObject("type") != null ? st.getJSONObject("type").optString("state") : "";
                JSONObject venue = comp.optJSONObject("venue");
                x.venue = venue == null ? "" : venue.optString("fullName");
                JSONArray cs = comp.optJSONArray("competitors");
                if (cs == null) continue;
                for (int k = 0; k < cs.length(); k++) {
                    JSONObject t = cs.getJSONObject(k);
                    JSONObject tm = t.optJSONObject("team");
                    String nm = tm == null ? "?" : tm.optString("displayName", tm.optString("shortDisplayName"));
                    String sc = scoreOf(t.opt("score"));
                    if ("home".equals(t.optString("homeAway"))) { x.home = nm; x.homeScore = sc; if (tm != null && teamId.equals(tm.optString("id"))) x.homeIsUs = true; }
                    else { x.away = nm; x.awayScore = sc; }
                }
                if (x.home != null && x.away != null && x.when > 0) out.add(x);
            }
        } catch (Exception ignored) {}
        return out;
    }

    static String scoreOf(Object o) {
        if (o == null) return "";
        if (o instanceof JSONObject) { JSONObject s = (JSONObject) o; return s.optString("displayValue", s.has("value") ? String.valueOf((int) s.optDouble("value")) : ""); }
        String s = String.valueOf(o);
        return s.equals("null") ? "" : s.replaceAll("\\.0$", "");
    }

    static Ev nextMatch(Team t) {
        Ev best = null;
        long now = System.currentTimeMillis() - 2 * 3_600_000L;      // un partido que empezó hace un rato sigue siendo «el de hoy»
        List<String[]> comps = new ArrayList<>();
        comps.add(new String[]{t.league, t.leagueName});
        for (String[] cu : CUPS) comps.add(cu);
        for (String[] cp : comps)
            for (Ev e : schedule(cp[0], cp[1], t.id, true))
                if (e.when >= now && !"post".equals(e.state) && (best == null || e.when < best.when)) best = e;
        return best;
    }

    static Ev lastMatch(Team t) {
        Ev best = null;
        List<String[]> comps = new ArrayList<>();
        comps.add(new String[]{t.league, t.leagueName});
        for (String[] cu : CUPS) comps.add(cu);
        for (String[] cp : comps)
            for (Ev e : schedule(cp[0], cp[1], t.id, false))
                if (("post".equals(e.state) || (e.state.isEmpty() && !e.homeScore.isEmpty())) && e.when <= System.currentTimeMillis()
                        && (best == null || e.when > best.when)) best = e;
        return best;
    }

    static String nextLine(Team t, Ev e, String lang, boolean also) {
        String rival = e.homeIsUs ? e.away : e.home;
        String where = e.homeIsUs ? say(lang, "en casa", "in casa", "at home") : say(lang, "fuera", "in trasferta", "away");
        String when = whenText(e.when, lang);
        if ("in".equals(e.state)) return say(lang, "¡El " + t.name + " está jugando ahora mismo contra el " + rival + "! Van " + e.homeScore + " a " + e.awayScore + ".",
                t.name + " sta giocando adesso contro " + rival + "! " + e.homeScore + " a " + e.awayScore + ".",
                t.name + " is playing " + rival + " right now! It's " + e.homeScore + "-" + e.awayScore + ".");
        return say(lang, (also ? "El próximo: " : "El " + t.name + " juega ") + when + " contra el " + rival + ", " + where + " (" + e.comp + ").",
                (also ? "La prossima: " : t.name + " gioca ") + when + " contro " + rival + ", " + where + " (" + e.comp + ").",
                (also ? "Next: " : t.name + " plays ") + when + " against " + rival + ", " + where + " (" + e.comp + ").");
    }

    static String resultLine(Team t, Ev e, String lang) {
        int us, them;
        try {
            us = Integer.parseInt((e.homeIsUs ? e.homeScore : e.awayScore).replaceAll("\\D.*", ""));
            them = Integer.parseInt((e.homeIsUs ? e.awayScore : e.homeScore).replaceAll("\\D.*", ""));
        } catch (Exception ex) { us = them = -1; }
        String rival = e.homeIsUs ? e.away : e.home;
        String day = whenText(e.when, lang).replaceAll(",? a las .*| alle .*| at .*", "");
        String verb = us < 0 ? say(lang, "jugó", "ha giocato", "played") : us > them ? say(lang, "ganó", "ha vinto", "won") : us < them ? say(lang, "perdió", "ha perso", "lost")
                : say(lang, "empató", "ha pareggiato", "drew");
        String score = us < 0 ? "" : " " + us + "-" + them;
        return say(lang, "El último partido lo " + verb + score + " contra el " + rival + " (" + day + ", " + e.comp + ").",
                "L'ultima partita: " + verb + score + " contro " + rival + " (" + day + ", " + e.comp + ").",
                "Last match: " + verb + score + " against " + rival + " (" + day + ", " + e.comp + ").");
    }

    // ---------------------------------------------------------------- clasificación
    static String standings(String[] lg, Team t, String lang) throws Exception {
        JSONObject j = new JSONObject(Web.get("https://site.api.espn.com/apis/v2/sports/soccer/" + lg[0] + "/standings"));
        JSONArray children = j.optJSONArray("children");
        JSONObject holder = children != null && children.length() > 0 ? children.getJSONObject(0) : j;
        JSONArray entries = holder.getJSONObject("standings").getJSONArray("entries");
        List<String[]> rows = new ArrayList<>();          // {pos, nombre, puntos, jugados, id}
        for (int i = 0; i < entries.length(); i++) {
            JSONObject en = entries.getJSONObject(i);
            JSONObject tm = en.getJSONObject("team");
            String pts = "", gp = "", rank = String.valueOf(i + 1);
            JSONArray st = en.optJSONArray("stats");
            if (st != null) for (int k = 0; k < st.length(); k++) {
                JSONObject s = st.getJSONObject(k);
                String nm = s.optString("name");
                String v = s.optString("displayValue", String.valueOf((int) s.optDouble("value")));
                if (nm.equals("points")) pts = v; else if (nm.equals("gamesPlayed")) gp = v; else if (nm.equals("rank")) rank = v;
            }
            rows.add(new String[]{rank, tm.optString("displayName"), pts, gp, tm.optString("id")});
        }
        rows.sort((a, b) -> { try { return Integer.parseInt(a[0]) - Integer.parseInt(b[0]); } catch (Exception e) { return 0; } });
        synchronized (lastSources) { lastSources.add(new String[]{"ESPN", "https://www.espn.com/soccer/standings/_/league/" + lg[0]}); }
        StringBuilder b = new StringBuilder();
        if (t != null) {
            for (String[] r : rows) if (r[4].equals(t.id)) {
                b.append(say(lang, "El " + t.name + " va " + r[0] + "º en la " + lg[1] + " con " + r[2] + " puntos en " + r[3] + " partidos.",
                        t.name + " è " + r[0] + "º in " + lg[1] + " con " + r[2] + " punti in " + r[3] + " partite.",
                        t.name + " is " + ord(r[0]) + " in the " + lg[1] + " with " + r[2] + " points from " + r[3] + " games."));
            }
            if (!rows.isEmpty()) b.append(say(lang, " El líder es el " + rows.get(0)[1] + " con " + rows.get(0)[2] + ".",
                    " In testa c'è " + rows.get(0)[1] + " con " + rows.get(0)[2] + ".", " The leader is " + rows.get(0)[1] + " with " + rows.get(0)[2] + "."));
            return b.toString().trim();
        }
        b.append(say(lang, "Así va la " + lg[1] + ": ", "Ecco la " + lg[1] + ": ", "Here's the " + lg[1] + ": "));
        for (int i = 0; i < Math.min(5, rows.size()); i++) {
            String[] r = rows.get(i);
            b.append(r[0]).append("º ").append(r[1]).append(" ").append(r[2]).append(say(lang, " puntos", " punti", " pts")).append(i < Math.min(5, rows.size()) - 1 ? "; " : ".");
        }
        return b.toString();
    }

    static String ord(String n) { return n + (n.endsWith("1") && !n.endsWith("11") ? "st" : n.endsWith("2") && !n.endsWith("12") ? "nd" : n.endsWith("3") && !n.endsWith("13") ? "rd" : "th"); }

    // ---------------------------------------------------------------- fechas
    static long iso(String s) {
        if (s == null || s.isEmpty()) return 0;
        for (String f : new String[]{"yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"}) {
            try {
                SimpleDateFormat df = new SimpleDateFormat(f, Locale.ROOT);
                df.setTimeZone(TimeZone.getTimeZone("UTC"));
                return df.parse(s).getTime();
            } catch (Exception ignored) {}
        }
        return 0;
    }

    /** «hoy a las 20:45», «mañana a las 18:00», «el sábado 22 a las 15:00». */
    static String whenText(long t, String lang) {
        Calendar now = Calendar.getInstance(), k = Calendar.getInstance();
        k.setTimeInMillis(t);
        int days = (int) ((startOfDay(k) - startOfDay(now)) / 86_400_000L);
        String hh = new SimpleDateFormat("HH:mm", Locale.ROOT).format(new Date(t));
        String[] dEs = {"domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"};
        String[] dIt = {"domenica", "lunedì", "martedì", "mercoledì", "giovedì", "venerdì", "sabato"};
        String[] dEn = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        int dow = k.get(Calendar.DAY_OF_WEEK) - 1, dom = k.get(Calendar.DAY_OF_MONTH);
        String[] mEs = {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"};
        String[] mIt = {"gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre"};
        String[] mEn = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        int mo = k.get(Calendar.MONTH);
        String dayEs = days == 0 ? "hoy" : days == 1 ? "mañana" : days == -1 ? "ayer" : days > 1 && days < 7 ? "el " + dEs[dow] : "el " + dEs[dow] + " " + dom + " de " + mEs[mo];
        String dayIt = days == 0 ? "oggi" : days == 1 ? "domani" : days == -1 ? "ieri" : days > 1 && days < 7 ? dIt[dow] : dIt[dow] + " " + dom + " " + mIt[mo];
        String dayEn = days == 0 ? "today" : days == 1 ? "tomorrow" : days == -1 ? "yesterday" : days > 1 && days < 7 ? "on " + dEn[dow] : "on " + dEn[dow] + ", " + mEn[mo] + " " + dom;
        return say(lang, dayEs + " a las " + hh, dayIt + " alle " + hh, dayEn + " at " + hh);
    }

    static long startOfDay(Calendar c) {
        Calendar k = (Calendar) c.clone();
        k.set(Calendar.HOUR_OF_DAY, 0); k.set(Calendar.MINUTE, 0); k.set(Calendar.SECOND, 0); k.set(Calendar.MILLISECOND, 0);
        return k.getTimeInMillis();
    }

    static String say(String lang, String es, String it, String en) { return "it".equals(lang) ? it : "en".equals(lang) ? en : es; }
}
