package com.aplauso.encuentra;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** Centro de documentos: leer, editar, convertir entre PDF/EPUB/DOCX/TXT y crear nuevos. */
public class DocsActivity extends NeonActivity {
    static final int REQ_READ = 50, REQ_EDIT = 51, REQ_CONVERT = 52;
    static final String[] DOC_MIMES = {"application/pdf", "application/epub+zip",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain", "text/html"};

    TextView status;
    LinearLayout recent;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("DOCUMENTOS");

        LinearLayout acts = panel("◢ ¿QUÉ QUIERES HACER?");
        acts.addView(spaced(button("📖 LEER UN DOCUMENTO", v -> pick(REQ_READ))));
        acts.addView(spaced(button("✏ EDITAR TEXTO", v -> pick(REQ_EDIT))));
        acts.addView(spaced(button("🔄 CONVERTIR (PDF · EPUB · DOCX · TXT)", v -> pick(REQ_CONVERT))));
        acts.addView(spaced(button("📝 NUEVO DOCUMENTO", v -> startActivity(new Intent(this, DocEditActivity.class)))));
        acts.addView(spaced(button("📚 MI BIBLIOTECA", v -> startActivity(new Intent(this, LibraryActivity.class)))));
        col.addView(acts, gapBelow(14));

        status = text("", 13);
        col.addView(status, gapBelow(10));

        recent = panel("◢ TUS DOCUMENTOS");
        col.addView(recent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        fillRecent();
    }

    void fillRecent() {
        recent.removeAllViews();
        recent.addView(neonText("◢ TUS DOCUMENTOS", 13));
        if (!Media.allFiles(this)) {
            recent.addView(text("Para ver aquí los documentos de todo el teléfono (descargas, WhatsApp, Telegram…), "
                    + "SSS+ necesita \"Acceso a todos los archivos\". Si no quieres darlo, usa los botones de arriba.", 13));
            recent.addView(spaced(button("🔓 PERMITIR ACCESO", v -> Media.requestAllFiles(this))));
            return;
        }
        TextView loading = text("Buscando documentos…", 13);
        recent.addView(loading);
        new Thread(() -> {
            List<Media.Item> docs = Media.scanDocs(60);
            runOnUiThread(() -> {
                recent.removeView(loading);
                if (docs.isEmpty()) { recent.addView(text("No he encontrado documentos.", 13)); return; }
                for (Media.Item it : docs) {
                    TextView row = button(icon(it.name) + "  " + it.name + "\n      " + SysInfo.bytes(it.size), v -> openOptions(it.uri, it.name));
                    row.setGravity(android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL);
                    row.setTextSize(12);
                    recent.addView(spaced(row));
                }
            });
        }).start();
    }

    static String icon(String name) {
        String t = DocIO.typeOf(name);
        if ("pdf".equals(t)) return "📕";
        if ("epub".equals(t)) return "📗";
        if ("docx".equals(t)) return "📘";
        return "📄";
    }

    void openOptions(Uri u, String name) {
        String[] ops = {"📖 Leer", "✏ Editar texto", "🔄 Convertir", "📚 Añadir a la biblioteca"};
        new AlertDialog.Builder(this).setTitle(name).setItems(ops, (d, w) -> {
            if (w == 0) startActivity(new Intent(this, DocReaderActivity.class).setData(u));
            else if (w == 1) startActivity(new Intent(this, DocEditActivity.class).setData(u));
            else if (w == 2) convert(u);
            else { LibraryActivity.add(this, u, name); toast("Añadido a tu biblioteca ✓"); }
        }).show();
    }

    android.view.View spaced(android.view.View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dpi(8);
        v.setLayoutParams(lp);
        return v;
    }

    void pick(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, DOC_MIMES);
        startActivityForResult(i, req);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req < REQ_READ || req > REQ_CONVERT) { super.onActivityResult(req, res, data); return; }
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        if (req == REQ_READ) startActivity(new Intent(this, DocReaderActivity.class).setData(u));
        else if (req == REQ_EDIT) startActivity(new Intent(this, DocEditActivity.class).setData(u));
        else convert(u);
    }

    void convert(Uri u) {
        String name = Media.nameOf(this, u);
        String[] names = {"PDF", "EPUB (libro electrónico)", "DOCX (Word)", "TXT (texto)"};
        new AlertDialog.Builder(this)
                .setTitle("Convertir \"" + name + "\" a…")
                .setItems(names, (d, w) -> doConvert(u, DocIO.FORMATS[w]))
                .show();
    }

    void doConvert(Uri u, String format) {
        status.setText("🔄 Convirtiendo a " + format.toUpperCase() + "…");
        new Thread(() -> {
            Uri out = null;
            String err = null;
            try {
                DocIO.Doc d = DocPdf.load(this, u);
                out = DocPdf.saveAs(this, d, format);
            } catch (Throwable t) { err = t.getMessage(); }
            Uri fo = out;
            String fe = err;
            runOnUiThread(() -> {
                if (fo == null) { status.setText("No se pudo convertir" + (fe != null ? ": " + fe : "")); return; }
                status.setText("✓ Convertido a " + format.toUpperCase() + " en Documentos/SSS");
                new AlertDialog.Builder(this).setTitle("¡Listo!")
                        .setMessage("Guardado en Documentos/SSS como " + format.toUpperCase() + "."
                                + ("pdf".equals(DocIO.typeOf(Media.nameOf(this, u))) ? "\n\nDesde un PDF se convierte el texto, sin el diseño original." : ""))
                        .setPositiveButton("Abrir", (x, y) -> startActivity(new Intent(this, DocReaderActivity.class).setData(fo)))
                        .setNegativeButton("Cerrar", null).show();
            });
        }).start();
    }
}
