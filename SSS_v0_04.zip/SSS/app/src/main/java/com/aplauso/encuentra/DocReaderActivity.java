package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Lector de documentos: texto con tamaño ajustable, páginas originales del PDF y lectura en voz alta. */
public class DocReaderActivity extends NeonActivity {
    Uri uri;
    String key;
    DocIO.Doc doc;
    DocPdf.Pages pages;
    boolean pageMode;
    ListView list;
    TextView status, titleView, speakBtn, rateBtn, modeBtn;
    final Adapter adapter = new Adapter();
    TextToSpeech tts;
    boolean ttsReady, speaking;
    int speakIdx = -1, fontSize;
    float rate = 1f;
    final ExecutorService ex = Executors.newSingleThreadExecutor();
    final LruCache<Integer, Bitmap> cache = new LruCache<Integer, Bitmap>(40 * 1024 * 1024) {
        @Override protected int sizeOf(Integer k, Bitmap b) { return b.getByteCount(); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        uri = getIntent().getData();
        key = uri == null ? "x" : Integer.toHexString(uri.toString().hashCode());
        fontSize = p.getInt("reader_size", 18);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(10), dpi(14), dpi(10), dpi(6));
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(circleButton("←", v -> finish()), new LinearLayout.LayoutParams(dpi(42), dpi(42)));
        titleView = neonText("  Cargando…", 15);
        titleView.setSingleLine(true);
        top.addView(titleView, new LinearLayout.LayoutParams(0, -2, 1));
        col.addView(top, gapBelow(8));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = new LinearLayout(this);
        speakBtn = tool(tools, "🔊 LEER EN VOZ", v -> toggleSpeak());
        rateBtn = tool(tools, "VEL 1x", v -> cycleRate());
        tool(tools, "A−", v -> setFont(fontSize - 2));
        tool(tools, "A+", v -> setFont(fontSize + 2));
        modeBtn = tool(tools, "📄 PÁGINAS", v -> toggleMode());
        modeBtn.setVisibility(View.GONE);
        tool(tools, "✏ EDITAR", v -> startActivity(new Intent(this, DocEditActivity.class).setData(uri)));
        tool(tools, "📚 A BIBLIOTECA", v -> {
            LibraryActivity.add(this, uri, Media.nameOf(this, uri));
            toast("Añadido a tu biblioteca ✓");
        });
        hs.addView(tools);
        col.addView(hs, gapBelow(8));

        list = new ListView(this);
        list.setDividerHeight(0);
        list.setAdapter(adapter);
        list.setBackground(frame(12));
        list.setPadding(dpi(6), dpi(6), dpi(6), dpi(6));
        list.setOnItemClickListener((parent, view, pos, id) -> { if (speaking && !pageMode) speak(pos); });
        col.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        status = text("", 12);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dpi(6), 0, 0);
        col.addView(status);
        setContentView(makeRoot(col));

        tts = new TextToSpeech(this, st -> {
            ttsReady = st == TextToSpeech.SUCCESS;
            if (ttsReady) {
                int r = tts.setLanguage(Locale.getDefault());
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(new Locale("es", "ES"));
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    public void onStart(String id) {}
                    public void onDone(String id) { runOnUiThread(() -> { if (speaking) speak(speakIdx + 1); }); }
                    @Override public void onError(String id) { runOnUiThread(() -> { if (speaking) speak(speakIdx + 1); }); }
                });
            }
        });

        if (uri == null) { titleView.setText("  Sin documento"); return; }
        ex.execute(() -> {
            try {
                DocIO.Doc d = DocPdf.load(this, uri);
                DocPdf.Pages pg = null;
                if ("pdf".equals(d.type)) { try { pg = new DocPdf.Pages(this, uri); } catch (Exception ignored) {} }
                DocPdf.Pages fpg = pg;
                runOnUiThread(() -> loaded(d, fpg));
            } catch (Throwable t) {
                runOnUiThread(() -> {
                    titleView.setText("  No se pudo abrir");
                    status.setText("Error: " + t.getMessage());
                });
            }
        });
    }

    TextView tool(LinearLayout parent, String label, View.OnClickListener l) {
        TextView t = button(label, l);
        t.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dpi(6);
        parent.addView(t, lp);
        return t;
    }

    void loaded(DocIO.Doc d, DocPdf.Pages pg) {
        doc = d;
        pages = pg;
        titleView.setText("  " + (d.title.isEmpty() ? Media.nameOf(this, uri) : d.title));
        if (pages != null) {
            modeBtn.setVisibility(View.VISIBLE);
            pageMode = p.getBoolean("rmode_" + key, true);
            modeBtn.setText(pageMode ? "📝 TEXTO" : "📄 PÁGINAS");
        }
        adapter.notifyDataSetChanged();
        int pos = pageMode ? p.getInt("rpage_" + key, 0) : p.getInt("rpos_" + key, 0);
        if (pos > 0 && pos < adapter.getCount()) list.setSelection(pos);
        if (doc.paras.isEmpty() && pages == null) status.setText("El documento no tiene texto que mostrar.");
    }

    void setFont(int s) {
        fontSize = Math.max(12, Math.min(40, s));
        p.edit().putInt("reader_size", fontSize).apply();
        adapter.notifyDataSetChanged();
    }

    void toggleMode() {
        if (pages == null) return;
        int first = list.getFirstVisiblePosition();
        float frac = adapter.getCount() == 0 ? 0 : first / (float) adapter.getCount();
        pageMode = !pageMode;
        p.edit().putBoolean("rmode_" + key, pageMode).apply();
        modeBtn.setText(pageMode ? "📝 TEXTO" : "📄 PÁGINAS");
        adapter.notifyDataSetChanged();
        list.setSelection(Math.round(frac * adapter.getCount()));
    }

    void cycleRate() {
        float[] rates = {0.75f, 1f, 1.25f, 1.5f, 2f};
        int i = 0;
        while (i < rates.length && rates[i] <= rate + 0.01f) i++;
        rate = rates[i % rates.length];
        rateBtn.setText("VEL " + (rate == (int) rate ? String.valueOf((int) rate) : String.valueOf(rate)) + "x");
        if (tts != null) tts.setSpeechRate(rate);
        if (speaking) speak(speakIdx);
    }

    void toggleSpeak() {
        if (doc == null) return;
        if (!ttsReady) { toast("La voz del teléfono aún no está lista"); return; }
        if (speaking) {
            speaking = false;
            tts.stop();
            speakBtn.setText("🔊 LEER EN VOZ");
            return;
        }
        speaking = true;
        speakBtn.setText("⏸ PARAR VOZ");
        int start = list.getFirstVisiblePosition();
        if (pageMode && pages != null && pages.count() > 0)
            start = Math.round(start / (float) pages.count() * doc.paras.size());
        speak(start);
    }

    void speak(int i) {
        if (doc == null || i < 0) return;
        if (i >= doc.paras.size()) {
            speaking = false;
            speakIdx = -1;
            speakBtn.setText("🔊 LEER EN VOZ");
            adapter.notifyDataSetChanged();
            return;
        }
        speakIdx = i;
        tts.setSpeechRate(rate);
        tts.speak(doc.paras.get(i), TextToSpeech.QUEUE_FLUSH, null, "p" + i);
        if (!pageMode) {
            adapter.notifyDataSetChanged();
            if (i < list.getFirstVisiblePosition() || i > list.getLastVisiblePosition()) list.setSelection(i);
        }
    }

    @Override
    protected void onTick() {
        if (doc == null || adapter.getCount() == 0) return;
        int first = list.getFirstVisiblePosition();
        int pct = Math.round(100f * (first + 1) / adapter.getCount());
        status.setText((pageMode ? "Página " + (first + 1) + " de " + adapter.getCount() : "Párrafo " + (first + 1) + " de " + adapter.getCount())
                + " · " + pct + " %" + (speaking ? " · 🔊 leyendo" : ""));
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (doc == null) return;
        int first = list.getFirstVisiblePosition();
        int total = adapter.getCount();
        p.edit().putInt(pageMode ? "rpage_" + key : "rpos_" + key, first)
                .putInt("rpct_" + key, total == 0 ? 0 : Math.round(100f * (first + 1) / total)).apply();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        ex.shutdownNow();
        if (pages != null) pages.close();
    }

    class Adapter extends BaseAdapter {
        @Override public int getCount() {
            if (doc == null) return 0;
            return pageMode && pages != null ? pages.count() : doc.paras.size();
        }
        @Override public Object getItem(int i) { return i; }
        @Override public long getItemId(int i) { return i; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int i) { return pageMode && pages != null ? 1 : 0; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            if (pageMode && pages != null) {
                ImageView iv = convert instanceof ImageView ? (ImageView) convert : new ImageView(DocReaderActivity.this);
                iv.setAdjustViewBounds(true);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iv.setPadding(0, 0, 0, dpi(6));
                iv.setTag(pos);
                int w = Math.max(400, list.getWidth() - dpi(12));
                Bitmap bm = cache.get(pos);
                if (bm != null) iv.setImageBitmap(bm);
                else {
                    iv.setImageBitmap(null);
                    iv.setMinimumHeight(Math.round(w * 1.41f));
                    ex.execute(() -> {
                        Bitmap r = pages.render(pos, w);
                        if (r == null) return;
                        cache.put(pos, r);
                        runOnUiThread(() -> { if (Integer.valueOf(pos).equals(iv.getTag())) { iv.setMinimumHeight(0); iv.setImageBitmap(r); } });
                    });
                }
                return iv;
            }
            TextView t = convert instanceof TextView ? (TextView) convert : new TextView(DocReaderActivity.this);
            t.setText(doc.paras.get(pos));
            t.setTextSize(fontSize);
            t.setTextColor(Color.rgb(230, 232, 240));
            t.setLineSpacing(0, 1.25f);
            t.setPadding(dpi(10), dpi(6), dpi(10), dpi(10));
            t.setBackgroundColor(pos == speakIdx ? Color.argb(70, 0, 229, 255) : Color.TRANSPARENT);
            return t;
        }
    }
}
