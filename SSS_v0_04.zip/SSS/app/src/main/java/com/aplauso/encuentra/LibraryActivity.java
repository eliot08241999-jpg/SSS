package com.aplauso.encuentra;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Biblioteca: los libros y documentos que tú eliges, con el progreso de lectura de cada uno. */
public class LibraryActivity extends NeonActivity {
    static final int REQ_ADD = 60;

    static class Book {
        String uri, name;
        long added;
    }

    // ---------------- almacenamiento ----------------
    static List<Book> load(Context c) {
        List<Book> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("library", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Book b = new Book();
                b.uri = o.getString("uri");
                b.name = o.getString("name");
                b.added = o.optLong("added", 0);
                out.add(b);
            }
        } catch (Exception ignored) {}
        return out;
    }

    static void store(Context c, List<Book> books) {
        try {
            JSONArray a = new JSONArray();
            for (Book b : books) {
                JSONObject o = new JSONObject();
                o.put("uri", b.uri);
                o.put("name", b.name);
                o.put("added", b.added);
                a.put(o);
            }
            c.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString("library", a.toString()).apply();
        } catch (Exception ignored) {}
    }

    static void add(Context c, Uri uri, String name) {
        List<Book> books = load(c);
        for (Book b : books) if (b.uri.equals(uri.toString())) return;
        Book b = new Book();
        b.uri = uri.toString();
        b.name = name;
        b.added = System.currentTimeMillis();
        books.add(0, b);
        store(c, books);
    }

    static int progress(Context c, String uri) {
        SharedPreferences p = c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        return p.getInt("rpct_" + Integer.toHexString(uri.hashCode()), 0);
    }

    // ---------------- pantalla ----------------
    LinearLayout shelf;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("BIBLIOTECA");
        LinearLayout addP = panel("◢ AÑADIR");
        addP.addView(spaced(button("➕ ELEGIR LIBROS DEL TELÉFONO", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, DocsActivity.DOC_MIMES);
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(i, REQ_ADD);
        })));
        addP.addView(spaced(button("📂 DESDE MIS DOCUMENTOS", v -> fromScan())));
        col.addView(addP, gapBelow(14));
        shelf = panel("◢ TUS LIBROS");
        col.addView(shelf);
    }

    @Override
    protected void onResume() {
        super.onResume();
        fill();
    }

    void fill() {
        shelf.removeAllViews();
        shelf.addView(neonText("◢ TUS LIBROS", 13));
        List<Book> books = load(this);
        if (books.isEmpty()) {
            shelf.addView(text("Tu biblioteca está vacía. Añade libros o documentos y los tendrás siempre a mano, "
                    + "con la página donde te quedaste y lectura en voz alta.", 13));
            return;
        }
        for (Book bk : books) {
            int pct = progress(this, bk.uri);
            TextView row = button(DocsActivity.icon(bk.name) + "  " + bk.name + "\n      " + (pct > 0 ? "Leído " + pct + " %" : "Sin empezar"),
                    v -> startActivity(new Intent(this, DocReaderActivity.class).setData(Uri.parse(bk.uri))));
            row.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            row.setTextSize(13);
            row.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setTitle(bk.name)
                        .setItems(new String[]{"📖 Leer", "✏ Editar texto", "🗑 Quitar de la biblioteca"}, (d, w) -> {
                            if (w == 0) startActivity(new Intent(this, DocReaderActivity.class).setData(Uri.parse(bk.uri)));
                            else if (w == 1) startActivity(new Intent(this, DocEditActivity.class).setData(Uri.parse(bk.uri)));
                            else {
                                List<Book> all = load(this);
                                for (int i = 0; i < all.size(); i++) if (all.get(i).uri.equals(bk.uri)) { all.remove(i); break; }
                                store(this, all);
                                fill();
                            }
                        }).show();
                return true;
            });
            shelf.addView(spaced(row));
        }
        TextView tip = text("Mantén pulsado un libro para más opciones.", 11);
        tip.setPadding(0, dpi(8), 0, 0);
        shelf.addView(tip);
    }

    void fromScan() {
        if (!Media.allFiles(this)) {
            new AlertDialog.Builder(this).setTitle("Acceso a archivos")
                    .setMessage("Para listar los documentos del teléfono, SSS+ necesita \"Acceso a todos los archivos\". "
                            + "También puedes usar \"Elegir libros del teléfono\" sin dar ese permiso.")
                    .setPositiveButton("Permitir", (d, w) -> Media.requestAllFiles(this))
                    .setNegativeButton("Ahora no", null).show();
            return;
        }
        toast("Buscando documentos…");
        new Thread(() -> {
            List<Media.Item> docs = Media.scanDocs(200);
            runOnUiThread(() -> {
                if (docs.isEmpty()) { toast("No he encontrado documentos"); return; }
                String[] names = new String[docs.size()];
                boolean[] checked = new boolean[docs.size()];
                for (int i = 0; i < docs.size(); i++) names[i] = DocsActivity.icon(docs.get(i).name) + " " + docs.get(i).name;
                new AlertDialog.Builder(this).setTitle("Elige los libros")
                        .setMultiChoiceItems(names, checked, (d, w, c) -> checked[w] = c)
                        .setPositiveButton("Añadir", (d, w) -> {
                            int n = 0;
                            for (int i = 0; i < docs.size(); i++) if (checked[i]) { add(this, docs.get(i).uri, docs.get(i).name); n++; }
                            toast(n + " añadidos ✓");
                            fill();
                        })
                        .setNegativeButton("Cancelar", null).show();
            });
        }).start();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req != REQ_ADD) { super.onActivityResult(req, res, data); return; }
        if (res != RESULT_OK || data == null) return;
        List<Uri> uris = new ArrayList<>();
        ClipData clip = data.getClipData();
        if (clip != null) for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
        else if (data.getData() != null) uris.add(data.getData());
        for (Uri u : uris) {
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            add(this, u, Media.nameOf(this, u));
        }
        toast(uris.size() + " añadidos ✓");
        fill();
    }

    android.view.View spaced(android.view.View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dpi(8);
        v.setLayoutParams(lp);
        return v;
    }
}
