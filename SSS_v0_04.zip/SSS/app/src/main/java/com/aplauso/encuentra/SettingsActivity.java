package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Configuración: detección, sonido, Skin (color, opacidad, fondo, color cambiante) y batería. */
public class SettingsActivity extends NeonActivity {
    static final int[] PRESETS = {
            Color.rgb(0, 229, 255),   // cian
            Color.rgb(255, 45, 170),  // rosa
            Color.rgb(57, 255, 20),   // verde
            Color.rgb(170, 70, 255),  // morado
            Color.rgb(255, 140, 0),   // naranja
            Color.rgb(255, 230, 0),   // amarillo
    };

    TextView soundLbl;
    View swatch;
    SeekBar rBar, gBar, bBar;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(18), dpi(18), dpi(18), dpi(28));

        // --- Barra superior ---
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(circleButton("←", v -> finish()), new LinearLayout.LayoutParams(dpi(46), dpi(46)));
        TextView title = neonText("  AJUSTES", 24);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        col.addView(top, gapBelow(16));

        // --- Detección ---
        LinearLayout det = panel("◢ DETECCIÓN");
        slider(det, "Aplausos necesarios", "claps", 5, 2, 8, "", null);
        slider(det, "Sensibilidad", "sens", 6, 1, 10, "", null);
        TextView tip = text("Consejo: en la pantalla principal, la línea blanca del medidor "
                + "marca desde dónde cuenta un aplauso.", 12);
        tip.setPadding(0, dpi(6), 0, 0);
        det.addView(tip);
        col.addView(det, gapBelow(14));

        // --- Sonido ---
        LinearLayout snd = panel("◢ SONIDO");
        soundLbl = text("", 15);
        snd.addView(soundLbl);
        slider(snd, "Volumen", "volume", 100, 10, 100, " %", null);
        snd.addView(spaced(button("♪ ELEGIR MI SONIDO", v -> pickSound())));
        snd.addView(spaced(button("↺ SONIDO POR DEFECTO", v -> {
            p.edit().remove("sound_uri").remove("sound_name").apply();
            onSoundChanged();
        })));
        snd.addView(spaced(button("▶ PROBAR / PARAR", v -> {
            if (SoundPlayer.isPlaying()) SoundPlayer.stop(this);
            else SoundPlayer.play(this, null);
        })));
        col.addView(snd, gapBelow(14));

        // --- Skin ---
        LinearLayout skin = panel("◢ SKIN");
        skin.addView(text("Color de los marcos", 14));
        LinearLayout chips = new LinearLayout(this);
        chips.setPadding(0, dpi(8), 0, dpi(4));
        for (int c : PRESETS) {
            View chip = new View(this);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(c);
            d.setStroke(dpi(2), Color.WHITE);
            chip.setBackground(d);
            chip.setOnClickListener(v -> setColor(c));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpi(34), dpi(34));
            lp.rightMargin = dpi(10);
            chips.addView(chip, lp);
        }
        skin.addView(chips);

        LinearLayout rgbRow = new LinearLayout(this);
        rgbRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout rgb = new LinearLayout(this);
        rgb.setOrientation(LinearLayout.VERTICAL);
        int cur = p.getInt("neon", Neon.DEFAULT_COLOR);
        p.edit().putInt("r", Color.red(cur)).putInt("g", Color.green(cur)).putInt("b", Color.blue(cur)).apply();
        rBar = slider(rgb, "R", "r", Color.red(cur), 0, 255, "", v -> rgbChanged());
        gBar = slider(rgb, "G", "g", Color.green(cur), 0, 255, "", v -> rgbChanged());
        bBar = slider(rgb, "B", "b", Color.blue(cur), 0, 255, "", v -> rgbChanged());
        rgbRow.addView(rgb, new LinearLayout.LayoutParams(0, -2, 1));
        swatch = new View(this);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(dpi(56), dpi(56));
        sl.leftMargin = dpi(12);
        rgbRow.addView(swatch, sl);
        updateSwatch(cur);
        skin.addView(rgbRow);

        slider(skin, "Opacidad de paneles y botones", "opacity", 70, 0, 100, " %", null);

        Switch cycle = neonSwitch("Color cambiante (arcoíris)");
        cycle.setChecked(p.getBoolean("cycle", false));
        cycle.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("cycle", on).apply());
        skin.addView(cycle);
        slider(skin, "Velocidad del cambio", "cycle_speed", 4, 1, 10, "", null);

        TextView bgLbl = text("Fondo de pantalla", 14);
        bgLbl.setPadding(0, dpi(10), 0, 0);
        skin.addView(bgLbl);
        LinearLayout bgRow = new LinearLayout(this);
        TextView pick = button("🖼 ELEGIR", v -> pickBackground());
        TextView clear = button("✕ QUITAR", v -> {
            p.edit().remove("bg_uri").apply();
            loadBackground();
        });
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, -2, 1);
        lp1.rightMargin = dpi(8);
        lp1.topMargin = dpi(8);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, -2, 1);
        lp2.topMargin = dpi(8);
        bgRow.addView(pick, lp1);
        bgRow.addView(clear, lp2);
        skin.addView(bgRow);
        col.addView(skin, gapBelow(14));

        // --- Batería ---
        LinearLayout bat = panel("◢ BATERÍA");
        bat.addView(text("Si tu teléfono cierra SSS+ en segundo plano, ponla en "
                + "\"Sin restricciones\".", 13));
        bat.addView(spaced(button("⚡ AJUSTES DE BATERÍA", v ->
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)))));
        col.addView(bat, gapBelow(14));

        TextView ver = text("SSS+ v0.4", 12);
        ver.setGravity(Gravity.CENTER);
        col.addView(ver);

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(makeRoot(sv));
        onSoundChanged();
    }

    private View spaced(View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dpi(8);
        v.setLayoutParams(lp);
        return v;
    }

    private void rgbChanged() {
        int c = Color.rgb(p.getInt("r", 0), p.getInt("g", 229), p.getInt("b", 255));
        p.edit().putInt("neon", c).apply();
        updateSwatch(c);
    }

    private void setColor(int c) {
        p.edit().putInt("neon", c).putInt("r", Color.red(c)).putInt("g", Color.green(c))
                .putInt("b", Color.blue(c)).putBoolean("cycle", false).apply();
        rBar.setProgress(Color.red(c));
        gBar.setProgress(Color.green(c));
        bBar.setProgress(Color.blue(c));
        updateSwatch(c);
        recreate(); // refresca también el interruptor de color cambiante
    }

    private void updateSwatch(int c) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(dp(12));
        d.setColor(c);
        d.setStroke(dpi(2), Color.WHITE);
        swatch.setBackground(d);
    }

    @Override
    protected void onSoundChanged() {
        if (soundLbl != null) soundLbl.setText("Actual: " + soundName());
    }
}
