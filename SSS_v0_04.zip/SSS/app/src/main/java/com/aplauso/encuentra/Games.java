package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Los 4 minijuegos neón. Controles táctiles: toques y deslizamientos. */
public class Games {

    // ======================================================================
    // Base común: bucle, puntuación, récord y pantalla de "fin de partida"
    // ======================================================================
    abstract static class Base extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Handler h = new Handler(Looper.getMainLooper());
        final Random rnd = new Random();
        final String key;
        int color = Neon.DEFAULT_COLOR;
        int score;
        boolean over, started, won;
        long interval = 16;
        private float downX, downY;
        private long downAt;

        private final Runnable loop = new Runnable() {
            public void run() {
                if (started && !over) step();
                invalidate();
                h.postDelayed(this, interval);
            }
        };

        Base(Context c, String key) {
            super(c);
            this.key = key;
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            glow.setMaskFilter(new BlurMaskFilter(dp(6), BlurMaskFilter.Blur.NORMAL));
            txt.setTextAlign(Paint.Align.CENTER);
            txt.setFakeBoldText(true);
            txt.setColor(Color.WHITE);
        }

        float dp(float v) { return v * getResources().getDisplayMetrics().density; }

        void startLoop() { h.removeCallbacks(loop); h.post(loop); }
        void stopLoop() { h.removeCallbacks(loop); }

        SharedPreferences prefs() { return getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE); }
        int best() { return prefs().getInt("best_" + key, 0); }

        void gameOver(boolean win) {
            over = true;
            won = win;
            if (score > best()) prefs().edit().putInt("best_" + key, score).apply();
        }

        void newGame() {
            score = 0;
            over = false;
            won = false;
            started = true;
            reset();
        }

        @Override
        protected void onSizeChanged(int w, int h0, int ow, int oh) {
            if (w > 0 && h0 > 0) newGame();
        }

        abstract void reset();
        abstract void step();
        abstract void render(Canvas c);
        void onTap(float x, float y, boolean longPress) {}
        void onSwipe(int dx, int dy) {}   // dx/dy: -1, 0 o 1
        void onDrag(float x, float y) {}

        @Override
        protected void onDraw(Canvas c) {
            render(c);
            if (over) {
                c.drawColor(Color.argb(170, 0, 0, 0));
                txt.setTextSize(dp(30));
                txt.setColor(color);
                c.drawText(won ? "¡GANASTE!" : "FIN DE PARTIDA", getWidth() / 2f, getHeight() / 2f - dp(30), txt);
                txt.setColor(Color.WHITE);
                txt.setTextSize(dp(18));
                c.drawText("Puntos: " + score + "   ·   Récord: " + best(), getWidth() / 2f, getHeight() / 2f + dp(6), txt);
                txt.setTextSize(dp(15));
                c.drawText("Toca para jugar otra vez", getWidth() / 2f, getHeight() / 2f + dp(40), txt);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX(); downY = e.getY(); downAt = SystemClock.uptimeMillis();
                    if (!over) onDrag(e.getX(), e.getY());
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!over) onDrag(e.getX(), e.getY());
                    return true;
                case MotionEvent.ACTION_UP:
                    if (over) { newGame(); return true; }
                    float dx = e.getX() - downX, dy = e.getY() - downY;
                    float min = dp(30);
                    if (Math.abs(dx) < min && Math.abs(dy) < min) {
                        onTap(e.getX(), e.getY(), SystemClock.uptimeMillis() - downAt > 400);
                    } else if (Math.abs(dx) > Math.abs(dy)) {
                        onSwipe(dx > 0 ? 1 : -1, 0);
                    } else {
                        onSwipe(0, dy > 0 ? 1 : -1);
                    }
                    return true;
            }
            return super.onTouchEvent(e);
        }

        /** Celda neón con brillo. */
        void cell(Canvas c, float l, float t, float r, float b, int col) {
            float pad = Math.max(1, (r - l) * 0.08f);
            glow.setColor(Neon.withAlpha(col, 160));
            c.drawRoundRect(l + pad, t + pad, r - pad, b - pad, pad * 2, pad * 2, glow);
            p.setStyle(Paint.Style.FILL);
            p.setColor(col);
            c.drawRoundRect(l + pad, t + pad, r - pad, b - pad, pad * 2, pad * 2, p);
        }

        void frame(Canvas c, float l, float t, float r, float b) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2));
            p.setColor(Neon.withAlpha(color, 140));
            c.drawRoundRect(l, t, r, b, dp(8), dp(8), p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    // ======================================================================
    // CULEBRITA: desliza para girar
    // ======================================================================
    static class Snake extends Base {
        static final int COLS = 18;
        int rows;
        float cs, ox, oy;
        final ArrayDeque<int[]> body = new ArrayDeque<>();
        int dirX = 1, dirY = 0, nextX = 1, nextY = 0;
        int foodX, foodY;

        Snake(Context c) { super(c, "snake"); }

        @Override void reset() {
            cs = getWidth() / (float) COLS;
            rows = Math.max(10, (int) (getHeight() / cs));
            ox = (getWidth() - cs * COLS) / 2f;
            oy = (getHeight() - cs * rows) / 2f;
            body.clear();
            int sx = COLS / 2, sy = rows / 2;
            for (int i = 0; i < 4; i++) body.addLast(new int[]{sx - i, sy});
            dirX = nextX = 1;
            dirY = nextY = 0;
            interval = 150;
            placeFood();
        }

        void placeFood() {
            while (true) {
                foodX = rnd.nextInt(COLS);
                foodY = rnd.nextInt(rows);
                boolean onBody = false;
                for (int[] s : body) if (s[0] == foodX && s[1] == foodY) { onBody = true; break; }
                if (!onBody) return;
            }
        }

        @Override void onSwipe(int dx, int dy) {
            if (dx != 0 && dirX == 0) { nextX = dx; nextY = 0; }
            if (dy != 0 && dirY == 0) { nextX = 0; nextY = dy; }
        }

        @Override void onTap(float x, float y, boolean lp) {
            // Toque: gira hacia el lado donde tocas
            int[] head = body.peekFirst();
            if (head == null) return;
            float hx = ox + (head[0] + 0.5f) * cs, hy = oy + (head[1] + 0.5f) * cs;
            if (dirX != 0) onSwipe(0, y > hy ? 1 : -1);
            else onSwipe(x > hx ? 1 : -1, 0);
        }

        @Override void step() {
            dirX = nextX;
            dirY = nextY;
            int[] head = body.peekFirst();
            int nx = head[0] + dirX, ny = head[1] + dirY;
            if (nx < 0 || ny < 0 || nx >= COLS || ny >= rows) { gameOver(false); return; }
            for (int[] s : body) if (s[0] == nx && s[1] == ny) { gameOver(false); return; }
            body.addFirst(new int[]{nx, ny});
            if (nx == foodX && ny == foodY) {
                score += 10;
                interval = Math.max(60, interval - 3);
                placeFood();
            } else {
                body.removeLast();
            }
        }

        @Override void render(Canvas c) {
            frame(c, ox, oy, ox + cs * COLS, oy + cs * rows);
            cell(c, ox + foodX * cs, oy + foodY * cs, ox + (foodX + 1) * cs, oy + (foodY + 1) * cs, Color.rgb(255, 45, 170));
            boolean first = true;
            for (int[] s : body) {
                int col = first ? Color.WHITE : color;
                cell(c, ox + s[0] * cs, oy + s[1] * cs, ox + (s[0] + 1) * cs, oy + (s[1] + 1) * cs, col);
                first = false;
            }
        }
    }

    // ======================================================================
    // BLOQUES QUE CAEN: toca izquierda/derecha para mover, centro para girar,
    // desliza abajo para dejar caer
    // ======================================================================
    static class Blocks extends Base {
        static final int W = 10, H = 20;
        static final int[][][] SHAPES = {
                {{0, 1}, {1, 1}, {2, 1}, {3, 1}},   // I
                {{0, 0}, {1, 0}, {0, 1}, {1, 1}},   // O
                {{1, 0}, {0, 1}, {1, 1}, {2, 1}},   // T
                {{1, 0}, {2, 0}, {0, 1}, {1, 1}},   // S
                {{0, 0}, {1, 0}, {1, 1}, {2, 1}},   // Z
                {{0, 0}, {0, 1}, {1, 1}, {2, 1}},   // J
                {{2, 0}, {0, 1}, {1, 1}, {2, 1}},   // L
        };
        static final int[] COLORS = {
                Color.rgb(0, 229, 255), Color.rgb(255, 230, 0), Color.rgb(170, 70, 255),
                Color.rgb(57, 255, 20), Color.rgb(255, 60, 90), Color.rgb(60, 120, 255), Color.rgb(255, 140, 0)};
        int[][] board = new int[H][W]; // 0 = vacío, si no índice de color + 1
        int[][] cur = new int[4][2];
        int curType, px, py, nextType;
        int lines;
        long fallMs, acc;
        float cs, ox, oy;
        // controles: ◀ ↻ ▶ ⬇ ⤓
        static final String[] BTN = {"◀", "↻", "▶", "⬇", "⤓"};
        final RectF[] btns = new RectF[5];
        float btnH;
        int held = -1;          // botón mantenido (para repetir)
        long nextRepeat;
        boolean soft;           // caída rápida mientras se mantiene ⬇
        float dragX, dragY, dragStartY;
        long dragAt;
        boolean dragging, moved;

        Blocks(Context c) { super(c, "blocks"); }

        @Override void reset() {
            interval = 30;
            btnH = dp(64);
            float area = getHeight() - btnH - dp(14);
            cs = Math.min(getWidth() * 0.74f / W, area * 0.97f / H);
            ox = (getWidth() - cs * W) / 2f - cs * 1.4f;
            if (ox < dp(4)) ox = dp(4);
            oy = (area - cs * H) / 2f;
            float bw = getWidth() / 5f;
            for (int i = 0; i < 5; i++)
                btns[i] = new RectF(i * bw + dp(4), getHeight() - btnH, (i + 1) * bw - dp(4), getHeight() - dp(4));
            board = new int[H][W];
            lines = 0;
            fallMs = 600;
            acc = 0;
            nextType = rnd.nextInt(SHAPES.length);
            spawn();
        }

        void spawn() {
            curType = nextType;
            nextType = rnd.nextInt(SHAPES.length);
            for (int i = 0; i < 4; i++) { cur[i][0] = SHAPES[curType][i][0]; cur[i][1] = SHAPES[curType][i][1]; }
            px = 3;
            py = 0;
            if (!fits(cur, px, py)) gameOver(false);
        }

        boolean fits(int[][] s, int x, int y) {
            for (int[] b : s) {
                int bx = x + b[0], by = y + b[1];
                if (bx < 0 || bx >= W || by >= H) return false;
                if (by >= 0 && board[by][bx] != 0) return false;
            }
            return true;
        }

        void rotate() {
            if (curType == 1) return; // el cuadrado no gira
            int[][] r = new int[4][2];
            for (int i = 0; i < 4; i++) { r[i][0] = 2 - cur[i][1]; r[i][1] = cur[i][0]; }
            int[] kicks = {0, -1, 1, -2, 2};
            for (int k : kicks) if (fits(r, px + k, py)) { cur = r; px += k; return; }
        }

        void lock() {
            for (int[] b : cur) {
                int by = py + b[1];
                if (by < 0) { gameOver(false); return; }
                board[by][px + b[0]] = curType + 1;
            }
            int cleared = 0;
            for (int y = H - 1; y >= 0; y--) {
                boolean full = true;
                for (int x = 0; x < W; x++) if (board[y][x] == 0) { full = false; break; }
                if (full) {
                    for (int yy = y; yy > 0; yy--) board[yy] = board[yy - 1].clone();
                    board[0] = new int[W];
                    cleared++;
                    y++;
                }
            }
            int[] pts = {0, 100, 300, 500, 800};
            score += pts[cleared];
            lines += cleared;
            fallMs = Math.max(120, 600 - lines * 20L);
            spawn();
        }

        @Override void step() {
            long now = SystemClock.uptimeMillis();
            if ((held == 0 || held == 2) && now >= nextRepeat) {
                shift(held == 0 ? -1 : 1);
                nextRepeat = now + 70;
            }
            acc += interval;
            if (acc < (soft ? Math.min(fallMs, 45) : fallMs)) return;
            acc = 0;
            if (fits(cur, px, py + 1)) py++;
            else lock();
        }

        void shift(int d) { if (fits(cur, px + d, py)) { px += d; invalidate(); } }

        void hardDrop() {
            while (fits(cur, px, py + 1)) { py++; score += 1; }
            lock();
            acc = 0;
        }

        int buttonAt(float x, float y) {
            for (int i = 0; i < 5; i++) if (btns[i] != null && btns[i].contains(x, y)) return i;
            return -1;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    if (over) return true;
                    int b = buttonAt(x, y);
                    if (b >= 0) {
                        held = b;
                        long now = SystemClock.uptimeMillis();
                        if (b == 0) shift(-1);
                        else if (b == 2) shift(1);
                        else if (b == 1) rotate();
                        else if (b == 3) soft = true;
                        else if (b == 4) hardDrop();
                        nextRepeat = now + 220;
                        invalidate();
                        return true;
                    }
                    dragging = true;
                    moved = false;
                    dragX = x; dragY = y; dragStartY = y;
                    dragAt = SystemClock.uptimeMillis();
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    if (!dragging || over) return true;
                    // la pieza sigue al dedo casilla a casilla
                    while (x - dragX > cs * 0.9f) { shift(1); dragX += cs * 0.9f; moved = true; }
                    while (dragX - x > cs * 0.9f) { shift(-1); dragX -= cs * 0.9f; moved = true; }
                    // bajar despacio arrastrando hacia abajo
                    while (y - dragY > cs) {
                        if (fits(cur, px, py + 1)) { py++; score += 1; }
                        dragY += cs; moved = true;
                    }
                    invalidate();
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    if (over) { if (e.getActionMasked() == MotionEvent.ACTION_UP) newGame(); return true; }
                    if (held >= 0) { held = -1; soft = false; return true; }
                    if (dragging) {
                        dragging = false;
                        long dt = SystemClock.uptimeMillis() - dragAt;
                        float dy = y - dragStartY;
                        if (dy > cs * 3 && dt < 250) hardDrop();          // deslizamiento rápido: soltar
                        else if (!moved && Math.abs(dy) < cs) rotate();   // toque: girar
                        invalidate();
                    }
                    return true;
                }
            }
            return true;
        }

        @Override void render(Canvas c) {
            frame(c, ox - dp(3), oy - dp(3), ox + cs * W + dp(3), oy + cs * H + dp(3));
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                    if (board[y][x] != 0)
                        cell(c, ox + x * cs, oy + y * cs, ox + (x + 1) * cs, oy + (y + 1) * cs, COLORS[board[y][x] - 1]);
            // sombra de dónde caerá
            int gy = py;
            while (fits(cur, px, gy + 1)) gy++;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.5f));
            p.setColor(Neon.withAlpha(COLORS[curType], 120));
            for (int[] b : cur)
                c.drawRect(ox + (px + b[0]) * cs + 2, oy + (gy + b[1]) * cs + 2, ox + (px + b[0] + 1) * cs - 2, oy + (gy + b[1] + 1) * cs - 2, p);
            p.setStyle(Paint.Style.FILL);
            for (int[] b : cur)
                if (py + b[1] >= 0)
                    cell(c, ox + (px + b[0]) * cs, oy + (py + b[1]) * cs, ox + (px + b[0] + 1) * cs, oy + (py + b[1] + 1) * cs, COLORS[curType]);
            // siguiente pieza
            float nx = ox + cs * W + dp(14), ny = oy + dp(20), ns = cs * 0.6f;
            txt.setTextSize(dp(12));
            txt.setColor(color);
            c.drawText("SIGUE", nx + ns * 2, ny, txt);
            for (int[] b : SHAPES[nextType])
                cell(c, nx + b[0] * ns, ny + dp(10) + b[1] * ns, nx + (b[0] + 1) * ns, ny + dp(10) + (b[1] + 1) * ns, COLORS[nextType]);
            c.drawText("LÍNEAS", nx + ns * 2, ny + dp(80), txt);
            txt.setColor(Color.WHITE);
            txt.setTextSize(dp(18));
            c.drawText(String.valueOf(lines), nx + ns * 2, ny + dp(104), txt);
            // botones
            for (int i = 0; i < 5; i++) {
                RectF r = btns[i];
                if (r == null) continue;
                p.setStyle(Paint.Style.FILL);
                p.setColor(Neon.withAlpha(color, held == i ? 120 : 40));
                c.drawRoundRect(r, dp(12), dp(12), p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(2));
                p.setColor(color);
                c.drawRoundRect(r, dp(12), dp(12), p);
                p.setStyle(Paint.Style.FILL);
                txt.setColor(Color.WHITE);
                txt.setTextSize(dp(26));
                c.drawText(BTN[i], r.centerX(), r.centerY() + dp(9), txt);
            }
            txt.setTextSize(dp(11));
            txt.setColor(Color.argb(170, 255, 255, 255));
            c.drawText("Arrastra = mover · toca = girar · desliza abajo = soltar", getWidth() / 2f, oy + cs * H + dp(12), txt);
        }
    }

    // ======================================================================
    // ROMPELADRILLOS: arrastra el dedo para mover la barra
    // ======================================================================
    static class Breakout extends Base {
        static final int C = 12, R = 10, LEVELS = 20;
        static final String KEYS = "roygcbpkwns";
        static final int[] PAL = {
                Color.rgb(255, 60, 80), Color.rgb(255, 154, 48), Color.rgb(255, 224, 64), Color.rgb(80, 224, 96),
                Color.rgb(48, 224, 255), Color.rgb(64, 128, 255), Color.rgb(160, 80, 255), Color.rgb(255, 112, 192),
                Color.rgb(240, 240, 240), Color.rgb(160, 96, 42), Color.rgb(154, 160, 176)};
        static final String[] NAMES = {"CLÁSICO", "CORAZÓN", "BARQUITO", "CASA", "GATO", "ÁRBOL", "COHETE", "PEZ",
                "HONGO", "ESTRELLA", "FLOR", "FANTASMA", "TAZA", "SOL", "CALAVERA", "LLAVE", "PATO", "RAYO",
                "CASTILLO", "CORONA"};
        static final String[][] LV = {
                {"rrrrrrrrrrrr", "oooooooooooo", "yyyyyyyyyyyy", "gggggggggggg", "cccccccccccc", "bbbbbbbbbbbb", "pppppppppppp"},
                {"............", "..kkk..kkk..", ".kkkkkkkkkk.", ".kkwkkkkkkk.", ".kkkkkkkkkk.", "..kkkkkkkk..", "...kkkkkk...", "....kkkk....", ".....kk....."},
                {".....w......", ".....ww.....", ".....www....", ".....wwww...", ".....wwwww..", ".....n......", "nnnnnnnnnnnn", ".nnnnnnnnnn.", "..nnnnnnnn..", "bbbbbbbbbbbb"},
                {".....rr.....", "....rrrr....", "...rrrrrr...", "..rrrrrrrr..", ".rrrrrrrrrr.", "..yyyyyyyy..", "..ycyyyycy..", "..yyynnyyy..", "..yyynnyyy..", "gggggggggggg"},
                {"..o......o..", ".oo......oo.", ".oooooooooo.", ".oggooooggo.", ".oooookoooo.", ".woooooooow.", "..oooooooo..", "..oooooooo..", "...oo..oo..."},
                {".....gg.....", "....gggg....", "...gggggg...", "..gggrgggg..", ".gggggggrgg.", "gggrgggggggg", "....nnnn....", "....nnnn....", "....nnnn....", "...gggggg..."},
                {".....rr.....", "....wwww....", "....wccw....", "....wccw....", "....wwww....", "....wwww....", "...rwwwwr...", "..rrwwwwrr..", "....oyyo....", ".....oo....."},
                {"............", "....bbbb....", "..bbbbbbb..b", ".bwbbbbbbbbb", "bbbbbbbbbbb.", ".bbbcbbbbbbb", "..bbbbbbb..b", "....bbbb...."},
                {"...rrrrrr...", "..rrwrrwrr..", ".rrrrrrrrrr.", "rrwrrrrrrwrr", "rrrrrrrrrrrr", "...wwwwww...", "...wkwwkw...", "...wwwwww...", "...wwwwww..."},
                {".....yy.....", ".....yy.....", "....yyyy....", "yyyyyyyyyyyy", ".yyyyyyyyyy.", "..yyyyyyyy..", "...yyyyyy...", "..yyy..yyy..", ".yy......yy."},
                {"....kkkk....", "...kkkkkk...", "..kkkyykkk..", "..kkyyyykk..", "..kkkyykkk..", "...kkkkkk...", ".....gg.....", "..ggggg.....", ".....ggggg..", ".....gg....."},
                {"....pppp....", "..pppppppp..", ".pppppppppp.", ".ppwwppwwpp.", ".ppwbppwbpp.", ".pppppppppp.", ".pppppppppp.", ".pppppppppp.", ".pp.pp.pp.pp"},
                {"....w..w....", ".....w..w...", "............", ".nnnnnnnn...", ".nwwwwwwnnn.", ".nwwwwwwn.n.", ".nwwwwwwn.n.", ".nwwwwwwnnn.", "..nwwwwn....", "cccccccccccc"},
                {"..y..yy..y..", "...y.yy.y...", "....oooo....", "yy.oooooo.yy", "..oooyyooo..", "..oooooooo..", "yy.oooooo.yy", "....oooo....", "...y.yy.y...", "..y..yy..y.."},
                {"...wwwwww...", "..wwwwwwww..", ".wwwwwwwwww.", ".wwkkwwkkww.", ".wwkkwwkkww.", ".wwwwkkwwww.", "..wwwwwwww..", "...w.ww.w...", "...wwwwww..."},
                {".yyyy.......", "yyyyyy......", "yy..yy......", "yy..yyyyyyyy", "yy..yyyyyyyy", "yyyyyy...yy.", ".yyyy....yy.", "..........y."},
                {"...yyy......", "..yykyy.....", "..yyyyyoo...", "...yyyy.....", "..yyyyyyyy..", ".yyyyyyyyyy.", ".yyywwyyyyy.", "..yyyyyyyy..", "bbbbbbbbbbbb", ".bbbbbbbbbb."},
                {".......yyyy.", "......yyyy..", ".....yyyy...", "....yyyy....", "...yyyyyyy..", "......yyy...", ".....yyy....", "....yyy.....", "...yy.......", "..y........."},
                {"s.s......s.s", "sss..ss..sss", "sss.ssss.sss", "ssssssssssss", "sssrssssrsss", "ssssssssssss", "sssssnnsssss", "sssssnnsssss", "sssssnnsssss", "bbbbbbbbbbbb"},
                {"y....yy....y", "yy..yyyy..yy", "yyyyyyyyyyyy", "yyryyyyyyryy", "yyyyyccyyyyy", "yyyyyyyyyyyy", "kkkkkkkkkkkk"}};

        int[][] bricks = new int[R][C];   // 0 = vacío; si no, índice de color + 1
        float padX, padW, padY, bx, by, vx, vy, r;
        int lives, left, level;
        boolean waiting;
        float bannerT;

        Breakout(Context c) { super(c, "breakout"); }

        @Override void reset() {
            interval = 16;
            lives = 3;
            level = 0;
            padW = getWidth() * 0.24f;
            padY = getHeight() - dp(70);
            padX = getWidth() / 2f;
            r = dp(7);
            loadLevel();
        }

        void loadLevel() {
            bricks = new int[R][C];
            left = 0;
            String[] rows = LV[level];
            for (int y = 0; y < R && y < rows.length; y++)
                for (int x = 0; x < C && x < rows[y].length(); x++) {
                    int k = KEYS.indexOf(rows[y].charAt(x));
                    if (k >= 0) { bricks[y][x] = k + 1; left++; }
                }
            bannerT = 2.2f;
            serve();
        }

        void serve() {
            bx = padX;
            by = padY - r - dp(2);
            vx = 0;
            vy = 0;
            waiting = true;
        }

        float baseSpeed() { return getHeight() / 115f * (1 + 0.03f * level); }
        float maxSpeed() { return getHeight() / 72f; }

        void launch() {
            float speed = baseSpeed();
            vx = speed * (rnd.nextBoolean() ? 0.55f : -0.55f);
            vy = -speed;
            waiting = false;
        }

        @Override void onDrag(float x, float y) {
            padX = Math.max(padW / 2, Math.min(getWidth() - padW / 2, x));
            if (waiting) bx = padX;
        }

        @Override void onTap(float x, float y, boolean lp) { if (waiting) launch(); }
        @Override void onSwipe(int dx, int dy) { if (waiting) launch(); }

        float bw() { return getWidth() / (float) C; }
        float bh() { return dp(18); }
        float boy() { return dp(58); }

        /** Rompe el ladrillo que hay en (x, y), si hay alguno. */
        boolean hitAt(float x, float y) {
            int col = (int) Math.floor(x / bw()), row = (int) Math.floor((y - boy()) / bh());
            if (row < 0 || row >= R || col < 0 || col >= C || bricks[row][col] == 0) return false;
            bricks[row][col] = 0;
            left--;
            score += 10 + level * 2;
            return true;
        }

        @Override void step() {
            if (bannerT > 0) bannerT -= interval / 1000f;
            if (waiting) return;
            float w = getWidth();
            float speed = (float) Math.hypot(vx, vy);
            int steps = Math.max(1, (int) Math.ceil(speed / (r * 0.5f)));
            boolean broke = false;   // como mucho un ladrillo por fotograma
            for (int i = 0; i < steps; i++) {
                float sx = vx / steps, sy = vy / steps;
                // eje X
                bx += sx;
                if (bx < r) { bx = r; vx = Math.abs(vx); }
                if (bx > w - r) { bx = w - r; vx = -Math.abs(vx); }
                if (!broke && hitAt(bx + Math.signum(vx) * r, by)) { vx = -vx; bx -= sx; broke = true; }
                // eje Y
                by += sy;
                if (by < dp(10) + r) { by = dp(10) + r; vy = Math.abs(vy); }
                if (!broke && hitAt(bx, by + Math.signum(vy) * r)) { vy = -vy; by -= sy; broke = true; }
                // barra
                if (vy > 0 && by + r >= padY && by + r - sy <= padY + 2 && Math.abs(bx - padX) < padW / 2 + r) {
                    float off = GameKit.clamp((bx - padX) / (padW / 2), -1, 1);
                    float sp = Math.min(maxSpeed(), (float) Math.hypot(vx, vy) * 1.015f);
                    vx = sp * off * 0.8f;
                    // ángulo mínimo: nunca sale totalmente vertical (evita quedarse rebotando en una columna vacía)
                    float minVx = sp * 0.22f;
                    if (Math.abs(vx) < minVx) vx = (off < 0 || (off == 0 && rnd.nextBoolean()) ? -1 : 1) * minVx;
                    vy = -(float) Math.sqrt(Math.max(sp * sp * 0.3f, sp * sp - vx * vx));
                    by = padY - r;
                    break;
                }
            }
            if (left <= 0) {
                if (level + 1 >= LEVELS) { gameOver(true); return; }   // nivel 20 superado
                level++;
                if (level % 5 == 0) lives++;
                loadLevel();
                return;
            }
            if (by > getHeight()) {
                lives--;
                if (lives <= 0) { gameOver(false); return; }
                serve();
            }
        }

        @Override void render(Canvas c) {
            float bw = bw(), bh = bh(), boy = boy();
            for (int y = 0; y < R; y++)
                for (int x = 0; x < C; x++)
                    if (bricks[y][x] != 0)
                        cell(c, x * bw, boy + y * bh, (x + 1) * bw, boy + (y + 1) * bh, PAL[bricks[y][x] - 1]);
            cell(c, padX - padW / 2, padY, padX + padW / 2, padY + dp(14), color);
            glow.setColor(Color.WHITE);
            c.drawCircle(bx, by, r, glow);
            p.setColor(Color.WHITE);
            c.drawCircle(bx, by, r, p);
            txt.setTextSize(dp(13));
            txt.setColor(color);
            StringBuilder hearts = new StringBuilder();
            for (int i = 0; i < lives; i++) hearts.append("♥ ");
            c.drawText("NIVEL " + (level + 1) + "/" + LEVELS + " · " + NAMES[level] + "   " + hearts, getWidth() / 2f, dp(36), txt);
            if (bannerT > 0 && !over) {
                txt.setTextSize(dp(26));
                txt.setColor(Color.WHITE);
                c.drawText("NIVEL " + (level + 1) + ": " + NAMES[level], getWidth() / 2f, getHeight() * 0.62f, txt);
            }
            if (waiting && !over) {
                txt.setTextSize(dp(13));
                txt.setColor(Color.WHITE);
                c.drawText("Toca para lanzar · arrastra para mover", getWidth() / 2f, padY + dp(44), txt);
            }
        }
    }

    // ======================================================================
    // BUSCAMINAS: toca para descubrir, mantén pulsado para poner bandera
    // ======================================================================
    static class Mines extends Base {
        static final String[] DN = {"FÁCIL", "NORMAL", "DIFÍCIL", "NIGHTMARE"};
        static final int[][] DIM = {{14, 20, 50}, {18, 28, 100}, {22, 34, 150}, {26, 46, 250}};  // columnas, filas, bombas
        static final int[] BASE_PTS = {1000, 2000, 3500, 6000};
        int C = 14, R = 20, MINES = 50, diff = -1;
        boolean[][] mine = new boolean[1][1], open = new boolean[1][1], flag = new boolean[1][1];
        int[][] near = new int[1][1];
        boolean placed, flagMode;
        int opened;
        long startAt;
        float cs, zoom = 1, panX, panY, top;
        final RectF bPlus = new RectF(), bMinus = new RectF(), bMenu = new RectF(), bFlag = new RectF();
        final RectF[] diffBtns = {new RectF(), new RectF(), new RectF(), new RectF()};
        float downX, downY, lastX, lastY, pinchDist, pinchZoom;
        long downAt;
        boolean moved, pinching;

        Mines(Context c) { super(c, "mines"); }

        @Override void reset() {
            interval = 250;
            top = dp(92);
            float w = getWidth();
            float bs = dp(46);
            bFlag.set(w - bs * 4 - dp(16), dp(42), w - bs * 3 - dp(16), dp(42) + bs);
            bMinus.set(w - bs * 3 - dp(12), dp(42), w - bs * 2 - dp(12), dp(42) + bs);
            bPlus.set(w - bs * 2 - dp(8), dp(42), w - bs - dp(8), dp(42) + bs);
            bMenu.set(w - bs - dp(4), dp(42), w - dp(4), dp(42) + bs);
            for (int i = 0; i < 4; i++) {
                float y = getHeight() * 0.28f + i * dp(74);
                diffBtns[i].set(w * 0.14f, y, w * 0.86f, y + dp(62));
            }
            if (diff < 0) return;
            C = DIM[diff][0]; R = DIM[diff][1]; MINES = DIM[diff][2];
            mine = new boolean[R][C];
            open = new boolean[R][C];
            flag = new boolean[R][C];
            near = new int[R][C];
            placed = false;
            opened = 0;
            flagMode = false;
            startAt = SystemClock.elapsedRealtime();
            cs = (w - dp(8)) / C;
            zoom = diff >= 2 ? 1.6f : 1f;     // los tableros grandes empiezan algo acercados
            panX = 0; panY = 0;
            clampPan();
        }

        float viewW() { return getWidth() - dp(8); }
        float viewH() { return getHeight() - top - dp(4); }

        void clampPan() {
            float bw = C * cs * zoom, bh = R * cs * zoom;
            panX = bw <= viewW() ? (viewW() - bw) / 2 : GameKit.clamp(panX, viewW() - bw, 0);
            panY = bh <= viewH() ? (viewH() - bh) / 2 : GameKit.clamp(panY, viewH() - bh, 0);
        }

        void zoomBy(float f, float fx, float fy) {
            float nz = GameKit.clamp(zoom * f, 1, 4);
            // mantener fijo el punto (fx, fy) de la pantalla
            float bx0 = (fx - dp(4) - panX) / zoom, by0 = (fy - top - panY) / zoom;
            zoom = nz;
            panX = fx - dp(4) - bx0 * zoom;
            panY = fy - top - by0 * zoom;
            clampPan();
            invalidate();
        }

        void place(int sr, int sc) {
            int n = 0;
            while (n < MINES) {
                int r = rnd.nextInt(R), c = rnd.nextInt(C);
                if (mine[r][c] || (Math.abs(r - sr) <= 1 && Math.abs(c - sc) <= 1)) continue;
                mine[r][c] = true;
                n++;
            }
            for (int r = 0; r < R; r++)
                for (int c = 0; c < C; c++) {
                    int k = 0;
                    for (int dr = -1; dr <= 1; dr++)
                        for (int dc = -1; dc <= 1; dc++) {
                            int rr = r + dr, cc = c + dc;
                            if (rr >= 0 && rr < R && cc >= 0 && cc < C && mine[rr][cc]) k++;
                        }
                    near[r][c] = k;
                }
            placed = true;
            startAt = SystemClock.elapsedRealtime();
        }

        void reveal(int r, int c) {
            List<int[]> stack = new ArrayList<>();
            stack.add(new int[]{r, c});
            while (!stack.isEmpty()) {
                int[] q = stack.remove(stack.size() - 1);
                int rr = q[0], cc = q[1];
                if (rr < 0 || rr >= R || cc < 0 || cc >= C || open[rr][cc] || flag[rr][cc]) continue;
                open[rr][cc] = true;
                opened++;
                if (near[rr][cc] == 0 && !mine[rr][cc])
                    for (int dr = -1; dr <= 1; dr++)
                        for (int dc = -1; dc <= 1; dc++)
                            if (dr != 0 || dc != 0) stack.add(new int[]{rr + dr, cc + dc});
            }
        }

        void tapCell(float x, float y, boolean longPress) {
            float s0 = cs * zoom;
            int c = (int) Math.floor((x - dp(4) - panX) / s0), r = (int) Math.floor((y - top - panY) / s0);
            if (y < top || r < 0 || r >= R || c < 0 || c >= C) return;
            if (longPress || flagMode) {
                if (!open[r][c]) flag[r][c] = !flag[r][c];
            } else {
                if (flag[r][c] || open[r][c]) return;
                if (!placed) place(r, c);
                if (mine[r][c]) {
                    for (int rr = 0; rr < R; rr++) for (int cc = 0; cc < C; cc++) if (mine[rr][cc]) open[rr][cc] = true;
                    gameOver(false);
                } else {
                    reveal(r, c);
                    if (opened == R * C - MINES) {
                        long secs = (SystemClock.elapsedRealtime() - startAt) / 1000;
                        score = (int) Math.max(10, BASE_PTS[diff] - secs * 5);
                        gameOver(true);
                    }
                }
            }
            invalidate();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = lastX = x; downY = lastY = y;
                    downAt = SystemClock.uptimeMillis();
                    moved = false;
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (e.getPointerCount() >= 2 && diff >= 0 && !over) {
                        pinching = true;
                        pinchDist = (float) Math.max(1, Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
                        pinchZoom = zoom;
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (pinching && e.getPointerCount() >= 2) {
                        float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                        float target = GameKit.clamp(pinchZoom * d / pinchDist, 1, 4);
                        zoomBy(target / zoom, (e.getX(0) + e.getX(1)) / 2, (e.getY(0) + e.getY(1)) / 2);
                        moved = true;
                        return true;
                    }
                    if (Math.hypot(x - downX, y - downY) > dp(10)) moved = true;
                    if (moved && diff >= 0 && !over) {
                        panX += x - lastX;
                        panY += y - lastY;
                        clampPan();
                        invalidate();
                    }
                    lastX = x; lastY = y;
                    return true;
                case MotionEvent.ACTION_POINTER_UP:
                    return true;
                case MotionEvent.ACTION_UP: {
                    boolean wasPinch = pinching;
                    pinching = false;
                    if (wasPinch || moved) return true;
                    if (over) { diff = -1; newGame(); return true; }
                    if (diff < 0) {
                        for (int i = 0; i < 4; i++) if (diffBtns[i].contains(x, y)) { diff = i; newGame(); }
                        return true;
                    }
                    if (bPlus.contains(x, y)) { zoomBy(1.5f, getWidth() / 2f, top + viewH() / 2); return true; }
                    if (bMinus.contains(x, y)) { zoomBy(1 / 1.5f, getWidth() / 2f, top + viewH() / 2); return true; }
                    if (bFlag.contains(x, y)) { flagMode = !flagMode; invalidate(); return true; }
                    if (bMenu.contains(x, y)) { diff = -1; newGame(); return true; }
                    tapCell(x, y, SystemClock.uptimeMillis() - downAt > 400);
                    return true;
                }
            }
            return true;
        }

        @Override void step() {}

        void topButton(Canvas c, RectF r, String label, boolean on) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Neon.withAlpha(color, on ? 140 : 40));
            c.drawRoundRect(r, dp(10), dp(10), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2));
            p.setColor(color);
            c.drawRoundRect(r, dp(10), dp(10), p);
            p.setStyle(Paint.Style.FILL);
            txt.setTextSize(dp(20));
            txt.setColor(Color.WHITE);
            c.drawText(label, r.centerX(), r.centerY() + dp(7), txt);
        }

        @Override void render(Canvas c) {
            if (diff < 0) {
                txt.setTextSize(dp(26));
                txt.setColor(color);
                c.drawText("💣 BUSCAMINAS", getWidth() / 2f, getHeight() * 0.18f, txt);
                txt.setTextSize(dp(13));
                txt.setColor(Color.WHITE);
                c.drawText("Elige la dificultad", getWidth() / 2f, getHeight() * 0.18f + dp(28), txt);
                for (int i = 0; i < 4; i++) {
                    RectF r = diffBtns[i];
                    int col = i == 3 ? Color.rgb(255, 50, 80) : color;
                    p.setColor(Neon.withAlpha(col, 50));
                    c.drawRoundRect(r, dp(14), dp(14), p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(2));
                    p.setColor(col);
                    c.drawRoundRect(r, dp(14), dp(14), p);
                    p.setStyle(Paint.Style.FILL);
                    txt.setTextSize(dp(19));
                    txt.setColor(Color.WHITE);
                    c.drawText((i == 3 ? "☠ " : "") + DN[i], r.centerX(), r.centerY() - dp(2), txt);
                    txt.setTextSize(dp(12));
                    txt.setColor(Color.LTGRAY);
                    c.drawText(DIM[i][2] + " bombas · " + DIM[i][0] + "×" + DIM[i][1] + " casillas", r.centerX(), r.centerY() + dp(18), txt);
                }
                return;
            }
            int flags = 0;
            for (int r = 0; r < R; r++) for (int cc = 0; cc < C; cc++) if (flag[r][cc]) flags++;
            long secs = placed && !over ? (SystemClock.elapsedRealtime() - startAt) / 1000 : 0;
            txt.setTextSize(dp(14));
            txt.setColor(color);
            c.drawText(DN[diff] + "   💣 " + (MINES - flags) + "   ⏱ " + secs + " s", getWidth() / 2f, dp(28), txt);
            topButton(c, bFlag, "🚩", flagMode);
            topButton(c, bMinus, "🔍−", false);
            topButton(c, bPlus, "🔍+", false);
            topButton(c, bMenu, "☰", false);
            txt.setTextSize(dp(11));
            txt.setColor(Color.argb(170, 255, 255, 255));
            c.drawText(flagMode ? "Modo bandera: toca para marcar 🚩" : "Toca = abrir · mantén = 🚩 · arrastra = mover · pellizca = zoom",
                    (bFlag.left) / 2f, dp(66), txt);

            int[] numCol = {0, Color.rgb(0, 229, 255), Color.rgb(57, 255, 20), Color.rgb(255, 60, 90),
                    Color.rgb(170, 70, 255), Color.rgb(255, 140, 0), Color.rgb(0, 200, 200), Color.WHITE, Color.GRAY};
            float s0 = cs * zoom;
            c.save();
            c.clipRect(0, top, getWidth(), getHeight());
            int c0 = Math.max(0, (int) Math.floor(-panX / s0)), c1 = Math.min(C - 1, (int) Math.ceil((viewW() - panX) / s0));
            int r0 = Math.max(0, (int) Math.floor(-panY / s0)), r1 = Math.min(R - 1, (int) Math.ceil((viewH() - panY) / s0));
            float pad = Math.max(1, s0 * 0.06f);
            for (int r = r0; r <= r1; r++)
                for (int cc = c0; cc <= c1; cc++) {
                    float l = dp(4) + panX + cc * s0, t = top + panY + r * s0;
                    RectF rc = new RectF(l + pad, t + pad, l + s0 - pad, t + s0 - pad);
                    if (open[r][cc]) {
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(mine[r][cc] ? Color.rgb(160, 20, 50) : Color.argb(60, 255, 255, 255));
                        c.drawRoundRect(rc, s0 * 0.15f, s0 * 0.15f, p);
                        if (mine[r][cc]) {
                            txt.setTextSize(s0 * 0.55f);
                            c.drawText("💣", l + s0 / 2, t + s0 * 0.7f, txt);
                        } else if (near[r][cc] > 0) {
                            txt.setTextSize(s0 * 0.62f);
                            txt.setColor(numCol[near[r][cc]]);
                            c.drawText(String.valueOf(near[r][cc]), l + s0 / 2, t + s0 * 0.72f, txt);
                        }
                    } else {
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(Neon.withAlpha(color, 55));
                        c.drawRoundRect(rc, s0 * 0.15f, s0 * 0.15f, p);
                        p.setStyle(Paint.Style.STROKE);
                        p.setStrokeWidth(Math.max(1, s0 * 0.05f));
                        p.setColor(Neon.withAlpha(color, 170));
                        c.drawRoundRect(rc, s0 * 0.15f, s0 * 0.15f, p);
                        p.setStyle(Paint.Style.FILL);
                        if (flag[r][cc]) {
                            txt.setTextSize(s0 * 0.55f);
                            c.drawText("🚩", l + s0 / 2, t + s0 * 0.7f, txt);
                        }
                    }
                }
            c.restore();
        }
    }
}
