package com.aplauso.encuentra;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Panel de Chloe (v1.1), como el de Gemini: aparece abajo, encima de lo que estés haciendo, cuando la llamas
 * («Hola Chloe», mantener pulsado el botón de inicio/encendido o el acceso directo). Muestra claramente si te
 * está escuchando, pensando o hablando. Tocando fuera del recuadro se cierra y deja de escuchar.
 */
public class ChloeActivity extends Activity {
    static final String EXTRA_LISTEN = "listen", EXTRA_ASK = "ask";
    static volatile boolean open;
    static ChloeActivity inst;

    /** Se abrió otra app (YouTube, VidTube…) desde un hilo: el panel se aparta cuando termine de hablar. */
    static void closeSoon() {
        ChloeActivity a = inst;
        if (a == null) return;
        a.runOnUiThread(() -> {
            a.h.removeCallbacksAndMessages(null);          // sin volver a escuchar
            a.h.postDelayed(new Runnable() {
                int n;
                @Override public void run() { if (Voice.speaking && n++ < 20) a.h.postDelayed(this, 200); else a.finish(); }
            }, 300);
        });
    }

    /** «Stop Chloe»: se calla y el panel se cierra. */
    static void closeIfOpen() {
        ChloeActivity a = inst;
        if (a != null) a.runOnUiThread(() -> { Voice.stop(); a.finish(); });
    }

    final Handler h = new Handler(Looper.getMainLooper());
    SpeechRecognizer sr;
    boolean listening, busy;
    TextView state, you, her;
    EditText input;
    TextView mic;
    ObjectAnimator pulse;
    long lastActivity;

    int dp(float v) { return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics())); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        L.init(this);
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0x55000000);
        root.setOnClickListener(v -> finish());              // tocar fuera = cerrar y dejar de escuchar

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(28));
        bg.setColor(0xF0101420);
        bg.setStroke(dp(2), Neon.color(this));
        card.setBackground(bg);
        card.setClickable(true);                               // tocar dentro no cierra
        card.setElevation(dp(12));

        // cabecera: nombre y estado
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = new TextView(this);
        name.setText("✦ " + Brain.botName(this));
        name.setTextColor(Neon.color(this));
        name.setTextSize(16);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        top.addView(name);
        state = new TextView(this);
        state.setTextColor(Color.rgb(170, 180, 200));
        state.setTextSize(13);
        state.setPadding(dp(10), 0, 0, 0);
        top.addView(state, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(Color.rgb(170, 180, 200));
        close.setTextSize(18);
        close.setPadding(dp(10), dp(4), dp(4), dp(4));
        close.setOnClickListener(v -> finish());
        top.addView(close);
        card.addView(top);

        // conversación (lo último)
        ScrollView sv = new ScrollView(this);
        LinearLayout talk = new LinearLayout(this);
        talk.setOrientation(LinearLayout.VERTICAL);
        you = new TextView(this);
        you.setTextColor(Color.rgb(150, 160, 180));
        you.setTextSize(14);
        you.setPadding(0, dp(8), 0, 0);
        her = new TextView(this);
        her.setTextColor(Color.WHITE);
        her.setTextSize(17);
        her.setPadding(0, dp(6), 0, dp(6));
        her.setLineSpacing(0, 1.15f);
        talk.addView(you);
        talk.addView(her);
        sv.addView(talk);
        int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.38f);
        card.addView(sv, new LinearLayout.LayoutParams(-1, -2) {{ }});
        sv.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            if (sv.getHeight() > maxH) { ViewGroup.LayoutParams lp = sv.getLayoutParams(); lp.height = maxH; sv.setLayoutParams(lp); }
        });

        // barra: escribir + micrófono
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable ib = new GradientDrawable();
        ib.setCornerRadius(dp(26));
        ib.setColor(0xFF1C2232);
        bar.setBackground(ib);
        bar.setPadding(dp(16), dp(4), dp(6), dp(4));
        input = new EditText(this);
        input.setHint(L.t("Pregúntale a") + " " + Brain.botName(this));
        input.setHintTextColor(Color.rgb(130, 140, 160));
        input.setTextColor(Color.WHITE);
        input.setTextSize(16);
        input.setBackground(null);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setOnEditorActionListener((v, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_SEND || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) { sendTyped(); return true; }
            return false;
        });
        bar.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        mic = new TextView(this);
        mic.setText("🎤");
        mic.setTextSize(22);
        mic.setGravity(Gravity.CENTER);
        GradientDrawable mb = new GradientDrawable();
        mb.setShape(GradientDrawable.OVAL);
        mb.setColor(Neon.color(this) & 0x00FFFFFF | 0x66000000);
        mic.setBackground(mb);
        mic.setOnClickListener(v -> {
            if (input.getText().toString().trim().length() > 0) { sendTyped(); return; }
            if (listening) stopListening(); else listen();
        });
        bar.addView(mic, new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
        bl.topMargin = dp(10);
        card.addView(bar, bl);
        input.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            public void onTextChanged(CharSequence s, int a, int c, int d) {}
            public void afterTextChanged(android.text.Editable s) { mic.setText(s.toString().trim().isEmpty() ? (listening ? "⏹" : "🎤") : "➤"); touch(); }
        });

        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        cl.setMargins(dp(10), 0, dp(10), dp(18));
        root.addView(card, cl);
        setContentView(root);

        pulse = ObjectAnimator.ofFloat(mic, "alpha", 1f, 0.35f);
        pulse.setDuration(600);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);

        Voice.init(this, null);
        setState(L.t("Toca el micrófono o escribe"));
        handle(getIntent());
        touch();
        h.postDelayed(idle, 5000);
    }

    /** Plan B para callarla: con el panel abierto, el botón de bajar volumen la para al momento (no depende del micrófono). */
    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_VOLUME_DOWN && (Voice.speaking || listening)) {
            Voice.stop();
            stopListening();
            setState(L.t("Toca el micrófono para hablar."));
            return true;
        }
        return super.onKeyDown(code, e);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handle(i);
    }

    void handle(Intent i) {
        String q = i == null ? null : i.getStringExtra(EXTRA_ASK);
        if (q != null && !q.trim().isEmpty()) { chime(); ask(q); return; }
        String a = i == null ? null : i.getAction();
        boolean wantListen = (i != null && i.getBooleanExtra(EXTRA_LISTEN, false))
                || Intent.ACTION_ASSIST.equals(a) || "android.intent.action.VOICE_COMMAND".equals(a);
        if (wantListen) { chime(); h.postDelayed(this::listen, 350); }
    }

    @Override
    protected void onResume() { super.onResume(); open = true; inst = this; }

    @Override
    protected void onPause() {
        super.onPause();
        open = false;
        if (isFinishing()) cleanup();
    }

    @Override
    protected void onDestroy() {
        if (inst == this) inst = null;
        cleanup();
        super.onDestroy();
    }

    void cleanup() {
        h.removeCallbacksAndMessages(null);
        stopListening();
        if (sr != null) { try { sr.destroy(); } catch (Exception ignored) {} sr = null; }
        Voice.stop();
        ShieldService.yieldMic = false;
    }

    void touch() { lastActivity = System.currentTimeMillis(); }

    /** Si no pasa nada en 30 s, se cierra sola (no se queda escuchando ni gastando batería). */
    final Runnable idle = new Runnable() {
        @Override public void run() {
            if (!listening && !busy && !Voice.speaking && System.currentTimeMillis() - lastActivity > 30000) { finish(); return; }
            h.postDelayed(this, 5000);
        }
    };

    void setState(String s) { state.setText(s); }

    void chime() {
        try { new android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 60).startTone(android.media.ToneGenerator.TONE_PROP_ACK, 120); }
        catch (Exception ignored) {}
    }

    // ---------------- escuchar ----------------
    void listen() {
        if (isFinishing() || busy) return;
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            setState(L.t("Necesito permiso de micrófono (en la pantalla del asistente)."));
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { setState(L.t("Este teléfono no tiene reconocimiento de voz: escríbeme.")); return; }
        Voice.stop();
        ShieldService.yieldMic = true;                       // el oído de la palabra clave le deja el micrófono
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle p) { setState(L.t("Te escucho…")); }
                public void onBeginningOfSpeech() { touch(); }
                public void onRmsChanged(float v) { mic.setScaleX(1f + Math.max(0, Math.min(10, v)) / 40f); mic.setScaleY(mic.getScaleX()); }
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() { setState(L.t("Pensando…")); }
                public void onError(int e) {
                    listeningOff();
                    setState(e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                            ? L.t("No te he oído. Toca el micrófono para hablar.") : L.t("Toca el micrófono para hablar."));
                }
                public void onResults(Bundle r) {
                    listeningOff();
                    ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l != null && !l.isEmpty() && !l.get(0).trim().isEmpty()) ask(l.get(0));
                    else setState(L.t("No te he oído. Toca el micrófono para hablar."));
                }
                public void onPartialResults(Bundle r) {
                    ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l != null && !l.isEmpty()) you.setText("🗣 " + l.get(0));
                    touch();
                }
                public void onEvent(int t, Bundle p) {}
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en".equals(L.lang) ? "en-US" : "it".equals(L.lang) ? "it-IT" : "es-ES")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        listening = true;
        mic.setText("⏹");
        pulse.start();
        you.setText("");
        setState(L.t("Te escucho…"));
        // le da al oído medio segundo para soltar el micrófono
        h.postDelayed(() -> { if (listening && sr != null) try { sr.startListening(i); } catch (Exception e) { listeningOff(); } }, 450);
        touch();
    }

    void stopListening() {
        if (sr != null && listening) try { sr.stopListening(); } catch (Exception ignored) {}
        listeningOff();
    }

    void listeningOff() {
        listening = false;
        if (pulse != null) pulse.cancel();
        if (mic != null) { mic.setAlpha(1f); mic.setScaleX(1f); mic.setScaleY(1f); mic.setText(input.getText().toString().trim().isEmpty() ? "🎤" : "➤"); }
        ShieldService.yieldMic = false;
    }

    void sendTyped() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) return;
        input.setText("");
        ((android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0);
        ask(q);
    }

    // ---------------- responder ----------------
    void ask(String q) {
        if (Wake.isStop(q) || Actions.canon(q).matches("^(?:stop|para|parate|callate|calla|basta|silencio|cancela|nada|olvidalo|ya esta)$")) { Voice.stop(); finish(); return; }
        if (busy) return;
        touch();
        you.setText("🗣 " + q);
        her.setText("");
        Actions.Result r = Actions.parse(this, q);
        if (r != null) { reply(r.say, r); return; }
        busy = true;
        setState(L.t("Pensando…"));
        her.setText("…");
        new Thread(() -> {
            String raw = Brain.ask(this, q);
            String cmd = Brain.cmdOf(raw), a = Brain.speech(raw);
            Actions.Result rc = cmd == null ? null : Actions.parse(this, cmd);
            h.post(() -> { busy = false; reply(a.isEmpty() && rc != null ? rc.say : a, rc); });
        }, "chloe").start();
    }

    void reply(String text, Actions.Result r) {
        if (isFinishing()) return;
        her.setText(text);
        boolean opened = false;
        if (r != null && r.intent != null) opened = Actions.run(this, r);
        Voice.say(this, text);
        setState(L.t("Hablando…"));
        touch();
        if (opened) { h.postDelayed(this::finish, 600); return; }    // se abrió otra app: el panel se aparta
        // cuando termina de hablar, vuelve a escuchar una vez por si quieres seguir la conversación
        h.postDelayed(new Runnable() {
            int waited;
            @Override public void run() {
                if (isFinishing()) return;
                if (Voice.speaking && waited < 60) { waited++; h.postDelayed(this, 300); return; }
                touch();
                if (getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("chloe_followup", true)) listen();
                else setState(L.t("Toca el micrófono para seguir"));
            }
        }, 800);
    }
}
