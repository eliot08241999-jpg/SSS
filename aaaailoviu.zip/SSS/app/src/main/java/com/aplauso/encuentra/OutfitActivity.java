package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * v1.8.2 · 👕 CAMBIAR LA ROPA: dices qué ropa quieres («una chaqueta vaquera azul») y se repinta solo la ropa,
 * con el Estudio de dibujo (dentro del teléfono). Máscara automática (cuerpo sin la cabeza) que se retoca con el dedo.
 * Nunca desnuda ni sexualiza: lo explícito se bloquea y el «lo que NO quieres» lleva siempre NSFW.
 */
public class OutfitActivity extends NeonActivity {
    static final int REQ = 72;
    final Handler h = new Handler(Looper.getMainLooper());
    CompareView cmp;
    Bitmap src, result;
    String name = "foto";
    EditText what;
    SeekBar change;
    TextView brushBtn, info;
    NeonProgress prog;
    volatile boolean busy;
    SdEngine.Job job;

    static final String BLOCK = "(?i).*\\b(desnud\\w*|sin ropa|quita(?:le|r)? la ropa|ropa interior|lencer\\w*|tanga|topless|sexy|sensual|er[oó]tic\\w*|porno?\\w*|nsfw|nude|naked|undress\\w*|"
            + "lingerie|underwear|bikini|nud[oa]|nudi|spoglia\\w*|senza vestiti|intimo|transparen\\w*|see[- ]?through|escote|cleavage)\\b.*";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("👕 CAMBIAR LA ROPA");
        LinearLayout a = panel(null);
        cmp = new CompareView(this);
        a.addView(cmp, new LinearLayout.LayoutParams(-1, dpi(340)));
        info = text("Elige una foto. Se marca la ropa sola (en rojo); retócala con el dedo si hace falta.", 12);
        a.addView(info);
        LinearLayout r = new LinearLayout(this);
        r.addView(button("🖼 FOTO", v -> PickActivity.start(this, new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ, "outfit")), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.leftMargin = dpi(6);
        r.addView(button("💾 GUARDAR", v -> save()), lp);
        a.addView(r, gapBelow(4));
        brushBtn = button("", v -> { cmp.brush = !cmp.brush; cmp.erase = false; refresh(); });
        a.addView(brushBtn, gapBelow(4));
        LinearLayout br = new LinearLayout(this);
        br.addView(button("➕ MARCAR", v -> { cmp.brush = true; cmp.erase = false; refresh(); }), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1); l2.leftMargin = dpi(6);
        br.addView(button("➖ DESMARCAR", v -> { cmp.brush = true; cmp.erase = true; refresh(); }), l2);
        a.addView(br);
        col.addView(a, gapBelow(10));

        LinearLayout o = panel("◢ ¿QUÉ ROPA?");
        what = new EditText(this);
        what.setHint(L.t("p. ej. una chaqueta vaquera azul con camiseta blanca"));
        what.setTextColor(Color.WHITE); what.setHintTextColor(Color.GRAY);
        what.setBackground(frame(10)); what.setPadding(dpi(10), dpi(8), dpi(10), dpi(8));
        o.addView(what, gapBelow(6));
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        LinearLayout chips = new LinearLayout(this);
        for (String c : new String[]{"👔 traje elegante", "🧥 abrigo de invierno", "👘 kimono", "🦸 traje de superhéroe", "🎄 jersey navideño", "⚽ camiseta de fútbol", "🧑‍🍳 de chef", "🥋 de kárate"}) {
            TextView t = button(c, v -> what.setText(c.replaceFirst("^\\S+\\s", "")));
            t.setTextSize(12); t.setPadding(dpi(10), dpi(6), dpi(10), dpi(6));
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2); cl.rightMargin = dpi(5);
            chips.addView(t, cl);
        }
        hs.addView(chips);
        o.addView(hs, gapBelow(6));
        o.addView(text("Cuánto cambia (izquierda = parecida a la original)", 11));
        change = new SeekBar(this); change.setMax(100); change.setProgress(85);
        o.addView(change, gapBelow(6));
        o.addView(button("▶ CAMBIAR LA ROPA", v -> run()), gapBelow(6));
        prog = new NeonProgress(this);
        o.addView(prog, gapBelow(4));
        o.addView(button("✕ CANCELAR", v -> { if (job != null) job.cancel = true; }));
        TextView n = text("Usa el modelo elegido en el Estudio de dibujo. Solo ropa normal: no desnuda ni hace contenido sexual, y menos de personas reales.", 11);
        n.setTextColor(Color.rgb(160, 170, 190));
        o.addView(n);
        col.addView(o);
        refresh();
    }

    void refresh() {
        brushBtn.setText(cmp.brush ? (cmp.erase ? L.t("➖ Desmarcando (toca aquí para terminar)") : L.t("➕ Marcando la ropa (toca aquí para terminar)")) : L.t("✏ RETOCAR LA ZONA CON EL DEDO"));
        cmp.invalidate();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req == REQ && res == RESULT_OK && d != null && d.getData() != null) open(d.getData());
    }

    void open(Uri u) {
        Bitmap b = PhotoTools.load(this, u, 1400);
        if (b == null) { toast(L.t("No puedo abrir esa foto.")); return; }
        src = b.copy(Bitmap.Config.ARGB_8888, false);
        result = null;
        name = Media.nameOf(this, u).replaceAll("\\.[A-Za-z0-9]{2,4}$", "");
        cmp.mask = null;
        cmp.set(src, null);
        cmp.brushPx = Math.max(6, Math.max(src.getWidth(), src.getHeight()) / 50f);
        autoMask();
    }

    /** Ropa ≈ la persona (ML Kit) sin la cabeza (detector de caras de Android). */
    void autoMask() {
        busy = true;
        prog.begin(); prog.phase(L.t("Buscando la ropa…"));
        new Thread(() -> {
            boolean[] m = new boolean[src.getWidth() * src.getHeight()];
            try {
                float[] c = ImgAI.subject(src);
                int W = src.getWidth(), H = src.getHeight();
                for (int i = 0; i < m.length; i++) m[i] = c[i] > 0.5f;
                Bitmap b565 = src.copy(Bitmap.Config.RGB_565, false);
                int fw = W & ~1; if (fw != W) b565 = Bitmap.createBitmap(b565, 0, 0, fw, H);
                android.media.FaceDetector.Face[] f = new android.media.FaceDetector.Face[5];
                int n = new android.media.FaceDetector(b565.getWidth(), H, 5).findFaces(b565, f);
                for (int k = 0; k < n; k++) {
                    android.graphics.PointF mid = new android.graphics.PointF(); f[k].getMidPoint(mid);
                    float ed = f[k].eyesDistance();
                    float cx = mid.x, cy = mid.y + ed * 0.3f, rx = ed * 1.6f, ry = ed * 2.3f;      // cabeza y pelo fuera
                    for (int y = Math.max(0, (int) (cy - ry * 1.4f)); y < Math.min(H, (int) (cy + ry)); y++)
                        for (int x = Math.max(0, (int) (cx - rx)); x < Math.min(W, (int) (cx + rx)); x++) {
                            float dx = (x - cx) / rx, dy = (y - cy) / ry;
                            if (dx * dx + dy * dy < 1 || y < cy) m[y * W + x] = false;
                        }
                }
            } catch (Throwable e) { h.post(() -> toast(L.t("Marca la ropa con el dedo (no pude detectarla sola)."))); }
            h.post(() -> { busy = false; prog.hide(); cmp.setMask(m); });
        }).start();
    }

    void run() {
        if (src == null) { toast(L.t("Primero elige una foto.")); return; }
        if (busy) return;
        String w = what.getText().toString().trim();
        if (w.isEmpty()) { toast(L.t("Dime qué ropa quieres.")); return; }
        if (w.matches(BLOCK)) {
            new android.app.AlertDialog.Builder(this).setMessage(L.t("Eso no lo hago: aquí solo se cambia por ropa normal, sin desnudar ni sexualizar a nadie (y menos a personas reales). Prueba con otra prenda."))
                    .setPositiveButton("OK", null).show();
            return;
        }
        if (!cmp.hasMask()) { toast(L.t("Marca la ropa en rojo con el dedo.")); return; }
        busy = true;
        cmp.brush = false; refresh();
        prog.begin();
        final boolean[] pm = cmp.mask.clone();
        final float strength = 0.55f + 0.45f * change.getProgress() / 100f;
        new Thread(() -> {
            try {
                String en = w;
                if (!"en".equals(L.lang)) {
                    h.post(() -> prog.phase(L.t("Traduciendo…")));
                    DocTranslate.Session tr = new DocTranslate.Session(L.lang, "en");
                    try { tr.prepare(); en = tr.tr(w); } catch (Exception ignored) {} finally { tr.close(); }
                }
                if (en.matches(BLOCK)) throw new SecurityException("blocked");
                // tamaño de trabajo: múltiplos de 64 cerca de 512 con la forma de la foto
                int W = src.getWidth(), H = src.getHeight();
                float ar = W / (float) H;
                int tw = ar >= 1 ? 640 : Math.round(640 * ar / 64f) * 64, th = ar >= 1 ? Math.round(640 / ar / 64f) * 64 : 640;
                tw = Math.max(320, Math.min(768, tw)); th = Math.max(320, Math.min(768, th));
                int lw = tw / 8, lh = th / 8;
                float[] lm = new float[lw * lh];
                for (int y = 0; y < lh; y++) for (int x = 0; x < lw; x++) {   // máscara latente (un poco más grande, para que encaje)
                    int x0 = x * W / lw, x1 = (x + 1) * W / lw, y0 = y * H / lh, y1 = (y + 1) * H / lh, cnt = 0, tot = 0;
                    for (int yy = y0; yy < y1; yy += 2) for (int xx = x0; xx < x1; xx += 2) { tot++; if (pm[yy * W + xx]) cnt++; }
                    lm[y * lw + x] = tot > 0 && cnt > tot * 0.2f ? 1 : 0;
                }
                job = new SdEngine.Job();
                job.model = p.getString("sd_model", job.model);
                job.prompt = "a person wearing " + en + ", photo, realistic, natural lighting, detailed fabric, same pose";
                job.negative = SdEngine.DEFAULT_NEG + ", nude, naked, nsfw, underwear, lingerie, cleavage, deformed, extra arms";
                job.width = tw; job.height = th;
                job.steps = SdEngine.isLcm(job.model) ? 6 : 22;
                job.cfg = SdEngine.isLcm(job.model) ? 1.5f : 7f;
                job.strength = strength;
                job.init = src;
                job.mask = lm;
                Bitmap out = SdEngine.generate(this, job, (step, msg, prev) -> h.post(() -> { if (step >= 0) prog.set(L.t("Pintando la ropa"), step, job.steps); else prog.phase(msg); }));
                if (out == null) throw new InterruptedException();
                // pegar solo la zona marcada (bordes suaves) sobre la foto original a su tamaño
                Bitmap big = Bitmap.createScaledBitmap(out, W, H, true);
                float[] a = new float[W * H];
                for (int i = 0; i < a.length; i++) a[i] = pm[i] ? 1 : 0;
                a = BgRemoveActivity.blur(a, W, H, Math.max(2, Math.max(W, H) / 150));
                int[] o = new int[W * H], s0 = new int[W * H], g = new int[W * H];
                src.getPixels(s0, 0, W, 0, 0, W, H); big.getPixels(g, 0, W, 0, 0, W, H);
                for (int i = 0; i < o.length; i++) {
                    float t = a[i]; int p1 = s0[i], p2 = g[i];
                    o[i] = 0xFF000000 | (Math.round(((p1 >> 16) & 255) * (1 - t) + ((p2 >> 16) & 255) * t) << 16) | (Math.round(((p1 >> 8) & 255) * (1 - t) + ((p2 >> 8) & 255) * t) << 8)
                            | Math.round((p1 & 255) * (1 - t) + (p2 & 255) * t);
                }
                Bitmap res = Bitmap.createBitmap(o, W, H, Bitmap.Config.ARGB_8888);
                h.post(() -> { busy = false; prog.hide(); result = res; cmp.set(src, res); toast(L.t("¡Listo! Arrastra la barra para comparar.")); });
            } catch (SecurityException e) {
                h.post(() -> { busy = false; prog.hide(); toast(L.t("Eso no lo hago: solo ropa normal.")); });
            } catch (InterruptedException e) {
                h.post(() -> { busy = false; prog.hide(); toast(L.t("Cancelado.")); });
            } catch (Throwable e) {
                h.post(() -> { busy = false; prog.hide(); toast(L.t("No se pudo") + ": " + e.getMessage() + " · " + L.t("¿Tienes un modelo descargado en el Estudio?")); });
            }
        }).start();
    }

    void save() {
        if (result == null) { toast(L.t("Primero cambia la ropa.")); return; }
        new Thread(() -> {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            result.compress(Bitmap.CompressFormat.JPEG, 94, bo);
            Uri u = Media.saveBytes(this, bo.toByteArray(), "Ropa", name + "_ropa.jpg", "image/jpeg");
            h.post(() -> toast(u != null ? L.t("Guardada en SSS+/Ropa.") : L.t("No se pudo guardar.")));
        }).start();
    }

    @Override protected void onDestroy() { if (job != null) job.cancel = true; super.onDestroy(); }
}
