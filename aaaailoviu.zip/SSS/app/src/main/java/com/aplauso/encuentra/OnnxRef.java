package com.aplauso.encuentra;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * v1.8.3 · 🧬 REFERENCIA (como «reference_only» de ControlNet, sin descargar nada). Se reescribe el grafo de la UNet:
 * en cada autoatención (attn1) las «claves» y los «valores» se calculan sobre [lo que se dibuja ‖ la referencia], así el
 * dibujo nuevo «mira» a tu personaje (cara, pelo, ropa, colores) en cada paso.
 *  · Cada attn1 recibe una entrada nueva «sssref_i» [lote, fichas, canales] que se concatena a su entrada (eje 1).
 *  · Y saca su entrada como salida «sssrefh_i», para capturarla en la pasada de la referencia.
 * Las proyecciones comprimidas (DynamicQuantizeLinear → MatMulInteger → Cast → Mul) se duplican con su propia compresión
 * para la concatenación; la de la consulta (to_q) se queda igual. El resultado va a otro archivo (el original no se toca).
 */
public class OnnxRef {
    public static final class Report { public int blocks; public String detail = ""; public List<Long> channels = new ArrayList<>(); }

    /** Devuelve cuántas autoatenciones se conectaron (0 = no se reconoció el grafo; detail explica por qué). */
    static Report patch(File in, File out) throws Exception {
        Report rep = new Report();
        byte[] b = java.nio.file.Files.readAllBytes(in.toPath());
        int[] gp = OnnxFloat.findGraph(b);
        if (gp == null) { rep.detail = "sin grafo"; return rep; }
        List<OnnxFloat.Node> nodes = new ArrayList<>();
        Map<String, OnnxPatch.Tensor> inits = new HashMap<>();
        OnnxPatch.Buf r = new OnnxPatch.Buf(b, gp[0]);
        while (r.p < gp[1]) {
            int start = r.p;
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 1 && wt == 2) {
                int n = (int) r.varint();
                OnnxFloat.Node nd = OnnxFloat.parseNode(b, r.p, r.p + n);
                nd.raw = java.util.Arrays.copyOfRange(b, start, r.p + n);
                nodes.add(nd);
                r.p += n;
            } else if (f == 5 && wt == 2) {
                int n = (int) r.varint();
                OnnxPatch.Tensor tn = OnnxPatch.tensor(b, r.p, r.p + n); inits.put(tn.name, tn);
                r.p += n;
            } else r.skip(wt);
        }
        Map<String, OnnxFloat.Node> producer = new HashMap<>();
        Map<String, List<OnnxFloat.Node>> consumers = new HashMap<>();
        for (OnnxFloat.Node n : nodes) {
            for (String o : n.out) producer.put(o, n);
            for (String i : n.in) if (!i.isEmpty()) consumers.computeIfAbsent(i, k -> new ArrayList<>()).add(n);
        }

        // ---- 1) las proyecciones k y v de cada attn1, agrupadas por bloque
        Map<String, List<OnnxFloat.Node>> byBlock = new LinkedHashMap<>();
        int namedMm = 0;
        for (OnnxFloat.Node n : nodes) {
            if (!n.op.equals("MatMul") && !n.op.equals("MatMulInteger")) continue;
            String nm = n.name;
            int k = nm.indexOf("attn1/to_k"), v = nm.indexOf("attn1/to_v");
            if (nm.contains("to_")) namedMm++;
            int at = k >= 0 ? k : v;
            if (at < 0) continue;
            byBlock.computeIfAbsent(nm.substring(0, at + 5), x -> new ArrayList<>()).add(n);
        }
        if (byBlock.isEmpty()) {
            int fused = 0; for (OnnxFloat.Node n : nodes) if (n.op.contains("Attention")) fused++;
            StringBuilder ex = new StringBuilder();
            for (OnnxFloat.Node n : nodes) if ((n.op.equals("MatMul") || n.op.equals("MatMulInteger")) && ex.length() < 300) ex.append(n.name).append(" | ");
            rep.detail = "attn1 no encontrado · nodos " + nodes.size() + " · con to_: " + namedMm + " · atención fusionada: " + fused + " · ej: " + ex;
            return rep;
        }

        Map<OnnxFloat.Node, List<OnnxFloat.Node>> insertBefore = new HashMap<>();
        Map<OnnxFloat.Node, OnnxFloat.Node> replaceWith = new HashMap<>();
        List<String> newInputs = new ArrayList<>(), newOutputs = new ArrayList<>();
        int uid = 0, idx = 0;
        StringBuilder why = new StringBuilder();
        for (Map.Entry<String, List<OnnxFloat.Node>> e : byBlock.entrySet()) {
            List<OnnxFloat.Node> mms = e.getValue();
            // la entrada en coma flotante (lo que sale de norm1)
            String x = null;
            OnnxFloat.Node first = mms.get(0);
            if (first.op.equals("MatMul")) x = inits.containsKey(first.in.get(0)) ? first.in.get(1) : first.in.get(0);
            else { OnnxFloat.Node d = producer.get(first.in.get(0)); if (d != null && d.op.equals("DynamicQuantizeLinear")) x = d.in.get(0); }
            if (x == null) { why.append("sin entrada en ").append(e.getKey()).append("; "); continue; }
            String refIn = "sssref_" + idx, cat = "sssref_cat_" + idx;
            OnnxFloat.Node cc = new OnnxFloat.Node();
            cc.op = "Concat"; cc.name = "sssref_concat_" + idx;
            cc.in.add(x); cc.in.add(refIn); cc.out.add(cat);
            cc.attrs = OnnxFloat.attrInt("axis", 1);
            boolean ok = true;
            List<OnnxFloat.Node> pre = new ArrayList<>();
            pre.add(cc);
            OnnxFloat.Node dqlNew = null;
            for (OnnxFloat.Node m : mms) {
                if (m.op.equals("MatMul")) {                         // sin comprimir: solo cambia la entrada
                    OnnxFloat.Node mm = new OnnxFloat.Node();
                    mm.op = "MatMul"; mm.name = m.name + "_sssref";
                    mm.in.add(m.in.get(0).equals(x) ? cat : m.in.get(0)); mm.in.add(m.in.get(1).equals(x) ? cat : m.in.get(1));
                    mm.out.addAll(m.out);
                    replaceWith.put(m, mm);
                    continue;
                }
                // comprimida: DQL(x) → MatMulInteger → Cast → Mul(escala)
                List<OnnxFloat.Node> cs = consumers.getOrDefault(m.out.get(0), new ArrayList<>());
                if (cs.size() != 1 || !cs.get(0).op.equals("Cast")) { ok = false; break; }
                OnnxFloat.Node cast = cs.get(0);
                List<OnnxFloat.Node> cs2 = consumers.getOrDefault(cast.out.get(0), new ArrayList<>());
                if (cs2.size() != 1 || !cs2.get(0).op.equals("Mul")) { ok = false; break; }
                OnnxFloat.Node mulOut = cs2.get(0);
                OnnxFloat.Node d = producer.get(m.in.get(0));
                if (d == null || !d.op.equals("DynamicQuantizeLinear")) { ok = false; break; }
                String sName = mulOut.in.get(0).equals(cast.out.get(0)) ? mulOut.in.get(1) : mulOut.in.get(0);
                OnnxFloat.Node sMul = producer.get(sName);
                if (sMul == null || !sMul.op.equals("Mul")) { ok = false; break; }
                String wScale = sMul.in.get(0).equals(d.out.get(1)) ? sMul.in.get(1) : sMul.in.get(1).equals(d.out.get(1)) ? sMul.in.get(0) : null;
                if (wScale == null) { ok = false; break; }
                if (dqlNew == null) {
                    dqlNew = new OnnxFloat.Node();
                    dqlNew.op = "DynamicQuantizeLinear"; dqlNew.name = "sssref_dql_" + idx;
                    dqlNew.in.add(cat);
                    dqlNew.out.add("sssref_q_" + idx); dqlNew.out.add("sssref_s_" + idx); dqlNew.out.add("sssref_z_" + idx);
                    pre.add(dqlNew);
                }
                OnnxFloat.Node mi = new OnnxFloat.Node();
                mi.op = "MatMulInteger"; mi.name = m.name + "_sssref";
                mi.in.add(dqlNew.out.get(0)); mi.in.add(m.in.get(1)); mi.in.add(dqlNew.out.get(2));
                if (m.in.size() > 3) mi.in.add(m.in.get(3));
                mi.out.add("sssref_mi_" + (uid++));
                OnnxFloat.Node ca = new OnnxFloat.Node();
                ca.op = "Cast"; ca.name = "sssref_cast_" + uid; ca.in.add(mi.out.get(0)); ca.out.add("sssref_ca_" + (uid++));
                ca.attrs = OnnxFloat.attrInt("to", 1);
                OnnxFloat.Node sm = new OnnxFloat.Node();
                sm.op = "Mul"; sm.name = "sssref_smul_" + uid; sm.in.add(dqlNew.out.get(1)); sm.in.add(wScale); sm.out.add("sssref_sm_" + (uid++));
                OnnxFloat.Node mo = new OnnxFloat.Node();
                mo.op = "Mul"; mo.name = mulOut.name + "_sssref"; mo.in.add(ca.out.get(0)); mo.in.add(sm.out.get(0));
                mo.out.addAll(mulOut.out);                                // mismo nombre de salida: lo de después no cambia
                List<OnnxFloat.Node> chain = new ArrayList<>();
                chain.add(mi); chain.add(ca); chain.add(sm);
                insertBefore.put(mulOut, chain);
                replaceWith.put(mulOut, mo);
                m.dead = true; cast.dead = true;
            }
            if (!ok) { why.append("patrón raro en ").append(e.getKey()).append("; "); continue; }
            // la concatenación (y su compresión) justo antes de la primera proyección (k o v), ya después de norm1
            insertBefore.computeIfAbsent(first, k -> new ArrayList<>()).addAll(0, pre);
            // canales de este bloque (filas del peso de k): hacen falta para la entrada vacía
            String wName = first.op.equals("MatMul") ? (inits.containsKey(first.in.get(1)) ? first.in.get(1) : first.in.get(0)) : first.in.get(1);
            OnnxPatch.Tensor wt = inits.get(wName);
            rep.channels.add(wt != null && wt.dims.size() == 2 ? wt.dims.get(0) : -1L);
            newInputs.add(refIn);
            newOutputs.add(x);
            idx++;
        }
        rep.blocks = idx;
        rep.detail = why.toString();
        if (idx == 0) return rep;

        // ---- 2) escribir el grafo: nodos (en orden), entradas y salidas nuevas
        ByteArrayOutputStream g = new ByteArrayOutputStream(gp[1] - gp[0] + 65536);
        int ni = 0;
        r = new OnnxPatch.Buf(b, gp[0]);
        while (r.p < gp[1]) {
            int start = r.p;
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 1 && wt == 2) {
                int n = (int) r.varint();
                r.p += n;
                OnnxFloat.Node nd = nodes.get(ni++);
                List<OnnxFloat.Node> pre = insertBefore.get(nd);
                if (pre != null) for (OnnxFloat.Node p : pre) OnnxFloat.writeNode(g, p, new HashMap<>());
                OnnxFloat.Node rp = replaceWith.get(nd);
                if (rp != null) OnnxFloat.writeNode(g, rp, new HashMap<>());
                else if (!nd.dead) g.write(nd.raw, 0, nd.raw.length);
            } else if (f == 13 && wt == 2) {
                r.skip(wt);                                              // value_info: opcional
            } else { r.skip(wt); g.write(b, start, r.p - start); }
        }
        for (int i = 0; i < newInputs.size(); i++) valueInfo(g, 11, newInputs.get(i), true);
        for (int i = 0; i < newOutputs.size(); i++) {
            // la salida se llama como el tensor interno; se añade un Identity con nombre propio para no chocar con nada
            OnnxFloat.Node id = new OnnxFloat.Node();
            id.op = "Identity"; id.name = "sssrefh_id_" + i; id.in.add(newOutputs.get(i)); id.out.add("sssrefh_" + i);
            OnnxFloat.writeNode(g, id, new HashMap<>());
            valueInfo(g, 12, "sssrefh_" + i, false);
        }
        byte[] graph = g.toByteArray();
        try (java.io.OutputStream os = new java.io.BufferedOutputStream(new java.io.FileOutputStream(out), 1 << 16)) {
            OnnxPatch.Buf m = new OnnxPatch.Buf(b, 0);
            while (m.p < b.length) {
                int start = m.p;
                long key = m.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
                if (f == 7 && wt == 2) {
                    int n = (int) m.varint();
                    m.p += n;
                    OnnxPatch.putVarint(os, key); OnnxPatch.putVarint(os, graph.length); os.write(graph);
                } else { m.skip(wt); os.write(b, start, m.p - start); }
            }
        }
        return rep;
    }

    /** ValueInfoProto: nombre + tensor float (entradas: rango 3 con dimensiones simbólicas). */
    static void valueInfo(ByteArrayOutputStream g, int field, String name, boolean shaped) {
        ByteArrayOutputStream tt = new ByteArrayOutputStream();
        OnnxPatch.putVarint(tt, 1 << 3); OnnxPatch.putVarint(tt, 1);              // elem_type = FLOAT
        if (shaped) {
            ByteArrayOutputStream sh = new ByteArrayOutputStream();
            for (String d : new String[]{"ref_b", "ref_n", "ref_c"}) {
                ByteArrayOutputStream dim = new ByteArrayOutputStream();
                OnnxFloat.str(dim, 2, d);                                       // dim_param
                byte[] x = dim.toByteArray();
                OnnxPatch.putVarint(sh, (1 << 3) | 2); OnnxPatch.putVarint(sh, x.length); sh.write(x, 0, x.length);
            }
            byte[] x = sh.toByteArray();
            OnnxPatch.putVarint(tt, (2 << 3) | 2); OnnxPatch.putVarint(tt, x.length); tt.write(x, 0, x.length);
        }
        ByteArrayOutputStream type = new ByteArrayOutputStream();
        byte[] t = tt.toByteArray();
        OnnxPatch.putVarint(type, (1 << 3) | 2); OnnxPatch.putVarint(type, t.length); type.write(t, 0, t.length);   // tensor_type
        ByteArrayOutputStream vi = new ByteArrayOutputStream();
        OnnxFloat.str(vi, 1, name);
        byte[] ty = type.toByteArray();
        OnnxPatch.putVarint(vi, (2 << 3) | 2); OnnxPatch.putVarint(vi, ty.length); vi.write(ty, 0, ty.length);
        byte[] v = vi.toByteArray();
        OnnxPatch.putVarint(g, (field << 3) | 2); OnnxPatch.putVarint(g, v.length); g.write(v, 0, v.length);
    }
}
