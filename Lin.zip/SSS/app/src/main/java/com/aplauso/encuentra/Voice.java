package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.Locale;

/**
 * La voz del asistente (v0.9.2): usa los motores de voz instalados en el teléfono.
 * Se puede elegir el motor (Google, Samsung, RHVoice... los que instales desde Play Store),
 * la voz concreta, el tono y la velocidad.
 */
public class Voice {
    static TextToSpeech tts;
    static String engineNow;
    static volatile boolean ready, speaking;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    static void init(Context c, Runnable onReady) {
        Context app = c.getApplicationContext();
        String eng = prefs(c).getString("tts_engine", "");
        if (tts != null && eng.equals(engineNow == null ? "" : engineNow) && ready) { if (onReady != null) onReady.run(); return; }
        shutdown();
        engineNow = eng;
        TextToSpeech.OnInitListener l = status -> {
            ready = status == TextToSpeech.SUCCESS;
            if (ready) apply(app);
            if (onReady != null) onReady.run();
        };
        tts = eng.isEmpty() ? new TextToSpeech(app, l) : new TextToSpeech(app, l, eng);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { speaking = true; lastWord = android.os.SystemClock.uptimeMillis(); }
            @Override public void onRangeStart(String id, int start, int end, int frame) { lastWord = android.os.SystemClock.uptimeMillis(); }   // v1.4: para mover la boca
            @Override public void onDone(String id) { speaking = false; }
            @Override public void onError(String id) { speaking = false; }
        });
    }

    /** v1.4: cuándo empezó la última palabra (para la boca de Chloe). */
    static volatile long lastWord;

    static void apply(Context c) {
        if (tts == null || !ready) return;
        SharedPreferences p = prefs(c);
        Locale loc = "en".equals(L.lang) ? Locale.US : "it".equals(L.lang) ? Locale.ITALY : new Locale("es", "ES");
        try { tts.setLanguage(loc); } catch (Exception ignored) {}
        String vn = p.getString("tts_voice", "");
        if (!vn.isEmpty()) {
            try {
                for (android.speech.tts.Voice v : tts.getVoices()) if (v.getName().equals(vn)) { tts.setVoice(v); break; }
            } catch (Exception ignored) {}
        }
        tts.setPitch(p.getInt("tts_pitch", 100) / 100f);
        tts.setSpeechRate(p.getInt("tts_rate", 100) / 100f);
    }

    static void say(Context c, String text) {
        init(c, () -> {
            if (!ready) return;
            apply(c);
            speaking = true;
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), "sss" + System.currentTimeMillis());
        });
    }

    static void stop() { if (tts != null) try { tts.stop(); } catch (Exception ignored) {} speaking = false; }

    static void shutdown() {
        if (tts != null) try { tts.shutdown(); } catch (Exception ignored) {}
        tts = null;
        ready = false;
        speaking = false;
    }
}
