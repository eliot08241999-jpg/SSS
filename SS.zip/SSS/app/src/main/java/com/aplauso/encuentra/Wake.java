package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.File;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Palabra clave del asistente (v0.9.2), sin internet: usa Vosk con un modelo pequeño de voz (≈40 MB)
 * que se descarga una vez. Escucha SOLO la palabra elegida ("paradoja"); al oírla, escucha la pregunta
 * y la pasa al cerebro de Chloe. Nada del audio sale del teléfono.
 */
public class Wake {
    interface Listener { void onWake(); void onQuestion(String text); }

    static final String[][] MODELS = {
            {"es", "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip", "hey chloe, hola chloe, clo responde"},
            {"en", "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip", "hey chloe, hello chloe, chloe answer"},
            {"it", "https://alphacephei.com/vosk/models/vosk-model-small-it-0.22.zip", "hey chloe, ciao chloe, clo rispondi"},
    };

    static volatile Listener listener;
    static Model model;
    static String modelLang;
    static Recognizer wakeRec, askRec;
    static String wakeFor;
    static volatile boolean asking;
    static long askStart;
    static float[] resampleCarry;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static boolean enabled(Context c) { return prefs(c).getBoolean("ai_wake", false); }
    static String lang() { return "en".equals(L.lang) || "it".equals(L.lang) ? L.lang : "es"; }
    static String[] info() { for (String[] m : MODELS) if (m[0].equals(lang())) return m; return MODELS[0]; }
    static String phrase(Context c) {
        String s = prefs(c).getString("ai_phrase", "").trim().toLowerCase(java.util.Locale.ROOT);
        if (s.matches("paradoja|paradox|paradosso")) s = "";        // la antigua palabra por defecto → las nuevas
        return s.isEmpty() ? info()[2] : s;
    }
    static File dir(Context c) { return new File(c.getFilesDir(), "vosk-" + lang()); }
    static boolean downloaded(Context c) { return new File(dir(c), "am").exists() || new File(dir(c), "conf").exists(); }

    /** ¿Está todo listo para escuchar la palabra clave? */
    static boolean ready(Context c) { return enabled(c) && downloaded(c); }

    interface Progress { void at(int percent, String msg); }

    // v0.9.2: la descarga la hace el gestor de descargas de Android: sigue aunque salgas de la app,
    // se reanuda sola si se corta y avisa con su propia notificación. Primero desde Hugging Face (rápido)
    // y, si falla, desde la web oficial de Vosk.
    static String[] urls() {
        String[] m = info();
        String file = m[1].substring(m[1].lastIndexOf('/') + 1);
        return new String[]{"https://huggingface.co/rhasspy/vosk-models/resolve/main/" + m[0] + "/" + file, m[1]};
    }

    static File zipFile(Context c) { return new File(c.getExternalFilesDir(null), "vosk-" + lang() + ".zip"); }
    static String idKey() { return "vosk_dl_" + lang(); }

    /** Empieza (o deja seguir) la descarga. */
    static void startDownload(Context c, int mirror) {
        android.app.DownloadManager dm = c.getSystemService(android.app.DownloadManager.class);
        long old = prefs(c).getLong(idKey(), -1);
        if (old >= 0) {
            int[] st = status(c);
            if (st != null && (st[0] == android.app.DownloadManager.STATUS_RUNNING || st[0] == android.app.DownloadManager.STATUS_PENDING
                    || st[0] == android.app.DownloadManager.STATUS_PAUSED)) return;          // ya va: no empezar de cero
            dm.remove(old);
        }
        File z = zipFile(c);
        if (z.exists()) z.delete();
        android.app.DownloadManager.Request r = new android.app.DownloadManager.Request(android.net.Uri.parse(urls()[Math.min(mirror, 1)]))
                .setTitle(L.t("Oído del asistente SSS+"))
                .setDescription(L.t("Modelo de voz para la palabra clave"))
                .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationUri(android.net.Uri.fromFile(z))
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true);
        long id = dm.enqueue(r);
        prefs(c).edit().putLong(idKey(), id).putInt("vosk_mirror", mirror).apply();
    }

    /** {estado, bytes bajados, bytes totales} o null si no hay descarga. */
    static int[] status(Context c) {
        long id = prefs(c).getLong(idKey(), -1);
        if (id < 0) return null;
        android.app.DownloadManager dm = c.getSystemService(android.app.DownloadManager.class);
        try (android.database.Cursor k = dm.query(new android.app.DownloadManager.Query().setFilterById(id))) {
            if (k == null || !k.moveToFirst()) return null;
            int st = k.getInt(k.getColumnIndexOrThrow(android.app.DownloadManager.COLUMN_STATUS));
            long got = k.getLong(k.getColumnIndexOrThrow(android.app.DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            long tot = k.getLong(k.getColumnIndexOrThrow(android.app.DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            return new int[]{st, (int) (got >> 10), (int) (tot >> 10)};
        } catch (Exception e) {
            return null;
        }
    }

    static volatile boolean unzipping;

    /**
     * Mira cómo va la descarga: devuelve un texto para mostrar. Si ya terminó, descomprime
     * (bloquea unos segundos: llamar desde un hilo). Si falló, prueba con el otro servidor.
     */
    static synchronized String poll(Context c, Progress pr) {
        if (downloaded(c)) return null;
        int[] st = status(c);
        if (st == null) return null;
        if (st[0] == android.app.DownloadManager.STATUS_SUCCESSFUL) {
            if (unzipping) return L.t("Descomprimiendo…");
            unzipping = true;
            try {
                boolean ok = unzip(c, zipFile(c), pr);
                prefs(c).edit().remove(idKey()).apply();
                zipFile(c).delete();
                return ok ? L.t("¡Listo!") : L.t("El archivo llegó dañado: vuelve a descargarlo.");
            } finally { unzipping = false; }
        }
        if (st[0] == android.app.DownloadManager.STATUS_FAILED) {
            int mirror = prefs(c).getInt("vosk_mirror", 0);
            if (mirror == 0) { startDownload(c, 1); return L.t("Probando con otro servidor…"); }
            prefs(c).edit().remove(idKey()).apply();
            return L.t("No se pudo descargar. Revisa tu conexión y vuelve a intentarlo.");
        }
        String mb = (st[1] >> 10) + " / " + (st[2] > 0 ? (st[2] >> 10) + " MB" : "? MB");
        int pc = st[2] > 0 ? (int) ((long) st[1] * 100 / st[2]) : 0;
        if (st[0] == android.app.DownloadManager.STATUS_PAUSED) return L.t("Descarga en pausa (esperando conexión)… ") + mb;
        return L.t("Descargando el oído… ") + mb + "  " + pc + " % · " + L.t("puedes salir de la app, sigue sola");
    }

    static boolean unzip(Context c, File zip, Progress pr) {
        File out = dir(c);
        try {
            pr.at(92, L.t("Descomprimiendo…"));
            deleteAll(out);
            out.mkdirs();
            try (ZipInputStream z = new ZipInputStream(new java.io.FileInputStream(zip))) {
                ZipEntry e;
                byte[] b = new byte[65536];
                while ((e = z.getNextEntry()) != null) {
                    String name = e.getName();
                    int slash = name.indexOf('/');
                    if (slash < 0) continue;
                    name = name.substring(slash + 1);          // quita la carpeta "vosk-model-small-xx/"
                    if (name.isEmpty() || name.contains("..")) continue;
                    File f = new File(out, name);
                    if (e.isDirectory()) { f.mkdirs(); continue; }
                    f.getParentFile().mkdirs();
                    try (FileOutputStream fo = new FileOutputStream(f)) {
                        int n;
                        while ((n = z.read(b)) > 0) fo.write(b, 0, n);
                    }
                }
            }
            close();
            pr.at(100, L.t("¡Listo!"));
            return downloaded(c);
        } catch (Exception e) {
            pr.at(-1, L.t("No se pudo descomprimir: ") + e.getMessage());
            return false;
        }
    }

    static void deleteAll(File f) {
        if (f.isDirectory()) { File[] k = f.listFiles(); if (k != null) for (File x : k) deleteAll(x); }
        f.delete();
    }

    /** Prepara el modelo y el reconocedor de la palabra clave. */
    static synchronized boolean prepare(Context c) {
        if (!ready(c)) return false;
        try {
            if (model == null || !lang().equals(modelLang)) {
                close();
                model = new Model(dir(c).getAbsolutePath());
                modelLang = lang();
            }
            String ph = phrase(c);
            if (wakeRec == null || !ph.equals(wakeFor)) {
                if (wakeRec != null) wakeRec.close();
                // v1.0: reconocedor LIBRE (antes era una gramática con solo la palabra clave, y Vosk acababa
                // "oyendo" paradoja en cualquier frase: por eso respondía sin que la dijeras).
                wakeRec = new Recognizer(model, 16000f);
                wakeRec.setWords(true);
                wakeFor = ph;
            }
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    static synchronized void close() {
        if (wakeRec != null) wakeRec.close();
        if (askRec != null) askRec.close();
        if (model != null) model.close();
        wakeRec = askRec = null;
        model = null;
        asking = false;
    }

    /** Le pasa audio (de cualquier frecuencia) al detector. */
    static synchronized void feed(Context c, short[] buf, int n, int rate) {
        if (wakeRec == null || n <= 0) return;
        if (Voice.speaking) return;                 // que no se escuche a sí mismo
        short[] s = rate == 16000 ? buf : resample(buf, n, rate);
        int len = rate == 16000 ? n : s.length;
        try {
            if (!asking) {
                if (System.currentTimeMillis() < quietUntil) { wakeRec.acceptWaveForm(s, len); return; }
                if (wakeRec.acceptWaveForm(s, len)) check(c, wakeRec.getResult());
            } else {
                boolean end = askRec.acceptWaveForm(s, len);
                long t = System.currentTimeMillis();
                if (end || t - askStart > 9000) {
                    String q = text(end ? askRec.getResult() : askRec.getFinalResult());
                    if (q.isEmpty() && !end) q = text(askRec.getFinalResult());
                    if (!q.isEmpty() || t - askStart > 9000) {
                        asking = false;
                        askRec.close();
                        askRec = null;
                        wakeRec.reset();
                        quietUntil = System.currentTimeMillis() + 1500;
                        Listener l = listener;
                        if (l != null && !q.isEmpty()) l.onQuestion(q);
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    /** Tras responder, unos segundos sin escuchar la palabra clave (que no se active con su propia voz). */
    static volatile long quietUntil;
    static final float MIN_CONF = 0.75f;

    static String plain(String s) {
        return java.text.Normalizer.normalize(s.toLowerCase(java.util.Locale.ROOT), java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").replaceAll("[^a-z0-9]", "");
    }

    /** Lo último que oyó el oído (solo en memoria, para la pantalla del asistente; no se guarda). */
    static volatile String heard = "";

    /** Las frases para despertarla, separadas por comas («hey chloe, hola chloe, clo responde»). */
    static String[] phrases(String all) {
        String[] p = all.split("[,;/|]");
        java.util.List<String> out = new java.util.ArrayList<>();
        for (String x : p) if (!x.trim().isEmpty()) out.add(x.trim());
        return out.toArray(new String[0]);
    }

    /** Forma "fonética" para comparar con lo que oye el reconocedor (Chloe → cloe, hey → ei, hola → ola…). */
    static String sound(String s) {
        String t = plain(s);
        t = t.replace("ch", "c").replace("ll", "i").replace("h", "").replace("y", "i").replace("k", "c").replace("q", "c")
                .replace("v", "b").replace("z", "s").replace("w", "u");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < t.length(); i++) if (i == 0 || t.charAt(i) != t.charAt(i - 1)) b.append(t.charAt(i));
        return b.toString();
    }

    static int dist(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++)
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1));
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    static final float MIN_FUZZY_CONF = 0.6f;

    /**
     * Se activa si en una frase TERMINADA aparece alguna de las frases clave («hey Chloe», «hola Chloe», «Clo, responde»),
     * comparando cómo suena (el reconocedor escribe «Chloe» como «cloe», «clo e»…) y con seguridad suficiente.
     * Si dijiste algo después («hola Chloe, ¿qué tiempo hace?»), eso ya es la pregunta.
     */
    static void check(Context c, String json) {
        try {
            org.json.JSONArray w = new JSONObject(json).optJSONArray("result");
            if (w == null || w.length() == 0) return;
            heard = new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ROOT).format(new java.util.Date()) + " · «" + text(json) + "»";
            String[] ph = phrases(wakeFor);
            int nW = w.length();
            int bestEnd = -1, bestD = 99;
            float bestConf = 0;
            for (String p : ph) {
                String target = sound(p);
                if (target.length() < 3) continue;
                int maxD = target.length() >= 9 ? 2 : 1;
                for (int i = 0; i < nW; i++) {
                    StringBuilder joined = new StringBuilder();
                    float confSum = 0;
                    for (int k = i; k < Math.min(nW, i + 4); k++) {
                        JSONObject o = w.getJSONObject(k);
                        joined.append(o.optString("word", ""));
                        confSum += (float) o.optDouble("conf", 0);
                        String got = sound(joined.toString());
                        if (got.length() > target.length() + 2) break;
                        int d = dist(got, target);
                        float conf = confSum / (k - i + 1);
                        if (d <= maxD && conf >= MIN_FUZZY_CONF && (d < bestD || (d == bestD && conf > bestConf))) {
                            bestD = d; bestEnd = k; bestConf = conf;
                        }
                    }
                }
            }
            if (bestEnd < 0) return;
            StringBuilder rest = new StringBuilder();
            for (int r = bestEnd + 1; r < nW; r++) rest.append(rest.length() == 0 ? "" : " ").append(w.getJSONObject(r).optString("word", ""));
            String q = rest.toString().trim();
            prefs(c).edit().putString("wake_last", new java.text.SimpleDateFormat("HH:mm", java.util.Locale.ROOT).format(new java.util.Date())
                    + " · «" + text(json) + "» (" + Math.round(bestConf * 100) + " %)").apply();
            Listener l = listener;
            if (q.split(" ").length >= 2 || q.length() >= 6) {     // la pregunta vino en la misma frase
                if (l != null) l.onQuestion(q);
                wakeRec.reset();
            } else startAsking();
        } catch (Exception ignored) {}
    }

    /** El panel de Chloe se encarga de escuchar la pregunta: el oído vuelve a esperar la palabra clave. */
    static synchronized void cancelAsk() {
        if (askRec != null) try { askRec.close(); } catch (Throwable ignored) {}
        askRec = null;
        asking = false;
        quietUntil = System.currentTimeMillis() + 3000;
    }

    static void startAsking() {
        try {
            askRec = new Recognizer(model, 16000f);
            asking = true;
            askStart = System.currentTimeMillis();
            Listener l = listener;
            if (l != null) l.onWake();
        } catch (Throwable ignored) {}
    }

    static String text(String json) { return text(json, "text"); }
    static String text(String json, String key) {
        try { return new JSONObject(json).optString(key, "").trim(); } catch (Exception e) { return ""; }
    }

    /** Cambia la frecuencia a 16 kHz (interpolación lineal sencilla). */
    static short[] resample(short[] in, int n, int rate) {
        int outN = (int) ((long) n * 16000 / rate);
        short[] out = new short[outN];
        double step = (double) rate / 16000;
        for (int i = 0; i < outN; i++) {
            double x = i * step;
            int a = (int) x;
            int b = Math.min(n - 1, a + 1);
            double f = x - a;
            out[i] = (short) (in[a] * (1 - f) + in[b] * f);
        }
        return out;
    }
}
