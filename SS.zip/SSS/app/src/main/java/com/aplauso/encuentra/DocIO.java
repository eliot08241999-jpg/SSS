package com.aplauso.encuentra;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Lectura y escritura de documentos TXT, DOCX y EPUB en Java puro (son ZIP con XML dentro).
 * Los PDF se leen y escriben en DocPdf (usa Android y PdfBox).
 * Un documento se representa como título + lista de párrafos.
 */
public class DocIO {

    public static class Doc {
        String title = "";
        String type = "txt";
        final List<String> paras = new ArrayList<>();

        String text() {
            StringBuilder sb = new StringBuilder();
            for (String p : paras) sb.append(p).append("\n\n");
            return sb.toString().trim();
        }

        static Doc fromText(String title, String text) {
            Doc d = new Doc();
            d.title = title;
            for (String p : text.replace("\r", "").split("\n\\s*\n|\n")) {
                String t = p.trim();
                if (!t.isEmpty()) d.paras.add(t);
            }
            return d;
        }
    }

    static final String[] FORMATS = {"pdf", "epub", "docx", "txt"};

    /** Tipo de documento según el nombre del archivo (null si no es un documento). */
    static String typeOf(String name) {
        if (name == null) return null;
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".pdf")) return "pdf";
        if (n.endsWith(".epub")) return "epub";
        if (n.endsWith(".docx")) return "docx";
        if (n.endsWith(".txt") || n.endsWith(".md") || n.endsWith(".log") || n.endsWith(".csv")) return "txt";
        if (n.endsWith(".html") || n.endsWith(".htm") || n.endsWith(".xhtml")) return "html";
        return null;
    }

    static String mime(String type) {
        switch (type) {
            case "pdf": return "application/pdf";
            case "epub": return "application/epub+zip";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            default: return "text/plain";
        }
    }

    static String baseName(String name) {
        if (name == null) return "documento";
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name;
    }

    // =====================================================================
    // Lectura
    // =====================================================================
    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        return bos.toByteArray();
    }

    static Doc readTxt(InputStream in, String title) throws IOException {
        String s = new String(readAll(in), StandardCharsets.UTF_8);
        if (s.startsWith("﻿")) s = s.substring(1);
        Doc d = Doc.fromText(title, s);
        d.type = "txt";
        return d;
    }

    static Doc readHtml(InputStream in, String title) throws IOException {
        Doc d = new Doc();
        d.title = title;
        d.type = "html";
        d.paras.addAll(htmlToParas(new String(readAll(in), StandardCharsets.UTF_8)));
        return d;
    }

    static Map<String, byte[]> unzip(InputStream in) throws IOException {
        Map<String, byte[]> m = new HashMap<>();
        try (ZipInputStream z = new ZipInputStream(in)) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (!e.isDirectory()) m.put(e.getName(), readAll(z));
            }
        }
        return m;
    }

    static final Pattern W_P = Pattern.compile("<w:p[ >].*?</w:p>|<w:p/>", Pattern.DOTALL);
    static final Pattern W_RUN = Pattern.compile("<w:t(?: [^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br/>|<w:cr/>", Pattern.DOTALL);

    static Doc readDocx(InputStream in, String title) throws IOException {
        Map<String, byte[]> m = unzip(in);
        byte[] xml = m.get("word/document.xml");
        if (xml == null) throw new IOException("No es un DOCX válido");
        Doc d = new Doc();
        d.title = title;
        d.type = "docx";
        String s = new String(xml, StandardCharsets.UTF_8);
        Matcher p = W_P.matcher(s);
        while (p.find()) {
            Matcher r = W_RUN.matcher(p.group());
            StringBuilder sb = new StringBuilder();
            while (r.find()) {
                String g = r.group();
                if (g.startsWith("<w:tab")) sb.append('\t');
                else if (g.startsWith("<w:br") || g.startsWith("<w:cr")) sb.append('\n');
                else sb.append(unesc(r.group(1)));
            }
            String t = sb.toString().trim();
            if (!t.isEmpty()) d.paras.add(t);
        }
        byte[] core = m.get("docProps/core.xml");
        if (core != null) {
            String ct = find(new String(core, StandardCharsets.UTF_8), "<dc:title>(.*?)</dc:title>");
            if (ct != null && !ct.trim().isEmpty()) d.title = unesc(ct.trim());
        }
        return d;
    }

    static Doc readEpub(InputStream in, String title) throws IOException {
        Map<String, byte[]> m = unzip(in);
        byte[] cont = m.get("META-INF/container.xml");
        if (cont == null) throw new IOException("No es un EPUB válido");
        String opfPath = find(new String(cont, StandardCharsets.UTF_8), "full-path=\"([^\"]+)\"");
        byte[] opfB = opfPath == null ? null : m.get(opfPath);
        if (opfB == null) throw new IOException("EPUB sin índice");
        String opf = new String(opfB, StandardCharsets.UTF_8);
        String base = opfPath.contains("/") ? opfPath.substring(0, opfPath.lastIndexOf('/') + 1) : "";
        Doc d = new Doc();
        d.type = "epub";
        String t = find(opf, "<dc:title[^>]*>(.*?)</dc:title>");
        d.title = t != null ? unesc(t.trim()) : title;
        Map<String, String> hrefs = new HashMap<>();
        Matcher it = Pattern.compile("<item\\s[^>]*>", Pattern.DOTALL).matcher(opf);
        while (it.find()) {
            String tag = it.group();
            String id = attr(tag, "id"), href = attr(tag, "href");
            if (id != null && href != null) hrefs.put(id, href);
        }
        Matcher sp = Pattern.compile("<itemref\\s[^>]*idref=\"([^\"]+)\"", Pattern.DOTALL).matcher(opf);
        while (sp.find()) {
            String href = hrefs.get(sp.group(1));
            if (href == null) continue;
            String path = base + decode(href);
            byte[] page = m.get(path);
            if (page == null) continue;
            d.paras.addAll(htmlToParas(new String(page, StandardCharsets.UTF_8)));
        }
        return d;
    }

    static String decode(String s) {
        try { return URLDecoder.decode(s.replace("+", "%2B"), "UTF-8"); } catch (Exception e) { return s; }
    }

    static String attr(String tag, String name) {
        Matcher a = Pattern.compile("\\s" + name + "=\"([^\"]*)\"").matcher(tag);
        return a.find() ? a.group(1) : null;
    }

    static String find(String s, String regex) {
        Matcher mm = Pattern.compile(regex, Pattern.DOTALL).matcher(s);
        return mm.find() ? mm.group(1) : null;
    }

    static List<String> htmlToParas(String html) {
        String s = html.replaceAll("(?is)<head.*?</head>", "")
                .replaceAll("(?is)<script.*?</script>", "")
                .replaceAll("(?is)<style.*?</style>", "")
                .replaceAll("(?i)<br\\s*/?>", "\n")
                .replaceAll("(?i)</(p|div|h[1-6]|li|tr|blockquote|section|title)>", "\n")
                .replaceAll("(?s)<[^>]+>", "");
        s = unesc(s);
        List<String> out = new ArrayList<>();
        for (String line : s.split("\n")) {
            String t = line.replaceAll("[ \\t\\u00A0]+", " ").trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    static String unesc(String s) {
        if (s == null) return "";
        if (s.indexOf('&') < 0) return s;
        StringBuilder sb = new StringBuilder();
        Matcher mm = Pattern.compile("&(#x[0-9a-fA-F]+|#[0-9]+|[a-zA-Z]+);").matcher(s);
        int last = 0;
        while (mm.find()) {
            sb.append(s, last, mm.start());
            String e = mm.group(1);
            String rep;
            try {
                if (e.startsWith("#x")) rep = new String(Character.toChars(Integer.parseInt(e.substring(2), 16)));
                else if (e.startsWith("#")) rep = new String(Character.toChars(Integer.parseInt(e.substring(1))));
                else {
                    switch (e) {
                        case "amp": rep = "&"; break;
                        case "lt": rep = "<"; break;
                        case "gt": rep = ">"; break;
                        case "quot": rep = "\""; break;
                        case "apos": rep = "'"; break;
                        case "nbsp": rep = " "; break;
                        case "mdash": rep = "—"; break;
                        case "ndash": rep = "–"; break;
                        case "hellip": rep = "…"; break;
                        case "laquo": rep = "«"; break;
                        case "raquo": rep = "»"; break;
                        case "iexcl": rep = "¡"; break;
                        case "iquest": rep = "¿"; break;
                        case "ntilde": rep = "ñ"; break;
                        case "Ntilde": rep = "Ñ"; break;
                        case "aacute": rep = "á"; break;
                        case "eacute": rep = "é"; break;
                        case "iacute": rep = "í"; break;
                        case "oacute": rep = "ó"; break;
                        case "uacute": rep = "ú"; break;
                        default: rep = mm.group(); break;
                    }
                }
            } catch (Exception x) { rep = mm.group(); }
            sb.append(rep);
            last = mm.end();
        }
        sb.append(s.substring(last));
        return sb.toString();
    }

    static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    // =====================================================================
    // Escritura
    // =====================================================================
    static void writeTxt(Doc d, OutputStream os) throws IOException {
        os.write(d.text().getBytes(StandardCharsets.UTF_8));
    }

    static void putText(ZipOutputStream z, String name, String content) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    static void writeDocx(Doc d, OutputStream os) throws IOException {
        try (ZipOutputStream z = new ZipOutputStream(os)) {
            putText(z, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                    + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                    + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                    + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                    + "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"
                    + "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>"
                    + "</Types>");
            putText(z, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                    + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                    + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>"
                    + "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
                    + "</Relationships>");
            putText(z, "docProps/core.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                    + "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" "
                    + "xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:title>" + esc(d.title) + "</dc:title><dc:creator>SSS+</dc:creator></cp:coreProperties>");
            StringBuilder b = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                    + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>");
            for (String p : d.paras) {
                b.append("<w:p><w:r>");
                String[] lines = p.split("\n", -1);
                for (int i = 0; i < lines.length; i++) {
                    if (i > 0) b.append("<w:br/>");
                    b.append("<w:t xml:space=\"preserve\">").append(esc(lines[i])).append("</w:t>");
                }
                b.append("</w:r></w:p>");
            }
            b.append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\"/></w:sectPr>");
            b.append("</w:body></w:document>");
            putText(z, "word/document.xml", b.toString());
        }
    }

    static void writeEpub(Doc d, OutputStream os) throws IOException {
        try (ZipOutputStream z = new ZipOutputStream(os)) {
            // "mimetype" debe ir primero y sin comprimir
            byte[] mt = "application/epub+zip".getBytes(StandardCharsets.US_ASCII);
            ZipEntry me = new ZipEntry("mimetype");
            me.setMethod(ZipEntry.STORED);
            me.setSize(mt.length);
            me.setCompressedSize(mt.length);
            CRC32 crc = new CRC32();
            crc.update(mt);
            me.setCrc(crc.getValue());
            z.putNextEntry(me);
            z.write(mt);
            z.closeEntry();
            putText(z, "META-INF/container.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + "<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\"><rootfiles>"
                    + "<rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles></container>");
            // capítulos de 60 párrafos
            int per = 60, chapters = Math.max(1, (d.paras.size() + per - 1) / per);
            StringBuilder manifest = new StringBuilder(), spine = new StringBuilder(), nav = new StringBuilder(), ncx = new StringBuilder();
            for (int c = 0; c < chapters; c++) {
                String file = "cap" + (c + 1) + ".xhtml";
                StringBuilder x = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE html>\n"
                        + "<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"es\"><head><title>" + esc(d.title) + "</title></head><body>");
                if (c == 0) x.append("<h1>").append(esc(d.title)).append("</h1>");
                for (int i = c * per; i < Math.min(d.paras.size(), (c + 1) * per); i++)
                    x.append("<p>").append(esc(d.paras.get(i)).replace("\n", "<br/>")).append("</p>");
                x.append("</body></html>");
                putText(z, "OEBPS/" + file, x.toString());
                manifest.append("<item id=\"c").append(c + 1).append("\" href=\"").append(file).append("\" media-type=\"application/xhtml+xml\"/>");
                spine.append("<itemref idref=\"c").append(c + 1).append("\"/>");
                nav.append("<li><a href=\"").append(file).append("\">Parte ").append(c + 1).append("</a></li>");
                ncx.append("<navPoint id=\"n").append(c + 1).append("\" playOrder=\"").append(c + 1).append("\"><navLabel><text>Parte ")
                        .append(c + 1).append("</text></navLabel><content src=\"").append(file).append("\"/></navPoint>");
            }
            putText(z, "OEBPS/nav.xhtml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE html>\n"
                    + "<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\"><head><title>Índice</title></head><body>"
                    + "<nav epub:type=\"toc\"><ol>" + nav + "</ol></nav></body></html>");
            putText(z, "OEBPS/toc.ncx", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + "<ncx xmlns=\"http://www.daisy.org/z3986/2005/ncx/\" version=\"2005-1\"><head><meta name=\"dtb:uid\" content=\"sss-" + Math.abs(d.title.hashCode()) + "\"/></head>"
                    + "<docTitle><text>" + esc(d.title) + "</text></docTitle><navMap>" + ncx + "</navMap></ncx>");
            putText(z, "OEBPS/content.opf", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + "<package xmlns=\"http://www.idpf.org/2007/opf\" version=\"3.0\" unique-identifier=\"uid\">"
                    + "<metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:identifier id=\"uid\">sss-" + Math.abs(d.title.hashCode()) + "</dc:identifier>"
                    + "<dc:title>" + esc(d.title) + "</dc:title><dc:language>es</dc:language>"
                    + "<meta property=\"dcterms:modified\">2026-01-01T00:00:00Z</meta></metadata>"
                    + "<manifest><item id=\"nav\" href=\"nav.xhtml\" media-type=\"application/xhtml+xml\" properties=\"nav\"/>"
                    + "<item id=\"ncx\" href=\"toc.ncx\" media-type=\"application/x-dtbncx+xml\"/>" + manifest + "</manifest>"
                    + "<spine toc=\"ncx\">" + spine + "</spine></package>");
        }
    }
}
