package com.aplauso.encuentra;

import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import com.google.mediapipe.tasks.genai.llminference.LlmInference;

import java.io.File;

/**
 * Cerebro de Chloe DENTRO del teléfono (v1.1): sin internet, sin cupos y gratis para siempre.
 * Modelo Qwen2.5 1.5B Instruct (Apache 2.0, de litert-community), ≈1,6 GB, que se descarga una vez.
 * Funciona con MediaPipe LLM Inference de Google. Bloquea: llamar desde un hilo.
 */
public class LocalBrain {
    static final String FILE = "chloe-qwen2.5-1.5b.task";
    static final String URL = "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/"
            + "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task";
    static final long SIZE_MIN = 1_000_000_000L;      // si el archivo pesa menos, está incompleto
    /** El modelo admite 1280 fichas en total (pregunta + respuesta): hay que ser breve. */
    static final int MAX_TOKENS = 1280;

    static LlmInference llm;
    static volatile String loadError = "";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static File file(Context c) { return new File(c.getExternalFilesDir(null), FILE); }
    static boolean ready(Context c) {
        File f = file(c);
        return f.exists() && f.length() > SIZE_MIN && status(c) == null;
    }

    // ---------------- descarga (sigue aunque cierres la app) ----------------
    static void startDownload(Context c) {
        DownloadManager dm = c.getSystemService(DownloadManager.class);
        long old = prefs(c).getLong("llm_dl", -1);
        if (old >= 0) {
            long[] st = status(c);
            if (st != null && (st[0] == DownloadManager.STATUS_RUNNING || st[0] == DownloadManager.STATUS_PENDING
                    || st[0] == DownloadManager.STATUS_PAUSED)) return;
            dm.remove(old);
        }
        File f = file(c);
        if (f.exists()) f.delete();
        DownloadManager.Request r = new DownloadManager.Request(Uri.parse(URL))
                .setTitle(L.t("Cerebro de Chloe (SSS+)"))
                .setDescription(L.t("Modelo de IA para usar sin internet · 1,6 GB"))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationUri(Uri.fromFile(f))
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false);
        prefs(c).edit().putLong("llm_dl", dm.enqueue(r)).apply();
    }

    /** {estado, MB bajados, MB totales} mientras hay una descarga sin terminar; null si no hay. */
    static long[] status(Context c) {
        long id = prefs(c).getLong("llm_dl", -1);
        if (id < 0) return null;
        DownloadManager dm = c.getSystemService(DownloadManager.class);
        try (android.database.Cursor k = dm.query(new DownloadManager.Query().setFilterById(id))) {
            if (k == null || !k.moveToFirst()) { prefs(c).edit().remove("llm_dl").apply(); return null; }
            int st = k.getInt(k.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            if (st == DownloadManager.STATUS_SUCCESSFUL) { prefs(c).edit().remove("llm_dl").apply(); return null; }
            long got = k.getLong(k.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            long tot = k.getLong(k.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            return new long[]{st, got >> 20, tot >> 20};
        } catch (Exception e) {
            return null;
        }
    }

    static String progress(Context c) {
        long[] st = status(c);
        if (st == null) return ready(c) ? L.t("✓ Cerebro descargado. Chloe ya piensa sin internet y sin cupos.") : L.t("Aún no está descargado.");
        if (st[0] == DownloadManager.STATUS_FAILED) return L.t("La descarga falló. Vuelve a pulsar DESCARGAR.");
        String mb = st[1] + " / " + (st[2] > 0 ? st[2] + " MB" : "? MB");
        int pc = st[2] > 0 ? (int) (st[1] * 100 / st[2]) : 0;
        if (st[0] == DownloadManager.STATUS_PAUSED) return L.t("Descarga en pausa (esperando wifi o conexión)… ") + mb;
        return L.t("Descargando el cerebro… ") + mb + "  " + pc + " % · " + L.t("puedes salir de la app, sigue sola");
    }

    static void delete(Context c) {
        close();
        long id = prefs(c).getLong("llm_dl", -1);
        if (id >= 0) c.getSystemService(DownloadManager.class).remove(id);
        prefs(c).edit().remove("llm_dl").apply();
        file(c).delete();
    }

    // ---------------- pensar ----------------
    static synchronized boolean load(Context c) {
        if (llm != null) return true;
        if (!ready(c)) return false;
        try {
            LlmInference.LlmInferenceOptions.Builder b = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(file(c).getAbsolutePath())
                    .setMaxTokens(MAX_TOKENS);
            gpu(b);
            llm = LlmInference.createFromOptions(c.getApplicationContext(), b.build());
            loadError = "";
            return true;
        } catch (Throwable e) {
            loadError = String.valueOf(e.getMessage());
            llm = null;
            return false;
        }
    }

    /** Usa la gráfica del teléfono si esta versión de MediaPipe lo permite (mucho más rápido). */
    static void gpu(LlmInference.LlmInferenceOptions.Builder b) {
        try {
            Class<?> be = Class.forName("com.google.mediapipe.tasks.genai.llminference.LlmInference$Backend");
            Object g = null;
            for (Object o : be.getEnumConstants()) if (o.toString().equals("GPU")) g = o;
            if (g != null) b.getClass().getMethod("setPreferredBackend", be).invoke(b, g);
        } catch (Throwable ignored) {}
    }

    static synchronized void close() {
        try { if (llm != null) llm.close(); } catch (Throwable ignored) {}
        llm = null;
    }

    /** Responde con el formato de chat de Qwen. null si no se pudo. */
    static synchronized String generate(Context c, String system, java.util.List<String[]> hist, String user) throws Exception {
        if (!load(c)) throw new Exception(loadError.isEmpty() ? L.t("el cerebro no está descargado") : loadError);
        StringBuilder p = new StringBuilder();
        p.append("<|im_start|>system\n").append(system).append("<|im_end|>\n");
        // solo lo último de la conversación: el modelo tiene poco espacio
        int from = Math.max(0, hist.size() - 4);
        for (int i = from; i < hist.size(); i++) {
            String[] h = hist.get(i);
            String t = Brain.speech(h[1]);
            if (t.length() > 300) t = t.substring(0, 300);
            p.append("<|im_start|>").append(h[0].equals("model") ? "assistant" : "user").append('\n').append(t).append("<|im_end|>\n");
        }
        p.append("<|im_start|>user\n").append(user).append("<|im_end|>\n<|im_start|>assistant\n");
        String out = llm.generateResponse(p.toString());
        if (out == null) return null;
        int end = out.indexOf("<|im_end|>");
        if (end >= 0) out = out.substring(0, end);
        return out.replace("<|im_start|>", "").replace("assistant\n", "").trim();
    }
}
