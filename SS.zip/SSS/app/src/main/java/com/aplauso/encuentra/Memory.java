package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/**
 * Memoria del asistente (v1.1): cosas que tú le enseñas. Se guardan solo en el teléfono y se le pasan al
 * cerebro en cada pregunta. «Recuerda que…» añade, «olvida…» quita, «¿qué recuerdas?» las dice.
 * También se ven, añaden y borran a mano en la pantalla del asistente.
 */
public class Memory {
    static final int MAX = 200;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    static synchronized List<String> all(Context c) {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("ai_memory", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getString(i));
        } catch (Exception ignored) {}
        return out;
    }

    static synchronized void save(Context c, List<String> l) {
        JSONArray a = new JSONArray();
        for (String s : l) a.put(s);
        prefs(c).edit().putString("ai_memory", a.toString()).apply();
    }

    static synchronized boolean add(Context c, String fact) {
        fact = fact.trim();
        if (fact.isEmpty()) return false;
        fact = Character.toUpperCase(fact.charAt(0)) + fact.substring(1);
        List<String> l = all(c);
        for (String s : l) if (Actions.norm(s).equals(Actions.norm(fact))) return false;
        l.add(fact);
        if (l.size() > MAX) return false;
        save(c, l);
        return true;
    }

    static synchronized void remove(Context c, int i) {
        List<String> l = all(c);
        if (i >= 0 && i < l.size()) { l.remove(i); save(c, l); }
    }

    /** Quita los recuerdos que contengan esas palabras. Devuelve cuántos quitó. */
    static synchronized int forget(Context c, String what) {
        String w = Actions.norm(what).replaceAll("^(?:que |lo de |lo que |eso de |el |la |los |las |mi |mis )+", "");
        if (w.isEmpty()) return 0;
        List<String> l = all(c), keep = new ArrayList<>();
        int n = 0;
        for (String s : l) { if (Actions.norm(s).contains(w)) n++; else keep.add(s); }
        if (n > 0) save(c, keep);
        return n;
    }

    /** Texto para el cerebro. */
    static String forPrompt(Context c) {
        List<String> l = all(c);
        String name = prefs(c).getString("ai_name", "").trim();
        if (l.isEmpty() && name.isEmpty()) return "";
        StringBuilder b = new StringBuilder("\nLO QUE SABES DEL USUARIO (te lo enseñó él, escrito en primera persona desde su punto de vista; úsalo cuando venga a cuento, no lo repitas sin motivo):\n");
        if (!name.isEmpty()) b.append("- Se llama ").append(name).append(".\n");
        for (String s : l) b.append("- ").append(s).append('\n');
        return b.toString();
    }

    /** Órdenes de memoria por voz. null si no es una. */
    static String handle(Context c, String said) {
        String s = Actions.norm(said);
        java.util.regex.Matcher k;
        if ((k = Actions.m("^(?:recuerda|recuerdalo|apuntate|apunta|aprende|aprendete|memoriza|guarda en tu memoria|remember|ricorda)(?: que| esto| lo siguiente|:)?\\s+(.+)$", s)) != null) {
            // se guarda tal cual lo dijiste (con tildes), quitando solo el principio
            String raw = said.trim().replaceFirst("(?i)^\\s*\\S+(?:\\s+(?:que|esto|lo siguiente|en tu memoria))?[:,]?\\s+", "");
            if (all(c).size() >= MAX) return L.t("Mi memoria está llena. Borra algún recuerdo en la pantalla del asistente y vuelve a pedírmelo.");
            boolean ok = add(c, raw.isEmpty() ? k.group(1) : raw);
            int n = all(c).size();
            return (ok ? L.t("Apuntado. Me acordaré de que ") + raw + "." : L.t("Eso ya lo sabía."))
                    + (n >= MAX - 20 ? " " + L.t("Ojo: me quedan") + " " + (MAX - n) + " " + L.t("recuerdos libres.") : "");
        }
        if ((k = Actions.m("^(?:olvida|olvidate de|borra de tu memoria|forget|dimentica)(?: que)?\\s+(.+)$", s)) != null) {
            if (k.group(1).matches("^(?:todo|todo lo que sabes|toda tu memoria|everything|tutto)$")) { save(c, new ArrayList<>()); return L.t("Hecho, he borrado toda mi memoria."); }
            int n = forget(c, k.group(1));
            return n > 0 ? L.t("Olvidado.") : L.t("No tenía nada apuntado sobre eso.");
        }
        if (Actions.m("^(?:que recuerdas|que sabes de mi|que tienes en tu memoria|que te he ensenado|what do you remember|cosa ricordi)", s) != null) {
            List<String> l = all(c);
            if (l.isEmpty()) return L.t("Aún no me has enseñado nada. Dime «recuerda que…» y lo apunto.");
            StringBuilder b = new StringBuilder(L.t("Esto es lo que recuerdo: "));
            for (int i = 0; i < l.size(); i++) b.append(i == 0 ? "" : "; ").append(l.get(i));
            return b.append('.').toString();
        }
        return null;
    }
}
