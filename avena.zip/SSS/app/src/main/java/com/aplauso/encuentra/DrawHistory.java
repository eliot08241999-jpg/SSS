package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * v1.7.4 · HISTORIAL DEL ESTUDIO: cada dibujo se guarda dentro de la app 24 horas. Si no lo guardas en la galería
 * ni lo fijas (📌), a las 24 h se borra solo. También puedes borrarlo antes.
 */
public class DrawHistory {
    static final long TTL = 24L * 3600 * 1000;

    public static final class Item {
        public String id, prompt = "", model = "";
        public long seed, created;
        public boolean pinned, saved;
        File png(Context c) { return new File(dir(c), id + ".png"); }
        File meta(Context c) { return new File(dir(c), id + ".json"); }
        /** Milisegundos que le quedan (o -1 si está fijado). */
        long left() { return pinned ? -1 : Math.max(0, created + TTL - System.currentTimeMillis()); }
    }

    static File dir(Context c) { File d = new File(c.getFilesDir(), "draw_history"); d.mkdirs(); return d; }

    static synchronized Item add(Context c, Bitmap b, SdEngine.Job j) {
        Item it = new Item();
        it.created = System.currentTimeMillis();
        it.id = Long.toString(it.created, 36) + Integer.toString((int) (Math.random() * 1296), 36);
        it.prompt = j == null ? "" : j.prompt;
        it.model = j == null ? "" : j.model;
        it.seed = j == null ? -1 : j.seed;
        try (FileOutputStream os = new FileOutputStream(it.png(c))) { b.compress(Bitmap.CompressFormat.PNG, 100, os); }
        catch (Exception e) { return null; }
        write(c, it);
        return it;
    }

    static void write(Context c, Item it) {
        try {
            JSONObject o = new JSONObject().put("id", it.id).put("prompt", it.prompt).put("model", it.model).put("seed", it.seed)
                    .put("created", it.created).put("pinned", it.pinned).put("saved", it.saved);
            java.nio.file.Files.write(it.meta(c).toPath(), o.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
    }

    /** Todos (los más nuevos primero), borrando antes los caducados. */
    static synchronized List<Item> all(Context c) {
        cleanup(c);
        List<Item> out = new ArrayList<>();
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".json"));
        if (fs != null) for (File f : fs) {
            try {
                JSONObject o = new JSONObject(new String(java.nio.file.Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
                Item it = new Item();
                it.id = o.getString("id"); it.prompt = o.optString("prompt"); it.model = o.optString("model");
                it.seed = o.optLong("seed", -1); it.created = o.optLong("created"); it.pinned = o.optBoolean("pinned"); it.saved = o.optBoolean("saved");
                if (it.png(c).exists()) out.add(it); else f.delete();
            } catch (Exception e) { f.delete(); }
        }
        out.sort((a, b) -> Long.compare(b.created, a.created));
        return out;
    }

    /** Borra lo que lleva más de 24 h sin fijar. */
    static synchronized int cleanup(Context c) {
        int n = 0;
        File[] fs = dir(c).listFiles((d, nm) -> nm.endsWith(".json"));
        if (fs == null) return 0;
        for (File f : fs) {
            try {
                JSONObject o = new JSONObject(new String(java.nio.file.Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
                if (!o.optBoolean("pinned") && System.currentTimeMillis() - o.optLong("created") > TTL) {
                    new File(dir(c), o.getString("id") + ".png").delete();
                    f.delete();
                    n++;
                }
            } catch (Exception e) { f.delete(); }
        }
        return n;
    }

    static Bitmap load(Context c, Item it, int maxSide) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            if (maxSide > 0) {
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(it.png(c).getPath(), o);
                int s = 1;
                while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2;
                o = new BitmapFactory.Options();
                o.inSampleSize = s;
            }
            return BitmapFactory.decodeFile(it.png(c).getPath(), o);
        } catch (Throwable e) { return null; }
    }

    static void delete(Context c, Item it) { it.png(c).delete(); it.meta(c).delete(); }
    static void pin(Context c, Item it, boolean on) { it.pinned = on; write(c, it); }

    /** A la galería (Imágenes/SSS+). */
    static boolean toGallery(Context c, Item it) {
        Bitmap b = load(c, it, 0);
        if (b == null) return false;
        boolean ok = DrawService.saveToGallery(c, b);
        if (ok) { it.saved = true; write(c, it); }
        return ok;
    }

    static String leftText(Item it) {
        if (it.pinned) return "📌";
        long ms = it.left();
        long h = ms / 3_600_000L, m = (ms / 60_000L) % 60;
        return "⏳ " + (h > 0 ? h + " h" : m + " min");
    }
}
