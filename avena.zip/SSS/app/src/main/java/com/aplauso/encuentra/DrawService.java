package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.MediaStore;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * v1.7.3 · DIBUJAR EN SEGUNDO PLANO (y varias imágenes de una vez). El Estudio le pasa el trabajo y este servicio dibuja
 * aunque salgas de la app o apagues la pantalla: notificación con el progreso y, al acabar, un aviso. Cada imagen se guarda
 * sola en Imágenes/SSS+ (así no se pierde nada si cierras la app).
 */
public class DrawService extends Service {
    public interface Listener { void update(); }

    static volatile boolean running;
    static volatile SdEngine.Job job;              // el trabajo que se está dibujando ahora
    static SdEngine.Job template;
    static volatile int count = 1, index = 0;
    static volatile String status = "", error = "";
    static volatile Bitmap preview;
    static final List<Bitmap> results = new ArrayList<>();
    static final List<Long> seeds = new ArrayList<>();
    static volatile boolean cancelAll;
    static Listener listener;

    static String ch, chDone;
    NotificationManager nm;
    PowerManager.WakeLock wl;

    /** Empieza (desde el Estudio). */
    static void start(Context c, SdEngine.Job t, int n) {
        template = t;
        count = Math.max(1, Math.min(8, n));
        index = 0;
        cancelAll = false;
        error = "";
        status = L.t("Preparando…");
        synchronized (results) { results.clear(); seeds.clear(); }
        running = true;
        Intent i = new Intent(c, DrawService.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void stop() {
        cancelAll = true;
        SdEngine.Job j = job;
        if (j != null) j.cancel = true;
    }

    static void tell() { Listener l = listener; if (l != null) try { l.update(); } catch (Exception ignored) {} }

    @Override public IBinder onBind(Intent i) { return null; }

    Notification progress(String text, int pc) {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, DrawStudioActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, ch);
        return b.setSmallIcon(android.R.drawable.ic_menu_gallery).setContentTitle(L.t("Dibujando") + (count > 1 ? " " + (index + 1) + "/" + count : "") + " · Chloe Nova")
                .setContentText(text).setProgress(100, Math.max(0, pc), pc < 0).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi).build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        nm = getSystemService(NotificationManager.class);
        ch = Notif.ch(this, "draw", L.t("Estudio de dibujo"), NotificationManager.IMPORTANCE_LOW);
        // el aviso de «¡listo!» va en un canal normal (suena), aunque las fijas sean discretas
        android.app.NotificationChannel done = new android.app.NotificationChannel("draw_done", L.t("Dibujos terminados"), NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(done);
        chDone = "draw_done";
        Notification n = progress(L.t("Preparando…"), -1);
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(61, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(61, n);
        if (template == null || job != null) { if (job == null) { running = false; stopSelf(); } return START_NOT_STICKY; }
        wl = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sss:draw");
        wl.acquire(6L * 3600 * 1000);
        final SdEngine.Job t = template;
        new Thread(() -> {
            int saved = 0;
            try {
                for (index = 0; index < count && !cancelAll; index++) {
                    SdEngine.Job j = copy(t);
                    // con semilla fija: semilla, semilla+1, semilla+2… (variaciones que se pueden repetir)
                    if (t.seed >= 0) j.seed = t.seed + index;
                    job = j;
                    final long[] lastN = {0};
                    Bitmap out = SdEngine.generate(this, j, (step, msg, prev) -> {
                        status = (count > 1 ? (index + 1) + "/" + count + " · " : "") + msg;
                        if (prev != null) preview = prev;
                        long now = System.currentTimeMillis();
                        if (now - lastN[0] > 1500) {
                            lastN[0] = now;
                            int pc = step < 0 ? -1 : (int) (100L * step / Math.max(1, j.steps));
                            nm.notify(61, progress(msg, pc));
                        }
                        tell();
                    });
                    if (out == null) break;                      // parado
                    synchronized (results) { results.add(out); seeds.add(j.seed); }
                    if (DrawHistory.add(this, out, j) != null) saved++;        // v1.7.4: al historial (24 h)
                    tell();
                }
                status = cancelAll ? L.t("Parado.") : (count > 1 ? L.t("¡Hechas!") + " " + saved + " " + L.t("imágenes en el historial (24 h).")
                        : L.t("¡Hecho! Está en el historial 24 h: pulsa GUARDAR o 📌 para quedártela."));
            } catch (OutOfMemoryError e) {
                error = L.t("No hay memoria suficiente: cierra otras apps o usa el tamaño «Rápida».");
                SdEngine.unload();
            } catch (Throwable e) {
                error = L.t("No he podido dibujar: ") + e.getMessage();
                SdEngine.unload();
            } finally {
                job = null;
                running = false;
                if (wl != null && wl.isHeld()) wl.release();
                stopForeground(true);
                if (!cancelAll || saved > 0) {
                    PendingIntent pi = PendingIntent.getActivity(this, 1, new Intent(this, DrawStudioActivity.class), PendingIntent.FLAG_IMMUTABLE);
                    Notification.Builder b = new Notification.Builder(this, chDone)
                            .setSmallIcon(android.R.drawable.ic_menu_gallery)
                            .setContentTitle(error.isEmpty() ? "✨ " + (saved > 1 ? saved + " " + L.t("dibujos listos") : L.t("Tu dibujo está listo")) : L.t("Estudio de dibujo"))
                            .setContentText(error.isEmpty() ? L.t("Toca para verlos. Están en el historial 24 h: guarda o fija los que quieras.") : error)
                            .setAutoCancel(true).setContentIntent(pi);
                    Bitmap last;
                    synchronized (results) { last = results.isEmpty() ? null : results.get(results.size() - 1); }
                    if (last != null) b.setLargeIcon(last).setStyle(new Notification.BigPictureStyle().bigPicture(last));
                    nm.notify(62, b.build());
                }
                tell();
                stopSelf();
            }
        }, "dibujar").start();
        return START_NOT_STICKY;
    }

    static SdEngine.Job copy(SdEngine.Job t) {
        SdEngine.Job j = new SdEngine.Job();
        j.model = t.model; j.prompt = t.prompt; j.negative = t.negative;
        j.width = t.width; j.height = t.height; j.steps = t.steps; j.cfg = t.cfg; j.strength = t.strength;
        j.init = t.init; j.seed = t.seed;
        return j;
    }

    static boolean saveToGallery(Context c, Bitmap b) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "SSS_dibujo_" + System.currentTimeMillis() + ".png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (android.os.Build.VERSION.SDK_INT >= 29) v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SSS+");
            Uri u = c.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            try (OutputStream os = c.getContentResolver().openOutputStream(u)) { b.compress(Bitmap.CompressFormat.PNG, 100, os); }
            return true;
        } catch (Exception e) { return false; }
    }
}
