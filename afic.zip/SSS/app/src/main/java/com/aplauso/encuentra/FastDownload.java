package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;

/**
 * v1.3.2 · Descarga RÁPIDA de los modelos del Estudio de dibujo: cada archivo grande se baja a trozos de 8 MB
 * por 8 conexiones a la vez (el gestor de descargas de Android usa una sola y va lentísimo).
 * Va en un servicio con notificación, así sigue aunque salgas de la app. Si se corta, continúa donde iba.
 */
public class FastDownload extends Service {
    static final int THREADS = 8;
    static final long CHUNK = 8L << 20;

    static volatile String runningId, lastId;
    static volatile boolean cancel;
    static volatile String error = "";
    static final AtomicLong got = new AtomicLong();
    static volatile long total;
    static volatile long startTime, startGot;

    static boolean running(String id) { return id != null && id.equals(runningId); }

    static void start(Context c, String id) {
        if (runningId != null) return;
        Intent i = new Intent(c, FastDownload.class).putExtra("id", id);
        if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void stop() { cancel = true; }

    /** MB/s desde que empezó. */
    static double speed() {
        long el = System.currentTimeMillis() - startTime;
        return el < 1500 ? 0 : (got.get() - startGot) / 1048576.0 / (el / 1000.0);
    }

    @Override public IBinder onBind(Intent i) { return null; }

    NotificationManager nm;

    Notification notif(String text, int pc) {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, DrawStudioActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "descargas") : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle(L.t("Estudio de dibujo (SSS+)"))
                .setContentText(text).setProgress(100, Math.max(0, pc), pc < 0).setOngoing(true).setContentIntent(pi).build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        inst = this;
        nm = getSystemService(NotificationManager.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel("descargas", "Descargas SSS+", NotificationManager.IMPORTANCE_LOW));
        Notification n = notif(L.t("Preparando la descarga…"), -1);
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(31, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(31, n);
        String id = intent == null ? null : intent.getStringExtra("id");
        if (id == null || runningId != null) { if (runningId == null) stopSelf(); return START_NOT_STICKY; }
        runningId = id;
        lastId = id;
        cancel = false;
        error = "";
        got.set(0);
        total = 0;
        new Thread(() -> {
            android.os.PowerManager.WakeLock wl = getSystemService(android.os.PowerManager.class)
                    .newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "sss:descarga");
            wl.acquire(3 * 60 * 60 * 1000L);
            android.net.wifi.WifiManager.WifiLock wf = null;
            try {
                wf = ((android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE))
                        .createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF, "sss:descarga");
                wf.acquire();
            } catch (Exception ignored) {}
            try { run(id); } catch (Exception e) { error = e.getMessage() == null ? e.toString() : e.getMessage(); }
            finally {
                wl.release();
                if (wf != null) try { wf.release(); } catch (Exception ignored) {}
                runningId = null;
                stopForeground(true);
                stopSelf();
            }
        }, "descarga-modelo").start();
        return START_NOT_STICKY;
    }

    String base(String id) { return "https://huggingface.co/" + SdEngine.model(id)[3] + "/resolve/main/"; }

    void run(String id) throws Exception {
        File d = SdEngine.dir(this, id);
        // fase 1: los archivos fijos; fase 2: los pesos aparte que piden los .onnx
        for (int phase = 0; phase < 3 && !cancel; phase++) {
            List<String> todo = new ArrayList<>();
            for (String f : SdEngine.needed(this, id)) if (!complete(new File(d, f))) todo.add(f);
            if (todo.isEmpty()) break;
            // tamaños
            long[] sizes = new long[todo.size()];
            String[] urls = new String[todo.size()];
            total = 0;
            got.set(0);
            for (int i = 0; i < todo.size(); i++) {
                long[] sz = new long[1];
                urls[i] = resolve(base(id) + todo.get(i).replace(" ", "%20"), sz);
                sizes[i] = sz[0];
                total += Math.max(0, sz[0]);
                got.addAndGet(doneBytes(new File(d, todo.get(i)), sz[0]));
            }
            startTime = System.currentTimeMillis();
            startGot = got.get();
            for (int i = 0; i < todo.size() && !cancel; i++) fetch(base(id) + todo.get(i).replace(" ", "%20"), urls[i], new File(d, todo.get(i)), sizes[i]);
        }
        if (cancel) { error = ""; return; }
        SdEngine.prefs(this).edit().remove("sd_ok_" + id).apply();
        if (!SdEngine.ready(this, id)) error = L.t("Faltan archivos del modelo. Vuelve a pulsar DESCARGAR.");
        else {
            nm.notify(32, new Notification.Builder(this, "descargas").setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle(L.t("Estudio de dibujo (SSS+)")).setContentText(SdEngine.model(id)[1] + " · " + L.t("¡listo para dibujar!"))
                    .setAutoCancel(true).setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, DrawStudioActivity.class), PendingIntent.FLAG_IMMUTABLE)).build());
        }
    }

    /** Sigue las redirecciones de Hugging Face y devuelve la URL final; en size[0] el tamaño (o -1). */
    static String resolve(String url, long[] size) throws Exception {
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("Range", "bytes=0-0");
            c.setRequestProperty("User-Agent", "SSS-plus/1.3");
            c.setConnectTimeout(20000);
            c.setReadTimeout(30000);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                url = new URL(new URL(url), loc).toString();
                continue;
            }
            if (code == 404) { c.disconnect(); throw new Exception(L.t("no existe en el servidor: ") + url.substring(url.lastIndexOf("/main/") + 6)); }
            String cr = c.getHeaderField("Content-Range");
            size[0] = cr != null && cr.contains("/") ? Long.parseLong(cr.substring(cr.indexOf('/') + 1).trim()) : c.getContentLengthLong();
            if (code == 200) size[0] = -size[0] - 1;            // el servidor no admite trozos: se baja de una vez
            c.disconnect();
            return url;
        }
        throw new Exception(L.t("demasiadas redirecciones"));
    }

    static File parts(File f) { return new File(f.getPath() + ".parts"); }

    static boolean complete(File f) { return f.exists() && f.length() > 0 && !parts(f).exists(); }

    /** Bytes ya bajados de un archivo a medias (según su .parts). */
    static long doneBytes(File f, long size) {
        if (complete(f)) return Math.max(0, size);
        File p = parts(f);
        if (!p.exists() || size <= 0) return 0;
        try {
            String s = new String(java.nio.file.Files.readAllBytes(p.toPath()));
            long n = 0;
            for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '1') n += CHUNK;
            return Math.min(n, size);
        } catch (Exception e) { return 0; }
    }

    static FastDownload inst;

    static void fetch(String orig, String url0, File out, long size) throws Exception {
        final String[] cur = {url0};
        String url = url0;
        out.getParentFile().mkdirs();
        if (size < 0) {                                   // sin trozos
            File tmp = new File(out.getPath() + ".tmp");
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            try (InputStream in = c.getInputStream(); java.io.FileOutputStream fo = new java.io.FileOutputStream(tmp)) {
                byte[] b = new byte[1 << 16]; int k;
                while ((k = in.read(b)) > 0) { if (cancel) return; fo.write(b, 0, k); got.addAndGet(k); }
            }
            tmp.renameTo(out);
            return;
        }
        int n = (int) ((size + CHUNK - 1) / CHUNK);
        File pf = parts(out);
        char[] done = new char[n];
        java.util.Arrays.fill(done, '0');
        if (pf.exists() && out.exists()) {
            String s = new String(java.nio.file.Files.readAllBytes(pf.toPath()));
            if (s.length() == n) done = s.toCharArray();
        } else {
            if (out.exists()) out.delete();
            try (RandomAccessFile r = new RandomAccessFile(out, "rw")) { r.setLength(size); }
            java.nio.file.Files.write(pf.toPath(), new String(done).getBytes());
        }
        ConcurrentLinkedQueue<Integer> q = new ConcurrentLinkedQueue<>();
        for (int i = 0; i < n; i++) if (done[i] != '1') q.add(i);
        final char[] state = done;
        final Exception[] fail = new Exception[1];
        List<Thread> ts = new ArrayList<>();
        for (int t = 0; t < Math.min(THREADS, q.size()); t++) {
            Thread th = new Thread(() -> {
                Integer ci;
                while (!cancel && fail[0] == null && (ci = q.poll()) != null) {
                    long from = ci * CHUNK, to = Math.min(size, from + CHUNK) - 1;
                    Exception last = null;
                    for (int tries = 0; tries < 5 && !cancel; tries++) {
                        long wrote = 0;
                        try {
                            HttpURLConnection c = (HttpURLConnection) new URL(cur[0]).openConnection();
                            c.setRequestProperty("Range", "bytes=" + from + "-" + to);
                            c.setConnectTimeout(20000);
                            c.setReadTimeout(30000);
                            int code = c.getResponseCode();
                            if (code == 403 || code == 410) {           // el enlace firmado caducó: se pide otro
                                synchronized (cur) { cur[0] = resolve(orig, new long[1]); }
                                throw new Exception("HTTP " + code);
                            }
                            if (code != 206) throw new Exception("HTTP " + code);
                            try (InputStream in = c.getInputStream(); RandomAccessFile r = new RandomAccessFile(out, "rw")) {
                                r.seek(from);
                                byte[] b = new byte[1 << 16]; int k;
                                while ((k = in.read(b)) > 0) { if (cancel) return; r.write(b, 0, k); wrote += k; got.addAndGet(k); }
                            }
                            if (wrote != to - from + 1) throw new Exception("corte");
                            synchronized (state) {
                                state[ci] = '1';
                                try { java.nio.file.Files.write(pf.toPath(), new String(state).getBytes()); } catch (Exception ignored) {}
                            }
                            last = null;
                            break;
                        } catch (Exception e) {
                            got.addAndGet(-wrote);
                            last = e;
                            try { Thread.sleep(1500L * (tries + 1)); } catch (InterruptedException ignored) {}
                        }
                    }
                    if (last != null) { fail[0] = last; return; }
                }
            }, "trozo");
            ts.add(th);
            th.start();
        }
        while (true) {
            boolean alive = false;
            for (Thread th : ts) if (th.isAlive()) alive = true;
            if (!alive) break;
            int pc = total > 0 ? (int) (got.get() * 100 / total) : -1;
            if (inst != null && inst.nm != null) inst.nm.notify(31, inst.notif((got.get() >> 20) + " / " + (total >> 20) + " MB · " + String.format(java.util.Locale.ROOT, "%.1f MB/s", speed()), pc));
            Thread.sleep(1000);
        }
        if (fail[0] != null) throw fail[0];
        if (!cancel) pf.delete();
    }
}
