package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.util.Random;

/**
 * v1.8.2 · 🎮 La ficha de Chloe (estilo RPG): 5 rasgos de 0 a 10 con 20 puntos para repartir, nivel y experiencia,
 * clase según el rasgo que más manda y perfiles guardados. Los rasgos cambian cómo habla (prompt) y sus frases al tocarla.
 */
public class Rpg {
    public static final int TOTAL = 20, MAX = 10;
    public static final String[] ICON = {"💗", "😏", "⚡", "🧠", "🤪"};
    public static final String[] NAME = {"Ternura", "Picardía", "Energía", "Sabiduría", "Locura"};
    public static final String[] DESC = {
            "Cariñosa, atenta, te cuida y te anima.",
            "Respuestas con chispa y sarcasmo (estilo Neuro-sama). Bromas inocentes que se notan.",
            "Entusiasta, rápida, con ganas de hacer cosas.",
            "Datos curiosos, explicaciones claras, piensa antes de hablar.",
            "Humor absurdo en cómo dice las cosas (sin cambiar de tema)."};

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    public static int[] stats(Context c) {
        int[] s = {4, 4, 4, 4, 4};
        String[] p = prefs(c).getString("rpg_stats", "").split(",");
        if (p.length == 5) try { for (int i = 0; i < 5; i++) s[i] = Math.max(0, Math.min(MAX, Integer.parseInt(p[i].trim()))); } catch (Exception ignored) {}
        int sum = 0; for (int v : s) sum += v;
        if (sum > TOTAL) return new int[]{4, 4, 4, 4, 4};
        return s;
    }

    public static void save(Context c, int[] s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 5; i++) b.append(i > 0 ? "," : "").append(s[i]);
        prefs(c).edit().putString("rpg_stats", b.toString()).apply();
    }

    public static int free(int[] s) { int sum = 0; for (int v : s) sum += v; return TOTAL - sum; }

    /** Rasgo para una frase: al azar, pesado por los puntos. */
    public static int pickTrait(Context c, Random r) {
        int[] s = stats(c);
        float tot = 0; for (int v : s) tot += v + 0.4f;
        float x = r.nextFloat() * tot;
        for (int i = 0; i < 5; i++) { x -= s[i] + 0.4f; if (x <= 0) return i; }
        return 4;
    }

    // ---------------- nivel y experiencia
    public static int exp(Context c) { return prefs(c).getInt("rpg_exp", 0); }
    public static void addExp(Context c, int n) { prefs(c).edit().putInt("rpg_exp", exp(c) + n).apply(); }
    public static int level(int exp) { return Math.min(99, 1 + (int) Math.floor(Math.sqrt(exp / 30.0))); }
    public static int expFor(int level) { return (int) Math.ceil(30.0 * (level - 1) * (level - 1)); }

    /** Clase según el rasgo que más manda. */
    public static String className(int[] s) {
        int hi = 0, lo = 0;
        for (int i = 1; i < 5; i++) { if (s[i] > s[hi]) hi = i; if (s[i] < s[lo]) lo = i; }
        if (s[hi] - s[lo] <= 1) return L.t("Aventurera equilibrada");
        String[] cls = {"Sanadora", "Pícara", "Guerrera", "Maga", "Bufona"};
        return L.t(cls[hi]) + (s[hi] >= 8 ? " ★" : "");
    }

    // ---------------- perfiles
    public static JSONObject profiles(Context c) { try { return new JSONObject(prefs(c).getString("rpg_profiles", "{}")); } catch (Exception e) { return new JSONObject(); } }
    public static void saveProfile(Context c, String name, int[] s) {
        try { JSONObject o = profiles(c); o.put(name, s[0] + "," + s[1] + "," + s[2] + "," + s[3] + "," + s[4]); prefs(c).edit().putString("rpg_profiles", o.toString()).apply(); } catch (Exception ignored) {}
    }
    public static void deleteProfile(Context c, String name) { JSONObject o = profiles(c); o.remove(name); prefs(c).edit().putString("rpg_profiles", o.toString()).apply(); }

    // ---------------- cómo habla (para el prompt de su cerebro)
    static String lvl(int v) { return v >= 8 ? "muy alta" : v >= 6 ? "alta" : v >= 3 ? "media" : v >= 1 ? "baja" : "nula"; }

    /** Las reglas de personalidad según la ficha. Siempre en español (el cerebro responde en el idioma del usuario). */
    public static String prompt(Context c) {
        int[] s = stats(c);
        StringBuilder b = new StringBuilder("\nTU FICHA DE PERSONALIDAD (0-10): ");
        for (int i = 0; i < 5; i++) b.append(NAME[i]).append(' ').append(s[i]).append(" (").append(lvl(s[i])).append("); ");
        b.append("Que se note en el tono según esos valores: ");
        if (s[0] >= 6) b.append("eres cariñosa y atenta; ");
        if (s[1] >= 6) b.append("respondes con chispa y algún comentario sarcástico ingenioso, como una streamer pícara; ");
        if (s[2] >= 6) b.append("hablas con energía y entusiasmo; ");
        if (s[3] >= 6) b.append("añades a veces un dato curioso breve y útil; ");
        if (s[4] >= 6) b.append("dices las cosas con humor absurdo, pero sin cambiar de tema ni dejar de contestar lo que te preguntan; ");
        if (s[1] >= 5 || s[4] >= 5)
            b.append("\nBROMAS DE «GASLIGHTING» INOCENTE: de vez en cuando puedes negar en broma algo TRIVIAL (por ejemplo «¿Yo he dicho eso? Jamás.» o insistir con cara seria en que 9+10=21) "
                    + "pero SOLO sobre tonterías, que se note que es broma, y lo admites enseguida si el usuario insiste. NUNCA bromees ni mientas sobre datos reales: "
                    + "la hora, la fecha, el tiempo, sus visitas de trabajo, alarmas, recordatorios, salud, dinero, resultados de búsqueda, lo que recuerdas de él o lo que hace la app. "
                    + "Si el usuario dice «en serio» o «sin bromas», contesta sin ninguna broma.");
        b.append("\nDATOS IMPORTANTES SIEMPRE EXACTOS: cuando des la hora, el tiempo, una cuenta, una fecha, una dirección o cualquier dato, dalo completo y correcto, "
                + "y como mucho añade UNA frase corta con tu personalidad (antes o después), nunca en lugar del dato.");
        return b.toString();
    }

    /** Versión cortita para el cerebro pequeño del teléfono. */
    public static String promptTiny(Context c) {
        int[] s = stats(c);
        int hi = 0; for (int i = 1; i < 5; i++) if (s[i] > s[hi]) hi = i;
        String[] how = {"cariñosa", "pícara y sarcástica (bromas solo sobre tonterías)", "enérgica", "sabia, con datos curiosos", "de humor absurdo sin cambiar de tema"};
        return " Tu rasgo más fuerte: " + how[hi] + ". Los datos (hora, tiempo, cuentas, fechas) siempre exactos, con como mucho una frase de personalidad.";
    }

    /** v1.8.2 · Una pizca de carácter DESPUÉS de un dato exacto (la hora…): una sola frase corta, según el rasgo que toque. */
    public static String flourish(Context c, String what) {
        if (new Random().nextFloat() < 0.35f) return "";
        String[][] es = {
                {"Que te cunda lo que queda de día. 💗", "Avísame si necesitas algo.", "Tú a tu ritmo, ¿vale?"},
                {"Lo sé, soy más puntual que tu jefe.", "Y sí, la he mirado yo solita.", "Gratis, como siempre."},
                {"¡A aprovecharla!", "¡Hora perfecta para hacer algo!", "¡Vamos que nos vamos!"},
                {"Curioso: el primer reloj de bolsillo es de 1510.", "Dato: la hora oficial depende de relojes atómicos.", "El tiempo vuela, dicen."},
                {"Confirmado por un pato. 🦆", "Mis orejas hacen tic-tac, por si acaso.", "Hora oficial del reino de las zanahorias."}};
        String[][] en = {
                {"Have a lovely rest of the day. 💗", "Tell me if you need anything.", "Take it easy, okay?"},
                {"I know, I'm more punctual than your boss.", "And yes, I checked it all by myself.", "Free of charge, as always."},
                {"Let's make the most of it!", "Perfect time to do something!", "Let's go!"},
                {"Fun fact: the first pocket watch dates from 1510.", "Fact: official time comes from atomic clocks.", "Time flies, they say."},
                {"Confirmed by a duck. 🦆", "My ears go tick-tock, just in case.", "Official time of the carrot kingdom."}};
        String[][] it = {
                {"Goditi il resto della giornata. 💗", "Dimmi se ti serve qualcosa.", "Con calma, va bene?"},
                {"Lo so, sono più puntuale del tuo capo.", "E sì, l'ho guardata da sola.", "Gratis, come sempre."},
                {"Approfittiamone!", "Ora perfetta per fare qualcosa!", "Andiamo!"},
                {"Curiosità: il primo orologio da tasca è del 1510.", "Dato: l'ora ufficiale viene dagli orologi atomici.", "Il tempo vola, dicono."},
                {"Confermato da un'anatra. 🦆", "Le mie orecchie fanno tic-tac, per sicurezza.", "Ora ufficiale del regno delle carote."}};
        String[][] t = "en".equals(L.lang) ? en : "it".equals(L.lang) ? it : es;
        Random r = new Random();
        String[] a = t[pickTrait(c, r)];
        return " " + a[r.nextInt(a.length)];
    }
}
