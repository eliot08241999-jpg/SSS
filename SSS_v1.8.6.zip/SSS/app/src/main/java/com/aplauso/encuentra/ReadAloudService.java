package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * v1.8 · Lectura de libros en segundo plano (con la pantalla apagada o en otra app), con notificación multimedia:
 * ⏮ ⏯ ⏭ y ⏹. Al parar con ⏹ pone una marca automática para seguir desde ahí la próxima vez.
 */
public class ReadAloudService extends Service {
    static final String CH = "read_aloud";
    static final int NID = 71;

    // estado compartido con el lector
    static volatile List<String> paras = new ArrayList<>();
    static volatile String title = "", key = "";
    static volatile Uri uri;
    static volatile int idx = -1;
    static volatile boolean running, playing;
    static volatile float rate = 1f;

    TextToSpeech tts;
    boolean ready;
    MediaSession session;

    /** Empieza (o cambia de libro). Los párrafos se pasan por memoria: un libro no cabe en un Intent. */
    static void start(Context c, Uri u, String k, String t, List<String> p, int from, float r) {
        paras = new ArrayList<>(p);
        uri = u; key = k; title = t; idx = Math.max(0, from); rate = r;
        Intent i = new Intent(c, ReadAloudService.class).setAction("play");
        if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void send(Context c, String action) { c.startService(new Intent(c, ReadAloudService.class).setAction(action)); }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH, L.t("Lectura en voz alta"), NotificationManager.IMPORTANCE_LOW));
        session = new MediaSession(this, "chloe-lector");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { jump(1); }
            @Override public void onSkipToPrevious() { jump(-1); }
            @Override public void onStop() { stopAndMark(); }
            @Override public void onSeekTo(long ms) { seekMs(ms); }
            @Override public void onCustomAction(String a, android.os.Bundle b) { if ("close".equals(a)) stopAndMark(); }
        });
        session.setActive(true);
        tts = new TextToSpeech(this, st -> {
            ready = st == TextToSpeech.SUCCESS;
            if (!ready) return;
            int r = tts.setLanguage(Locale.getDefault());
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(new Locale("es", "ES"));
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                public void onStart(String id) {}
                public void onDone(String id) { if (playing && ("p" + idx).equals(id)) { idx++; speak(); } }
                @Override public void onError(String id) { if (playing) { idx++; speak(); } }
            });
            if (playing && !chloeVoice()) speak();
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? "play" : String.valueOf(intent.getAction());
        if ("stop".equals(a) && !running) { stopSelf(); return START_NOT_STICKY; }
        running = true;
        if (!"toggle".equals(a) || !playing) startForegroundNow();
        switch (a) {
            case "play": playing = true; isEs = null; if (ready || chloeVoice()) speak(); break;
            case "toggle": if (playing) pause(); else resume(); break;
            case "next": jump(1); break;
            case "prev": jump(-1); break;
            case "stop": stopAndMark(); break;
            case "quiet": playing = false; if (tts != null) tts.stop(); kokoroStop(); finishService(); break;   // parar sin marca (desde el lector)
        }
        return START_NOT_STICKY;
    }

    void startForegroundNow() {
        Notification n = build();
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(NID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NID, n);
    }

    void speak() {
        if (idx >= paras.size()) { playing = false; mark(L.t("Fin del libro"), true); finishService(); return; }
        if (chloeVoice()) { kokoroFrom(idx); savePos(); update(); return; }      // v1.8.3 · 🐑 con la voz de Chloe
        if (!ready || tts == null) return;
        // v1.8.3: frase a frase, con pausas y un poco de entonación (preguntas, exclamaciones, diálogos): menos robótica
        tts.setSpeechRate(rate);
        java.util.List<String[]> parts = sentences(paras.get(idx));
        for (int i = 0; i < parts.size(); i++) {
            String t = parts.get(i)[0];
            boolean dlg = "d".equals(parts.get(i)[1]);
            float pitch = 1f + (dlg ? 0.08f : 0) + (t.trim().endsWith("?") ? 0.06f : t.trim().endsWith("!") ? 0.04f : 0);
            tts.setPitch(pitch);
            tts.setSpeechRate(rate * (dlg ? 1.04f : 1f));
            tts.speak(t, i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, i == parts.size() - 1 ? "p" + idx : "s" + idx + "_" + i);
            if (i < parts.size() - 1) tts.playSilentUtterance(t.trim().matches(".*[.!?…»”\"]$") ? 260 : 120, TextToSpeech.QUEUE_ADD, "z" + idx + "_" + i);
        }
        tts.setPitch(1f);
        savePos();
        update();
    }

    // =============================================================== v1.8.3 · 🐑 leer con la voz de Chloe
    /** Voz de Chloe (Kokoro) si la tienes y el libro está en español; si no, la del teléfono. */
    boolean chloeVoice() {
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        if (!p.getBoolean("rd_chloe", true) || !KokoroVoice.filesReady(this)) return false;
        return spanish();
    }

    Boolean isEs;
    boolean spanish() {
        if (isEs != null) return isEs;
        int es = 0, tot = 0;
        for (int i = 0; i < Math.min(40, paras.size()); i++) for (String w : paras.get(i).toLowerCase(Locale.ROOT).split("[^a-záéíóúñü]+")) {
            if (w.isEmpty()) continue;
            tot++;
            if (w.matches("el|la|los|las|de|que|y|en|un|una|es|por|con|para|se|no|su|al|lo|como|más|pero|sus|le|ya|o|fue|este|ha|sí|porque|esta|muy|sin|sobre|también|me|hasta|hay|donde|quien|desde|todo|nos|durante|ni|contra|ese|eso|había|él|ella")) es++;
        }
        isEs = tot == 0 || es * 100 / tot >= 18;
        return isEs;
    }

    /** Partes de un párrafo: {texto, "n" narración / "d" diálogo («…», "…", “…” o línea con raya). */
    static java.util.List<String[]> sentences(String para) {
        java.util.List<String[]> out = new java.util.ArrayList<>();
        String t = para.trim();
        boolean dashDialog = t.startsWith("—") || t.startsWith("–") || t.startsWith("- ");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("«[^»]+»|“[^”]+”|\"[^\"]+\"").matcher(t);
        int last = 0;
        while (m.find()) {
            if (m.start() > last) addSentences(out, t.substring(last, m.start()), dashDialog ? "d" : "n");
            addSentences(out, t.substring(m.start(), m.end()), "d");
            last = m.end();
        }
        if (last < t.length()) addSentences(out, t.substring(last), dashDialog ? "d" : "n");
        if (out.isEmpty()) out.add(new String[]{t, "n"});
        return out;
    }

    static void addSentences(java.util.List<String[]> out, String s, String kind) {
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            cur.append(c);
            if (".!?…".indexOf(c) >= 0 && (i + 1 >= s.length() || s.charAt(i + 1) == ' ') && cur.toString().trim().length() > 1) {
                out.add(new String[]{cur.toString().trim(), kind}); cur.setLength(0);
            }
        }
        if (cur.toString().trim().replaceAll("[\\p{Punct}«»“”—–\\s]", "").length() > 0) out.add(new String[]{cur.toString().trim(), kind});
    }

    // --- tubería propia: una hebra prepara el audio con antelación (≈ 3 frases) y otra lo va sonando; así no hay huecos
    static final class Piece { short[] pcm; int para; Piece(short[] p, int i) { pcm = p; para = i; } }
    volatile int kgen;
    volatile android.media.AudioTrack ktrack;
    final android.os.Handler main = new android.os.Handler(android.os.Looper.getMainLooper());

    void kokoroStop() {
        kgen++;
        android.media.AudioTrack t = ktrack;
        if (t != null) try { t.pause(); t.flush(); } catch (Exception ignored) {}
    }

    void kokoroFrom(int from) {
        kokoroStop();
        KokoroVoice.stop();                                    // que no hable a la vez en el chat
        final int my = ++kgen;
        final java.util.concurrent.LinkedBlockingQueue<Object> q = new java.util.concurrent.LinkedBlockingQueue<>(6);
        final Object END = new Object();
        final KokoroVoice.Cfg narr = new KokoroVoice.Cfg(this), dlg = new KokoroVoice.Cfg(this);
        narr.maxLen = dlg.maxLen = 240;                      // frases enteras: entonación más natural (empieza 1-2 s después)
        narr.quick = dlg.quick = false;
        narr.speed *= rate; dlg.speed *= rate * 1.05f;
        dlg.expr = Math.min(1f, narr.expr + 0.3f);            // los diálogos, con más vida
        final boolean voices = getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("rd_dialog", true);
        new Thread(() -> {
            try {
                KokoroVoice.load(this);
                java.util.Random rnd = new java.util.Random();
                for (int pi = from; pi < paras.size() && kgen == my; pi++) {
                    for (String[] part : sentences(paras.get(pi))) {
                        if (kgen != my) break;
                        KokoroVoice.Cfg g = voices && "d".equals(part[1]) ? dlg : narr;
                        for (KokoroText.Chunk ch : KokoroText.split(part[0], g.maxLen, false, g.expr, g.pause, rnd)) {
                            if (kgen != my) break;
                            float[] wav = KokoroVoice.make(g, ch);
                            int sil = (int) (Math.max(ch.pause, 0.18f) * VoiceFx.SR * narr.pitch);
                            short[] pcm = new short[wav.length + sil];
                            for (int i = 0; i < wav.length; i++) pcm[i] = (short) Math.max(-32767, Math.min(32767, Math.round(wav[i] * 32767)));
                            while (kgen == my && !q.offer(new Piece(pcm, pi), 200, java.util.concurrent.TimeUnit.MILLISECONDS)) { /* espera sitio */ }
                        }
                    }
                    // pausa entre párrafos (más larga tras un título corto)
                    String pt = paras.get(pi).trim();
                    float gap = pt.length() < 60 && !pt.endsWith(".") ? 1.1f : 0.55f;
                    short[] s0 = new short[(int) (gap * VoiceFx.SR * narr.pitch)];
                    while (kgen == my && !q.offer(new Piece(s0, pi), 200, java.util.concurrent.TimeUnit.MILLISECONDS)) { /* */ }
                }
            } catch (Throwable e) {
                main.post(() -> { if (kgen == my) { getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("rd_chloe", false).apply(); speak(); } });   // falla: voz del teléfono
                return;
            }
            try { while (kgen == my && !q.offer(END, 200, java.util.concurrent.TimeUnit.MILLISECONDS)) { /* */ } } catch (InterruptedException ignored) {}
        }, "lector-chloe-hacer").start();
        new Thread(() -> {
            android.media.AudioTrack tr = null;
            try {
                int sr = Math.round(VoiceFx.SR * narr.pitch);
                int min = android.media.AudioTrack.getMinBufferSize(sr, android.media.AudioFormat.CHANNEL_OUT_MONO, android.media.AudioFormat.ENCODING_PCM_16BIT);
                tr = new android.media.AudioTrack.Builder()
                        .setAudioAttributes(new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        .setAudioFormat(new android.media.AudioFormat.Builder().setSampleRate(sr).setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT).setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO).build())
                        .setBufferSizeInBytes(Math.max(min, sr)).setTransferMode(android.media.AudioTrack.MODE_STREAM).build();
                ktrack = tr;
                tr.play();
                while (kgen == my) {
                    Object o = q.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS);
                    if (o == null) continue;
                    if (o == END) {
                        long lim = System.currentTimeMillis() + 2500;
                        while (kgen == my && System.currentTimeMillis() < lim && tr.getPlaybackHeadPosition() > 0) { Thread.sleep(100); break; }
                        main.post(() -> { if (kgen == my) { idx = paras.size(); speak(); } });
                        break;
                    }
                    Piece pc = (Piece) o;
                    if (pc.para != idx) { final int np = pc.para; main.post(() -> { if (kgen == my) { idx = np; savePos(); update(); } }); }
                    for (int pp = 0; pp < pc.pcm.length && kgen == my; pp += 2048) {
                        int w = tr.write(pc.pcm, pp, Math.min(2048, pc.pcm.length - pp));
                        if (w < 0) throw new Exception("audio " + w);
                    }
                }
            } catch (Throwable ignored) {
            } finally {
                if (tr != null) { try { tr.pause(); tr.flush(); } catch (Exception ignored) {} try { tr.release(); } catch (Exception ignored) {} }
                if (ktrack == tr) ktrack = null;
            }
        }, "lector-chloe-sonar").start();
    }

    /** v1.8.2: en pausa guarda dónde ibas (marca automática) y la notificación se puede quitar deslizando o con ✕. */
    void pause() {
        playing = false; if (tts != null) tts.stop(); kokoroStop(); savePos(); mark("⏸ " + L.t("Donde paraste"), true); update();
        if (android.os.Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);
    }

    void resume() { playing = true; startForegroundNow(); speak(); }

    // v1.8.2: barra de tiempo estimada (caracteres ÷ velocidad) en vez de 00:00, y se puede arrastrar
    long[] cum;
    long msPerChar() { return Math.max(20, Math.round(1000 / (14.0 * Math.max(0.3f, rate)))); }
    long[] cum() {
        if (cum == null || cum.length != paras.size() + 1) {
            cum = new long[paras.size() + 1];
            for (int i = 0; i < paras.size(); i++) cum[i + 1] = cum[i] + paras.get(i).length() + 8;
        }
        return cum;
    }
    void seekMs(long ms) {
        long[] c = cum(); long ch = ms / msPerChar(); int i = 0;
        while (i < paras.size() - 1 && c[i + 1] <= ch) i++;
        idx = i; if (playing) speak(); else { savePos(); update(); }
    }

    void jump(int d) {
        idx = Math.max(0, Math.min(paras.size() - 1, idx + d));
        if (playing) speak(); else { savePos(); update(); }
    }

    /** ⏹: para y pone una marca borrable para seguir desde aquí. */
    void stopAndMark() {
        playing = false;
        if (tts != null) tts.stop();
        kokoroStop();
        mark("⏹ " + L.t("Donde paraste"), true);
        finishService();
    }

    void finishService() {
        savePos();
        running = false;
        stopForeground(true);
        stopSelf();
    }

    void savePos() {
        if (key.isEmpty() || idx < 0) return;
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        int total = Math.max(1, paras.size());
        p.edit().putLong("rposT_" + key, System.currentTimeMillis()).putInt("rpos_" + key, Math.min(idx, total - 1)).putInt("rpct_" + key, Math.round(100f * (Math.min(idx, total - 1) + 1) / total)).apply();
    }

    /** Marcadores: «bm_<libro>» = [{n: nombre, i: párrafo, a: automático}]. La marca automática se sustituye. */
    void mark(String name, boolean auto) { addBookmark(this, key, name, Math.max(0, Math.min(idx, paras.size() - 1)), auto); }

    static void addBookmark(Context c, String key, String name, int para, boolean auto) {
        try {
            SharedPreferences p = c.getSharedPreferences("cfg", MODE_PRIVATE);
            JSONArray a = new JSONArray(p.getString("bm_" + key, "[]")), out = new JSONArray();
            for (int i = 0; i < a.length(); i++) if (!(auto && a.getJSONObject(i).optBoolean("a"))) out.put(a.getJSONObject(i));
            JSONObject o = new JSONObject();
            o.put("n", name); o.put("i", para); o.put("a", auto); o.put("t", System.currentTimeMillis());
            out.put(o);
            p.edit().putString("bm_" + key, out.toString()).apply();
        } catch (Exception ignored) {}
    }

    void update() {
        getSystemService(NotificationManager.class).notify(NID, build());
        long[] c = cum(); int at = Math.max(0, Math.min(idx, paras.size()));
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SEEK_TO)
                .addCustomAction(new PlaybackState.CustomAction.Builder("close", L.t("Cerrar"), android.R.drawable.ic_menu_close_clear_cancel).build())   // ✕ visible en la tarjeta multimedia
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, c[at] * msPerChar(), playing ? 1f : 0f).build());
        session.setMetadata(new android.media.MediaMetadata.Builder()
                .putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, c[c.length - 1] * msPerChar())
                .putString(android.media.MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, progress()).build());
    }

    String progress() {
        int n = Math.max(1, paras.size());
        return L.t("Párrafo") + " " + (Math.min(idx, n - 1) + 1) + " / " + n + " · " + Math.round(100f * (Math.min(idx, n - 1) + 1) / n) + " %";
    }

    PendingIntent act(String a, int rc) {
        return PendingIntent.getService(this, rc, new Intent(this, ReadAloudService.class).setAction(a), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    Notification build() {
        Intent open = new Intent(this, DocReaderActivity.class).setData(uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title.isEmpty() ? L.t("Leyendo") : title)
                .setContentText(progress())
                .setContentIntent(content)
                .setOngoing(playing)
                .setDeleteIntent(act("stop", 6))          // v1.8.2: deslizarla (en pausa) también cierra y guarda dónde ibas
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous, L.t("Anterior"), act("prev", 2)).build())
                .addAction(new Notification.Action.Builder(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, playing ? L.t("Pausa") : L.t("Seguir"), act("toggle", 3)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next, L.t("Siguiente"), act("next", 4)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "✕ " + L.t("Cerrar"), act("stop", 5)).build())
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 3));
        return b.build();
    }

    /** v1.8.2: si cierras la app desde recientes estando en pausa, se cierra el lector y guarda dónde ibas. */
    @Override
    public void onTaskRemoved(Intent root) {
        if (!playing) stopAndMark();
        super.onTaskRemoved(root);
    }

    @Override
    public void onDestroy() {
        if (running && !key.isEmpty() && idx >= 0) { savePos(); mark("⏹ " + L.t("Donde paraste"), true); }   // cierre forzado: no perder el sitio
        running = false;
        playing = false;
        kokoroStop();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (session != null) session.release();
        super.onDestroy();
    }
}
