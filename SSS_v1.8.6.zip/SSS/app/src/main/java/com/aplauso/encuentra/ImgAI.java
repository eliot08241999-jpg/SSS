package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;

import java.io.File;
import java.nio.FloatBuffer;
import java.util.Collections;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OnnxValue;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

/**
 * v1.8.2 · IA para fotos, dentro del teléfono (se descargan una vez):
 *  · LaMa (Apache 2.0): borra rayas, manchas u objetos y rellena lo que falta.
 *  · GFPGAN 1.4 (Apache 2.0): recupera caras borrosas o dañadas.
 *  · DDColor-tiny (Apache 2.0): colorea fotos en blanco y negro.
 *  · ML Kit (Google): separa a la persona u objeto principal del fondo.
 */
public class ImgAI {
    public static final String[][] MODELS = {
            // id, archivo, url, MB aprox., nombre
            {"lama", "lama_fp32.onnx", "https://huggingface.co/sapienkit/LaMa-ONNX/resolve/main/lama_fp32.onnx", "208", "Borrar rayas y manchas (LaMa)"},
            {"gfpgan", "GFPGANv1.4.onnx", "https://huggingface.co/netrunner-exe/Face-Upscalers-onnx/resolve/main/GFPGANv1.4.onnx", "340", "Mejorar caras (GFPGAN)"},
            {"ddcolor", "ddcolor-tiny-fp16.onnx", "https://huggingface.co/edgetools/ddcolor/resolve/main/ddcolor-tiny-fp16.onnx", "130", "Colorear (DDColor)"},
    };

    public interface Prog { void on(String what, int done, int total); boolean cancelled(); }

    static String[] model(String id) { for (String[] m : MODELS) if (m[0].equals(id)) return m; return null; }
    static File file(Context c, String id) { return new File(new File(c.getFilesDir(), "imgai"), model(id)[1]); }
    public static boolean have(Context c, String id) { File f = file(c, id); return FastDownload.complete(f) && f.length() > 1_000_000; }

    /** Descarga (por trozos, continúa si se corta). */
    static synchronized void ensure(Context c, String id, Prog p) throws Exception {
        if (have(c, id)) return;
        String[] m = model(id);
        File f = file(c, id);
        long[] sz = new long[1];
        String url = FastDownload.resolve(m[2], sz);
        long size = sz[0] < 0 ? -1 : sz[0];
        FastDownload.cancel = false;
        FastDownload.total = Math.max(1, Math.abs(sz[0]));
        FastDownload.got.set(size > 0 ? FastDownload.doneBytes(f, size) : 0);
        FastDownload.startTime = System.currentTimeMillis(); FastDownload.startGot = FastDownload.got.get();
        final boolean[] done = {false};
        Thread watch = new Thread(() -> {
            while (!done[0]) {
                if (p != null) { if (p.cancelled()) FastDownload.cancel = true; p.on(L.t("Descargando") + " " + L.t(m[4]), (int) (FastDownload.got.get() >> 20), (int) (FastDownload.total >> 20)); }
                try { Thread.sleep(400); } catch (Exception ignored) {}
            }
        });
        watch.start();
        try { FastDownload.fetch(m[2], url, f, size); } finally { done[0] = true; }
        if (FastDownload.cancel) throw new InterruptedException();
        if (!have(c, id)) throw new Exception(L.t("La descarga no se completó."));
    }

    static OrtEnvironment env;
    static OrtSession sess; static String sessId;

    static synchronized OrtSession session(Context c, String id) throws Exception {
        if (sess != null && id.equals(sessId)) return sess;
        close();
        if (env == null) env = OrtEnvironment.getEnvironment();
        SdEngine.unload();                                            // la memoria es para esto ahora
        OrtSession.SessionOptions o = new OrtSession.SessionOptions();
        o.setIntraOpNumThreads(Math.max(2, Math.min(6, Runtime.getRuntime().availableProcessors() - 2)));
        o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
        sess = env.createSession(file(c, id).getAbsolutePath(), o);
        sessId = id;
        return sess;
    }

    public static synchronized void close() { if (sess != null) try { sess.close(); } catch (Exception ignored) {} sess = null; sessId = null; }

    static float[] run1(OrtSession s, float[] in, long[] shape) throws Exception {
        String name = s.getInputInfo().keySet().iterator().next();
        try (OnnxTensor t = OnnxTensor.createTensor(env, FloatBuffer.wrap(in), shape);
             OrtSession.Result r = s.run(Collections.singletonMap(name, t))) {
            return flat(r.get(0));
        }
    }

    static float[] flat(OnnxValue v) throws Exception {
        Object o = v.getValue();
        float[][][][] a = (float[][][][]) o;
        int C = a[0].length, H = a[0][0].length, W = a[0][0][0].length;
        float[] out = new float[C * H * W];
        for (int ch = 0; ch < C; ch++) for (int y = 0; y < H; y++) System.arraycopy(a[0][ch][y], 0, out, (ch * H + y) * W, W);
        return out;
    }

    // ======================================================================= LaMa: rellenar lo marcado
    /** mask: 1 = borrar. Trabaja en ventanas de 512 alrededor de lo marcado, a la resolución original. */
    static Bitmap inpaint(Context c, Bitmap src, boolean[] mask, Prog p) throws Exception {
        ensure(c, "lama", p);
        OrtSession s = session(c, "lama");
        int W = src.getWidth(), H = src.getHeight(), S = 512, step = 448;
        int[] px = new int[W * H];
        src.getPixels(px, 0, W, 0, 0, W, H);
        int[] out = px.clone();
        // si la foto es grande y lo marcado ocupa mucho, se trabaja a escala (LaMa ve contexto)
        java.util.List<int[]> wins = new java.util.ArrayList<>();
        for (int y0 = 0; y0 < Math.max(1, H - S + step); y0 += step) for (int x0 = 0; x0 < Math.max(1, W - S + step); x0 += step) {
            int x = Math.max(0, Math.min(x0, W - S)), y = Math.max(0, Math.min(y0, H - S));
            boolean any = false;
            for (int yy = y; yy < Math.min(H, y + S) && !any; yy += 2) for (int xx = x; xx < Math.min(W, x + S); xx += 2) if (mask[yy * W + xx]) { any = true; break; }
            if (any) wins.add(new int[]{x, y});
        }
        String[] names = s.getInputInfo().keySet().toArray(new String[0]);
        String imgName = names[0], maskName = names.length > 1 ? names[1] : null;
        for (String n : names) { if (n.toLowerCase().contains("mask")) maskName = n; else imgName = n; }
        int k = 0;
        for (int[] w : wins) {
            if (p != null) { if (p.cancelled()) throw new InterruptedException(); p.on(L.t("Borrando rayas y manchas"), k++, wins.size()); }
            float[] img = new float[3 * S * S], m = new float[S * S];
            for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
                int sx = Math.min(W - 1, w[0] + x), sy = Math.min(H - 1, w[1] + y), v = out[sy * W + sx];
                img[y * S + x] = ((v >> 16) & 255) / 255f; img[S * S + y * S + x] = ((v >> 8) & 255) / 255f; img[2 * S * S + y * S + x] = (v & 255) / 255f;
                m[y * S + x] = mask[sy * W + sx] ? 1 : 0;
            }
            float[] r;
            try (OnnxTensor ti = OnnxTensor.createTensor(env, FloatBuffer.wrap(img), new long[]{1, 3, S, S});
                 OnnxTensor tm = OnnxTensor.createTensor(env, FloatBuffer.wrap(m), new long[]{1, 1, S, S})) {
                java.util.Map<String, OnnxTensor> in = new java.util.HashMap<>();
                in.put(imgName, ti); in.put(maskName, tm);
                try (OrtSession.Result res = s.run(in)) { r = flat(res.get(0)); }
            }
            float mx = 0; for (int i = 0; i < r.length; i += 97) mx = Math.max(mx, r[i]);
            float sc = mx <= 1.5f ? 255f : 1f;                           // por si devuelve 0..1 en vez de 0..255
            for (int y = 0; y < S && w[1] + y < H; y++) for (int x = 0; x < S && w[0] + x < W; x++) {
                int i = (w[1] + y) * W + w[0] + x;
                if (!mask[i]) continue;
                int R = clamp(r[y * S + x] * sc), G = clamp(r[S * S + y * S + x] * sc), B = clamp(r[2 * S * S + y * S + x] * sc);
                out[i] = 0xFF000000 | (R << 16) | (G << 8) | B;
            }
        }
        return Bitmap.createBitmap(out, W, H, Bitmap.Config.ARGB_8888);
    }

    static int clamp(float v) { return Math.max(0, Math.min(255, Math.round(v))); }

    /** Rayas y manchas típicas de fotos viejas: líneas finas mucho más claras u oscuras que lo de alrededor. */
    static boolean[] autoScratches(Bitmap b, float sens) {
        int W = b.getWidth(), H = b.getHeight();
        int[] px = new int[W * H];
        b.getPixels(px, 0, W, 0, 0, W, H);
        float[] g = new float[W * H];
        for (int i = 0; i < px.length; i++) g[i] = (((px[i] >> 16) & 255) * 0.3f + ((px[i] >> 8) & 255) * 0.59f + (px[i] & 255) * 0.11f);
        boolean[] m = new boolean[W * H];
        int R = Math.max(2, Math.min(W, H) / 250);
        float th = 38 - 22 * sens;
        int st = Math.max(1, R / 2);
        float[] win = new float[(2 * R / st + 2) * (2 * R / st + 2)];
        for (int y = R; y < H - R; y++) for (int x = R; x < W - R; x++) {
            int n = 0;                                                            // mediana de la ventana (pocas muestras: ordenación por inserción)
            for (int dy = -R; dy <= R; dy += st) for (int dx = -R; dx <= R; dx += st) {
                float v = g[(y + dy) * W + x + dx];
                int j = n++;
                while (j > 0 && win[j - 1] > v) { win[j] = win[j - 1]; j--; }
                win[j] = v;
            }
            if (Math.abs(g[y * W + x] - win[n / 2]) > th) m[y * W + x] = true;
        }
        // quita puntos sueltos (textura) y engorda un poco lo que queda (bordes de la raya)
        boolean[] o = new boolean[W * H];
        for (int y = 1; y < H - 1; y++) for (int x = 1; x < W - 1; x++) {
            if (!m[y * W + x]) continue;
            int nb = 0; for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) if (m[(y + dy) * W + x + dx]) nb++;
            if (nb >= 3) for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) o[(y + dy) * W + x + dx] = true;
        }
        return o;
    }

    // ======================================================================= GFPGAN: caras
    /** Busca las caras (detector de Android) y las mejora una a una. fidelity: 0 = original, 1 = todo IA. */
    static Bitmap faces(Context c, Bitmap src, float fidelity, Prog p) throws Exception {
        Bitmap b565 = src.copy(Bitmap.Config.RGB_565, false);
        int fw = b565.getWidth() & ~1;
        if (fw != b565.getWidth()) b565 = Bitmap.createBitmap(b565, 0, 0, fw, b565.getHeight());
        android.media.FaceDetector.Face[] found = new android.media.FaceDetector.Face[10];
        int n = new android.media.FaceDetector(b565.getWidth(), b565.getHeight(), 10).findFaces(b565, found);
        if (n == 0) return null;
        ensure(c, "gfpgan", p);
        OrtSession s = session(c, "gfpgan");
        Bitmap out = src.copy(Bitmap.Config.ARGB_8888, true);
        int S = 512;
        for (int k = 0; k < n; k++) {
            if (p != null) { if (p.cancelled()) throw new InterruptedException(); p.on(L.t("Mejorando caras"), k, n); }
            android.graphics.PointF mid = new android.graphics.PointF();
            found[k].getMidPoint(mid);
            float ed = found[k].eyesDistance();
            float size = ed / 0.246f;                                       // plantilla FFHQ: ojos a 126 px de 512
            float x0 = mid.x - size * 0.5f, y0 = mid.y - size * 0.469f;
            Bitmap crop = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
            android.graphics.Canvas cv = new android.graphics.Canvas(crop);
            cv.drawColor(Color.BLACK);
            android.graphics.Matrix mtx = new android.graphics.Matrix();
            mtx.setTranslate(-x0, -y0); mtx.postScale(S / size, S / size);
            cv.drawBitmap(src, mtx, new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG));
            int[] px = new int[S * S]; crop.getPixels(px, 0, S, 0, 0, S, S);
            float[] in = new float[3 * S * S];
            for (int i = 0; i < S * S; i++) { int v = px[i]; in[i] = ((v >> 16) & 255) / 127.5f - 1; in[S * S + i] = ((v >> 8) & 255) / 127.5f - 1; in[2 * S * S + i] = (v & 255) / 127.5f - 1; }
            float[] r = run1(s, in, new long[]{1, 3, S, S});
            float mn = 0; for (int i = 0; i < r.length; i += 101) mn = Math.min(mn, r[i]);
            boolean signed = mn < -0.15f;
            int[] fo = new int[S * S];
            for (int i = 0; i < S * S; i++) {
                float R = r[i], G = r[S * S + i], B = r[2 * S * S + i];
                if (signed) { R = (R + 1) * 127.5f; G = (G + 1) * 127.5f; B = (B + 1) * 127.5f; } else { R *= 255; G *= 255; B *= 255; }
                fo[i] = 0xFF000000 | (clamp(R) << 16) | (clamp(G) << 8) | clamp(B);
            }
            Bitmap face = Bitmap.createBitmap(fo, S, S, Bitmap.Config.ARGB_8888);
            // pegar con un óvalo difuminado y la fidelidad elegida
            Bitmap soft = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
            android.graphics.Canvas sc = new android.graphics.Canvas(soft);
            sc.drawBitmap(face, 0, 0, null);
            android.graphics.Paint mp = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            mp.setShader(new android.graphics.RadialGradient(S / 2f, S * 0.52f, S * 0.48f, new int[]{Color.BLACK, Color.BLACK, Color.TRANSPARENT}, new float[]{0, 0.72f, 1f}, android.graphics.Shader.TileMode.CLAMP));
            mp.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN));
            sc.drawRect(0, 0, S, S, mp);
            android.graphics.Canvas oc = new android.graphics.Canvas(out);
            android.graphics.Matrix back = new android.graphics.Matrix();
            back.setScale(size / S, size / S); back.postTranslate(x0, y0);
            android.graphics.Paint bp = new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG);
            bp.setAlpha(Math.round(255 * Math.max(0, Math.min(1, fidelity))));
            oc.drawBitmap(soft, back, bp);
        }
        return out;
    }

    // ======================================================================= DDColor: colorear
    static Bitmap colorize(Context c, Bitmap src, float intensity, Prog p) throws Exception {
        ensure(c, "ddcolor", p);
        if (p != null) p.on(L.t("Coloreando"), 0, 1);
        OrtSession s = session(c, "ddcolor");
        int S = 512, W = src.getWidth(), H = src.getHeight();
        Bitmap sm = Bitmap.createScaledBitmap(src, S, S, true);
        int[] px = new int[S * S]; sm.getPixels(px, 0, S, 0, 0, S, S);
        float[] in = new float[3 * S * S];
        for (int i = 0; i < S * S; i++) {                                  // solo la luz: gris en RGB (Lab con a = b = 0)
            float[] lab = rgb2lab(px[i]);
            int g = lab2rgb(lab[0], 0, 0);
            in[i] = ((g >> 16) & 255) / 255f; in[S * S + i] = ((g >> 8) & 255) / 255f; in[2 * S * S + i] = (g & 255) / 255f;
        }
        float[] ab = run1(s, in, new long[]{1, 3, S, S});
        int[] full = new int[W * H]; src.getPixels(full, 0, W, 0, 0, W, H);
        for (int y = 0; y < H; y++) {
            float sy = (y + 0.5f) * S / H - 0.5f; int y0 = Math.max(0, Math.min(S - 1, (int) Math.floor(sy))), y1 = Math.min(S - 1, y0 + 1); float fy = Math.max(0, Math.min(1, sy - y0));
            for (int x = 0; x < W; x++) {
                float sx = (x + 0.5f) * S / W - 0.5f; int x0 = Math.max(0, Math.min(S - 1, (int) Math.floor(sx))), x1 = Math.min(S - 1, x0 + 1); float fx = Math.max(0, Math.min(1, sx - x0));
                float a = bil(ab, 0, S, x0, x1, y0, y1, fx, fy) * intensity, b = bil(ab, S * S, S, x0, x1, y0, y1, fx, fy) * intensity;
                float L = rgb2lab(full[y * W + x])[0];
                full[y * W + x] = lab2rgb(L, a, b);
            }
        }
        return Bitmap.createBitmap(full, W, H, Bitmap.Config.ARGB_8888);
    }

    static float bil(float[] a, int off, int S, int x0, int x1, int y0, int y1, float fx, float fy) {
        float t = a[off + y0 * S + x0] * (1 - fx) + a[off + y0 * S + x1] * fx, u = a[off + y1 * S + x0] * (1 - fx) + a[off + y1 * S + x1] * fx;
        return t * (1 - fy) + u * fy;
    }

    // Lab (convención de OpenCV en coma flotante: L 0..100, a/b ≈ ±127, D65, sRGB)
    static float lin(float v) { return v <= 0.04045f ? v / 12.92f : (float) Math.pow((v + 0.055) / 1.055, 2.4); }
    static float gam(float v) { return v <= 0.0031308f ? 12.92f * v : (float) (1.055 * Math.pow(v, 1 / 2.4) - 0.055); }
    static float f(float t) { return t > 0.008856f ? (float) Math.cbrt(t) : 7.787f * t + 16f / 116f; }
    static float fi(float t) { float t3 = t * t * t; return t3 > 0.008856f ? t3 : (t - 16f / 116f) / 7.787f; }

    static float[] rgb2lab(int p) {
        float r = lin(((p >> 16) & 255) / 255f), g = lin(((p >> 8) & 255) / 255f), b = lin((p & 255) / 255f);
        float X = (0.412453f * r + 0.357580f * g + 0.180423f * b) / 0.950456f, Y = 0.212671f * r + 0.715160f * g + 0.072169f * b, Z = (0.019334f * r + 0.119193f * g + 0.950227f * b) / 1.088754f;
        float fy = f(Y);
        return new float[]{Y > 0.008856f ? 116 * fy - 16 : 903.3f * Y, 500 * (f(X) - fy), 200 * (fy - f(Z))};
    }

    static int lab2rgb(float L, float a, float b) {
        float fy = (L + 16) / 116f, fx = fy + a / 500f, fz = fy - b / 200f;
        float X = fi(fx) * 0.950456f, Y = fi(fy), Z = fi(fz) * 1.088754f;
        float r = 3.240479f * X - 1.537150f * Y - 0.498535f * Z, g = -0.969256f * X + 1.875992f * Y + 0.041556f * Z, bb = 0.055648f * X - 0.204043f * Y + 1.057311f * Z;
        return 0xFF000000 | (clamp(gam(Math.max(0, r)) * 255) << 16) | (clamp(gam(Math.max(0, g)) * 255) << 8) | clamp(gam(Math.max(0, bb)) * 255);
    }

    // ======================================================================= ML Kit: separar del fondo
    /** Confianza 0..1 de que cada píxel es el sujeto principal (persona, animal u objeto). Bloquea: llamar fuera del hilo principal. */
    static float[] subject(Bitmap b) throws Exception {
        com.google.mlkit.vision.segmentation.subject.SubjectSegmenter seg = com.google.mlkit.vision.segmentation.subject.SubjectSegmentation.getClient(
                new com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions.Builder().enableForegroundConfidenceMask().build());
        try {
            com.google.mlkit.vision.segmentation.subject.SubjectSegmentationResult r = com.google.android.gms.tasks.Tasks.await(
                    seg.process(com.google.mlkit.vision.common.InputImage.fromBitmap(b, 0)), 60, java.util.concurrent.TimeUnit.SECONDS);
            FloatBuffer fb = r.getForegroundConfidenceMask();
            float[] m = new float[b.getWidth() * b.getHeight()];
            fb.rewind(); fb.get(m, 0, Math.min(m.length, fb.remaining()));
            return m;
        } finally { try { seg.close(); } catch (Exception ignored) {} }
    }

    /** Clasico: contraste automático (estira los niveles) y quita un poco de ruido. */
    static Bitmap autoFix(Bitmap src) {
        int W = src.getWidth(), H = src.getHeight();
        int[] px = new int[W * H]; src.getPixels(px, 0, W, 0, 0, W, H);
        int[][] hist = new int[3][256];
        for (int v : px) { hist[0][(v >> 16) & 255]++; hist[1][(v >> 8) & 255]++; hist[2][v & 255]++; }
        int[] lo = new int[3], hi = new int[3];
        for (int ch = 0; ch < 3; ch++) {
            int acc = 0; for (int i = 0; i < 256; i++) { acc += hist[ch][i]; if (acc > px.length * 0.005) { lo[ch] = i; break; } }
            acc = 0; for (int i = 255; i >= 0; i--) { acc += hist[ch][i]; if (acc > px.length * 0.005) { hi[ch] = i; break; } }
            if (hi[ch] - lo[ch] < 30) { lo[ch] = 0; hi[ch] = 255; }
        }
        int[] out = new int[px.length];
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            int r = 0, g = 0, b = 0, n = 0;                                   // un desenfoque mínimo 3×3 ponderado: menos grano
            for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                int xx = Math.max(0, Math.min(W - 1, x + dx)), yy = Math.max(0, Math.min(H - 1, y + dy)), w = (dx == 0 && dy == 0) ? 4 : 1, v = px[yy * W + xx];
                r += ((v >> 16) & 255) * w; g += ((v >> 8) & 255) * w; b += (v & 255) * w; n += w;
            }
            r /= n; g /= n; b /= n;
            out[y * W + x] = 0xFF000000 | (clamp((r - lo[0]) * 255f / (hi[0] - lo[0])) << 16) | (clamp((g - lo[1]) * 255f / (hi[1] - lo[1])) << 8) | clamp((b - lo[2]) * 255f / (hi[2] - lo[2]));
        }
        return Bitmap.createBitmap(out, W, H, Bitmap.Config.ARGB_8888);
    }
}
