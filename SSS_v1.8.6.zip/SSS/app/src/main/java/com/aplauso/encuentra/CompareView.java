package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * v1.8.2 · Antes / después con una barra que se arrastra; y modo pincel para marcar (o desmarcar) zonas sobre la foto.
 * Fondo de cuadritos para ver la transparencia (quitar fondo).
 */
public class CompareView extends View {
    Bitmap before, after;
    float split = 0.5f;
    public boolean brush, erase;
    public float brushPx = 18;                    // radio en píxeles de la imagen
    public boolean[] mask;                        // a la resolución de «before»
    Bitmap maskBmp;
    public Runnable onMaskChanged;
    final Paint pt = new Paint(Paint.FILTER_BITMAP_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG);
    final RectF dst = new RectF();
    Bitmap checker;

    public CompareView(Context c) { super(c); line.setStrokeWidth(4); }

    public void set(Bitmap before, Bitmap after) {
        this.before = before; this.after = after;
        if (before != null && (mask == null || mask.length != before.getWidth() * before.getHeight())) { mask = new boolean[before.getWidth() * before.getHeight()]; maskBmp = null; }
        invalidate();
    }

    public void setMask(boolean[] m) { mask = m; maskBmp = null; invalidate(); }
    public boolean hasMask() { if (mask == null) return false; for (boolean b : mask) if (b) return true; return false; }

    void layoutDst() {
        Bitmap b = before != null ? before : after;
        if (b == null) return;
        float s = Math.min(getWidth() / (float) b.getWidth(), getHeight() / (float) b.getHeight());
        float w = b.getWidth() * s, h = b.getHeight() * s;
        dst.set((getWidth() - w) / 2, (getHeight() - h) / 2, (getWidth() + w) / 2, (getHeight() + h) / 2);
    }

    @Override
    protected void onDraw(Canvas c) {
        layoutDst();
        if (before == null && after == null) return;
        if (checker == null) {
            checker = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888);
            for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) checker.setPixel(x, y, ((x / 8 + y / 8) & 1) == 0 ? Color.rgb(60, 60, 70) : Color.rgb(90, 90, 100));
        }
        Paint cp = new Paint();
        cp.setShader(new android.graphics.BitmapShader(checker, android.graphics.Shader.TileMode.REPEAT, android.graphics.Shader.TileMode.REPEAT));
        c.drawRect(dst, cp);
        float sx = dst.left + dst.width() * split;
        if (after == null || brush) c.drawBitmap(before, null, dst, pt);
        else if (before == null) c.drawBitmap(after, null, dst, pt);
        else {
            c.save(); c.clipRect(dst.left, dst.top, sx, dst.bottom); c.drawBitmap(before, null, dst, pt); c.restore();
            c.save(); c.clipRect(sx, dst.top, dst.right, dst.bottom); c.drawBitmap(after, null, dst, pt); c.restore();
            line.setColor(Color.WHITE);
            c.drawLine(sx, dst.top, sx, dst.bottom, line);
            line.setColor(Neon.color(getContext()));
            c.drawCircle(sx, dst.centerY(), 18, line);
            Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG); tp.setColor(Color.WHITE); tp.setTextSize(30); tp.setShadowLayer(4, 0, 0, Color.BLACK);
            c.drawText(L.t("ANTES"), dst.left + 12, dst.top + 40, tp);
            tp.setTextAlign(Paint.Align.RIGHT);
            c.drawText(L.t("DESPUÉS"), dst.right - 12, dst.top + 40, tp);
        }
        if (mask != null && before != null && (brush || after == null)) {
            if (maskBmp == null) rebuildMask();
            if (maskBmp != null) c.drawBitmap(maskBmp, null, dst, pt);
        }
    }

    void rebuildMask() {
        if (before == null || mask == null) return;
        int W = before.getWidth(), H = before.getHeight();
        int s = Math.max(1, Math.max(W, H) / 700);                // vista reducida de la máscara
        int w = W / s, h = H / s;
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) px[y * w + x] = mask[Math.min(H - 1, y * s) * W + Math.min(W - 1, x * s)] ? 0x88FF3060 : 0;
        maskBmp = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        getParent().requestDisallowInterceptTouchEvent(true);
        if (!brush) {
            if (dst.width() > 0) split = Math.max(0, Math.min(1, (e.getX() - dst.left) / dst.width()));
            invalidate();
            return true;
        }
        if (before == null || mask == null) return true;
        int W = before.getWidth(), H = before.getHeight();
        float ix = (e.getX() - dst.left) / dst.width() * W, iy = (e.getY() - dst.top) / dst.height() * H;
        int r = Math.round(brushPx);
        for (int y = Math.max(0, (int) iy - r); y < Math.min(H, (int) iy + r); y++)
            for (int x = Math.max(0, (int) ix - r); x < Math.min(W, (int) ix + r); x++)
                if ((x - ix) * (x - ix) + (y - iy) * (y - iy) <= r * r) mask[y * W + x] = !erase;
        if (e.getAction() == MotionEvent.ACTION_UP && onMaskChanged != null) onMaskChanged.run();
        maskBmp = null;
        invalidate();
        return true;
    }
}
