package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

import java.util.Random;

/**
 * v1.8.2 · 🏆 Trofeo en pixel art. Cuanto más alto el nivel, más efectos:
 * 1 bronce (liso) · 2 plata (+ reflejo que pasa) · 3 oro (+ destellos) · 4 platino (+ brillo y cambio de color)
 * · 5 diamante (+ partículas y arcoíris). Bloqueado: silueta gris con «?».
 */
public class TrophyView extends View {
    static final String[] CUP = {
            "..########..",
            "############",
            "#.########.#",
            "#.########.#",
            ".##########.",
            "..########..",
            "...######...",
            "....####....",
            ".....##.....",
            ".....##.....",
            "...######...",
            "..########.."};
    static final String[] MEDAL = {
            ".##......##.",
            "..##....##..",
            "...##..##...",
            "....####....",
            "...######...",
            "..###..###..",
            ".###.##.###.",
            ".##.####.##.",
            ".###.##.###.",
            "..###..###..",
            "...######...",
            "....####...."};
    static final int[][] TIER = {{150, 150, 150}, {205, 127, 50}, {205, 210, 222}, {255, 196, 40}, {150, 230, 255}, {255, 255, 255}};

    int series, tier;
    boolean locked;
    final Paint pt = new Paint();
    final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Random rnd = new Random();
    final float[][] parts = new float[14][4];     // partículas: x, y, vida, velocidad

    public TrophyView(Context c, int series, int tier, boolean locked) {
        super(c);
        this.series = series; this.tier = tier; this.locked = locked;
        for (float[] p : parts) reset(p, true);
    }

    void reset(float[] p, boolean anyY) { p[0] = rnd.nextFloat(); p[1] = anyY ? rnd.nextFloat() : 1f; p[2] = 0.5f + rnd.nextFloat() * 0.5f; p[3] = 0.15f + rnd.nextFloat() * 0.25f; }

    int base(float t) {
        if (locked) return Color.rgb(70, 74, 90);
        int[] c = TIER[Math.max(0, Math.min(5, tier))];
        if (tier == 4) {                                        // platino: va virando de color poco a poco
            float[] hsv = new float[3]; Color.RGBToHSV(c[0], c[1], c[2], hsv);
            hsv[0] = (hsv[0] + 40 * (float) Math.sin(t * 0.9)) % 360; if (hsv[0] < 0) hsv[0] += 360;
            return Color.HSVToColor(hsv);
        }
        if (tier == 5) return Color.HSVToColor(new float[]{(t * 60) % 360, 0.35f, 1f});   // diamante: arcoíris
        return Color.rgb(c[0], c[1], c[2]);
    }

    static int shade(int c, float k) {
        return Color.rgb(Math.min(255, Math.max(0, Math.round(Color.red(c) * k))), Math.min(255, Math.max(0, Math.round(Color.green(c) * k))), Math.min(255, Math.max(0, Math.round(Color.blue(c) * k))));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float t = SystemClock.uptimeMillis() / 1000f;
        int w = getWidth(), h = getHeight();
        float px = Math.min(w, h) / 16f;                       // 12 px de trofeo + margen para efectos
        float ox = (w - 12 * px) / 2f, oy = (h - 12 * px) / 2f;
        int col = base(t);
        // 4 · brillo
        if (!locked && tier >= 4) {
            float r = Math.min(w, h) * (0.5f + 0.05f * (float) Math.sin(t * 3));
            glow.setShader(new RadialGradient(w / 2f, h / 2f, Math.max(1, r), Color.argb(150, Color.red(col), Color.green(col), Color.blue(col)), Color.TRANSPARENT, Shader.TileMode.CLAMP));
            cv.drawCircle(w / 2f, h / 2f, r, glow);
        }
        String[] shape = series == 0 ? CUP : MEDAL;
        float sweep = ((t * 0.7f) % 2f) * 18 - 4;               // 2 · reflejo diagonal que pasa
        for (int y = 0; y < 12; y++) for (int x = 0; x < 12; x++) {
            if (shape[y].charAt(x) != '#') continue;
            float k = x < 4 ? 1.18f : x > 8 ? 0.72f : 1f;           // luz por la izquierda
            if (y >= 10) k *= 0.85f;
            int c = shade(col, k);
            if (!locked && tier >= 2 && Math.abs((x + y) - sweep) < 1.2f) c = Color.WHITE;
            pt.setColor(c);
            cv.drawRect(ox + x * px, oy + y * px, ox + (x + 1) * px + 0.5f, oy + (y + 1) * px + 0.5f, pt);
        }
        if (locked) {
            pt.setColor(Color.rgb(200, 205, 220));
            pt.setTextSize(px * 6);
            pt.setTextAlign(Paint.Align.CENTER);
            pt.setFakeBoldText(true);
            cv.drawText("?", w / 2f, oy + 8.5f * px, pt);
            return;
        }
        // 3 · destellos en cruz que parpadean
        if (tier >= 3) {
            for (int i = 0; i < 3; i++) {
                float ph = (t * 1.3f + i * 0.37f) % 1f;
                if (ph > 0.45f) continue;
                float a = 1 - Math.abs(ph - 0.22f) / 0.23f;
                int sx = (int) ((Math.sin(i * 12.9 + Math.floor(t * 1.3 + i * 0.37) * 7.1) * 0.5 + 0.5) * 14) - 1;
                int sy = (int) ((Math.cos(i * 4.3 + Math.floor(t * 1.3 + i * 0.37) * 3.7) * 0.5 + 0.5) * 12) - 1;
                pt.setColor(Color.argb((int) (255 * a), 255, 255, 230));
                float cx = ox + sx * px, cy = oy + sy * px;
                cv.drawRect(cx, cy, cx + px, cy + px, pt);
                cv.drawRect(cx - px, cy, cx, cy + px, pt); cv.drawRect(cx + px, cy, cx + 2 * px, cy + px, pt);
                cv.drawRect(cx, cy - px, cx + px, cy, pt); cv.drawRect(cx, cy + px, cx + px, cy + 2 * px, pt);
            }
        }
        // 5 · partículas que suben
        if (tier >= 5) {
            for (float[] p : parts) {
                p[1] -= p[3] * 0.016f; p[2] -= 0.008f;
                if (p[1] < 0 || p[2] <= 0) reset(p, false);
                pt.setColor(Color.HSVToColor((int) (255 * Math.min(1, p[2] * 1.5f)), new float[]{(t * 90 + p[0] * 360) % 360, 0.5f, 1f}));
                float x = p[0] * w, y = p[1] * h;
                cv.drawRect(x, y, x + px * 0.8f, y + px * 0.8f, pt);
            }
        }
        if (tier >= 2) postInvalidateOnAnimation();
    }
}
