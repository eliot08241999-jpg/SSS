package com.aplauso.encuentra;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** v1.8 · La ventanita al tocar un acorde: su dibujo, dedos, otras posiciones, ▶ escuchar y alternativas. */
public final class ChordPopup {
    private ChordPopup() {}

    public interface OnReplace { void replace(MusicTheory.Chord from, MusicTheory.Chord to); }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    /** Cuerdas del instrumento de acordes (null si es piano). */
    static int[] strings(Context c) {
        String id = prefs(c).getString("mus_chord_instr", "gtr6");
        return "piano".equals(id) ? null : MusicTheory.byId(c, id).strings;
    }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    /** Vista con el acorde (diagrama o piano) y botones ◀ ▶ ▶escuchar. Devuelve el contenedor. */
    public static LinearLayout chordView(Activity a, MusicTheory.Chord ch, int capo) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 8));
        int[] st = strings(a);
        boolean lefty = prefs(a).getBoolean("mus_lefty", false);
        double a4 = prefs(a).getFloat("tun_a4", 440f);
        TextView info = new TextView(a);
        info.setTextColor(Color.rgb(190, 200, 215));
        info.setTextSize(12);
        info.setGravity(Gravity.CENTER);
        if (st == null) {
            MusicViews.Piano pv = new MusicViews.Piano(a);
            pv.set(ch.pcs(), ch.root);
            TextView t = new TextView(a);
            t.setText(ch.name(a));
            t.setTextColor(Color.WHITE);
            t.setTextSize(22);
            t.setGravity(Gravity.CENTER);
            box.addView(t);
            box.addView(pv);
            StringBuilder notes = new StringBuilder();
            for (int i : ch.intervals()) notes.append(MusicTheory.name(a, ch.root + i)).append("  ");
            info.setText(notes.toString().trim());
            box.addView(info);
            TextView play = btn(a, "▶ " + L.t("Escuchar"));
            play.setOnClickListener(v -> {
                int[] iv = ch.intervals(); int[] m = new int[iv.length];
                for (int i = 0; i < iv.length; i++) m[i] = 60 + ch.root + iv[i];
                MusicAudio.playNotes(m, 0, a4);
            });
            box.addView(play);
            return box;
        }
        List<MusicTheory.Voicing> vs = MusicTheory.voicings(ch, st, capo, 8);
        MusicViews.ChordDiagram dg = new MusicViews.ChordDiagram(a);
        final int[] idx = {0};
        Runnable show = () -> {
            if (vs.isEmpty()) { dg.set(ch.name(a), null, st.length, lefty); info.setText(L.t("No encuentro una posición cómoda para este acorde.")); return; }
            MusicTheory.Voicing v = vs.get(idx[0]);
            dg.set(ch.name(a), v, st.length, lefty);
            info.setText((idx[0] + 1) + " / " + vs.size() + (v.barre > 0 ? " · " + L.t("cejilla en el") + " " + v.barre : "")
                    + (capo > 0 ? " · " + L.t("con cejilla (capo) en el") + " " + capo : ""));
        };
        show.run();
        box.addView(dg, new LinearLayout.LayoutParams(-1, -2));
        box.addView(info);
        LinearLayout row = new LinearLayout(a);
        TextView prev = btn(a, "◀"), play = btn(a, "▶ " + L.t("Escuchar")), next = btn(a, "▶▶");
        prev.setOnClickListener(v -> { if (!vs.isEmpty()) { idx[0] = (idx[0] - 1 + vs.size()) % vs.size(); show.run(); } });
        next.setOnClickListener(v -> { if (!vs.isEmpty()) { idx[0] = (idx[0] + 1) % vs.size(); show.run(); } });
        play.setOnClickListener(v -> {
            if (vs.isEmpty()) return;
            int[] f = vs.get(idx[0]).frets; int[] m = new int[f.length];
            for (int i = 0; i < f.length; i++) m[i] = f[i] < 0 ? -1 : st[i] + capo + f[i];
            MusicAudio.playNotes(m, 35, a4);
        });
        play.setOnLongClickListener(v -> {                       // mantener: nota a nota
            if (vs.isEmpty()) return true;
            int[] f = vs.get(idx[0]).frets; int[] m = new int[f.length];
            for (int i = 0; i < f.length; i++) m[i] = f[i] < 0 ? -1 : st[i] + capo + f[i];
            MusicAudio.playNotes(m, 320, a4);
            return true;
        });
        row.addView(prev, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(play, new LinearLayout.LayoutParams(0, -2, 2));
        row.addView(next, new LinearLayout.LayoutParams(0, -2, 1));
        box.addView(row);
        return box;
    }

    static TextView btn(Activity a, String s) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextColor(Neon.color(a));
        t.setTextSize(15);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(a, 8), dp(a, 12), dp(a, 8), dp(a, 12));
        return t;
    }

    /** La ventanita completa. «replace» puede ser null (no se ofrece cambiar en la canción). */
    public static void show(Activity a, MusicTheory.Chord ch, int capo, OnReplace replace) {
        LinearLayout box = chordView(a, ch, capo);
        android.widget.ScrollView sv = new android.widget.ScrollView(a);
        sv.addView(box);
        AlertDialog.Builder b = new AlertDialog.Builder(a).setView(sv).setPositiveButton("OK", null);
        b.setNeutralButton(L.t("💡 Alternativas"), (d, w) -> alternatives(a, ch, capo, replace));
        b.show();
    }

    /** Acordes que suenan bien en su lugar: más fáciles, con más color y sustitutos. */
    public static void alternatives(Activity a, MusicTheory.Chord ch, int capo, OnReplace replace) {
        int[] st = strings(a);
        List<MusicTheory.Alt> alts = MusicTheory.alternatives(ch, st == null ? MusicTheory.TUNINGS.get(0).strings : st);
        String[] items = new String[alts.size()];
        for (int i = 0; i < items.length; i++) items[i] = alts.get(i).chord.name(a) + "   ·   " + L.t(alts.get(i).why);
        new AlertDialog.Builder(a).setTitle(L.t("En vez de") + " " + ch.name(a) + "…").setItems(items, (d, w) -> {
            MusicTheory.Chord to = alts.get(w).chord;
            LinearLayout v = chordView(a, to, capo);
            AlertDialog.Builder b = new AlertDialog.Builder(a).setView(v).setNegativeButton(L.t("Volver"), (d2, w2) -> alternatives(a, ch, capo, replace));
            if (replace != null) b.setPositiveButton(L.t("✔ Cambiar en la canción"), (d2, w2) -> replace.replace(ch, to));
            b.show();
        }).show();
    }
}
