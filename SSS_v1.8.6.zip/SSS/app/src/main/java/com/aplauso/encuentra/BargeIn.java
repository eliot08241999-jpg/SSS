package com.aplauso.encuentra;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.NoiseSuppressor;
import android.os.Handler;
import android.os.Looper;

/**
 * v1.8: mientras Chloe habla en el modo conversación, escucha el micrófono (con cancelación de eco)
 * y, si detecta que TÚ empiezas a hablar, la hace callar al instante.
 *
 * Cómo distingue tu voz de la suya: los primeros ~0,6 s mide cuánto se cuela su propia voz por el
 * micrófono (eco) y luego solo reacciona a algo claramente más fuerte que eso, durante ~0,3 s seguidos.
 */
final class BargeIn {
    static final int RATE = 16000, FRAME = 320;           // tramos de 20 ms

    private volatile boolean run;
    private Thread th;

    static boolean on(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("live_bargein", true); }

    /** 0 = poco sensible … 2 = muy sensible. */
    static int sens(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("live_bargein_sens", 1); }

    void start(Context c, Runnable onUser) {
        stop();
        if (!on(c)) return;
        final int s = sens(c);
        final float margin = s == 0 ? 16f : s == 2 ? 8f : 12f;    // dB por encima del eco
        final float floor = s == 0 ? -32f : s == 2 ? -44f : -38f; // dBFS mínimo para contar como voz
        final Handler main = new Handler(Looper.getMainLooper());
        run = true;
        th = new Thread(() -> {
            AudioRecord ar = null;
            AcousticEchoCanceler aec = null;
            NoiseSuppressor ns = null;
            try {
                int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                ar = new AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(min, FRAME * 8));
                if (ar.getState() != AudioRecord.STATE_INITIALIZED) return;
                try { if (AcousticEchoCanceler.isAvailable()) { aec = AcousticEchoCanceler.create(ar.getAudioSessionId()); if (aec != null) aec.setEnabled(true); } } catch (Throwable ignored) {}
                try { if (NoiseSuppressor.isAvailable()) { ns = NoiseSuppressor.create(ar.getAudioSessionId()); if (ns != null) ns.setEnabled(true); } } catch (Throwable ignored) {}
                ar.startRecording();
                short[] buf = new short[FRAME];
                float[] cal = new float[30];                       // 30 × 20 ms = 0,6 s para medir el eco
                int nCal = 0, hits = 0;
                float echo = -90f;
                while (run) {
                    int n = ar.read(buf, 0, FRAME);
                    if (n <= 0) continue;
                    double sum = 0;
                    for (int i = 0; i < n; i++) sum += (double) buf[i] * buf[i];
                    float db = (float) (10 * Math.log10(sum / n / (32768.0 * 32768.0) + 1e-12));
                    if (nCal < cal.length) {                       // calibrar con su propia voz
                        cal[nCal++] = db;
                        if (nCal == cal.length) {
                            float[] c2 = cal.clone();
                            java.util.Arrays.sort(c2);
                            echo = c2[(int) (c2.length * 0.8f)];   // percentil 80: los picos de su voz
                        }
                        continue;
                    }
                    if (db < echo - 3) echo = echo * 0.98f + db * 0.02f;   // si baja el eco, se adapta despacio
                    boolean voice = db > floor && db > echo + margin;
                    // sube con cada tramo de voz y baja con cada silencio: aguanta las pausas entre sílabas
                    hits = voice ? hits + 1 : Math.max(0, hits - 1);
                    if (hits >= 15) {                              // ~0,3 s de voz clara por encima de ella
                        run = false;
                        main.post(onUser);
                        break;
                    }
                }
            } catch (Throwable ignored) {
                // sin permiso o micro ocupado: simplemente no se puede interrumpir hablando
            } finally {
                try { if (ar != null) { ar.stop(); ar.release(); } } catch (Throwable ignored) {}
                try { if (aec != null) aec.release(); } catch (Throwable ignored) {}
                try { if (ns != null) ns.release(); } catch (Throwable ignored) {}
            }
        }, "barge-in");
        th.start();
    }

    void stop() {
        run = false;
        Thread t = th;
        th = null;
        if (t != null) try { t.join(300); } catch (InterruptedException ignored) {}
    }
}
