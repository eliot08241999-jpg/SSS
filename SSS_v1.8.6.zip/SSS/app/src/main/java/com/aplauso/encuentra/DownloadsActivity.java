package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** v1.8.2 · ⬇ Pantalla del gestor de descargas (ver Downloads). También recibe enlaces compartidos desde otras apps. */
public class DownloadsActivity extends NeonActivity {
    final Handler h = new Handler(Looper.getMainLooper());
    LinearLayout listBox;
    TextView quotaBtn, timeBtn, wifiBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("⬇ DESCARGAS");
        LinearLayout a = panel(null);
        EditText url = new EditText(this);
        url.setHint(L.t("Pega un enlace (https://…)"));
        url.setTextColor(Color.WHITE); url.setHintTextColor(Color.GRAY); url.setSingleLine(true);
        url.setBackground(frame(10)); url.setPadding(dpi(10), dpi(8), dpi(10), dpi(8));
        a.addView(url, gapBelow(6));
        a.addView(button("➕ AÑADIR A LA COLA", v -> {
            String u = url.getText().toString().trim();
            if (!u.matches("(?i)^https?://\\S+")) { toast(L.t("Eso no parece un enlace.")); return; }
            if (u.matches("(?i).*(youtube\\.com|youtu\\.be).*")) { toast(L.t("De YouTube no descargo.")); return; }
            Downloads.add(this, u, p.getBoolean("dl_wifi", false));
            url.setText("");
            fill();
        }), gapBelow(6));
        wifiBtn = button("", v -> { p.edit().putBoolean("dl_wifi", !p.getBoolean("dl_wifi", false)).apply(); refresh(); });
        a.addView(wifiBtn, gapBelow(4));
        quotaBtn = button("", v -> pickQuota());
        a.addView(quotaBtn, gapBelow(4));
        timeBtn = button("", v -> pickTime());
        a.addView(timeBtn);
        col.addView(a, gapBelow(10));
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        col.addView(listBox);
        String shared = getIntent().getStringExtra(Intent.EXTRA_TEXT);
        if (shared != null) { java.util.regex.Matcher m = java.util.regex.Pattern.compile("https?://\\S+").matcher(shared); if (m.find()) url.setText(m.group()); }
        refresh();
    }

    void refresh() {
        wifiBtn.setText(p.getBoolean("dl_wifi", false) ? L.t("📶 Solo con Wi-Fi: sí") : L.t("📶 Solo con Wi-Fi: no"));
        long q = p.getLong("dl_quota_mb", 0);
        quotaBtn.setText(L.t("📊 Límite al día: ") + (q == 0 ? L.t("sin límite") : (q >= 1024 ? (q / 1024) + " GB" : q + " MB")) + "  ·  " + L.t("hoy") + " " + (Downloads.usedToday(this) >> 20) + " MB");
        int at = p.getInt("dl_at", -1);
        timeBtn.setText(L.t("⏰ Empezar sola a una hora: ") + (at < 0 ? L.t("no") : String.format(java.util.Locale.ROOT, "%02d:%02d", at / 60, at % 60)));
        fill();
    }

    void pickQuota() {
        String[] o = {L.t("Sin límite"), "500 MB", "1 GB", "2 GB", "5 GB", "10 GB"};
        long[] v = {0, 500, 1024, 2048, 5120, 10240};
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Pausar al llegar a…")).setItems(o, (d, w) -> { p.edit().putLong("dl_quota_mb", v[w]).apply(); refresh(); }).show();
    }

    void pickTime() {
        String[] o = {L.t("No"), "00:00", "01:00", "02:00", "03:00", "06:00", L.t("Otra hora…")};
        new android.app.AlertDialog.Builder(this).setItems(o, (d, w) -> {
            if (w == 0) Downloads.schedule(this, -1);
            else if (w < 6) Downloads.schedule(this, Integer.parseInt(o[w].substring(0, 2)) * 60);
            else { new android.app.TimePickerDialog(this, (tp, hh, mm) -> { Downloads.schedule(this, hh * 60 + mm); refresh(); }, 2, 0, true).show(); return; }
            refresh();
        }).show();
    }

    final Runnable tick = new Runnable() { @Override public void run() { fill(); h.postDelayed(this, 1000); } };
    @Override protected void onResume() { super.onResume(); h.post(tick); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tick); }

    void fill() {
        listBox.removeAllViews();
        List<Downloads.Item> l = Downloads.list(this);
        if (l.isEmpty()) { listBox.addView(text("La cola está vacía. Pega un enlace arriba, o comparte un enlace con Chloe Nova desde otra app.", 12)); return; }
        for (int i = l.size() - 1; i >= 0; i--) {
            Downloads.Item it = l.get(i);
            LinearLayout c = panel(null);
            c.addView(neonText(it.name, 14));
            String st = it.state.equals("running") ? "⬇ " + L.t("Descargando") + " · " + (Downloads.speed >> 10) + " KB/s"
                    : it.state.equals("paused") ? "⏸ " + L.t("En pausa") : it.state.equals("waiting") ? "⏳ " + L.t("Esperando") : it.state.equals("done") ? "✅ " + L.t("Terminada (Descargas/Chloe Nova)")
                    : it.state.equals("error") ? "⚠ " + L.t("Error") : "🕒 " + L.t("En cola");
            TextView t = text(st + " · " + (it.done >> 20) + (it.size > 0 ? " / " + (it.size >> 20) + " MB (" + (it.done * 100 / Math.max(1, it.size)) + " %)" : " MB")
                    + (it.error.isEmpty() || it.state.equals("done") ? "" : "\n" + it.error), 11);
            t.setTextColor(Color.rgb(170, 180, 200));
            c.addView(t);
            LinearLayout r = new LinearLayout(this);
            if (!it.state.equals("done")) {
                boolean paused = it.state.equals("paused");
                r.addView(button(paused ? "▶ " + L.t("SEGUIR") : "⏸ " + L.t("PAUSAR"), v -> {
                    Downloads.Item cur = Downloads.find(this, it.id); if (cur == null) return;
                    cur.state = paused ? "queued" : "paused"; cur.waitUntil = 0; Downloads.update(this, cur);
                    if (paused) Downloads.kick(this);
                    fill();
                }), new LinearLayout.LayoutParams(0, -2, 1));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.leftMargin = dpi(6);
            r.addView(button("🗑 " + L.t("QUITAR"), v -> {
                List<Downloads.Item> all = Downloads.list(this);
                all.removeIf(x -> x.id.equals(it.id));
                Downloads.save(this, all);
                Downloads.part(this, it).delete();
                fill();
            }), lp);
            c.addView(r);
            listBox.addView(c, gapBelow(8));
        }
    }
}
