package com.aplauso.encuentra;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.IBinder;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * v1.8.2 · ⬇ GESTOR DE DESCARGAS: cola, pausar y seguir donde iba (aunque se corte o cierres la app), solo con Wi-Fi,
 * límite de datos al día (se pausa al llegar y sigue al día siguiente), y si el servidor dice «cupo agotado» (429/509)
 * espera y vuelve a intentarlo solo. Rutina: empezar a una hora (p. ej. de noche). Lo terminado va a Descargas/Chloe Nova.
 */
public class Downloads extends Service {
    static final String CH = "gestor_descargas";
    static final int NID = 74;

    public static final class Item {
        public String id, url, name, state = "queued", error = "";      // queued · running · paused · waiting · done · error
        public long size = -1, done, waitUntil;
        public boolean wifiOnly;
        JSONObject json() throws Exception {
            return new JSONObject().put("id", id).put("url", url).put("name", name).put("state", state).put("error", error).put("size", size).put("done", done)
                    .put("waitUntil", waitUntil).put("wifi", wifiOnly);
        }
        static Item from(JSONObject o) {
            Item i = new Item();
            i.id = o.optString("id"); i.url = o.optString("url"); i.name = o.optString("name"); i.state = o.optString("state", "queued"); i.error = o.optString("error");
            i.size = o.optLong("size", -1); i.done = o.optLong("done"); i.waitUntil = o.optLong("waitUntil"); i.wifiOnly = o.optBoolean("wifi");
            return i;
        }
    }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    static synchronized List<Item> list(Context c) {
        List<Item> l = new ArrayList<>();
        try { JSONArray a = new JSONArray(prefs(c).getString("dl_items", "[]")); for (int i = 0; i < a.length(); i++) l.add(Item.from(a.getJSONObject(i))); } catch (Exception ignored) {}
        return l;
    }

    static synchronized void save(Context c, List<Item> l) {
        try { JSONArray a = new JSONArray(); for (Item i : l) a.put(i.json()); prefs(c).edit().putString("dl_items", a.toString()).apply(); } catch (Exception ignored) {}
    }

    static synchronized void update(Context c, Item it) {
        List<Item> l = list(c);
        for (int i = 0; i < l.size(); i++) if (l.get(i).id.equals(it.id)) l.set(i, it);
        save(c, l);
    }

    static File part(Context c, Item it) { return new File(new File(c.getFilesDir(), "dl"), it.id + ".part"); }

    static void add(Context c, String url, boolean wifiOnly) {
        Item it = new Item();
        it.id = Long.toString(System.currentTimeMillis(), 36);
        it.url = url.trim();
        String nm = Uri.parse(it.url).getLastPathSegment();
        it.name = nm == null || nm.isEmpty() ? "descarga_" + it.id : Uri.decode(nm);
        it.wifiOnly = wifiOnly;
        List<Item> l = list(c); l.add(it); save(c, l);
        kick(c);
    }

    static void kick(Context c) {
        Intent i = new Intent(c, Downloads.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static volatile boolean running, stopNow;
    static volatile String activeId;
    static volatile long speed;

    // límite diario de datos
    static long quotaBytes(Context c) { return prefs(c).getLong("dl_quota_mb", 0) << 20; }
    static String today() { return new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.ROOT).format(new java.util.Date()); }
    static long usedToday(Context c) { return today().equals(prefs(c).getString("dl_day", "")) ? prefs(c).getLong("dl_used", 0) : 0; }
    static void addUsed(Context c, long n) { prefs(c).edit().putString("dl_day", today()).putLong("dl_used", usedToday(c) + n).apply(); }

    static boolean onWifi(Context c) {
        ConnectivityManager cm = c.getSystemService(ConnectivityManager.class);
        NetworkCapabilities nc = cm == null ? null : cm.getNetworkCapabilities(cm.getActiveNetwork());
        return nc != null && (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
    }

    /** Rutina: empezar la cola a una hora (minutos desde medianoche; −1 = apagado). */
    static void schedule(Context c, int minutes) {
        prefs(c).edit().putInt("dl_at", minutes).apply();
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent pi = PendingIntent.getForegroundService(c, 77, new Intent(c, Downloads.class).setAction("timer"), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        am.cancel(pi);
        if (minutes < 0) return;
        java.util.Calendar k = java.util.Calendar.getInstance();
        k.set(java.util.Calendar.HOUR_OF_DAY, minutes / 60); k.set(java.util.Calendar.MINUTE, minutes % 60); k.set(java.util.Calendar.SECOND, 0);
        if (k.getTimeInMillis() <= System.currentTimeMillis()) k.add(java.util.Calendar.DAY_OF_MONTH, 1);
        // exacta si se puede (Android solo deja arrancar el servicio desde alarmas exactas); cada día se vuelve a programar
        if (android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, k.getTimeInMillis(), pi);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, k.getTimeInMillis(), pi);
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH, L.t("Gestor de descargas"), NotificationManager.IMPORTANCE_LOW));
        Notification n = notif(L.t("Descargas"), -1);
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(NID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(NID, n);
        if (intent != null && "timer".equals(intent.getAction())) {           // la rutina: lo pausado por ti vuelve a la cola
            schedule(this, prefs(this).getInt("dl_at", -1));                     // y mañana otra vez
            List<Item> l = list(this);
            for (Item it : l) if (it.state.equals("paused") || it.state.equals("waiting")) { it.state = "queued"; it.waitUntil = 0; }
            save(this, l);
        }
        if (!running) { running = true; stopNow = false; new Thread(this::loop).start(); }
        return START_STICKY;
    }

    Notification notif(String text, int pc) {
        Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        PendingIntent open = PendingIntent.getActivity(this, 78, new Intent(this, DownloadsActivity.class), PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle(L.t("Descargando")).setContentText(text).setContentIntent(open).setOngoing(true);
        if (pc >= 0) b.setProgress(100, pc, false); else b.setProgress(0, 0, true);
        return b.build();
    }

    void loop() {
        try {
            while (!stopNow) {
                Item next = null;
                long now = System.currentTimeMillis(), soonest = Long.MAX_VALUE;
                for (Item it : list(this)) {
                    if (it.state.equals("waiting")) { if (it.waitUntil <= now) { it.state = "queued"; update(this, it); } else soonest = Math.min(soonest, it.waitUntil); }
                    if (it.state.equals("queued") && (!it.wifiOnly || onWifi(this))) { next = it; break; }
                }
                if (next == null) {
                    if (soonest != Long.MAX_VALUE && soonest - now < 6 * 3600_000L) { Thread.sleep(Math.min(60_000, Math.max(2000, soonest - now))); continue; }
                    break;                                                         // nada que hacer
                }
                long q = quotaBytes(this);
                if (q > 0 && usedToday(this) >= q) {                               // límite diario alcanzado: mañana sigue
                    for (Item it : list(this)) if (it.state.equals("queued")) { it.state = "waiting"; it.error = L.t("Límite de datos de hoy alcanzado"); it.waitUntil = tomorrow(); update(this, it); }
                    continue;
                }
                fetch(next);
            }
        } catch (Exception ignored) {}
        running = false;
        activeId = null;
        stopForeground(true);
        stopSelf();
    }

    static long tomorrow() {
        java.util.Calendar k = java.util.Calendar.getInstance();
        k.add(java.util.Calendar.DAY_OF_MONTH, 1); k.set(java.util.Calendar.HOUR_OF_DAY, 0); k.set(java.util.Calendar.MINUTE, 5);
        return k.getTimeInMillis();
    }

    void fetch(Item it) {
        activeId = it.id;
        it.state = "running"; it.error = ""; update(this, it);
        File f = part(this, it);
        f.getParentFile().mkdirs();
        long have = f.exists() ? f.length() : 0;
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(it.url).openConnection();
            con.setInstanceFollowRedirects(true);
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) ChloeNova/1.8.2");
            if (have > 0) con.setRequestProperty("Range", "bytes=" + have + "-");
            con.setConnectTimeout(20000); con.setReadTimeout(30000);
            int code = con.getResponseCode();
            if (code == 429 || code == 509 || code == 503) {                     // cupo / demasiadas: espera y reintenta solo
                long ra = 0; try { ra = Long.parseLong(con.getHeaderField("Retry-After")) * 1000; } catch (Exception ignored) {}
                it.state = "waiting"; it.waitUntil = System.currentTimeMillis() + (ra > 0 ? ra : 30 * 60_000L);
                it.error = L.t("El servidor dice que se acabó el cupo: lo reintento solo a las") + " " + new java.text.SimpleDateFormat("HH:mm").format(new java.util.Date(it.waitUntil));
                update(this, it); return;
            }
            if (code >= 400) throw new Exception("HTTP " + code);
            if (have > 0 && code != 206) { have = 0; f.delete(); }                // no admite seguir: empieza de nuevo
            String cd = con.getHeaderField("Content-Disposition");
            if (cd != null) { java.util.regex.Matcher m = java.util.regex.Pattern.compile("filename\\*?=(?:UTF-8'')?\"?([^\";]+)").matcher(cd); if (m.find()) it.name = Uri.decode(m.group(1)); }
            long len = con.getContentLengthLong();
            if (len > 0) it.size = have + len;
            update(this, it);
            try (InputStream in = con.getInputStream(); RandomAccessFile raf = new RandomAccessFile(f, "rw")) {
                raf.seek(have);
                byte[] b = new byte[1 << 16];
                long t0 = System.currentTimeMillis(), lastSave = t0, got0 = have, acc = 0;
                int k;
                long q = quotaBytes(this);
                while ((k = in.read(b)) > 0) {
                    raf.write(b, 0, k);
                    have += k; acc += k;
                    long now = System.currentTimeMillis();
                    if (now - lastSave > 1000) {
                        speed = (have - got0) * 1000 / Math.max(1, now - t0);
                        it.done = have; addUsed(this, acc); acc = 0;
                        Item cur = find(this, it.id);
                        if (cur == null || cur.state.equals("paused")) { if (cur != null) { cur.done = have; update(this, cur); } return; }   // lo has pausado o borrado
                        update(this, it);
                        getSystemService(NotificationManager.class).notify(NID, notif(it.name + " · " + (have >> 20) + (it.size > 0 ? " / " + (it.size >> 20) : "") + " MB",
                                it.size > 0 ? (int) (have * 100 / it.size) : -1));
                        lastSave = now;
                        if (q > 0 && usedToday(this) >= q) { it.state = "waiting"; it.waitUntil = tomorrow(); it.error = L.t("Límite de datos de hoy alcanzado"); update(this, it); return; }
                        if (it.wifiOnly && !onWifi(this)) { it.state = "queued"; it.error = L.t("Esperando Wi-Fi"); update(this, it); return; }
                        if (stopNow) { it.state = "paused"; update(this, it); return; }
                    }
                }
                addUsed(this, acc);
            }
            it.done = have;
            if (it.size > 0 && have < it.size) throw new Exception(L.t("se cortó"));
            publish(it, f);
            it.state = "done"; it.error = "";
            update(this, it);
        } catch (Exception e) {
            Item cur = find(this, it.id);
            if (cur == null) return;
            cur.done = f.exists() ? f.length() : 0;
            cur.state = "waiting"; cur.waitUntil = System.currentTimeMillis() + 60_000;    // se reintenta en un minuto, sigue donde iba
            cur.error = L.t("Error") + ": " + e.getMessage() + " · " + L.t("reintento en 1 min");
            update(this, cur);
        } finally { if (con != null) con.disconnect(); activeId = null; }
    }

    static Item find(Context c, String id) { for (Item i : list(c)) if (i.id.equals(id)) return i; return null; }

    /** A Descargas/Chloe Nova (lo ve cualquier app). */
    void publish(Item it, File f) throws Exception {
        String mime = java.net.URLConnection.guessContentTypeFromName(it.name);
        if (mime == null) mime = "application/octet-stream";
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, it.name);
            v.put(MediaStore.Downloads.MIME_TYPE, mime);
            v.put(MediaStore.Downloads.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/Chloe Nova");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new Exception(L.t("no se pudo guardar"));
            try (OutputStream o = getContentResolver().openOutputStream(u); InputStream in = new java.io.FileInputStream(f)) {
                byte[] b = new byte[1 << 16]; int k; while ((k = in.read(b)) > 0) o.write(b, 0, k);
            }
        } else {
            File d = new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "Chloe Nova");
            d.mkdirs();
            java.nio.file.Files.copy(f.toPath(), new File(d, it.name).toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
        f.delete();
    }
}
