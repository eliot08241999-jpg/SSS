package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * v1.8.2 · 🎚 QUITAR LA VOZ (KARAOKE), método clásico y rápido: la voz suele ir en el centro del estéreo, así que se
 * resta un canal del otro y se devuelven los graves (bajo y bombo). Saca dos pistas: «sin voz» y «voz aproximada».
 * No es una IA de separación: funciona bien en canciones de estudio con voz centrada; en directos o mono, poco.
 */
public class KaraokeActivity extends NeonActivity {
    static final int REQ = 71;
    final Handler h = new Handler(Looper.getMainLooper());
    Uri song;
    String name = "cancion";
    TextView info;
    SeekBar bass, strength;
    NeonProgress prog;
    volatile boolean busy;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🎚 QUITAR LA VOZ");
        LinearLayout a = panel(null);
        info = text("Elige una canción en estéreo. Funciona mejor con canciones de estudio donde la voz va en el centro.", 12);
        a.addView(info);
        a.addView(button("🎵 ELEGIR CANCIÓN", v -> PickActivity.start(this, new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE), REQ, "karaoke")), gapBelow(6));
        TextView t1 = text("Cuánta voz quitar", 11); a.addView(t1);
        strength = new SeekBar(this); strength.setMax(100); strength.setProgress(100); a.addView(strength, gapBelow(4));
        TextView t2 = text("Recuperar graves por debajo de (Hz): 80 – 300", 11); a.addView(t2);
        bass = new SeekBar(this); bass.setMax(220); bass.setProgress(90); a.addView(bass, gapBelow(6));
        a.addView(button("▶ SEPARAR (sin voz + voz aproximada)", v -> run()), gapBelow(6));
        prog = new NeonProgress(this);
        a.addView(prog);
        TextView n = text("Se guardan en SSS+/Pistas como WAV. Para sacar acordes y notas, usa 🎼 Transcribir canción.", 11);
        n.setTextColor(Color.rgb(160, 170, 190));
        a.addView(n);
        col.addView(a);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req == REQ && res == RESULT_OK && d != null && d.getData() != null) {
            song = d.getData();
            name = Media.nameOf(this, song).replaceAll("\\.[A-Za-z0-9]{2,4}$", "");
            info.setText("🎵 " + name);
        }
    }

    /** Filtro de un polo (paso bajo) sencillo. */
    static final class LP { float a, y; LP(float fc, int sr) { a = (float) (1 - Math.exp(-2 * Math.PI * fc / sr)); } float f(float x) { y += a * (x - y); return y; } }

    void run() {
        if (song == null) { toast(L.t("Primero elige una canción.")); return; }
        if (busy) return;
        busy = true;
        prog.begin();
        final float k = strength.getProgress() / 100f, fc = 80 + bass.getProgress();
        new Thread(() -> {
            File wav = new File(getCacheDir(), "karaoke_in.wav"), noVox = new File(getCacheDir(), "karaoke_novoz.wav"), vox = new File(getCacheDir(), "karaoke_voz.wav");
            try {
                long dur = MediaTools.durationMs(this, song);
                MediaTools.toWav(this, song, wav, 0, dur > 0 ? dur * 1000L : Long.MAX_VALUE / 4, 1f, 0, 0, f -> h.post(() -> prog.set(L.t("Leyendo la canción"), Math.round(f * 100), 100)));
                try (RandomAccessFile in = new RandomAccessFile(wav, "r"); RandomAccessFile o1 = new RandomAccessFile(noVox, "rw"); RandomAccessFile o2 = new RandomAccessFile(vox, "rw")) {
                    byte[] hdr = new byte[44]; in.readFully(hdr);
                    ByteBuffer hb = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN);
                    int ch = hb.getShort(22), sr = hb.getInt(24);
                    if (ch < 2) throw new Exception(L.t("la canción es mono: no se puede separar la voz así"));
                    long dataLen = in.length() - 44, frames = dataLen / (2L * ch);
                    o1.setLength(0); o2.setLength(0);
                    o1.write(hdr); o2.write(hdr);
                    LP lpMid = new LP(fc, sr), hpVoxLo = new LP(180, sr), lpVoxHi = new LP(5000, sr);
                    byte[] buf = new byte[4096 * 2 * ch], ob1 = new byte[4096 * 4], ob2 = new byte[4096 * 4];
                    long done = 0;
                    while (done < frames) {
                        int n = (int) Math.min(4096, frames - done);
                        in.readFully(buf, 0, n * 2 * ch);
                        ByteBuffer bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
                        ByteBuffer w1 = ByteBuffer.wrap(ob1).order(ByteOrder.LITTLE_ENDIAN), w2 = ByteBuffer.wrap(ob2).order(ByteOrder.LITTLE_ENDIAN);
                        for (int i = 0; i < n; i++) {
                            float l = bb.getShort(i * 2 * ch) / 32768f, r = bb.getShort(i * 2 * ch + 2) / 32768f;
                            float mid = (l + r) / 2, side = (l - r) / 2;
                            float bassMid = lpMid.f(mid);
                            float vocal = mid - bassMid;                                     // centro sin graves ≈ voz (+ lo que va en el centro)
                            vocal = lpVoxHi.f(vocal - hpVoxLo.f(vocal));
                            float L1 = l - k * vocal, R1 = r - k * vocal;                   // sin voz: quita el centro, deja graves y lados
                            float v1 = vocal * (1 - Math.min(1, Math.abs(side) * 3));        // voz aproximada
                            w1.putShort(i * 4, (short) Math.max(-32768, Math.min(32767, Math.round(L1 * 32767))));
                            w1.putShort(i * 4 + 2, (short) Math.max(-32768, Math.min(32767, Math.round(R1 * 32767))));
                            short sv = (short) Math.max(-32768, Math.min(32767, Math.round(v1 * 32767 * 1.4f)));
                            w2.putShort(i * 4, sv); w2.putShort(i * 4 + 2, sv);
                        }
                        o1.write(ob1, 0, n * 4); o2.write(ob2, 0, n * 4);
                        done += n;
                        if ((done / 4096) % 50 == 0) { final long dd = done; h.post(() -> prog.set(L.t("Separando"), (int) (dd * 100 / frames), 100)); }
                    }
                    for (RandomAccessFile o : new RandomAccessFile[]{o1, o2}) MediaTools.writeWavHeader(o, sr, 2, frames * 4);
                }
                Uri a = Media.saveOwn(this, noVox, "Pistas", name + "_sin_voz.wav", "audio/wav");
                Uri b = Media.saveOwn(this, vox, "Pistas", name + "_voz.wav", "audio/wav");
                h.post(() -> { busy = false; prog.hide(); toast(a != null ? L.t("Listo: guardadas en SSS+/Pistas.") : L.t("No se pudo guardar.")); });
            } catch (Throwable e) {
                h.post(() -> { busy = false; prog.hide(); toast(L.t("No se pudo separar") + ": " + e.getMessage()); });
            } finally { wav.delete(); }
        }).start();
    }
}
