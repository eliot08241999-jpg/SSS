package com.aplauso.encuentra;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** v1.8 · 🎼 Armónica: de notas a tabs (con el tono que necesita menos bends), practicar con el micrófono y calibrar TU armónica. */
public class HarmonicaActivity extends NeonActivity {
    final Handler h = new Handler(Looper.getMainLooper());
    final MusicAudio.PitchDetector det = new MusicAudio.PitchDetector();
    EditText in;
    TextView harpBtn, modeBtn, result, status;
    MusicViews.Harmonica hv;
    boolean easiest = true;
    MusicTheory.HarpPlan plan;
    List<Integer> melody;
    int practiceIdx = -1;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🎼 ARMÓNICA");
        LinearLayout a = panel("◢ LA MELODÍA");
        a.addView(text("Escribe las notas separadas por espacios: «Do Do Re Do Fa Mi» o «C4 C4 D4 C4 F4 E4». Sin número de octava, la app elige la más cercana a la nota anterior.", 12));
        in = new EditText(this);
        in.setTextColor(Color.WHITE);
        in.setHintTextColor(Color.GRAY);
        in.setHint("Do Do Re Do Fa Mi");
        in.setBackground(frame(10));
        in.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        in.setMinLines(2);
        in.setText(p.getString("harp_last", ""));
        a.addView(in, gapBelow(8));
        harpBtn = button("", v -> pickHarp());
        a.addView(harpBtn, gapBelow(6));
        modeBtn = button("", v -> { easiest = !easiest; refresh(); convert(); });
        a.addView(modeBtn, gapBelow(6));
        a.addView(button("🎼 PASAR A TABS", v -> convert()), gapBelow(4));
        col.addView(a, gapBelow(12));

        LinearLayout r = panel("◢ TABS");
        hv = new MusicViews.Harmonica(this);
        r.addView(hv, gapBelow(8));
        result = text("", 16);
        result.setTypeface(Typeface.MONOSPACE);
        r.addView(result, gapBelow(6));
        status = text("4 = soplar en el agujero 4 · -4 = aspirar · ' = bend (doblar la nota medio tono; '' un tono)", 11);
        status.setTextColor(Color.rgb(160, 170, 190));
        r.addView(status, gapBelow(8));
        r.addView(button("▶ ESCUCHAR", v -> play()), gapBelow(6));
        r.addView(button("🎯 PRACTICAR (te escucho nota a nota)", v -> practice()), gapBelow(6));
        r.addView(button("📒 PASAR AL CANCIONERO", v -> toSongbook()));
        col.addView(r, gapBelow(12));

        LinearLayout c = panel("◢ 🎯 CALIBRAR CON MI ARMÓNICA");
        c.addView(text("Tocas cada agujero (soplar y aspirar) y apunto qué nota da de verdad. Así las tabs salen exactas para tu armónica, también si es una Melody Maker u otra afinación.", 12));
        c.addView(button("🎤 EMPEZAR A CALIBRAR", v -> calibrate()));
        col.addView(c, gapBelow(12));
        refresh();
        if (!in.getText().toString().trim().isEmpty()) convert();
    }

    MusicTheory.Harp harp() { return MusicTheory.harp(this, p.getString("mus_harp", "harp_c")); }

    void refresh() {
        harpBtn.setText("🎼 " + L.t(harp().name) + "  ▾");
        modeBtn.setText(easiest ? L.t("Tono: el más fácil (menos bends)") : L.t("Tono: tal cual (solo cambia de octava)"));
    }

    void pickHarp() {
        List<String[]> l = MusicTheory.harps(this);
        String[] n = new String[l.size()];
        for (int i = 0; i < n.length; i++) n[i] = L.t(l.get(i)[1]);
        new android.app.AlertDialog.Builder(this).setItems(n, (d, w) -> { p.edit().putString("mus_harp", l.get(w)[0]).apply(); refresh(); convert(); }).show();
    }

    void convert() {
        String t = in.getText().toString().trim();
        p.edit().putString("harp_last", t).apply();
        melody = MusicTheory.parseMelody(t, MusicTheory.notation(this));
        if (melody.isEmpty()) { result.setText(L.t("Escribe alguna nota.")); return; }
        MusicTheory.Harp hp = harp();
        plan = MusicTheory.bestHarp(hp, melody, easiest);
        MusicTheory.HarpPlan asIs = MusicTheory.bestHarp(hp, melody, false);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < plan.notes.size(); i++) {
            MusicTheory.HarpNote n = plan.notes.get(i);
            sb.append(String.format(java.util.Locale.ROOT, "%-5s", n == null ? "?" : n.tab()));
            if ((i + 1) % 8 == 0) sb.append('\n');
        }
        sb.append("\n\n♪ ");
        for (int m : melody) sb.append(MusicTheory.name(this, m + plan.shift)).append(' ');
        result.setText(sb.toString().trim());
        int key = MusicTheory.mod12(plan.shift);
        String keyMsg = key == 0 ? "" : "\n" + L.t("Movida") + " " + (key > 6 ? "−" + (12 - key) : "+" + key) + " " + L.t("semitonos para que salga más fácil") + " ("
                + L.t("tal cual tendría") + " " + asIs.bends + " " + L.t("bends") + (asIs.missing > 0 ? " " + L.t("y") + " " + asIs.missing + " " + L.t("notas imposibles") : "") + ").";
        status.setText(L.t("Dificultad") + ": " + (plan.missing > 0 ? "⚠ " + plan.missing + " " + L.t("notas no existen en esta armónica (?)")
                : plan.bends == 0 ? "⭐ " + L.t("fácil: solo soplar y aspirar") : plan.bends + " " + L.t("bends")) + keyMsg);
        hv.set(hp, plan.notes.isEmpty() ? null : plan.notes.get(0));
    }

    void play() {
        if (plan == null || melody == null) return;
        double a4 = p.getFloat("tun_a4", 440f);
        new Thread(() -> {
            for (int i = 0; i < melody.size(); i++) {
                final int k = i;
                runOnUiThread(() -> hv.set(harp(), plan.notes.get(k)));
                MusicAudio.playNotes(new int[]{melody.get(i) + plan.shift}, 0, a4);
                try { Thread.sleep(480); } catch (InterruptedException ignored) {}
            }
        }).start();
    }

    boolean mic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) return true;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 8);
        return false;
    }

    void practice() {
        if (plan == null || melody == null || !mic()) return;
        practiceIdx = 0;
        showPractice();
        double a4 = p.getFloat("tun_a4", 440f);
        final long[] since = {0};
        det.start((f, cl, rms) -> {
            if (practiceIdx < 0 || practiceIdx >= melody.size() || f <= 0 || cl < 0.8f) { since[0] = 0; return; }
            int want = melody.get(practiceIdx) + plan.shift;
            float[] nr = MusicAudio.nearest(f, a4);
            long now = android.os.SystemClock.uptimeMillis();
            if ((int) nr[0] == want && Math.abs(nr[1]) < 40) {
                if (since[0] == 0) since[0] = now;
                if (now - since[0] > 250) { since[0] = 0; practiceIdx++; runOnUiThread(this::showPractice); }
            } else {
                since[0] = 0;
                int heard = (int) nr[0];
                runOnUiThread(() -> status.setText("🎤 " + L.t("Oigo") + " " + MusicTheory.noteName(this, heard)
                        + (heard < want ? " · " + L.t("más agudo") : " · " + L.t("más grave"))
                        + (plan.notes.get(practiceIdx) != null && plan.notes.get(practiceIdx).bend > 0 && heard > want ? " · " + L.t("dobla más el bend") : "")));
            }
        });
    }

    void showPractice() {
        if (practiceIdx >= melody.size()) {
            det.stop();
            practiceIdx = -1;
            status.setText("🎉 " + L.t("¡Melodía completa!"));
            return;
        }
        MusicTheory.HarpNote n = plan.notes.get(practiceIdx);
        hv.set(harp(), n);
        status.setText((practiceIdx + 1) + " / " + melody.size() + " · " + L.t("Toca") + ": " + (n == null ? "?" : n.tab())
                + " (" + MusicTheory.noteName(this, melody.get(practiceIdx) + plan.shift) + ")");
    }

    void toSongbook() {
        if (melody == null || melody.isEmpty()) return;
        StringBuilder sb = new StringBuilder("♪ ");
        for (int m : melody) sb.append(MusicTheory.noteName(this, m + plan.shift)).append(' ');
        startActivity(new Intent(this, SongbookActivity.class).putExtra("new_title", "").putExtra("new_text", sb.toString().trim() + "\n"));
    }

    // ------------------------------------------------------------------ calibrar
    int calHole;
    boolean calDraw;
    int[] calBlow, calDrawN;
    float calHz;
    long calSince;

    void calibrate() {
        if (!mic()) return;
        calHole = 0; calDraw = false;
        calBlow = new int[10]; calDrawN = new int[10];
        double a4 = p.getFloat("tun_a4", 440f);
        android.app.AlertDialog d = new android.app.AlertDialog.Builder(this).setTitle(L.t("🎯 Calibrar"))
                .setMessage(prompt()).setNegativeButton(L.t("Cancelar"), (x, w) -> det.stop()).setCancelable(false).create();
        d.show();
        det.start((f, cl, rms) -> {
            if (f <= 0 || cl < 0.85f) { calSince = 0; return; }
            float[] nr = MusicAudio.nearest(f, a4);
            long now = android.os.SystemClock.uptimeMillis();
            if (calSince == 0 || Math.abs(nr[0] - calHz) > 0.5f) { calSince = now; calHz = nr[0]; return; }
            if (now - calSince < 600) return;                 // nota estable más de medio segundo
            calSince = 0;
            int midi = (int) nr[0];
            if (calDraw) calDrawN[calHole] = midi; else calBlow[calHole] = midi;
            if (!calDraw) calDraw = true; else { calDraw = false; calHole++; }
            runOnUiThread(() -> {
                if (calHole >= 10) { det.stop(); d.dismiss(); saveCal(); return; }
                d.setMessage("✔ " + MusicTheory.noteName(this, midi) + "\n\n" + prompt());
            });
            try { Thread.sleep(700); } catch (InterruptedException ignored) {}   // tiempo para cambiar de agujero
        });
    }

    String prompt() { return (calDraw ? "↓ " + L.t("ASPIRA") : "↑ " + L.t("SOPLA")) + " " + L.t("en el agujero") + " " + (calHole + 1) + "  (" + (calHole * 2 + (calDraw ? 2 : 1)) + " / 20)"; }

    void saveCal() {
        EditText e = new EditText(this);
        e.setHint(L.t("Nombre (p. ej. Mi Melody Maker)"));
        StringBuilder sum = new StringBuilder();
        for (int i = 0; i < 10; i++) sum.append(i + 1).append(": ↑").append(MusicTheory.name(this, calBlow[i])).append(" ↓").append(MusicTheory.name(this, calDrawN[i])).append('\n');
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dpi(18), dpi(8), dpi(18), 0);
        TextView t = new TextView(this);
        t.setText(sum.toString());
        t.setTextColor(Color.WHITE);
        box.addView(t);
        box.addView(e);
        new android.app.AlertDialog.Builder(this).setTitle(L.t("✔ Armónica calibrada")).setView(box).setPositiveButton(L.t("Guardar"), (d, w) -> {
            String n = e.getText().toString().replace("\n", " ").replace(";", " ").trim();
            if (n.isEmpty()) n = L.t("Mi armónica");
            StringBuilder b = new StringBuilder(), dr = new StringBuilder();
            for (int i = 0; i < 10; i++) { b.append(i > 0 ? "," : "").append(calBlow[i]); dr.append(i > 0 ? "," : "").append(calDrawN[i]); }
            String names = p.getString("harp_cal_names", "");
            if (!("\n" + names + "\n").contains("\n" + n + "\n")) names = names.isEmpty() ? n : names + "\n" + n;
            p.edit().putString("harp_cal_" + n, b + ";" + dr).putString("harp_cal_names", names).putString("mus_harp", "cal:" + n).apply();
            refresh();
            convert();
        }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    @Override protected void onPause() { super.onPause(); det.stop(); practiceIdx = -1; }
}
