package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * v1.8.2 · 🎵 REPRODUCTOR DE MÚSICA: tu música del teléfono, con cola, aleatorio, repetir, ecualizador, temporizador
 * para dormir y controles en la notificación, la pantalla de bloqueo y los auriculares. Solo archivos que ya tienes.
 */
public class MusicPlayerService extends Service {
    static final String CH = "music_player";
    static final int NID = 73;

    public static final class Track {
        public long id, albumId, dur;
        public String title = "", artist = "", album = "", folder = "", path = "";
        public Uri uri() { return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id); }
    }

    // estado compartido con la pantalla
    static volatile List<Track> queue = new ArrayList<>();
    static volatile int pos = -1, repeat;                    // repeat: 0 no · 1 toda la cola · 2 esta canción
    static volatile boolean playing, running, shuffle;
    static volatile long sleepAt;                              // 0 = sin temporizador; −1 = al acabar esta canción
    static volatile int audioSession;
    static MusicPlayerService inst;
    static final List<Runnable> listeners = new ArrayList<>();

    MediaPlayer mp;
    MediaSession session;
    android.media.audiofx.Equalizer eq;
    android.media.audiofx.BassBoost bass;
    AudioManager am;
    AudioFocusRequest focusReq;
    boolean ducked, pausedByFocus;
    final Handler h = new Handler(Looper.getMainLooper());
    Bitmap art;
    long artFor = -1;

    // ------------------------------------------------------------------ API para la pantalla y Chloe
    static void play(Context c, List<Track> q, int at) {
        queue = new ArrayList<>(q);
        pos = Math.max(0, Math.min(at, queue.size() - 1));
        Intent i = new Intent(c, MusicPlayerService.class).setAction("load");
        if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void send(Context c, String action) {
        if (!running && !"resume_last".equals(action)) return;
        Intent i = new Intent(c, MusicPlayerService.class).setAction(action);
        if (!running && android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static Track current() { List<Track> q = queue; int p = pos; return p >= 0 && p < q.size() ? q.get(p) : null; }
    static int position() { MusicPlayerService s = inst; try { return s != null && s.mp != null ? s.mp.getCurrentPosition() : 0; } catch (Exception e) { return 0; } }
    static int duration() { MusicPlayerService s = inst; try { return s != null && s.mp != null ? s.mp.getDuration() : 0; } catch (Exception e) { return 0; } }
    static void seek(int ms) { MusicPlayerService s = inst; if (s != null && s.mp != null) try { s.mp.seekTo(ms); s.update(); } catch (Exception ignored) {} }
    static void changed() { for (Runnable r : new ArrayList<>(listeners)) r.run(); }

    static void addNext(Track t) { if (pos < 0) { queue = new ArrayList<>(Collections.singletonList(t)); return; } List<Track> q = new ArrayList<>(queue); q.add(Math.min(q.size(), pos + 1), t); queue = q; changed(); }
    static void addEnd(Track t) { List<Track> q = new ArrayList<>(queue); q.add(t); queue = q; changed(); }

    // ------------------------------------------------------------------ biblioteca (MediaStore)
    static List<Track> library(Context c) {
        List<Track> l = new ArrayList<>();
        String[] col = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATA};
        String sel = MediaStore.Audio.Media.IS_MUSIC + "!=0 AND " + MediaStore.Audio.Media.DURATION + ">=20000";
        try (Cursor cu = c.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, col, sel, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE")) {
            if (cu != null) while (cu.moveToNext()) {
                Track t = new Track();
                t.id = cu.getLong(0);
                t.title = nz(cu.getString(1));
                t.artist = nz(cu.getString(2)); if (t.artist.equals("<unknown>")) t.artist = "";
                t.album = nz(cu.getString(3));
                t.albumId = cu.getLong(4);
                t.dur = cu.getLong(5);
                t.path = nz(cu.getString(6));
                int k = t.path.lastIndexOf('/');
                String dir = k > 0 ? t.path.substring(0, k) : "";
                t.folder = dir.substring(dir.lastIndexOf('/') + 1);
                l.add(t);
            }
        } catch (Exception ignored) {}
        return l;
    }

    static String nz(String s) { return s == null ? "" : s; }

    static Bitmap artOf(Context c, Track t, int size) {
        if (t == null) return null;
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) return c.getContentResolver().loadThumbnail(t.uri(), new android.util.Size(size, size), null);
        } catch (Exception ignored) {}
        try {
            android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
            r.setDataSource(c, t.uri());
            byte[] b = r.getEmbeddedPicture();
            r.release();
            if (b != null) return android.graphics.BitmapFactory.decodeByteArray(b, 0, b.length);
        } catch (Exception ignored) {}
        return null;
    }

    // ------------------------------------------------------------------ servicio
    @Override public IBinder onBind(Intent i) { return null; }

    final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { if (playing) pause(); }    // se desenchufan los auriculares
    };

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        am = getSystemService(AudioManager.class);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH, L.t("Reproductor de música"), NotificationManager.IMPORTANCE_LOW));
        session = new MediaSession(this, "chloe-musica");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { next(true); }
            @Override public void onSkipToPrevious() { prev(); }
            @Override public void onStop() { close(); }
            @Override public void onSeekTo(long ms) { seek((int) ms); }
            @Override public void onCustomAction(String a, android.os.Bundle b) { if ("close".equals(a)) close(); }
        });
        session.setActive(true);
        registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? "" : String.valueOf(intent.getAction());
        running = true;
        startFg();
        switch (a) {
            case "load": load(true); break;
            case "toggle": if (playing) pause(); else resume(); break;
            case "next": next(true); break;
            case "prev": prev(); break;
            case "stop": case "close": close(); break;
            case "resume_last": if (queue.isEmpty()) restore(); if (mp == null) load(true); else resume(); break;
        }
        return START_NOT_STICKY;
    }

    void startFg() {
        Notification n = build();
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(NID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NID, n);
    }

    void load(boolean start) {
        Track t = current();
        if (t == null) { close(); return; }
        releasePlayer();
        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setDataSource(this, t.uri());
            mp.setOnCompletionListener(m -> onDone());
            mp.setOnErrorListener((m, w, x) -> { h.postDelayed(() -> next(false), 300); return true; });
            mp.prepare();
            audioSession = mp.getAudioSessionId();
            applyFx();
            int resumeAt = getSharedPreferences("cfg", MODE_PRIVATE).getInt("mp_resume_ms", 0);
            if (resumeAt > 0 && getSharedPreferences("cfg", MODE_PRIVATE).getLong("mp_resume_id", -1) == t.id) mp.seekTo(resumeAt);
            getSharedPreferences("cfg", MODE_PRIVATE).edit().remove("mp_resume_ms").apply();
            if (start && focus()) { mp.start(); playing = true; Achievements.used(this, "music"); }
            else playing = false;
        } catch (Exception e) {
            playing = false;
            h.postDelayed(() -> next(false), 300);
        }
        save();
        update();
        changed();
    }

    void releasePlayer() {
        if (eq != null) try { eq.release(); } catch (Exception ignored) {}
        if (bass != null) try { bass.release(); } catch (Exception ignored) {}
        eq = null; bass = null;
        if (mp != null) try { mp.release(); } catch (Exception ignored) {}
        mp = null;
    }

    boolean focus() {
        AudioManager.OnAudioFocusChangeListener l = ch -> {
            if (ch == AudioManager.AUDIOFOCUS_LOSS) { pausedByFocus = false; pause(); }
            else if (ch == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) { if (playing) { pausedByFocus = true; pause(); } }
            else if (ch == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) { if (mp != null) { mp.setVolume(0.25f, 0.25f); ducked = true; } }
            else if (ch == AudioManager.AUDIOFOCUS_GAIN) {
                if (ducked && mp != null) { mp.setVolume(1f, 1f); ducked = false; }
                if (pausedByFocus) { pausedByFocus = false; resume(); }
            }
        };
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()).setOnAudioFocusChangeListener(l).build();
            return am.requestAudioFocus(focusReq) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        }
        return am.requestAudioFocus(l, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    void onDone() {
        if (sleepAt == -1) { sleepAt = 0; pause(); changed(); return; }        // temporizador: «al acabar esta canción»
        if (repeat == 2) { mp.seekTo(0); mp.start(); return; }
        next(false);
    }

    void pause() {
        if (mp != null && playing) try { mp.pause(); } catch (Exception ignored) {}
        playing = false;
        save();
        update();
        changed();
        if (android.os.Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);   // en pausa se puede quitar deslizando
    }

    void resume() {
        if (mp == null) { load(true); return; }
        if (!focus()) return;
        startFg();
        try { mp.start(); playing = true; } catch (Exception e) { load(true); return; }
        update();
        changed();
    }

    void next(boolean user) {
        List<Track> q = queue;
        if (q.isEmpty()) { close(); return; }
        if (shuffle && q.size() > 1) { int n; do n = new Random().nextInt(q.size()); while (n == pos); pos = n; }
        else if (pos + 1 < q.size()) pos++;
        else if (repeat == 1 || user) pos = 0;
        else { pos = 0; load(false); pause(); return; }                 // fin de la cola
        load(true);
    }

    void prev() {
        if (mp != null && mp.getCurrentPosition() > 4000) { mp.seekTo(0); update(); return; }
        if (pos > 0) pos--; else pos = Math.max(0, queue.size() - 1);
        load(true);
    }

    void close() {
        save();
        playing = false;
        running = false;
        releasePlayer();
        if (focusReq != null && android.os.Build.VERSION.SDK_INT >= 26) am.abandonAudioFocusRequest(focusReq);
        stopForeground(true);
        changed();
        stopSelf();
    }

    // ---- ecualizador: preajustes del propio Android + refuerzo de graves
    void applyFx() {
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        try {
            eq = new android.media.audiofx.Equalizer(0, audioSession);
            int preset = p.getInt("mp_eq", -1);
            if (preset >= 0 && preset < eq.getNumberOfPresets()) { eq.usePreset((short) preset); eq.setEnabled(true); }
            else eq.setEnabled(false);
        } catch (Throwable ignored) { eq = null; }
        try {
            int b = p.getInt("mp_bass", 0);
            bass = new android.media.audiofx.BassBoost(0, audioSession);
            if (b > 0 && bass.getStrengthSupported()) { bass.setStrength((short) Math.min(1000, b)); bass.setEnabled(true); }
            else bass.setEnabled(false);
        } catch (Throwable ignored) { bass = null; }
    }

    static String[] presets() {
        MusicPlayerService s = inst;
        if (s == null || s.eq == null) return new String[0];
        try {
            String[] n = new String[s.eq.getNumberOfPresets()];
            for (short i = 0; i < n.length; i++) n[i] = s.eq.getPresetName(i);
            return n;
        } catch (Throwable e) { return new String[0]; }
    }

    static void refx(Context c) { MusicPlayerService s = inst; if (s != null && s.mp != null) { if (s.eq != null) try { s.eq.release(); } catch (Exception ignored) {} if (s.bass != null) try { s.bass.release(); } catch (Exception ignored) {} s.applyFx(); } }

    // ---- temporizador para dormir
    final Runnable sleepTick = new Runnable() {
        @Override public void run() {
            if (sleepAt > 0 && System.currentTimeMillis() >= sleepAt) {
                sleepAt = 0;
                if (mp != null && playing) {                         // baja el volumen poco a poco antes de parar
                    final float[] v = {1f};
                    h.post(new Runnable() { @Override public void run() {
                        v[0] -= 0.05f;
                        if (mp == null) return;
                        if (v[0] <= 0) { pause(); try { mp.setVolume(1f, 1f); } catch (Exception ignored) {} return; }
                        try { mp.setVolume(v[0], v[0]); } catch (Exception ignored) {}
                        h.postDelayed(this, 300);
                    }});
                }
                changed();
            }
            if (running) h.postDelayed(this, 5000);
        }
    };

    static void setSleep(long at) { sleepAt = at; MusicPlayerService s = inst; if (s != null) { s.h.removeCallbacks(s.sleepTick); s.h.post(s.sleepTick); } changed(); }

    // ---- recordar dónde ibas
    void save() {
        Track t = current();
        if (t == null) return;
        StringBuilder ids = new StringBuilder();
        List<Track> q = queue;
        for (int i = 0; i < q.size() && i < 2000; i++) ids.append(q.get(i).id).append(',');
        int at = 0; try { if (mp != null) at = mp.getCurrentPosition(); } catch (Exception ignored) {}
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("mp_queue", ids.toString()).putInt("mp_pos", pos)
                .putLong("mp_resume_id", t.id).putInt("mp_resume_ms", at).apply();
    }

    void restore() {
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        List<Track> lib = library(this);
        java.util.Map<Long, Track> by = new java.util.HashMap<>();
        for (Track t : lib) by.put(t.id, t);
        List<Track> q = new ArrayList<>();
        for (String s : p.getString("mp_queue", "").split(",")) try { Track t = by.get(Long.parseLong(s)); if (t != null) q.add(t); } catch (Exception ignored) {}
        if (q.isEmpty()) { q = lib; Collections.shuffle(q); shuffle = true; }
        queue = q;
        pos = Math.max(0, Math.min(p.getInt("mp_pos", 0), q.size() - 1));
    }

    // ------------------------------------------------------------------ notificación y sesión
    void update() {
        Track t = current();
        if (t == null) return;
        if (artFor != t.id) { art = artOf(this, t, 256); artFor = t.id; }
        long dur = 0; int at = 0;
        try { if (mp != null) { dur = mp.getDuration(); at = mp.getCurrentPosition(); } } catch (Exception ignored) {}
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT
                        | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO)
                .addCustomAction(new PlaybackState.CustomAction.Builder("close", L.t("Cerrar"), android.R.drawable.ic_menu_close_clear_cancel).build())
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, at, playing ? 1f : 0f).build());
        MediaMetadata.Builder mb = new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, t.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, t.artist)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, t.album)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, dur);
        if (art != null) mb.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art);
        session.setMetadata(mb.build());
        getSystemService(NotificationManager.class).notify(NID, build());
    }

    PendingIntent act(String a, int rc) {
        return PendingIntent.getService(this, rc, new Intent(this, MusicPlayerService.class).setAction(a), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    Notification build() {
        Track t = current();
        Intent open = new Intent(this, MusicPlayerActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 11, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(t == null ? L.t("Mi música") : t.title)
                .setContentText(t == null ? "" : t.artist)
                .setContentIntent(content)
                .setDeleteIntent(act("close", 16))
                .setOngoing(playing)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous, L.t("Anterior"), act("prev", 12)).build())
                .addAction(new Notification.Action.Builder(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, playing ? L.t("Pausa") : L.t("Seguir"), act("toggle", 13)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next, L.t("Siguiente"), act("next", 14)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "✕ " + L.t("Cerrar"), act("close", 15)).build())
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
        if (art != null) b.setLargeIcon(art);
        return b.build();
    }

    @Override
    public void onTaskRemoved(Intent root) { if (!playing) close(); super.onTaskRemoved(root); }

    @Override
    public void onDestroy() {
        save();
        running = false; playing = false;
        h.removeCallbacksAndMessages(null);
        try { unregisterReceiver(noisy); } catch (Exception ignored) {}
        releasePlayer();
        if (session != null) session.release();
        inst = null;
        changed();
        super.onDestroy();
    }
}
