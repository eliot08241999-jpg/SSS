package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * v1.8.2 · 🎼 TRANSCRIBIR CANCIÓN: de un audio a una canción del Cancionero con acordes encima de la letra,
 * la melodía en notas (♪) y su tablatura, tempo y tono. Las notas y acordes salen dentro del teléfono;
 * la letra, si quieres, la escucha Gemini (sube el audio a Google) o la pegas tú.
 * Lo transcrito de canciones ajenas es solo para ti: se guarda marcado 🔒 y no se puede compartir ni exportar.
 */
public class TranscribeActivity extends NeonActivity {
    static final int REQ_AUDIO = 91;
    final Handler h = new Handler(Looper.getMainLooper());
    Uri audio;
    String name = "";
    long durMs;
    int lyricMode;                     // 0 Gemini · 1 pegar · 2 sin letra
    TextView info, lyricBtn, resultTv, keyTv, nowChord, playBtn;
    EditText pasted, titleEd, artistEd;
    android.widget.Switch withMel;
    NeonProgress prog;
    LinearLayout resultPanel;
    volatile boolean busy, cancel;
    SongTranscriber.Result result;
    List<SongTranscriber.Line> lines;
    String chordPro = "";
    MediaPlayer player;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🎼 TRANSCRIBIR CANCIÓN");
        LinearLayout a = panel("◢ CANCIÓN");
        info = text("Elige una canción (MP3, M4A, WAV… o un vídeo). Mejor si se oye clara: la guitarra y la voz bien al frente.", 13);
        a.addView(info);
        a.addView(button("🎵 ELEGIR CANCIÓN", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE)
                    .putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
            PickActivity.start(this, i, REQ_AUDIO, "transcribe");
        }), gapBelow(4));
        col.addView(a, gapBelow(12));

        LinearLayout l = panel("◢ LETRA");
        lyricMode = Gemini.on(this) ? 0 : 1;
        lyricBtn = button("", v -> pickLyricMode());
        l.addView(lyricBtn, gapBelow(6));
        pasted = new EditText(this);
        pasted.setHint(L.t("Pega aquí la letra (un verso por línea; puedes poner [Estribillo] para marcar secciones)"));
        pasted.setTextColor(Color.WHITE);
        pasted.setHintTextColor(Color.GRAY);
        pasted.setMinLines(4);
        pasted.setGravity(Gravity.TOP);
        pasted.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        pasted.setBackground(frame(10));
        pasted.setPadding(dpi(10), dpi(8), dpi(10), dpi(8));
        l.addView(pasted, gapBelow(6));
        withMel = neonSwitch("♪ Añadir la melodía (notas y tablatura) encima de cada verso");
        withMel.setChecked(p().getBoolean("tr_mel", true));
        withMel.setOnCheckedChangeListener((x, on) -> p().edit().putBoolean("tr_mel", on).apply());
        l.addView(withMel);
        TextView note = text("🔒 Lo que transcribas es solo para ti: se guarda en tu Cancionero y puedes editarlo o borrarlo, pero no compartirlo ni exportarlo (las letras y canciones son de sus autores).", 11);
        note.setTextColor(Color.rgb(160, 170, 190));
        l.addView(note);
        col.addView(l, gapBelow(12));

        LinearLayout g = panel("◢ TRANSCRIBIR");
        g.addView(button("▶ SACAR ACORDES, NOTAS Y LETRA", v -> start()), gapBelow(6));
        prog = new NeonProgress(this);
        g.addView(prog, gapBelow(6));
        g.addView(button("✕ CANCELAR", v -> cancel = true));
        col.addView(g, gapBelow(12));

        resultPanel = panel("◢ RESULTADO");
        resultPanel.setVisibility(android.view.View.GONE);
        keyTv = neonText("", 14);
        resultPanel.addView(keyTv, gapBelow(4));
        nowChord = neonText("", 30);
        nowChord.setGravity(Gravity.CENTER);
        resultPanel.addView(nowChord);
        playBtn = button("▶ ESCUCHAR CON LOS ACORDES", v -> togglePlay());
        resultPanel.addView(playBtn, gapBelow(8));
        titleEd = field("Título");
        artistEd = field("Artista (opcional)");
        resultPanel.addView(titleEd, gapBelow(4));
        resultPanel.addView(artistEd, gapBelow(6));
        resultPanel.addView(button("📒 GUARDAR EN MI CANCIONERO", v -> save()), gapBelow(8));
        resultTv = text("", 12);
        resultTv.setTypeface(Typeface.MONOSPACE);
        resultTv.setTextColor(Color.rgb(220, 225, 235));
        resultPanel.addView(resultTv);
        col.addView(resultPanel, gapBelow(12));
        refresh();
        Uri in = getIntent().getData();
        if (in != null) setAudio(in);
    }

    android.content.SharedPreferences p() { return getSharedPreferences("cfg", MODE_PRIVATE); }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(L.t(hint));
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setSingleLine(true);
        e.setBackground(frame(10));
        e.setPadding(dpi(10), dpi(8), dpi(10), dpi(8));
        return e;
    }

    void pickLyricMode() {
        String[] o = {L.t("🤖 Que la saque Gemini (sube el audio a Google)"), L.t("📝 La pego yo"), L.t("🎸 Solo acordes, sin letra")};
        new android.app.AlertDialog.Builder(this).setItems(o, (d, w) -> {
            if (w == 0 && !Gemini.on(this)) { toast(L.t("Activa Gemini en Ajustes (con tu clave gratuita) para sacar la letra.")); return; }
            lyricMode = w; refresh();
        }).show();
    }

    void refresh() {
        String[] n = {"🤖 Letra: la saca Gemini", "📝 Letra: la pego yo", "🎸 Sin letra: solo acordes"};
        lyricBtn.setText(L.t(n[lyricMode]));
        pasted.setVisibility(lyricMode == 1 ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_AUDIO && res == RESULT_OK && data != null && data.getData() != null) setAudio(data.getData());
    }

    void setAudio(Uri u) {
        audio = u;
        name = Media.nameOf(this, u).replaceAll("\\.[A-Za-z0-9]{2,4}$", "");
        durMs = MediaTools.durationMs(this, u);
        info.setText("🎵 " + name + (durMs > 0 ? "  ·  " + fmt(durMs / 1000f) : ""));
        if (durMs > 12 * 60_000) info.append("\n" + L.t("Es muy larga: se transcriben los primeros 12 minutos."));
        stopPlay();
    }

    static String fmt(float s) { int t = Math.round(s); return (t / 60) + ":" + String.format(java.util.Locale.ROOT, "%02d", t % 60); }

    // ================================================================== proceso
    void start() {
        if (busy) return;
        if (audio == null) { toast(L.t("Primero elige una canción.")); return; }
        if (lyricMode == 1 && pasted.getText().toString().trim().isEmpty()) { toast(L.t("Pega la letra o elige «solo acordes».")); return; }
        busy = true; cancel = false;
        stopPlay();
        prog.begin();
        prog.phase(L.t("Leyendo el audio…"));
        final int mode = lyricMode;
        final String paste = pasted.getText().toString();
        final boolean mel = withMel.isChecked();
        new Thread(() -> {
            File wav = new File(getCacheDir(), "transcribe.wav");
            try {
                long end = Math.min(durMs > 0 ? durMs * 1000L : Long.MAX_VALUE / 4, 12 * 60_000_000L);
                MediaTools.toWav(this, audio, wav, 0, end, 1f, 0, 0, f -> h.post(() -> prog.set(L.t("Leyendo el audio"), Math.round(f * 100), 100)));
                if (cancel) throw new InterruptedException();
                float[] pcm = SongTranscriber.loadWav(wav);
                byte[] model;
                try (java.io.InputStream in = getAssets().open("basic_pitch.onnx")) { model = DocIO.readAll(in); }
                SongTranscriber.Result r = SongTranscriber.run(model, pcm, new SongTranscriber.Prog() {
                    public void on(String ph, int d, int t) {
                        String w = ph.equals("notes") ? L.t("Escuchando las notas") : ph.equals("decode") ? L.t("Separando las notas") : L.t("Buscando los acordes");
                        h.post(() -> { if (t > 1) prog.set(w, d, t); else prog.phase(w + "…"); });
                    }
                    public boolean cancelled() { return cancel; }
                });
                List<SongTranscriber.Line> ly = new ArrayList<>();
                String warn = null;
                if (mode == 0) {
                    h.post(() -> prog.phase(L.t("Gemini está escuchando la letra…")));
                    try { ly = SongTranscriber.parseGemini(geminiLyrics(pcm), r.dur); if (ly.isEmpty()) warn = L.t("Gemini no ha encontrado letra cantada; te dejo solo los acordes."); }
                    catch (Exception e) {
                        String m = String.valueOf(e.getMessage());
                        warn = m.contains("RECITATION") ? L.t("Google no permite sacar la letra de esta canción. Pégala tú con «📝 La pego yo» y la coloco con los acordes.")
                                : L.t("No pude sacar la letra") + ": " + m;
                    }
                } else if (mode == 1) ly = SongTranscriber.alignPasted(r, paste);
                String not = MusicTheory.notation(this);
                boolean fl = MusicTheory.flats(this);
                String cp = SongTranscriber.chordPro(r, ly, not, fl, mel);
                final List<SongTranscriber.Line> fly = ly;
                final String fw = warn;
                h.post(() -> done(r, fly, cp, fw));
            } catch (InterruptedException e) {
                h.post(() -> { prog.hide(); busy = false; toast(L.t("Cancelado.")); });
            } catch (Throwable e) {
                h.post(() -> { prog.hide(); busy = false; toast(L.t("No he podido transcribirla") + ": " + e.getMessage()); });
            } finally { wav.delete(); }
        }).start();
    }

    /** Sube el audio (mono, 16 kHz, máx. ~7 min) a Gemini y pide la letra con tiempos. */
    String geminiLyrics(float[] pcm22) throws Exception {
        float[] x = SongTranscriber.resample(pcm22, SongTranscriber.SR, 16000);
        int n = Math.min(x.length, 16000 * 60 * 7);
        ByteArrayOutputStream bo = new ByteArrayOutputStream(44 + n * 2);
        java.nio.ByteBuffer hd = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN);
        hd.putInt(0x46464952).putInt(36 + n * 2).putInt(0x45564157).putInt(0x20746d66).putInt(16).putShort((short) 1).putShort((short) 1)
                .putInt(16000).putInt(32000).putShort((short) 2).putShort((short) 16).putInt(0x61746164).putInt(n * 2);
        bo.write(hd.array());
        byte[] buf = new byte[n * 2];
        for (int i = 0; i < n; i++) { int v = Math.max(-32768, Math.min(32767, Math.round(x[i] * 32767))); buf[2 * i] = (byte) v; buf[2 * i + 1] = (byte) (v >> 8); }
        bo.write(buf);
        String b64 = android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP);
        String lang = "es".equals(L.lang) ? "español" : "it".equals(L.lang) ? "italiano" : "English";
        String prompt = "Escucha esta canción y transcribe solo la letra cantada, en su idioma original, verso por verso, con sus tiempos. "
                + "Responde únicamente con JSON: una lista de objetos {\"t\": segundo en que empieza el verso, \"e\": segundo en que termina, "
                + "\"l\": \"texto del verso\", \"s\": \"sección (Estrofa, Estribillo, Puente…) escrita en " + lang + "\"}. "
                + "No inventes nada: si no se entiende una palabra, pon (…). Si no hay voz, responde [].";
        JSONObject body = new JSONObject();
        body.put("contents", new JSONArray().put(new JSONObject().put("role", "user").put("parts", new JSONArray()
                .put(new JSONObject().put("inline_data", new JSONObject().put("mime_type", "audio/wav").put("data", b64)))
                .put(new JSONObject().put("text", prompt)))));
        body.put("generationConfig", new JSONObject().put("temperature", 0.2).put("maxOutputTokens", 8192).put("responseMimeType", "application/json"));
        String json = body.toString();
        Exception last = null;
        for (String m : Gemini.MODELS) {
            try { return Gemini.call(this, m, json, 180_000).text; }
            catch (Gemini.NotFound e) { last = e; }
        }
        throw last != null ? last : new Exception("Gemini");
    }

    void done(SongTranscriber.Result r, List<SongTranscriber.Line> ly, String cp, String warn) {
        busy = false;
        prog.hide();
        result = r; lines = ly; chordPro = cp;
        resultPanel.setVisibility(android.view.View.VISIBLE);
        String not = MusicTheory.notation(this);
        String key = MusicTheory.name(r.keyPc, not, MusicTheory.flats(this)) + (r.keyMinor == 1 ? "m" : "");
        int nCh = 0; for (SongTranscriber.ChordSeg s : r.chords) if (s.chord != null) nCh++;
        keyTv.setText(L.t("Tono") + ": " + key + (r.bpm > 0 ? "  ·  " + Math.round(r.bpm) + " BPM" : "") + "  ·  " + nCh + " " + L.t("cambios de acorde")
                + "  ·  " + r.melody.size() + " " + L.t("notas de melodía"));
        if (titleEd.getText().toString().trim().isEmpty()) titleEd.setText(name);
        resultTv.setText(preview(cp));
        if (warn != null) new android.app.AlertDialog.Builder(this).setMessage(warn).setPositiveButton("OK", null).show();
        else toast(L.t("¡Listo! Revísalo y guárdalo en tu Cancionero."));
    }

    /** Vista previa: los ♪ con su tablatura del instrumento de acordes, debajo los acordes y la letra. */
    String preview(String cp) {
        int[] strings = ChordPopup.strings(this);
        String not = MusicTheory.notation(this);
        boolean fl = MusicTheory.flats(this);
        StringBuilder sb = new StringBuilder();
        for (String line : cp.split("\n")) {
            if (line.startsWith("♪") && strings != null) {
                List<Integer> mel = MusicTheory.parseMelody(line.substring(1), not);
                sb.append(line).append('\n').append(SongTranscriber.tabText(SongTranscriber.tab(mel, strings, 0), strings, not, fl, 10));
            } else sb.append(line).append('\n');
        }
        return sb.toString();
    }

    void save() {
        if (result == null) return;
        try {
            File dir = new File(getFilesDir(), "songs");
            dir.mkdirs();
            JSONObject o = new JSONObject();
            String t = titleEd.getText().toString().trim();
            o.put("title", t.isEmpty() ? name : t);
            o.put("artist", artistEd.getText().toString().trim());
            o.put("key", MusicTheory.name(result.keyPc, MusicTheory.notation(this), MusicTheory.flats(this)) + (result.keyMinor == 1 ? "m" : ""));
            if (result.bpm > 0) o.put("bpm", Math.round(result.bpm));
            o.put("text", chordPro);
            o.put("personal", true);                 // 🔒 no se comparte ni se exporta
            o.put("source", "transcribed");
            File f = new File(dir, System.currentTimeMillis() + ".json");
            SongbookActivity.write(f, o);
            toast(L.t("Guardada en tu Cancionero 🔒"));
            stopPlay();
            startActivity(new Intent(this, SongbookActivity.class).putExtra("open_file", f.getAbsolutePath()));
        } catch (Exception e) { toast(L.t("No se pudo guardar.")); }
    }

    // ================================================================== escuchar con los acordes
    final Runnable tick = new Runnable() {
        @Override public void run() {
            if (player == null || result == null) return;
            float t = player.getCurrentPosition() / 1000f;
            String now = "—", next = "";
            for (int i = 0; i < result.chords.size(); i++) {
                SongTranscriber.ChordSeg s = result.chords.get(i);
                if (t >= s.t0 && t < s.t1) {
                    now = s.chord == null ? "—" : s.chord.name(TranscribeActivity.this);
                    for (int j = i + 1; j < result.chords.size(); j++) if (result.chords.get(j).chord != null) { next = result.chords.get(j).chord.name(TranscribeActivity.this); break; }
                    break;
                }
            }
            String lyric = "";
            if (lines != null) for (SongTranscriber.Line ln : lines) if (t >= ln.t0 && t < ln.t1) { lyric = ln.text; break; }
            nowChord.setText(now + (next.isEmpty() ? "" : "   →  " + next) + (lyric.isEmpty() ? "" : "\n" + lyric));
            h.postDelayed(this, 100);
        }
    };

    void togglePlay() {
        if (audio == null) return;
        if (player != null) { stopPlay(); return; }
        try {
            player = MediaPlayer.create(this, audio);
            if (player == null) { toast(L.t("No puedo reproducirla.")); return; }
            player.setOnCompletionListener(m -> stopPlay());
            player.start();
            playBtn.setText(L.t("⏹ PARAR"));
            h.post(tick);
        } catch (Exception e) { toast(L.t("No puedo reproducirla.")); }
    }

    void stopPlay() {
        h.removeCallbacks(tick);
        if (player != null) { try { player.stop(); player.release(); } catch (Exception ignored) {} player = null; }
        if (playBtn != null) playBtn.setText(L.t("▶ ESCUCHAR CON LOS ACORDES"));
    }

    @Override
    protected void onPause() { super.onPause(); if (player != null && player.isPlaying()) stopPlay(); }

    @Override
    protected void onDestroy() { cancel = true; stopPlay(); super.onDestroy(); }
}
