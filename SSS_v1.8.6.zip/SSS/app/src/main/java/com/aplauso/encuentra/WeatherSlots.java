package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;

/**
 * v1.8 · Cuatro nubecitas junto a Chloe: 🌧 lluvia, ⛈ tormenta, 🧊 granizo y 💨 viento fuerte.
 * Cada una se enciende (y se anima) solo cuando ese fenómeno está pasando AHORA donde estás.
 * Mientras alguna esté encendida, Chloe no se duerme: se queda mirándola.
 */
public class WeatherSlots extends View {
    public static final int RAIN = 0, STORM = 1, HAIL = 2, WIND = 3;
    static final float WIND_KMH = 40f;

    final boolean[] on = new boolean[4];
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Path cloud = new Path();
    final long t0 = SystemClock.uptimeMillis();
    int neon = Color.CYAN;

    /** Hacia dónde mirar (en coordenadas de pantalla) o NaN si no hay nada encendido. Lo lee el avatar. */
    static volatile float watchX = Float.NaN, watchY = Float.NaN;

    public WeatherSlots(Context c) {
        super(c);
        neon = Neon.color(c);
    }

    /** Qué está pasando ahora, según los códigos de Open-Meteo. */
    public static boolean[] active(Weather.Fc f) {
        boolean[] a = new boolean[4];
        if (f == null) return a;
        int k = Weather.kind(f.code);
        a[HAIL] = f.code == 96 || f.code == 99;
        a[STORM] = f.code >= 95;
        a[RAIN] = k == Weather.RAIN || k == Weather.DRIZZLE || (f.precip > 0.1 && k != Weather.SNOW);
        a[WIND] = f.wind >= WIND_KMH;
        return a;
    }

    public void set(Weather.Fc f) {
        boolean[] a = active(f);
        System.arraycopy(a, 0, on, 0, 4);
        updateWatch();
        invalidate();
    }

    boolean any() { return on[0] || on[1] || on[2] || on[3]; }

    void updateWatch() {
        if (!any() || getWidth() == 0) { watchX = Float.NaN; watchY = Float.NaN; return; }
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        float slot = getWidth() / 4f;
        for (int i = 0; i < 4; i++) if (on[i]) { watchX = loc[0] + slot * (i + 0.5f); watchY = loc[1] + getHeight() / 2f; return; }
    }

    @Override protected void onLayout(boolean ch, int l, int t, int r, int b) { super.onLayout(ch, l, t, r, b); updateWatch(); }

    @Override protected void onDetachedFromWindow() { super.onDetachedFromWindow(); watchX = Float.NaN; watchY = Float.NaN; }

    @Override
    protected void onMeasure(int w, int h) {
        float d = getResources().getDisplayMetrics().density;
        setMeasuredDimension((int) (4 * 40 * d), (int) (38 * d));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float d = getResources().getDisplayMetrics().density;
        float s = getWidth() / 4f, h = getHeight();
        float t = (SystemClock.uptimeMillis() - t0) / 1000f;
        for (int i = 0; i < 4; i++) {
            float cx = s * (i + 0.5f), cy = h * 0.42f;
            // marco del hueco
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.2f * d);
            p.setColor(on[i] ? neon : Color.argb(60, Color.red(neon), Color.green(neon), Color.blue(neon)));
            cv.drawRoundRect(new RectF(cx - s * 0.44f, 2 * d, cx + s * 0.44f, h - 2 * d), 8 * d, 8 * d, p);
            int alpha = on[i] ? 255 : 55;
            switch (i) {
                case RAIN: cloud(cv, cx, cy, d, Color.argb(alpha, 200, 215, 235)); if (on[i]) drops(cv, cx, cy, d, t, Color.rgb(120, 180, 255), false); break;
                case STORM:
                    cloud(cv, cx, cy, d, Color.argb(alpha, 120, 125, 150));
                    if (on[i]) { drops(cv, cx, cy, d, t, Color.rgb(110, 160, 240), false); if ((t % 2.3f) < 0.18f) bolt(cv, cx, cy, d, Color.rgb(255, 230, 90)); }
                    else bolt(cv, cx, cy, d, Color.argb(alpha, 255, 230, 90));
                    break;
                case HAIL: cloud(cv, cx, cy, d, Color.argb(alpha, 190, 200, 215)); if (on[i]) drops(cv, cx, cy, d, t, Color.WHITE, true); break;
                case WIND: wind(cv, cx, cy, d, t, alpha, on[i]); break;
            }
        }
        if (any()) postInvalidateDelayed(40);
    }

    void cloud(Canvas cv, float cx, float cy, float d, int col) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(col);
        float r = 6.5f * d;
        cv.drawCircle(cx - r, cy, r, p);
        cv.drawCircle(cx + r * 0.9f, cy, r * 0.95f, p);
        cv.drawCircle(cx, cy - r * 0.7f, r * 1.15f, p);
        cv.drawRect(cx - r, cy, cx + r * 0.9f, cy + r * 0.8f, p);
    }

    void drops(Canvas cv, float cx, float cy, float d, float t, int col, boolean balls) {
        p.setColor(col);
        p.setStrokeWidth(1.4f * d);
        float top = cy + 6 * d, bottom = getHeight() - 4 * d, span = bottom - top;
        for (int k = 0; k < 4; k++) {
            float x = cx - 7 * d + k * 4.6f * d;
            float ph = ((t * (balls ? 1.1f : 1.6f)) + k * 0.27f) % 1f;
            float y = top + ph * span;
            if (balls) { p.setStyle(Paint.Style.FILL); cv.drawCircle(x, y, 1.6f * d, p); }
            else { p.setStyle(Paint.Style.STROKE); cv.drawLine(x, y, x - 1.2f * d, y + 3.5f * d, p); }
        }
    }

    void bolt(Canvas cv, float cx, float cy, float d, int col) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(col);
        Path b = new Path();
        b.moveTo(cx + 1 * d, cy + 3 * d); b.lineTo(cx - 3 * d, cy + 10 * d); b.lineTo(cx, cy + 10 * d);
        b.lineTo(cx - 2 * d, cy + 16 * d); b.lineTo(cx + 4 * d, cy + 8 * d); b.lineTo(cx + 1 * d, cy + 8 * d); b.close();
        cv.drawPath(b, p);
    }

    void wind(Canvas cv, float cx, float cy, float d, float t, int alpha, boolean on) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.8f * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(Color.argb(alpha, 220, 235, 245));
        for (int k = 0; k < 3; k++) {
            float off = on ? ((t * 1.4f + k * 0.33f) % 1f - 0.5f) * 10 * d : 0;
            float y = cy - 6 * d + k * 6 * d;
            float w = (k == 1 ? 13 : 9) * d;
            cv.drawLine(cx - w + off, y, cx + w * 0.6f + off, y, p);
            cv.drawArc(new RectF(cx + w * 0.6f - 3 * d + off, y - 6 * d, cx + w * 0.6f + 3 * d + off, y), 90, -220, false, p);
        }
    }
}
