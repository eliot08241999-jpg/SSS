package com.aplauso.encuentra;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** v1.8 · 🎯 Afinador preciso (MPM): instrumentos y afinaciones, cromático, aguja o estroboscopio, La de referencia ajustable. */
public class TunerActivity extends NeonActivity {
    final MusicAudio.PitchDetector det = new MusicAudio.PitchDetector();
    MusicTheory.Instrument inst;     // null = cromático
    int manual = -1;                 // cuerda elegida a mano (−1 = automático)
    double a4;
    boolean strobe;
    Meter meter;
    TextView noteTv, infoTv, instBtn, a4Btn, modeBtn;
    LinearLayout stringsRow;
    volatile float hz, cents;
    volatile int target = -1, heard = -1;
    volatile long lastGood;
    float smooth = Float.NaN;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🎯 AFINADOR");
        a4 = p.getFloat("tun_a4", 440f);
        strobe = p.getBoolean("tun_strobe", false);
        String id = p.getString("tun_inst", "gtr6");
        inst = "chromatic".equals(id) ? null : MusicTheory.byId(this, id);

        LinearLayout top = panel(null);
        instBtn = button("", v -> pickInstrument());
        top.addView(instBtn, gapBelow(8));
        noteTv = neonText("—", 46);
        noteTv.setGravity(Gravity.CENTER);
        top.addView(noteTv);
        meter = new Meter();
        top.addView(meter, new LinearLayout.LayoutParams(-1, dpi(150)));
        infoTv = text("Toca una cuerda para empezar a afinar.", 14);
        infoTv.setGravity(Gravity.CENTER);
        top.addView(infoTv, gapBelow(8));
        stringsRow = new LinearLayout(this);
        stringsRow.setGravity(Gravity.CENTER);
        top.addView(stringsRow, gapBelow(4));
        col.addView(top, gapBelow(12));

        LinearLayout o = panel("◢ AJUSTES");
        modeBtn = button("", v -> { strobe = !strobe; p.edit().putBoolean("tun_strobe", strobe).apply(); refresh(); });
        o.addView(modeBtn, gapBelow(6));
        a4Btn = button("", v -> pickA4());
        o.addView(a4Btn, gapBelow(6));
        o.addView(button("➕ CREAR AFINACIÓN PERSONALIZADA", v -> customTuning()), gapBelow(6));
        TextView t = text("Automático: detecta qué cuerda tocas. Toca una cuerda en la pantalla para fijarla y escuchar su nota de referencia. "
                + "Verde = afinada (±3 cents). Las flechas dicen si apretar (↑ subir) o aflojar (↓ bajar) la clavija.", 11);
        t.setTextColor(Color.rgb(160, 170, 190));
        o.addView(t);
        col.addView(o, gapBelow(12));
        refresh();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override protected void onResume() {
        super.onResume();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 5);
            return;
        }
        listen();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) listen();
        else infoTv.setText(L.t("Necesito el micrófono para afinar."));
    }

    @Override protected void onPause() { super.onPause(); det.stop(); }

    void listen() {
        det.start((f, clarity, rms) -> {
            if (f < 0) { runOnUiThread(() -> infoTv.setText(L.t("No puedo usar el micrófono ahora."))); return; }
            if (f <= 0 || clarity < 0.8f || f < 25 || f > 4200) return;
            float[] nr = MusicAudio.nearest(f, a4);
            int tgt = (int) nr[0];
            if (inst != null) {                               // la cuerda más cercana (o la elegida)
                if (manual >= 0) tgt = inst.strings[manual];
                else {
                    double best = 1e9;
                    for (int s : inst.strings) {
                        double d = Math.abs(12 * Math.log(f / MusicTheory.freq(s, a4)) / Math.log(2));
                        if (d < best) { best = d; tgt = s; }
                    }
                }
            }
            float c = (float) (1200 * Math.log(f / MusicTheory.freq(tgt, a4)) / Math.log(2));
            hz = f;
            target = tgt;
            heard = (int) nr[0];
            smooth = Float.isNaN(smooth) || Math.abs(smooth - c) > 40 ? c : smooth * 0.7f + c * 0.3f;
            cents = smooth;
            lastGood = SystemClock.uptimeMillis();
            runOnUiThread(this::show);
        });
    }

    void show() {
        boolean fresh = SystemClock.uptimeMillis() - lastGood < 1200;
        if (!fresh || target < 0) return;
        noteTv.setText(MusicTheory.noteName(this, target));
        float c = cents;
        String dir = Math.abs(c) <= 3 ? "✅ " + L.t("¡Afinada!") : c < 0 ? "↑ " + L.t("Sube (aprieta la clavija)") : "↓ " + L.t("Baja (afloja la clavija)");
        if (Math.abs(c) > 50 && inst != null) dir = "≈ " + L.t("Suena") + " " + MusicTheory.noteName(this, heard) + " · " + dir;
        infoTv.setText(String.format(java.util.Locale.ROOT, "%.1f Hz · %+.1f cents\n", hz, c) + dir);
        markStrings();
        meter.invalidate();
    }

    void refresh() {
        instBtn.setText("🎸 " + (inst == null ? L.t("Cromático (cualquier instrumento)") : L.t(inst.name)) + "  ▾");
        a4Btn.setText(L.t("La de referencia") + " (A4): " + (a4 == Math.rint(a4) ? String.valueOf((int) a4) : String.valueOf(a4)) + " Hz");
        modeBtn.setText(strobe ? L.t("Vista: estroboscópica (ultraprecisa)") : L.t("Vista: aguja"));
        stringsRow.removeAllViews();
        if (inst != null) {
            TextView auto = button("AUTO", v -> { manual = -1; markStrings(); });
            auto.setTextSize(11);
            stringsRow.addView(auto, lp());
            for (int i = 0; i < inst.strings.length; i++) {
                final int k = i;
                TextView s = button(MusicTheory.name(this, inst.strings[i]), v -> { manual = k; markStrings(); MusicAudio.reference(inst.strings[k], a4); });
                s.setTextSize(13);
                stringsRow.addView(s, lp());
            }
        }
        markStrings();
        meter.invalidate();
    }

    LinearLayout.LayoutParams lp() { LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, -2, 1); l.rightMargin = dpi(3); return l; }

    void markStrings() {
        if (inst == null) return;
        for (int i = 0; i < stringsRow.getChildCount(); i++) {
            View v = stringsRow.getChildAt(i);
            boolean sel = i == 0 ? manual < 0 : manual == i - 1 || (manual < 0 && target == inst.strings[i - 1]);
            boolean ok = i > 0 && target == inst.strings[i - 1] && Math.abs(cents) <= 3 && SystemClock.uptimeMillis() - lastGood < 1200;
            v.setAlpha(sel ? 1f : 0.45f);
            if (v instanceof TextView) ((TextView) v).setTextColor(ok ? Color.rgb(90, 230, 120) : Color.WHITE);
        }
    }

    void pickInstrument() {
        List<MusicTheory.Instrument> l = MusicTheory.all(this);
        String[] n = new String[l.size() + 1];
        n[0] = L.t("Cromático (cualquier instrumento, voz, armónica…)");
        for (int i = 0; i < l.size(); i++) {
            StringBuilder sb = new StringBuilder(L.t(l.get(i).name)).append("  ·  ");
            for (int s : l.get(i).strings) sb.append(MusicTheory.noteName(this, s)).append(' ');
            n[i + 1] = sb.toString().trim();
        }
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Instrumento y afinación")).setItems(n, (d, w) -> {
            inst = w == 0 ? null : l.get(w - 1);
            manual = -1;
            p.edit().putString("tun_inst", inst == null ? "chromatic" : inst.id).apply();
            refresh();
        }).show();
    }

    void pickA4() {
        String[] o = {"440 Hz (estándar)", "442 Hz (orquesta)", "443 Hz", "441 Hz", "438 Hz", "435 Hz", "432 Hz", "415 Hz (barroco)", "466 Hz", "Otro…"};
        float[] v = {440, 442, 443, 441, 438, 435, 432, 415, 466};
        new android.app.AlertDialog.Builder(this).setTitle(L.t("La de referencia")).setItems(o, (d, w) -> {
            if (w < v.length) { a4 = v[w]; p.edit().putFloat("tun_a4", (float) a4).apply(); refresh(); return; }
            android.widget.EditText e = new android.widget.EditText(this);
            e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
            e.setText(String.valueOf(a4));
            new android.app.AlertDialog.Builder(this).setTitle("A4 (415–466)").setView(e).setPositiveButton("OK", (d2, w2) -> {
                try { a4 = Math.max(415, Math.min(466, Double.parseDouble(e.getText().toString().replace(',', '.')))); } catch (Exception ignored) {}
                p.edit().putFloat("tun_a4", (float) a4).apply();
                refresh();
            }).show();
        }).show();
    }

    void customTuning() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dpi(18), dpi(8), dpi(18), 0);
        android.widget.EditText name = new android.widget.EditText(this);
        name.setHint(L.t("Nombre (p. ej. Mi afinación)"));
        android.widget.EditText notes = new android.widget.EditText(this);
        notes.setHint(L.t("Notas de grave a agudo, p. ej. D2 A2 D3 G3 B3 E4"));
        box.addView(name);
        box.addView(notes);
        new android.app.AlertDialog.Builder(this).setTitle(L.t("➕ Afinación personalizada")).setView(box).setPositiveButton("OK", (d, w) -> {
            String n = name.getText().toString().replace("\t", " ").replace("\n", " ").trim();
            List<Integer> m = new java.util.ArrayList<>();
            for (String t : notes.getText().toString().trim().split("[\\s,]+")) {
                int x = MusicTheory.parseNote(t, 3, MusicTheory.notation(this));
                if (x > 0) m.add(x);
            }
            if (n.isEmpty() || m.size() < 2) { toast(L.t("Pon un nombre y al menos dos notas con su octava.")); return; }
            StringBuilder sb = new StringBuilder();
            for (int x : m) sb.append(sb.length() > 0 ? "," : "").append(x);
            String all = p.getString("mus_custom_tunings", "");
            p.edit().putString("mus_custom_tunings", (all.isEmpty() ? "" : all + "\n") + n + "\t" + sb).apply();
            inst = MusicTheory.byId(this, "custom:" + n);
            p.edit().putString("tun_inst", inst.id).apply();
            refresh();
        }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    class Meter extends View {
        final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        float phase;
        long last;
        Meter() { super(TunerActivity.this); }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            int neon = Neon.color(getContext());
            boolean fresh = SystemClock.uptimeMillis() - lastGood < 1200;
            float c = fresh ? Math.max(-50, Math.min(50, cents)) : 0;
            boolean ok = fresh && Math.abs(cents) <= 3;
            if (strobe) {
                long now = SystemClock.uptimeMillis();
                float dt = last == 0 ? 0 : (now - last) / 1000f;
                last = now;
                if (fresh) phase += c * dt * 6;      // se mueve según lo desafinada; quieta = perfecta
                int bands = 4;
                for (int r = 0; r < bands; r++) {
                    float y0 = h * 0.1f + r * h * 0.2f;
                    float stripe = w / 8;
                    float off = ((phase * (r + 1)) % (2 * stripe) + 2 * stripe) % (2 * stripe);
                    pt.setColor(ok ? Color.rgb(90, 230, 120) : fresh ? neon : Color.rgb(60, 65, 80));
                    for (float x = -2 * stripe + off; x < w; x += 2 * stripe) cv.drawRect(x, y0, x + stripe, y0 + h * 0.16f, pt);
                }
                postInvalidateOnAnimation();
                return;
            }
            float cx = w / 2, cy = h * 0.95f, R = Math.min(w * 0.46f, h * 0.85f);
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(dp(2));
            pt.setColor(Color.argb(120, Color.red(neon), Color.green(neon), Color.blue(neon)));
            cv.drawArc(new RectF(cx - R, cy - R, cx + R, cy + R), 200, 140, false, pt);
            pt.setTextAlign(Paint.Align.CENTER);
            pt.setTypeface(Typeface.DEFAULT);
            pt.setTextSize(dp(10));
            for (int k = -50; k <= 50; k += 10) {
                double a = Math.toRadians(-90 + k * 1.4);
                float x1 = cx + (float) Math.cos(a) * R, y1 = cy + (float) Math.sin(a) * R;
                float x2 = cx + (float) Math.cos(a) * (R - dp(k == 0 ? 18 : 10)), y2 = cy + (float) Math.sin(a) * (R - dp(k == 0 ? 18 : 10));
                pt.setColor(k == 0 ? Color.rgb(90, 230, 120) : Color.rgb(150, 160, 180));
                cv.drawLine(x1, y1, x2, y2, pt);
            }
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(Color.rgb(150, 160, 180));
            pt.setTextSize(dp(22));
            cv.drawText("♭", cx - R * 0.85f, cy - R * 0.25f, pt);
            cv.drawText("♯", cx + R * 0.85f, cy - R * 0.25f, pt);
            double a = Math.toRadians(-90 + c * 1.4);
            pt.setStrokeWidth(dp(4));
            pt.setColor(ok ? Color.rgb(90, 230, 120) : fresh ? neon : Color.rgb(80, 85, 100));
            cv.drawLine(cx, cy, cx + (float) Math.cos(a) * (R - dp(6)), cy + (float) Math.sin(a) * (R - dp(6)), pt);
            cv.drawCircle(cx, cy, dp(7), pt);
            if (fresh) postInvalidateDelayed(50);
        }
    }
}
