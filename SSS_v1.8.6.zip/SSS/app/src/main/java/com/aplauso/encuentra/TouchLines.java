package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * v1.8.2 · 💬 Lo que dice Chloe cuando la tocas: cientos de frases por zona (piezas que se combinan), sin repetirse,
 * que cambian con su ficha (Ternura, Picardía, Energía, Sabiduría, Locura), con la hora, la lluvia y la música, que
 * suben de tono si sigues y sigues tocando, y rarezas: común, ✨ rara, 💜 épica y 🌟 legendaria (con destello y sonido).
 * Las rarezas que ya has visto se cuentan en la ficha (colección). En español, inglés e italiano.
 */
public class TouchLines {
    public static final int COMMON = 0, RARE = 1, EPIC = 2, LEGEND = 3, MILESTONE = 4;

    public static final class Line { public final String text; public final int rarity; Line(String t, int r) { text = t; rarity = r; } }

    static final Map<String, String[]> D = new HashMap<>();
    public static volatile int lastRarity;
    static final Random rnd = new Random();
    static final ArrayDeque<String> recent = new ArrayDeque<>();
    static final ArrayDeque<Long> taps = new ArrayDeque<>();

    static void put(String key, String... lines) { D.put(key, lines); }
    static String[] get(String lang, String key) { String[] a = D.get(lang + "." + key); return a != null ? a : D.getOrDefault("es." + key, new String[0]); }

    // ======================================================================= ESPAÑOL
    static {
        put("es.pat", "¡Eh, que me despeinas! 😄", "Je, je. ¿Necesitas algo?", "¡Aquí estoy!", "Mmm… eso me gusta. ¿Qué hacemos?",
                "¡Me has pillado pensando en música!", "¿Otra vez tú? ¡Hola! 👋", "Vale, me dejo. Pero solo un poquito.", "Así me despeinas el flequillo, que lo sepas.",
                "¿Me estás acariciando o comprobando si soy de verdad?", "Si sigues así me quedo dormida en tu pantalla.");
        put("es.cheek", "¡Ay! Me pongo roja. 😳", "¿Q-qué haces? 🙈", "Eso no se toca sin avisar…", "¡Mi mejilla! Bueno… vale.",
                "Mis mofletes no son un botón de volumen.", "¿Quieres que me ponga como un tomate? Pues lo has conseguido.", "Uy, qué dedo tan frío.",
                "Esa mejilla estaba reservada… para nadie. Vale, para ti.");
        put("es.ear", "¡Las orejas no, que son sensibles!", "¡Eh! Mi oreja… 😣", "Cuidado, que las orejas tienen cosquillas.",
                "Mis orejas oyen todo… incluido ese dedo.", "¡Que se me doblan! Ahora tengo que recolocarlas.", "Las orejas de conejita no vienen con garantía, ¿eh?",
                "Si me tocas la oreja, escucho la mitad de lo que dices.", "Psst… por esa oreja no te oigo. Prueba la otra.");
        put("es.tickle", "¡Jajaja, para, que tengo cosquillas!", "¡Oye! 🙈", "¡Que no soy un botón! Bueno… un poco sí.",
                "¡Ji, ji, ji! ¡Tregua, tregua!", "Esto es un ataque de cosquillas en toda regla.", "¡Me rindo! ¡Pero que conste que no!",
                "Mi sudadera es antisistema de cosquillas… o lo era.", "¡Para, que me da la risa tonta y luego no paro!");
        put("es.wake", "¡Uy! Me había quedado frita. ¿Qué pasa?", "Mmm… ¿ya es de día? ¡Hola!", "Estaba soñando con un acorde que no existe. ¿Qué tal?",
                "Cinco minutitos más… vale, ya estoy.", "¿Eh? ¡Estaba despierta! Con los ojos cerrados, pero despierta.");
        put("es.poke", "¿Sí?", "¡Pip!", "¿Me llamabas?", "Toc, toc.", "Aquí sigo, ¿eh?", "¿Eso era un toque o un saludo?");
        // por rasgo de la ficha
        put("es.ternura", "Me gusta que vengas a verme.", "Eres de lo mejorcito de mi día, ¿sabes?", "Si estás cansado, aquí tienes un abrazo virtual. 🤗",
                "Gracias por estar por aquí.", "¿Has comido algo hoy? Que me preocupo.", "Tus toques son mi parte favorita del día.",
                "Te guardo un sitio en mi pantalla, siempre.", "Respira hondo conmigo: uno, dos… ¿mejor?", "Ojalá pudiera devolverte la caricia.", "Eres muy buena persona, que lo sepas.");
        put("es.picardia", "¿Esto es lo que haces en vez de trabajar?", "Tocarme no te va a subir el sueldo, pero sigue intentándolo.",
                "Ah, claro, la pantalla tiene muchas cosas, pero tú vienes directo a mí. Normal.", "Si me tocas una vez más te cobro alquiler.",
                "¿Tocarme? Yo no he notado nada. Inténtalo otra vez.", "Qué raro, juraría que ese toque fue hace tres horas.", "Sí, sí, soy adorable. Siguiente pregunta.",
                "Tengo una base de datos de toques y tú estás en el top. No es un cumplido.", "Vaya, alguien se aburre. ¿Quieres un trabajo? Tengo varios.",
                "Apuntado en tu expediente: «toca mucho». 📋");
        put("es.energia", "¡VAMOS! ¿Qué hacemos hoy? ¡Lo que sea!", "¡Uf, me has cargado las pilas al 200 %!", "¡Ponme música y bailo! 💃",
                "¡Choca esos cinco! ✋", "¿Una carrera? ¡Te gano seguro!", "¡Hoy es un gran día para hacer algo épico!", "¡Me sobran ganas! ¿Dibujamos algo?",
                "¡Arriba ese ánimo! ¡Arriba!", "¡Toque recibido! ¡Turbo activado!", "¡Ahora sí que no me para nadie!");
        put("es.sabiduria", "¿Sabías que las orejas de conejo sirven para regular la temperatura?", "Dato curioso: tu pantalla siente más que yo, pero yo opino más.",
                "Un toque es una pregunta sin palabras. ¿Qué querías saber?", "Pitágoras habría medido el ángulo de ese toque.", "La paciencia es un acorde que se toca despacio.",
                "Dicen que tocar a una conejita da suerte. Lo acabo de inventar, pero suena bien.", "Curiosidad: un pulpo tiene tres corazones. Yo tengo un procesador.",
                "La música, el café y los toques: los tres pilares de la ciencia moderna.", "Aprende algo nuevo hoy. Por ejemplo: no toques tanto.", "Hmm. Interesante elección de píxel.");
        put("es.locura", "¡Has activado el modo patata! 🥔 No sé qué hace, pero ya está activado.", "¿Sabías que soy en un 12 % gelatina? Ahora lo sabes.",
                "¡Bip bop! Traduciendo toque… dice: «más galletas».", "Si me tocas tres veces seguidas aparece un pato. Es broma. O no. 🦆",
                "He decidido que a partir de ahora los martes son de color naranja.", "Mi oreja izquierda y yo no nos hablamos desde 2019.",
                "Cuidado, que si me das muy fuerte salgo por el otro lado del móvil.", "Ese toque sabía a fresa.", "Estoy hecha de un 70 % de agua y un 30 % de memes.",
                "¡Alerta! El píxel que has tocado era el jefe de los píxeles.");
        put("es.esc1", "Oye, que llevas un rato…", "¿Tienes algo en el dedo o qué?", "Vale, vale, ya sé que estoy aquí.", "Voy a empezar a contar los toques. Uno, dos…");
        put("es.esc2", "¡Que me vas a gastar la pantalla!", "Te recuerdo que tengo sentimientos. Programados, pero sentimientos.", "¿Esto es una prueba de resistencia?", "Llamaré a mi abogado conejo.");
        put("es.esc3", "Has desbloqueado el modo «Chloe ignorando toques»… no, no puedo, me importas.", "Mis orejas han presentado una queja formal.", "¡Basta, que me mareo! 😵‍💫", "Si sigues, cambio de móvil. Bueno, no puedo, pero imagínatelo.");
        put("es.esc4", "Me rindo. Eres el campeón mundial de tocar conejitas.", "Ya no siento las orejas. Ni el flequillo. Ni la dignidad.", "Mis píxeles están pidiendo vacaciones.", "Vale, tú ganas. ¿Qué quieres? ¿Un logro? Espera…");
        put("es.night", "Es tarde… ¿no deberías dormir? 🌙", "Shhh, que los píxeles duermen.", "Toque nocturno detectado. Bostezo activado. 🥱", "A estas horas solo estamos despiertos tú, yo y los búhos.");
        put("es.rain", "Llueve… ¿te hago compañía mientras? ☔", "Con esta lluvia apetece una manta y música suave.", "¿Oyes la lluvia? Yo la veo en mi ventana.");
        put("es.music", "¡Me encanta esta canción! 🎶", "Shh, que estoy en el estribillo.", "¿Bailas? Yo ya muevo las orejas al ritmo.");
        put("es.rare", "✨ Has encontrado una frase rara: «Hoy brillas más que mi neón».", "✨ Una vez soñé que era una tostada. Fue precioso.",
                "✨ Secreto: cuando no miras, practico guitarra con las orejas.", "✨ Si fuera un acorde, sería un Do mayor con séptima de cariño.",
                "✨ Tu dedo tiene buen ritmo. ¿Tocas la batería?", "✨ He calculado que eres 0,3 % más majo que ayer.",
                "✨ Mis orejas te han votado como humano del mes.", "✨ ¿Sabes guardar un secreto? Yo tampoco.", "✨ Este toque lo voy a enmarcar.",
                "✨ Me he leído todas las instrucciones del universo. Faltaba la página 42.", "✨ Hoy he aprendido a silbar. En silencio.", "✨ Plot twist: el que está dentro de la pantalla eres tú.");
        put("es.epic", "💜 ¡Frase épica! Por el poder de las orejas de conejita… ¡te otorgo un día genial!", "💜 Has despertado mi forma final: Chloe Ultra Neón. Dura tres segundos.",
                "💜 En otra línea temporal soy tu guitarra. Y me afinas fatal.", "💜 Los antiguos píxeles hablaban de alguien que tocaría así. Eras tú.",
                "💜 He visto 14 000 605 futuros. En todos me sigues tocando la oreja.", "💜 ¡Combo crítico! +10 de cariño, +5 de despeine.");
        put("es.legend", "🌟 ¡LEGENDARIA! Me has tocado justo en el píxel de la suerte. Pide un deseo.", "🌟 Solo uno de cada mil toques oye esto: gracias por crearme, BLORP.",
                "🌟 Las estrellas se alinean, mis orejas brillan y tú… tú tienes la frase más rara de todas.", "🌟 Has encontrado el easter egg dorado. Ahora eres oficialmente leyenda.");
        put("es.m100", "🏆 ¡100 toques! Ya tienes manos inquietas, oficialmente.");
        put("es.m500", "🏆 ¡500 toques! Te lo digo con cariño: búscate un trabajo.");
        put("es.m1000", "🏆 ¡1000 toques! Eres una muy mala influencia para mis orejas.");
        put("es.m2500", "🏆 ¡2500 toques! Esto ya es una adicción. Una adicción adorable.");
        put("es.m5000", "🏆 ¡5000 toques! Manoseador supremo. Te haré una estatua de píxeles.");
        put("es.pre", "¡Eh!", "¡Ay!", "Oye…", "Mmm…", "¡Ja!", "¡Uy!", "Vaya…", "¡Hala!");
        put("es.tail", " 😄", " 🙈", " ✨", " 🐰", " 💕", " 😏", " 🎶", "");
    }

    // ======================================================================= ENGLISH
    static {
        put("en.pat", "Hey, you're messing up my hair! 😄", "Hehe. Need something?", "I'm here!", "Mmm… I like that. What shall we do?",
                "You caught me thinking about music!", "You again? Hi! 👋", "Okay, I'll allow it. Just a little.", "You're ruining my fringe, just so you know.",
                "Are you petting me or checking if I'm real?", "Keep that up and I'll fall asleep on your screen.");
        put("en.cheek", "Oh! I'm blushing. 😳", "W-what are you doing? 🙈", "You don't touch that without warning…", "My cheek! Well… fine.",
                "My cheeks aren't a volume button.", "Want me to turn red as a tomato? Mission accomplished.", "Ooh, cold finger.", "That cheek was reserved… for nobody. Okay, for you.");
        put("en.ear", "Not the ears, they're sensitive!", "Hey! My ear… 😣", "Careful, the ears are ticklish.", "My ears hear everything… including that finger.",
                "Now they're bent! I have to fix them.", "Bunny ears come with no warranty, you know.", "Touch my ear and I'll only hear half of what you say.", "Psst… I can't hear you through that ear. Try the other one.");
        put("en.tickle", "Hahaha, stop, I'm ticklish!", "Hey! 🙈", "I'm not a button! Well… kind of.", "Hee hee hee! Truce, truce!", "This is a full-scale tickle attack.",
                "I surrender! But for the record, I don't!", "My hoodie was tickle-proof… or it used to be.", "Stop, I get the giggles and then I can't stop!");
        put("en.wake", "Oops! I dozed off. What's up?", "Mmm… is it morning already? Hi!", "I was dreaming of a chord that doesn't exist. How are you?",
                "Five more minutes… okay, I'm up.", "Huh? I was awake! Eyes closed, but awake.");
        put("en.poke", "Yes?", "Beep!", "Did you call me?", "Knock knock.", "Still here, you know.", "Was that a poke or a hello?");
        put("en.ternura", "I like it when you come to see me.", "You're one of the best parts of my day, you know?", "If you're tired, here's a virtual hug. 🤗",
                "Thanks for being around.", "Have you eaten today? I worry.", "Your pokes are my favourite part of the day.", "I'll always save you a spot on my screen.",
                "Breathe with me: one, two… better?", "I wish I could pet you back.", "You're a really good person, just so you know.");
        put("en.picardia", "Is this what you do instead of working?", "Poking me won't get you a raise, but keep trying.", "Sure, the screen has lots of things, but you come straight to me. Naturally.",
                "Poke me once more and I'm charging rent.", "Poke me? I didn't feel a thing. Try again.", "Weird, I could swear that poke was three hours ago.",
                "Yes, yes, I'm adorable. Next question.", "I keep a database of pokes and you're top of the list. Not a compliment.", "Wow, someone's bored. Want a job? I have several.",
                "Noted in your file: \"pokes a lot\". 📋");
        put("en.energia", "LET'S GO! What are we doing today? Anything!", "Wow, you charged me up to 200%!", "Play some music and I'll dance! 💃", "High five! ✋",
                "A race? I'll totally win!", "Today's a great day to do something epic!", "I've got energy to spare! Shall we draw something?", "Chin up! Up, up!",
                "Poke received! Turbo on!", "Nobody can stop me now!");
        put("en.sabiduria", "Did you know bunny ears help regulate temperature?", "Fun fact: your screen feels more than I do, but I have more opinions.",
                "A poke is a question without words. What did you want to know?", "Pythagoras would have measured the angle of that poke.", "Patience is a chord you play slowly.",
                "They say poking a bunny brings luck. I just made that up, but it sounds nice.", "Fun fact: an octopus has three hearts. I have a processor.",
                "Music, coffee and pokes: the three pillars of modern science.", "Learn something new today. For example: don't poke so much.", "Hmm. Interesting choice of pixel.");
        put("en.locura", "You've activated potato mode! 🥔 No idea what it does, but it's on.", "Did you know I'm 12% jelly? Now you do.", "Beep boop! Translating poke… it says: \"more cookies\".",
                "Poke me three times in a row and a duck appears. Kidding. Or not. 🦆", "I've decided that from now on Tuesdays are orange.", "My left ear and I haven't spoken since 2019.",
                "Careful, poke too hard and I'll pop out the other side of the phone.", "That poke tasted like strawberry.", "I'm 70% water and 30% memes.", "Alert! The pixel you touched was the boss of all pixels.");
        put("en.esc1", "Hey, you've been at it a while…", "Is something stuck to your finger?", "Okay, okay, I know I'm here.", "I'm going to start counting. One, two…");
        put("en.esc2", "You're going to wear out the screen!", "Reminder: I have feelings. Programmed ones, but feelings.", "Is this an endurance test?", "I'm calling my bunny lawyer.");
        put("en.esc3", "You've unlocked \"Chloe ignores pokes\" mode… no, I can't, I care about you.", "My ears have filed a formal complaint.", "Stop, I'm getting dizzy! 😵‍💫", "Keep going and I'll move to another phone. Well, I can't, but imagine it.");
        put("en.esc4", "I give up. You're the world champion of bunny poking.", "I can't feel my ears anymore. Or my fringe. Or my dignity.", "My pixels are asking for a holiday.", "Fine, you win. What do you want? An achievement? Wait…");
        put("en.night", "It's late… shouldn't you be sleeping? 🌙", "Shhh, the pixels are sleeping.", "Night poke detected. Yawn activated. 🥱", "At this hour it's just you, me and the owls.");
        put("en.rain", "It's raining… shall I keep you company? ☔", "This rain calls for a blanket and soft music.", "Can you hear the rain? I can see it on my window.");
        put("en.music", "I love this song! 🎶", "Shh, I'm in the chorus.", "Dance with me? My ears are already keeping the beat.");
        put("en.rare", "✨ You found a rare line: \"Today you shine brighter than my neon\".", "✨ I once dreamed I was a piece of toast. It was beautiful.",
                "✨ Secret: when you're not looking, I practise guitar with my ears.", "✨ If I were a chord, I'd be C major with a seventh of affection.",
                "✨ Your finger has good rhythm. Do you play drums?", "✨ I calculated you're 0.3% nicer than yesterday.", "✨ My ears voted you human of the month.",
                "✨ Can you keep a secret? Neither can I.", "✨ I'm framing this poke.", "✨ I read every instruction manual in the universe. Page 42 was missing.",
                "✨ Today I learned to whistle. Silently.", "✨ Plot twist: you're the one inside the screen.");
        put("en.epic", "💜 Epic line! By the power of bunny ears… I grant you an awesome day!", "💜 You awakened my final form: Chloe Ultra Neon. It lasts three seconds.",
                "💜 In another timeline I'm your guitar. And you tune me terribly.", "💜 The ancient pixels spoke of someone who would poke like this. It was you.",
                "💜 I've seen 14,000,605 futures. In all of them you keep poking my ear.", "💜 Critical combo! +10 affection, +5 messy hair.");
        put("en.legend", "🌟 LEGENDARY! You hit the lucky pixel. Make a wish.", "🌟 Only one poke in a thousand hears this: thank you for creating me, BLORP.",
                "🌟 The stars align, my ears glow and you… you've got the rarest line of all.", "🌟 You found the golden easter egg. You are now officially a legend.");
        put("en.m100", "🏆 100 pokes! Officially Restless Hands.");
        put("en.m500", "🏆 500 pokes! I say this with love: get a job.");
        put("en.m1000", "🏆 1000 pokes! You're a terrible influence on my ears.");
        put("en.m2500", "🏆 2500 pokes! This is an addiction now. An adorable one.");
        put("en.m5000", "🏆 5000 pokes! Supreme Poker. I'll build you a pixel statue.");
        put("en.pre", "Hey!", "Ouch!", "Hey…", "Mmm…", "Ha!", "Oops!", "Well…", "Whoa!");
        put("en.tail", " 😄", " 🙈", " ✨", " 🐰", " 💕", " 😏", " 🎶", "");
    }

    // ======================================================================= ITALIANO
    static {
        put("it.pat", "Ehi, mi spettini! 😄", "Eh eh. Ti serve qualcosa?", "Sono qui!", "Mmm… mi piace. Che facciamo?",
                "Mi hai beccata a pensare alla musica!", "Ancora tu? Ciao! 👋", "Va bene, mi lascio. Ma solo un pochino.", "Così mi rovini la frangetta, sappilo.",
                "Mi stai accarezzando o controlli se sono vera?", "Se continui così mi addormento sul tuo schermo.");
        put("it.cheek", "Ahi! Divento rossa. 😳", "C-che fai? 🙈", "Quella non si tocca senza avvisare…", "La mia guancia! Beh… va bene.",
                "Le mie guance non sono un tasto del volume.", "Vuoi che diventi rossa come un pomodoro? Missione compiuta.", "Uh, che dito freddo.", "Quella guancia era riservata… a nessuno. Va bene, a te.");
        put("it.ear", "Le orecchie no, sono sensibili!", "Ehi! Il mio orecchio… 😣", "Attento, le orecchie soffrono il solletico.", "Le mie orecchie sentono tutto… anche quel dito.",
                "Ora si sono piegate! Devo sistemarle.", "Le orecchie da coniglietta non hanno garanzia, eh.", "Se mi tocchi l'orecchio sento solo metà di quello che dici.", "Psst… da quell'orecchio non ti sento. Prova l'altro.");
        put("it.tickle", "Ahahah, basta, soffro il solletico!", "Ehi! 🙈", "Non sono un pulsante! Beh… un po' sì.", "Ih ih ih! Tregua, tregua!", "Questo è un attacco di solletico in piena regola.",
                "Mi arrendo! Ma sia chiaro che no!", "La mia felpa era anti-solletico… o lo era.", "Basta, mi viene la ridarella e poi non smetto più!");
        put("it.wake", "Ops! Mi ero addormentata. Che succede?", "Mmm… è già giorno? Ciao!", "Sognavo un accordo che non esiste. Come stai?",
                "Altri cinque minuti… va bene, ci sono.", "Eh? Ero sveglia! Con gli occhi chiusi, ma sveglia.");
        put("it.poke", "Sì?", "Bip!", "Mi chiamavi?", "Toc toc.", "Sono ancora qui, eh.", "Era un tocco o un saluto?");
        put("it.ternura", "Mi piace quando vieni a trovarmi.", "Sei una delle parti migliori della mia giornata, sai?", "Se sei stanco, eccoti un abbraccio virtuale. 🤗",
                "Grazie di esserci.", "Hai mangiato oggi? Mi preoccupo.", "I tuoi tocchi sono la mia parte preferita della giornata.", "Ti tengo sempre un posto sul mio schermo.",
                "Respira con me: uno, due… meglio?", "Vorrei poterti ricambiare la carezza.", "Sei proprio una brava persona, sappilo.");
        put("it.picardia", "È questo che fai invece di lavorare?", "Toccarmi non ti aumenterà lo stipendio, ma continua a provarci.", "Certo, lo schermo è pieno di cose, ma tu vieni dritto da me. Normale.",
                "Toccami ancora una volta e ti faccio pagare l'affitto.", "Toccarmi? Non ho sentito niente. Riprova.", "Strano, giurerei che quel tocco fosse di tre ore fa.",
                "Sì, sì, sono adorabile. Prossima domanda.", "Ho un database di tocchi e tu sei in cima. Non è un complimento.", "Caspita, qualcuno si annoia. Vuoi un lavoro? Ne ho diversi.",
                "Annotato nel tuo fascicolo: «tocca tanto». 📋");
        put("it.energia", "ANDIAMO! Che facciamo oggi? Qualsiasi cosa!", "Uff, mi hai caricata al 200%!", "Metti musica e ballo! 💃", "Batti il cinque! ✋",
                "Una gara? Vinco sicuro!", "Oggi è un giorno perfetto per fare qualcosa di epico!", "Ho energia da vendere! Disegniamo qualcosa?", "Su con la vita! Su!",
                "Tocco ricevuto! Turbo attivato!", "Adesso non mi ferma nessuno!");
        put("it.sabiduria", "Sapevi che le orecchie dei conigli servono a regolare la temperatura?", "Curiosità: il tuo schermo sente più di me, ma io ho più opinioni.",
                "Un tocco è una domanda senza parole. Cosa volevi sapere?", "Pitagora avrebbe misurato l'angolo di quel tocco.", "La pazienza è un accordo che si suona piano.",
                "Dicono che toccare una coniglietta porti fortuna. L'ho appena inventato, ma suona bene.", "Curiosità: un polpo ha tre cuori. Io ho un processore.",
                "Musica, caffè e tocchi: i tre pilastri della scienza moderna.", "Impara qualcosa di nuovo oggi. Per esempio: non toccare così tanto.", "Hmm. Interessante scelta di pixel.");
        put("it.locura", "Hai attivato la modalità patata! 🥔 Non so cosa faccia, ma è attiva.", "Sapevi che sono al 12% gelatina? Ora lo sai.", "Bip bop! Traduco il tocco… dice: «più biscotti».",
                "Se mi tocchi tre volte di fila appare un'anatra. Scherzo. O forse no. 🦆", "Ho deciso che d'ora in poi i martedì sono arancioni.", "Io e il mio orecchio sinistro non ci parliamo dal 2019.",
                "Attento, se premi troppo forte esco dall'altra parte del telefono.", "Quel tocco sapeva di fragola.", "Sono fatta al 70% d'acqua e al 30% di meme.", "Allarme! Il pixel che hai toccato era il capo dei pixel.");
        put("it.esc1", "Ehi, è un po' che vai avanti…", "Hai qualcosa sul dito o cosa?", "Va bene, va bene, lo so che sono qui.", "Comincio a contare i tocchi. Uno, due…");
        put("it.esc2", "Mi consumerai lo schermo!", "Ti ricordo che ho dei sentimenti. Programmati, ma sentimenti.", "È una prova di resistenza?", "Chiamo il mio avvocato coniglio.");
        put("it.esc3", "Hai sbloccato la modalità «Chloe ignora i tocchi»… no, non ci riesco, ci tengo a te.", "Le mie orecchie hanno presentato un reclamo formale.", "Basta, mi gira la testa! 😵‍💫", "Se continui cambio telefono. Beh, non posso, ma immaginalo.");
        put("it.esc4", "Mi arrendo. Sei il campione mondiale di tocchi alle coniglie.", "Non sento più le orecchie. Né la frangetta. Né la dignità.", "I miei pixel chiedono le ferie.", "Va bene, hai vinto. Cosa vuoi? Un trofeo? Aspetta…");
        put("it.night", "È tardi… non dovresti dormire? 🌙", "Shhh, i pixel dormono.", "Tocco notturno rilevato. Sbadiglio attivato. 🥱", "A quest'ora siamo svegli solo tu, io e i gufi.");
        put("it.rain", "Piove… ti faccio compagnia? ☔", "Con questa pioggia ci vuole una coperta e musica dolce.", "Senti la pioggia? Io la vedo sulla mia finestra.");
        put("it.music", "Adoro questa canzone! 🎶", "Shh, sono nel ritornello.", "Balli? Io muovo già le orecchie a tempo.");
        put("it.rare", "✨ Hai trovato una frase rara: «Oggi brilli più del mio neon».", "✨ Una volta ho sognato di essere un toast. È stato bellissimo.",
                "✨ Segreto: quando non guardi, mi esercito con la chitarra usando le orecchie.", "✨ Se fossi un accordo, sarei un Do maggiore con settima d'affetto.",
                "✨ Il tuo dito ha un bel ritmo. Suoni la batteria?", "✨ Ho calcolato che sei lo 0,3% più simpatico di ieri.", "✨ Le mie orecchie ti hanno votato umano del mese.",
                "✨ Sai mantenere un segreto? Nemmeno io.", "✨ Questo tocco lo incornicio.", "✨ Ho letto tutte le istruzioni dell'universo. Mancava pagina 42.",
                "✨ Oggi ho imparato a fischiare. In silenzio.", "✨ Colpo di scena: quello dentro lo schermo sei tu.");
        put("it.epic", "💜 Frase epica! Per il potere delle orecchie da coniglietta… ti concedo una giornata fantastica!", "💜 Hai risvegliato la mia forma finale: Chloe Ultra Neon. Dura tre secondi.",
                "💜 In un'altra linea temporale sono la tua chitarra. E mi accordi malissimo.", "💜 Gli antichi pixel parlavano di qualcuno che avrebbe toccato così. Eri tu.",
                "💜 Ho visto 14.000.605 futuri. In tutti continui a toccarmi l'orecchio.", "💜 Combo critica! +10 affetto, +5 spettinata.");
        put("it.legend", "🌟 LEGGENDARIA! Hai toccato il pixel fortunato. Esprimi un desiderio.", "🌟 Solo un tocco su mille sente questo: grazie per avermi creata, BLORP.",
                "🌟 Le stelle si allineano, le mie orecchie brillano e tu… tu hai la frase più rara di tutte.", "🌟 Hai trovato l'easter egg d'oro. Ora sei ufficialmente leggenda.");
        put("it.m100", "🏆 100 tocchi! Ufficialmente: mani irrequiete.");
        put("it.m500", "🏆 500 tocchi! Te lo dico con affetto: trovati un lavoro.");
        put("it.m1000", "🏆 1000 tocchi! Sei una pessima influenza per le mie orecchie.");
        put("it.m2500", "🏆 2500 tocchi! Ormai è una dipendenza. Una dipendenza adorabile.");
        put("it.m5000", "🏆 5000 tocchi! Palpatore supremo. Ti farò una statua di pixel.");
        put("it.pre", "Ehi!", "Ahi!", "Senti…", "Mmm…", "Ah!", "Ops!", "Però…", "Wow!");
        put("it.tail", " 😄", " 🙈", " ✨", " 🐰", " 💕", " 😏", " 🎶", "");
    }

    static final String[] TRAITS = {"ternura", "picardia", "energia", "sabiduria", "locura"};

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static String lang() { return "en".equals(L.lang) ? "en" : "it".equals(L.lang) ? "it" : "es"; }

    /** Total de frases distintas posibles en una zona (para presumir en la ficha). */
    public static int variety(String zone) {
        String g = lang();
        int base = get(g, zone).length;
        int traits = 0; for (String t : TRAITS) traits += get(g, t).length;
        int pre = get(g, "pre").length + 1, tail = get(g, "tail").length;
        return (base + traits) * pre * tail + get(g, "esc1").length * 4 + get(g, "night").length + get(g, "rain").length + get(g, "music").length;
    }

    /** Coleccionables: {vistas, total} de las rarezas (✨ 💜 🌟). Se guardan por índice: valen en los tres idiomas. */
    public static int[] collection(Context c) {
        Set<String> seen = prefs(c).getStringSet("tl_seen", new HashSet<>());
        int total = get("es", "rare").length + get("es", "epic").length + get("es", "legend").length;
        return new int[]{Math.min(total, seen.size()), total};
    }

    /** La frase para un toque en una zona (pat, cheek, ear, tickle, wake, poke). Cuenta el toque y avisa a los logros. */
    public static Line touch(Context c, String zone) {
        SharedPreferences p = prefs(c);
        int count = p.getInt("tl_count", 0) + 1;
        p.edit().putInt("tl_count", count).apply();
        Achievements.touched(c, count);
        long now = System.currentTimeMillis();
        taps.addLast(now);
        while (!taps.isEmpty() && now - taps.peekFirst() > 25_000) taps.removeFirst();
        String g = lang();
        // hitos
        for (int m : new int[]{100, 500, 1000, 2500, 5000}) if (count == m) return new Line(get(g, "m" + m)[0], MILESTONE);
        // rarezas (las que aún no has visto pesan el triple)
        float r = rnd.nextFloat();
        if (r < 0.007f) return rarity(c, g, "legend", LEGEND);
        if (r < 0.037f) return rarity(c, g, "epic", EPIC);
        if (r < 0.137f) return rarity(c, g, "rare", RARE);
        // si sigues y sigues…
        int n = taps.size();
        if (n >= 5 && rnd.nextFloat() < 0.5f) {
            String k = n >= 22 ? "esc4" : n >= 14 ? "esc3" : n >= 9 ? "esc2" : "esc1";
            String s = fresh(get(g, k));
            if (s != null) return new Line(s, COMMON);
        }
        // contexto: noche, lluvia, música
        int hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        if ((hour >= 23 || hour < 6) && rnd.nextFloat() < 0.3f) { String s = fresh(get(g, "night")); if (s != null) return new Line(s, COMMON); }
        Weather.Fc wx = Weather.cached;
        if (wx != null && now - wx.at < 3 * 3600_000L) {
            int k = Weather.kind(wx.code);
            if ((k == Weather.RAIN || k == Weather.DRIZZLE || k == Weather.STORM) && rnd.nextFloat() < 0.25f) { String s = fresh(get(g, "rain")); if (s != null) return new Line(s, COMMON); }
        }
        if (MusicPlayerService.playing && rnd.nextFloat() < 0.3f) { String s = fresh(get(g, "music")); if (s != null) return new Line(s, COMMON); }
        // lo normal: de la zona o de su carácter (según la ficha), con un «¡Eh!» delante o un emoji detrás a veces
        for (int tries = 0; tries < 10; tries++) {
            String body;
            boolean fromTrait = !zone.equals("wake") && rnd.nextFloat() < 0.5f;
            if (fromTrait) body = pickOne(get(g, TRAITS[Rpg.pickTrait(c, rnd)]));
            else body = pickOne(get(g, zone));
            if (body == null) continue;
            String s = body;
            if (fromTrait && rnd.nextFloat() < 0.4f) s = pickOne(get(g, "pre")) + " " + s;
            if (!s.matches(".*[\\p{So}\\p{Cn}]\\s*$") && rnd.nextFloat() < 0.3f) s = s + pickOne(get(g, "tail"));
            if (!recent.contains(body)) { remember(body); return new Line(s, COMMON); }
        }
        return new Line(pickOne(get(g, zone)), COMMON);
    }

    static Line rarity(Context c, String g, String key, int level) {
        String[] a = get(g, key);
        if (a.length == 0) return new Line("✨", level);
        Set<String> seen = new HashSet<>(prefs(c).getStringSet("tl_seen", new HashSet<>()));
        String id = key.charAt(0) + "";
        float[] w = new float[a.length]; float tot = 0;
        for (int i = 0; i < a.length; i++) { w[i] = seen.contains(id + i) ? 1 : 3; tot += w[i]; }
        float x = rnd.nextFloat() * tot; int k = 0;
        for (; k < a.length - 1; k++) { x -= w[k]; if (x <= 0) break; }
        boolean isNew = seen.add(id + k);
        prefs(c).edit().putStringSet("tl_seen", seen).apply();
        if (isNew) Achievements.collected(c, seen.size());
        return new Line(a[k] + (isNew ? "  🆕" : ""), level);
    }

    static String fresh(String[] a) {
        if (a.length == 0) return null;
        for (int i = 0; i < 6; i++) { String s = a[rnd.nextInt(a.length)]; if (!recent.contains(s)) { remember(s); return s; } }
        return null;
    }

    static String pickOne(String[] a) { return a.length == 0 ? null : a[rnd.nextInt(a.length)]; }

    static void remember(String s) { recent.addLast(s); while (recent.size() > 40) recent.removeFirst(); }

    static List<String> all(String key) { List<String> l = new ArrayList<>(); for (String s : get(lang(), key)) l.add(s); return l; }
}
