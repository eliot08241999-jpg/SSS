package com.aplauso.encuentra;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/** v1.8 · 🎸 Biblioteca de acordes calculada (cualquier instrumento y afinación), «¿qué acorde es?», práctica y progresiones. */
public class ChordsActivity extends NeonActivity {
    int root = 0, capo = 0;
    String type = "";
    LinearLayout chordBox, rootRow, typeRow, whatBox, progBox, practiceBox;
    TextView instBtn, capoBtn, whatRes;
    MusicViews.ChordDiagram whatDg;
    final Random rnd = new Random();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🎸 ACORDES");
        LinearLayout top = panel(null);
        instBtn = button("", v -> pickInstrument());
        top.addView(instBtn, gapBelow(6));
        LinearLayout r = new LinearLayout(this);
        capoBtn = button("", v -> pickCapo());
        r.addView(capoBtn, new LinearLayout.LayoutParams(0, -2, 1));
        android.widget.Switch lefty = neonSwitch("Zurdo");
        lefty.setChecked(p.getBoolean("mus_lefty", false));
        lefty.setOnCheckedChangeListener((v, on) -> { p.edit().putBoolean("mus_lefty", on).apply(); showChord(); });
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(-2, -2); ll.leftMargin = dpi(10);
        r.addView(lefty, ll);
        top.addView(r, gapBelow(8));
        rootRow = new LinearLayout(this);
        top.addView(scroll(rootRow), gapBelow(6));
        typeRow = new LinearLayout(this);
        top.addView(scroll(typeRow), gapBelow(6));
        chordBox = new LinearLayout(this);
        chordBox.setOrientation(LinearLayout.VERTICAL);
        top.addView(chordBox);
        top.addView(button("💡 ALTERNATIVAS A ESTE ACORDE", v -> ChordPopup.alternatives(this, cur(), capo, null)), gapBelow(4));
        col.addView(top, gapBelow(12));

        whatBox = panel("◢ 🔍 ¿QUÉ ACORDE ES?");
        whatBox.addView(text("Pon los dedos tocando el mástil (toca encima para cuerda al aire ↔ que no suene), o tócalo en tu instrumento y lo escucho.", 12));
        whatDg = new MusicViews.ChordDiagram(this);
        whatBox.addView(whatDg, new LinearLayout.LayoutParams(-1, -2));
        whatRes = neonText("", 16);
        whatBox.addView(whatRes, gapBelow(6));
        whatBox.addView(button("🎤 ESCUCHAR LO QUE TOCO", v -> listenWhat()), gapBelow(4));
        whatBox.addView(button("↺ BORRAR", v -> { resetWhat(); }));
        col.addView(whatBox, gapBelow(12));

        practiceBox = panel("◢ 🎯 PRACTICAR");
        practiceBox.addView(button("🎸 TOCAR ACORDE (te escucho y te digo si suena bien)", v -> practice(false)), gapBelow(6));
        practiceBox.addView(button("🧠 DE MEMORIA (solo el nombre)", v -> practice(true)), gapBelow(6));
        practiceBox.addView(button("❓ CUESTIONARIO (sin instrumento)", v -> quiz()));
        col.addView(practiceBox, gapBelow(12));

        progBox = panel("◢ 🔁 PROGRESIONES POR TONALIDAD");
        progBox.addView(button("ELEGIR TONALIDAD Y PROGRESIÓN", v -> pickProgression()), gapBelow(6));
        col.addView(progBox, gapBelow(12));

        String q = getIntent().getStringExtra("chord");
        if (q != null) { MusicTheory.Chord c = MusicTheory.parseChord(q, MusicTheory.notation(this)); if (c != null) { root = c.root; type = c.type; } }
        build();
    }

    HorizontalScrollView scroll(LinearLayout row) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        return hs;
    }

    MusicTheory.Chord cur() { MusicTheory.Chord c = new MusicTheory.Chord(); c.root = root; c.type = type; return c; }

    void build() {
        String id = p.getString("mus_chord_instr", "gtr6");
        instBtn.setText("🎸 " + ("piano".equals(id) ? L.t("Piano") : L.t(MusicTheory.byId(this, id).name)) + "  ▾");
        capoBtn.setText(L.t("Cejilla (capo)") + ": " + (capo == 0 ? L.t("no") : String.valueOf(capo)));
        rootRow.removeAllViews();
        for (int i = 0; i < 12; i++) {
            final int k = i;
            TextView t = button(MusicTheory.name(this, i), v -> { root = k; build(); });
            t.setTextSize(15);
            t.setAlpha(i == root ? 1f : 0.45f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpi(58), -2); lp.rightMargin = dpi(4);
            rootRow.addView(t, lp);
        }
        typeRow.removeAllViews();
        for (String t0 : MusicTheory.TYPES.keySet()) {
            String label = t0.isEmpty() ? L.t("mayor") : t0.equals("m") ? L.t("menor") : t0;
            TextView t = button(label, v -> { type = t0; build(); });
            t.setTextSize(13);
            t.setAlpha(t0.equals(type) ? 1f : 0.45f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dpi(4);
            typeRow.addView(t, lp);
        }
        showChord();
        resetWhat();
    }

    void showChord() {
        chordBox.removeAllViews();
        chordBox.addView(ChordPopup.chordView(this, cur(), capo));
        if (capo > 0) {
            TextView t = text(L.t("Con cejilla en el") + " " + capo + ", " + L.t("esta forma suena como") + " " + cur().transpose(capo).name(this) + ".", 12);
            t.setTextColor(Color.rgb(255, 210, 120));
            chordBox.addView(t);
        }
    }

    void pickInstrument() {
        List<MusicTheory.Instrument> l = MusicTheory.all(this);
        List<String> names = new ArrayList<>(), ids = new ArrayList<>();
        for (MusicTheory.Instrument i : l) if (i.fretted) { names.add(L.t(i.name)); ids.add(i.id); }
        names.add(L.t("🎹 Piano")); ids.add("piano");
        new android.app.AlertDialog.Builder(this).setItems(names.toArray(new String[0]), (d, w) -> {
            p.edit().putString("mus_chord_instr", ids.get(w)).apply();
            build();
        }).show();
    }

    void pickCapo() {
        String[] o = new String[10];
        for (int i = 0; i < 10; i++) o[i] = i == 0 ? L.t("Sin cejilla") : L.t("Traste") + " " + i;
        new android.app.AlertDialog.Builder(this).setItems(o, (d, w) -> { capo = w; build(); }).show();
    }

    // ------------------------------------------------------------------ ¿qué acorde es?
    void resetWhat() {
        int[] st = ChordPopup.strings(this);
        whatBox.setVisibility(View.VISIBLE);
        if (st == null) { whatDg.setVisibility(View.GONE); whatRes.setText(L.t("Toca el acorde en tu piano y pulsa ESCUCHAR.")); return; }
        whatDg.setVisibility(View.VISIBLE);
        whatDg.startEdit(st.length);
        whatDg.onEdit = this::nameWhat;
        nameWhat();
    }

    void nameWhat() {
        int[] st = ChordPopup.strings(this);
        if (st == null || whatDg.edit == null) return;
        Set<Integer> pcs = new HashSet<>();
        int low = 999;
        for (int s = 0; s < st.length; s++) {
            if (whatDg.edit[s] < 0) continue;
            int m = st[s] + capo + whatDg.edit[s];
            pcs.add(MusicTheory.mod12(m));
            low = Math.min(low, m);
        }
        whatRes.setText(namesFor(pcs, low == 999 ? -1 : MusicTheory.mod12(low)));
    }

    /** Todos los nombres posibles para esas notas (el que tiene el bajo como fundamental, primero). */
    String namesFor(Set<Integer> pcs, int bassPc) {
        if (pcs.size() < 2) return L.t("Pon al menos dos notas.");
        List<String> exact = new ArrayList<>(), slash = new ArrayList<>();
        for (int r = 0; r < 12; r++) for (String t : MusicTheory.TYPES.keySet()) {
            Set<Integer> s = new HashSet<>();
            for (int i : MusicTheory.TYPES.get(t)) s.add(MusicTheory.mod12(r + i));
            if (!s.equals(pcs)) continue;
            MusicTheory.Chord c = new MusicTheory.Chord(); c.root = r; c.type = t;
            if (bassPc < 0 || bassPc == r) exact.add(c.name(this));
            else { c.bass = bassPc; slash.add(c.name(this)); }
        }
        exact.addAll(slash);
        if (exact.isEmpty()) {
            StringBuilder sb = new StringBuilder(L.t("No es un acorde de la lista. Notas") + ": ");
            for (int pc : pcs) sb.append(MusicTheory.name(this, pc)).append(' ');
            return sb.toString().trim();
        }
        return "= " + android.text.TextUtils.join("  ·  ", exact.subList(0, Math.min(4, exact.size())));
    }

    boolean mic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) return true;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 7);
        return false;
    }

    void listenWhat() {
        if (!mic()) return;
        whatRes.setText(L.t("🎤 Toca el acorde ahora…"));
        MusicAudio.listenChroma(2500, (ch, lvl) -> runOnUiThread(() -> {
            if (lvl < 0.01f) { whatRes.setText(L.t("No he oído nada. Tócalo más fuerte o acerca el móvil.")); return; }
            // las 3-4 notas más fuertes
            Set<Integer> pcs = new HashSet<>();
            Integer[] idx = new Integer[12];
            for (int i = 0; i < 12; i++) idx[i] = i;
            java.util.Arrays.sort(idx, (a, b) -> Float.compare(ch[b], ch[a]));
            for (int i = 0; i < 4; i++) if (ch[idx[i]] > 0.45f) pcs.add(idx[i]);
            String best = bestChord(ch);
            whatRes.setText((best == null ? namesFor(pcs, -1) : "= " + best) + "\n" + L.t("(por el sonido; puede confundir acordes muy parecidos)"));
        }));
    }

    /** El acorde que mejor encaja con lo que sonó. */
    String bestChord(float[] ch) {
        double best = -1; String name = null;
        for (int r = 0; r < 12; r++) for (String t : new String[]{"", "m", "7", "m7", "maj7", "sus2", "sus4", "dim", "5"}) {
            int[] iv = MusicTheory.TYPES.get(t);
            Set<Integer> s = new HashSet<>();
            for (int i : iv) s.add(MusicTheory.mod12(r + i));
            double in = 0, out = 0;
            for (int pc = 0; pc < 12; pc++) if (s.contains(pc)) in += ch[pc]; else out += ch[pc];
            double score = in / s.size() - out / (12 - s.size()) * 1.2 + (pcMax(ch) == r ? 0.05 : 0);
            if (score > best) { best = score; MusicTheory.Chord c = new MusicTheory.Chord(); c.root = r; c.type = t; name = c.name(this); }
        }
        return best > 0.25 ? name : null;
    }

    static int pcMax(float[] ch) { int m = 0; for (int i = 1; i < 12; i++) if (ch[i] > ch[m]) m = i; return m; }

    // ------------------------------------------------------------------ práctica
    static final String[] COMMON = {"C", "G", "D", "A", "E", "F", "Am", "Em", "Dm", "G7", "C7", "D7", "A7", "E7", "B7", "Bm", "F#m", "Cmaj7", "Fmaj7", "Asus4", "Dsus2"};

    MusicTheory.Chord randomChord() { return MusicTheory.parseChord(COMMON[rnd.nextInt(COMMON.length)], MusicTheory.EN); }

    void practice(boolean memory) {
        MusicTheory.Chord c = randomChord();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dpi(16), dpi(8), dpi(16), dpi(8));
        TextView title = neonText(c.name(this), 30);
        title.setGravity(android.view.Gravity.CENTER);
        box.addView(title);
        LinearLayout dg = ChordPopup.chordView(this, c, capo);
        if (memory) dg.setVisibility(View.GONE);
        box.addView(dg);
        TextView res = text(memory ? "Ponlo de memoria y pulsa ESCUCHAR." : "Ponlo y pulsa ESCUCHAR.", 14);
        box.addView(res);
        android.app.AlertDialog d = new android.app.AlertDialog.Builder(this).setView(box)
                .setPositiveButton(L.t("🎤 ESCUCHAR"), null)
                .setNeutralButton(L.t("Otro"), (x, w) -> practice(memory))
                .setNegativeButton(L.t("Salir"), null).create();
        d.setOnShowListener(x -> d.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (!mic()) return;
            res.setText(L.t("🎤 Tócalo ahora…"));
            MusicAudio.listenChroma(2500, (ch, lvl) -> runOnUiThread(() -> {
                if (lvl < 0.01f) { res.setText(L.t("No he oído nada.")); return; }
                int[][] j = MusicAudio.judge(ch, c.pcs());
                if (j[0].length == 0 && j[1].length == 0) res.setText("✅ " + L.t("¡Suena bien!"));
                else {
                    StringBuilder sb = new StringBuilder("⚠ ");
                    if (j[0].length > 0) { sb.append(L.t("No oigo")).append(": "); for (int pc : j[0]) sb.append(MusicTheory.name(this, pc)).append(' '); }
                    if (j[1].length > 0) { sb.append(L.t("Sobra")).append(": "); for (int pc : j[1]) sb.append(MusicTheory.name(this, pc)).append(' '); }
                    sb.append("\n").append(L.t("Revisa que cada dedo pise bien y que no rocen otras cuerdas."));
                    res.setText(sb.toString());
                    dg.setVisibility(View.VISIBLE);
                }
            }));
        }));
        d.show();
    }

    int quizOk, quizN;

    void quiz() {
        MusicTheory.Chord c = randomChord();
        List<MusicTheory.Chord> opts = new ArrayList<>();
        opts.add(c);
        while (opts.size() < 4) { MusicTheory.Chord x = randomChord(); if (!opts.contains(x)) opts.add(x); }
        java.util.Collections.shuffle(opts, rnd);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout dg = ChordPopup.chordView(this, c, 0);
        // esconder el nombre: el título del diagrama lo diría
        int[] st = ChordPopup.strings(this);
        if (st != null && dg.getChildAt(0) instanceof MusicViews.ChordDiagram) {
            MusicViews.ChordDiagram cd = (MusicViews.ChordDiagram) dg.getChildAt(0);
            List<MusicTheory.Voicing> vs = MusicTheory.voicings(c, st, 0, 1);
            cd.set("?", vs.isEmpty() ? null : vs.get(0), st.length, p.getBoolean("mus_lefty", false));
        }
        box.addView(dg);
        String[] names = new String[4];
        for (int i = 0; i < 4; i++) names[i] = opts.get(i).name(this);
        new android.app.AlertDialog.Builder(this).setTitle(L.t("¿Qué acorde es?") + (quizN > 0 ? "  (" + quizOk + "/" + quizN + ")" : "")).setView(box)
                .setItems(names, (d, w) -> {
                    quizN++;
                    boolean ok = opts.get(w).equals(c);
                    if (ok) quizOk++;
                    toast(ok ? "✅ " + L.t("¡Correcto!") : "❌ " + L.t("Era") + " " + c.name(this));
                    quiz();
                }).setNegativeButton(L.t("Salir"), null).show();
    }

    // ------------------------------------------------------------------ progresiones
    void pickProgression() {
        String[] keys = new String[24];
        for (int i = 0; i < 12; i++) { keys[i] = MusicTheory.name(this, i) + " " + L.t("mayor"); keys[12 + i] = MusicTheory.name(this, i) + " " + L.t("menor"); }
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Tonalidad")).setItems(keys, (d, w) -> {
            boolean minor = w >= 12;
            int key = minor ? MusicTheory.mod12(w - 12 + 3) : w;     // en menor: las progresiones se calculan desde la relativa mayor
            String[] pn = new String[MusicTheory.PROGRESSIONS.length];
            for (int i = 0; i < pn.length; i++) pn[i] = L.t(MusicTheory.PROGRESSIONS[i][0]);
            new android.app.AlertDialog.Builder(this).setTitle(keys[w]).setItems(pn, (d2, w2) -> {
                String spec = MusicTheory.PROGRESSIONS[w2][1];
                int base = minor && spec.startsWith("0:m") ? w - 12 : key;
                List<MusicTheory.Chord> l = MusicTheory.progression(spec, base);
                showProgression(keys[w] + " · " + pn[w2], l);
            }).show();
        }).show();
    }

    void showProgression(String title, List<MusicTheory.Chord> l) {
        while (progBox.getChildCount() > 2) progBox.removeViewAt(2);
        progBox.addView(neonText(title, 13));
        LinearLayout row = new LinearLayout(this);
        for (MusicTheory.Chord c : l) {
            TextView t = button(c.name(this), v -> ChordPopup.show(this, c, capo, null));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dpi(6);
            row.addView(t, lp);
        }
        progBox.addView(scroll(row), gapBelow(6));
        TextView play = button("▶ " + L.t("ESCUCHAR LA PROGRESIÓN"), v -> new Thread(() -> {
            int[] st = ChordPopup.strings(this);
            for (MusicTheory.Chord c : l) {
                int[] notes;
                if (st == null) { int[] iv = c.intervals(); notes = new int[iv.length]; for (int i = 0; i < iv.length; i++) notes[i] = 60 + c.root + iv[i]; }
                else {
                    List<MusicTheory.Voicing> vs = MusicTheory.voicings(c, st, capo, 1);
                    if (vs.isEmpty()) continue;
                    notes = new int[st.length];
                    for (int s = 0; s < st.length; s++) notes[s] = vs.get(0).frets[s] < 0 ? -1 : st[s] + capo + vs.get(0).frets[s];
                }
                MusicAudio.playNotes(notes, 30, p.getFloat("tun_a4", 440f));
                try { Thread.sleep(1300); } catch (InterruptedException ignored) {}
            }
        }).start());
        progBox.addView(play);
    }
}
