package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * v1.8.2 · 🔤 OCR: lee el texto de PDF escaneados (páginas que son fotos) con ML Kit, dentro del teléfono.
 * El resultado se guarda, así la próxima vez el lector, la voz y el traductor ya lo tienen.
 */
public class Ocr {
    public interface Prog { void on(int page, int total); boolean cancelled(); }

    static File cache(Context c, Uri u) {
        String key = Media.nameOf(c, u) + "|" + u.toString();
        return new File(new File(c.getFilesDir(), "ocr"), Integer.toHexString(key.hashCode()) + ".txt");
    }

    /** Párrafos ya leídos antes (o null). */
    static List<String> cached(Context c, Uri u) {
        File f = cache(c, u);
        if (!f.exists()) return null;
        try {
            List<String> l = new ArrayList<>();
            for (String s : new String(java.nio.file.Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8).split("\n\n")) if (!s.trim().isEmpty()) l.add(s.trim());
            return l;
        } catch (Exception e) { return null; }
    }

    /** Lee todas las páginas. Bloquea: llamar fuera del hilo principal. */
    static List<String> pdf(Context c, Uri u, Prog p) throws Exception {
        DocPdf.Pages pg = new DocPdf.Pages(c, u);
        com.google.mlkit.vision.text.TextRecognizer rec = com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS);
        List<String> out = new ArrayList<>();
        try {
            int n = pg.count();
            for (int i = 0; i < n; i++) {
                if (p != null) { if (p.cancelled()) throw new InterruptedException(); p.on(i, n); }
                Bitmap b = pg.render(i, 1700);
                if (b == null) continue;
                Bitmap w = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
                Canvas cv = new Canvas(w); cv.drawColor(Color.WHITE); cv.drawBitmap(b, 0, 0, null);
                com.google.mlkit.vision.text.Text t = com.google.android.gms.tasks.Tasks.await(rec.process(com.google.mlkit.vision.common.InputImage.fromBitmap(w, 0)),
                        60, java.util.concurrent.TimeUnit.SECONDS);
                if (t == null) continue;
                for (com.google.mlkit.vision.text.Text.TextBlock bl : t.getTextBlocks()) {
                    String s = bl.getText().replaceAll("-\\n(\\p{Ll})", "$1").replace('\n', ' ').replaceAll("\\s+", " ").trim();
                    if (!s.isEmpty()) out.add(s);
                }
            }
        } finally { try { rec.close(); } catch (Exception ignored) {} }
        File f = cache(c, u);
        f.getParentFile().mkdirs();
        java.nio.file.Files.write(f.toPath(), String.join("\n\n", out).getBytes(StandardCharsets.UTF_8));
        return out;
    }

    /** ¿Parece escaneado? (casi sin texto para las páginas que tiene) */
    static boolean scanned(DocIO.Doc d, int pages) {
        int chars = 0; for (String s : d.paras) chars += s.length();
        return pages > 0 && chars < 60 * pages;
    }
}
