package com.aplauso.encuentra;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * v1.8 · 🎞 FOTOGRAMAS Y GIF: separar un vídeo en fotos (todas, X por segundo o un número total, con recomendaciones,
 * descartando borrosas y repetidas) y crear GIF desde un vídeo o desde varias fotos (velocidad, bucle, ida y vuelta, texto).
 */
public class FramesGifActivity extends NeonActivity {
    static final int REQ_VIDEO = 81, REQ_PHOTOS = 82;
    final Handler h = new Handler(Looper.getMainLooper());
    Uri video;
    List<Uri> photos = new ArrayList<>();
    String name = "video";
    long durMs;
    float fps = 30;
    int vw, vh;
    float startS, endS;
    TextView info, rangeTv, estTv, modeBtn, fmtBtn, gifInfo, gifFpsBtn, gifSizeBtn, gifLoopBtn, gifSpeedBtn;
    android.widget.Switch skipBlur, skipDup;
    EditText topText, bottomText;
    NeonProgress prog;
    volatile boolean busy, cancel;
    Uri lastGif;

    // modos de fotogramas
    static final String[] MODES = {"Todos los fotogramas", "1 por segundo", "2 por segundo", "3 por segundo", "5 por segundo", "10 por segundo", "12 por segundo (como el anime)",
            "15 por segundo", "Un número total…", "Uno por cambio de escena"};
    int mode = 3, total = 20;
    boolean png;
    int gifFps = 12, gifWidth = 320, gifLoop = 0;
    float gifSpeed = 1f;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🎞 FOTOGRAMAS Y GIF");
        LinearLayout a = panel("◢ VÍDEO");
        info = text("Elige un vídeo para separarlo en fotos o convertir un trozo en GIF.", 13);
        a.addView(info);
        a.addView(button("🎞 ELEGIR VÍDEO", v -> PickActivity.start(this, new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_VIDEO, "frames_video")), gapBelow(6));
        rangeTv = text("", 13);
        a.addView(rangeTv);
        LinearLayout rr = new LinearLayout(this);
        rr.addView(button("⏮ INICIO", v -> askTime(true)), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(0, -2, 1); rl.leftMargin = dpi(6);
        rr.addView(button("FIN ⏭", v -> askTime(false)), rl);
        a.addView(rr, gapBelow(4));
        col.addView(a, gapBelow(12));

        LinearLayout f = panel("◢ 🖼 SEPARAR EN FOTOGRAMAS");
        f.addView(text("¿Para qué los quieres? (elige y se ajusta solo)", 12));
        LinearLayout rec = new LinearLayout(this);
        recBtn(rec, "🎞 GIF", 6);
        recBtn(rec, "🖼 Mejor foto", 3);
        recBtn(rec, "🎨 Dibujar encima", 6);
        recBtn(rec, "📚 Resumen", 9);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.addView(rec);
        f.addView(hs, gapBelow(6));
        modeBtn = button("", v -> pickMode());
        f.addView(modeBtn, gapBelow(6));
        fmtBtn = button("", v -> { png = !png; refresh(); });
        f.addView(fmtBtn, gapBelow(6));
        skipBlur = neonSwitch("Descartar los borrosos");
        skipDup = neonSwitch("Descartar los repetidos (casi iguales al anterior)");
        skipBlur.setOnCheckedChangeListener((x, on) -> refresh());
        skipDup.setOnCheckedChangeListener((x, on) -> refresh());
        f.addView(skipBlur);
        f.addView(skipDup);
        estTv = text("", 12);
        estTv.setTextColor(Color.rgb(255, 210, 120));
        f.addView(estTv, gapBelow(6));
        f.addView(button("▶ SACAR FOTOGRAMAS", v -> extract()));
        col.addView(f, gapBelow(12));

        LinearLayout g = panel("◢ 🎞 CREAR GIF");
        g.addView(text("Del trozo elegido del vídeo, o de varias fotos.", 12));
        g.addView(button("🖼 USAR VARIAS FOTOS EN VEZ DEL VÍDEO", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            PickActivity.start(this, i, REQ_PHOTOS, "gif_photos");
        }), gapBelow(6));
        gifInfo = text("", 12);
        g.addView(gifInfo);
        gifFpsBtn = button("", v -> pick(new String[]{"5", "8", "10", "12", "15", "20"}, w -> gifFps = new int[]{5, 8, 10, 12, 15, 20}[w]));
        g.addView(gifFpsBtn, gapBelow(6));
        gifSizeBtn = button("", v -> pick(new String[]{"240 px", "320 px", "400 px", "480 px", "640 px"}, w -> gifWidth = new int[]{240, 320, 400, 480, 640}[w]));
        g.addView(gifSizeBtn, gapBelow(6));
        gifSpeedBtn = button("", v -> pick(new String[]{"0,25×", "0,5×", "1×", "1,5×", "2×", "4×"}, w -> gifSpeed = new float[]{0.25f, 0.5f, 1f, 1.5f, 2f, 4f}[w]));
        g.addView(gifSpeedBtn, gapBelow(6));
        gifLoopBtn = button("", v -> pick(new String[]{"Normal", "Al revés", "Ida y vuelta (boomerang)"}, w -> gifLoop = w));
        g.addView(gifLoopBtn, gapBelow(6));
        topText = edit("Texto de arriba (opcional, tipo meme)");
        bottomText = edit("Texto de abajo (opcional)");
        g.addView(topText, gapBelow(4));
        g.addView(bottomText, gapBelow(6));
        g.addView(button("▶ CREAR GIF", v -> makeGif()), gapBelow(6));
        g.addView(button("📤 COMPARTIR EL ÚLTIMO GIF", v -> {
            if (lastGif == null) { toast(L.t("Primero crea un GIF.")); return; }
            startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("image/gif").putExtra(Intent.EXTRA_STREAM, lastGif).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), L.t("Compartir GIF")));
        }));
        col.addView(g, gapBelow(12));

        LinearLayout pr = panel("◢ PROGRESO");
        prog = new NeonProgress(this);
        pr.addView(prog, gapBelow(6));
        pr.addView(button("✕ CANCELAR", v -> cancel = true));
        col.addView(pr, gapBelow(12));
        if (getIntent().getData() != null) openVideo(getIntent().getData());
        refresh();
    }

    EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(L.t(hint));
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setSingleLine(true);
        e.setBackground(frame(10));
        e.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        return e;
    }

    interface Pick { void at(int w); }

    void pick(String[] o, Pick k) {
        String[] t = new String[o.length];
        for (int i = 0; i < o.length; i++) t[i] = L.t(o[i]);
        new android.app.AlertDialog.Builder(this).setItems(t, (d, w) -> { k.at(w); refresh(); }).show();
    }

    void recBtn(LinearLayout row, String label, int m) {
        TextView t = button(label, v -> {
            mode = m;
            if (label.startsWith("🖼")) { skipBlur.setChecked(true); skipDup.setChecked(true); }
            else if (label.startsWith("🎞")) { skipBlur.setChecked(false); skipDup.setChecked(false); }
            else if (label.startsWith("🎨")) { skipBlur.setChecked(false); skipDup.setChecked(false); png = true; }
            refresh();
        });
        t.setTextSize(12);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dpi(5);
        row.addView(t, lp);
    }

    void pickMode() {
        pick(MODES, w -> {
            mode = w;
            if (w == 8) {
                EditText e = new EditText(this);
                e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                e.setText(String.valueOf(total));
                new android.app.AlertDialog.Builder(this).setTitle(L.t("¿Cuántos en total?")).setView(e).setPositiveButton("OK", (d, x) -> {
                    total = Math.max(1, Math.min(2000, SongbookActivity.parse(e.getText().toString())));
                    refresh();
                }).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        if (req == REQ_VIDEO && data.getData() != null) openVideo(data.getData());
        if (req == REQ_PHOTOS) {
            photos.clear();
            if (data.getClipData() != null) for (int i = 0; i < data.getClipData().getItemCount(); i++) photos.add(data.getClipData().getItemAt(i).getUri());
            else if (data.getData() != null) photos.add(data.getData());
            refresh();
        }
    }

    void openVideo(Uri u) {
        video = u;
        photos.clear();
        MediaMetadataRetriever mr = new MediaMetadataRetriever();
        try {
            mr.setDataSource(this, u);
            durMs = Long.parseLong(nz(mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION), "0"));
            vw = Integer.parseInt(nz(mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH), "0"));
            vh = Integer.parseInt(nz(mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT), "0"));
            String rot = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            if ("90".equals(rot) || "270".equals(rot)) { int t = vw; vw = vh; vh = t; }
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                String fc = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT);
                if (fc != null && durMs > 0) fps = Math.max(1, Math.min(120, Long.parseLong(fc) * 1000f / durMs));
            }
        } catch (Exception e) { toast(L.t("No puedo abrir ese vídeo.")); video = null; }
        finally { try { mr.release(); } catch (Exception ignored) {} }
        String s = u.getLastPathSegment();
        name = s == null ? "video" : s.replaceAll(".*[/:]", "").replaceAll("\\.[A-Za-z0-9]+$", "");
        startS = 0;
        endS = durMs / 1000f;
        refresh();
    }

    static String nz(String s, String d) { return s == null || s.isEmpty() ? d : s; }

    void askTime(boolean start) {
        if (video == null) { toast(L.t("Primero elige un vídeo.")); return; }
        EditText e = new EditText(this);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(String.format(Locale.ROOT, "%.1f", start ? startS : endS));
        new android.app.AlertDialog.Builder(this).setTitle(start ? L.t("Inicio (segundos)") : L.t("Fin (segundos)")).setView(e).setPositiveButton("OK", (d, w) -> {
            try {
                float v = Float.parseFloat(e.getText().toString().replace(',', '.'));
                v = Math.max(0, Math.min(durMs / 1000f, v));
                if (start) startS = Math.min(v, endS - 0.1f); else endS = Math.max(v, startS + 0.1f);
            } catch (Exception ignored) {}
            refresh();
        }).show();
    }

    /** Momentos (en microsegundos) de los fotogramas que se van a sacar. */
    List<Long> times() {
        List<Long> l = new ArrayList<>();
        float len = Math.max(0.05f, endS - startS);
        float step;
        if (mode == 0) step = 1f / fps;
        else if (mode == 8) step = len / Math.max(1, total);
        else if (mode == 9) step = 1f / Math.min(fps, 5);              // escenas: mira 5 por segundo y se queda con los cambios
        else step = 1f / new int[]{0, 1, 2, 3, 5, 10, 12, 15}[mode];
        for (float t = startS; t < endS - 1e-3; t += step) l.add((long) (t * 1_000_000L));
        return l;
    }

    void refresh() {
        String fmt = String.format(Locale.ROOT, "%.1f", startS) + " s → " + String.format(Locale.ROOT, "%.1f", endS) + " s";
        if (video != null) {
            info.setText(name + "\n" + vw + " × " + vh + " · " + NeonProgress.dur(durMs / 1000) + " · " + Math.round(fps) + " fps");
            rangeTv.setText(L.t("Trozo") + ": " + fmt);
        }
        modeBtn.setText(L.t("Cuántos") + ": " + L.t(MODES[mode]) + (mode == 8 ? " (" + total + ")" : ""));
        fmtBtn.setText(L.t("Formato") + ": " + (png ? L.t("PNG (sin pérdida, pesa más)") : L.t("JPG (pesa menos)")));
        if (video != null) {
            int n = times().size();
            double perMb = (vw * (double) vh) / 1e6 * (png ? 1.6 : 0.25);
            estTv.setText("≈ " + n + " " + L.t("fotos") + (mode == 9 || skipBlur.isChecked() || skipDup.isChecked() ? " " + L.t("como mucho") : "")
                    + " · ~" + Math.max(1, Math.round(n * perMb)) + " MB" + (n > 300 ? "\n⚠ " + L.t("Son muchas: quizá te vale con menos por segundo.") : ""));
        } else estTv.setText("");
        gifInfo.setText(!photos.isEmpty() ? photos.size() + " " + L.t("fotos elegidas") : video != null ? L.t("Del vídeo") + ": " + fmt : L.t("Elige un vídeo o varias fotos."));
        gifFpsBtn.setText(L.t("Fotogramas por segundo") + ": " + gifFps);
        gifSizeBtn.setText(L.t("Ancho") + ": " + gifWidth + " px");
        gifSpeedBtn.setText(L.t("Velocidad") + ": " + (gifSpeed == (int) gifSpeed ? String.valueOf((int) gifSpeed) : String.valueOf(gifSpeed).replace('.', ',')) + "×");
        gifLoopBtn.setText(L.t("Bucle") + ": " + L.t(new String[]{"Normal", "Al revés", "Ida y vuelta (boomerang)"}[gifLoop]));
    }

    // ------------------------------------------------------------------ fotogramas
    void extract() {
        if (video == null) { toast(L.t("Primero elige un vídeo.")); return; }
        if (busy) return;
        busy = true; cancel = false;
        final List<Long> ts = times();
        final boolean blur = skipBlur.isChecked(), dup = skipDup.isChecked() || mode == 9, scene = mode == 9, asPng = png;
        prog.begin();
        prog.set(L.t("Fotograma"), 0, ts.size());
        new Thread(() -> {
            MediaMetadataRetriever mr = new MediaMetadataRetriever();
            int saved = 0, skipped = 0;
            String err = null;
            try {
                mr.setDataSource(this, video);
                float[] prevSig = null;
                for (int i = 0; i < ts.size() && !cancel; i++) {
                    Bitmap f = mr.getFrameAtTime(ts.get(i), MediaMetadataRetriever.OPTION_CLOSEST);
                    final int k = i + 1;
                    h.post(() -> prog.set(L.t("Fotograma"), k, ts.size()));
                    if (f == null) continue;
                    float[] sig = signature(f);
                    if (dup && prevSig != null && diff(sig, prevSig) < (scene ? 0.25f : 0.04f)) { skipped++; continue; }
                    if (blur && sharpness(f) < 18) { skipped++; continue; }
                    prevSig = sig;
                    String fn = String.format(Locale.ROOT, "%s_%04d_%06.2fs.%s", safe(name), saved + 1, ts.get(i) / 1e6, asPng ? "png" : "jpg");
                    if (save(f, fn, "Pictures/SSS+/" + L.t("Fotogramas") + "/" + safe(name), asPng)) saved++;
                    f.recycle();
                }
            } catch (Exception e) { err = e.getMessage(); }
            finally { try { mr.release(); } catch (Exception ignored) {} }
            int s = saved, sk = skipped;
            String er = err;
            h.post(() -> {
                busy = false;
                prog.hide();
                String msg = er != null ? L.t("No se pudo: ") + er : (cancel ? L.t("Cancelado.") + " " : "") + "✔ " + s + " " + L.t("fotos guardadas en Imágenes → SSS+ → Fotogramas")
                        + (sk > 0 ? " · " + sk + " " + L.t("descartadas") : "");
                estTv.setText(msg);
                toast(msg);
            });
        }, "fotogramas").start();
    }

    static String safe(String s) { return s.replaceAll("[\\\\/:*?\"<>|]", "_"); }

    /** Huella pequeña (16×9 en gris) para comparar fotogramas. */
    static float[] signature(Bitmap b) {
        Bitmap s = Bitmap.createScaledBitmap(b, 16, 9, true);
        float[] o = new float[16 * 9];
        for (int y = 0; y < 9; y++) for (int x = 0; x < 16; x++) {
            int p = s.getPixel(x, y);
            o[y * 16 + x] = (((p >> 16) & 255) * 0.3f + ((p >> 8) & 255) * 0.59f + (p & 255) * 0.11f) / 255f;
        }
        return o;
    }

    static float diff(float[] a, float[] b) { float d = 0; for (int i = 0; i < a.length; i++) d += Math.abs(a[i] - b[i]); return d / a.length; }

    /** Nitidez: varianza del laplaciano sobre una versión de 256 px. */
    static double sharpness(Bitmap b) {
        int w = 256, hh = Math.max(16, b.getHeight() * 256 / Math.max(1, b.getWidth()));
        Bitmap s = Bitmap.createScaledBitmap(b, w, hh, true);
        int[] px = new int[w * hh];
        s.getPixels(px, 0, w, 0, 0, w, hh);
        float[] g = new float[px.length];
        for (int i = 0; i < px.length; i++) g[i] = ((px[i] >> 16) & 255) * 0.3f + ((px[i] >> 8) & 255) * 0.59f + (px[i] & 255) * 0.11f;
        double sum = 0, sq = 0; int n = 0;
        for (int y = 1; y < hh - 1; y++) for (int x = 1; x < w - 1; x++) {
            int i = y * w + x;
            double l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w];
            sum += l; sq += l * l; n++;
        }
        double m = sum / n;
        return sq / n - m * m;
    }

    boolean save(Bitmap b, String fileName, String relPath, boolean png) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            v.put(MediaStore.Images.Media.MIME_TYPE, png ? "image/png" : "image/jpeg");
            if (android.os.Build.VERSION.SDK_INT >= 29) v.put(MediaStore.Images.Media.RELATIVE_PATH, relPath);
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            try (OutputStream os = getContentResolver().openOutputStream(u)) { b.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, png ? 100 : 92, os); }
            return true;
        } catch (Exception e) { return false; }
    }

    // ------------------------------------------------------------------ GIF
    void makeGif() {
        if (video == null && photos.isEmpty()) { toast(L.t("Elige un vídeo o varias fotos.")); return; }
        if (busy) return;
        busy = true; cancel = false;
        final String top = topText.getText().toString().trim(), bottom = bottomText.getText().toString().trim();
        final List<Uri> imgs = new ArrayList<>(photos);
        final int fpsOut = gifFps, width = gifWidth, loop = gifLoop;
        final float speed = gifSpeed;
        prog.begin();
        prog.phase(L.t("Preparando…"));
        new Thread(() -> {
            String err = null;
            Uri out = null;
            List<byte[]> frames = new ArrayList<>();     // guardados comprimidos: 400 fotogramas sin comprimir no caben en memoria
            int[] firstH = {0};
            try {
                if (!imgs.isEmpty()) {
                    for (int i = 0; i < imgs.size() && !cancel; i++) {
                        final int k = i + 1;
                        h.post(() -> prog.set(L.t("Leyendo foto"), k, imgs.size()));
                        try (java.io.InputStream in = getContentResolver().openInputStream(imgs.get(i))) {
                            Bitmap bm = BitmapFactory.decodeStream(in);
                            if (bm != null) { Bitmap ft = fit(bm, width, firstH[0]); if (firstH[0] == 0) firstH[0] = ft.getHeight(); frames.add(pack(ft)); bm.recycle(); }
                        }
                    }
                } else {
                    MediaMetadataRetriever mr = new MediaMetadataRetriever();
                    mr.setDataSource(this, video);
                    float step = speed / fpsOut;                  // segundos de vídeo entre fotogramas del GIF
                    List<Long> ts = new ArrayList<>();
                    for (float t = startS; t < endS - 1e-3; t += step) ts.add((long) (t * 1_000_000L));
                    if (ts.size() > 400) ts = ts.subList(0, 400);
                    for (int i = 0; i < ts.size() && !cancel; i++) {
                        final int k = i + 1, n = ts.size();
                        h.post(() -> prog.set(L.t("Sacando fotograma"), k, n));
                        Bitmap f = mr.getFrameAtTime(ts.get(i), MediaMetadataRetriever.OPTION_CLOSEST);
                        if (f != null) { frames.add(pack(fit(f, width, 0))); f.recycle(); }
                    }
                    mr.release();
                }
                if (frames.isEmpty() || cancel) throw new Exception(cancel ? L.t("Cancelado.") : L.t("No hay fotogramas."));
                List<byte[]> seq = new ArrayList<>(frames);
                if (loop == 1) java.util.Collections.reverse(seq);
                else if (loop == 2) for (int i = frames.size() - 2; i > 0; i--) seq.add(frames.get(i));
                Bitmap first = unpack(seq.get(0));
                int w = first.getWidth(), hh = first.getHeight();
                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME, "SSS_gif_" + System.currentTimeMillis() + ".gif");
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/gif");
                if (android.os.Build.VERSION.SDK_INT >= 29) v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SSS+/GIF");
                out = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                int delay = imgs.isEmpty() ? Math.round(1000f / fpsOut) : Math.round(1000f / fpsOut / speed);
                try (OutputStream os = new java.io.BufferedOutputStream(getContentResolver().openOutputStream(out))) {
                    GifEncoder ge = new GifEncoder(os, w, hh);
                    for (int i = 0; i < seq.size() && !cancel; i++) {
                        final int k = i + 1, n = seq.size();
                        h.post(() -> prog.set(L.t("Creando GIF"), k, n));
                        Bitmap fr = unpack(seq.get(i));
                        if (!top.isEmpty() || !bottom.isEmpty()) fr = caption(fr, top, bottom);
                        ge.addFrame(fr, delay);
                    }
                    ge.finish();
                }
                if (cancel) { getContentResolver().delete(out, null, null); out = null; throw new Exception(L.t("Cancelado.")); }
            } catch (Exception e) { err = e.getMessage(); }
            Uri o = out;
            String er = err;
            long size = 0;
            if (o != null) try (android.content.res.AssetFileDescriptor fd = getContentResolver().openAssetFileDescriptor(o, "r")) { size = fd.getLength(); } catch (Exception ignored) {}
            long sz = size;
            h.post(() -> {
                busy = false;
                prog.hide();
                if (er != null) { gifInfo.setText(er); return; }
                lastGif = o;
                String mb = String.format(Locale.ROOT, "%.1f MB", sz / 1048576f);
                gifInfo.setText("✔ " + L.t("GIF guardado en Imágenes → SSS+ → GIF") + " · " + mb
                        + (sz > 8 * 1048576 ? "\n⚠ " + L.t("Pesa mucho para Discord o WhatsApp: baja el ancho, los fotogramas por segundo o el trozo.") : ""));
            });
        }, "gif").start();
    }

    static byte[] pack(Bitmap b) {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.JPEG, 95, bo);
        return bo.toByteArray();
    }

    static Bitmap unpack(byte[] d) { return BitmapFactory.decodeByteArray(d, 0, d.length); }

    /** Escala al ancho pedido (y al mismo alto que el primero, para fotos de distinto tamaño). */
    static Bitmap fit(Bitmap b, int width, int forceH) {
        int w = Math.min(width, b.getWidth());
        int hh = forceH > 0 ? forceH : Math.max(2, Math.round(b.getHeight() * (w / (float) b.getWidth())));
        if (forceH > 0) {                                   // encajar sin deformar, con bandas negras
            Bitmap out = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(out);
            c.drawColor(Color.BLACK);
            float s = Math.min(w / (float) b.getWidth(), hh / (float) b.getHeight());
            int dw = Math.round(b.getWidth() * s), dh = Math.round(b.getHeight() * s);
            c.drawBitmap(Bitmap.createScaledBitmap(b, Math.max(1, dw), Math.max(1, dh), true), (w - dw) / 2f, (hh - dh) / 2f, null);
            return out;
        }
        return Bitmap.createScaledBitmap(b, w, hh, true);
    }

    /** Texto tipo meme (blanco con borde negro), arriba y abajo. */
    static Bitmap caption(Bitmap b, String top, String bottom) {
        Bitmap o = b.copy(Bitmap.Config.ARGB_8888, true);
        Canvas c = new Canvas(o);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextAlign(Paint.Align.CENTER);
        float size = o.getWidth() / 11f;
        for (int pass = 0; pass < 2; pass++) {
            String t = pass == 0 ? top : bottom;
            if (t.isEmpty()) continue;
            t = t.toUpperCase(Locale.ROOT);
            p.setTextSize(size);
            while (p.measureText(t) > o.getWidth() * 0.94f && p.getTextSize() > 8) p.setTextSize(p.getTextSize() - 1);
            float y = pass == 0 ? p.getTextSize() * 1.1f : o.getHeight() - p.getTextSize() * 0.35f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(p.getTextSize() / 7);
            p.setColor(Color.BLACK);
            c.drawText(t, o.getWidth() / 2f, y, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);
            c.drawText(t, o.getWidth() / 2f, y, p);
        }
        return o;
    }
}
