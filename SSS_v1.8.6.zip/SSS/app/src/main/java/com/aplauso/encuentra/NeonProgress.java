package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * v1.8 · Barra de carga de verdad para todo lo que tarda: porcentaje, paso actual,
 * tiempo transcurrido y tiempo restante. Si no se sabe el total, una franja que se mueve.
 */
public class NeonProgress extends LinearLayout {
    final TextView label;
    final Bar bar;
    long startMs;

    public NeonProgress(Context c) {
        super(c);
        setOrientation(VERTICAL);
        label = new TextView(c);
        label.setTextColor(Color.rgb(220, 230, 240));
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        addView(label);
        bar = new Bar(c);
        LayoutParams lp = new LayoutParams(-1, (int) (12 * getResources().getDisplayMetrics().density));
        lp.topMargin = (int) (5 * getResources().getDisplayMetrics().density);
        addView(bar, lp);
        setVisibility(GONE);
    }

    /** Empieza a contar el tiempo desde ahora. */
    public void begin() { startMs = SystemClock.elapsedRealtime(); setVisibility(VISIBLE); }

    /** Empieza a contar desde un momento conocido (p. ej. cuando arrancó el servicio). */
    public void begin(long elapsedStart) { startMs = elapsedStart; setVisibility(VISIBLE); }

    public void hide() { setVisibility(GONE); bar.frac = -1; }

    /**
     * @param what  qué se está haciendo («Fotograma», «Paso»…)
     * @param done  hechos
     * @param total total (0 = no se sabe)
     */
    public void set(String what, long done, long total) {
        if (getVisibility() != VISIBLE) begin();
        float f = total > 0 ? Math.min(1f, done / (float) total) : -1f;
        bar.frac = f;
        bar.invalidate();
        long el = (SystemClock.elapsedRealtime() - startMs) / 1000;
        StringBuilder sb = new StringBuilder();
        if (what != null && !what.isEmpty()) sb.append(what).append(' ');
        if (total > 0) sb.append(done).append(" / ").append(total).append(" · ").append(Math.round(f * 100)).append(" %");
        sb.append("\n⏱ ").append(dur(el));
        if (total > 0 && done > 0 && done < total) {
            long left = el * (total - done) / done;
            sb.append(" · ").append(L.t("faltan")).append(' ').append(dur(left));
        }
        label.setText(sb.toString());
    }

    /** Solo texto (fases sin número: «Preparando…», «Copiando el sonido…»). */
    public void phase(String text) {
        if (getVisibility() != VISIBLE) begin();
        bar.frac = -1;
        bar.invalidate();
        long el = (SystemClock.elapsedRealtime() - startMs) / 1000;
        label.setText(text + "\n⏱ " + dur(el));
    }

    public static String dur(long s) {
        if (s < 0) s = 0;
        if (s >= 3600) return s / 3600 + " h " + (s % 3600) / 60 + " min";
        if (s >= 60) return s / 60 + " min " + (s % 60) + " s";
        return s + " s";
    }

    static class Bar extends View {
        float frac = -1;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final int neon;

        Bar(Context c) { super(c); neon = Neon.color(c); }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), r = h / 2;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(50, Color.red(neon), Color.green(neon), Color.blue(neon)));
            cv.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
            p.setColor(neon);
            if (frac >= 0) {
                if (frac > 0) cv.drawRoundRect(new RectF(0, 0, Math.max(h, w * frac), h), r, r, p);
            } else {                                     // sin total: una franja que va y viene
                float t = (SystemClock.uptimeMillis() % 1600) / 1600f;
                float x = (t < 0.5f ? t * 2 : 2 - t * 2) * (w * 0.7f);
                cv.drawRoundRect(new RectF(x, 0, x + w * 0.3f, h), r, r, p);
                postInvalidateOnAnimation();
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.2f * getResources().getDisplayMetrics().density);
            cv.drawRoundRect(new RectF(1, 1, w - 1, h - 1), r, r, p);
        }
    }
}
