package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * v1.8.2 · 📡 MANDO UNIVERSAL: por infrarrojos (el emisor IR del móvil: Samsung, LG, Sony) y por Wi-Fi (Roku y
 * teles Samsung Tizen). Teclas grandes, números, macros (varias teclas seguidas, p. ej. «Noche») y control por voz:
 * «apaga la tele», «sube el volumen de la tele», «pon el canal 5 en la tele».
 */
public class RemoteActivity extends NeonActivity {
    static final String[] KEYS = {"POWER", "VOL_UP", "VOL_DOWN", "MUTE", "CH_UP", "CH_DOWN", "INPUT", "MENU", "HOME", "BACK", "UP", "DOWN", "LEFT", "RIGHT", "OK",
            "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "PLAY", "PAUSE"};

    // ---- infrarrojos: códigos (hex de LIRC, se envían del bit alto al bajo)
    static final Map<String, String> SAMSUNG = new LinkedHashMap<>(), LG = new LinkedHashMap<>();
    static final Map<String, Integer> SONY = new LinkedHashMap<>();
    static {
        String[][] s = {{"POWER", "E0E040BF"}, {"VOL_UP", "E0E0E01F"}, {"VOL_DOWN", "E0E0D02F"}, {"MUTE", "E0E0F00F"}, {"CH_UP", "E0E048B7"}, {"CH_DOWN", "E0E008F7"},
                {"INPUT", "E0E0807F"}, {"MENU", "E0E058A7"}, {"HOME", "E0E09E61"}, {"BACK", "E0E01AE5"}, {"UP", "E0E006F9"}, {"DOWN", "E0E08679"}, {"LEFT", "E0E0A659"},
                {"RIGHT", "E0E046B9"}, {"OK", "E0E016E9"}, {"1", "E0E020DF"}, {"2", "E0E0A05F"}, {"3", "E0E0609F"}, {"4", "E0E010EF"}, {"5", "E0E0906F"}, {"6", "E0E050AF"},
                {"7", "E0E030CF"}, {"8", "E0E0B04F"}, {"9", "E0E0708F"}, {"0", "E0E08877"}, {"PLAY", "E0E0E21D"}, {"PAUSE", "E0E052AD"}};
        for (String[] x : s) SAMSUNG.put(x[0], x[1]);
        String[][] l = {{"POWER", "20DF10EF"}, {"VOL_UP", "20DF40BF"}, {"VOL_DOWN", "20DFC03F"}, {"MUTE", "20DF906F"}, {"CH_UP", "20DF00FF"}, {"CH_DOWN", "20DF807F"},
                {"INPUT", "20DFD02F"}, {"MENU", "20DFC23D"}, {"HOME", "20DF3EC1"}, {"BACK", "20DF14EB"}, {"UP", "20DF02FD"}, {"DOWN", "20DF827D"}, {"LEFT", "20DFE01F"},
                {"RIGHT", "20DF609F"}, {"OK", "20DF22DD"}, {"1", "20DF8877"}, {"2", "20DF48B7"}, {"3", "20DFC837"}, {"4", "20DF28D7"}, {"5", "20DFA857"}, {"6", "20DF6897"},
                {"7", "20DFE817"}, {"8", "20DF18E7"}, {"9", "20DF9867"}, {"0", "20DF08F7"}, {"PLAY", "20DF0DF2"}, {"PAUSE", "20DF5DA2"}};
        for (String[] x : l) LG.put(x[0], x[1]);
        Object[][] so = {{"POWER", 21}, {"VOL_UP", 18}, {"VOL_DOWN", 19}, {"MUTE", 20}, {"CH_UP", 16}, {"CH_DOWN", 17}, {"INPUT", 37}, {"MENU", 96}, {"HOME", 96},
                {"BACK", 99}, {"UP", 116}, {"DOWN", 117}, {"LEFT", 52}, {"RIGHT", 51}, {"OK", 101}, {"1", 0}, {"2", 1}, {"3", 2}, {"4", 3}, {"5", 4}, {"6", 5}, {"7", 6},
                {"8", 7}, {"9", 8}, {"0", 9}};
        for (Object[] x : so) SONY.put((String) x[0], (Integer) x[1]);
    }

    static int[] necLike(String hex, int hdrOn, int hdrOff) {
        long v = Long.parseLong(hex, 16);
        int[] p = new int[2 + 64 + 2];
        int k = 0;
        p[k++] = hdrOn; p[k++] = hdrOff;
        for (int i = 31; i >= 0; i--) { p[k++] = 560; p[k++] = ((v >> i) & 1) == 1 ? 1690 : 560; }
        p[k++] = 560; p[k++] = 40000;
        return p;
    }

    static int[] sony(int cmd, int addr) {
        int[] frame = new int[2 + 24];
        int k = 0;
        frame[k++] = 2400; frame[k++] = 600;
        int bits = cmd | (addr << 7);
        for (int i = 0; i < 12; i++) { frame[k++] = ((bits >> i) & 1) == 1 ? 1200 : 600; frame[k++] = 600; }
        int len = 0; for (int x : frame) len += x;
        frame[k - 1] += Math.max(0, 45000 - len);
        int[] p = new int[frame.length * 3];                     // Sony repite 3 veces
        for (int r = 0; r < 3; r++) System.arraycopy(frame, 0, p, r * frame.length, frame.length);
        return p;
    }

    // ---- dispositivos guardados: {nombre: "ir:samsung" | "ir:lg" | "ir:sony" | "roku:IP" | "tizen:IP"}
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static JSONObject devices(Context c) { try { return new JSONObject(prefs(c).getString("rm_devices", "{}")); } catch (Exception e) { return new JSONObject(); } }
    static String current(Context c) { return prefs(c).getString("rm_current", ""); }

    /** Envía una tecla al aparato elegido. Devuelve un error legible o null. Bloquea en Wi-Fi: llamar fuera del hilo principal. */
    static String send(Context c, String key) {
        String dev = devices(c).optString(current(c), "");
        if (dev.isEmpty()) return L.t("Primero elige o añade un aparato en 📡 Mando universal.");
        try {
            if (dev.startsWith("ir:")) {
                ConsumerIrManager ir = (ConsumerIrManager) c.getSystemService(Context.CONSUMER_IR_SERVICE);
                if (ir == null || !ir.hasIrEmitter()) return L.t("Este teléfono no tiene emisor de infrarrojos.");
                String brand = dev.substring(3);
                if (brand.equals("sony")) { Integer cmd = SONY.get(key); if (cmd == null) return L.t("Esa tecla no está en este mando."); ir.transmit(40000, sony(cmd, 1)); }
                else {
                    String hex = (brand.equals("lg") ? LG : SAMSUNG).get(key);
                    if (hex == null) return L.t("Esa tecla no está en este mando.");
                    ir.transmit(38000, brand.equals("lg") ? necLike(hex, 9000, 4500) : necLike(hex, 4500, 4500));
                }
                return null;
            }
            if (dev.startsWith("roku:")) { roku(dev.substring(5), key); return null; }
            if (dev.startsWith("tizen:")) { tizen(c, dev.substring(6), key); return null; }
        } catch (Exception e) { return L.t("No responde") + ": " + e.getMessage(); }
        return L.t("Aparato desconocido.");
    }

    static final Map<String, String> ROKU = new LinkedHashMap<>(), TIZEN = new LinkedHashMap<>();
    static {
        String[][] r = {{"POWER", "Power"}, {"VOL_UP", "VolumeUp"}, {"VOL_DOWN", "VolumeDown"}, {"MUTE", "VolumeMute"}, {"CH_UP", "ChannelUp"}, {"CH_DOWN", "ChannelDown"},
                {"INPUT", "InputHDMI1"}, {"MENU", "Info"}, {"HOME", "Home"}, {"BACK", "Back"}, {"UP", "Up"}, {"DOWN", "Down"}, {"LEFT", "Left"}, {"RIGHT", "Right"},
                {"OK", "Select"}, {"PLAY", "Play"}, {"PAUSE", "Play"}};
        for (String[] x : r) ROKU.put(x[0], x[1]);
        for (String k : KEYS) TIZEN.put(k, "KEY_" + (k.equals("VOL_UP") ? "VOLUP" : k.equals("VOL_DOWN") ? "VOLDOWN" : k.equals("CH_UP") ? "CHUP" : k.equals("CH_DOWN") ? "CHDOWN"
                : k.equals("INPUT") ? "SOURCE" : k.equals("BACK") ? "RETURN" : k.equals("OK") ? "ENTER" : k));
    }

    static void roku(String ip, String key) throws Exception {
        String k = ROKU.get(key);
        if (k == null && key.matches("\\d")) k = "Lit_" + key;
        if (k == null) throw new Exception(L.t("Esa tecla no está en este mando."));
        java.net.HttpURLConnection con = (java.net.HttpURLConnection) new java.net.URL("http://" + ip + ":8060/keypress/" + k).openConnection();
        con.setRequestMethod("POST"); con.setConnectTimeout(2500); con.setReadTimeout(2500); con.setDoOutput(true);
        con.getOutputStream().close();
        con.getResponseCode(); con.disconnect();
    }

    /** Teles Samsung (2016 en adelante): WebSocket local. La primera vez la tele pregunta si permites el mando: acepta. */
    static void tizen(Context c, String ip, String key) throws Exception {
        String k = TIZEN.get(key);
        if (k == null) throw new Exception(L.t("Esa tecla no está en este mando."));
        String name = android.util.Base64.encodeToString("Chloe Nova".getBytes(), android.util.Base64.NO_WRAP);
        String token = prefs(c).getString("rm_tok_" + ip, "");
        Exception last = null;
        for (int port : new int[]{8002, 8001}) {
            try (Socket so = open(ip, port)) {
                String path = "/api/v2/channels/samsung.remote.control?name=" + name + (port == 8002 && !token.isEmpty() ? "&token=" + token : "");
                OutputStream o = so.getOutputStream(); InputStream in = so.getInputStream();
                String wsKey = android.util.Base64.encodeToString(java.util.UUID.randomUUID().toString().substring(0, 16).getBytes(), android.util.Base64.NO_WRAP);
                o.write(("GET " + path + " HTTP/1.1\r\nHost: " + ip + ":" + port + "\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: " + wsKey
                        + "\r\nSec-WebSocket-Version: 13\r\n\r\n").getBytes());
                String hdr = readHeaders(in);
                if (!hdr.contains(" 101")) throw new Exception("HTTP " + hdr.split("\r\n")[0]);
                String first = readFrame(in);                       // ms.channel.connect (con el token la primera vez)
                if (first != null && first.contains("\"token\"")) {
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"token\"\\s*:\\s*\"?(\\w+)").matcher(first);
                    if (m.find()) prefs(c).edit().putString("rm_tok_" + ip, m.group(1)).apply();
                }
                if (first != null && first.contains("unauthorized")) throw new Exception(L.t("la tele no lo ha permitido"));
                writeText(o, "{\"method\":\"ms.remote.control\",\"params\":{\"Cmd\":\"Click\",\"DataOfCmd\":\"" + k + "\",\"Option\":\"false\",\"TypeOfRemote\":\"SendRemoteKey\"}}");
                Thread.sleep(150);
                return;
            } catch (Exception e) { last = e; }
        }
        throw last;
    }

    static Socket open(String ip, int port) throws Exception {
        if (port == 8002) {                                         // la tele usa un certificado propio: solo en tu red local
            if (!InetAddress.getByName(ip).isSiteLocalAddress()) throw new Exception(L.t("solo teles de tu red de casa"));
            javax.net.ssl.SSLContext ctx = javax.net.ssl.SSLContext.getInstance("TLS");
            ctx.init(null, new javax.net.ssl.TrustManager[]{new javax.net.ssl.X509TrustManager() {
                public void checkClientTrusted(java.security.cert.X509Certificate[] x, String a) {}
                public void checkServerTrusted(java.security.cert.X509Certificate[] x, String a) {}
                public java.security.cert.X509Certificate[] getAcceptedIssuers() { return new java.security.cert.X509Certificate[0]; }
            }}, null);
            Socket s = ctx.getSocketFactory().createSocket();
            s.connect(new java.net.InetSocketAddress(ip, port), 2500);
            s.setSoTimeout(30000);                                  // la primera vez espera a que aceptes en la tele
            return s;
        }
        Socket s = new Socket();
        s.connect(new java.net.InetSocketAddress(ip, port), 2500);
        s.setSoTimeout(30000);
        return s;
    }

    static String readHeaders(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) { sb.append((char) c); if (sb.length() > 4 && sb.substring(sb.length() - 4).equals("\r\n\r\n")) break; if (sb.length() > 8000) break; }
        return sb.toString();
    }

    static String readFrame(InputStream in) throws Exception {
        int b0 = in.read(), b1 = in.read();
        if (b0 < 0 || b1 < 0) return null;
        long len = b1 & 127;
        if (len == 126) len = (in.read() << 8) | in.read();
        else if (len == 127) { len = 0; for (int i = 0; i < 8; i++) len = (len << 8) | in.read(); }
        if (len > 1 << 20) return null;
        byte[] d = new byte[(int) len];
        int got = 0; while (got < len) { int k = in.read(d, got, (int) len - got); if (k < 0) break; got += k; }
        return new String(d, 0, got, java.nio.charset.StandardCharsets.UTF_8);
    }

    static void writeText(OutputStream o, String s) throws Exception {
        byte[] d = s.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        java.io.ByteArrayOutputStream f = new java.io.ByteArrayOutputStream();
        f.write(0x81);
        if (d.length < 126) f.write(0x80 | d.length); else { f.write(0x80 | 126); f.write(d.length >> 8); f.write(d.length & 255); }
        byte[] mask = new byte[4]; new java.util.Random().nextBytes(mask);
        f.write(mask);
        for (int i = 0; i < d.length; i++) f.write(d[i] ^ mask[i & 3]);
        o.write(f.toByteArray()); o.flush();
    }

    /** Busca Roku y teles Samsung en tu Wi-Fi (SSDP, 3 segundos). {nombre, "roku:IP" / "tizen:IP"} */
    static List<String[]> discover() {
        List<String[]> out = new ArrayList<>();
        java.util.Set<String> seen = new java.util.HashSet<>();
        try (DatagramSocket ds = new DatagramSocket()) {
            ds.setSoTimeout(700);
            String msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n";
            byte[] b = msg.getBytes();
            InetAddress grp = InetAddress.getByName("239.255.255.250");
            for (int i = 0; i < 2; i++) ds.send(new DatagramPacket(b, b.length, grp, 1900));
            long end = System.currentTimeMillis() + 3000;
            byte[] buf = new byte[2048];
            while (System.currentTimeMillis() < end) {
                try {
                    DatagramPacket pk = new DatagramPacket(buf, buf.length);
                    ds.receive(pk);
                    String r = new String(pk.getData(), 0, pk.getLength()).toLowerCase();
                    String ip = pk.getAddress().getHostAddress();
                    if (r.contains("roku") && seen.add("roku" + ip)) out.add(new String[]{"Roku (" + ip + ")", "roku:" + ip});
                    else if (r.contains("samsung") && (r.contains("tizen") || r.contains("tv") || r.contains("dial")) && seen.add("sam" + ip)) out.add(new String[]{"Samsung TV (" + ip + ")", "tizen:" + ip});
                } catch (java.net.SocketTimeoutException ignored) {}
            }
        } catch (Exception ignored) {}
        return out;
    }

    // ================================================================== pantalla
    final Handler h = new Handler(Looper.getMainLooper());
    final List<TextView> keyViews = new ArrayList<>();
    android.widget.ScrollView scroll;
    static final int REQ_BG = 93;
    TextView devBtn, recBtn;
    LinearLayout macroBox;
    List<String> recording;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("📡 MANDO UNIVERSAL");
        LinearLayout d = panel(null);
        devBtn = button("", v -> pickDevice());
        d.addView(devBtn, gapBelow(4));
        ConsumerIrManager ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        TextView irInfo = text(ir != null && ir.hasIrEmitter() ? "✅ Tu móvil tiene infrarrojos: apunta a la tele." : "ℹ Tu móvil no tiene infrarrojos: usa la tele por Wi-Fi (Roku o Samsung).", 11);
        irInfo.setTextColor(Color.rgb(160, 170, 190));
        d.addView(irInfo);
        col.addView(d, gapBelow(10));

        LinearLayout k = panel(null);
        row(k, new String[]{"⏻", "POWER"}, new String[]{"🔇", "MUTE"}, new String[]{"⇄", "INPUT"});
        row(k, new String[]{"🔊 +", "VOL_UP"}, new String[]{"▲", "UP"}, new String[]{"CH +", "CH_UP"});
        row(k, new String[]{"◀", "LEFT"}, new String[]{"OK", "OK"}, new String[]{"▶", "RIGHT"});
        row(k, new String[]{"🔉 −", "VOL_DOWN"}, new String[]{"▼", "DOWN"}, new String[]{"CH −", "CH_DOWN"});
        row(k, new String[]{"↩", "BACK"}, new String[]{"⌂", "HOME"}, new String[]{"☰", "MENU"});
        row(k, new String[]{"1", "1"}, new String[]{"2", "2"}, new String[]{"3", "3"});
        row(k, new String[]{"4", "4"}, new String[]{"5", "5"}, new String[]{"6", "6"});
        row(k, new String[]{"7", "7"}, new String[]{"8", "8"}, new String[]{"9", "9"});
        row(k, new String[]{"⏯", "PLAY"}, new String[]{"0", "0"}, new String[]{"⏸", "PAUSE"});
        col.addView(k, gapBelow(10));

        LinearLayout m = panel("◢ MACROS");
        m.addView(text("Graba varias teclas seguidas (con sus pausas) y repítelas con un toque o diciéndole a Chloe «macro Noche».", 11));
        recBtn = button("", v -> toggleRec());
        m.addView(recBtn, gapBelow(6));
        macroBox = new LinearLayout(this);
        macroBox.setOrientation(LinearLayout.VERTICAL);
        m.addView(macroBox);
        col.addView(m, gapBelow(10));
        // v1.8.3 · 🎨 tu mando a tu gusto: color de las teclas, modo RGB que va cambiando y fondo de pantalla
        LinearLayout st = panel("◢ 🎨 ESTILO DEL MANDO");
        // como en Ajustes → apariencia: tu color en RGB, opacidad, arcoíris con velocidad y fondo
        int cur = keyColor();
        p.edit().putInt("rm_r", Color.red(cur)).putInt("rm_g", Color.green(cur)).putInt("rm_b", Color.blue(cur)).apply();
        LinearLayout rgbRow = new LinearLayout(this);
        rgbRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout rgbCol = new LinearLayout(this);
        rgbCol.setOrientation(LinearLayout.VERTICAL);
        slider(rgbCol, "R", "rm_r", Color.red(cur), 0, 255, "", v -> rgbChanged());
        slider(rgbCol, "G", "rm_g", Color.green(cur), 0, 255, "", v -> rgbChanged());
        slider(rgbCol, "B", "rm_b", Color.blue(cur), 0, 255, "", v -> rgbChanged());
        rgbRow.addView(rgbCol, new LinearLayout.LayoutParams(0, -2, 1));
        swatch = new View(this);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(dpi(56), dpi(56)); sl.leftMargin = dpi(12);
        rgbRow.addView(swatch, sl);
        st.addView(rgbRow);
        LinearLayout pre = new LinearLayout(this);
        for (int pc : new int[]{Color.rgb(255, 40, 120), Color.rgb(160, 80, 255), Color.rgb(0, 200, 255), Color.rgb(0, 255, 140), Color.rgb(255, 210, 0), Color.rgb(255, 110, 30), Color.WHITE}) {
            View sw = new View(this);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL); g.setColor(pc); g.setStroke(dpi(2), Color.WHITE);
            sw.setBackground(g);
            sw.setOnClickListener(v -> { p.edit().putInt("rm_color", pc).putBoolean("rm_rgb", false).apply(); recreate(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dpi(30), 1); lp.leftMargin = lp.rightMargin = dpi(4); lp.topMargin = dpi(6);
            pre.addView(sw, lp);
        }
        st.addView(pre, gapBelow(4));
        slider(st, "Opacidad de las teclas", "rm_opacity", 28, 0, 100, " %", v -> restyle());
        android.widget.Switch rgb = neonSwitch("🌈 Color cambiante (arcoíris RGB)");
        rgb.setChecked(p.getBoolean("rm_rgb", false));
        rgb.setOnCheckedChangeListener((x, on) -> { p.edit().putBoolean("rm_rgb", on).apply(); restyle(); });
        st.addView(rgb);
        android.widget.Switch wave = neonSwitch("〰 En ola (cada tecla un color)");
        wave.setChecked(p.getBoolean("rm_wave", true));
        wave.setOnCheckedChangeListener((x, on) -> p.edit().putBoolean("rm_wave", on).apply());
        st.addView(wave);
        slider(st, "Velocidad del cambio", "rm_speed", 4, 1, 10, "", null);
        TextView bl = text("Fondo de pantalla del mando", 14);
        bl.setPadding(0, dpi(10), 0, 0);
        st.addView(bl);
        LinearLayout bgRow = new LinearLayout(this);
        bgRow.addView(button("🖼 ELEGIR", v -> PickActivity.start(this, new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).setType("image/*")
                .addCategory(android.content.Intent.CATEGORY_OPENABLE), REQ_BG, "remote_bg")), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams ql = new LinearLayout.LayoutParams(0, -2, 1); ql.leftMargin = dpi(6);
        bgRow.addView(button("✕ QUITAR", v -> { new java.io.File(getFilesDir(), "remote_bg.jpg").delete(); applyBg(); }), ql);
        st.addView(bgRow);
        slider(st, "Oscurecer el fondo", "rm_bg_dim", 45, 0, 90, " %", v -> applyBg());
        col.addView(st, gapBelow(10));
        TextView vh = text("🗣 Con Chloe: «apaga la tele», «sube el volumen de la tele», «canal 5 en la tele», «silencia la tele», «macro Noche».", 11);
        vh.setTextColor(Color.rgb(160, 170, 190));
        col.addView(vh);
        refresh();
        if (col.getParent() instanceof android.widget.ScrollView) scroll = (android.widget.ScrollView) col.getParent();
        applyBg();
        rgbChanged();
    }

    // ================================================================== estilo
    int keyColor() { return p.getInt("rm_color", Neon.color(this)); }
    View swatch;

    void rgbChanged() {
        int c = Color.rgb(p.getInt("rm_r", 0), p.getInt("rm_g", 0), p.getInt("rm_b", 0));
        p.edit().putInt("rm_color", c).apply();
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setCornerRadius(dp(12)); g.setColor(c); g.setStroke(dpi(2), Color.WHITE);
        if (swatch != null) swatch.setBackground(g);
        restyle();
    }

    /** Teclas con el color elegido (relleno suave, borde y brillo), o en modo RGB con un arcoíris que recorre el mando. */
    void restyle() {
        h.removeCallbacks(rgbTick);
        if (p.getBoolean("rm_rgb", false)) { h.post(rgbTick); return; }
        int c = keyColor();
        for (TextView t : keyViews) paint(t, c);
    }

    void paint(TextView t, int c) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(Color.argb(Math.round(p.getInt("rm_opacity", 28) * 2.55f), Color.red(c), Color.green(c), Color.blue(c)));
        g.setStroke(dpi(2), c);
        t.setBackground(g);
        t.setTextColor(Color.WHITE);
        t.setShadowLayer(dp(8), 0, 0, c);
    }

    final Runnable rgbTick = new Runnable() {
        @Override public void run() {
            long period = 24000L / Math.max(1, p.getInt("rm_speed", 4));           // como el arcoíris de la app
            float base = (System.currentTimeMillis() % period) * 360f / period;
            boolean wave = p.getBoolean("rm_wave", true);
            for (int i = 0; i < keyViews.size(); i++) paint(keyViews.get(i), Color.HSVToColor(new float[]{(base + (wave ? i * 13f : 0)) % 360f, 0.85f, 1f}));
            h.postDelayed(this, 60);
        }
    };

    /** El fondo elegido (recortado para llenar la pantalla) con un velo oscuro para que se lean las teclas. */
    void applyBg() {
        if (scroll == null) return;
        java.io.File f = new java.io.File(getFilesDir(), "remote_bg.jpg");
        if (!f.exists()) { scroll.setBackground(null); return; }
        android.graphics.Bitmap bm = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath());
        if (bm == null) { scroll.setBackground(null); return; }
        android.graphics.drawable.BitmapDrawable bd = new android.graphics.drawable.BitmapDrawable(getResources(), bm) {
            @Override public void draw(android.graphics.Canvas c) {                  // «centerCrop» a mano
                android.graphics.Rect b = getBounds();
                float k = Math.max(b.width() / (float) bm.getWidth(), b.height() / (float) bm.getHeight());
                float w = bm.getWidth() * k, hh = bm.getHeight() * k;
                c.drawBitmap(bm, null, new android.graphics.RectF(b.centerX() - w / 2, b.centerY() - hh / 2, b.centerX() + w / 2, b.centerY() + hh / 2), getPaint());
            }
        };
        int dim = p.getInt("rm_bg_dim", 45);
        android.graphics.drawable.ColorDrawable veil = new android.graphics.drawable.ColorDrawable(Color.argb(Math.round(dim * 2.55f), 0, 0, 0));
        scroll.setBackground(new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{bd, veil}));
    }

    @Override
    protected void onActivityResult(int req, int res, android.content.Intent d) {
        super.onActivityResult(req, res, d);
        if (req != REQ_BG || res != RESULT_OK || d == null || d.getData() == null) return;
        android.graphics.Bitmap b = PhotoTools.load(this, d.getData(), 1600);
        if (b == null) { toast(L.t("No puedo abrir esa foto.")); return; }
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(new java.io.File(getFilesDir(), "remote_bg.jpg"))) { b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, o); } catch (Exception ignored) {}
        applyBg();
    }

    @Override protected void onResume() { super.onResume(); if (!keyViews.isEmpty()) restyle(); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(rgbTick); }

    void row(LinearLayout parent, String[]... keys) {
        LinearLayout r = new LinearLayout(this);
        for (String[] k : keys) {
            TextView t = button(k[0], v -> press(k[1]));
            keyViews.add(t);
            t.setTextSize(18);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dpi(12), 0, dpi(12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.leftMargin = lp.rightMargin = dpi(4);
            r.addView(t, lp);
        }
        parent.addView(r, gapBelow(6));
    }

    long lastPress;

    void press(String key) {
        if (recording != null) { long now = System.currentTimeMillis(); if (!recording.isEmpty()) recording.add("wait:" + Math.min(8000, now - lastPress)); recording.add(key); lastPress = now; }
        try { getWindow().getDecorView().performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP); } catch (Exception ignored) {}
        new Thread(() -> { String e = send(this, key); if (e != null) h.post(() -> toast(e)); }).start();
    }

    void refresh() {
        String cur = current(this);
        devBtn.setText(cur.isEmpty() ? L.t("➕ ELEGIR O AÑADIR TU TELE") : "📺 " + cur + "  ▾");
        recBtn.setText(recording == null ? L.t("⏺ GRABAR MACRO") : L.t("⏹ TERMINAR Y GUARDAR") + " (" + recording.size() + ")");
        macroBox.removeAllViews();
        JSONObject ms = macros(this);
        for (Iterator<String> it = ms.keys(); it.hasNext(); ) {
            String n = it.next();
            TextView t = button("▶ " + n, v -> new Thread(() -> runMacro(this, n)).start());
            t.setOnLongClickListener(v -> { new android.app.AlertDialog.Builder(this).setMessage(L.t("¿Borrar la macro") + " «" + n + "»?").setPositiveButton(L.t("Borrar"), (dd, w) -> {
                JSONObject o = macros(this); o.remove(n); prefs(this).edit().putString("rm_macros", o.toString()).apply(); refresh(); }).setNegativeButton(L.t("Cancelar"), null).show(); return true; });
            macroBox.addView(t, gapBelow(4));
        }
    }

    void toggleRec() {
        if (recording == null) { recording = new ArrayList<>(); toast(L.t("Grabando: pulsa las teclas en orden.")); refresh(); return; }
        List<String> r = recording; recording = null;
        if (r.isEmpty()) { refresh(); return; }
        EditText e = new EditText(this);
        e.setHint(L.t("Nombre (p. ej. Noche)"));
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Guardar macro")).setView(e).setPositiveButton("OK", (d, w) -> {
            String n = e.getText().toString().trim();
            if (n.isEmpty()) return;
            try { JSONObject o = macros(this); o.put(n, String.join(",", r)); prefs(this).edit().putString("rm_macros", o.toString()).apply(); } catch (Exception ignored) {}
            refresh();
        }).setNegativeButton(L.t("Cancelar"), null).show();
        refresh();
    }

    static JSONObject macros(Context c) { try { return new JSONObject(prefs(c).getString("rm_macros", "{}")); } catch (Exception e) { return new JSONObject(); } }

    static String runMacro(Context c, String name) {
        String seq = null;
        JSONObject o = macros(c);
        for (Iterator<String> it = o.keys(); it.hasNext(); ) { String k = it.next(); if (Actions.norm(k).equals(Actions.norm(name))) seq = o.optString(k); }
        if (seq == null) return L.t("No tengo esa macro.");
        for (String s : seq.split(",")) {
            if (s.startsWith("wait:")) { try { Thread.sleep(Math.min(8000, Long.parseLong(s.substring(5)))); } catch (Exception ignored) {} continue; }
            String e = send(c, s);
            if (e != null) return e;
        }
        return null;
    }

    void pickDevice() {
        JSONObject ds = devices(this);
        List<String> names = new ArrayList<>();
        for (Iterator<String> it = ds.keys(); it.hasNext(); ) names.add(it.next());
        List<String> opts = new ArrayList<>(names);
        opts.add(L.t("➕ Tele por infrarrojos…"));
        opts.add(L.t("📶 Buscar en mi Wi-Fi (Roku, Samsung)"));
        opts.add(L.t("⌨ Por Wi-Fi escribiendo su IP…"));
        new android.app.AlertDialog.Builder(this).setItems(opts.toArray(new String[0]), (d, w) -> {
            if (w < names.size()) { prefs(this).edit().putString("rm_current", names.get(w)).apply(); refresh(); return; }
            int k = w - names.size();
            if (k == 0) {
                String[] br = {"Samsung", "LG", "Sony"};
                new android.app.AlertDialog.Builder(this).setItems(br, (d2, w2) -> addDevice(br[w2] + " (IR)", "ir:" + br[w2].toLowerCase())).show();
            } else if (k == 1) {
                toast(L.t("Buscando…"));
                new Thread(() -> {
                    List<String[]> f = discover();
                    h.post(() -> {
                        if (f.isEmpty()) { toast(L.t("No he encontrado ninguna. Prueba con su IP.")); return; }
                        String[] n = new String[f.size()]; for (int i = 0; i < n.length; i++) n[i] = f.get(i)[0];
                        new android.app.AlertDialog.Builder(this).setItems(n, (d3, w3) -> addDevice(f.get(w3)[0], f.get(w3)[1])).show();
                    });
                }).start();
            } else {
                EditText e = new EditText(this);
                e.setHint("192.168.1.50");
                String[] ty = {"Roku", "Samsung (Tizen)"};
                new android.app.AlertDialog.Builder(this).setTitle(L.t("IP de la tele")).setView(e).setItems(ty, (d4, w4) -> {
                    String ip = e.getText().toString().trim();
                    if (!ip.matches("\\d+\\.\\d+\\.\\d+\\.\\d+")) { toast(L.t("Esa IP no parece válida.")); return; }
                    addDevice(ty[w4] + " (" + ip + ")", (w4 == 0 ? "roku:" : "tizen:") + ip);
                }).show();
            }
        }).show();
    }

    void addDevice(String name, String spec) {
        try { JSONObject o = devices(this); o.put(name, spec); prefs(this).edit().putString("rm_devices", o.toString()).putString("rm_current", name).apply(); } catch (Exception ignored) {}
        refresh();
        if (spec.startsWith("tizen:")) toast(L.t("La primera vez la tele te preguntará si permites el mando: acepta."));
    }

    /** Para Chloe: «apaga la tele», «sube el volumen de la tele»… (null si no es para la tele) */
    static Actions.Result voice(Context c, String s) {
        if (!s.matches(".*\\b(?:tele|television|tv|telly)\\b.*") && !s.startsWith("macro ")) return null;
        if (current(c).isEmpty()) return new Actions.Result(L.t("Primero añade tu tele en el mando universal."), new android.content.Intent(c, RemoteActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
        java.util.regex.Matcher m;
        List<String> keys = new ArrayList<>();
        String say;
        if (s.startsWith("macro ")) {
            String n = s.substring(6).trim();
            new Thread(() -> runMacro(c, n)).start();
            return new Actions.Result(L.t("Macro") + " «" + n + "».", null);
        }
        if (s.matches(".*\\b(?:apaga|enciende|prende|apagar|encender|turn (?:on|off)|accendi|spegni)\\b.*")) { keys.add("POWER"); say = L.t("Hecho, la tele."); }
        else if ((m = java.util.regex.Pattern.compile("\\bcanal (\\d{1,4})\\b").matcher(s)).find()) { for (char ch : m.group(1).toCharArray()) keys.add(String.valueOf(ch)); say = L.t("Canal") + " " + m.group(1) + "."; }
        else if (s.matches(".*\\b(?:sube|subele|mas alto|alza)\\b.*")) { for (int i = 0; i < 3; i++) keys.add("VOL_UP"); say = L.t("Subo el volumen de la tele."); }
        else if (s.matches(".*\\b(?:baja|bajale|mas bajo)\\b.*")) { for (int i = 0; i < 3; i++) keys.add("VOL_DOWN"); say = L.t("Bajo el volumen de la tele."); }
        else if (s.matches(".*\\b(?:silencia|mute|quita el sonido)\\b.*")) { keys.add("MUTE"); say = L.t("Silencio en la tele."); }
        else if (s.matches(".*\\b(?:siguiente canal|canal siguiente)\\b.*")) { keys.add("CH_UP"); say = L.t("Siguiente canal."); }
        else if (s.matches(".*\\b(?:canal anterior)\\b.*")) { keys.add("CH_DOWN"); say = L.t("Canal anterior."); }
        else if (s.matches(".*\\b(?:entrada|fuente|hdmi|source|input)\\b.*")) { keys.add("INPUT"); say = L.t("Cambio la entrada."); }
        else return null;
        new Thread(() -> { for (String k : keys) { send(c, k); try { Thread.sleep(250); } catch (Exception ignored) {} } }).start();
        return new Actions.Result(say, null);
    }
}
