package com.aplauso.encuentra;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OnnxValue;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

/**
 * v1.8.2 · 🎼 TRANSCRIBIR CANCIÓN (estilo Moises). Escucha un audio y saca:
 *  · las notas (Basic Pitch de Spotify, Apache 2.0, 230 KB, dentro del teléfono),
 *  · la melodía (la voz que manda en cada momento),
 *  · los acordes a lo largo del tiempo (plantillas + Viterbi para que no salten),
 *  · el tempo (BPM) y la tonalidad.
 * Todo sin internet. La letra (opcional) la pone TranscribeActivity.
 */
public class SongTranscriber {
    public static final int SR = 22050, HOP = 256, NS = SR * 2 - HOP, FR = 172, OLAP_F = 30, OLAP = OLAP_F * HOP, STEP = NS - OLAP;
    public static final float FPS = SR / (float) HOP;
    static final int MIDI_OFFSET = 21;

    public static final class Note {
        public float t0, t1, amp; public int midi;
        Note(float a, float b, int m, float amp) { t0 = a; t1 = b; midi = m; this.amp = amp; }
    }
    public static final class ChordSeg {
        public float t0, t1; public MusicTheory.Chord chord;   // chord null = sin acorde (silencio / solo percusión)
        ChordSeg(float a, float b, MusicTheory.Chord c) { t0 = a; t1 = b; chord = c; }
    }
    public static final class Result {
        public List<Note> notes = new ArrayList<>(), melody = new ArrayList<>();
        public List<ChordSeg> chords = new ArrayList<>();
        public float bpm, dur;
        public int keyPc, keyMinor;
    }
    public interface Prog { void on(String phase, int done, int total); boolean cancelled(); }

    // ======================================================================= red neuronal
    /** Devuelve {notas[T][88], inicios[T][88]}. audio: mono a 22050 Hz. */
    static float[][][] infer(byte[] model, float[] audio, Prog p) throws Exception {
        OrtEnvironment env = OrtEnvironment.getEnvironment();
        OrtSession.SessionOptions o = new OrtSession.SessionOptions();
        try { o.setIntraOpNumThreads(Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors() / 2))); } catch (Exception ignored) {}
        try (OrtSession s = env.createSession(model, o)) {
            String in = s.getInputInfo().keySet().iterator().next();
            int pad = OLAP / 2;
            int total = audio.length + pad;
            int nWin = Math.max(1, (total + STEP - 1) / STEP);
            int keep = FR - OLAP_F;                               // se quitan 15 cuadros por cada lado
            int nOut = (int) Math.floor(audio.length * (FPS / SR));
            float[][] note = new float[Math.max(1, nOut)][88], onset = new float[Math.max(1, nOut)][88];
            float[] win = new float[NS];
            int row = 0;
            for (int w = 0; w < nWin && row < nOut; w++) {
                if (p != null) { if (p.cancelled()) throw new InterruptedException(); p.on("notes", w, nWin); }
                java.util.Arrays.fill(win, 0);
                int start = w * STEP - pad;                     // posición en el audio original
                for (int i = 0; i < NS; i++) { int k = start + i; if (k >= 0 && k < audio.length) win[i] = audio[k]; }
                try (OnnxTensor t = OnnxTensor.createTensor(env, FloatBuffer.wrap(win), new long[]{1, NS, 1});
                     OrtSession.Result r = s.run(Collections.singletonMap(in, t))) {
                    float[][] nt = out(r, "StatefulPartitionedCall:1"), on = out(r, "StatefulPartitionedCall:2");
                    for (int f = OLAP_F / 2; f < OLAP_F / 2 + keep && row < nOut; f++, row++) { note[row] = nt[f]; onset[row] = on[f]; }
                }
            }
            return new float[][][]{note, onset};
        }
    }

    static float[][] out(OrtSession.Result r, String name) throws Exception {
        OnnxValue v = r.get(name).orElse(null);
        if (v == null) {                                         // por si la exportación cambia de nombres: por forma
            int i = name.endsWith("1") ? 1 : 2;
            v = r.get(i);
        }
        return ((float[][][]) v.getValue())[0];
    }

    // ======================================================================= de activaciones a notas
    static float frameTime(int f) {
        double off = (HOP / (double) SR) * (FR - (NS / (double) HOP)) + 0.0018;
        return (float) (f * HOP / (double) SR - off * Math.floor(f / (double) FR));
    }

    /** Igual que output_to_notes_polyphonic de Basic Pitch (con inicios inferidos y el truco «melodia»), pero rápido. */
    static List<Note> notes(float[][] frames, float[][] onsets0, float onsetTh, float frameTh, int minLen) {
        int T = frames.length, F = 88, tol = 11;
        List<Note> out = new ArrayList<>();
        if (T < 3) return out;
        // inicios inferidos de los saltos de energía
        float[][] on = new float[T][F];
        float maxOn = 0, maxDiff = 0;
        float[][] diff = new float[T][F];
        for (int t = 0; t < T; t++) for (int f = 0; f < F; f++) {
            maxOn = Math.max(maxOn, onsets0[t][f]);
            if (t < 2) continue;
            float d1 = frames[t][f] - frames[t - 1][f], d2 = frames[t][f] - frames[t - 2][f];
            float d = Math.max(0, Math.min(d1, d2));
            diff[t][f] = d; maxDiff = Math.max(maxDiff, d);
        }
        float sc = maxDiff > 0 ? maxOn / maxDiff : 0;
        for (int t = 0; t < T; t++) for (int f = 0; f < F; f++) on[t][f] = Math.max(onsets0[t][f], diff[t][f] * sc);

        float[][] rem = new float[T][];
        for (int t = 0; t < T; t++) rem[t] = frames[t].clone();
        // picos de inicio (máximo local en el tiempo) por encima del umbral, de atrás hacia delante
        List<int[]> peaks = new ArrayList<>();
        for (int t = 1; t < T - 1; t++) for (int f = 0; f < F; f++) {
            float v = on[t][f];
            if (v >= onsetTh && v > on[t - 1][f] && v > on[t + 1][f]) peaks.add(new int[]{t, f});
        }
        Collections.sort(peaks, (a, b) -> a[0] != b[0] ? b[0] - a[0] : b[1] - a[1]);
        for (int[] pk : peaks) {
            int s = pk[0], f = pk[1];
            if (s >= T - 1) continue;
            int i = s + 1, k = 0;
            while (i < T - 1 && k < tol) { if (rem[i][f] < frameTh) k++; else k = 0; i++; }
            i -= k;
            if (i - s <= minLen) continue;
            for (int x = s; x < i; x++) { rem[x][f] = 0; if (f < F - 1) rem[x][f + 1] = 0; if (f > 0) rem[x][f - 1] = 0; }
            out.add(new Note(frameTime(s), frameTime(i), f + MIDI_OFFSET, mean(frames, s, i, f)));
        }
        // «melodia»: notas sin inicio claro, de la más fuerte a la más floja
        List<long[]> cand = new ArrayList<>();
        for (int t = 0; t < T; t++) for (int f = 0; f < F; f++) if (rem[t][f] > frameTh) cand.add(new long[]{Float.floatToIntBits(rem[t][f]), t, f});
        Collections.sort(cand, (a, b) -> Float.compare(Float.intBitsToFloat((int) b[0]), Float.intBitsToFloat((int) a[0])));
        for (long[] c : cand) {
            int mid = (int) c[1], f = (int) c[2];
            if (rem[mid][f] <= frameTh) continue;
            rem[mid][f] = 0;
            int i = mid + 1, k = 0;
            while (i < T - 1 && k < tol) {
                if (rem[i][f] < frameTh) k++; else k = 0;
                rem[i][f] = 0; if (f < F - 1) rem[i][f + 1] = 0; if (f > 0) rem[i][f - 1] = 0;
                i++;
            }
            int end = i - 1 - k;
            i = mid - 1; k = 0;
            while (i > 0 && k < tol) {
                if (rem[i][f] < frameTh) k++; else k = 0;
                rem[i][f] = 0; if (f < F - 1) rem[i][f + 1] = 0; if (f > 0) rem[i][f - 1] = 0;
                i--;
            }
            int st = i + 1 + k;
            if (end - st <= minLen) continue;
            out.add(new Note(frameTime(st), frameTime(end), f + MIDI_OFFSET, mean(frames, st, end, f)));
        }
        Collections.sort(out, (a, b) -> Float.compare(a.t0, b.t0));
        return out;
    }

    static float mean(float[][] fr, int a, int b, int f) { float s = 0; for (int i = a; i < b; i++) s += fr[i][f]; return b > a ? s / (b - a) : 0; }

    // ======================================================================= melodía
    /** La línea que manda: cada 10 ms, la nota más aguda que suene con fuerza parecida a la más fuerte (estilo «skyline»). */
    static List<Note> melody(List<Note> all, int lo, int hi) {
        List<Note> c = new ArrayList<>();
        float end = 0;
        for (Note n : all) if (n.midi >= lo && n.midi <= hi && n.t1 - n.t0 >= 0.09f) { c.add(n); end = Math.max(end, n.t1); }
        int steps = (int) (end / 0.01f) + 1;
        Note[] pick = new Note[steps];
        List<Note> active = new ArrayList<>();
        int ci = 0;
        Collections.sort(c, (a, b) -> Float.compare(a.t0, b.t0));
        for (int k = 0; k < steps; k++) {
            float t = k * 0.01f;
            while (ci < c.size() && c.get(ci).t0 <= t) active.add(c.get(ci++));
            active.removeIf(n -> n.t1 <= t);
            if (active.isEmpty()) continue;
            float mx = 0; for (Note n : active) mx = Math.max(mx, n.amp);
            Note best = null;
            for (Note n : active) if (n.amp >= 0.55f * mx && (best == null || n.midi > best.midi)) best = n;
            pick[k] = best;
        }
        List<Note> mel = new ArrayList<>();
        Note cur = null; float st = 0;
        for (int k = 0; k <= steps; k++) {
            Note p = k < steps ? pick[k] : null;
            if (p == cur) continue;
            // solo cuenta si la nota empieza ahí (un ataque nuevo); si ya sonaba de antes, es el acompañamiento que queda debajo
            if (cur != null) { float t1 = k * 0.01f; if (t1 - st >= 0.07f && st - cur.t0 <= 0.08f) mel.add(new Note(Math.max(st, cur.t0), t1, cur.midi, cur.amp)); }
            cur = p; st = k * 0.01f;
        }
        // la misma nota partida por una interrupción mínima → una sola, salvo que empiece de nuevo (otro ataque)
        List<Note> out = new ArrayList<>();
        for (Note n : mel) {
            Note last = out.isEmpty() ? null : out.get(out.size() - 1);
            if (last != null && last.midi == n.midi && n.t0 - last.t1 < 0.03f && Math.abs(n.t0 - last.t0) < 0.02f) { last.t1 = n.t1; continue; }
            out.add(n);
        }
        return out;
    }

    // ======================================================================= acordes
    static final String[] TYPES = {"", "m", "7", "m7", "sus4", "dim"};
    static final float[] TYPE_COST = {0f, 0f, 0.035f, 0.035f, 0.06f, 0.08f};

    /** Acordes a lo largo del tiempo a partir de las activaciones (bloques de ~0,2 s, Viterbi con penalización por cambiar). */
    static List<ChordSeg> chords(float[][] frames, float switchCost) {
        int T = frames.length, B = 17;                            // 17 cuadros ≈ 0,197 s
        int nb = Math.max(1, T / B);
        int nc = 12 * TYPES.length + 1;                           // + «sin acorde»
        float[][] tpl = new float[nc - 1][12];
        for (int r = 0; r < 12; r++) for (int ty = 0; ty < TYPES.length; ty++) {
            int[] iv = MusicTheory.TYPES.get(TYPES[ty]);
            float[] v = tpl[r * TYPES.length + ty];
            for (int i : iv) v[MusicTheory.mod12(r + i)] = i == 0 ? 1.25f : 1f;
            norm(v);
        }
        float[][] score = new float[nb][nc];
        float[] energy = new float[nb];
        float maxE = 1e-6f;
        for (int b = 0; b < nb; b++) {
            float[] ch = new float[12], bass = new float[12];
            for (int t = b * B; t < Math.min(T, (b + 1) * B); t++) {
                int low = -1;
                for (int f = 0; f < 88; f++) {
                    float v = frames[t][f];
                    if (v < 0.15f) continue;
                    int pc = MusicTheory.mod12(f + MIDI_OFFSET);
                    float w = (f + MIDI_OFFSET) < 48 ? 1.4f : (f + MIDI_OFFSET) > 84 ? 0.5f : 1f;   // los graves pesan más
                    ch[pc] += v * w;
                    if (low < 0 && v > 0.3f) low = f;
                }
                if (low >= 0) bass[MusicTheory.mod12(low + MIDI_OFFSET)] += 1;
            }
            float e = 0; for (float x : ch) e += x;
            energy[b] = e; maxE = Math.max(maxE, e);
            norm(ch);
            int bassPc = argmax(bass);
            boolean hasBass = bass[bassPc] > 0;
            for (int k = 0; k < nc - 1; k++) {
                float s = 0; for (int i = 0; i < 12; i++) s += ch[i] * tpl[k][i];
                if (hasBass && k / TYPES.length == bassPc) s += 0.12f;
                score[b][k] = s - TYPE_COST[k % TYPES.length];
            }
        }
        for (int b = 0; b < nb; b++) score[b][nc - 1] = energy[b] < 0.06f * maxE ? 1f : 0.25f;   // silencio → «sin acorde»
        // Viterbi
        float[] prev = score[0].clone();
        int[][] back = new int[nb][nc];
        for (int b = 1; b < nb; b++) {
            int bestK = argmax(prev);
            float best = prev[bestK];
            float[] cur = new float[nc];
            for (int k = 0; k < nc; k++) {
                float stay = prev[k], jump = best - switchCost;
                if (stay >= jump) { cur[k] = stay + score[b][k]; back[b][k] = k; }
                else { cur[k] = jump + score[b][k]; back[b][k] = bestK; }
            }
            prev = cur;
        }
        int[] path = new int[nb];
        path[nb - 1] = argmax(prev);
        for (int b = nb - 1; b > 0; b--) path[b - 1] = back[b][path[b]];
        List<ChordSeg> segs = new ArrayList<>();
        float blk = B / FPS;
        for (int b = 0; b < nb; b++) {
            int k = path[b];
            MusicTheory.Chord c = null;
            if (k < nc - 1) { c = new MusicTheory.Chord(); c.root = k / TYPES.length; c.type = TYPES[k % TYPES.length]; }
            if (!segs.isEmpty() && same(segs.get(segs.size() - 1).chord, c)) segs.get(segs.size() - 1).t1 = (b + 1) * blk;
            else segs.add(new ChordSeg(b * blk, (b + 1) * blk, c));
        }
        // trozos muy cortos (< 0,45 s) se funden con el vecino
        for (int i = 0; i < segs.size(); i++) {
            ChordSeg s = segs.get(i);
            if (s.t1 - s.t0 >= 0.45f || segs.size() < 2) continue;
            if (i > 0) segs.get(i - 1).t1 = s.t1; else segs.get(i + 1).t0 = s.t0;
            segs.remove(i); i = Math.max(-1, i - 2);
            for (int j = 1; j < segs.size(); j++) if (same(segs.get(j - 1).chord, segs.get(j).chord)) { segs.get(j - 1).t1 = segs.get(j).t1; segs.remove(j); j--; }
        }
        return segs;
    }

    static boolean same(MusicTheory.Chord a, MusicTheory.Chord b) { return a == null ? b == null : a.equals(b); }
    static void norm(float[] v) { float s = 0; for (float x : v) s += x * x; s = (float) Math.sqrt(s); if (s > 0) for (int i = 0; i < v.length; i++) v[i] /= s; }
    static int argmax(float[] v) { int b = 0; for (int i = 1; i < v.length; i++) if (v[i] > v[b]) b = i; return b; }

    // ======================================================================= tempo
    static float bpm(float[][] onsets) {
        int T = onsets.length;
        if (T < 200) return 0;
        float[] env = new float[T];
        for (int t = 0; t < T; t++) { float s = 0; for (float v : onsets[t]) s += v; env[t] = s; }
        float m = 0; for (float v : env) m += v; m /= T;
        for (int t = 0; t < T; t++) env[t] = Math.max(0, env[t] - m);
        double best = -1; float bestBpm = 0;
        for (int lag = (int) (FPS * 60 / 190); lag <= (int) (FPS * 60 / 55); lag++) {
            double s = 0;
            for (int t = lag; t < T; t++) s += env[t] * env[t - lag];
            float b = (float) (60 * FPS / lag);
            double prior = Math.exp(-0.5 * Math.pow(Math.log(b / 110.0) / 0.45, 2));   // los tempos normales, más probables
            s *= prior;
            if (s > best) { best = s; bestBpm = b; }
        }
        return Math.round(bestBpm);
    }

    // ======================================================================= todo junto
    static Result run(byte[] model, float[] audio, Prog p) throws Exception {
        Result r = new Result();
        r.dur = audio.length / (float) SR;
        float[][][] o = infer(model, audio, p);
        if (p != null) p.on("decode", 0, 1);
        r.notes = notes(o[0], o[1], 0.5f, 0.3f, Math.round(127.7f / 1000f * FPS));
        r.melody = melody(r.notes, 52, 88);
        if (p != null) p.on("chords", 0, 1);
        r.chords = chords(o[0], 0.9f);
        r.bpm = bpm(o[1]);
        List<MusicTheory.Chord> cs = new ArrayList<>();
        for (ChordSeg s : r.chords) if (s.chord != null) cs.add(s.chord);
        int[] k = MusicTheory.guessKey(cs);
        r.keyPc = k[0]; r.keyMinor = k[1];
        return r;
    }

    // ======================================================================= de audio a 22050 Hz mono
    /** Lee un WAV de 16 bits (de MediaTools.toWav) por trozos, a mono y a 22050 Hz (con un filtro sencillo anti-aliasing). */
    static float[] loadWav(java.io.File f) throws Exception {
        try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(f, "r")) {
            byte[] hdr = new byte[12]; raf.readFully(hdr);
            int ch = 2, rate = 44100; long dataPos = -1, dataLen = 0;
            long pos = 12;
            byte[] h8 = new byte[8];
            while (pos + 8 <= raf.length()) {
                raf.seek(pos); raf.readFully(h8);
                java.nio.ByteBuffer b = java.nio.ByteBuffer.wrap(h8).order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int id = b.getInt(0); long len = b.getInt(4) & 0xffffffffL;
                if (id == 0x20746d66) {
                    byte[] fm = new byte[16]; raf.readFully(fm);
                    java.nio.ByteBuffer x = java.nio.ByteBuffer.wrap(fm).order(java.nio.ByteOrder.LITTLE_ENDIAN);
                    ch = x.getShort(2); rate = x.getInt(4);
                } else if (id == 0x61746164) { dataPos = pos + 8; dataLen = Math.min(len, raf.length() - dataPos); break; }
                pos += 8 + len + (len & 1);
            }
            if (dataPos < 0) throw new Exception("WAV");
            long frames = dataLen / (2L * ch);
            float[] mono = new float[(int) frames];
            raf.seek(dataPos);
            byte[] buf = new byte[65536 - 65536 % (2 * ch)];
            int at = 0;
            while (at < frames) {
                int want = (int) Math.min(buf.length, (frames - at) * 2L * ch);
                raf.readFully(buf, 0, want);
                java.nio.ByteBuffer b = java.nio.ByteBuffer.wrap(buf, 0, want).order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int n = want / (2 * ch);
                for (int i = 0; i < n; i++) { float s = 0; for (int c = 0; c < ch; c++) s += b.getShort((i * ch + c) * 2); mono[at++] = s / (32768f * ch); }
            }
            return resample(mono, rate, SR);
        }
    }

    static float[] resample(float[] x, int from, int to) {
        if (from == to) return x;
        if (from > to) {                                          // paso bajo: media móvil del tamaño de la relación
            int w = Math.max(1, Math.round(from / (float) to));
            if (w > 1) {
                float[] y = new float[x.length]; double acc = 0;
                for (int i = 0; i < x.length; i++) { acc += x[i]; if (i >= w) acc -= x[i - w]; y[i] = (float) (acc / Math.min(i + 1, w)); }
                x = y;
            }
        }
        int n = (int) ((long) x.length * to / from);
        float[] out = new float[n];
        double step = from / (double) to;
        for (int i = 0; i < n; i++) {
            double p = i * step; int a = (int) p; double fr = p - a;
            float v0 = x[Math.min(a, x.length - 1)], v1 = x[Math.min(a + 1, x.length - 1)];
            out[i] = (float) (v0 + (v1 - v0) * fr);
        }
        return out;
    }

    // ======================================================================= tablatura
    /** Trastes (cuerda, traste) para tocar una melodía con el mínimo movimiento de mano. strings: de grave a agudo. */
    static int[][] tab(List<Integer> mel, int[] strings, int capo) {
        int n = mel.size(), S = strings.length;
        int[][] res = new int[n][];
        if (n == 0) return res;
        List<int[]>[] opts = new List[n];
        for (int i = 0; i < n; i++) {
            opts[i] = new ArrayList<>();
            for (int s = 0; s < S; s++) { int fr = mel.get(i) - strings[s] - capo; if (fr >= 0 && fr <= 17) opts[i].add(new int[]{s, fr}); }
            if (opts[i].isEmpty()) opts[i].add(new int[]{-1, -1});           // no cabe en el mástil
        }
        double[][] cost = new double[n][]; int[][] from = new int[n][];
        for (int i = 0; i < n; i++) {
            cost[i] = new double[opts[i].size()]; from[i] = new int[opts[i].size()];
            for (int j = 0; j < opts[i].size(); j++) {
                int[] o = opts[i].get(j);
                double base = o[0] < 0 ? 50 : (o[1] == 0 ? 0 : 0.6 + o[1] * 0.15);          // mejor abajo en el mástil
                if (i == 0) { cost[i][j] = base; continue; }
                double best = 1e18; int bk = 0;
                for (int k = 0; k < opts[i - 1].size(); k++) {
                    int[] q = opts[i - 1].get(k);
                    double mv = (o[0] < 0 || q[0] < 0) ? 0 : (o[1] == 0 || q[1] == 0 ? 0.3 : Math.max(0, Math.abs(o[1] - q[1]) - 3) * 1.2 + Math.abs(o[1] - q[1]) * 0.1) + Math.abs(o[0] - q[0]) * 0.25;   // la mano abarca ~4 trastes
                    double c = cost[i - 1][k] + mv;
                    if (c < best) { best = c; bk = k; }
                }
                cost[i][j] = best + base; from[i][j] = bk;
            }
        }
        int j = 0; for (int k = 1; k < cost[n - 1].length; k++) if (cost[n - 1][k] < cost[n - 1][j]) j = k;
        for (int i = n - 1; i >= 0; i--) { res[i] = opts[i].get(j); j = from[i][j]; }
        return res;
    }

    /** Dibujo ASCII de la tablatura (cuerda aguda arriba), partido en filas de «perRow» notas. */
    static String tabText(int[][] pos, int[] strings, String notation, boolean flats, int perRow) {
        StringBuilder sb = new StringBuilder();
        int S = strings.length;
        for (int from = 0; from < pos.length; from += perRow) {
            int to = Math.min(pos.length, from + perRow);
            for (int s = S - 1; s >= 0; s--) {
                String nm = MusicTheory.name(MusicTheory.mod12(strings[s]), notation, flats);
                if (nm.length() > 2) nm = nm.substring(0, 2);
                StringBuilder l = new StringBuilder(String.format(java.util.Locale.ROOT, "%-2s|", nm));
                for (int i = from; i < to; i++) {
                    String c = pos[i][0] == s ? String.valueOf(pos[i][1]) : (pos[i][0] < 0 && s == S - 1 ? "?" : "");
                    l.append('-').append(c);
                    for (int k = c.length(); k < 2; k++) l.append('-');
                }
                sb.append(l).append("-|\n");
            }
            if (to < pos.length) sb.append('\n');
        }
        return sb.toString();
    }

    // ======================================================================= ChordPro
    public static final class Line { public float t0, t1; public String text, section; public Line(float a, float b, String t, String s) { t0 = a; t1 = b; text = t; section = s; } }

    /** Monta la canción: acordes encima de la palabra donde suenan, ♪ con la melodía de cada verso, secciones. */
    static String chordPro(Result r, List<Line> lyrics, String notation, boolean flats, boolean withMelody) {
        StringBuilder sb = new StringBuilder();
        List<Line> lines = lyrics;
        if (lines == null || lines.isEmpty()) {                   // sin letra: una línea por cada ~4 compases
            lines = new ArrayList<>();
            float len = r.bpm > 0 ? 16 * 60f / r.bpm : 8f;
            for (float t = 0; t < r.dur; t += len) lines.add(new Line(t, Math.min(r.dur, t + len), "", null));
        }
        String lastSection = null;
        float prevEnd = 0;
        for (Line ln : lines) {
            // hueco instrumental largo antes de este verso
            if (ln.t0 - prevEnd > 6f && !ln.text.isEmpty()) {
                String inst = chordsOnly(r, prevEnd, ln.t0, notation, flats);
                if (!inst.isEmpty()) sb.append("# ").append(prevEnd < 1 ? L.t("Intro") : L.t("Instrumental")).append('\n').append(inst).append("\n\n");
                lastSection = null;
            }
            if (ln.section != null && !ln.section.isEmpty() && !ln.section.equals(lastSection)) { sb.append("\n# ").append(ln.section).append('\n'); lastSection = ln.section; }
            if (withMelody) {
                StringBuilder mel = new StringBuilder();
                int cnt = 0;
                for (Note n : r.melody) if (n.t0 >= ln.t0 - 0.05f && n.t0 < ln.t1 && cnt < 32) {
                    mel.append(MusicTheory.name(MusicTheory.mod12(n.midi), notation, flats)).append(n.midi / 12 - 1).append(' '); cnt++;
                }
                if (cnt > 0) sb.append("♪ ").append(mel.toString().trim()).append('\n');
            }
            if (ln.text.isEmpty()) sb.append(chordsOnly(r, ln.t0, ln.t1, notation, flats)).append('\n');
            else sb.append(place(r, ln, notation, flats)).append('\n');
            prevEnd = ln.t1;
        }
        if (r.dur - prevEnd > 6f && lyrics != null && !lyrics.isEmpty()) {
            String out = chordsOnly(r, prevEnd, r.dur, notation, flats);
            if (!out.isEmpty()) sb.append("\n# ").append(L.t("Final")).append('\n').append(out).append('\n');
        }
        return sb.toString().replaceAll("\n{3,}", "\n\n").trim() + "\n";
    }

    static String chordsOnly(Result r, float a, float b, String notation, boolean flats) {
        StringBuilder sb = new StringBuilder();
        String last = null;
        for (ChordSeg s : r.chords) {
            if (s.t1 <= a || s.t0 >= b || s.chord == null) continue;
            String nm = s.chord.name(notation, flats);
            if (nm.equals(last)) continue;
            sb.append('[').append(nm).append("] ");
            last = nm;
        }
        return sb.toString().trim();
    }

    static String place(Result r, Line ln, String notation, boolean flats) {
        String text = ln.text;
        int L0 = text.length();
        java.util.TreeMap<Integer, String> at = new java.util.TreeMap<>();
        float span = Math.max(0.3f, ln.t1 - ln.t0);
        for (ChordSeg s : r.chords) {
            if (s.chord == null || s.t1 <= ln.t0 || s.t0 >= ln.t1) continue;
            float t = Math.max(s.t0, ln.t0);
            if (t > ln.t0 && (t - ln.t0) / span > 0.9f) continue;          // empieza justo al final: irá al principio del siguiente verso
            int col = Math.round((t - ln.t0) / span * L0);
            col = snapWord(text, Math.min(L0, Math.max(0, col)));
            String nm = s.chord.name(notation, flats);
            if (at.containsKey(col)) { at.put(col, nm); continue; }       // el más reciente en la misma palabra gana
            at.put(col, nm);
        }
        // quitar repetidos seguidos
        StringBuilder sb = new StringBuilder();
        String last = null; int prev = 0;
        for (Map.Entry<Integer, String> e : at.entrySet()) {
            sb.append(text, prev, e.getKey());
            if (!e.getValue().equals(last)) sb.append('[').append(e.getValue()).append(']');
            last = e.getValue(); prev = e.getKey();
        }
        sb.append(text.substring(prev));
        return sb.toString();
    }

    static int snapWord(String t, int col) {
        if (col >= t.length()) return t.length();
        if (col == 0 || t.charAt(col - 1) == ' ') return col;
        int l = col, r = col;
        while (l > 0 && t.charAt(l - 1) != ' ') l--;
        while (r < t.length() && t.charAt(r) != ' ') r++;
        return (col - l <= r - col || r >= t.length()) ? l : Math.min(t.length(), r + 1);
    }

    /** Sin Gemini: reparte la letra pegada por los tramos donde suena la melodía (frases separadas por silencios). */
    static List<Line> alignPasted(Result r, String lyrics) {
        List<String> ls = new ArrayList<>();
        List<String> sec = new ArrayList<>();
        String curSec = null;
        for (String l : lyrics.split("\n")) {
            String t = l.trim();
            if (t.isEmpty()) continue;
            if (t.matches("^\\[[^\\]]{2,30}\\]$") || t.startsWith("#")) { curSec = t.replaceAll("^[#\\[\\s]+|[\\]\\s]+$", ""); continue; }
            ls.add(t); sec.add(curSec); curSec = null;
        }
        List<float[]> phr = new ArrayList<>();
        float s = -1, e = -1;
        for (Note n : r.melody) {
            if (s < 0) { s = n.t0; e = n.t1; continue; }
            if (n.t0 - e > 0.6f) { phr.add(new float[]{s, e}); s = n.t0; }
            e = Math.max(e, n.t1);
        }
        if (s >= 0) phr.add(new float[]{s, e});
        List<Line> out = new ArrayList<>();
        if (ls.isEmpty()) return out;
        if (phr.isEmpty()) { float d = r.dur / ls.size(); for (int i = 0; i < ls.size(); i++) out.add(new Line(i * d, (i + 1) * d, ls.get(i), sec.get(i))); return out; }
        // a cada verso, un grupo de frases seguidas de duración proporcional a sus sílabas
        int[] syl = new int[ls.size()]; int totSyl = 0;
        for (int i = 0; i < ls.size(); i++) { syl[i] = Math.max(1, ls.get(i).replaceAll("[^aeiouáéíóúàèìòùAEIOUÁÉÍÓÚÀÈÌÒÙyY]+", " ").trim().split("\\s+").length); totSyl += syl[i]; }
        float totDur = 0; for (float[] p : phr) totDur += p[1] - p[0];
        int pi = 0; float used = 0;
        for (int i = 0; i < ls.size(); i++) {
            float want = totDur * syl[i] / totSyl;
            float t0 = pi < phr.size() ? phr.get(pi)[0] + used : r.dur;
            float got = 0, t1 = t0;
            while (pi < phr.size() && got < want * 0.999f) {
                float left = phr.get(pi)[1] - phr.get(pi)[0] - used;
                float take = Math.min(left, want - got);
                got += take; used += take; t1 = phr.get(pi)[0] + used;
                if (used >= phr.get(pi)[1] - phr.get(pi)[0] - 1e-3f) { pi++; used = 0; if (got > want * 0.6f) break; }
            }
            out.add(new Line(t0, Math.max(t0 + 0.3f, t1), ls.get(i), sec.get(i)));
        }
        return out;
    }

    /** Respuesta de Gemini («[{"t":12.3,"e":15.0,"l":"…","s":"Estribillo"}]») → versos. */
    static List<Line> parseGemini(String txt, float dur) {
        List<Line> out = new ArrayList<>();
        try {
            String j = txt.trim();
            int a = j.indexOf('['), b = j.lastIndexOf(']');
            if (a < 0 || b <= a) return out;
            org.json.JSONArray arr = new org.json.JSONArray(j.substring(a, b + 1));
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String l = o.optString("l", o.optString("line", "")).trim();
                if (l.isEmpty()) continue;
                float t0 = (float) o.optDouble("t", o.optDouble("start", -1));
                float t1 = (float) o.optDouble("e", o.optDouble("end", -1));
                if (t0 < 0) continue;
                out.add(new Line(t0, t1, l, o.optString("s", o.optString("section", "")).trim()));
            }
            Collections.sort(out, (x, y) -> Float.compare(x.t0, y.t0));
            for (int i = 0; i < out.size(); i++) {
                Line ln = out.get(i);
                float next = i + 1 < out.size() ? out.get(i + 1).t0 : dur;
                if (ln.t1 <= ln.t0 || ln.t1 > next + 0.5f) ln.t1 = Math.min(next, ln.t0 + Math.max(1.5f, ln.text.length() * 0.09f));
            }
        } catch (Exception ignored) {}
        return out;
    }

}
