package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

/**
 * v1.8 · 📒 CANCIONERO: letra con acordes encima (formato ChordPro: «[Am]Yo te escribí…»), notas de la melodía
 * (línea «♪ Do Re Mi…») con tabs de armónica, transporte con tabla, simplificada/original, acordes alternativos,
 * cejilla recomendada, desplazamiento automático y modo escenario. Todo en el teléfono.
 */
public class SongbookActivity extends NeonActivity {
    static final int REQ_IMPORT = 91;
    final Handler h = new Handler(Looper.getMainLooper());
    File dir;
    String query = "";
    LinearLayout listBox;

    // canción abierta
    JSONObject song;
    File songFile;
    int shift;               // semitonos de transporte (sin guardar)
    boolean simple, stage, autoscroll;
    float scrollSpeed = 1f;
    ScrollView viewScroll;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dir = new File(getFilesDir(), "songs");
        dir.mkdirs();
        String add = getIntent().getStringExtra("new_text");
        if (add != null) { newSong(getIntent().getStringExtra("new_title"), add); return; }
        showList();
        String open = getIntent().getStringExtra("open_file");               // v1.8.2: desde 🎼 Transcribir canción
        if (open != null && new File(open).exists()) openSong(new File(open));
    }

    // ================================================================== lista
    void showList() {
        song = null;
        stopScroll();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout col = screen("📒 CANCIONERO");
        LinearLayout tools = new LinearLayout(this);
        tools.addView(button("＋ NUEVA", v -> newSong("", "")), new LinearLayout.LayoutParams(0, -2, 1));
        TextView imp = button("📥 IMPORTAR", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_IMPORT);
        });
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(0, -2, 1); il.leftMargin = dpi(6);
        tools.addView(imp, il);
        col.addView(tools, gapBelow(8));
        EditText search = new EditText(this);
        search.setHint(L.t("🔍 Buscar por título, artista o letra"));
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.GRAY);
        search.setBackground(frame(10));
        search.setPadding(dpi(12), dpi(10), dpi(12), dpi(10));
        search.setText(query);
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(android.text.Editable e) { query = e.toString(); fillList(); }
        });
        col.addView(search, gapBelow(8));
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        col.addView(listBox);
        fillList();
    }

    List<File> files() {
        File[] f = dir.listFiles((d, n) -> n.endsWith(".json"));
        List<File> l = new ArrayList<>();
        if (f != null) for (File x : f) l.add(x);
        return l;
    }

    static JSONObject read(File f) {
        try { return new JSONObject(new String(java.nio.file.Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8)); }
        catch (Exception e) { return new JSONObject(); }
    }

    void fillList() {
        listBox.removeAllViews();
        List<Object[]> items = new ArrayList<>();
        String q = Actions.norm(query);
        for (File f : files()) {
            JSONObject o = read(f);
            String hay = Actions.norm(o.optString("title") + " " + o.optString("artist") + " " + o.optString("folder") + " " + o.optString("text"));
            if (!q.isEmpty() && !hay.contains(q)) continue;
            items.add(new Object[]{f, o});
        }
        java.util.Collections.sort(items, (a, b) -> {
            JSONObject x = (JSONObject) a[1], y = (JSONObject) b[1];
            if (x.optBoolean("fav") != y.optBoolean("fav")) return x.optBoolean("fav") ? -1 : 1;
            int c = x.optString("folder").compareToIgnoreCase(y.optString("folder"));
            return c != 0 ? c : x.optString("title").compareToIgnoreCase(y.optString("title"));
        });
        if (items.isEmpty()) {
            listBox.addView(text(query.isEmpty() ? "Aún no tienes canciones. Pulsa ＋ NUEVA: escribe la letra y pon los acordes entre corchetes, por ejemplo [Am]Yo te escribí una canción."
                    : "Nada con eso.", 13));
            return;
        }
        String lastFolder = null;
        for (Object[] it : items) {
            JSONObject o = (JSONObject) it[1];
            String folder = o.optString("folder");
            if (!o.optBoolean("fav") && !folder.equals(lastFolder) && !folder.isEmpty()) { listBox.addView(neonText("📁 " + folder, 12)); lastFolder = folder; }
            LinearLayout c = panel(null);
            c.addView(neonText((o.optBoolean("fav") ? "⭐ " : "") + (o.optBoolean("personal") ? "🔒 " : "") + o.optString("title", L.t("Sin título")), 16));
            String sub = o.optString("artist");
            String key = o.optString("key");
            TextView d = text((sub.isEmpty() ? "" : sub) + (key.isEmpty() ? "" : (sub.isEmpty() ? "" : " · ") + key) + (o.optInt("bpm") > 0 ? " · " + o.optInt("bpm") + " BPM" : ""), 12);
            d.setTextColor(Color.rgb(170, 180, 200));
            c.addView(d);
            c.setClickable(true);
            File f = (File) it[0];
            c.setOnClickListener(v -> openSong(f));
            c.setOnLongClickListener(v -> { songMenu(f); return true; });
            listBox.addView(c, gapBelow(8));
        }
    }

    void songMenu(File f) {
        JSONObject o = read(f);
        // v1.8.2: las transcritas de canciones de otros son solo para ti: sin compartir ni exportar
        boolean personal = o.optBoolean("personal");
        String[] opts = {o.optBoolean("fav") ? L.t("☆ Quitar de favoritas") : L.t("⭐ Favorita"), L.t("📁 Carpeta / lista…"),
                personal ? L.t("🔒 Solo para ti (no se comparte)") : L.t("📤 Compartir (ChordPro)"), L.t("🗑 Borrar")};
        new android.app.AlertDialog.Builder(this).setTitle(o.optString("title")).setItems(opts, (d, w) -> {
            try {
                if (w == 0) { o.put("fav", !o.optBoolean("fav")); write(f, o); fillList(); }
                else if (w == 1) {
                    EditText e = new EditText(this);
                    e.setText(o.optString("folder"));
                    e.setHint(L.t("p. ej. Para el viernes"));
                    new android.app.AlertDialog.Builder(this).setView(e).setPositiveButton("OK", (d2, w2) -> {
                        try { o.put("folder", e.getText().toString().trim()); write(f, o); fillList(); } catch (Exception ignored) {}
                    }).show();
                } else if (w == 2) { if (personal) toast(L.t("Es una canción transcrita: es solo para ti y se queda en tu Cancionero.")); else share(o); }
                else new android.app.AlertDialog.Builder(this).setMessage(L.t("¿Borrar") + " «" + o.optString("title") + "»?")
                            .setPositiveButton(L.t("Borrar"), (d2, w2) -> { f.delete(); fillList(); }).setNegativeButton(L.t("Cancelar"), null).show();
            } catch (Exception ignored) {}
        }).show();
    }

    static void write(File f, JSONObject o) {
        try { o.put("updated", System.currentTimeMillis()); java.nio.file.Files.write(f.toPath(), o.toString(1).getBytes(StandardCharsets.UTF_8)); } catch (Exception ignored) {}
    }

    void share(JSONObject o) {
        StringBuilder sb = new StringBuilder();
        sb.append("{title: ").append(o.optString("title")).append("}\n");
        if (!o.optString("artist").isEmpty()) sb.append("{artist: ").append(o.optString("artist")).append("}\n");
        if (!o.optString("key").isEmpty()) sb.append("{key: ").append(o.optString("key")).append("}\n");
        if (o.optInt("bpm") > 0) sb.append("{tempo: ").append(o.optInt("bpm")).append("}\n");
        if (o.optInt("capo") > 0) sb.append("{capo: ").append(o.optInt("capo")).append("}\n");
        sb.append("\n").append(o.optString("text"));
        startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, o.optString("title"))
                .putExtra(Intent.EXTRA_TEXT, sb.toString()), L.t("Compartir canción")));
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMPORT || res != RESULT_OK || data == null || data.getData() == null) return;
        try (java.io.InputStream in = getContentResolver().openInputStream(data.getData())) {
            String t = new String(DocIO.readAll(in), StandardCharsets.UTF_8);
            String title = meta(t, "title|t");
            t = t.replaceAll("(?m)^\\{(?:title|t|artist|a|key|tempo|capo|subtitle|st)\\s*:[^}]*\\}\\s*$\\n?", "");
            newSong(title.isEmpty() ? nameOf(data.getData()) : title, t.trim());
        } catch (Exception e) { toast(L.t("No puedo leer ese archivo.")); }
    }

    String nameOf(Uri u) { String s = u.getLastPathSegment(); return s == null ? "" : s.replaceAll(".*[/:]", "").replaceAll("\\.[A-Za-z0-9]+$", ""); }

    static String meta(String t, String keys) {
        Matcher m = java.util.regex.Pattern.compile("(?mi)^\\{(?:" + keys + ")\\s*:\\s*([^}]*)\\}").matcher(t);
        return m.find() ? m.group(1).trim() : "";
    }

    // ================================================================== editor
    void newSong(String title, String text) {
        try {
            JSONObject o = new JSONObject();
            o.put("title", title == null ? "" : title);
            o.put("text", text == null ? "" : text);
            File f = new File(dir, System.currentTimeMillis() + ".json");
            edit(f, o);
        } catch (Exception ignored) {}
    }

    void edit(File f, JSONObject o) {
        song = null;
        stopScroll();
        LinearLayout col = screen("✏ " + L.t("CANCIÓN"));
        EditText title = field(col, "Título", o.optString("title"), false);
        EditText artist = field(col, "Artista", o.optString("artist"), false);
        LinearLayout r = new LinearLayout(this);
        EditText key = field(null, "Tonalidad (p. ej. Am)", o.optString("key"), false);
        EditText bpm = field(null, "BPM", o.optInt("bpm") > 0 ? String.valueOf(o.optInt("bpm")) : "", false);
        EditText capo = field(null, "Cejilla", o.optInt("capo") > 0 ? String.valueOf(o.optInt("capo")) : "", false);
        bpm.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        capo.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        r.addView(key, new LinearLayout.LayoutParams(0, -2, 1.4f));
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1); l2.leftMargin = dpi(4);
        r.addView(bpm, l2);
        LinearLayout.LayoutParams l3 = new LinearLayout.LayoutParams(0, -2, 1); l3.leftMargin = dpi(4);
        r.addView(capo, l3);
        col.addView(r, gapBelow(6));
        TextView help = text("Escribe la letra y pon cada acorde entre corchetes justo antes de la sílaba: [Am]Yo te es[F]cribí. "
                + "Secciones: una línea «# Estribillo». Notas de la melodía: una línea que empiece por ♪ (♪ Do Re Mi Fa) y verás las tabs de tu armónica. "
                + "Cualquier otra línea es una nota libre (rasgueo, tablatura…).", 11);
        help.setTextColor(Color.rgb(160, 170, 190));
        col.addView(help, gapBelow(6));
        LinearLayout quick = new LinearLayout(this);
        EditText text = field(null, "Letra con [acordes]…", o.optString("text"), true);
        for (String s : new String[]{"[ ]", "♪ ", "# Estribillo", "# Estrofa", "# Intro", "# Puente"}) {
            TextView t = button(s, v -> {
                int at = Math.max(0, text.getSelectionStart());
                String ins = s.equals("[ ]") ? "[]" : (at > 0 && text.getText().charAt(at - 1) != '\n' ? "\n" : "") + s + (s.startsWith("#") ? "\n" : "");
                text.getText().insert(at, ins);
                if (s.equals("[ ]")) text.setSelection(at + 1);
            });
            t.setTextSize(12);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dpi(4);
            quick.addView(t, lp);
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.addView(quick);
        col.addView(hs, gapBelow(6));
        col.addView(text, gapBelow(8));
        LinearLayout btns = new LinearLayout(this);
        btns.addView(button("💾 GUARDAR", v -> {
            try {
                o.put("title", title.getText().toString().trim());
                o.put("artist", artist.getText().toString().trim());
                o.put("key", key.getText().toString().trim());
                o.put("bpm", parse(bpm.getText().toString()));
                o.put("capo", parse(capo.getText().toString()));
                o.put("text", text.getText().toString());
                if (o.optString("key").isEmpty()) {
                    List<MusicTheory.Chord> cs = MusicTheory.chordsIn(o.optString("text"), MusicTheory.notation(this));
                    if (!cs.isEmpty()) {
                        int[] k = MusicTheory.guessKey(cs);
                        MusicTheory.Chord kc = new MusicTheory.Chord(); kc.root = k[0]; kc.type = k[1] == 1 ? "m" : "";
                        o.put("key", kc.name(this));
                    }
                }
                write(f, o);
                openSong(f);
            } catch (Exception e) { toast(L.t("No se pudo guardar.")); }
        }), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1); cl.leftMargin = dpi(6);
        btns.addView(button("✕ CANCELAR", v -> { if (f.exists()) openSong(f); else showList(); }), cl);
        col.addView(btns);
    }

    static int parse(String s) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; } }

    EditText field(LinearLayout parent, String hint, String val, boolean multi) {
        EditText e = new EditText(this);
        e.setHint(L.t(hint));
        e.setText(val);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setBackground(frame(10));
        e.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        if (multi) { e.setMinLines(12); e.setGravity(Gravity.TOP | Gravity.START); e.setTypeface(Typeface.MONOSPACE); e.setTextSize(14); }
        else e.setSingleLine(true);
        if (parent != null) parent.addView(e, gapBelow(6));
        return e;
    }

    // ================================================================== ver y tocar
    void openSong(File f) {
        songFile = f;
        song = read(f);
        shift = 0;
        simple = false;
        render();
    }

    String notation() { return MusicTheory.notation(this); }

    /** El texto como se ve ahora (transportado / simplificado). */
    String shown() {
        String t = song.optString("text");
        boolean fl = MusicTheory.flats(this);
        return MusicTheory.mapChords(t, notation(), fl, c -> { MusicTheory.Chord x = c.transpose(shift); return simple ? MusicTheory.simplify(x) : x; });
    }

    void render() {
        stopScroll();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dpi(14), dpi(14), dpi(14), dpi(8));
        if (!stage) {
            root.addView(topBar(song.optString("title", L.t("Sin título"))), gapBelow(4));
            String sub = song.optString("artist");
            String key = song.optString("key");
            MusicTheory.Chord kc = MusicTheory.parseChord(key, notation());
            String keyNow = kc == null ? key : kc.transpose(shift).name(this);
            TextView info = text((sub.isEmpty() ? "" : sub + " · ") + (keyNow.isEmpty() ? "" : L.t("Tono") + ": " + keyNow)
                    + (song.optInt("capo") > 0 ? " · " + L.t("cejilla") + " " + song.optInt("capo") : "")
                    + (song.optInt("bpm") > 0 ? " · " + song.optInt("bpm") + " BPM" : "") + (shift != 0 ? "  (" + (shift > 0 ? "+" : "") + shift + ")" : ""), 12);
            info.setTextColor(Color.rgb(170, 180, 200));
            root.addView(info, gapBelow(6));
            // resumen de acordes
            List<MusicTheory.Chord> cs = MusicTheory.chordsIn(shown(), notation());
            LinearLayout chips = new LinearLayout(this);
            java.util.Set<String> known = new java.util.HashSet<>(java.util.Arrays.asList(p.getString("mus_known", "").split(",")));
            for (MusicTheory.Chord c : cs) {
                String n = c.name(this);
                TextView t = button(n, v -> ChordPopup.show(this, c, song.optInt("capo"), this::replaceChord));
                t.setTextSize(13);
                t.setAlpha(known.contains(n) ? 0.4f : 1f);
                t.setOnLongClickListener(v -> {               // «ya me lo sé»
                    java.util.Set<String> k2 = new java.util.HashSet<>(java.util.Arrays.asList(p.getString("mus_known", "").split(",")));
                    if (!k2.remove(n)) k2.add(n);
                    k2.remove("");
                    p.edit().putString("mus_known", android.text.TextUtils.join(",", k2)).apply();
                    toast(k2.contains(n) ? L.t("Marcado como «ya me lo sé».") : L.t("Quitado de «ya me lo sé»."));
                    render();
                    return true;
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dpi(4);
                chips.addView(t, lp);
            }
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            hs.addView(chips);
            root.addView(hs, gapBelow(6));
            // barra de herramientas
            LinearLayout tb = new LinearLayout(this);
            tool(tb, "♭ −½", v -> { shift--; render(); });
            tool(tb, "♯ +½", v -> { shift++; render(); });
            tool(tb, simple ? L.t("Original") : L.t("Simplificada"), v -> { simple = !simple; render(); });
            tool(tb, "🔁 " + L.t("Tabla"), v -> transposeTable());
            tool(tb, "🎚 " + L.t("Cejilla"), v -> capoAdvice());
            tool(tb, autoscroll ? "⏸" : "⏬", v -> { autoscroll = !autoscroll; if (autoscroll) startScroll(); else stopScroll(); render(); });
            tool(tb, "🎤 " + L.t("Escenario"), v -> { stage = true; render(); });
            tool(tb, "🥁", v -> startActivity(new Intent(this, MetronomeActivity.class).putExtra("bpm", song.optInt("bpm", 0))));
            if (song.optString("text").contains("♪")) {
                String tm = p.getString("sb_tab", song.optBoolean("personal") ? "gtr" : "harp");
                tool(tb, tm.equals("harp") ? "🎼 " + L.t("Tab: armónica") : tm.equals("gtr") ? "🎸 " + L.t("Tab: guitarra") : "🎼🎸 " + L.t("Tab: las dos"), v -> {
                    p.edit().putString("sb_tab", tm.equals("harp") ? "gtr" : tm.equals("gtr") ? "both" : "harp").apply(); render();
                });
            }
            tool(tb, "✏", v -> edit(songFile, song));
            tool(tb, "💾 " + L.t("Guardar tono"), v -> saveTransposed());
            HorizontalScrollView th = new HorizontalScrollView(this);
            th.setHorizontalScrollBarEnabled(false);
            th.addView(tb);
            root.addView(th, gapBelow(6));
        }
        viewScroll = new ScrollView(this);
        TextView body = new TextView(this);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextColor(Color.rgb(230, 235, 245));
        body.setTextSize(stage ? 22 : 15);
        body.setText(layout(shown()));
        body.setMovementMethod(LinkMovementMethod.getInstance());
        body.setPadding(0, 0, 0, dpi(200));
        if (stage) body.setOnLongClickListener(v -> { stage = false; render(); return true; });
        viewScroll.addView(body);
        root.addView(viewScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        if (stage) {
            TextView hint = text("Mantén pulsada la letra para salir del modo escenario.", 10);
            hint.setTextColor(Color.rgb(120, 130, 150));
            root.addView(hint);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(makeRoot(root));
        if (autoscroll) startScroll();
    }

    void tool(LinearLayout tb, String label, View.OnClickListener l) {
        TextView t = button(label, l);
        t.setTextSize(12);
        t.setPadding(dpi(10), dpi(9), dpi(10), dpi(9));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dpi(4);
        tb.addView(t, lp);
    }

    /** ChordPro → dos líneas (acordes encima de la sílaba), secciones y tabs de armónica. Acordes tocables. */
    CharSequence layout(String text) {
        SpannableStringBuilder out = new SpannableStringBuilder();
        int neon = Neon.color(this);
        MusicTheory.Harp harp = MusicTheory.harp(this, p.getString("mus_harp", "harp_c"));
        int capo = song.optInt("capo");
        for (String line : text.split("\n", -1)) {
            String tl = line.trim();
            if (tl.startsWith("#") || tl.matches("(?i)^\\{(?:c|comment|soc|start_of_chorus|eoc|end_of_chorus)[^}]*\\}$")) {
                String name = tl.startsWith("#") ? tl.replaceFirst("^#+\\s*", "") : tl.replaceAll("(?i)^\\{(?:c|comment)\\s*:\\s*|\\}$", "").replaceAll("(?i)^\\{(?:soc|start_of_chorus)$", L.t("Estribillo"));
                if (name.matches("(?i)^\\{(?:eoc|end_of_chorus)\\}?$")) continue;
                int s = out.length();
                out.append("\n▌ ").append(name.toUpperCase(java.util.Locale.ROOT)).append("\n");
                out.setSpan(new ForegroundColorSpan(Color.rgb(255, 200, 120)), s, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                out.setSpan(new StyleSpan(Typeface.BOLD), s, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                continue;
            }
            if (tl.startsWith("♪") || tl.toLowerCase(java.util.Locale.ROOT).startsWith("notas:")) {
                String notes = tl.replaceFirst("(?i)^(?:♪|notas:)\\s*", "");
                List<Integer> mel = MusicTheory.parseMelody(notes, notation());
                // transporte también a la melodía
                for (int i = 0; i < mel.size(); i++) mel.set(i, mel.get(i) + shift);
                StringBuilder nl = new StringBuilder("♪ ");
                for (int m : mel) nl.append(MusicTheory.name(this, m)).append(' ');
                out.append(nl.toString().trim()).append('\n');
                // v1.8.2: tablatura de guitarra (tu instrumento de acordes) además de / en vez de la armónica
                String tabMode = p.getString("sb_tab", song.optBoolean("personal") ? "gtr" : "harp");
                int[] strs = ChordPopup.strings(this);
                if (!mel.isEmpty() && strs != null && !tabMode.equals("harp")) {
                    int s0 = out.length();
                    out.append(SongTranscriber.tabText(SongTranscriber.tab(mel, strs, capo), strs, notation(), MusicTheory.flats(this), 10));
                    out.setSpan(new android.text.style.TypefaceSpan("monospace"), s0, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    out.setSpan(new ForegroundColorSpan(Color.rgb(170, 255, 200)), s0, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    out.setSpan(new android.text.style.RelativeSizeSpan(0.85f), s0, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                if (!mel.isEmpty() && !tabMode.equals("gtr")) {
                    MusicTheory.HarpPlan hp = MusicTheory.bestHarp(harp, mel, false);
                    StringBuilder tb = new StringBuilder("🎼 ");
                    for (MusicTheory.HarpNote hn : hp.notes) tb.append(hn == null ? "?" : hn.tab()).append(' ');
                    int s = out.length();
                    out.append(tb.toString().trim()).append(hp.missing > 0 ? "  (" + L.t("? = no está en tu armónica") + ")" : "").append('\n');
                    out.setSpan(new ForegroundColorSpan(Color.rgb(170, 220, 255)), s, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                continue;
            }
            Matcher m = MusicTheory.INLINE.matcher(line);
            if (!m.find()) { out.append(line).append('\n'); continue; }
            m.reset();
            StringBuilder lyric = new StringBuilder(), chords = new StringBuilder();
            List<int[]> spans = new ArrayList<>();      // {inicio, fin} en la línea de acordes
            List<String> names = new ArrayList<>();
            int last = 0;
            while (m.find()) {
                lyric.append(line, last, m.start());
                int col = lyric.length();
                if (chords.length() > col) { int pad = chords.length() - col; for (int i = 0; i < pad; i++) lyric.append(' '); col = lyric.length(); }
                while (chords.length() < col) chords.append(' ');
                spans.add(new int[]{chords.length(), chords.length() + m.group(1).length()});
                names.add(m.group(1));
                chords.append(m.group(1)).append(' ');
                last = m.end();
            }
            lyric.append(line.substring(last));
            int base = out.length();
            out.append(chords.toString().replaceAll("\\s+$", "")).append('\n');
            for (int i = 0; i < spans.size(); i++) {
                MusicTheory.Chord c = MusicTheory.parseChord(names.get(i), notation());
                int a = base + spans.get(i)[0], b = Math.min(out.length() - 1, base + spans.get(i)[1]);
                if (a >= b) continue;
                out.setSpan(new StyleSpan(Typeface.BOLD), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                if (c == null) continue;
                out.setSpan(new ClickableSpan() {
                    @Override public void onClick(View w) { ChordPopup.show(SongbookActivity.this, c, capo, SongbookActivity.this::replaceChord); }
                    @Override public void updateDrawState(TextPaint ds) { ds.setColor(neon); ds.setUnderlineText(false); }
                }, a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if (lyric.toString().trim().length() > 0) out.append(lyric).append('\n');
        }
        return out;
    }

    /** Cambia un acorde por otro en toda la canción (desde «Alternativas»). Guarda la versión original. */
    void replaceChord(MusicTheory.Chord from, MusicTheory.Chord to) {
        try {
            if (!song.has("original")) song.put("original", song.optString("text"));
            // los acordes de la vista están transportados: deshacer el transporte antes de comparar
            MusicTheory.Chord f0 = from.transpose(-shift), t0 = to.transpose(-shift);
            String nt = MusicTheory.mapChords(song.optString("text"), notation(), MusicTheory.flats(this), c -> c.equals(f0) ? t0 : c);
            song.put("text", nt);
            write(songFile, song);
            toast(from.name(this) + " → " + to.name(this) + ". " + L.t("(La versión original queda guardada.)"));
            render();
        } catch (Exception ignored) {}
    }

    void transposeTable() {
        List<MusicTheory.Chord> cs = MusicTheory.chordsIn(song.optString("text"), notation());
        String[] opts = new String[13];
        for (int i = -6; i <= 6; i++) {
            String d = i == 0 ? L.t("Original") : (i > 0 ? "+" : "") + i + " " + L.t("semitonos") + " (" + (Math.abs(i) % 2 == 0 ? Math.abs(i) / 2 + " " + L.t(Math.abs(i) == 2 ? "tono" : "tonos") : (Math.abs(i) == 1 ? "½ " + L.t("tono") : Math.abs(i) / 2 + " ½ " + L.t("tonos"))) + (i > 0 ? " " + L.t("más alto") : i < 0 ? " " + L.t("más bajo") : "") + ")";
            opts[i + 6] = i == 0 ? d : d;
        }
        new android.app.AlertDialog.Builder(this).setTitle(L.t("🔁 Transportar")).setItems(opts, (d, w) -> {
            int n = w - 6;
            StringBuilder sb = new StringBuilder();
            for (MusicTheory.Chord c : cs) sb.append(c.name(this)).append("  →  ").append(c.transpose(n).name(this)).append('\n');
            MusicTheory.Chord kc = MusicTheory.parseChord(song.optString("key"), notation());
            if (kc != null) sb.insert(0, L.t("Tono") + ": " + kc.name(this) + " → " + kc.transpose(n).name(this) + "\n\n");
            int[] st = ChordPopup.strings(this);
            if (n > 0 && st != null) sb.append("\n💡 ").append(L.t("Truco: con la cejilla en el traste")).append(' ').append(n)
                    .append(' ').append(L.t("tocas las mismas posiciones de antes y suena")).append(' ').append(n).append(' ').append(L.t("semitonos más alto."));
            new android.app.AlertDialog.Builder(this).setTitle(opts[w]).setMessage(sb.toString())
                    .setPositiveButton(L.t("✔ Ver así"), (d2, w2) -> { shift = n; render(); }).setNegativeButton(L.t("Cancelar"), null).show();
        }).show();
    }

    void capoAdvice() {
        int[] st = ChordPopup.strings(this);
        if (st == null) { toast(L.t("La cejilla es para instrumentos de cuerda.")); return; }
        List<MusicTheory.Chord> cs = MusicTheory.chordsIn(shown(), notation());
        if (cs.isEmpty()) return;
        toast(L.t("Calculando…"));
        new Thread(() -> {
            int best = MusicTheory.bestCapo(cs, st);
            StringBuilder sb = new StringBuilder();
            if (best == 0) sb.append(L.t("Sin cejilla ya es lo más cómodo para esta canción."));
            else {
                sb.append(L.t("Pon la cejilla en el traste")).append(' ').append(best).append(' ').append(L.t("y toca estas formas:")).append("\n\n");
                for (MusicTheory.Chord c : cs) sb.append(c.name(this)).append("  →  ").append(L.t("forma de")).append(' ').append(c.transpose(-best).name(this)).append('\n');
            }
            int fb = best;
            runOnUiThread(() -> new android.app.AlertDialog.Builder(this).setTitle(L.t("🎚 Cejilla recomendada")).setMessage(sb.toString())
                    .setPositiveButton("OK", null)
                    .setNeutralButton(fb > 0 ? L.t("Ver con cejilla") : null, (d, w) -> {
                        try { song.put("capo", fb); shift -= fb; render(); } catch (Exception ignored) {}
                    }).show());
        }).start();
    }

    void saveTransposed() {
        if (shift == 0 && !simple) { toast(L.t("No hay cambios que guardar.")); return; }
        try {
            if (!song.has("original")) song.put("original", song.optString("text"));
            song.put("text", shown());
            MusicTheory.Chord kc = MusicTheory.parseChord(song.optString("key"), notation());
            if (kc != null) song.put("key", kc.transpose(shift).name(this));
            write(songFile, song);
            shift = 0; simple = false;
            toast(L.t("Guardado en el tono nuevo. (La versión original queda guardada.)"));
            render();
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------------ desplazamiento automático
    final Runnable scroller = new Runnable() {
        public void run() {
            if (!autoscroll || viewScroll == null) return;
            int bpm = song == null ? 0 : song.optInt("bpm");
            float sp = (bpm > 0 ? bpm / 90f : 1f) * scrollSpeed;
            viewScroll.scrollBy(0, Math.max(1, Math.round(dp(1) * sp)));
            h.postDelayed(this, 60);
        }
    };

    void startScroll() { h.removeCallbacks(scroller); h.postDelayed(scroller, 800); }

    void stopScroll() { h.removeCallbacks(scroller); }

    @Override public void onBackPressed() {
        if (stage) { stage = false; render(); return; }
        if (song != null) { autoscroll = false; showList(); return; }
        super.onBackPressed();
    }

    @Override protected void onDestroy() { stopScroll(); super.onDestroy(); }
}
