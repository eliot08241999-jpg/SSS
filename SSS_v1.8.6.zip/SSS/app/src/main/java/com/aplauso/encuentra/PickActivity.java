package com.aplauso.encuentra;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.LruCache;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * v1.8 · Elegir un archivo desde la «🗂 Galería de Chloe Nova» (fotos, vídeos, música y documentos del teléfono,
 * con buscador y los recientes arriba) o desde «📁 Mis archivos» (el selector de Android). Recuerda la elección de cada pantalla.
 */
public class PickActivity extends NeonActivity {
    static final int REQ_SYSTEM = 991;
    int type;
    boolean multi;
    String screen;
    Intent fallback;
    List<Media.Item> all = new ArrayList<>(), shown = new ArrayList<>();
    final LinkedHashSet<Uri> chosen = new LinkedHashSet<>();
    GridView grid;
    TextView useBtn, info;
    final ExecutorService ex = Executors.newFixedThreadPool(3);
    final LruCache<Uri, Bitmap> thumbs = new LruCache<Uri, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(Uri k, Bitmap b) { return b.getByteCount(); }
    };

    // ================================================================== uso desde cualquier pantalla
    /**
     * En vez de startActivityForResult(intentDelSistema, req): pregunta de dónde elegir (o usa lo recordado).
     * El resultado llega igual que antes, en onActivityResult(req…) con getData() / getClipData().
     */
    public static void start(Activity a, Intent system, int req, String screen) {
        int type = typeOf(system);
        if (type < 0) { a.startActivityForResult(system, req); return; }      // otros archivos (.task, .vrm…): selector de Android
        SharedPreferences p = a.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        String src = p.getString("pick_src_" + screen, "");
        if ("app".equals(src)) { launchApp(a, system, req, screen, type); return; }
        if ("sys".equals(src)) { a.startActivityForResult(system, req); return; }
        String[] opts = {L.t("🗂 Galería de Chloe Nova"), L.t("📁 Mis archivos")};
        android.widget.CheckBox remember = new android.widget.CheckBox(a);
        remember.setText(L.t("Recordar para esta pantalla"));
        remember.setTextColor(Color.WHITE);
        LinearLayout box = new LinearLayout(a);
        box.setPadding(Math.round(20 * a.getResources().getDisplayMetrics().density), 0, 0, 0);
        box.addView(remember);
        new android.app.AlertDialog.Builder(a).setTitle(L.t("¿Desde dónde?")).setView(box).setItems(opts, (d, w) -> {
            if (remember.isChecked()) p.edit().putString("pick_src_" + screen, w == 0 ? "app" : "sys").apply();
            if (w == 0) launchApp(a, system, req, screen, type); else a.startActivityForResult(system, req);
        }).show();
    }

    static void launchApp(Activity a, Intent system, int req, String screen, int type) {
        a.startActivityForResult(new Intent(a, PickActivity.class).putExtra("type", type).putExtra("screen", screen)
                .putExtra("multi", system.getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)).putExtra("fallback", system), req);
    }

    /** Tipo de lo que se pide: foto, vídeo, audio, documento o −1 (otra cosa). */
    static int typeOf(Intent i) {
        String t = i.getType() == null ? "" : i.getType();
        String[] mimes = i.getStringArrayExtra(Intent.EXTRA_MIME_TYPES);
        if (mimes != null && mimes.length > 0) {
            boolean doc = true;
            for (String m : mimes) if (m.startsWith("image/") || m.startsWith("video/") || m.startsWith("audio/")) doc = false;
            if (doc) return Media.TYPE_DOC;
            t = mimes[0];
        }
        if (t.startsWith("image/")) return Media.TYPE_IMAGE;
        if (t.startsWith("video/")) return Media.TYPE_VIDEO;
        if (t.startsWith("audio/")) return Media.TYPE_AUDIO;
        return -1;
    }

    // ================================================================== la pantalla
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        type = getIntent().getIntExtra("type", Media.TYPE_IMAGE);
        multi = getIntent().getBooleanExtra("multi", false);
        screen = getIntent().getStringExtra("screen");
        fallback = getIntent().getParcelableExtra("fallback");
        String[] titles = {"🖼 FOTOS", "🎞 VÍDEOS", "🎵 MÚSICA", "📄 DOCUMENTOS"};
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dpi(12), dpi(14), dpi(12), dpi(8));
        root.addView(topBar(L.t("🗂 GALERÍA") + " · " + L.t(titles[type])), gapBelow(6));
        LinearLayout tools = new LinearLayout(this);
        TextView sys = button("📁 MIS ARCHIVOS", v -> { if (fallback != null) startActivityForResult(fallback, REQ_SYSTEM); });
        sys.setTextSize(12);
        tools.addView(sys, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ch = button("⚙ " + L.t("CAMBIAR"), v -> changeDefault());
        ch.setTextSize(12);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1); cl.leftMargin = dpi(6);
        tools.addView(ch, cl);
        root.addView(tools, gapBelow(6));
        EditText search = new EditText(this);
        search.setHint(L.t("🔍 Buscar por nombre"));
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.GRAY);
        search.setSingleLine(true);
        search.setBackground(frame(10));
        search.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {}
            public void onTextChanged(CharSequence s, int a, int b2, int c) {}
            public void afterTextChanged(android.text.Editable e) { filter(e.toString()); }
        });
        root.addView(search, gapBelow(6));
        info = text("", 12);
        info.setTextColor(Color.rgb(170, 180, 200));
        root.addView(info);
        grid = new GridView(this);
        boolean visual = type == Media.TYPE_IMAGE || type == Media.TYPE_VIDEO;
        grid.setNumColumns(visual ? 3 : 1);
        grid.setHorizontalSpacing(dpi(4));
        grid.setVerticalSpacing(dpi(4));
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((pa, v, pos, id) -> tap(shown.get(pos).uri));
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        useBtn = button("", v -> finishWith(new ArrayList<>(chosen)));
        useBtn.setVisibility(View.GONE);
        root.addView(useBtn);
        setContentView(makeRoot(root));
        load();
    }

    void load() {
        if (type != Media.TYPE_DOC && Media.access(this, type) == Media.ACCESS_NONE) { Media.request(this, 77); info.setText(L.t("Esperando permiso…")); return; }
        info.setText(L.t("Cargando…"));
        ex.execute(() -> {
            List<Media.Item> l = type == Media.TYPE_DOC ? Media.scanDocs(2000) : Media.query(this, type, null, null, 0);
            // recientes de esta pantalla, arriba
            List<Media.Item> rec = new ArrayList<>();
            for (String s : getSharedPreferences("cfg", MODE_PRIVATE).getString("pick_recent_" + screen, "").split("\n")) {
                if (s.isEmpty()) continue;
                for (Media.Item it : l) if (it.uri.toString().equals(s)) { rec.add(it); break; }
            }
            List<Media.Item> out = new ArrayList<>(rec);
            for (Media.Item it : l) if (!rec.contains(it)) out.add(it);
            int nRec = rec.size();
            runOnUiThread(() -> {
                all = out;
                filter("");
                info.setText(all.isEmpty() ? L.t(type == Media.TYPE_DOC && !Media.allFiles(this) ? "Para ver aquí tus documentos, Android pide el permiso de «Acceso a todos los archivos» (Gestor de archivos). Mientras, usa 📁 MIS ARCHIVOS." : "No encuentro nada aquí. Prueba con 📁 MIS ARCHIVOS.")
                        : all.size() + " · " + (nRec > 0 ? "⭐ " + nRec + " " + L.t("recientes arriba") + " · " : "") + (multi ? L.t("toca para elegir varios") : L.t("toca para elegir")));
            });
        });
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r, p, g); load(); }

    void filter(String q) {
        String n = Actions.norm(q);
        shown = new ArrayList<>();
        for (Media.Item it : all) if (n.isEmpty() || Actions.norm(it.name == null ? "" : it.name).contains(n)) shown.add(it);
        adapter.notifyDataSetChanged();
    }

    void tap(Uri u) {
        if (!multi) { List<Uri> l = new ArrayList<>(); l.add(u); finishWith(l); return; }
        if (!chosen.remove(u)) chosen.add(u);
        useBtn.setVisibility(chosen.isEmpty() ? View.GONE : View.VISIBLE);
        useBtn.setText("✔ " + L.t("USAR") + " (" + chosen.size() + ")");
        adapter.notifyDataSetChanged();
    }

    void finishWith(List<Uri> l) {
        if (l.isEmpty()) return;
        // recientes
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        LinkedHashSet<String> rec = new LinkedHashSet<>();
        for (Uri u : l) rec.add(u.toString());
        for (String s : p.getString("pick_recent_" + screen, "").split("\n")) if (!s.isEmpty()) rec.add(s);
        List<String> r = new ArrayList<>(rec);
        p.edit().putString("pick_recent_" + screen, android.text.TextUtils.join("\n", r.subList(0, Math.min(8, r.size())))).apply();
        Intent out = new Intent().setData(l.get(0)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (l.size() > 1 || multi) {
            ClipData cd = ClipData.newRawUri("", l.get(0));
            for (int i = 1; i < l.size(); i++) cd.addItem(new ClipData.Item(l.get(i)));
            out.setClipData(cd);
        }
        setResult(RESULT_OK, out);
        finish();
    }

    void changeDefault() {
        String[] o = {L.t("Preguntar siempre"), L.t("Siempre la galería de Chloe Nova"), L.t("Siempre Mis archivos")};
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Al elegir archivos en esta pantalla…")).setItems(o, (d, w) -> {
            getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("pick_src_" + screen, w == 0 ? "" : w == 1 ? "app" : "sys").apply();
            toast(L.t("Hecho."));
        }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_SYSTEM) { if (res == RESULT_OK && data != null) { setResult(RESULT_OK, data); finish(); } return; }
        super.onActivityResult(req, res, data);
    }

    @Override protected void onDestroy() { ex.shutdownNow(); super.onDestroy(); }

    // ================================================================== lista
    final BaseAdapter adapter = new BaseAdapter() {
        public int getCount() { return shown.size(); }
        public Object getItem(int i) { return shown.get(i); }
        public long getItemId(int i) { return i; }

        public View getView(int pos, View cv, ViewGroup parent) {
            Media.Item it = shown.get(pos);
            boolean visual = type == Media.TYPE_IMAGE || type == Media.TYPE_VIDEO;
            boolean sel = chosen.contains(it.uri);
            if (visual) {
                android.widget.FrameLayout f = cv instanceof android.widget.FrameLayout ? (android.widget.FrameLayout) cv : new android.widget.FrameLayout(PickActivity.this);
                ImageView iv;
                TextView tag;
                if (f.getChildCount() == 0) {
                    iv = new ImageView(PickActivity.this);
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    f.addView(iv, new android.widget.FrameLayout.LayoutParams(-1, -1));
                    tag = new TextView(PickActivity.this);
                    tag.setTextColor(Color.WHITE);
                    tag.setTextSize(11);
                    tag.setShadowLayer(3, 0, 0, Color.BLACK);
                    f.addView(tag, new android.widget.FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END));
                } else { iv = (ImageView) f.getChildAt(0); tag = (TextView) f.getChildAt(1); }
                int side = (parent.getWidth() - dpi(8)) / 3;
                f.setLayoutParams(new android.widget.AbsListView.LayoutParams(-1, Math.max(dpi(90), side)));
                iv.setTag(it.uri);
                Bitmap bm = thumbs.get(it.uri);
                iv.setImageBitmap(bm);
                if (bm == null) ex.execute(() -> {
                    Bitmap t = thumb(it.uri);
                    if (t == null) return;
                    thumbs.put(it.uri, t);
                    runOnUiThread(() -> { if (it.uri.equals(iv.getTag())) iv.setImageBitmap(t); });
                });
                tag.setText((sel ? "✔ " : "") + (it.durationMs > 0 ? NeonProgress.dur(it.durationMs / 1000) + " " : ""));
                f.setForeground(sel ? new android.graphics.drawable.ColorDrawable(Color.argb(90, 0, 229, 255)) : null);
                return f;
            }
            TextView t = cv instanceof TextView ? (TextView) cv : new TextView(PickActivity.this);
            t.setTextColor(Color.WHITE);
            t.setTextSize(14);
            t.setPadding(dpi(10), dpi(10), dpi(10), dpi(10));
            t.setBackground(frame(10));
            String ic = type == Media.TYPE_AUDIO ? "🎵 " : "📄 ";
            t.setText((sel ? "✔ " : ic) + it.name + "\n" + String.format(java.util.Locale.ROOT, "%.1f MB", it.size / 1048576f)
                    + (it.durationMs > 0 ? " · " + NeonProgress.dur(it.durationMs / 1000) : ""));
            return t;
        }
    };

    Bitmap thumb(Uri u) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) return getContentResolver().loadThumbnail(u, new Size(256, 256), null);
            long id = android.content.ContentUris.parseId(u);
            if (type == Media.TYPE_VIDEO) return android.provider.MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), id, android.provider.MediaStore.Video.Thumbnails.MINI_KIND, null);
            return android.provider.MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), id, android.provider.MediaStore.Images.Thumbnails.MINI_KIND, null);
        } catch (Exception e) { return null; }
    }
}
