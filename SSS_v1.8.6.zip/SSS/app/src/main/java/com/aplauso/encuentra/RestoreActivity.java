package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/**
 * v1.8.2 · 📷 RESTAURAR FOTOS ANTIGUAS: quita rayas y manchas (automático + pincel, con LaMa), mejora las caras (GFPGAN,
 * con fidelidad), colorea las de blanco y negro (DDColor, con intensidad), contraste y ruido, y amplía ×2/×4.
 * Antes / después con barra. Todo dentro del teléfono (los modelos se bajan la primera vez).
 */
public class RestoreActivity extends NeonActivity {
    static final int REQ = 61;
    final Handler h = new Handler(Looper.getMainLooper());
    CompareView cmp;
    Bitmap src, result;
    String name = "foto";
    Switch swScr, swFace, swColor, swFix;
    SeekBar fidelity, intensity, sens;
    TextView upBtn, brushBtn, info;
    int up;                         // 0 no · 1 ×2 · 2 ×4
    NeonProgress prog;
    volatile boolean busy, cancel;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("📷 RESTAURAR FOTOS");
        LinearLayout a = panel(null);
        cmp = new CompareView(this);
        a.addView(cmp, new LinearLayout.LayoutParams(-1, dpi(330)));
        info = text("Elige una foto antigua. Arrastra la barra para comparar el antes y el después.", 12);
        a.addView(info);
        LinearLayout r = new LinearLayout(this);
        r.addView(button("🖼 ELEGIR FOTO", v -> PickActivity.start(this, new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ, "restore")), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.leftMargin = dpi(6);
        r.addView(button("💾 GUARDAR", v -> save()), lp);
        a.addView(r);
        col.addView(a, gapBelow(12));

        LinearLayout o = panel("◢ QUÉ ARREGLAR");
        swScr = neonSwitch("🩹 Quitar rayas, manchas y dobleces");
        swScr.setChecked(true);
        o.addView(swScr);
        sens = slider(o, "Sensibilidad de la detección automática", 50);
        brushBtn = button("", v -> { cmp.brush = !cmp.brush; cmp.erase = false; refresh(); });
        o.addView(brushBtn, gapBelow(4));
        LinearLayout br = new LinearLayout(this);
        br.addView(button("🔍 DETECTAR", v -> detect()), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1); l2.leftMargin = dpi(6);
        br.addView(button("🧽 BORRADOR", v -> { cmp.brush = true; cmp.erase = !cmp.erase; refresh(); }), l2);
        LinearLayout.LayoutParams l3 = new LinearLayout.LayoutParams(0, -2, 1); l3.leftMargin = dpi(6);
        br.addView(button("✕ LIMPIAR", v -> { if (src != null) cmp.setMask(new boolean[src.getWidth() * src.getHeight()]); }), l3);
        o.addView(br, gapBelow(8));
        swFace = neonSwitch("🙂 Mejorar las caras");
        swFace.setChecked(true);
        o.addView(swFace);
        fidelity = slider(o, "Cuánto se nota la IA en las caras (izquierda = más fiel a la foto)", 70);
        swColor = neonSwitch("🎨 Colorear (fotos en blanco y negro)");
        o.addView(swColor);
        intensity = slider(o, "Intensidad del color", 85);
        swFix = neonSwitch("✨ Contraste automático y menos ruido");
        swFix.setChecked(true);
        o.addView(swFix);
        upBtn = button("", v -> { up = (up + 1) % 3; refresh(); });
        o.addView(upBtn, gapBelow(6));
        TextView sz = text("La primera vez se descarga cada IA: rayas ≈208 MB · caras ≈340 MB · color ≈130 MB. Después funciona sin internet.", 11);
        sz.setTextColor(Color.rgb(160, 170, 190));
        o.addView(sz);
        col.addView(o, gapBelow(12));

        LinearLayout g = panel("◢ RESTAURAR");
        g.addView(button("▶ RESTAURAR", v -> run()), gapBelow(6));
        prog = new NeonProgress(this);
        g.addView(prog, gapBelow(6));
        g.addView(button("✕ CANCELAR", v -> { cancel = true; FastDownload.cancel = true; }));
        col.addView(g, gapBelow(12));
        refresh();
        if (getIntent().getData() != null) open(getIntent().getData());
    }

    SeekBar slider(LinearLayout parent, String label, int v) {
        TextView t = text(label, 11);
        t.setTextColor(Color.rgb(170, 180, 200));
        parent.addView(t);
        SeekBar s = new SeekBar(this);
        s.setMax(100); s.setProgress(v);
        parent.addView(s, gapBelow(4));
        return s;
    }

    void refresh() {
        brushBtn.setText(cmp.brush ? (cmp.erase ? L.t("🧽 Borrando la marca (toca ✏ para volver)") : L.t("✏ Pintando: marca las rayas con el dedo (toca para terminar)")) : L.t("✏ MARCAR A MANO LO QUE HAY QUE BORRAR"));
        upBtn.setText(L.t("🔍 Ampliar: ") + (up == 0 ? L.t("no") : up == 1 ? "×2" : "×4"));
        cmp.invalidate();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req == REQ && res == RESULT_OK && d != null && d.getData() != null) open(d.getData());
    }

    void open(Uri u) {
        Bitmap b = PhotoTools.load(this, u, 2400);
        if (b == null) { toast(L.t("No puedo abrir esa foto.")); return; }
        src = b.copy(Bitmap.Config.ARGB_8888, false);
        result = null;
        name = Media.nameOf(this, u).replaceAll("\\.[A-Za-z0-9]{2,4}$", "");
        cmp.mask = null;
        cmp.set(src, null);
        cmp.brushPx = Math.max(6, Math.max(src.getWidth(), src.getHeight()) / 160f);
        info.setText(src.getWidth() + " × " + src.getHeight() + " px");
        if (looksGray(src)) { swColor.setChecked(true); toast(L.t("Parece en blanco y negro: activo «Colorear».")); }
    }

    static boolean looksGray(Bitmap b) {
        Bitmap s = Bitmap.createScaledBitmap(b, 64, 64, true);
        long sat = 0;
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) { int p = s.getPixel(x, y); int r = (p >> 16) & 255, g = (p >> 8) & 255, bb = p & 255; sat += Math.max(r, Math.max(g, bb)) - Math.min(r, Math.min(g, bb)); }
        return sat / 4096f < 14;
    }

    void detect() {
        if (src == null || busy) return;
        busy = true;
        prog.begin(); prog.phase(L.t("Buscando rayas y manchas…"));
        float s = sens.getProgress() / 100f;
        new Thread(() -> {
            boolean[] m = ImgAI.autoScratches(src, s);
            h.post(() -> {
                busy = false; prog.hide();
                if (cmp.mask != null) for (int i = 0; i < m.length; i++) m[i] |= cmp.mask[i];
                cmp.setMask(m);
                int n = 0; for (boolean x : m) if (x) n++;
                toast(n == 0 ? L.t("No he visto rayas: márcalas con el pincel si las hay.") : L.t("Marcado en rojo. Corrige con el pincel o el borrador."));
            });
        }).start();
    }

    void run() {
        if (src == null) { toast(L.t("Primero elige una foto.")); return; }
        if (busy) return;
        busy = true; cancel = false;
        cmp.brush = false; refresh();
        prog.begin();
        final boolean doScr = swScr.isChecked(), doFace = swFace.isChecked(), doColor = swColor.isChecked(), doFix = swFix.isChecked();
        final float fid = fidelity.getProgress() / 100f, inten = intensity.getProgress() / 100f;
        final int upscale = up;
        final boolean[] mask0 = cmp.mask == null ? null : cmp.mask.clone();
        ImgAI.Prog pg = new ImgAI.Prog() {
            public void on(String w, int d, int t) { h.post(() -> { if (t > 1) prog.set(w, d, t); else prog.phase(w + "…"); }); }
            public boolean cancelled() { return cancel; }
        };
        new Thread(() -> {
            try {
                Bitmap b = src;
                if (doScr) {
                    boolean[] m = mask0;
                    boolean any = false; if (m != null) for (boolean x : m) if (x) { any = true; break; }
                    if (!any) { pg.on(L.t("Buscando rayas y manchas"), 0, 1); m = ImgAI.autoScratches(b, sens.getProgress() / 100f); any = false; for (boolean x : m) if (x) { any = true; break; } }
                    if (any) b = ImgAI.inpaint(this, b, m, pg);
                }
                if (cancel) throw new InterruptedException();
                if (doFix) { pg.on(L.t("Contraste y ruido"), 0, 1); b = ImgAI.autoFix(b); }
                if (doColor) b = ImgAI.colorize(this, b, inten, pg);
                if (cancel) throw new InterruptedException();
                if (doFace) { Bitmap f = ImgAI.faces(this, b, fid, pg); if (f != null) b = f; else h.post(() -> toast(L.t("No he encontrado caras de frente."))); }
                if (cancel) throw new InterruptedException();
                ImgAI.close();
                if (upscale > 0) {
                    pg.on(L.t("Ampliando"), 0, 1);
                    int k = upscale == 1 ? 2 : 4;
                    Bitmap in = b;
                    long maxPx = 16_000_000L;                         // que no se pase de memoria
                    while ((long) in.getWidth() * in.getHeight() * k * k > maxPx) in = Bitmap.createScaledBitmap(in, in.getWidth() * 3 / 4, in.getHeight() * 3 / 4, true);
                    b = VideoSR.upscaleBitmap(this, in, in.getWidth() * k, in.getHeight() * k, 1);
                }
                final Bitmap fb = b;
                h.post(() -> { busy = false; prog.hide(); result = fb; cmp.set(src, fb); cmp.split = 0.5f; toast(L.t("¡Listo! Arrastra la barra para comparar.")); Achievements.used(this, "RestoreActivity"); });
            } catch (InterruptedException e) {
                h.post(() -> { busy = false; prog.hide(); toast(L.t("Cancelado.")); });
            } catch (Throwable e) {
                h.post(() -> { busy = false; prog.hide(); toast(L.t("No se pudo restaurar") + ": " + e.getMessage()); });
            }
        }).start();
    }

    void save() {
        if (result == null) { toast(L.t("Primero restaura la foto.")); return; }
        new Thread(() -> {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            result.compress(Bitmap.CompressFormat.JPEG, 95, bo);
            Uri u = Media.saveBytes(this, bo.toByteArray(), "Restauradas", name + "_restaurada.jpg", "image/jpeg");
            h.post(() -> toast(u != null ? L.t("Guardada en SSS+/Restauradas.") : L.t("No se pudo guardar.")));
        }).start();
    }

    @Override protected void onDestroy() { cancel = true; super.onDestroy(); }
}
