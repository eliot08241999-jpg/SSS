package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * v1.8.2 · 🏆 LOGROS. Dos series de cinco trofeos (de bronce a diamante, cada uno con más brillo):
 *  · Toques (acumulados): 100, 500, 1000, 2500, 5000.
 *  · Aventura: usar al menos 5 veces cada función de la app (20 %, 40 %, 60 %, 80 %, 100 %).
 * Los nombres están en español, inglés e italiano; el progreso se guarda por identificador (no cambia con el idioma).
 */
public class Achievements {
    public static final class Def {
        public final String id; public final int series, tier, need; final String[] names, descs;
        Def(String id, int series, int tier, int need, String[] n, String[] d) { this.id = id; this.series = series; this.tier = tier; this.need = need; names = n; descs = d; }
        public String name() { return names["en".equals(L.lang) ? 1 : "it".equals(L.lang) ? 2 : 0]; }
        public String desc() { return descs["en".equals(L.lang) ? 1 : "it".equals(L.lang) ? 2 : 0]; }
    }

    static String[] d(String es, String en, String it) { return new String[]{es, en, it}; }

    public static final Def[] ALL = {
            new Def("t100", 0, 1, 100, d("🥉 Manos inquietas", "🥉 Restless Hands", "🥉 Mani irrequiete"),
                    d("Toca a Chloe 100 veces.", "Poke Chloe 100 times.", "Tocca Chloe 100 volte.")),
            new Def("t500", 0, 2, 500, d("🥈 Búscate un trabajo", "🥈 Get a Job", "🥈 Trovati un lavoro"),
                    d("Toca a Chloe 500 veces.", "Poke Chloe 500 times.", "Tocca Chloe 500 volte.")),
            new Def("t1000", 0, 3, 1000, d("🥇 Muy mala influencia", "🥇 Bad Influence", "🥇 Pessima influenza"),
                    d("Toca a Chloe 1000 veces.", "Poke Chloe 1000 times.", "Tocca Chloe 1000 volte.")),
            new Def("t2500", 0, 4, 2500, d("🏆 Adicto a manosear", "🏆 Addicted to Poking", "🏆 Dipendente dalle carezze"),
                    d("Toca a Chloe 2500 veces.", "Poke Chloe 2500 times.", "Tocca Chloe 2500 volte.")),
            new Def("t5000", 0, 5, 5000, d("💎 Manoseador supremo", "💎 Supreme Poker", "💎 Palpatore supremo"),
                    d("Toca a Chloe 5000 veces.", "Poke Chloe 5000 times.", "Tocca Chloe 5000 volte.")),
            new Def("a20", 1, 1, 20, d("🗺 El inicio de la aventura", "🗺 The Adventure Begins", "🗺 L'inizio dell'avventura"),
                    d("Usa el 20 % de las funciones (5 veces cada una).", "Use 20% of the features (5 times each).", "Usa il 20% delle funzioni (5 volte ciascuna).")),
            new Def("a40", 1, 2, 40, d("👑 El rey en busca de su corona", "👑 The King Seeks His Crown", "👑 Il re in cerca della sua corona"),
                    d("Usa el 40 % de las funciones (5 veces cada una).", "Use 40% of the features (5 times each).", "Usa il 40% delle funzioni (5 volte ciascuna).")),
            new Def("a60", 1, 3, 60, d("✨ Leyenda naciente", "✨ Rising Legend", "✨ Leggenda nascente"),
                    d("Usa el 60 % de las funciones (5 veces cada una).", "Use 60% of the features (5 times each).", "Usa il 60% delle funzioni (5 volte ciascuna).")),
            new Def("a80", 1, 4, 80, d("🛡 Héroe veterano", "🛡 Veteran Hero", "🛡 Eroe veterano"),
                    d("Usa el 80 % de las funciones (5 veces cada una).", "Use 80% of the features (5 times each).", "Usa l'80% delle funzioni (5 volte ciascuna).")),
            new Def("a100", 1, 5, 100, d("💥 All for one!", "💥 All for one!", "💥 All for one!"),
                    d("Usa TODAS las funciones (5 veces cada una).", "Use EVERY feature (5 times each).", "Usa TUTTE le funzioni (5 volte ciascuna).")),
    };

    public static final int NEED_USES = 5;
    public interface Listener { void unlocked(Def d); }
    public static final List<Listener> listeners = new ArrayList<>();
    static final Handler main = new Handler(Looper.getMainLooper());

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    public static Set<String> done(Context c) { return new HashSet<>(prefs(c).getStringSet("ach_done", new HashSet<>())); }
    public static boolean has(Context c, String id) { return done(c).contains(id); }
    public static Def def(String id) { for (Def x : ALL) if (x.id.equals(id)) return x; return null; }

    static void unlock(Context c, Def x) {
        Set<String> s = done(c);
        if (!s.add(x.id)) return;
        prefs(c).edit().putStringSet("ach_done", s).putLong("ach_at_" + x.id, System.currentTimeMillis()).putString("ach_new", x.id).apply();
        Rpg.addExp(c, 50 * x.tier);
        main.post(() -> {
            if (listeners.isEmpty()) android.widget.Toast.makeText(c.getApplicationContext(), "🏆 " + L.t("¡Logro desbloqueado!") + "  " + x.name(), android.widget.Toast.LENGTH_LONG).show();
            for (Listener l : new ArrayList<>(listeners)) l.unlocked(x);
        });
    }

    // ---------------- toques
    static void touched(Context c, int count) {
        Rpg.addExp(c, 1);
        for (Def x : ALL) if (x.series == 0 && count >= x.need) unlock(c, x);
    }

    static void collected(Context c, int n) { Rpg.addExp(c, 10); }

    // ---------------- funciones: cuáles cuentan (las de la guía de la app con pantalla propia)
    public static List<Object[]> features() {
        List<Object[]> l = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Object[] f : AppGuide.F) {
            if (f.length < 5 || !(f[4] instanceof Class)) continue;
            String k = ((Class<?>) f[4]).getSimpleName();
            if (seen.add(k)) l.add(new Object[]{f[0], k, f[4]});
        }
        return l;
    }

    static long lastUse; static String lastKey = "";

    /** Se ha abierto una pantalla (NeonActivity) o usado una función: cuenta una vez cada 20 s como mucho. */
    static void used(Context c, String key) {
        long now = System.currentTimeMillis();
        if (key.equals(lastKey) && now - lastUse < 20_000) return;
        lastKey = key; lastUse = now;
        SharedPreferences p = prefs(c);
        p.edit().putInt("use_" + key, p.getInt("use_" + key, 0) + 1).apply();
        Rpg.addExp(c, 3);
        int pct = adventure(c);
        for (Def x : ALL) if (x.series == 1 && pct >= x.need) unlock(c, x);
    }

    static void usedActivity(Context c, Class<?> k) {
        for (Object[] f : features()) if (f[1].equals(k.getSimpleName())) { used(c, k.getSimpleName()); return; }
    }

    public static int uses(Context c, String key) { return prefs(c).getInt("use_" + key, 0); }

    /** % de funciones usadas al menos 5 veces. */
    public static int adventure(Context c) {
        List<Object[]> f = features();
        if (f.isEmpty()) return 0;
        int ok = 0;
        for (Object[] x : f) if (uses(c, (String) x[1]) >= NEED_USES) ok++;
        return (int) Math.floor(100.0 * ok / f.size());
    }

    /** Las que faltan: {nombre visible, clave, clase, usos}. */
    public static List<Object[]> missing(Context c) {
        List<Object[]> l = new ArrayList<>();
        for (Object[] x : features()) { int u = uses(c, (String) x[1]); if (u < NEED_USES) l.add(new Object[]{x[0], x[1], x[2], u}); }
        return l;
    }

    public static int touches(Context c) { return prefs(c).getInt("tl_count", 0); }

    /** Progreso hacia un logro: {actual, necesario}. */
    public static int[] progress(Context c, Def x) {
        return x.series == 0 ? new int[]{Math.min(touches(c), x.need), x.need} : new int[]{Math.min(adventure(c), x.need), x.need};
    }
}
