package com.aplauso.encuentra;

import android.graphics.Bitmap;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * v1.8 · Codificador de GIF animado propio (GIF89a + LZW), sin librerías: paleta de 256 colores por fotograma
 * (corte por la mediana) con difuminado Floyd–Steinberg suave, bucle infinito y transparencia opcional.
 */
public final class GifEncoder {
    private final OutputStream out;
    private final int w, h;
    private boolean started;
    public boolean transparent;          // los píxeles con alfa < 128 se vuelven transparentes
    public boolean dither = true;

    public GifEncoder(OutputStream out, int w, int h) { this.out = out; this.w = w; this.h = h; }

    public void addFrame(Bitmap bmp, int delayMs) throws IOException {
        if (bmp.getWidth() != w || bmp.getHeight() != h) bmp = Bitmap.createScaledBitmap(bmp, w, h, true);
        int[] px = new int[w * h];
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        addPixels(px, delayMs);
    }

    public void addPixels(int[] px, int delayMs) throws IOException {
        if (!started) { header(); started = true; }
        int[] pal = palette(px, transparent ? 255 : 256);
        byte[] idx = index(px, pal);
        // control gráfico
        out.write(0x21); out.write(0xF9); out.write(4);
        out.write((transparent ? 1 : 0) | (2 << 2));          // disposición: restaurar al fondo
        int d = Math.max(2, Math.round(delayMs / 10f));
        out.write(d & 0xFF); out.write((d >> 8) & 0xFF);
        out.write(transparent ? 255 : 0);
        out.write(0);
        // descriptor de imagen con paleta local de 256
        out.write(0x2C);
        short16(0); short16(0); short16(w); short16(h);
        out.write(0x80 | 7);
        for (int i = 0; i < 256; i++) {
            int c = i < pal.length ? pal[i] : 0;
            out.write((c >> 16) & 0xFF); out.write((c >> 8) & 0xFF); out.write(c & 0xFF);
        }
        lzw(idx);
    }

    public void finish() throws IOException { if (started) out.write(0x3B); out.flush(); }

    void header() throws IOException {
        out.write("GIF89a".getBytes("US-ASCII"));
        short16(w); short16(h);
        out.write(0x70); out.write(0); out.write(0);          // sin paleta global
        // bucle infinito (NETSCAPE2.0)
        out.write(0x21); out.write(0xFF); out.write(11);
        out.write("NETSCAPE2.0".getBytes("US-ASCII"));
        out.write(3); out.write(1); short16(0); out.write(0);
    }

    void short16(int v) throws IOException { out.write(v & 0xFF); out.write((v >> 8) & 0xFF); }

    // ------------------------------------------------------------------ paleta (corte por la mediana)
    static int[] palette(int[] px, int max) {
        int step = Math.max(1, px.length / 40000);
        List<int[]> boxes = new ArrayList<>();
        int n = 0;
        int[] sample = new int[px.length / step + 1];
        for (int i = 0; i < px.length; i += step) if ((px[i] >>> 24) >= 128) sample[n++] = px[i] & 0xFFFFFF;
        if (n == 0) return new int[]{0};
        boxes.add(Arrays.copyOf(sample, n));
        while (boxes.size() < max) {
            int bi = -1, bestRange = -1, bestCh = 0;
            for (int i = 0; i < boxes.size(); i++) {
                int[] b = boxes.get(i);
                if (b.length < 2) continue;
                for (int ch = 0; ch < 3; ch++) {
                    int mn = 255, mx = 0, sh = 16 - ch * 8;
                    for (int c : b) { int v = (c >> sh) & 0xFF; if (v < mn) mn = v; if (v > mx) mx = v; }
                    if (mx - mn > bestRange) { bestRange = mx - mn; bi = i; bestCh = ch; }
                }
            }
            if (bi < 0 || bestRange <= 0) break;
            int[] b = boxes.remove(bi);
            final int sh = 16 - bestCh * 8;
            Integer[] boxed = new Integer[b.length];
            for (int i = 0; i < b.length; i++) boxed[i] = b[i];
            Arrays.sort(boxed, (x, y) -> ((x >> sh) & 0xFF) - ((y >> sh) & 0xFF));
            int mid = b.length / 2;
            int[] l = new int[mid], r = new int[b.length - mid];
            for (int i = 0; i < b.length; i++) if (i < mid) l[i] = boxed[i]; else r[i - mid] = boxed[i];
            boxes.add(l); boxes.add(r);
        }
        int[] pal = new int[boxes.size()];
        for (int i = 0; i < pal.length; i++) {
            long rs = 0, gs = 0, bs = 0;
            int[] b = boxes.get(i);
            for (int c : b) { rs += (c >> 16) & 0xFF; gs += (c >> 8) & 0xFF; bs += c & 0xFF; }
            int k = Math.max(1, b.length);
            pal[i] = (int) (rs / k) << 16 | (int) (gs / k) << 8 | (int) (bs / k);
        }
        return pal;
    }

    byte[] index(int[] px, int[] pal) {
        byte[] o = new byte[px.length];
        int[] cache = new int[32768];
        Arrays.fill(cache, -1);
        float[] er = new float[(w + 2) * 2], eg = new float[(w + 2) * 2], eb = new float[(w + 2) * 2];
        for (int y = 0; y < h; y++) {
            int cur = (y & 1) * (w + 2), nxt = ((y + 1) & 1) * (w + 2);
            Arrays.fill(er, nxt, nxt + w + 2, 0); Arrays.fill(eg, nxt, nxt + w + 2, 0); Arrays.fill(eb, nxt, nxt + w + 2, 0);
            for (int x = 0; x < w; x++) {
                int p = px[y * w + x];
                if (transparent && (p >>> 24) < 128) { o[y * w + x] = (byte) 255; continue; }
                int r = (p >> 16) & 0xFF, g = (p >> 8) & 0xFF, b = p & 0xFF;
                if (dither) {
                    r = clamp(r + Math.round(er[cur + x + 1])); g = clamp(g + Math.round(eg[cur + x + 1])); b = clamp(b + Math.round(eb[cur + x + 1]));
                }
                int key = (r >> 3) << 10 | (g >> 3) << 5 | (b >> 3);
                int best = cache[key];
                if (best < 0) {
                    int bd = Integer.MAX_VALUE;
                    for (int i = 0; i < pal.length; i++) {
                        int c = pal[i], dr = ((c >> 16) & 0xFF) - r, dg = ((c >> 8) & 0xFF) - g, db = (c & 0xFF) - b;
                        int dd = dr * dr * 3 + dg * dg * 4 + db * db * 2;
                        if (dd < bd) { bd = dd; best = i; }
                    }
                    cache[key] = best;
                }
                o[y * w + x] = (byte) best;
                if (dither) {
                    int c = pal[best];
                    float qr = (r - ((c >> 16) & 0xFF)) * 0.75f, qg = (g - ((c >> 8) & 0xFF)) * 0.75f, qb = (b - (c & 0xFF)) * 0.75f;   // suave: menos «ruido»
                    er[cur + x + 2] += qr * 7 / 16; eg[cur + x + 2] += qg * 7 / 16; eb[cur + x + 2] += qb * 7 / 16;
                    er[nxt + x] += qr * 3 / 16; eg[nxt + x] += qg * 3 / 16; eb[nxt + x] += qb * 3 / 16;
                    er[nxt + x + 1] += qr * 5 / 16; eg[nxt + x + 1] += qg * 5 / 16; eb[nxt + x + 1] += qb * 5 / 16;
                    er[nxt + x + 2] += qr / 16; eg[nxt + x + 2] += qg / 16; eb[nxt + x + 2] += qb / 16;
                }
            }
        }
        return o;
    }

    static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    // ------------------------------------------------------------------ LZW
    void lzw(byte[] data) throws IOException {
        final int minCode = 8;
        out.write(minCode);
        final int clear = 1 << minCode, eoi = clear + 1;
        java.util.HashMap<Integer, Integer> dict = new java.util.HashMap<>(8192);
        int next = eoi + 1, size = minCode + 1;
        byte[] blk = new byte[255];
        int[] st = {0, 0, 0};    // bitBuf, bitCount, blkLen
        writeCode(clear, size, st, blk);
        int prefix = data.length > 0 ? data[0] & 0xFF : 0;
        for (int i = 1; i < data.length; i++) {
            int k = data[i] & 0xFF;
            int key = prefix << 8 | k;
            Integer c = dict.get(key);
            if (c != null) { prefix = c; continue; }
            writeCode(prefix, size, st, blk);
            if (next < 4096) {
                dict.put(key, next++);
                if (next > (1 << size) && size < 12) size++;
            } else {
                writeCode(clear, size, st, blk);
                dict.clear(); next = eoi + 1; size = minCode + 1;
            }
            prefix = k;
        }
        writeCode(prefix, size, st, blk);
        writeCode(eoi, size, st, blk);
        if (st[1] > 0) { blk[st[2]++] = (byte) (st[0] & 0xFF); if (st[2] == 255) flushBlk(blk, st); }
        if (st[2] > 0) flushBlk(blk, st);
        out.write(0);
    }

    void writeCode(int code, int size, int[] st, byte[] blk) throws IOException {
        st[0] |= code << st[1];
        st[1] += size;
        while (st[1] >= 8) {
            blk[st[2]++] = (byte) (st[0] & 0xFF);
            if (st[2] == 255) flushBlk(blk, st);
            st[0] >>>= 8;
            st[1] -= 8;
        }
    }

    void flushBlk(byte[] blk, int[] st) throws IOException { out.write(st[2]); out.write(blk, 0, st[2]); st[2] = 0; }
}
