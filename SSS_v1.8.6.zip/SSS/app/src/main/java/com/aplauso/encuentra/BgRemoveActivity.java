package com.aplauso.encuentra;

import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * v1.8.2 · ✂ QUITAR FONDO: separa a la persona, mascota u objeto principal (ML Kit de Google, en el teléfono),
 * pincel para retocar, bordes suaves, fondo transparente / color / desenfocado / otra foto, pegatinas con borde blanco
 * y por lotes (varias fotos de golpe).
 */
public class BgRemoveActivity extends NeonActivity {
    static final int REQ = 62, REQ_BG = 63, REQ_BATCH = 64;
    final Handler h = new Handler(Looper.getMainLooper());
    CompareView cmp;
    Bitmap src, bgImg;
    float[] conf;
    String name = "foto";
    int bgMode;                         // 0 transparente · 1 color · 2 desenfocado · 3 foto
    int bgColor = Color.WHITE;
    SeekBar feather;
    Switch sticker;
    TextView bgBtn, brushBtn;
    NeonProgress prog;
    volatile boolean busy;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("✂ QUITAR FONDO");
        LinearLayout a = panel(null);
        cmp = new CompareView(this);
        cmp.onMaskChanged = this::compose;
        a.addView(cmp, new LinearLayout.LayoutParams(-1, dpi(330)));
        LinearLayout r = new LinearLayout(this);
        r.addView(button("🖼 FOTO", v -> PickActivity.start(this, new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ, "bgremove")), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.leftMargin = dpi(6);
        r.addView(button("💾 GUARDAR", v -> save()), lp);
        a.addView(r, gapBelow(4));
        brushBtn = button("", v -> { cmp.brush = !cmp.brush; cmp.erase = false; refresh(); });
        a.addView(brushBtn, gapBelow(4));
        LinearLayout br = new LinearLayout(this);
        br.addView(button("➕ AÑADIR", v -> { cmp.brush = true; cmp.erase = false; refresh(); }), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1); l2.leftMargin = dpi(6);
        br.addView(button("➖ QUITAR", v -> { cmp.brush = true; cmp.erase = true; refresh(); }), l2);
        a.addView(br);
        col.addView(a, gapBelow(12));

        LinearLayout o = panel("◢ RESULTADO");
        TextView ft = text("Bordes suaves", 11);
        o.addView(ft);
        feather = new SeekBar(this);
        feather.setMax(20); feather.setProgress(3);
        feather.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {}
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) { compose(); }
        });
        o.addView(feather, gapBelow(4));
        bgBtn = button("", v -> pickBg());
        o.addView(bgBtn, gapBelow(6));
        sticker = neonSwitch("🏷 Pegatina (borde blanco y recortada)");
        sticker.setOnCheckedChangeListener((x, on) -> compose());
        o.addView(sticker);
        o.addView(button("📚 VARIAS FOTOS A LA VEZ (PNG sin fondo)", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            PickActivity.start(this, i, REQ_BATCH, "bgremove_batch");
        }), gapBelow(6));
        prog = new NeonProgress(this);
        o.addView(prog);
        col.addView(o, gapBelow(12));
        refresh();
        if (getIntent().getData() != null) open(getIntent().getData());
    }

    void refresh() {
        brushBtn.setText(cmp.brush ? (cmp.erase ? L.t("➖ Pinta lo que sobra (toca aquí para terminar)") : L.t("➕ Pinta lo que falta (toca aquí para terminar)")) : L.t("✏ RETOCAR CON EL DEDO"));
        String[] n = {"🔳 Fondo: transparente", "🎨 Fondo: color", "🌫 Fondo: desenfocado", "🖼 Fondo: otra foto"};
        bgBtn.setText(L.t(n[bgMode]));
        cmp.invalidate();
    }

    void pickBg() {
        String[] o = {L.t("🔳 Transparente"), L.t("⬜ Blanco"), L.t("⬛ Negro"), L.t("💜 Neón"), L.t("🟦 Azul estudio"), L.t("🌫 Desenfocado"), L.t("🖼 Otra foto…")};
        new android.app.AlertDialog.Builder(this).setItems(o, (d, w) -> {
            if (w == 0) bgMode = 0;
            else if (w <= 4) { bgMode = 1; bgColor = new int[]{0, Color.WHITE, Color.BLACK, Neon.color(this), Color.rgb(40, 90, 200)}[w]; }
            else if (w == 5) bgMode = 2;
            else { PickActivity.start(this, new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_BG, "bgremove_bg"); return; }
            refresh(); compose();
        }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (res != RESULT_OK || d == null) return;
        if (req == REQ && d.getData() != null) open(d.getData());
        else if (req == REQ_BG && d.getData() != null) { bgImg = PhotoTools.load(this, d.getData(), 2400); bgMode = 3; refresh(); compose(); }
        else if (req == REQ_BATCH) {
            List<Uri> l = new ArrayList<>();
            ClipData cd = d.getClipData();
            if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) l.add(cd.getItemAt(i).getUri());
            else if (d.getData() != null) l.add(d.getData());
            batch(l);
        }
    }

    void open(Uri u) {
        Bitmap b = PhotoTools.load(this, u, 2000);
        if (b == null) { toast(L.t("No puedo abrir esa foto.")); return; }
        src = b.copy(Bitmap.Config.ARGB_8888, false);
        name = Media.nameOf(this, u).replaceAll("\\.[A-Za-z0-9]{2,4}$", "");
        cmp.mask = null;
        cmp.set(src, null);
        cmp.brushPx = Math.max(6, Math.max(src.getWidth(), src.getHeight()) / 70f);
        segment();
    }

    void segment() {
        busy = true;
        prog.begin(); prog.phase(L.t("Separando del fondo…"));
        new Thread(() -> {
            try {
                float[] c = ImgAI.subject(src);
                boolean[] m = new boolean[c.length];
                for (int i = 0; i < c.length; i++) m[i] = c[i] > 0.5f;
                h.post(() -> { busy = false; prog.hide(); conf = c; cmp.setMask(m); compose(); Achievements.used(this, "BgRemoveActivity"); });
            } catch (Throwable e) {
                h.post(() -> { busy = false; prog.hide(); toast(L.t("No pude separar el fondo (necesita los servicios de Google Play actualizados)") + ": " + e.getMessage()); });
            }
        }).start();
    }

    /** Alfa final: la máscara (con tus retoques) + bordes suaves de la confianza, difuminado. */
    float[] alpha(Bitmap s, float[] cf, boolean[] m, int fr) {
        int W = s.getWidth(), H = s.getHeight();
        float[] a = new float[W * H];
        for (int i = 0; i < a.length; i++) a[i] = m[i] ? (cf != null && cf[i] > 0.5f ? Math.min(1, cf[i] * 1.6f - 0.3f) : 1f) : 0f;
        if (fr > 0) a = blur(a, W, H, fr);
        return a;
    }

    static float[] blur(float[] a, int W, int H, int r) {
        float[] t = new float[a.length], o = new float[a.length];
        for (int y = 0; y < H; y++) { float acc = 0; int n = 0;
            for (int x = -r; x < W; x++) {
                if (x + r < W) { acc += a[y * W + x + r]; n++; }
                if (x - r - 1 >= 0) { acc -= a[y * W + x - r - 1]; n--; }
                if (x >= 0) t[y * W + x] = acc / n;
            } }
        for (int x = 0; x < W; x++) { float acc = 0; int n = 0;
            for (int y = -r; y < H; y++) {
                if (y + r < H) { acc += t[(y + r) * W + x]; n++; }
                if (y - r - 1 >= 0) { acc -= t[(y - r - 1) * W + x]; n--; }
                if (y >= 0) o[y * W + x] = acc / n;
            } }
        return o;
    }

    void compose() {
        if (src == null || cmp.mask == null) return;
        Bitmap out = render(src, conf, cmp.mask.clone());
        cmp.set(src, out);
    }

    Bitmap render(Bitmap s, float[] cf, boolean[] m) {
        int W = s.getWidth(), H = s.getHeight();
        float[] a = alpha(s, cf, m, feather.getProgress());
        int[] px = new int[W * H]; s.getPixels(px, 0, W, 0, 0, W, H);
        int[] bg = null;
        if (bgMode == 2) { Bitmap bl = Bitmap.createScaledBitmap(Bitmap.createScaledBitmap(s, Math.max(1, W / 24), Math.max(1, H / 24), true), W, H, true); bg = new int[W * H]; bl.getPixels(bg, 0, W, 0, 0, W, H); }
        if (bgMode == 3 && bgImg != null) {
            Bitmap c = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
            float k = Math.max(W / (float) bgImg.getWidth(), H / (float) bgImg.getHeight());
            Canvas cv = new Canvas(c);
            cv.translate((W - bgImg.getWidth() * k) / 2, (H - bgImg.getHeight() * k) / 2); cv.scale(k, k);
            cv.drawBitmap(bgImg, 0, 0, new Paint(Paint.FILTER_BITMAP_FLAG));
            bg = new int[W * H]; c.getPixels(bg, 0, W, 0, 0, W, H);
        }
        int[] o = new int[W * H];
        for (int i = 0; i < o.length; i++) {
            float al = a[i];
            int p = px[i];
            if (bgMode == 0) { o[i] = (Math.round(al * 255) << 24) | (p & 0xFFFFFF); continue; }
            int q = bgMode == 1 ? bgColor : bg != null ? bg[i] : Color.WHITE;
            int r = Math.round(((p >> 16) & 255) * al + ((q >> 16) & 255) * (1 - al)), g = Math.round(((p >> 8) & 255) * al + ((q >> 8) & 255) * (1 - al)), b = Math.round((p & 255) * al + (q & 255) * (1 - al));
            o[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
        }
        Bitmap res = Bitmap.createBitmap(o, W, H, Bitmap.Config.ARGB_8888);
        if (sticker.isChecked()) res = stickerize(res, a, W, H);
        return res;
    }

    /** Pegatina: recorta al sujeto y le pone un borde blanco gordito. */
    static Bitmap stickerize(Bitmap img, float[] a, int W, int H) {
        int x0 = W, y0 = H, x1 = 0, y1 = 0;
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) if (a[y * W + x] > 0.3f) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
        if (x1 <= x0) return img;
        int pad = Math.max(8, Math.max(x1 - x0, y1 - y0) / 25);
        int w = x1 - x0 + 1 + 2 * pad, h = y1 - y0 + 1 + 2 * pad;
        float[] sa = new float[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) { int sx = x0 + x - pad, sy = y0 + y - pad; if (sx >= 0 && sy >= 0 && sx < W && sy < H) sa[y * w + x] = a[sy * W + sx]; }
        float[] grow = blur(sa, w, h, pad * 2 / 3);
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        int[] o = new int[w * h];
        for (int i = 0; i < o.length; i++) o[i] = grow[i] > 0.04f ? 0xFFFFFFFF : 0;
        out.setPixels(o, 0, w, 0, 0, w, h);
        Canvas c = new Canvas(out);
        Bitmap cut = Bitmap.createBitmap(img, x0, y0, x1 - x0 + 1, y1 - y0 + 1);
        c.drawBitmap(cut, pad, pad, null);
        return out;
    }

    void save() {
        if (src == null || cmp.mask == null) { toast(L.t("Primero elige una foto.")); return; }
        Bitmap out = render(src, conf, cmp.mask.clone());
        new Thread(() -> {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            boolean png = bgMode == 0 || sticker.isChecked();
            out.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 95, bo);
            Uri u = Media.saveBytes(this, bo.toByteArray(), "Sin fondo", name + (sticker.isChecked() ? "_pegatina" : "_sin_fondo") + (png ? ".png" : ".jpg"), png ? "image/png" : "image/jpeg");
            h.post(() -> toast(u != null ? L.t("Guardada en SSS+/Sin fondo.") : L.t("No se pudo guardar.")));
        }).start();
    }

    void batch(List<Uri> l) {
        if (l.isEmpty() || busy) return;
        busy = true;
        prog.begin();
        new Thread(() -> {
            int ok = 0;
            for (int i = 0; i < l.size(); i++) {
                final int k = i;
                h.post(() -> prog.set(L.t("Quitando fondos"), k, l.size()));
                try {
                    Bitmap b = PhotoTools.load(this, l.get(i), 2000);
                    if (b == null) continue;
                    b = b.copy(Bitmap.Config.ARGB_8888, false);
                    float[] c = ImgAI.subject(b);
                    boolean[] m = new boolean[c.length];
                    for (int j = 0; j < c.length; j++) m[j] = c[j] > 0.5f;
                    Bitmap out = render(b, c, m);
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    out.compress(Bitmap.CompressFormat.PNG, 95, bo);
                    String nm = Media.nameOf(this, l.get(i)).replaceAll("\\.[A-Za-z0-9]{2,4}$", "");
                    if (Media.saveBytes(this, bo.toByteArray(), "Sin fondo", nm + "_sin_fondo.png", "image/png") != null) ok++;
                } catch (Throwable ignored) {}
            }
            final int fok = ok;
            h.post(() -> { busy = false; prog.hide(); toast(fok + " / " + l.size() + " " + L.t("guardadas en SSS+/Sin fondo.")); });
        }).start();
    }
}
