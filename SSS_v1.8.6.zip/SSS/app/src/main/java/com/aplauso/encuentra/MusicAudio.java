package com.aplauso.encuentra;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;

/**
 * v1.8 · Sonido de la sección Música: detector de tono preciso (McLeod / MPM), sonidos de cuerda pulsada
 * (Karplus-Strong) para escuchar acordes, tonos de referencia y el motor del metrónomo (exacto a la muestra).
 */
public final class MusicAudio {
    private MusicAudio() {}
    public static final int SR = 44100;

    // ================================================================== detector de tono
    public interface PitchListener { void pitch(float hz, float clarity, float rms); }

    public static final class PitchDetector {
        private volatile boolean run;
        private Thread th;

        public void start(PitchListener l) {
            stop();
            run = true;
            th = new Thread(() -> {
                AudioRecord ar = null;
                try {
                    int n = 4096, hop = 1024;
                    int min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                    ar = new AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, n * 4));
                    if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
                        ar.release();
                        ar = new AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, n * 4));
                    }
                    ar.startRecording();
                    short[] rd = new short[hop];
                    float[] win = new float[n];
                    float[] dec = new float[n / 2];         // a 22 050 Hz: la mitad de trabajo y llega hasta el Si grave del bajo
                    float[] nsdf = new float[n / 4];
                    float[] hi = new float[256];
                    while (run) {
                        int got = ar.read(rd, 0, hop);
                        if (got <= 0) continue;
                        System.arraycopy(win, got, win, 0, n - got);
                        for (int i = 0; i < got; i++) win[n - got + i] = rd[i] / 32768f;
                        double e = 0;
                        for (float v : win) e += v * v;
                        float rms = (float) Math.sqrt(e / n);
                        if (rms < 0.004f) { l.pitch(0, 0, rms); continue; }
                        for (int i = 0; i < dec.length; i++) dec[i] = 0.5f * (win[2 * i] + win[2 * i + 1]);
                        float[] r = mpm(dec, nsdf, SR / 2f);
                        if (r[0] > 700) { float[] r2 = mpm(win, hi, SR); if (r2[0] > 0) r = r2; }   // notas agudas: a 44 100 Hz, más fino
                        l.pitch(r[0], r[1], rms);
                    }
                } catch (Throwable t) {
                    l.pitch(-1, 0, 0);
                } finally {
                    try { if (ar != null) { ar.stop(); ar.release(); } } catch (Throwable ignored) {}
                }
            }, "afinador");
            th.start();
        }

        public void stop() {
            run = false;
            Thread t = th;
            th = null;
            if (t != null) try { t.join(400); } catch (InterruptedException ignored) {}
        }
    }

    /** McLeod Pitch Method: {frecuencia, claridad 0..1}. */
    static float[] mpm(float[] x, float[] nsdf, float sr) {
        int n = x.length, maxLag = nsdf.length;
        for (int tau = 0; tau < maxLag; tau++) {
            double acf = 0, m = 0;
            for (int i = 0; i < n - tau; i++) { acf += x[i] * x[i + tau]; m += x[i] * x[i] + x[i + tau] * x[i + tau]; }
            nsdf[tau] = m > 0 ? (float) (2 * acf / m) : 0;
        }
        // picos positivos después de cada cruce por cero
        float best = 0;
        int[] peaks = new int[64];
        int np = 0, pos = 0;
        while (pos < maxLag - 1 && nsdf[pos] > 0) pos++;              // salta el primer lóbulo
        while (pos < maxLag - 1 && nsdf[pos] <= 0) pos++;
        while (pos < maxLag - 1 && np < peaks.length) {
            int peak = -1;
            while (pos < maxLag - 1 && nsdf[pos] > 0) {
                if (peak < 0 || nsdf[pos] > nsdf[peak]) peak = pos;
                pos++;
            }
            if (peak > 0) { peaks[np++] = peak; best = Math.max(best, nsdf[peak]); }
            while (pos < maxLag - 1 && nsdf[pos] <= 0) pos++;
        }
        if (np == 0 || best < 0.3f) return new float[]{0, best};
        float thr = 0.9f * best;
        int pick = peaks[0];
        for (int i = 0; i < np; i++) if (nsdf[peaks[i]] >= thr) { pick = peaks[i]; break; }
        // interpolación parabólica
        float a = nsdf[pick - 1], b = nsdf[pick], c = pick + 1 < maxLag ? nsdf[pick + 1] : b;
        float den = a - 2 * b + c;
        float shift = den == 0 ? 0 : 0.5f * (a - c) / den;
        float lag = pick + shift;
        return new float[]{sr / lag, b};
    }

    /** Desviación en cents respecto a la nota MIDI más cercana: {midi, cents}. */
    public static float[] nearest(float hz, double a4) {
        double m = 69 + 12 * Math.log(hz / a4) / Math.log(2);
        int r = (int) Math.round(m);
        return new float[]{r, (float) ((m - r) * 100)};
    }

    // ================================================================== sonidos
    /** Cuerda pulsada (Karplus-Strong). */
    static short[] pluck(double hz, double sec, float amp) {
        int len = (int) (sec * SR);
        short[] out = new short[len];
        int p = Math.max(2, (int) Math.round(SR / hz));
        float[] buf = new float[p];
        java.util.Random r = new java.util.Random(42);
        for (int i = 0; i < p; i++) buf[i] = r.nextFloat() * 2 - 1;
        int idx = 0;
        for (int i = 0; i < len; i++) {
            int nx = (idx + 1) % p;
            float v = buf[idx];
            buf[idx] = 0.996f * 0.5f * (buf[idx] + buf[nx]);
            idx = nx;
            out[i] = (short) Math.max(-32767, Math.min(32767, v * amp * 32767));
        }
        return out;
    }

    static void mix(float[] dst, short[] src, int at) {
        for (int i = 0; i < src.length && at + i < dst.length; i++) if (at + i >= 0) dst[at + i] += src[i] / 32768f;
    }

    /** Toca notas MIDI: rasgueado (strumMs entre cuerdas) o arpegio (si strumMs es grande). */
    public static void playNotes(int[] midis, int strumMs, double a4) {
        new Thread(() -> {
            int count = 0;
            for (int m : midis) if (m > 0) count++;
            if (count == 0) return;
            double total = 2.2 + strumMs * count / 1000.0;
            float[] mixb = new float[(int) (total * SR)];
            int k = 0;
            for (int m : midis) {
                if (m <= 0) continue;
                mix(mixb, pluck(MusicTheory.freq(m, a4), 2.2, 0.5f), (int) ((long) k * strumMs * SR / 1000));
                k++;
            }
            playBuffer(mixb, 0.9f / (float) Math.sqrt(count));
        }, "tocar").start();
    }

    /** Tono de referencia (cuerda que suena unos segundos). */
    public static void reference(int midi, double a4) { playNotes(new int[]{midi}, 0, a4); }

    static void playBuffer(float[] b, float gain) {
        short[] s = new short[b.length];
        for (int i = 0; i < b.length; i++) s[i] = (short) Math.max(-32767, Math.min(32767, b[i] * gain * 32767));
        AudioTrack t = null;
        try {
            t = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(s.length * 2).setTransferMode(AudioTrack.MODE_STATIC).build();
            t.write(s, 0, s.length);
            t.play();
            Thread.sleep((long) (s.length * 1000L / SR) + 100);
        } catch (Throwable ignored) {
        } finally {
            if (t != null) try { t.stop(); t.release(); } catch (Throwable ignored) {}
        }
    }

    // ================================================================== metrónomo
    public static final class Metronome {
        public volatile int bpm = 100, beats = 4, sub = 1, sound = 0;
        public volatile boolean accent = true;
        /** Entrenador: sube «trainStep» BPM cada «trainBars» compases hasta «trainTo» (0 = apagado). */
        public volatile int trainStep, trainBars = 8, trainTo;
        /** Silencios de prueba: suena «playBars» compases y calla «muteBars» (0 = apagado). */
        public volatile int playBars, muteBars;
        public volatile long beatCount;          // tiempos (no subdivisiones) que han sonado
        public volatile long lastBeatAtMs;       // para encender los puntos a la vez que suena
        public volatile int lastBeatInBar;
        public volatile boolean lastMuted;
        private volatile boolean run;
        private Thread th;

        public boolean running() { return run; }

        public void start() {
            stop();
            run = true;
            beatCount = 0;
            th = new Thread(this::loop, "metronomo");
            th.setPriority(Thread.MAX_PRIORITY);
            th.start();
        }

        public void stop() {
            run = false;
            Thread t = th;
            th = null;
            if (t != null) try { t.join(500); } catch (InterruptedException ignored) {}
        }

        short[][] clicks() {
            short[][] c = new short[3][];
            double[][] f;
            switch (sound) {
                case 1: f = new double[][]{{1900, 0.035, 0.9}, {1500, 0.03, 0.6}, {1200, 0.02, 0.35}}; break;   // madera
                case 2: f = new double[][]{{800, 0.09, 0.9}, {540, 0.08, 0.6}, {540, 0.05, 0.3}}; break;     // cencerro
                case 3: f = new double[][]{{2400, 0.012, 0.9}, {2000, 0.01, 0.6}, {2000, 0.008, 0.3}}; break; // tic agudo
                default: f = new double[][]{{1600, 0.03, 0.9}, {1000, 0.03, 0.65}, {800, 0.02, 0.35}};        // clic
            }
            for (int k = 0; k < 3; k++) {
                int len = (int) (f[k][1] * SR);
                c[k] = new short[len];
                for (int i = 0; i < len; i++) {
                    double t = i / (double) SR, env = Math.exp(-t / (f[k][1] / 4));
                    double v = Math.sin(2 * Math.PI * f[k][0] * t);
                    if (sound == 2) v = 0.6 * Math.signum(v) + 0.4 * Math.sin(2 * Math.PI * f[k][0] * 1.48 * t);
                    if (sound == 1) v = v * 0.7 + (Math.random() * 2 - 1) * 0.3;
                    c[k][i] = (short) (v * env * f[k][2] * 32767);
                }
            }
            return c;
        }

        void loop() {
            AudioTrack t = null;
            try {
                int min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                t = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                        .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                        .setBufferSizeInBytes(Math.max(min, 2048 * 2)).setTransferMode(AudioTrack.MODE_STREAM)
                        .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build();
                t.play();
                short[][] ck = clicks();
                int lastSound = sound;
                final int CH = 512;
                short[] out = new short[CH];
                long sample = 0, nextTick = 0;
                int tick = 0;                  // subdivisión dentro del compás
                long bar = 0;
                int curBpm = bpm;
                short[] playing = null; int playPos = 0;
                while (run) {
                    if (sound != lastSound) { ck = clicks(); lastSound = sound; }
                    java.util.Arrays.fill(out, (short) 0);
                    for (int i = 0; i < CH; i++, sample++) {
                        if (sample >= nextTick) {
                            int sb = Math.max(1, sub), bt = Math.max(1, beats);
                            int inBar = tick % (bt * sb);
                            if (inBar == 0 && tick > 0) {
                                bar++;
                                if (trainStep > 0 && trainTo > 0 && bar % Math.max(1, trainBars) == 0)
                                    bpm = Math.min(trainTo, bpm + trainStep);
                            }
                            curBpm = Math.max(20, Math.min(300, bpm));
                            boolean muted = playBars > 0 && muteBars > 0 && (bar % (playBars + muteBars)) >= playBars;
                            int kind = inBar == 0 && accent ? 0 : inBar % sb == 0 ? 1 : 2;
                            if (!muted) { playing = ck[kind]; playPos = 0; }
                            if (inBar % sb == 0) {
                                lastBeatInBar = inBar / sb;
                                lastMuted = muted;
                                beatCount++;
                                lastBeatAtMs = android.os.SystemClock.uptimeMillis() + (long) (min / 2 * 1000L / SR);
                            }
                            tick++;
                            nextTick += Math.round(60.0 * SR / curBpm / sb);
                        }
                        if (playing != null && playPos < playing.length) out[i] = playing[playPos++];
                    }
                    t.write(out, 0, CH);
                }
            } catch (Throwable ignored) {
            } finally {
                if (t != null) try { t.stop(); t.release(); } catch (Throwable ignored) {}
            }
        }

    }

    // ================================================================== ¿suena el acorde?
    public interface ChromaListener { void done(float[] chroma, float level); }

    /** Escucha «ms» milisegundos y devuelve la energía de cada nota (Do..Si, normalizada a 1). */
    public static void listenChroma(int ms, ChromaListener l) {
        new Thread(() -> {
            AudioRecord ar = null;
            float[] chroma = new float[12];
            float level = 0;
            try {
                int n = 8192;
                int min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                ar = new AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, n * 2));
                ar.startRecording();
                short[] buf = new short[n];
                long end = android.os.SystemClock.uptimeMillis() + ms;
                double[] re = new double[n], im = new double[n];
                while (android.os.SystemClock.uptimeMillis() < end) {
                    int got = 0;
                    while (got < n) { int r = ar.read(buf, got, n - got); if (r <= 0) break; got += r; }
                    double e = 0;
                    for (int i = 0; i < n; i++) {
                        double w = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (n - 1));
                        re[i] = buf[i] / 32768.0 * w; im[i] = 0; e += re[i] * re[i];
                    }
                    level = Math.max(level, (float) Math.sqrt(e / n));
                    fft(re, im);
                    for (int k = 2; k < n / 2; k++) {
                        double f = k * (double) SR / n;
                        if (f < 70 || f > 2000) continue;
                        double mag = Math.sqrt(re[k] * re[k] + im[k] * im[k]);
                        int pc = (int) Math.round(12 * Math.log(f / 440.0) / Math.log(2)) + 69;
                        chroma[((pc % 12) + 12) % 12] += mag / Math.sqrt(f / 100);    // menos peso a los armónicos agudos
                    }
                }
                float mx = 0;
                for (float c : chroma) mx = Math.max(mx, c);
                if (mx > 0) for (int i = 0; i < 12; i++) chroma[i] /= mx;
            } catch (Throwable ignored) {
            } finally {
                try { if (ar != null) { ar.stop(); ar.release(); } } catch (Throwable ignored) {}
            }
            l.done(chroma, level);
        }, "acorde").start();
    }

    /** Compara lo que sonó con un acorde: {faltan…} y {sobran…} (pcs). */
    public static int[][] judge(float[] chroma, java.util.Set<Integer> want) {
        java.util.List<Integer> miss = new java.util.ArrayList<>(), extra = new java.util.ArrayList<>();
        for (int pc : want) if (chroma[pc] < 0.22f) miss.add(pc);
        for (int pc = 0; pc < 12; pc++) if (!want.contains(pc) && chroma[pc] > 0.6f) extra.add(pc);
        int[] a = new int[miss.size()], b = new int[extra.size()];
        for (int i = 0; i < a.length; i++) a[i] = miss.get(i);
        for (int i = 0; i < b.length; i++) b[i] = extra.get(i);
        return new int[][]{a, b};
    }

    static void fft(double[] re, double[] im) {
        int n = re.length;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) { double t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double ang = -2 * Math.PI / len, wr = Math.cos(ang), wi = Math.sin(ang);
            for (int i = 0; i < n; i += len) {
                double cr = 1, ci = 0;
                for (int k = 0; k < len / 2; k++) {
                    int a = i + k, b = i + k + len / 2;
                    double xr = re[b] * cr - im[b] * ci, xi = re[b] * ci + im[b] * cr;
                    re[b] = re[a] - xr; im[b] = im[a] - xi; re[a] += xr; im[a] += xi;
                    double t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t;
                }
            }
        }
    }
}
