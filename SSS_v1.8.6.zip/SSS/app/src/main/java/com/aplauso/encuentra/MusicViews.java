package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Set;

/** v1.8 · Dibujos de la sección Música: diagrama de acorde, teclado de piano y armónica. */
public final class MusicViews {
    private MusicViews() {}

    static final int[] FINGER_COLORS = {Color.rgb(160, 170, 190), Color.rgb(245, 170, 60), Color.rgb(210, 90, 220), Color.rgb(80, 170, 240), Color.rgb(240, 120, 90)};

    // ================================================================== diagrama de acorde
    public static class ChordDiagram extends View {
        MusicTheory.Voicing v;
        int strings = 6;
        boolean lefty;
        String title = "";
        /** Modo «¿qué acorde es?»: tocas el mástil para poner y quitar dedos. */
        public boolean editable;
        public int[] edit;      // trastes que has puesto (−1 = no suena)
        public Runnable onEdit;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final int neon;

        public ChordDiagram(Context c) { super(c); neon = Neon.color(c); }

        public void set(String title, MusicTheory.Voicing v, int strings, boolean lefty) {
            this.title = title; this.v = v; this.strings = strings; this.lefty = lefty;
            invalidate();
        }

        public void startEdit(int strings) {
            this.strings = strings;
            editable = true;
            edit = new int[strings];
            java.util.Arrays.fill(edit, 0);
            invalidate();
        }

        @Override protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w);
            setMeasuredDimension(W, (int) (W * 1.05f));
        }

        float left, top, sw, fh;

        @Override
        protected void onDraw(Canvas cv) {
            float d = getResources().getDisplayMetrics().density;
            float W = getWidth(), H = getHeight();
            int[] frets = editable ? edit : v == null ? null : v.frets;
            int[] fingers = editable || v == null ? null : v.fingers;
            int base = 1;
            if (frets != null) {
                int mx = 0, mn = 99;
                for (int f : frets) { if (f > 0) { mx = Math.max(mx, f); mn = Math.min(mn, f); } }
                if (mx > 5 && !editable) base = mn;
            }
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextAlign(Paint.Align.CENTER);
            p.setColor(Color.WHITE);
            p.setTextSize(22 * d);
            cv.drawText(title, W / 2, 26 * d, p);
            left = W * 0.2f; float right = W * 0.86f;
            top = 66 * d; float bottom = H - 14 * d;
            sw = strings > 1 ? (right - left) / (strings - 1) : 0;
            fh = (bottom - top) / 5;
            // trastes
            p.setColor(Color.rgb(120, 125, 140));
            p.setStrokeWidth(1.5f * d);
            for (int f = 0; f <= 5; f++) cv.drawLine(left, top + f * fh, right, top + f * fh, p);
            if (base == 1) { p.setColor(Color.WHITE); p.setStrokeWidth(6 * d); cv.drawLine(left, top, right, top, p); }
            // números de traste
            p.setColor(Color.rgb(170, 180, 200));
            p.setTextSize(13 * d);
            p.setTypeface(Typeface.DEFAULT);
            for (int f = 0; f < 5; f++) cv.drawText(String.valueOf(base + f), left - 22 * d, top + f * fh + fh * 0.62f, p);
            // cuerdas
            p.setColor(Color.rgb(200, 205, 215));
            for (int s = 0; s < strings; s++) {
                p.setStrokeWidth((1 + (strings - s) * 0.35f) * d);
                float x = sx(s, lefty);
                cv.drawLine(x, top, x, bottom, p);
            }
            if (frets == null) return;
            // cejilla
            if (!editable && v != null && v.barre > 0) {
                int first = -1, last = -1;
                for (int s = 0; s < strings; s++) if (frets[s] == v.barre) { if (first < 0) first = s; last = s; }
                if (first >= 0) {
                    float y = top + (v.barre - base) * fh + fh / 2;
                    p.setColor(FINGER_COLORS[1]);
                    float x1 = sx(first, lefty), x2 = sx(last, lefty);
                    cv.drawRoundRect(new RectF(Math.min(x1, x2) - 11 * d, y - 11 * d, Math.max(x1, x2) + 11 * d, y + 11 * d), 11 * d, 11 * d, p);
                }
            }
            p.setTextSize(15 * d);
            for (int s = 0; s < strings; s++) {
                float x = sx(s, lefty);
                if (frets[s] < 0) { p.setColor(Color.rgb(240, 110, 110)); cv.drawText("✕", x, top - 14 * d, p); continue; }
                if (frets[s] == 0) {
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2 * d); p.setColor(Color.WHITE);
                    cv.drawCircle(x, top - 19 * d, 7 * d, p); p.setStyle(Paint.Style.FILL);
                    continue;
                }
                float y = top + (frets[s] - base) * fh + fh / 2;
                int fg = fingers == null ? 0 : fingers[s];
                p.setColor(editable ? neon : FINGER_COLORS[Math.min(4, fg)]);
                cv.drawCircle(x, y, 12 * d, p);
                if (fg > 0) { p.setColor(Color.BLACK); cv.drawText(String.valueOf(fg), x, y + 5 * d, p); }
            }
        }

        float sx(int s, boolean lefty) { int k = lefty ? strings - 1 - s : s; return left + k * sw; }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (!editable || e.getAction() != MotionEvent.ACTION_UP || edit == null) return editable;
            float x = e.getX(), y = e.getY();
            int best = -1; float bd = 1e9f;
            for (int s = 0; s < strings; s++) { float dx = Math.abs(sx(s, lefty) - x); if (dx < bd) { bd = dx; best = s; } }
            if (best < 0 || bd > sw) return true;
            if (y < top) edit[best] = edit[best] == 0 ? -1 : 0;                 // encima: al aire ↔ no suena
            else {
                int f = (int) ((y - top) / fh) + 1;
                edit[best] = edit[best] == f ? 0 : Math.min(5, f);
            }
            invalidate();
            if (onEdit != null) onEdit.run();
            return true;
        }
    }

    // ================================================================== piano (dos octavas)
    public static class Piano extends View {
        Set<Integer> on = new java.util.HashSet<>();
        int rootPc = -1;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final int neon;
        public Piano(Context c) { super(c); neon = Neon.color(c); }
        public void set(Set<Integer> pcs, int root) { on = pcs; rootPc = root; invalidate(); }
        @Override protected void onMeasure(int w, int h) { int W = MeasureSpec.getSize(w); setMeasuredDimension(W, (int) (W * 0.32f)); }
        @Override protected void onDraw(Canvas cv) {
            float W = getWidth(), H = getHeight();
            int whites = 14;
            float ww = W / whites;
            int[] wpc = {0, 2, 4, 5, 7, 9, 11};
            for (int i = 0; i < whites; i++) {
                int pc = wpc[i % 7];
                p.setColor(on.contains(pc) ? (pc == rootPc ? Color.rgb(245, 170, 60) : neon) : Color.WHITE);
                cv.drawRect(i * ww + 1, 0, (i + 1) * ww - 1, H, p);
            }
            int[] bpc = {1, 3, -1, 6, 8, 10, -1};
            for (int i = 0; i < whites; i++) {
                int pc = bpc[i % 7];
                if (pc < 0 || i == whites - 1) continue;
                p.setColor(on.contains(pc) ? (pc == rootPc ? Color.rgb(245, 170, 60) : neon) : Color.rgb(20, 22, 30));
                cv.drawRect((i + 0.65f) * ww, 0, (i + 1.35f) * ww, H * 0.6f, p);
            }
        }
    }

    // ================================================================== armónica
    public static class Harmonica extends View {
        MusicTheory.Harp harp;
        MusicTheory.HarpNote now;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final int neon;
        String notation = MusicTheory.EN;
        boolean flats;
        public Harmonica(Context c) { super(c); neon = Neon.color(c); notation = MusicTheory.notation(c); flats = MusicTheory.flats(c); }
        public void set(MusicTheory.Harp h, MusicTheory.HarpNote n) { harp = h; now = n; invalidate(); }
        @Override protected void onMeasure(int w, int h) { int W = MeasureSpec.getSize(w); setMeasuredDimension(W, (int) (W * 0.36f)); }
        @Override protected void onDraw(Canvas cv) {
            if (harp == null) return;
            float d = getResources().getDisplayMetrics().density;
            float W = getWidth(), H = getHeight();
            int n = harp.holes();
            float hw = W / n;
            p.setColor(Color.rgb(170, 175, 190));
            cv.drawRoundRect(new RectF(0, H * 0.3f, W, H * 0.7f), 8 * d, 8 * d, p);
            p.setTextAlign(Paint.Align.CENTER);
            for (int i = 0; i < n; i++) {
                boolean hit = now != null && now.hole == i + 1;
                p.setColor(hit ? neon : Color.rgb(40, 42, 52));
                cv.drawRoundRect(new RectF(i * hw + hw * 0.18f, H * 0.38f, (i + 1) * hw - hw * 0.18f, H * 0.62f), 4 * d, 4 * d, p);
                p.setColor(Color.WHITE);
                p.setTextSize(12 * d);
                cv.drawText(String.valueOf(i + 1), i * hw + hw / 2, H * 0.55f, p);
                p.setTextSize(10 * d);
                p.setColor(Color.rgb(170, 220, 255));
                cv.drawText(MusicTheory.name(harp.blow[i], notation, flats), i * hw + hw / 2, H * 0.22f, p);
                p.setColor(Color.rgb(255, 190, 140));
                cv.drawText(MusicTheory.name(harp.draw[i], notation, flats), i * hw + hw / 2, H * 0.88f, p);
                if (hit) {
                    p.setColor(neon);
                    p.setTextSize(18 * d);
                    cv.drawText(now.draw ? "↓" : "↑", i * hw + hw / 2, now.draw ? H * 0.99f : H * 0.12f, p);
                }
            }
            p.setTextAlign(Paint.Align.LEFT);
            p.setTextSize(9 * d);
            p.setColor(Color.rgb(170, 220, 255));
            cv.drawText("↑ " + L.t("soplar"), 2 * d, 10 * d, p);
            p.setColor(Color.rgb(255, 190, 140));
            cv.drawText("↓ " + L.t("aspirar"), 2 * d, H - 2 * d, p);
        }
    }
}
