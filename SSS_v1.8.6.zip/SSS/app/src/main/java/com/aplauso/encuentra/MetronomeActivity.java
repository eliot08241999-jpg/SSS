package com.aplauso.encuentra;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/** v1.8 · 🥁 Metrónomo: el clic lo genera el motor de audio, así que no se desfasa. */
public class MetronomeActivity extends NeonActivity {
    static final MusicAudio.Metronome M = new MusicAudio.Metronome();
    final Handler h = new Handler(Looper.getMainLooper());
    TextView bpmTv, playBtn, sigBtn, subBtn, soundBtn, trainTv, muteTv, presetBox;
    Dots dots;
    boolean flash, vibrate;
    long seenBeat = -1;
    final long[] taps = new long[6];
    int nTaps;

    static final String[] SIGS = {"2/4", "3/4", "4/4", "5/4", "6/8", "7/8", "9/8", "12/8"};
    static final int[] SIG_BEATS = {2, 3, 4, 5, 6, 7, 9, 12};
    static final String[] SUBS = {"♩ negras", "♫ corcheas", "³ tresillos", "♬ semicorcheas"};
    static final int[] SUB_N = {1, 2, 3, 4};
    static final String[] SOUNDS = {"Clic", "Madera", "Cencerro", "Tic agudo"};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🥁 METRÓNOMO");
        M.bpm = p.getInt("met_bpm", 100);
        M.beats = p.getInt("met_beats", 4);
        M.sub = p.getInt("met_sub", 1);
        M.sound = p.getInt("met_sound", 0);
        M.accent = p.getBoolean("met_accent", true);
        flash = p.getBoolean("met_flash", false);
        vibrate = p.getBoolean("met_vibe", false);

        LinearLayout top = panel(null);
        dots = new Dots();
        top.addView(dots, new LinearLayout.LayoutParams(-1, dpi(44)));
        bpmTv = neonText("", 54);
        bpmTv.setGravity(Gravity.CENTER);
        top.addView(bpmTv);
        LinearLayout r = new LinearLayout(this);
        for (int d : new int[]{-5, -1, 1, 5}) {
            TextView t = button((d > 0 ? "+" : "") + d, v -> setBpm(M.bpm + d));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.rightMargin = dpi(4);
            r.addView(t, lp);
        }
        top.addView(r, gapBelow(8));
        android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(280);
        sb.setProgress(M.bpm - 20);
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(android.widget.SeekBar s, int pr, boolean u) { if (u) setBpm(pr + 20); }
            public void onStartTrackingTouch(android.widget.SeekBar s) {}
            public void onStopTrackingTouch(android.widget.SeekBar s) {}
        });
        this.seek = sb;
        top.addView(sb, gapBelow(8));
        LinearLayout r2 = new LinearLayout(this);
        playBtn = button("▶ EMPEZAR", v -> toggle());
        r2.addView(playBtn, new LinearLayout.LayoutParams(0, -2, 1.4f));
        TextView tap = button("👆 TAP", v -> tap());
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1); tl.leftMargin = dpi(6);
        r2.addView(tap, tl);
        top.addView(r2);
        col.addView(top, gapBelow(12));

        LinearLayout o = panel("◢ COMPÁS Y SONIDO");
        sigBtn = button("", v -> pick(SIGS, w -> { M.beats = SIG_BEATS[w]; save(); }));
        o.addView(sigBtn, gapBelow(6));
        subBtn = button("", v -> pick(SUBS, w -> { M.sub = SUB_N[w]; save(); }));
        o.addView(subBtn, gapBelow(6));
        soundBtn = button("", v -> pick(SOUNDS, w -> { M.sound = w; save(); }));
        o.addView(soundBtn, gapBelow(6));
        android.widget.Switch acc = neonSwitch("Acentuar el primer tiempo");
        acc.setChecked(M.accent);
        acc.setOnCheckedChangeListener((v, on) -> { M.accent = on; save(); });
        o.addView(acc);
        android.widget.Switch fl = neonSwitch("Destello de pantalla en cada tiempo");
        fl.setChecked(flash);
        fl.setOnCheckedChangeListener((v, on) -> { flash = on; save(); });
        o.addView(fl);
        android.widget.Switch vb = neonSwitch("Vibrar en cada tiempo");
        vb.setChecked(vibrate);
        vb.setOnCheckedChangeListener((v, on) -> { vibrate = on; save(); });
        o.addView(vb);
        col.addView(o, gapBelow(12));

        LinearLayout tr = panel("◢ PARA PRACTICAR");
        trainTv = text("", 13);
        tr.addView(trainTv);
        tr.addView(button("📈 SUBIR EL TEMPO SOLO", v -> trainer()), gapBelow(6));
        muteTv = text("", 13);
        tr.addView(muteTv);
        tr.addView(button("🔇 SILENCIOS DE PRUEBA", v -> muter()), gapBelow(6));
        col.addView(tr, gapBelow(12));

        LinearLayout ps = panel("◢ TEMPOS GUARDADOS");
        presetBox = text("", 13);
        ps.addView(presetBox);
        ps.addView(button("💾 GUARDAR ESTE TEMPO", v -> savePreset()), gapBelow(6));
        ps.addView(button("📂 CARGAR UNO", v -> loadPreset()));
        col.addView(ps, gapBelow(12));

        int sbpm = getIntent().getIntExtra("bpm", 0);
        if (sbpm > 0) setBpm(sbpm);
        refresh();
        h.post(tick);
    }

    android.widget.SeekBar seek;

    interface Pick { void at(int w); }

    void pick(String[] items, Pick k) {
        String[] t = new String[items.length];
        for (int i = 0; i < t.length; i++) t[i] = L.t(items[i]);
        new android.app.AlertDialog.Builder(this).setItems(t, (d, w) -> { k.at(w); refresh(); }).show();
    }

    void setBpm(int v) {
        M.bpm = Math.max(20, Math.min(300, v));
        if (seek != null) seek.setProgress(M.bpm - 20);
        save();
        refresh();
    }

    void save() {
        p.edit().putInt("met_bpm", M.bpm).putInt("met_beats", M.beats).putInt("met_sub", M.sub).putInt("met_sound", M.sound)
                .putBoolean("met_accent", M.accent).putBoolean("met_flash", flash).putBoolean("met_vibe", vibrate).apply();
    }

    void refresh() {
        bpmTv.setText(M.bpm + " BPM");
        int si = 2;
        for (int i = 0; i < SIG_BEATS.length; i++) if (SIG_BEATS[i] == M.beats) si = i;
        sigBtn.setText(L.t("Compás") + ": " + SIGS[si]);
        int ui = 0;
        for (int i = 0; i < SUB_N.length; i++) if (SUB_N[i] == M.sub) ui = i;
        subBtn.setText(L.t("Subdivisión") + ": " + L.t(SUBS[ui]));
        soundBtn.setText(L.t("Sonido") + ": " + L.t(SOUNDS[M.sound]));
        playBtn.setText(M.running() ? L.t("⏹ PARAR") : L.t("▶ EMPEZAR"));
        trainTv.setText(M.trainStep > 0 ? L.t("Sube") + " " + M.trainStep + " BPM " + L.t("cada") + " " + M.trainBars + " " + L.t("compases hasta") + " " + M.trainTo
                : L.t("Empieza lento y sube solo hasta tu objetivo."));
        muteTv.setText(M.playBars > 0 ? L.t("Suena") + " " + M.playBars + " " + L.t("compases y calla") + " " + M.muteBars + ": " + L.t("¿mantienes el ritmo tú solo?")
                : L.t("Calla algunos compases para comprobar si mantienes el ritmo."));
        presetBox.setText(p.getString("met_presets", "").isEmpty() ? L.t("Aún no hay ninguno.") : p.getString("met_presets", "").replace("\t", " · "));
        dots.invalidate();
    }

    void toggle() {
        if (M.running()) { M.stop(); getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); }
        else { M.start(); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); }
        refresh();
    }

    void tap() {
        long now = SystemClock.uptimeMillis();
        if (nTaps > 0 && now - taps[(nTaps - 1) % taps.length] > 2000) nTaps = 0;
        taps[nTaps % taps.length] = now;
        nTaps++;
        if (nTaps >= 2) {
            int k = Math.min(nTaps, taps.length);
            long first = taps[(nTaps - k) % taps.length], last = taps[(nTaps - 1) % taps.length];
            double per = (last - first) / (double) (k - 1);
            if (per > 0) setBpm((int) Math.round(60000 / per));
        }
    }

    void trainer() {
        if (M.trainStep > 0) { M.trainStep = 0; refresh(); return; }
        String[] o = {"+2 BPM cada 4 compases", "+5 BPM cada 8 compases", "+5 BPM cada 4 compases", "+10 BPM cada 8 compases"};
        int[][] v = {{2, 4}, {5, 8}, {5, 4}, {10, 8}};
        pick(o, w -> {
            android.widget.EditText e = new android.widget.EditText(this);
            e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            e.setText(String.valueOf(Math.min(300, M.bpm + 40)));
            new android.app.AlertDialog.Builder(this).setTitle(L.t("¿Hasta cuántos BPM?")).setView(e).setPositiveButton("OK", (d, x) -> {
                try { M.trainTo = Math.max(M.bpm + 1, Math.min(300, Integer.parseInt(e.getText().toString().trim()))); } catch (Exception ex) { M.trainTo = M.bpm + 40; }
                M.trainStep = v[w][0];
                M.trainBars = v[w][1];
                refresh();
            }).show();
        });
    }

    void muter() {
        if (M.playBars > 0) { M.playBars = 0; refresh(); return; }
        String[] o = {"Suena 4, calla 2", "Suena 4, calla 4", "Suena 2, calla 2", "Suena 8, calla 4"};
        int[][] v = {{4, 2}, {4, 4}, {2, 2}, {8, 4}};
        pick(o, w -> { M.playBars = v[w][0]; M.muteBars = v[w][1]; });
    }

    void savePreset() {
        android.widget.EditText e = new android.widget.EditText(this);
        e.setHint(L.t("Nombre (p. ej. Canción A)"));
        new android.app.AlertDialog.Builder(this).setTitle(L.t("💾 Guardar tempo")).setView(e).setPositiveButton("OK", (d, w) -> {
            String n = e.getText().toString().replace("\n", " ").replace("\t", " ").trim();
            if (n.isEmpty()) return;
            String line = n + "\t" + M.bpm + " BPM\t" + SIGS[java.util.Arrays.binarySearch(SIG_BEATS, M.beats) < 0 ? 2 : java.util.Arrays.binarySearch(SIG_BEATS, M.beats)];
            String all = p.getString("met_presets", "");
            p.edit().putString("met_presets", all.isEmpty() ? line : all + "\n" + line).apply();
            refresh();
        }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    void loadPreset() {
        String all = p.getString("met_presets", "");
        if (all.isEmpty()) { toast(L.t("Aún no hay ninguno.")); return; }
        String[] lines = all.split("\n");
        String[] show = new String[lines.length];
        for (int i = 0; i < lines.length; i++) show[i] = lines[i].replace("\t", " · ");
        new android.app.AlertDialog.Builder(this).setItems(show, (d, w) -> {
            String[] f = lines[w].split("\t");
            try { setBpm(Integer.parseInt(f[1].replaceAll("\\D", ""))); } catch (Exception ignored) {}
            for (int i = 0; i < SIGS.length && f.length > 2; i++) if (SIGS[i].equals(f[2])) M.beats = SIG_BEATS[i];
            save(); refresh();
        }).setNeutralButton(L.t("🗑 Borrar todos"), (d, w) -> { p.edit().remove("met_presets").apply(); refresh(); }).show();
    }

    final Runnable tick = new Runnable() {
        public void run() {
            if (isFinishing()) return;
            if (M.running() && M.beatCount != seenBeat && SystemClock.uptimeMillis() >= M.lastBeatAtMs) {
                seenBeat = M.beatCount;
                dots.invalidate();
                if (!M.lastMuted) {
                    if (flash) { View root = getWindow().getDecorView(); root.setAlpha(0.6f); h.postDelayed(() -> root.setAlpha(1f), 70); }
                    if (vibrate) try {
                        Vibrator vb = getSystemService(Vibrator.class);
                        if (vb != null) vb.vibrate(VibrationEffect.createOneShot(M.lastBeatInBar == 0 ? 45 : 22, VibrationEffect.DEFAULT_AMPLITUDE));
                    } catch (Exception ignored) {}
                }
                if (bpmTv != null && !(M.bpm + " BPM").contentEquals(bpmTv.getText())) refresh();
            }
            h.postDelayed(this, 8);
        }
    };

    @Override protected void onDestroy() { h.removeCallbacks(tick); M.stop(); super.onDestroy(); }

    class Dots extends View {
        final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        Dots() { super(MetronomeActivity.this); }
        @Override protected void onDraw(Canvas cv) {
            int n = Math.max(1, M.beats);
            float w = getWidth(), hh = getHeight(), step = w / n, r = Math.min(step * 0.32f, hh * 0.38f);
            int neon = Neon.color(getContext());
            boolean on = M.running();
            for (int i = 0; i < n; i++) {
                boolean cur = on && i == M.lastBeatInBar;
                pt.setStyle(cur ? Paint.Style.FILL : Paint.Style.STROKE);
                pt.setStrokeWidth(dp(2));
                pt.setColor(cur ? (M.lastMuted ? Color.rgb(90, 95, 110) : i == 0 && M.accent ? Color.rgb(245, 170, 60) : neon) : Color.argb(120, Color.red(neon), Color.green(neon), Color.blue(neon)));
                cv.drawCircle(step * (i + 0.5f), hh / 2, r, pt);
            }
        }
    }
}
