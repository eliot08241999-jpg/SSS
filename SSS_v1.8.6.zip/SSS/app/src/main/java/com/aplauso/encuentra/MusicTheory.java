package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v1.8 · Teoría musical para la sección Música: nombres de notas (C-D-E, Do-Re-Mi o alemán con H),
 * acordes (fórmulas, lectura, transporte), instrumentos y afinaciones, posiciones calculadas en el mástil
 * y armónicas (soplar/aspirar/bends) con tablatura a partir de notas.
 */
public final class MusicTheory {
    private MusicTheory() {}

    // ------------------------------------------------------------------ notación
    public static final String EN = "en", SOL = "sol", DE = "de";
    static final String[] SHARP = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    static final String[] FLAT = {"C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"};
    static final String[] SOL_SHARP = {"Do", "Do#", "Re", "Re#", "Mi", "Fa", "Fa#", "Sol", "Sol#", "La", "La#", "Si"};
    static final String[] SOL_FLAT = {"Do", "Reb", "Re", "Mib", "Mi", "Fa", "Solb", "Sol", "Lab", "La", "Sib", "Si"};

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    public static String notation(Context c) { return prefs(c).getString("mus_notation", "es".equals(L.lang) || "it".equals(L.lang) ? SOL : EN); }
    public static boolean flats(Context c) { return prefs(c).getBoolean("mus_flats", false); }

    public static int mod12(int n) { return ((n % 12) + 12) % 12; }

    public static String name(int pc, String notation, boolean flats) {
        pc = mod12(pc);
        if (SOL.equals(notation)) return (flats ? SOL_FLAT : SOL_SHARP)[pc];
        String n = (flats ? FLAT : SHARP)[pc];
        if (DE.equals(notation)) { if (pc == 11) return "H"; if (pc == 10) return "B"; }
        return n;
    }

    public static String name(Context c, int pc) { return name(pc, notation(c), flats(c)); }

    /** Nombre con octava (científica: C4 = Do central). */
    public static String noteName(Context c, int midi) { return name(c, midi) + (midi / 12 - 1); }

    public static double freq(int midi, double a4) { return a4 * Math.pow(2, (midi - 69) / 12.0); }

    // ------------------------------------------------------------------ leer notas («C4», «Do#», «sib3», «H»)
    static final Pattern NOTE = Pattern.compile("(?i)^(do|re|mi|fa|sol|la|si|[a-h])([#♯b♭]?)(-?\\d)?$");

    /** midi (o −1). Sin octava, usa «defOct». */
    public static int parseNote(String s, int defOct, String notation) {
        Matcher m = NOTE.matcher(s.trim());
        if (!m.matches()) return -1;
        int pc = rootPc(m.group(1), notation);
        if (pc < 0) return -1;
        String acc = m.group(2);
        if (acc.equals("#") || acc.equals("♯")) pc++;
        else if (acc.equalsIgnoreCase("b") || acc.equals("♭")) pc--;
        int oct = m.group(3) == null ? defOct : Integer.parseInt(m.group(3));
        return (oct + 1) * 12 + mod12(pc) + (pc < 0 ? -12 : pc > 11 ? 12 : 0);
    }

    static int rootPc(String r, String notation) {
        switch (r.toLowerCase(Locale.ROOT)) {
            case "do": case "c": return 0;
            case "re": case "d": return 2;
            case "mi": case "e": return 4;
            case "fa": case "f": return 5;
            case "sol": case "g": return 7;
            case "la": case "a": return 9;
            case "si": return 11;
            case "h": return 11;
            case "b": return DE.equals(notation) ? 10 : 11;
        }
        return -1;
    }

    // ------------------------------------------------------------------ acordes
    /** sufijo → intervalos (el primero es la fundamental). */
    static final LinkedHashMap<String, int[]> TYPES = new LinkedHashMap<>();
    static {
        TYPES.put("", new int[]{0, 4, 7});
        TYPES.put("m", new int[]{0, 3, 7});
        TYPES.put("5", new int[]{0, 7});
        TYPES.put("6", new int[]{0, 4, 7, 9});
        TYPES.put("m6", new int[]{0, 3, 7, 9});
        TYPES.put("7", new int[]{0, 4, 7, 10});
        TYPES.put("maj7", new int[]{0, 4, 7, 11});
        TYPES.put("m7", new int[]{0, 3, 7, 10});
        TYPES.put("mMaj7", new int[]{0, 3, 7, 11});
        TYPES.put("sus2", new int[]{0, 2, 7});
        TYPES.put("sus4", new int[]{0, 5, 7});
        TYPES.put("7sus4", new int[]{0, 5, 7, 10});
        TYPES.put("dim", new int[]{0, 3, 6});
        TYPES.put("dim7", new int[]{0, 3, 6, 9});
        TYPES.put("m7b5", new int[]{0, 3, 6, 10});
        TYPES.put("aug", new int[]{0, 4, 8});
        TYPES.put("add9", new int[]{0, 4, 7, 2});
        TYPES.put("madd9", new int[]{0, 3, 7, 2});
        TYPES.put("9", new int[]{0, 4, 7, 10, 2});
        TYPES.put("m9", new int[]{0, 3, 7, 10, 2});
        TYPES.put("maj9", new int[]{0, 4, 7, 11, 2});
        TYPES.put("7b9", new int[]{0, 4, 7, 10, 1});
        TYPES.put("7#9", new int[]{0, 4, 7, 10, 3});
        TYPES.put("6/9", new int[]{0, 4, 7, 9, 2});
        TYPES.put("11", new int[]{0, 7, 10, 2, 5});
        TYPES.put("13", new int[]{0, 4, 10, 2, 9});
    }
    static final Map<String, String> ALIAS = new LinkedHashMap<>();
    static {
        String[][] a = {{"min", "m"}, {"-", "m"}, {"mi", "m"}, {"maj", ""}, {"M", ""}, {"M7", "maj7"}, {"7M", "maj7"}, {"Δ", "maj7"}, {"Δ7", "maj7"},
                {"ma7", "maj7"}, {"min7", "m7"}, {"-7", "m7"}, {"m(maj7)", "mMaj7"}, {"mM7", "mMaj7"}, {"sus", "sus4"}, {"°", "dim"}, {"o", "dim"},
                {"°7", "dim7"}, {"o7", "dim7"}, {"ø", "m7b5"}, {"ø7", "m7b5"}, {"m7(b5)", "m7b5"}, {"+", "aug"}, {"(add9)", "add9"}, {"2", "add9"},
                {"m(add9)", "madd9"}, {"7(9)", "9"}, {"69", "6/9"}, {"7(#9)", "7#9"}, {"7(b9)", "7b9"}, {"7sus", "7sus4"}};
        for (String[] x : a) ALIAS.put(x[0], x[1]);
    }

    public static final class Chord {
        public int root, bass = -1;
        public String type = "";

        public int[] intervals() { int[] i = TYPES.get(type); return i == null ? new int[]{0, 4, 7} : i; }

        public Set<Integer> pcs() {
            Set<Integer> s = new HashSet<>();
            for (int i : intervals()) s.add(mod12(root + i));
            if (bass >= 0) s.add(mod12(bass));
            return s;
        }

        public Chord transpose(int n) {
            Chord c = new Chord();
            c.root = mod12(root + n);
            c.type = type;
            c.bass = bass < 0 ? -1 : mod12(bass + n);
            return c;
        }

        public String name(String notation, boolean flats) {
            String n = MusicTheory.name(root, notation, flats) + type;
            if (bass >= 0) n += "/" + MusicTheory.name(bass, notation, flats);
            return n;
        }

        public String name(Context c) { return name(notation(c), flats(c)); }

        @Override public boolean equals(Object o) { return o instanceof Chord && ((Chord) o).root == root && ((Chord) o).bass == bass && ((Chord) o).type.equals(type); }
        @Override public int hashCode() { return root * 31 + bass * 7 + type.hashCode(); }
    }

    static final Pattern CHORD = Pattern.compile("^(Do|Re|Mi|Fa|Sol|La|Si|[A-H])([#♯b♭]?)([^/\\s]*)(?:/(Do|Re|Mi|Fa|Sol|La|Si|[A-H])([#♯b♭]?))?$");

    /** «Am», «C#7», «Lam», «Sol7», «D/F#», «Bbmaj7»… (null si no es un acorde). */
    public static Chord parseChord(String s, String notation) {
        if (s == null) return null;
        Matcher m = CHORD.matcher(s.trim());
        if (!m.matches()) return null;
        Chord c = new Chord();
        int r = rootPc(m.group(1), notation);
        if (r < 0) return null;
        c.root = mod12(r + acc(m.group(2)));
        String q = m.group(3);
        if (ALIAS.containsKey(q)) q = ALIAS.get(q);
        if (!TYPES.containsKey(q)) {
            // «m7», «7» con paréntesis raros… intenta sin paréntesis
            String q2 = q.replace("(", "").replace(")", "");
            if (ALIAS.containsKey(q2)) q2 = ALIAS.get(q2);
            if (!TYPES.containsKey(q2)) return null;
            q = q2;
        }
        c.type = q;
        if (m.group(4) != null) c.bass = mod12(rootPc(m.group(4), notation) + acc(m.group(5)));
        return c;
    }

    static int acc(String a) { return a == null || a.isEmpty() ? 0 : (a.equals("#") || a.equals("♯")) ? 1 : -1; }

    /** Versión sencilla (para «Simplificada»): triada mayor o menor (o dim). */
    public static Chord simplify(Chord c) {
        Chord s = new Chord();
        s.root = c.root;
        int[] iv = c.intervals();
        boolean minor = false, dim = false;
        for (int i : iv) { if (i == 3) minor = true; }
        if (c.type.startsWith("dim") || c.type.equals("m7b5")) dim = true;
        s.type = dim ? "dim" : minor ? "m" : "";
        if (c.type.startsWith("sus") || c.type.equals("5")) s.type = "";
        return s;
    }

    // ------------------------------------------------------------------ instrumentos
    public static final class Instrument {
        public final String id, name;
        public final int[] strings;     // midi, de grave a agudo (como se ven en el diagrama, de izquierda a derecha)
        public final boolean fretted;
        Instrument(String id, String name, boolean fretted, int... s) { this.id = id; this.name = name; this.fretted = fretted; this.strings = s; }
    }

    public static final List<Instrument> TUNINGS = new ArrayList<>(Arrays.asList(
            new Instrument("gtr6", "Guitarra 6 cuerdas · Estándar", true, 40, 45, 50, 55, 59, 64),
            new Instrument("gtr_dropd", "Guitarra · Drop D", true, 38, 45, 50, 55, 59, 64),
            new Instrument("gtr_dropc", "Guitarra · Drop C", true, 36, 43, 48, 53, 57, 62),
            new Instrument("gtr_half", "Guitarra · Medio tono abajo", true, 39, 44, 49, 54, 58, 63),
            new Instrument("gtr_openg", "Guitarra · Open G", true, 38, 43, 50, 55, 59, 62),
            new Instrument("gtr_opend", "Guitarra · Open D", true, 38, 45, 50, 54, 57, 62),
            new Instrument("gtr_dadgad", "Guitarra · DADGAD", true, 38, 45, 50, 55, 57, 62),
            new Instrument("gtr7", "Guitarra 7 cuerdas", true, 35, 40, 45, 50, 55, 59, 64),
            new Instrument("gtr12", "Guitarra 12 cuerdas (como la de 6)", true, 40, 45, 50, 55, 59, 64),
            new Instrument("bass4", "Bajo 4 cuerdas", true, 28, 33, 38, 43),
            new Instrument("bass5", "Bajo 5 cuerdas", true, 23, 28, 33, 38, 43),
            new Instrument("bass6", "Bajo 6 cuerdas", true, 23, 28, 33, 38, 43, 48),
            new Instrument("uke", "Ukelele (GCEA)", true, 67, 60, 64, 69),
            new Instrument("uke_low", "Ukelele · Sol grave", true, 55, 60, 64, 69),
            new Instrument("mando", "Mandolina", true, 55, 62, 69, 76),
            new Instrument("cavaco", "Cavaquiño", true, 62, 67, 71, 74),
            new Instrument("balalaika", "Balalaica", true, 64, 64, 69),
            new Instrument("banjo", "Banjo 5 cuerdas (Open G)", true, 67, 50, 55, 59, 62),
            new Instrument("violin", "Violín", false, 55, 62, 69, 76),
            new Instrument("viola", "Viola", false, 48, 55, 62, 69),
            new Instrument("cello", "Chelo", false, 36, 43, 50, 57),
            new Instrument("dbass", "Contrabajo", false, 28, 33, 38, 43)));

    /** Las afinaciones que has creado tú: «nombre\tmidi,midi,…» por línea. */
    public static List<Instrument> all(Context c) {
        List<Instrument> l = new ArrayList<>(TUNINGS);
        for (String line : prefs(c).getString("mus_custom_tunings", "").split("\n")) {
            int k = line.indexOf('\t');
            if (k <= 0) continue;
            try {
                String[] p = line.substring(k + 1).split(",");
                int[] s = new int[p.length];
                for (int i = 0; i < p.length; i++) s[i] = Integer.parseInt(p[i].trim());
                l.add(new Instrument("custom:" + line.substring(0, k), "⭐ " + line.substring(0, k), true, s));
            } catch (Exception ignored) {}
        }
        return l;
    }

    public static Instrument byId(Context c, String id) {
        for (Instrument i : all(c)) if (i.id.equals(id)) return i;
        return TUNINGS.get(0);
    }

    // ------------------------------------------------------------------ posiciones en el mástil
    public static final class Voicing {
        public int[] frets;          // −1 = no se toca, 0 = al aire
        public int[] fingers;        // 0 = ninguno, 1..4
        public int barre;            // traste de la cejilla (0 = sin cejilla)
        public int score;
        public int base() { int m = 99; for (int f : frets) if (f > 0) m = Math.min(m, f); return m == 99 ? 0 : m; }
        public int max() { int m = 0; for (int f : frets) m = Math.max(m, f); return m; }
        public boolean hard() { return barre > 0; }
    }

    /** Busca las mejores posiciones de un acorde (ordenadas de más fácil a menos). */
    public static List<Voicing> voicings(Chord ch, int[] strings, int capo, int max) { return voicings(ch, strings, capo, max, 12); }

    public static List<Voicing> voicings(Chord ch, int[] strings, int capo, int max, int maxPos) {
        int n = strings.length;
        Set<Integer> want = ch.pcs();
        int[] iv = ch.intervals();
        int bassPc = ch.bass >= 0 ? ch.bass : ch.root;
        Set<Integer> required = new HashSet<>(want);
        if (iv.length >= 4 && ch.bass < 0) required.remove(mod12(ch.root + 7));   // en acordes de 4+ notas, la quinta puede faltar
        List<Voicing> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (int pos = 0; pos <= maxPos; pos++) {
            List<List<Integer>> opts = new ArrayList<>();
            for (int s = 0; s < n; s++) {
                List<Integer> o = new ArrayList<>();
                o.add(-1);
                if (want.contains(mod12(strings[s] + capo))) o.add(0);
                for (int f = Math.max(1, pos); f <= pos + 3 && f <= 15; f++) if (want.contains(mod12(strings[s] + capo + f))) o.add(f);
                opts.add(o);
            }
            int[] cur = new int[n];
            search(0, false, opts, cur, strings, capo, want, required, bassPc, out, seen);
        }
        Collections.sort(out, (a, b) -> a.score - b.score);
        return out.size() > max ? new ArrayList<>(out.subList(0, max)) : out;
    }

    static void search(int s, boolean sounded, List<List<Integer>> opts, int[] cur, int[] strings, int capo, Set<Integer> want, Set<Integer> required,
                       int bassPc, List<Voicing> out, Set<String> seen) {
        if (out.size() > 3000) return;
        if (s == cur.length) { evaluate(cur, strings, capo, required, bassPc, out, seen); return; }
        int n = cur.length;
        for (int f : opts.get(s)) {
            if (f < 0 && sounded && n > 4) continue;                       // sin huecos en medio
            if (f < 0 && !sounded && n > 4 && s >= n - 3) continue;        // al menos 4 cuerdas sonando
            if (f > 0) {                                                   // que quepa en 4 trastes
                int mn = f, mx = f;
                for (int k = 0; k < s; k++) if (cur[k] > 0) { mn = Math.min(mn, cur[k]); mx = Math.max(mx, cur[k]); }
                if (mx - mn > 3) continue;
            }
            cur[s] = f;
            search(s + 1, sounded || f >= 0, opts, cur, strings, capo, want, required, bassPc, out, seen);
        }
    }

    static void evaluate(int[] fr, int[] strings, int capo, Set<Integer> required, int bassPc, List<Voicing> out, Set<String> seen) {
        int n = fr.length, sounding = 0, firstSound = -1, lowNote = 999, lowPc = -1;
        Set<Integer> got = new HashSet<>();
        int minF = 99, maxF = 0;
        for (int s = 0; s < n; s++) {
            if (fr[s] < 0) continue;
            sounding++;
            if (firstSound < 0) firstSound = s;
            int midi = strings[s] + capo + fr[s];
            got.add(mod12(midi));
            if (midi < lowNote) { lowNote = midi; lowPc = mod12(midi); }
            if (fr[s] > 0) { minF = Math.min(minF, fr[s]); maxF = Math.max(maxF, fr[s]); }
        }
        if (!got.containsAll(required)) return;
        int minSound = n <= 4 ? n : Math.max(4, n - 2);
        if (sounding < minSound) return;
        // cuerdas sin tocar solo por el lado grave (salvo en instrumentos de 4 cuerdas o menos)
        for (int s = firstSound; s < n; s++) if (fr[s] < 0 && n > 4) return;
        if (maxF > 0 && maxF - minF > 3) return;
        // dedos: cejilla si hay 2+ cuerdas en el traste más bajo y hace falta
        int fretted = 0, atMin = 0;
        for (int f : fr) if (f > 0) { fretted++; if (f == minF) atMin++; }
        int barre = 0, fingersNeeded = fretted;
        if (fretted > 4 || (atMin >= 2 && minF > 0 && fretted > 3)) {
            // cejilla en minF: todas las cuerdas desde la primera en minF hasta la última deben estar en ≥ minF o al aire no
            int first = -1, last = -1;
            for (int s = 0; s < n; s++) if (fr[s] == minF) { if (first < 0) first = s; last = s; }
            boolean ok = true;
            for (int s = first; s <= last; s++) if (fr[s] == 0) ok = false;
            if (!ok) return;
            barre = minF;
            fingersNeeded = 1;
            for (int f : fr) if (f > minF) fingersNeeded++;
        }
        if (fingersNeeded > 4) return;
        String key = Arrays.toString(fr);
        if (!seen.add(key)) return;
        Voicing v = new Voicing();
        v.frets = fr.clone();
        v.barre = barre;
        v.fingers = fingers(fr, barre);
        int score = 0;
        if (lowPc != bassPc) score += 60;                      // que el bajo sea la fundamental
        score += (n - sounding) * 6;
        score += barre > 0 ? 25 : 0;
        score += (maxF > 0 ? minF : 0) * 4;                    // mejor cerca de la cejuela
        score += (maxF - (minF == 99 ? 0 : minF)) * 3;
        score += fingersNeeded * 2;
        for (int f : fr) if (f == 0) score -= 2;               // las cuerdas al aire suenan bien y son fáciles
        v.score = score;
        out.add(v);
    }

    static int[] fingers(int[] fr, int barre) {
        int[] fg = new int[fr.length];
        List<int[]> spots = new ArrayList<>();
        for (int s = 0; s < fr.length; s++) if (fr[s] > 0 && !(barre > 0 && fr[s] == barre)) spots.add(new int[]{fr[s], s});
        Collections.sort(spots, (a, b) -> a[0] != b[0] ? a[0] - b[0] : a[1] - b[1]);
        int next = barre > 0 ? 2 : 1;
        for (int[] sp : spots) fg[sp[1]] = Math.min(4, next++);
        if (barre > 0) for (int s = 0; s < fr.length; s++) if (fr[s] == barre) fg[s] = 1;
        return fg;
    }

    // ------------------------------------------------------------------ acordes de una canción
    static final Pattern INLINE = Pattern.compile("\\[([^\\]\\s]{1,12})\\]");

    /** Acordes que salen en un texto ChordPro, en orden de aparición y sin repetir. */
    public static List<Chord> chordsIn(String chordPro, String notation) {
        List<Chord> l = new ArrayList<>();
        Matcher m = INLINE.matcher(chordPro);
        while (m.find()) {
            Chord c = parseChord(m.group(1), notation);
            if (c != null && !l.contains(c)) l.add(c);
        }
        return l;
    }

    /** Cambia cada [acorde] del texto (transporte, simplificar…). */
    public interface ChordMap { Chord map(Chord c); }

    public static String mapChords(String text, String notation, boolean flats, ChordMap f) {
        Matcher m = INLINE.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            Chord c = parseChord(m.group(1), notation);
            String rep = c == null ? m.group() : "[" + f.map(c).name(notation, flats) + "]";
            m.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** Tonalidad probable a partir de los acordes (mayor o menor). Devuelve {pc, 0 mayor / 1 menor}. */
    public static int[] guessKey(List<Chord> chords) {
        if (chords.isEmpty()) return new int[]{0, 0};
        int best = 0, bestMode = 0, bestScore = -99;
        int[] major = {0, 2, 4, 5, 7, 9, 11};
        for (int k = 0; k < 12; k++) for (int mode = 0; mode < 2; mode++) {
            int tonic = mode == 0 ? k : mod12(k + 3);    // menor relativa comparte escala
            int score = 0;
            for (Chord c : chords) {
                boolean in = false;
                for (int d : major) if (mod12(k + d) == c.root) in = true;
                score += in ? 2 : -2;
                if (c.root == (mode == 0 ? k : mod12(k + 9))) score += 3;
            }
            if (chords.get(0).root == (mode == 0 ? k : mod12(k + 9))) score += 4;
            Chord last = chords.get(chords.size() - 1);
            if (last.root == (mode == 0 ? k : mod12(k + 9))) score += 2;
            if (score > bestScore) { bestScore = score; best = mode == 0 ? k : mod12(k + 9); bestMode = mode; }
        }
        return new int[]{best, bestMode};
    }

    /** Progresiones típicas por tonalidad (grados). */
    public static final String[][] PROGRESSIONS = {
            {"Pop (I–V–vi–IV)", "0:,7:,9:m,5:"},
            {"Clásica (I–IV–V)", "0:,5:,7:"},
            {"Balada (vi–IV–I–V)", "9:m,5:,0:,7:"},
            {"50s (I–vi–IV–V)", "0:,9:m,5:,7:"},
            {"Jazz (ii–V–I)", "2:m7,7:7,0:maj7"},
            {"Andaluza (i–VII–VI–V)", "0:m,10:,8:,7:"},
            {"Blues (I–IV–I–V)", "0:7,5:7,0:7,7:7"},
    };

    public static List<Chord> progression(String spec, int key) {
        List<Chord> l = new ArrayList<>();
        for (String it : spec.split(",")) {
            String[] p = it.split(":", -1);
            Chord c = new Chord();
            c.root = mod12(key + Integer.parseInt(p[0]));
            c.type = p[1];
            l.add(c);
        }
        return l;
    }

    // ------------------------------------------------------------------ alternativas a un acorde
    public static final class Alt { public final Chord chord; public final String why; Alt(Chord c, String w) { chord = c; why = w; } }

    public static List<Alt> alternatives(Chord c, int[] strings) {
        List<Alt> l = new ArrayList<>();
        boolean minor = false;
        for (int i : c.intervals()) if (i == 3) minor = true;
        String[] easy = minor ? new String[]{"m", "m7", "madd9"} : new String[]{"", "maj7", "7", "sus2", "sus4", "add9", "6"};
        // más fáciles: misma fundamental, posición sin cejilla
        for (String t : easy) {
            Chord x = new Chord(); x.root = c.root; x.type = t;
            if (x.equals(c)) continue;
            List<Voicing> v = voicings(x, strings, 0, 1);
            boolean easyShape = !v.isEmpty() && !v.get(0).hard();
            List<Voicing> vc = voicings(c, strings, 0, 1);
            boolean origHard = vc.isEmpty() || vc.get(0).hard();
            if (easyShape && origHard) l.add(new Alt(x, "Más fácil (sin cejilla)"));
        }
        // con más color
        String[] color = minor ? new String[]{"m7", "madd9", "m9"} : new String[]{"add9", "sus2", "sus4", "maj7", "6", "7"};
        for (String t : color) {
            Chord x = new Chord(); x.root = c.root; x.type = t;
            if (x.equals(c) || containsChord(l, x)) continue;
            l.add(new Alt(x, "Con más color"));
        }
        // sustitutos de la misma función
        Chord rel = new Chord();
        if (minor) { rel.root = mod12(c.root + 3); rel.type = ""; l.add(new Alt(rel, "Relativo mayor (misma función)")); }
        else { rel.root = mod12(c.root + 9); rel.type = "m"; l.add(new Alt(rel, "Relativo menor (misma función)")); }
        Chord third = new Chord();
        third.root = mod12(c.root + (minor ? 8 : 4)); third.type = minor ? "" : "m";
        l.add(new Alt(third, minor ? "Sexto grado (suave)" : "Tercer grado (suave)"));
        if (c.type.equals("7")) { Chord tri = new Chord(); tri.root = mod12(c.root + 6); tri.type = "7"; l.add(new Alt(tri, "Sustituto tritonal (jazz)")); }
        return l;
    }

    static boolean containsChord(List<Alt> l, Chord c) { for (Alt a : l) if (a.chord.equals(c)) return true; return false; }

    /** Mejor cejilla (capo) para tocar más acordes abiertos: devuelve el traste (0 = sin cejilla). */
    public static int bestCapo(List<Chord> chords, int[] strings) {
        int best = 0, bestHard = Integer.MAX_VALUE;
        for (int capo = 0; capo <= 7; capo++) {
            int hard = 0;
            for (Chord c : chords) {
                List<Voicing> v = voicings(c, strings, capo, 1, 2);
                if (v.isEmpty() || v.get(0).hard() || v.get(0).max() > 4) hard++;
            }
            if (hard < bestHard) { bestHard = hard; best = capo; }
        }
        return best;
    }

    // ------------------------------------------------------------------ armónicas
    public static final class Harp {
        public final String id, name;
        public final int[] blow, draw;     // midi por agujero (1..10 → índice 0..9)
        Harp(String id, String name, int[] b, int[] d) { this.id = id; this.name = name; blow = b; draw = d; }
        public int holes() { return blow.length; }
    }

    /** Diatónica Richter en Do. */
    public static final Harp HARP_C = new Harp("harp_c", "Armónica diatónica en Do",
            new int[]{60, 64, 67, 72, 76, 79, 84, 88, 91, 96}, new int[]{62, 67, 71, 74, 77, 81, 83, 86, 89, 93});
    /**
     * Lee Oskar Melody Maker «C»: se toca en Do en 2.ª posición. Construida sobre una Fa con el soplado 3, 6 y 9 un tono
     * más alto y el aspirado 5 y 9 medio tono más alto. Conviene comprobarla con «Calibrar con mi armónica».
     */
    public static final Harp HARP_MM_C = new Harp("harp_mm_c", "Melody Maker C",
            new int[]{65, 69, 74, 77, 81, 86, 89, 93, 98, 101}, new int[]{67, 72, 76, 79, 83, 86, 88, 91, 95, 98});

    public static Harp harp(Context c, String id) {
        if (id != null && id.startsWith("cal:")) {
            String raw = prefs(c).getString("harp_cal_" + id.substring(4), "");
            String[] p = raw.split(";");
            if (p.length == 2) try {
                String[] b = p[0].split(","), d = p[1].split(",");
                int[] bb = new int[b.length], dd = new int[d.length];
                for (int i = 0; i < b.length; i++) bb[i] = Integer.parseInt(b[i]);
                for (int i = 0; i < d.length; i++) dd[i] = Integer.parseInt(d[i]);
                return new Harp(id, "⭐ " + id.substring(4), bb, dd);
            } catch (Exception ignored) {}
        }
        if (HARP_MM_C.id.equals(id)) return HARP_MM_C;
        return HARP_C;
    }

    public static List<String[]> harps(Context c) {
        List<String[]> l = new ArrayList<>();
        l.add(new String[]{HARP_C.id, HARP_C.name});
        l.add(new String[]{HARP_MM_C.id, HARP_MM_C.name});
        for (String n : prefs(c).getString("harp_cal_names", "").split("\n")) if (!n.trim().isEmpty()) l.add(new String[]{"cal:" + n, "⭐ " + n});
        return l;
    }

    /** Una forma de tocar una nota: agujero, soplar/aspirar y cuántos semitonos de bend. */
    public static final class HarpNote {
        public int hole; public boolean draw; public int bend; public int cost;
        public String tab() {
            StringBuilder b = new StringBuilder(draw ? "-" : "").append(hole);
            for (int i = 0; i < bend; i++) b.append('\'');
            return b.toString();
        }
    }

    /** Todas las maneras de sacar esa nota en esa armónica (la más fácil primero). */
    public static List<HarpNote> harpWays(Harp h, int midi) {
        List<HarpNote> l = new ArrayList<>();
        for (int i = 0; i < h.holes(); i++) {
            int b = h.blow[i], d = h.draw[i];
            if (b == midi) l.add(hn(i + 1, false, 0, 0));
            if (d == midi && d != b) l.add(hn(i + 1, true, 0, 0));
            else if (d == midi) l.add(hn(i + 1, true, 0, 1));
            if (d > b && midi < d && midi > b) l.add(hn(i + 1, true, d - midi, 3 * (d - midi)));     // bend aspirando
            if (b > d && midi < b && midi > d) l.add(hn(i + 1, false, b - midi, 4 * (b - midi)));    // bend soplando
        }
        Collections.sort(l, (x, y) -> x.cost - y.cost);
        return l;
    }

    static HarpNote hn(int hole, boolean draw, int bend, int cost) { HarpNote n = new HarpNote(); n.hole = hole; n.draw = draw; n.bend = bend; n.cost = cost; return n; }

    /** Resultado de pasar una melodía a la armónica. */
    public static final class HarpPlan {
        public int shift;                 // semitonos que se movió la melodía (0 = tal cual)
        public int cost, missing, bends;
        public List<HarpNote> notes = new ArrayList<>();   // null = esa nota no existe en la armónica
    }

    public static HarpPlan planHarp(Harp h, List<Integer> melody, int shift) {
        HarpPlan p = new HarpPlan();
        p.shift = shift;
        int prevHole = -1;
        for (int m : melody) {
            List<HarpNote> w = harpWays(h, m + shift);
            if (w.isEmpty()) { p.notes.add(null); p.missing++; p.cost += 100; continue; }
            HarpNote best = w.get(0);
            if (prevHole > 0) for (HarpNote x : w) if (x.cost == best.cost && Math.abs(x.hole - prevHole) < Math.abs(best.hole - prevHole)) best = x;
            p.notes.add(best);
            p.cost += best.cost;
            if (best.bend > 0) p.bends++;
            prevHole = best.hole;
        }
        return p;
    }

    /** Busca cuánto mover la melodía (por octavas y, si se permite, de tono) para que salga con menos bends. */
    public static HarpPlan bestHarp(Harp h, List<Integer> melody, boolean allowKeyChange) {
        HarpPlan best = null;
        for (int sh = -36; sh <= 36; sh++) {
            if (!allowKeyChange && sh % 12 != 0) continue;
            HarpPlan p = planHarp(h, melody, sh);
            int penalty = (allowKeyChange ? Math.min(Math.abs(mod12(sh)), 12 - Math.abs(mod12(sh))) : 0) + Math.abs(sh) / 12;
            if (best == null || p.cost + penalty < best.cost + bestPenalty(best, allowKeyChange)) best = p;
        }
        return best;
    }

    static int bestPenalty(HarpPlan p, boolean allow) { int s = mod12(p.shift); return (allow ? Math.min(s, 12 - s) : 0) + Math.abs(p.shift) / 12; }

    /** Lee una melodía escrita: «Do Re Mi», «C4 D4 E4», «sol3 la3». Las notas sin octava siguen a la anterior (la más cercana). */
    public static List<Integer> parseMelody(String text, String notation) {
        List<Integer> l = new ArrayList<>();
        int prev = 60;
        for (String tk : text.split("[\\s,|·-]+")) {
            if (tk.isEmpty()) continue;
            String t = tk.replaceAll("[()\\[\\]{}.!?]", "");
            if (t.isEmpty()) continue;
            boolean hasOct = t.matches(".*-?\\d$");
            int m = parseNote(t, 4, notation);
            if (m < 0) continue;
            if (!hasOct && !l.isEmpty()) {           // la octava más cercana a la nota anterior
                int pc = mod12(m), best = m, bd = 99;
                for (int o = -1; o <= 8; o++) { int c = (o + 1) * 12 + pc; if (Math.abs(c - prev) < bd) { bd = Math.abs(c - prev); best = c; } }
                m = best;
            }
            l.add(m);
            prev = m;
        }
        return l;
    }
}
