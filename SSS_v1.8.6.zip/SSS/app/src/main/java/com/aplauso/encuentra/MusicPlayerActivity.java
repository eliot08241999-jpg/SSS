package com.aplauso.encuentra;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * v1.8.2 · 🎵 MI MÚSICA: biblioteca (canciones, álbumes, artistas, carpetas, listas), buscador, cola, aleatorio, repetir,
 * ecualizador, temporizador para dormir, letras sincronizadas (.lrc), ver los acordes en tu Cancionero o transcribirla,
 * y un visualizador neón que baila con la música.
 */
public class MusicPlayerActivity extends NeonActivity {
    static final int REQ_PERM = 41;
    final Handler h = new Handler(Looper.getMainLooper());
    List<MusicPlayerService.Track> lib = new ArrayList<>();
    List<Object> rows = new ArrayList<>();          // Track o String[] {grupo, subtítulo, clave}
    int tab;                                          // 0 canciones · 1 álbumes · 2 artistas · 3 carpetas · 4 listas
    String group;                                     // dentro de un álbum / artista / carpeta / lista
    String query = "";
    TextView titleTv, artistTv, timeTv, playBtn, shufBtn, repBtn, sleepBtn, backBtn;
    ImageView artIv;
    SeekBar seek;
    boolean dragging;
    ListView list;
    Adapter adapter;
    final List<TextView> tabBtns = new ArrayList<>();
    Bars bars;
    android.media.audiofx.Visualizer viz;
    int vizSession = -1;
    long artFor = -1;
    final Runnable onChange = () -> h.post(this::refreshNow);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dpi(14), dpi(14), dpi(14), dpi(6));
        root.addView(topBar("🎵 MI MÚSICA"), gapBelow(8));

        // ---- lo que suena
        LinearLayout now = panel(null);
        LinearLayout r1 = new LinearLayout(this);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        artIv = new ImageView(this);
        artIv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        artIv.setBackground(frame(10));
        r1.addView(artIv, new LinearLayout.LayoutParams(dpi(58), dpi(58)));
        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        tcol.setPadding(dpi(10), 0, 0, 0);
        titleTv = neonText("—", 16);
        titleTv.setSingleLine(true);
        titleTv.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
        titleTv.setSelected(true);
        artistTv = text("", 12);
        artistTv.setSingleLine(true);
        artistTv.setTextColor(Color.rgb(170, 180, 200));
        tcol.addView(titleTv);
        tcol.addView(artistTv);
        r1.addView(tcol, new LinearLayout.LayoutParams(0, -2, 1));
        now.addView(r1, gapBelow(4));
        bars = new Bars(this);
        now.addView(bars, new LinearLayout.LayoutParams(-1, dpi(34)));
        seek = new SeekBar(this);
        seek.setMax(1000);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean user) { if (user) timeTv.setText(fmt(v / 1000f * MusicPlayerService.duration()) + " / " + fmt(MusicPlayerService.duration())); }
            public void onStartTrackingTouch(SeekBar s) { dragging = true; }
            public void onStopTrackingTouch(SeekBar s) { dragging = false; MusicPlayerService.seek(Math.round(s.getProgress() / 1000f * MusicPlayerService.duration())); }
        });
        now.addView(seek);
        timeTv = text("0:00 / 0:00", 11);
        timeTv.setGravity(Gravity.END);
        now.addView(timeTv);
        LinearLayout ctl = new LinearLayout(this);
        shufBtn = ctlBtn(ctl, "🔀", v -> { MusicPlayerService.shuffle = !MusicPlayerService.shuffle; refreshNow(); });
        ctlBtn(ctl, "⏮", v -> MusicPlayerService.send(this, "prev"));
        playBtn = ctlBtn(ctl, "▶", v -> {
            if (MusicPlayerService.running) MusicPlayerService.send(this, "toggle");
            else if (!lib.isEmpty()) MusicPlayerService.send(this, "resume_last");
        });
        ctlBtn(ctl, "⏭", v -> MusicPlayerService.send(this, "next"));
        repBtn = ctlBtn(ctl, "🔁", v -> { MusicPlayerService.repeat = (MusicPlayerService.repeat + 1) % 3; refreshNow(); });
        now.addView(ctl, gapBelow(4));
        LinearLayout more = new LinearLayout(this);
        sleepBtn = ctlBtn(more, "⏲", v -> sleepMenu());
        ctlBtn(more, "🎚", v -> eqMenu());
        ctlBtn(more, "💬", v -> lyrics());
        ctlBtn(more, "🎸", v -> chords(MusicPlayerService.current()));
        ctlBtn(more, "📃", v -> queueDialog());
        for (int i = 0; i < more.getChildCount(); i++) ((TextView) more.getChildAt(i)).setTextSize(15);
        now.addView(more);
        root.addView(now, gapBelow(8));

        // ---- buscador y pestañas
        EditText search = new EditText(this);
        search.setHint(L.t("🔎 Buscar canción, artista o álbum"));
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.GRAY);
        search.setSingleLine(true);
        search.setBackground(frame(10));
        search.setPadding(dpi(10), dpi(7), dpi(10), dpi(7));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { query = Actions.norm(e.toString()); fill(); }
        });
        root.addView(search, gapBelow(6));
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        LinearLayout tabs = new LinearLayout(this);
        String[] tn = {"🎵 Canciones", "💿 Álbumes", "🎤 Artistas", "📁 Carpetas", "📃 Listas"};
        for (int i = 0; i < tn.length; i++) {
            final int k = i;
            TextView t = button(tn[i], v -> { tab = k; group = null; fill(); });
            t.setTextSize(12);
            t.setPadding(dpi(10), dpi(7), dpi(10), dpi(7));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dpi(4);
            tabs.addView(t, lp);
            tabBtns.add(t);
        }
        hs.addView(tabs);
        root.addView(hs, gapBelow(4));
        backBtn = button("", v -> { group = null; fill(); });
        backBtn.setTextSize(12);
        root.addView(backBtn, gapBelow(4));

        list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(dpi(4));
        adapter = new Adapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((pa, v, i, id) -> tap(i));
        list.setOnItemLongClickListener((pa, v, i, id) -> { longTap(i); return true; });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(makeRoot(root));

        if (hasPerm()) loadLib(); else requestPermissions(new String[]{perm()}, REQ_PERM);
    }

    TextView ctlBtn(LinearLayout row, String label, View.OnClickListener l) {
        TextView t = button(label, l);
        t.setTextSize(18);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dpi(6), 0, dpi(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.leftMargin = lp.rightMargin = dpi(2);
        row.addView(t, lp);
        return t;
    }

    String perm() { return android.os.Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE; }
    boolean hasPerm() { return checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED; }

    @Override
    public void onRequestPermissionsResult(int req, String[] p, int[] r) {
        super.onRequestPermissionsResult(req, p, r);
        if (req == REQ_PERM) { if (hasPerm()) loadLib(); else toast(L.t("Sin permiso para leer tu música no puedo enseñártela.")); }
        if (req == REQ_PERM + 1) startViz();
    }

    void loadLib() {
        new Thread(() -> {
            List<MusicPlayerService.Track> l = MusicPlayerService.library(this);
            h.post(() -> { lib = l; fill(); if (l.isEmpty()) toast(L.t("No encuentro música en tu teléfono.")); });
        }).start();
    }

    // ================================================================== lista
    void fill() {
        rows.clear();
        for (int i = 0; i < tabBtns.size(); i++) tabBtns.get(i).setAlpha(i == tab ? 1f : 0.55f);
        backBtn.setVisibility(group == null ? View.GONE : View.VISIBLE);
        backBtn.setText("← " + (group == null ? "" : group));
        if (tab == 0 || group != null) {
            for (MusicPlayerService.Track t : tracksOf()) if (match(t)) rows.add(t);
            if (tab == 0 && group == null && !rows.isEmpty()) rows.add(0, new String[]{L.t("🔀 Todo en aleatorio"), rows.size() + " " + L.t("canciones"), "*shuffle"});
        } else if (tab == 4) {
            rows.add(new String[]{L.t("＋ Nueva lista"), "", "*new"});
            for (String n : lists().keySet()) rows.add(new String[]{"📃 " + n, lists().get(n).length() + " " + L.t("canciones"), n});
        } else {
            Map<String, Integer> g = new LinkedHashMap<>();
            Map<String, String> sub = new LinkedHashMap<>();
            for (MusicPlayerService.Track t : lib) {
                if (!match(t)) continue;
                String k = key(t);
                if (k.isEmpty()) k = L.t("(Sin nombre)");
                g.put(k, g.containsKey(k) ? g.get(k) + 1 : 1);
                if (tab == 1 && !sub.containsKey(k)) sub.put(k, t.artist);
            }
            List<String> ks = new ArrayList<>(g.keySet());
            Collections.sort(ks, String.CASE_INSENSITIVE_ORDER);
            for (String k : ks) rows.add(new String[]{(tab == 1 ? "💿 " : tab == 2 ? "🎤 " : "📁 ") + k,
                    (sub.containsKey(k) && !sub.get(k).isEmpty() ? sub.get(k) + " · " : "") + g.get(k) + " " + L.t("canciones"), k});
        }
        adapter.notifyDataSetChanged();
    }

    String key(MusicPlayerService.Track t) { return tab == 1 ? t.album : tab == 2 ? t.artist : tab == 3 ? t.folder : ""; }

    boolean match(MusicPlayerService.Track t) {
        return query.isEmpty() || Actions.norm(t.title + " " + t.artist + " " + t.album + " " + t.folder).contains(query);
    }

    List<MusicPlayerService.Track> tracksOf() {
        if (group == null) return lib;
        List<MusicPlayerService.Track> l = new ArrayList<>();
        if (tab == 4) {
            JSONArray a = lists().get(group);
            Map<Long, MusicPlayerService.Track> by = new java.util.HashMap<>();
            for (MusicPlayerService.Track t : lib) by.put(t.id, t);
            if (a != null) for (int i = 0; i < a.length(); i++) { MusicPlayerService.Track t = by.get(a.optLong(i)); if (t != null) l.add(t); }
            return l;
        }
        String noName = L.t("(Sin nombre)");
        for (MusicPlayerService.Track t : lib) { String k = key(t); if (k.equals(group) || (k.isEmpty() && group.equals(noName))) l.add(t); }
        return l;
    }

    List<MusicPlayerService.Track> visibleTracks() {
        List<MusicPlayerService.Track> l = new ArrayList<>();
        for (Object o : rows) if (o instanceof MusicPlayerService.Track) l.add((MusicPlayerService.Track) o);
        return l;
    }

    void tap(int i) {
        Object o = rows.get(i);
        if (o instanceof MusicPlayerService.Track) {
            List<MusicPlayerService.Track> q = visibleTracks();
            MusicPlayerService.play(this, q, q.indexOf(o));
            return;
        }
        String[] g = (String[]) o;
        if (g[2].equals("*shuffle")) {
            List<MusicPlayerService.Track> q = visibleTracks();
            Collections.shuffle(q);
            MusicPlayerService.shuffle = true;
            MusicPlayerService.play(this, q, 0);
        } else if (g[2].equals("*new")) newList(null);
        else { group = g[2]; fill(); }
    }

    void longTap(int i) {
        Object o = rows.get(i);
        if (o instanceof String[]) {
            String[] g = (String[]) o;
            if (tab == 4 && !g[2].startsWith("*"))
                new android.app.AlertDialog.Builder(this).setTitle(g[2]).setItems(new String[]{L.t("▶ Reproducir"), L.t("🗑 Borrar lista")}, (d, w) -> {
                    if (w == 0) { group = g[2]; fill(); List<MusicPlayerService.Track> q = visibleTracks(); if (!q.isEmpty()) MusicPlayerService.play(this, q, 0); }
                    else { Map<String, JSONArray> m = lists(); m.remove(g[2]); saveLists(m); fill(); }
                }).show();
            return;
        }
        MusicPlayerService.Track t = (MusicPlayerService.Track) o;
        List<String> opts = new ArrayList<>();
        opts.add(L.t("⏭ Reproducir a continuación"));
        opts.add(L.t("➕ Añadir a la cola"));
        opts.add(L.t("📃 Añadir a una lista…"));
        if (tab == 4 && group != null) opts.add(L.t("➖ Quitar de esta lista"));
        opts.add(L.t("🎸 Ver los acordes"));
        opts.add(L.t("🎼 Transcribir (acordes, notas y letra)"));
        new android.app.AlertDialog.Builder(this).setTitle(t.title).setItems(opts.toArray(new String[0]), (d, w) -> {
            String s = opts.get(w);
            if (s.startsWith("⏭")) { MusicPlayerService.addNext(t); toast(L.t("Sonará después.")); }
            else if (s.startsWith("➕")) { MusicPlayerService.addEnd(t); toast(L.t("Añadida a la cola.")); }
            else if (s.startsWith("📃")) addToList(t);
            else if (s.startsWith("➖")) {
                Map<String, JSONArray> m = lists(); JSONArray a = m.get(group), b2 = new JSONArray();
                if (a != null) for (int k = 0; k < a.length(); k++) if (a.optLong(k) != t.id) b2.put(a.optLong(k));
                m.put(group, b2); saveLists(m); fill();
            }
            else if (s.startsWith("🎸")) chords(t);
            else startActivity(new Intent(this, TranscribeActivity.class).setData(t.uri()));
        }).show();
    }

    // ================================================================== listas
    Map<String, JSONArray> lists() {
        Map<String, JSONArray> m = new LinkedHashMap<>();
        try {
            JSONObject o = new JSONObject(p.getString("mp_lists", "{}"));
            for (java.util.Iterator<String> it = o.keys(); it.hasNext(); ) { String k = it.next(); m.put(k, o.getJSONArray(k)); }
        } catch (Exception ignored) {}
        return m;
    }

    void saveLists(Map<String, JSONArray> m) {
        try { JSONObject o = new JSONObject(); for (Map.Entry<String, JSONArray> e : m.entrySet()) o.put(e.getKey(), e.getValue()); p.edit().putString("mp_lists", o.toString()).apply(); } catch (Exception ignored) {}
    }

    void newList(MusicPlayerService.Track first) {
        EditText e = new EditText(this);
        e.setHint(L.t("Nombre de la lista"));
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Nueva lista")).setView(e).setPositiveButton("OK", (d, w) -> {
            String n = e.getText().toString().trim();
            if (n.isEmpty()) return;
            Map<String, JSONArray> m = lists();
            JSONArray a = m.containsKey(n) ? m.get(n) : new JSONArray();
            if (first != null) a.put(first.id);
            m.put(n, a); saveLists(m); fill();
            if (first != null) toast(L.t("Añadida a") + " «" + n + "».");
        }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    void addToList(MusicPlayerService.Track t) {
        List<String> names = new ArrayList<>(lists().keySet());
        names.add(0, L.t("＋ Nueva lista"));
        new android.app.AlertDialog.Builder(this).setItems(names.toArray(new String[0]), (d, w) -> {
            if (w == 0) { newList(t); return; }
            Map<String, JSONArray> m = lists(); m.get(names.get(w)).put(t.id); saveLists(m);
            toast(L.t("Añadida a") + " «" + names.get(w) + "».");
        }).show();
    }

    // ================================================================== extras
    void sleepMenu() {
        String[] o = {L.t("Apagado"), "15 min", "30 min", "45 min", "1 h", "1 h 30", L.t("Al acabar esta canción")};
        long[] m = {0, 15, 30, 45, 60, 90, -1};
        new android.app.AlertDialog.Builder(this).setTitle(L.t("⏲ Temporizador para dormir")).setItems(o, (d, w) -> {
            MusicPlayerService.setSleep(m[w] <= 0 ? m[w] : System.currentTimeMillis() + m[w] * 60_000);
            toast(w == 0 ? L.t("Sin temporizador.") : L.t("Bajaré el volumen poco a poco y pararé."));
            refreshNow();
        }).show();
    }

    void eqMenu() {
        String[] pr = MusicPlayerService.presets();
        List<String> o = new ArrayList<>();
        o.add(L.t("Normal (sin ecualizador)"));
        Collections.addAll(o, pr);
        o.add(L.t("🔊 Graves: ") + (p.getInt("mp_bass", 0) > 0 ? L.t("reforzados") : L.t("normales")));
        new android.app.AlertDialog.Builder(this).setTitle(L.t("🎚 Ecualizador")).setItems(o.toArray(new String[0]), (d, w) -> {
            if (w == o.size() - 1) p.edit().putInt("mp_bass", p.getInt("mp_bass", 0) > 0 ? 0 : 700).apply();
            else p.edit().putInt("mp_eq", w - 1).apply();
            MusicPlayerService.refx(this);
            if (pr.length == 0 && w < o.size() - 1) toast(L.t("Empieza a reproducir para ver los modos de tu teléfono."));
        }).show();
    }

    /** Letra sincronizada: un .lrc con el mismo nombre al lado de la canción. */
    void lyrics() {
        MusicPlayerService.Track t = MusicPlayerService.current();
        if (t == null) { toast(L.t("Pon una canción primero.")); return; }
        List<float[]> times = new ArrayList<>();
        List<String> lines = new ArrayList<>();
        try {
            File f = new File(t.path.replaceAll("\\.[A-Za-z0-9]{2,4}$", "") + ".lrc");
            if (f.exists()) for (String l : new String(java.nio.file.Files.readAllBytes(f.toPath()), java.nio.charset.StandardCharsets.UTF_8).split("\n")) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\[(\\d+):(\\d+(?:[.:]\\d+)?)\\]").matcher(l);
                String text = l.replaceAll("\\[[^\\]]*\\]", "").trim();
                while (m.find()) { times.add(new float[]{Integer.parseInt(m.group(1)) * 60 + Float.parseFloat(m.group(2).replace(':', '.')), lines.size()}); }
                if (l.matches("^\\s*\\[\\d+:.*")) lines.add(text);
            }
        } catch (Exception ignored) {}
        if (lines.isEmpty()) {
            new android.app.AlertDialog.Builder(this).setMessage(L.t("Esta canción no tiene letra sincronizada (un archivo .lrc con el mismo nombre al lado). ¿Quieres transcribirla? Te saco los acordes y la letra para tu Cancionero."))
                    .setPositiveButton(L.t("🎼 Transcribir"), (d, w) -> startActivity(new Intent(this, TranscribeActivity.class).setData(t.uri())))
                    .setNegativeButton(L.t("Cancelar"), null).show();
            return;
        }
        Collections.sort(times, (a, b) -> Float.compare(a[0], b[0]));
        TextView tv = text("", 17);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dpi(16), dpi(16), dpi(16), dpi(16));
        android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this).setView(tv).setPositiveButton("OK", null).show();
        int neon = Neon.color(this);
        Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (!dlg.isShowing()) return;
            float now = MusicPlayerService.position() / 1000f;
            int cur = -1;
            for (float[] x : times) if (x[0] <= now) cur = (int) x[1];
            android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
            for (int i = Math.max(0, cur - 2); i < Math.min(lines.size(), Math.max(0, cur) + 4); i++) {
                int s = sb.length();
                sb.append(lines.get(i)).append("\n\n");
                if (i == cur) {
                    sb.setSpan(new android.text.style.ForegroundColorSpan(neon), s, sb.length(), 0);
                    sb.setSpan(new android.text.style.RelativeSizeSpan(1.25f), s, sb.length(), 0);
                } else sb.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(150, 160, 180)), s, sb.length(), 0);
            }
            tv.setText(sb);
            h.postDelayed(tick[0], 250);
        };
        h.post(tick[0]);
    }

    /** Busca la canción en tu Cancionero por el título; si no está, te ofrece transcribirla. */
    void chords(MusicPlayerService.Track t) {
        if (t == null) { toast(L.t("Pon una canción primero.")); return; }
        File dir = new File(getFilesDir(), "songs");
        File[] fs = dir.listFiles();
        String want = Actions.norm(t.title.replaceAll("\\(.*?\\)|\\[.*?\\]", ""));
        if (fs != null) for (File f : fs) {
            JSONObject o = SongbookActivity.read(f);
            String have = Actions.norm(o.optString("title"));
            if (!have.isEmpty() && !want.isEmpty() && (have.contains(want) || want.contains(have))) {
                startActivity(new Intent(this, SongbookActivity.class).putExtra("open_file", f.getAbsolutePath()));
                return;
            }
        }
        new android.app.AlertDialog.Builder(this).setMessage("«" + t.title + "» " + L.t("no está en tu Cancionero. ¿La transcribo? Te saco los acordes, la melodía y la letra."))
                .setPositiveButton(L.t("🎼 Transcribir"), (d, w) -> startActivity(new Intent(this, TranscribeActivity.class).setData(t.uri())))
                .setNegativeButton(L.t("Cancelar"), null).show();
    }

    void queueDialog() {
        List<MusicPlayerService.Track> q = MusicPlayerService.queue;
        if (q.isEmpty()) { toast(L.t("La cola está vacía.")); return; }
        String[] n = new String[Math.min(q.size(), 300)];
        for (int i = 0; i < n.length; i++) n[i] = (i == MusicPlayerService.pos ? "▶ " : "   ") + q.get(i).title + (q.get(i).artist.isEmpty() ? "" : " · " + q.get(i).artist);
        new android.app.AlertDialog.Builder(this).setTitle(L.t("📃 Cola")).setItems(n, (d, w) -> MusicPlayerService.play(this, q, w)).show();
    }

    // ================================================================== estado
    static String fmt(float ms) { int s = Math.round(ms / 1000f); return (s / 60) + ":" + String.format(java.util.Locale.ROOT, "%02d", s % 60); }

    final Runnable tick = new Runnable() {
        @Override public void run() {
            int d = MusicPlayerService.duration(), at = MusicPlayerService.position();
            if (!dragging && d > 0) { seek.setProgress(Math.round(1000f * at / d)); timeTv.setText(fmt(at) + " / " + fmt(d)); }
            if (MusicPlayerService.audioSession != vizSession && MusicPlayerService.running) startViz();
            h.postDelayed(this, 500);
        }
    };

    void refreshNow() {
        MusicPlayerService.Track t = MusicPlayerService.current();
        titleTv.setText(t == null ? L.t("Elige una canción") : t.title);
        artistTv.setText(t == null ? "" : t.artist + (t.album.isEmpty() ? "" : " · " + t.album));
        playBtn.setText(MusicPlayerService.playing ? "⏸" : "▶");
        shufBtn.setAlpha(MusicPlayerService.shuffle ? 1f : 0.45f);
        repBtn.setText(MusicPlayerService.repeat == 2 ? "🔂" : "🔁");
        repBtn.setAlpha(MusicPlayerService.repeat == 0 ? 0.45f : 1f);
        sleepBtn.setText(MusicPlayerService.sleepAt > 0 ? "⏲ " + Math.max(1, (MusicPlayerService.sleepAt - System.currentTimeMillis()) / 60000) + "′" : MusicPlayerService.sleepAt == -1 ? "⏲ ♪" : "⏲");
        if (t != null && t.id != artFor) {
            artFor = t.id;
            new Thread(() -> { android.graphics.Bitmap bm = MusicPlayerService.artOf(this, t, 160); h.post(() -> { if (bm != null) artIv.setImageBitmap(bm); else artIv.setImageDrawable(null); }); }).start();
        }
        bars.on = MusicPlayerService.playing;
        bars.invalidate();
        adapter.notifyDataSetChanged();
    }

    void startViz() {
        stopViz();
        vizSession = MusicPlayerService.audioSession;
        if (vizSession <= 0) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;   // el visualizador lo exige; sin él, barras de adorno
        try {
            viz = new android.media.audiofx.Visualizer(vizSession);
            viz.setCaptureSize(Math.min(256, android.media.audiofx.Visualizer.getCaptureSizeRange()[1]));
            viz.setDataCaptureListener(new android.media.audiofx.Visualizer.OnDataCaptureListener() {
                public void onWaveFormDataCapture(android.media.audiofx.Visualizer v, byte[] w, int r) {}
                public void onFftDataCapture(android.media.audiofx.Visualizer v, byte[] fft, int r) { bars.fft(fft); }
            }, Math.min(android.media.audiofx.Visualizer.getMaxCaptureRate(), 20000), false, true);
            viz.setEnabled(true);
        } catch (Throwable e) { viz = null; }
    }

    void stopViz() { if (viz != null) try { viz.setEnabled(false); viz.release(); } catch (Throwable ignored) {} viz = null; }

    @Override protected void onResume() { super.onResume(); MusicPlayerService.listeners.add(onChange); refreshNow(); h.post(tick); }
    @Override protected void onPause() { super.onPause(); MusicPlayerService.listeners.remove(onChange); h.removeCallbacks(tick); stopViz(); vizSession = -1; }

    // ================================================================== filas
    class Adapter extends BaseAdapter {
        public int getCount() { return rows.size(); }
        public Object getItem(int i) { return rows.get(i); }
        public long getItemId(int i) { return i; }
        public View getView(int i, View v, ViewGroup parent) {
            LinearLayout row;
            TextView a, b;
            if (v == null) {
                row = new LinearLayout(MusicPlayerActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
                row.setBackground(frame(10));
                a = text("", 14); b = text("", 11);
                a.setSingleLine(true); b.setSingleLine(true);
                a.setEllipsize(android.text.TextUtils.TruncateAt.END); b.setEllipsize(android.text.TextUtils.TruncateAt.END);
                b.setTextColor(Color.rgb(160, 170, 190));
                row.addView(a); row.addView(b);
            } else { row = (LinearLayout) v; a = (TextView) row.getChildAt(0); b = (TextView) row.getChildAt(1); }
            Object o = rows.get(i);
            if (o instanceof MusicPlayerService.Track) {
                MusicPlayerService.Track t = (MusicPlayerService.Track) o;
                MusicPlayerService.Track cur = MusicPlayerService.current();
                boolean on = cur != null && cur.id == t.id;
                a.setText((on ? "▶ " : "") + t.title);
                a.setTextColor(on ? Neon.color(MusicPlayerActivity.this) : Color.WHITE);
                b.setText((t.artist.isEmpty() ? "" : t.artist + " · ") + fmt(t.dur));
            } else {
                String[] g = (String[]) o;
                a.setText(g[0]); a.setTextColor(Color.WHITE);
                b.setText(g[1]);
            }
            b.setVisibility(b.getText().length() == 0 ? View.GONE : View.VISIBLE);
            return row;
        }
    }

    /** Barras neón: con el visualizador del sistema si hay permiso; si no, un baile suave de adorno. */
    static class Bars extends View {
        final float[] lv = new float[24];
        final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        volatile boolean on;
        long lastFft;
        Bars(Context c) { super(c); }
        void fft(byte[] f) {
            int n = f.length / 2;
            for (int i = 0; i < lv.length; i++) {
                int a = (int) (Math.pow(i / (float) lv.length, 2) * (n - 2)) + 1, b = Math.max(a + 1, (int) (Math.pow((i + 1) / (float) lv.length, 2) * (n - 2)) + 1);
                float m = 0;
                for (int k = a; k < b && 2 * k + 1 < f.length; k++) m = Math.max(m, (float) Math.hypot(f[2 * k], f[2 * k + 1]));
                float v = (float) Math.min(1, Math.log10(1 + m) / 2.1);
                lv[i] = Math.max(v, lv[i] * 0.8f);
            }
            lastFft = System.currentTimeMillis();
            postInvalidate();
        }
        @Override protected void onDraw(Canvas c) {
            int col = Neon.color(getContext());
            boolean live = System.currentTimeMillis() - lastFft < 400;
            float w = getWidth() / (float) lv.length;
            double t = System.currentTimeMillis() / 220.0;
            for (int i = 0; i < lv.length; i++) {
                float v = live ? lv[i] : on ? (float) (0.25 + 0.2 * Math.sin(t + i * 0.7) * Math.sin(t * 0.37 + i)) : 0.05f;
                float bh = Math.max(dp(2), v * getHeight());
                pt.setColor(col);
                pt.setAlpha(120 + (int) (135 * v));
                c.drawRoundRect(i * w + w * 0.18f, getHeight() - bh, (i + 1) * w - w * 0.18f, getHeight(), dp(2), dp(2), pt);
            }
            if (on && !live) postInvalidateDelayed(60);
        }
        float dp(float v) { return v * getResources().getDisplayMetrics().density; }
    }
}
