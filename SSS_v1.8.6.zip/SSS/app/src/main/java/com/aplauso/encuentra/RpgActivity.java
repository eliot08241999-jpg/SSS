package com.aplauso.encuentra;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Iterator;
import java.util.List;

/**
 * v1.8.2 · 🎮 ESTADO: la ficha de Chloe al estilo de los menús azules de los RPG de 16 bits. Su sprite en pixel art
 * (se mueve un poquito), nivel y EXP, clase, los 5 rasgos con 20 puntos para repartir, perfiles, logros y la colección
 * de frases raras.
 */
public class RpgActivity extends NeonActivity {
    final Handler h = new Handler(Looper.getMainLooper());
    int[] st;
    TextView freeTv, clsTv;
    final TextView[] valTv = new TextView[5];
    final View[][] pips = new View[5][Rpg.MAX];
    ImageView sprite;
    Bitmap[] frames;
    int frame;
    LinearLayout trophies;

    static final int BLUE_TOP = Color.rgb(56, 88, 216), BLUE_BOT = Color.rgb(16, 24, 112);
    static final Typeface PIX = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        st = Rpg.stats(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(14), dpi(14), dpi(14), dpi(24));
        col.addView(topBar("🎮 ESTADO"), gapBelow(10));

        // ---- personaje
        LinearLayout w1 = win();
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        sprite = new ImageView(this);
        sprite.setScaleType(ImageView.ScaleType.FIT_CENTER);
        r.addView(sprite, new LinearLayout.LayoutParams(dpi(96), dpi(124)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dpi(12), 0, 0, 0);
        info.addView(px("CHLOE", 20));
        clsTv = px("", 13);
        info.addView(clsTv);
        int exp = Rpg.exp(this), lv = Rpg.level(exp), a = Rpg.expFor(lv), z = Rpg.expFor(lv + 1);
        info.addView(px(L.t("NV") + " " + lv, 16));
        info.addView(px("EXP " + exp + " / " + z, 12));
        info.addView(bar((exp - a) / (float) Math.max(1, z - a), Color.rgb(120, 230, 255)), new LinearLayout.LayoutParams(-1, dpi(8)));
        TextView hint = px(L.t("Gana EXP tocándola, usando funciones y con logros."), 10);
        hint.setTextColor(Color.rgb(190, 200, 255));
        info.addView(hint);
        r.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        w1.addView(r);
        col.addView(w1, gapBelow(10));

        // ---- rasgos
        LinearLayout w2 = win();
        w2.addView(px("▶ " + L.t("RASGOS"), 15), gapBelow(6));
        for (int i = 0; i < 5; i++) w2.addView(statRow(i), gapBelow(6));
        freeTv = px("", 13);
        w2.addView(freeTv, gapBelow(4));
        TextView note = px(L.t("Cambian cómo te habla y lo que dice al tocarla. Con Picardía o Locura altas hace bromas inocentes (nunca con datos importantes; di «en serio» y para)."), 10);
        note.setTextColor(Color.rgb(190, 200, 255));
        w2.addView(note);
        col.addView(w2, gapBelow(10));

        // ---- perfiles
        LinearLayout w3 = win();
        w3.addView(px("▶ " + L.t("PERFILES"), 15), gapBelow(6));
        LinearLayout pr = new LinearLayout(this);
        pr.addView(pxBtn("💾 " + L.t("Guardar"), v -> saveProfile()), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.leftMargin = dpi(6);
        pr.addView(pxBtn("📂 " + L.t("Cargar"), v -> loadProfile()), lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, -2, 1); lp2.leftMargin = dpi(6);
        pr.addView(pxBtn("↺ " + L.t("Igualar"), v -> { st = new int[]{4, 4, 4, 4, 4}; apply(); }), lp2);
        w3.addView(pr);
        col.addView(w3, gapBelow(10));

        // ---- logros
        LinearLayout w4 = win();
        w4.addView(px("▶ " + L.t("LOGROS"), 15), gapBelow(6));
        trophies = new LinearLayout(this);
        trophies.setOrientation(LinearLayout.VERTICAL);
        w4.addView(trophies);
        col.addView(w4, gapBelow(10));

        // ---- colección
        LinearLayout w5 = win();
        w5.addView(px("▶ " + L.t("COLECCIÓN DE FRASES"), 15), gapBelow(6));
        int[] cl = TouchLines.collection(this);
        w5.addView(px("✨💜🌟 " + cl[0] + " / " + cl[1] + "  " + L.t("rarezas encontradas"), 13));
        w5.addView(bar(cl[0] / (float) Math.max(1, cl[1]), Color.rgb(255, 210, 120)), new LinearLayout.LayoutParams(-1, dpi(8)));
        w5.addView(px("👆 " + Achievements.touches(this) + " " + L.t("toques en total"), 12));
        int var = 0; for (String zn : new String[]{"pat", "cheek", "ear", "tickle"}) var += TouchLines.variety(zn);
        TextView vt = px("≈ " + var + " " + L.t("frases distintas posibles (cabeza, mejillas, orejas y cosquillas)"), 10);
        vt.setTextColor(Color.rgb(190, 200, 255));
        w5.addView(vt);
        col.addView(w5, gapBelow(10));

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(makeRoot(sv));
        apply();
        fillTrophies();
        buildSprite();
    }

    // ================================================================== estilo FF azul
    LinearLayout win() {
        LinearLayout w = new LinearLayout(this);
        w.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{BLUE_TOP, BLUE_BOT});
        g.setCornerRadius(dp(7));
        g.setStroke(dpi(3), Color.WHITE);
        w.setBackground(g);
        w.setPadding(dpi(14), dpi(12), dpi(14), dpi(12));
        return w;
    }

    TextView px(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTypeface(PIX);
        t.setTextColor(Color.WHITE);
        t.setShadowLayer(0.01f, dp(1.5f), dp(1.5f), Color.rgb(10, 10, 40));
        return t;
    }

    TextView pxBtn(String s, View.OnClickListener l) {
        TextView t = px(s, 13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dpi(6), dpi(8), dpi(6), dpi(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(28, 40, 150));
        g.setStroke(dpi(2), Color.rgb(200, 210, 255));
        g.setCornerRadius(dp(5));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }

    View bar(float f, int color) {
        LinearLayout b = new LinearLayout(this);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.rgb(8, 12, 60)); bg.setStroke(dpi(1), Color.WHITE);
        b.setBackground(bg);
        View fill = new View(this);
        fill.setBackgroundColor(color);
        b.addView(fill, new LinearLayout.LayoutParams(0, -1, Math.max(0.001f, Math.min(1, f))));
        b.addView(new View(this), new LinearLayout.LayoutParams(0, -1, Math.max(0.001f, 1 - Math.min(1, f))));
        return b;
    }

    View statRow(int i) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView n = px(Rpg.ICON[i] + " " + L.t(Rpg.NAME[i]), 14);
        n.setOnClickListener(v -> new android.app.AlertDialog.Builder(this).setTitle(Rpg.ICON[i] + " " + L.t(Rpg.NAME[i])).setMessage(L.t(Rpg.DESC[i])).setPositiveButton("OK", null).show());
        row.addView(n, new LinearLayout.LayoutParams(dpi(118), -2));
        TextView minus = pxBtn("−", v -> { if (st[i] > 0) { st[i]--; apply(); } });
        row.addView(minus, new LinearLayout.LayoutParams(dpi(34), dpi(34)));
        LinearLayout pp = new LinearLayout(this);
        pp.setPadding(dpi(4), 0, dpi(4), 0);
        for (int k = 0; k < Rpg.MAX; k++) {
            View d = new View(this);
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, dpi(14), 1); l.leftMargin = l.rightMargin = dpi(1);
            pp.addView(d, l);
            pips[i][k] = d;
        }
        row.addView(pp, new LinearLayout.LayoutParams(0, -2, 1));
        valTv[i] = px("", 14);
        valTv[i].setGravity(Gravity.CENTER);
        row.addView(valTv[i], new LinearLayout.LayoutParams(dpi(26), -2));
        TextView plus = pxBtn("+", v -> { if (st[i] < Rpg.MAX && Rpg.free(st) > 0) { st[i]++; apply(); } else if (Rpg.free(st) <= 0) toast(L.t("No quedan puntos: quita de otro rasgo.")); });
        row.addView(plus, new LinearLayout.LayoutParams(dpi(34), dpi(34)));
        return row;
    }

    static final int[] STAT_COL = {Color.rgb(255, 120, 170), Color.rgb(255, 170, 60), Color.rgb(255, 235, 90), Color.rgb(120, 200, 255), Color.rgb(190, 120, 255)};

    void apply() {
        Rpg.save(this, st);
        for (int i = 0; i < 5; i++) {
            valTv[i].setText(String.valueOf(st[i]));
            for (int k = 0; k < Rpg.MAX; k++) pips[i][k].setBackgroundColor(k < st[i] ? STAT_COL[i] : Color.rgb(20, 28, 90));
        }
        freeTv.setText(L.t("Puntos libres") + ": " + Rpg.free(st) + " / " + Rpg.TOTAL);
        clsTv.setText(L.t("Clase") + ": " + Rpg.className(st));
    }

    // ================================================================== perfiles
    void saveProfile() {
        EditText e = new EditText(this);
        e.setHint(L.t("Nombre del perfil (p. ej. «Modo trabajo»)"));
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Guardar perfil")).setView(e).setPositiveButton("OK", (d, w) -> {
            String n = e.getText().toString().trim();
            if (n.isEmpty()) return;
            Rpg.saveProfile(this, n, st);
            toast(L.t("Guardado."));
        }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    void loadProfile() {
        JSONObject o = Rpg.profiles(this);
        java.util.List<String> names = new java.util.ArrayList<>();
        for (Iterator<String> it = o.keys(); it.hasNext(); ) names.add(it.next());
        if (names.isEmpty()) { toast(L.t("Aún no tienes perfiles guardados.")); return; }
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Cargar perfil")).setItems(names.toArray(new String[0]), (d, w) -> {
            String[] p = o.optString(names.get(w)).split(",");
            try { int[] s = new int[5]; for (int i = 0; i < 5; i++) s[i] = Integer.parseInt(p[i].trim()); st = s; apply(); } catch (Exception ignored) {}
        }).setNeutralButton(L.t("🗑 Borrar…"), (d, w) -> new android.app.AlertDialog.Builder(this).setItems(names.toArray(new String[0]), (d2, w2) -> {
            Rpg.deleteProfile(this, names.get(w2)); toast(L.t("Borrado."));
        }).show()).show();
    }

    // ================================================================== logros
    void fillTrophies() {
        trophies.removeAllViews();
        java.util.Set<String> done = Achievements.done(this);
        for (int s = 0; s < 2; s++) {
            trophies.addView(px(s == 0 ? "👆 " + L.t("Toques") + ": " + Achievements.touches(this) : "🗺 " + L.t("Aventura") + ": " + Achievements.adventure(this) + " %", 12));
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            for (Achievements.Def x : Achievements.ALL) {
                if (x.series != s) continue;
                TrophyView tv = new TrophyView(this, x.series, x.tier, !done.contains(x.id));
                tv.setOnClickListener(v -> detail(this, x));
                row.addView(tv, new LinearLayout.LayoutParams(0, dpi(56), 1));
            }
            trophies.addView(row, gapBelow(8));
        }
    }

    /** Qué es este logro, cuánto falta y (aventura) qué funciones te faltan, en azul para abrirlas. */
    static void detail(Activity a, Achievements.Def x) {
        boolean got = Achievements.has(a, x.id);
        int[] pg = Achievements.progress(a, x);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(18 * a.getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad / 2);
        TrophyView tv = new TrophyView(a, x.series, x.tier, !got);
        box.addView(tv, new LinearLayout.LayoutParams(-1, pad * 5));
        TextView t = new TextView(a);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        SpannableStringBuilder sb = new SpannableStringBuilder();
        sb.append(x.name()).append("\n\n").append(x.desc()).append("\n");
        if (got) {
            long at = a.getSharedPreferences("cfg", MODE_PRIVATE).getLong("ach_at_" + x.id, 0);
            sb.append("\n✅ ").append(L.t("¡Conseguido!"));
            if (at > 0) sb.append(" · ").append(android.text.format.DateFormat.getDateFormat(a).format(new java.util.Date(at)));
        } else sb.append("\n").append(L.t("Progreso")).append(": ").append(String.valueOf(pg[0])).append(x.series == 1 ? " %" : "").append(" / ").append(String.valueOf(pg[1])).append(x.series == 1 ? " %" : "");
        if (x.series == 1 && !got) {
            List<Object[]> miss = Achievements.missing(a);
            if (!miss.isEmpty()) {
                sb.append("\n\n").append(L.t("Te faltan (toca para abrir):")).append("\n");
                int neon = Color.rgb(110, 180, 255);
                for (Object[] m : miss) {
                    int s0 = sb.length();
                    sb.append("• ").append(L.t((String) m[0]));
                    int s1 = sb.length();
                    sb.append("  ").append(String.valueOf(m[3])).append("/").append(String.valueOf(Achievements.NEED_USES)).append("\n");
                    Class<?> k = (Class<?>) m[2];
                    sb.setSpan(new ClickableSpan() {
                        @Override public void onClick(View w) { try { a.startActivity(new Intent(a, k)); } catch (Exception ignored) {} }
                        @Override public void updateDrawState(TextPaint ds) { ds.setColor(neon); ds.setUnderlineText(true); }
                    }, s0 + 2, s1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
        }
        t.setText(sb);
        t.setMovementMethod(LinkMovementMethod.getInstance());
        ScrollView sv = new ScrollView(a);
        box.addView(t);
        sv.addView(box);
        new android.app.AlertDialog.Builder(a).setView(sv).setPositiveButton("OK", null).show();
    }

    /** 🎉 Logro nuevo: trofeo grande, nombre y una fanfarria. */
    static void celebrate(Activity a, Achievements.Def x) {
        if (a.isFinishing()) return;
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = Math.round(16 * a.getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);
        TextView top = new TextView(a);
        top.setText("🎉 " + L.t("¡Logro desbloqueado!"));
        top.setTextColor(Color.rgb(255, 220, 120));
        top.setTextSize(18);
        top.setTypeface(PIX);
        top.setGravity(Gravity.CENTER);
        box.addView(top);
        TrophyView tv = new TrophyView(a, x.series, x.tier, false);
        box.addView(tv, new LinearLayout.LayoutParams(pad * 8, pad * 8));
        TextView n = new TextView(a);
        n.setText(x.name() + "\n" + x.desc());
        n.setTextColor(Color.WHITE);
        n.setTextSize(15);
        n.setGravity(Gravity.CENTER);
        box.addView(n);
        tv.setScaleX(0.2f); tv.setScaleY(0.2f);
        tv.animate().scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(new android.view.animation.OvershootInterpolator(2.2f)).start();
        new android.app.AlertDialog.Builder(a).setView(box).setPositiveButton("🏆 OK", null).show();
        new Thread(() -> {                                   // fanfarria: Do Mi Sol Do (más notas en los niveles altos)
            int[][] seq = {{60}, {64}, {67}, {72}, {76}, {79}, {84}};
            for (int i = 0; i < 3 + x.tier && i < seq.length; i++) { MusicAudio.playNotes(seq[i], 0, 440); try { Thread.sleep(120); } catch (Exception ignored) {} }
        }).start();
    }

    /** Los trofeos conseguidos, pequeñitos, para la escena de Chloe. */
    static LinearLayout shelf(Activity a) {
        LinearLayout row = new LinearLayout(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        fillShelf(a, row);
        return row;
    }

    static void fillShelf(Activity a, LinearLayout row) {
        row.removeAllViews();
        int s = Math.round(26 * a.getResources().getDisplayMetrics().density);
        java.util.Set<String> done = Achievements.done(a);
        for (Achievements.Def x : Achievements.ALL) {
            if (!done.contains(x.id)) continue;
            TrophyView tv = new TrophyView(a, x.series, x.tier, false);
            tv.setOnClickListener(v -> detail(a, x));
            row.addView(tv, new LinearLayout.LayoutParams(s, s));
        }
        TextView more = new TextView(a);
        more.setText(done.isEmpty() ? "🎮" : "＋");
        more.setTextColor(Color.WHITE);
        more.setTextSize(13);
        more.setPadding(s / 4, 0, s / 4, 0);
        more.setOnClickListener(v -> a.startActivity(new Intent(a, RpgActivity.class)));
        row.addView(more);
    }

    // ================================================================== sprite pixel art
    void buildSprite() {
        new Thread(() -> {
            Bitmap[] f = sprites(this);
            h.post(() -> { frames = f; if (f != null) h.post(anim); });
        }).start();
    }

    final Runnable anim = new Runnable() {
        @Override public void run() {
            if (frames == null || isFinishing()) return;
            int[] seq = {0, 0, 1, 0, 0, 2};
            sprite.setImageBitmap(frames[seq[frame++ % seq.length]]);
            h.postDelayed(this, 320);
        }
    };

    /** De su retrato a pixel art de 68×88 (colores reducidos y contorno oscuro), en 3 fotogramas: quieta, «respira», orejas. */
    static Bitmap[] sprites(Activity a) {
        try {
            Bitmap src;
            try (java.io.InputStream in = a.getAssets().open("chloe_" + Outfit.now(a) + ".webp")) { src = BitmapFactory.decodeStream(in); }
            if (src == null) return null;
            int sw = src.getWidth();
            float k = sw / 480f;
            Bitmap crop = Bitmap.createBitmap(src, Math.round(70 * k), Math.round(20 * k), Math.round(340 * k), Math.round(440 * k));
            int W = 68, H = 88;
            Bitmap sm = Bitmap.createScaledBitmap(crop, W, H, true);
            int[] p = new int[W * H];
            sm.getPixels(p, 0, W, 0, 0, W, H);
            for (int i = 0; i < p.length; i++) {
                int al = p[i] >>> 24;
                if (al < 120) { p[i] = 0; continue; }
                int r = (p[i] >> 16) & 255, g = (p[i] >> 8) & 255, b = p[i] & 255;
                float l = (r + g + b) / 3f;                              // más contraste y color
                r = q((r - l) * 1.3f + (l - 128) * 1.25f + 128); g = q((g - l) * 1.3f + (l - 128) * 1.25f + 128); b = q((b - l) * 1.3f + (l - 128) * 1.25f + 128);
                p[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
            int[] o = p.clone();
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
                if (p[y * W + x] == 0) continue;
                boolean edge = x == 0 || y == 0 || x == W - 1 || y == H - 1 || p[y * W + x - 1] == 0 || p[y * W + x + 1] == 0 || p[(y - 1) * W + x] == 0 || p[(y + 1) * W + x] == 0;
                if (edge) o[y * W + x] = 0xFF281428;
            }
            Bitmap[] fr = new Bitmap[3];
            for (int f = 0; f < 3; f++) {
                int[] q = new int[W * (H + 2)];
                for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
                    int v = o[y * W + x];
                    if (v == 0) continue;
                    int ny = y + 1, nx = x;
                    if (f == 1) ny = y < 24 ? y : y + 1;                    // respira: el cuerpo baja 1 px, las orejas se quedan
                    if (f == 2 && y < 22) nx = x + (x < W / 2 ? -1 : 1);     // orejas que se abren
                    if (nx >= 0 && nx < W && ny >= 0 && ny < H + 2) q[ny * W + nx] = v;
                }
                Bitmap b = Bitmap.createBitmap(q, W, H + 2, Bitmap.Config.ARGB_8888);
                fr[f] = Bitmap.createScaledBitmap(b, W * 6, (H + 2) * 6, false);   // sin suavizar: píxeles nítidos
            }
            return fr;
        } catch (Throwable e) { return null; }
    }

    static int q(float v) { int x = Math.round(Math.max(0, Math.min(255, v)) / 32f) * 32; return Math.min(255, x); }

    @Override protected void onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy(); }
}
