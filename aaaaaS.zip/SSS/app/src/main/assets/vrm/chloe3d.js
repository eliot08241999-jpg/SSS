// SSS+ v1.6 · CHLOE EN 3D. Carga un modelo VRM (hecho en VRoid Studio, gratis) y le da vida:
// respiración, parpadeo, mirada, labios al hablar, gestos al azar (barbilla en la mano, mirar a otro lado,
// tocarse el pelo, saludar…), estados (escucha, piensa, contenta, triste…), pelo con física y escena según la hora.
import * as THREE from './three.module.min.js';
import { GLTFLoader } from './jsm/GLTFLoader.js';

const P = new URLSearchParams(location.search);
const MODEL = P.get('m') || 'model.vrm';
let frameMode = P.get('frame') || 'bust';
const NATIVE = window.SSS || null;
const msg = document.getElementById('msg');

// ------------------------------------------------------------------ escena
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: !!P.get('shot') });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(innerWidth, innerHeight);
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(28, innerWidth / innerHeight, 0.05, 50);
scene.add(new THREE.AmbientLight(0xffffff, 1.6));
const sunLight = new THREE.DirectionalLight(0xffffff, 1.4);
sunLight.position.set(0.6, 1.5, 2);
scene.add(sunLight);
// sombra suave en el suelo
const shadow = new THREE.Mesh(new THREE.CircleGeometry(0.35, 40), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28, depthWrite: false }));
shadow.rotation.x = -Math.PI / 2;
shadow.position.y = 0.002;
scene.add(shadow);

function sky() {
  const h = P.get('hour') != null ? +P.get('hour') : new Date().getHours() + new Date().getMinutes() / 60;
  const s = document.getElementById('sky').style, moon = document.getElementById('moon'), sun = document.getElementById('sun');
  let night = h < 6.5 || h >= 20.5, dusk = (h >= 18 && h < 20.5) || (h >= 6.5 && h < 8);
  if (night) s.background = 'linear-gradient(#03040c 0%,#0b1230 55%,#1b1f3d 100%)';
  else if (dusk) s.background = 'linear-gradient(#2a2350 0%,#c0587a 55%,#f5a35c 100%)';
  else s.background = 'linear-gradient(#5fa8e8 0%,#a9d4f5 60%,#e9f4fb 100%)';
  moon.style.display = night ? 'block' : 'none';
  sun.style.display = !night && !dusk ? 'block' : 'none';
  const c = document.getElementById('stars');
  c.width = innerWidth; c.height = innerHeight;
  const g = c.getContext('2d');
  g.clearRect(0, 0, c.width, c.height);
  if (night || dusk) for (let i = 0; i < (night ? 140 : 40); i++) {
    g.fillStyle = 'rgba(255,255,255,' + (0.3 + Math.random() * 0.7) + ')';
    const r = Math.random() < 0.1 ? 1.4 : 0.8;
    g.beginPath(); g.arc(Math.random() * c.width, Math.random() * c.height * 0.7, r, 0, 7); g.fill();
  }
  sunLight.intensity = night ? 0.7 : 1.4;
  sunLight.color.set(night ? 0x9fb0ff : dusk ? 0xffc59a : 0xffffff);
}
sky();
setInterval(sky, 5 * 60 * 1000);

// ------------------------------------------------------------------ el modelo
let vrm = null;            // {root, bones, rest, exprs, v0, springs}
const charQ = new THREE.Quaternion();

new GLTFLoader().load(MODEL, async (gltf) => {
  try { vrm = await setup(gltf); msg.style.display = 'none'; frame(); if (NATIVE) NATIVE.ready(); }
  catch (e) { fail(e); }
}, (p) => { if (p.total) msg.textContent = Math.round(p.loaded * 100 / p.total) + ' %'; }, fail);

function fail(e) { msg.textContent = '⚠ ' + (e && e.message ? e.message : e); if (NATIVE) NATIVE.error(String(e && e.message ? e.message : e)); }

async function setup(gltf) {
  const json = gltf.parser.json, ext = json.extensions || {};
  const v1 = ext.VRMC_vrm, v0 = ext.VRM;
  if (!v1 && !v0) throw new Error('no es un modelo VRM');
  const root = gltf.scene;
  if (v0) root.rotation.y = Math.PI;                     // los VRM 0.x miran hacia atrás
  scene.add(root);
  root.traverse(o => { if (o.isMesh) o.frustumCulled = false; });
  const node = (i) => gltf.parser.getDependency('node', i);
  // huesos
  const bones = {};
  if (v1) for (const [name, b] of Object.entries(v1.humanoid.humanBones)) bones[name] = await node(b.node);
  else for (const b of v0.humanoid.humanBones) bones[b.bone] = await node(b.node);
  root.updateMatrixWorld(true);
  const rest = {};
  for (const [n, b] of Object.entries(bones)) rest[n] = { local: b.quaternion.clone(), world: b.getWorldQuaternion(new THREE.Quaternion()), pos: b.position.clone() };
  // expresiones (caras)
  const exprs = {};
  const meshesOf = (o) => { const out = []; o.traverse(x => { if (x.morphTargetInfluences) out.push(x); }); return out; };
  if (v1) {
    const all = Object.assign({}, v1.expressions?.preset || {}, v1.expressions?.custom || {});
    for (const [name, e] of Object.entries(all)) {
      const binds = [];
      for (const b of (e.morphTargetBinds || [])) binds.push({ meshes: meshesOf(await node(b.node)), index: b.index, weight: b.weight });
      exprs[name] = { binds, binary: !!e.isBinary };
    }
  } else {
    const map = { a: 'aa', i: 'ih', u: 'ou', e: 'ee', o: 'oh', joy: 'happy', sorrow: 'sad', fun: 'relaxed', blink_l: 'blinkLeft', blink_r: 'blinkRight',
      lookleft: 'lookLeft', lookright: 'lookRight', lookup: 'lookUp', lookdown: 'lookDown' };
    for (const g of (v0.blendShapeMaster?.blendShapeGroups || [])) {
      const pre = (g.presetName || '').toLowerCase();
      const name = map[pre] || pre || g.name;
      const binds = [];
      for (const b of (g.binds || [])) {
        const objs = [];
        for (let i = 0; i < json.nodes.length; i++) if (json.nodes[i].mesh === b.mesh) objs.push(...meshesOf(await node(i)));
        binds.push({ meshes: objs, index: b.index, weight: (b.weight || 100) / 100 });
      }
      exprs[name] = { binds };
    }
  }
  // pelo y ropa con física
  const springs = [];
  const addJoint = (obj, p) => {
    const child = obj.children.find(c => c.isBone || c.type === 'Bone' || c.isObject3D);
    if (!child) return;
    const axis = child.position.clone(); const len = axis.length();
    if (len < 1e-4) return;
    const tail = obj.localToWorld(child.position.clone());
    springs.push({ bone: obj, axis: axis.normalize(), len, rest: obj.quaternion.clone(), tail, prev: tail.clone(),
      stiff: p.stiff ?? 1, grav: p.grav ?? 0, gdir: new THREE.Vector3(...(p.gdir || [0, -1, 0])), drag: p.drag ?? 0.4 });
  };
  if (v1 && ext.VRMC_springBone) {
    for (const s of (ext.VRMC_springBone.springs || []))
      for (const j of s.joints) addJoint(await node(j.node), { stiff: j.stiffness, grav: j.gravityPower, gdir: j.gravityDir ? [j.gravityDir[0], j.gravityDir[1], j.gravityDir[2]] : null, drag: j.dragForce });
  } else if (v0 && v0.secondaryAnimation) {
    for (const g of (v0.secondaryAnimation.boneGroups || [])) {
      const p = { stiff: g.stiffiness, grav: g.gravityPower, gdir: g.gravityDir ? [g.gravityDir.x, g.gravityDir.y, g.gravityDir.z] : null, drag: g.dragForce };
      for (const r of (g.bones || [])) { const o = await node(r); o.traverse(x => { if (x !== o || true) addJoint(x, p); }); }
    }
  }
  // restricciones de nodos (VRMC_node_constraint): mangas y huesos de giro que siguen a otro hueso
  const cons = [];
  for (let i = 0; i < json.nodes.length; i++) {
    const c = json.nodes[i].extensions?.VRMC_node_constraint?.constraint;
    if (!c) continue;
    const type = c.roll ? 'roll' : c.rotation ? 'rotation' : c.aim ? 'aim' : null;
    if (!type || type === 'aim') continue;
    const d = c[type];
    const dst = await node(i), src = await node(d.source);
    const ax = { X: [1, 0, 0], Y: [0, 1, 0], Z: [0, 0, 1] }[d.rollAxis || 'X'];
    cons.push({ type, dst, src, w: d.weight ?? 1, dstRest: dst.quaternion.clone(), srcRestInv: src.quaternion.clone().invert(), axis: new THREE.Vector3(...ax) });
  }
  // altura de la cabeza (para el encuadre)
  const hp = bones.head.getWorldPosition(new THREE.Vector3());
  return { root, bones, rest, exprs, springs, cons, headY: hp.y, v0: !!v0 };
}

// ------------------------------------------------------------------ encuadre
function frame(f) {
  if (f) frameMode = f;
  if (!vrm) return;
  const hy = vrm.headY, aspect = innerWidth / innerHeight;
  camera.aspect = aspect;
  if (frameMode === 'full') { camera.position.set(0, hy * 0.55, hy * 2.45 / Math.min(1, aspect * 1.6)); camera.lookAt(0, hy * 0.52, 0); }
  else { camera.position.set(0, hy - 0.02, 1.55 / Math.min(1, aspect * 1.7)); camera.lookAt(0, hy - 0.2, 0); }
  camera.updateProjectionMatrix();
  shadow.visible = frameMode === 'full';
}
addEventListener('resize', () => { renderer.setSize(innerWidth, innerHeight); frame(); sky(); });

// ------------------------------------------------------------------ poses (ángulos en radianes, ejes del personaje:
// X = su izquierda, Y = arriba, Z = hacia ti)
const POSES = {
  idle: { leftUpperArm: [0.05, 0.1, -1.22], rightUpperArm: [0.05, -0.1, 1.22], leftLowerArm: [0, -0.3, 0], rightLowerArm: [0, 0.3, 0],
    leftHand: [0, 0, -0.15], rightHand: [0, 0, 0.15] },
  // barbilla apoyada en la mano derecha (como pensando o escuchando con interés)
  chin: { leftUpperArm: [0.05, 0.1, -1.22], leftLowerArm: [0, -0.3, 0], rightUpperArm: [-0.3, 0.9, 1.3], rightLowerArm: [0, 2.55, 0],
    rightHand: [0, 0, -0.2], head: [-0.05, 0, 0.1], neck: [0, 0, 0.05] },
  // mano derecha tocándose el pelo, junto a la cabeza
  hair: { leftUpperArm: [0.05, 0.1, -1.22], leftLowerArm: [0, -0.3, 0], rightUpperArm: [-0.25, 0.45, -0.45], rightLowerArm: [0, 2.2, 0],
    head: [0, 0, -0.14] },
  wave: { leftUpperArm: [0.05, 0.1, -1.22], leftLowerArm: [0, -0.3, 0], rightUpperArm: [-0.2, 0.4, -0.6], rightLowerArm: [0, 1.9, 0], head: [0, 0, -0.06] },
  // manos arriba, contenta
  happy: { leftUpperArm: [-0.4, -0.15, -1.2], rightUpperArm: [-0.4, 0.15, 1.2], leftLowerArm: [0, -2.0, 0], rightLowerArm: [0, 2.0, 0], head: [0.05, 0, 0.1] },
  shy: { leftUpperArm: [-0.25, -0.35, -1.15], rightUpperArm: [-0.25, 0.35, 1.15], leftLowerArm: [0, -1.1, 0], rightLowerArm: [0, 1.1, 0], head: [0.15, 0, 0.12] },
  sad: { leftUpperArm: [0.05, 0.05, -1.32], rightUpperArm: [0.05, -0.05, 1.32], leftLowerArm: [0, -0.15, 0], rightLowerArm: [0, 0.15, 0], head: [0.25, 0, 0], neck: [0.1, 0, 0] },
};
const STATE_POSE = { idle: 'idle', listen: 'chin', think: 'chin', talk: 'idle', happy: 'happy', sad: 'sad', confused: 'hair', love: 'shy', sleep: 'sad' };
const STATE_FACE = { happy: { happy: 0.9 }, love: { happy: 0.6, relaxed: 0.4 }, sad: { sad: 0.8 }, confused: { surprised: 0.35 }, sleep: { blink: 1 }, think: { relaxed: 0.2 } };

let state = 'idle', flash = null, flashUntil = 0, gesture = null, gestureUntil = 0, nextGesture = 4;
let talkLevel = 0, talkPulse = 0, vowel = 'aa', vowelT = 0;
const cur = {};              // ángulos actuales por hueso (suavizados)
const face = {};             // expresiones actuales (suavizadas)
let t = 0, blinkT = 2 + Math.random() * 3, blinkV = 0, lookX = 0, lookY = 0, lookTX = 0, lookTY = 0, lookNext = 1, touchX = null, touchY = null, touchUntil = 0;

window.chloe = {
  state(s) { state = s || 'idle'; },
  react(s, ms) { flash = s; flashUntil = t + (ms || 1500) / 1000; if (s === 'happy' || s === 'love') gesture = null; },
  talk(level, pulse) { talkLevel = Math.max(0, Math.min(1, level)); if (pulse) talkPulse = 1; },
  frame(f) { frame(f); },
  gesture(g, secs) { gesture = g; gestureUntil = t + (secs || 3); },
  setPose(n, p) { POSES[n] = p; },
};

const E = new THREE.Euler(), Q = new THREE.Quaternion(), Qi = new THREE.Quaternion();

function setBone(name, a) {
  const b = vrm.bones[name], r = vrm.rest[name];
  if (!b || !r) return;
  E.set(a[0], a[1], a[2], 'XYZ');
  Q.setFromEuler(E);                                     // giro en ejes del personaje
  Qi.copy(r.world).invert();
  Q.premultiply(Qi).multiply(r.world);                   // → a los ejes del hueso
  b.quaternion.copy(r.local).multiply(Q);
}

function update(dt) {
  t += dt;
  const st = flash && t < flashUntil ? flash : state;
  // gestos al azar cuando no hace nada (no cíclico: cada vez otro, con tiempos distintos)
  if (st === 'idle' && t > nextGesture && !gesture) {
    const opts = ['chin', 'hair', 'look', 'tilt', 'chin', 'stretch'];
    gesture = opts[Math.floor(Math.random() * opts.length)];
    gestureUntil = t + 2.5 + Math.random() * 3.5;
    nextGesture = gestureUntil + 4 + Math.random() * 8;
  }
  if (gesture && (t > gestureUntil || st !== 'idle' && gesture !== 'wave')) gesture = null;
  let poseName = STATE_POSE[st] || 'idle';
  if (gesture && POSES[gesture]) poseName = gesture;
  const pose = POSES[poseName];
  // objetivo por hueso
  const target = {};
  for (const n of Object.keys(POSES.idle)) target[n] = [0, 0, 0];
  for (const n of ['head', 'neck', 'spine', 'chest', 'upperChest', 'hips', 'leftShoulder', 'rightShoulder']) target[n] = [0, 0, 0];
  for (const [n, a] of Object.entries(pose)) target[n] = a.slice();
  // respiración y vida
  const br = Math.sin(t * 1.6);
  target.chest = [br * 0.015, 0, 0];
  target.spine[2] += Math.sin(t * 0.37) * 0.02;
  target.spine[1] += Math.sin(t * 0.23) * 0.03;
  // la cabeza mira (a ti, a donde tocas o a otro lado)
  if (t > lookNext) { lookTX = (Math.random() - 0.5) * 0.35; lookTY = (Math.random() - 0.5) * 0.15; lookNext = t + 1.5 + Math.random() * 3; }
  let lx = lookTX, ly = lookTY;
  if (gesture === 'look') { lx = Math.sin(t * 0.3) > 0 ? 0.55 : -0.55; ly = -0.1; }
  if (st === 'listen' || st === 'talk') { lx *= 0.3; ly *= 0.3; }
  if (st === 'think') { lx = 0.25; ly = -0.25; }
  if (touchUntil > t) { lx = touchX * 0.5; ly = -touchY * 0.3; }
  lookX += (lx - lookX) * Math.min(1, dt * 3); lookY += (ly - lookY) * Math.min(1, dt * 3);
  target.head[1] += lookX * 0.7; target.neck[1] += lookX * 0.3;
  target.head[0] += lookY * 0.6;
  if (gesture === 'tilt') target.head[2] += 0.22 * Math.sin(Math.min(1, (gestureUntil - t)) * Math.PI);
  if (gesture === 'stretch') { target.leftUpperArm = [-0.2, 0, -0.15]; target.rightUpperArm = [-0.2, 0, 0.15]; target.leftLowerArm = [0, 0, -1.0]; target.rightLowerArm = [0, 0, 1.0]; target.head[0] -= 0.15; }
  if (gesture === 'wave') target.rightLowerArm[1] += Math.sin(t * 9) * 0.3;
  // hablando: cabeza y manos acompañan
  if (st === 'talk' || talkLevel > 0.05) {
    target.head[0] += Math.sin(t * 5.3) * 0.03 * talkLevel;
    target.head[2] += Math.sin(t * 2.1) * 0.04;
    target.leftLowerArm[1] += -0.25 * (0.5 + 0.5 * Math.sin(t * 1.7));
    target.rightLowerArm[1] += 0.25 * (0.5 + 0.5 * Math.sin(t * 1.3 + 1));
  }
  if (st === 'happy' || st === 'love') { target.hips = [0, 0, Math.sin(t * 6) * 0.03]; target.head[2] += 0.12; }
  // suavizar y aplicar
  const k = Math.min(1, dt * 5);
  for (const [n, a] of Object.entries(target)) {
    const c = cur[n] || (cur[n] = [0, 0, 0]);
    for (let i = 0; i < 3; i++) c[i] += (a[i] - c[i]) * k;
    setBone(n, c);
  }
  // salto suave de alegría
  const hips = vrm.bones.hips, hr = vrm.rest.hips;
  if (hips && hr) hips.position.y = hr.pos.y + ((st === 'happy') ? Math.abs(Math.sin(t * 6)) * 0.012 : br * 0.002);
  // cara
  const want = Object.assign({}, STATE_FACE[st] || {});
  // parpadeo
  blinkT -= dt;
  if (blinkT < 0) { blinkV = 1; blinkT = 1.8 + Math.random() * 4.5; if (Math.random() < 0.15) blinkT = 0.25; }
  blinkV = Math.max(0, blinkV - dt * 7);
  want.blink = Math.max(want.blink || 0, blinkV > 0.5 ? 1 - (blinkV - 0.5) * 2 : blinkV * 2);
  if (st === 'happy') want.blink = Math.max(want.blink, 0);   // la expresión «happy» ya cierra un poco los ojos
  // boca
  talkPulse = Math.max(0, talkPulse - dt * 6);
  if (talkLevel > 0.05) {
    vowelT -= dt;
    if (vowelT < 0) { vowel = ['aa', 'oh', 'ih', 'ee', 'ou', 'aa'][Math.floor(Math.random() * 6)]; vowelT = 0.09 + Math.random() * 0.1; }
    want[vowel] = Math.min(1, 0.25 + talkLevel * 0.6 + talkPulse * 0.3) * (0.6 + 0.4 * Math.abs(Math.sin(t * 17)));
  }
  for (const n of Object.keys(vrm.exprs)) {
    const v = want[n] || 0;
    face[n] = (face[n] || 0) + (v - (face[n] || 0)) * Math.min(1, dt * (n === 'blink' ? 30 : 12));
  }
  const touched = new Set();
  for (const e of Object.values(vrm.exprs)) for (const b of e.binds) for (const m of b.meshes) touched.add(m);
  for (const m of touched) m.morphTargetInfluences.fill(0);
  for (const [n, e] of Object.entries(vrm.exprs)) {
    const v = face[n] || 0;
    if (v < 0.001) continue;
    for (const b of e.binds) for (const m of b.meshes) if (b.index < m.morphTargetInfluences.length) m.morphTargetInfluences[b.index] = Math.min(1, m.morphTargetInfluences[b.index] + v * b.weight);
  }
  // las restricciones siguen a sus huesos
  for (const c of vrm.cons) {
    const d = c.srcRestInv.clone().multiply(c.src.quaternion);
    if (c.type === 'roll') {
      const v = new THREE.Vector3(d.x, d.y, d.z);
      const p = c.axis.clone().multiplyScalar(v.dot(c.axis));
      d.set(p.x, p.y, p.z, d.w).normalize();
    }
    c.dst.quaternion.copy(c.dstRest).multiply(new THREE.Quaternion().slerp(d, c.w));
  }
  vrm.root.updateMatrixWorld(true);
  springs(dt);
}

// física del pelo
const V1 = new THREE.Vector3(), V2 = new THREE.Vector3(), V3 = new THREE.Vector3(), PQ = new THREE.Quaternion(), Q2 = new THREE.Quaternion();
function springs(dt) {
  dt = Math.min(dt, 0.05);
  for (const s of vrm.springs) {
    const b = s.bone;
    b.parent.getWorldQuaternion(PQ);
    const pos = b.getWorldPosition(V1);
    const restDir = V2.copy(s.axis).applyQuaternion(Q2.copy(PQ).multiply(s.rest));
    const inertia = V3.copy(s.tail).sub(s.prev).multiplyScalar(1 - s.drag);
    const next = s.tail.clone().add(inertia).addScaledVector(restDir, s.stiff * dt).addScaledVector(s.gdir, s.grav * dt);
    next.sub(pos).normalize().multiplyScalar(s.len).add(pos);
    s.prev.copy(s.tail);
    s.tail.copy(next);
    const dir = next.clone().sub(pos).normalize();
    const turn = new THREE.Quaternion().setFromUnitVectors(restDir.normalize(), dir);
    const world = turn.multiply(PQ.clone().multiply(s.rest));
    b.quaternion.copy(PQ.invert().multiply(world));
    b.updateMatrixWorld(true);
  }
}

// tocarla
renderer.domElement.addEventListener('pointerdown', (e) => {
  touchX = (e.clientX / innerWidth - 0.5) * 2; touchY = (e.clientY / innerHeight - 0.5) * 2; touchUntil = t + 2.5;
  if (NATIVE) NATIVE.poke(touchX, touchY);
});

let last = performance.now();
function loop(now) {
  const dt = Math.min(0.1, (now - last) / 1000); last = now;
  if (vrm) update(dt);
  renderer.render(scene, camera);
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
