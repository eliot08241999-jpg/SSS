package com.aplauso.encuentra;

import android.content.Context;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * v1.4.1 · El traje de Chloe según la estación: otoño (abrigo granate), invierno (parka blanca),
 * primavera (vestido blanco) y verano (sombrero de paja). Mira el mes y en qué hemisferio estás
 * (por tu ciudad de las rutinas o, si no hay, por la zona horaria): en Argentina o Australia, al revés.
 */
public class Outfit {
    public static final String[] ALL = {"autumn", "winter", "spring", "summer"};
    public static final String[] LABEL = {"🍂 Otoño", "❄ Invierno", "🌸 Primavera", "☀ Verano"};

    static boolean south(Context c) {
        android.content.SharedPreferences p = c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        if (p.contains("ai_city_lat")) return p.getFloat("ai_city_lat", 1) < 0;
        String z = TimeZone.getDefault().getID();
        return z.startsWith("Australia/") || z.startsWith("Antarctica/") || z.matches("Pacific/(Auckland|Chatham|Fiji|Tongatapu|Apia|Noumea|Efate)")
                || z.matches("America/(Argentina/.*|Buenos_Aires|Cordoba|Mendoza|Santiago|Punta_Arenas|Sao_Paulo|Montevideo|Asuncion|Lima|La_Paz|Campo_Grande|Cuiaba|Porto_Velho|Rio_Branco|Maceio|Recife|Bahia|Fortaleza|Belem|Araguaina)")
                || z.matches("Africa/(Johannesburg|Maputo|Harare|Lusaka|Windhoek|Gaborone|Maseru|Mbabane|Lubumbashi|Luanda|Blantyre|Dar_es_Salaam)")
                || z.matches("Indian/(Antananarivo|Mauritius|Reunion|Mayotte|Comoro)");
    }

    /** El de hoy (o el que hayas elegido a mano). */
    public static String now(Context c) {
        String pick = c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("avatar_outfit", "auto");
        if (!pick.equals("auto")) return pick;
        int m = Calendar.getInstance().get(Calendar.MONTH);          // 0 = enero
        int season = m == 11 || m <= 1 ? 1 : m <= 4 ? 2 : m <= 7 ? 3 : 0;   // invierno, primavera, verano, otoño
        if (south(c)) season = (season + 2) % 4;
        return ALL[season];
    }
}
