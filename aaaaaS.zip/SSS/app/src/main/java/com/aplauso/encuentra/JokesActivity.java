package com.aplauso.encuentra;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.List;

/**
 * v1.6 · MIS CHISTES: los tuyos, cada uno normal u oscuro. Chloe los cuenta tal cual, mezclados con los suyos,
 * y los usa de ejemplo cuando le pides que se invente uno.
 */
public class JokesActivity extends NeonActivity {
    LinearLayout list;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen(L.t("😂 MIS CHISTES"));
        LinearLayout add = panel("◢ AÑADIR");
        EditText in = new EditText(this);
        in.setHint(L.t("Escribe el chiste tal cual quieres que lo cuente…"));
        in.setTextColor(Color.WHITE);
        in.setHintTextColor(Color.GRAY);
        in.setTextSize(15);
        in.setMinLines(3);
        in.setBackground(frame(dpi(10)));
        in.setPadding(dpi(12), dpi(10), dpi(12), dpi(10));
        add.addView(in);
        Switch dark = neonSwitch("Es de humor negro");
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dpi(8);
        add.addView(dark, sp);
        add.addView(button("➕ GUARDAR CHISTE", v -> {
            String t = in.getText().toString().trim();
            if (t.isEmpty()) return;
            List<Jokes.J> l = Jokes.mine(this);
            l.add(new Jokes.J(t, dark.isChecked()));
            Jokes.save(this, l);
            in.setText("");
            refresh();
            toast(L.t("¡Guardado! Ya lo puedo contar."));
        }), sp);
        add.addView(text("Consejo: con 3 o 4 de cada tipo, cuando le pidas «invéntate un chiste» los usa de ejemplo y le salen mucho mejor.", 11), sp);
        col.addView(add, gapBelow(14));
        LinearLayout lp = panel("◢ TUS CHISTES");
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        lp.addView(list);
        col.addView(lp, gapBelow(14));
        refresh();
    }

    void refresh() {
        list.removeAllViews();
        List<Jokes.J> l = Jokes.mine(this);
        if (l.isEmpty()) { list.addView(text("Todavía no hay ninguno.", 13)); return; }
        for (int i = 0; i < l.size(); i++) {
            final int k = i;
            Jokes.J j = l.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setPadding(0, dpi(6), 0, dpi(6));
            TextView t = text((j.dark ? "🖤 " : "😄 ") + j.t, 14);
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(circleButton("✕", v -> { List<Jokes.J> m = Jokes.mine(this); if (k < m.size()) m.remove(k); Jokes.save(this, m); refresh(); }),
                    new LinearLayout.LayoutParams(dpi(40), dpi(40)));
            list.addView(row);
        }
    }
}
