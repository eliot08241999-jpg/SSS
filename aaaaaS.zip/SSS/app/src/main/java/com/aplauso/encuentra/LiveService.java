package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;

/**
 * v1.4.7 · LIVE CON CHLOE: una «llamada» de voz, como Gemini Live. Le hablas, contesta en voz alta y vuelve
 * a escucharte sola, sin tocar nada. Sigue aunque salgas de la app (notificación con COLGAR y SILENCIAR).
 * Se cuelga sola tras 3 minutos sin que digas nada.
 */
public class LiveService extends Service {
    public static final int OFF = 0, LISTENING = 1, THINKING = 2, SPEAKING = 3, MUTED = 4;
    static volatile int state = OFF;
    static volatile String heard = "", said = "", partial = "";
    static volatile long startedAt;
    static volatile boolean muted;
    static volatile long lastVoice;

    static boolean on() { return state != OFF; }

    static void start(Context c) {
        Intent i = new Intent(c, LiveService.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void hangUp(Context c) { c.startService(new Intent(c, LiveService.class).setAction("hang")); }

    static void toggleMute(Context c) { c.startService(new Intent(c, LiveService.class).setAction("mute")); }

    /** Corta lo que está diciendo y vuelve a escuchar (tocar la pantalla mientras habla). */
    static void interrupt(Context c) { c.startService(new Intent(c, LiveService.class).setAction("interrupt")); }

    final Handler h = new Handler(Looper.getMainLooper());
    SpeechRecognizer sr;
    NotificationManager nm;
    boolean plain;
    int turn;                       // para ignorar respuestas viejas si cuelgas o interrumpes

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if ("hang".equals(a)) { stopSelf(); return START_NOT_STICKY; }
        if (state == OFF) begin();
        if ("mute".equals(a)) {
            muted = !muted;
            if (muted) { cancelListen(); state = MUTED; } else if (state == MUTED) listenSoon(200);
            notifyNow();
        }
        if ("interrupt".equals(a) && state == SPEAKING) { Voice.stop(); turn++; listenSoon(250); }
        return START_NOT_STICKY;
    }

    void begin() {
        nm = getSystemService(NotificationManager.class);
        if (android.os.Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(new NotificationChannel("live", L.t("Live con Chloe"), NotificationManager.IMPORTANCE_DEFAULT));
        startedAt = SystemClock.elapsedRealtime();
        lastVoice = startedAt;
        muted = false;
        heard = ""; said = ""; partial = "";
        state = LISTENING;
        try {
            Notification n = notification();
            if (android.os.Build.VERSION.SDK_INT >= 30) startForeground(41, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(41, n);
        } catch (Exception e) {                     // si el móvil no acepta el estilo «llamada», notificación normal
            plain = true;
            Notification n = notification();
            if (android.os.Build.VERSION.SDK_INT >= 30) startForeground(41, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(41, n);
        }
        ShieldService.yieldMic = true;               // la escucha de «Hola Chloe» suelta el micro
        android.media.AudioManager am = getSystemService(android.media.AudioManager.class);
        startMode = am == null ? 0 : am.getMode();
        h.postDelayed(callWatch, 500);
        Voice.init(this, null);
        String hi = L.t(pick(new String[]{"¡Te escucho! Cuéntame.", "Aquí estoy. ¿De qué hablamos?", "¡Hola! Dime lo que quieras."}));
        said = hi;
        speak(hi);
    }

    static String pick(String[] a) { return a[new java.util.Random().nextInt(a.length)]; }

    // ------------------------------------------------------------------ v1.4.7: si te llaman, Chloe cuelga
    int startMode;

    final Runnable callWatch = new Runnable() {
        public void run() {
            if (state == OFF) return;
            android.media.AudioManager am = getSystemService(android.media.AudioManager.class);
            int m = am == null ? 0 : am.getMode();
            boolean phone = m == android.media.AudioManager.MODE_RINGTONE || m == android.media.AudioManager.MODE_IN_CALL || m == 4 /* MODE_CALL_SCREENING */;
            boolean voip = m == android.media.AudioManager.MODE_IN_COMMUNICATION && startMode != android.media.AudioManager.MODE_IN_COMMUNICATION;
            if (phone || voip) { pausedByCall(); return; }
            h.postDelayed(this, 500);
        }
    };

    /** Te están llamando (o has empezado una llamada de WhatsApp…): se calla, suelta el micro y cuelga. */
    void pausedByCall() {
        Voice.stop();
        turn++;
        try {
            PendingIntent again = PendingIntent.getActivity(this, 3, new Intent(this, LiveActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "live") : new Notification.Builder(this);
            nm.notify(42, b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle(L.t("Live con Chloe"))
                    .setContentText(L.t("He colgado porque te estaban llamando. Toca para seguir hablando."))
                    .setAutoCancel(true).setContentIntent(again).build());
        } catch (Exception ignored) {}
        stopSelf();
    }

    // ------------------------------------------------------------------ escuchar
    void listenSoon(long ms) { h.removeCallbacks(listenR); h.postDelayed(listenR, ms); }

    final Runnable listenR = this::listen;

    void listen() {
        if (state == OFF || muted) return;
        android.media.AudioManager am = getSystemService(android.media.AudioManager.class);
        if (am != null && (am.getMode() == android.media.AudioManager.MODE_RINGTONE || am.getMode() == android.media.AudioManager.MODE_IN_CALL)) { pausedByCall(); return; }
        if (SystemClock.elapsedRealtime() - lastVoice > 3 * 60_000) {      // 3 minutos sin hablar: cuelga
            said = L.t("Me quedo por aquí. Cuando quieras, me vuelves a llamar.");
            speakThen(said, this::stopSelf);
            return;
        }
        ShieldService.yieldMic = true;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { said = L.t("Este teléfono no tiene reconocimiento de voz: escríbeme."); stopSelf(); return; }
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(listener);
        }
        state = LISTENING;
        partial = "";
        notifyNow();
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Brain.listenTag(this))
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                // v1.4.9: que entienda español, italiano o inglés sin avisar (Android 14+; si el reconocedor no sabe, lo ignora)
                .putExtra("android.speech.extra.ENABLE_LANGUAGE_DETECTION", true)
                .putStringArrayListExtra("android.speech.extra.LANGUAGE_DETECTION_ALLOWED_LANGUAGES", new ArrayList<>(java.util.Arrays.asList("es-ES", "it-IT", "en-US")))
                .putExtra("android.speech.extra.ENABLE_LANGUAGE_SWITCH", "balanced")
                .putStringArrayListExtra("android.speech.extra.LANGUAGE_SWITCH_ALLOWED_LANGUAGES", new ArrayList<>(java.util.Arrays.asList("es-ES", "it-IT", "en-US")))
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 2000L);
        try { sr.startListening(i); } catch (Exception e) { resetRecognizer(); listenSoon(800); }
    }

    void cancelListen() { h.removeCallbacks(listenR); try { if (sr != null) sr.cancel(); } catch (Exception ignored) {} }

    void resetRecognizer() { try { if (sr != null) sr.destroy(); } catch (Exception ignored) {} sr = null; }

    final RecognitionListener listener = new RecognitionListener() {
        public void onReadyForSpeech(Bundle b) {}
        public void onBeginningOfSpeech() { lastVoice = SystemClock.elapsedRealtime(); }
        public void onRmsChanged(float v) { if (v > 4) lastVoice = SystemClock.elapsedRealtime(); }
        public void onBufferReceived(byte[] b) {}
        public void onEndOfSpeech() {}
        public void onEvent(int t, Bundle b) {}
        public void onPartialResults(Bundle b) {
            ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (l != null && !l.isEmpty()) partial = l.get(0);
        }
        public void onError(int e) {
            if (state == OFF || muted) return;
            if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || e == SpeechRecognizer.ERROR_CLIENT) resetRecognizer();
            listenSoon(e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ? 150 : 700);
        }
        public void onResults(Bundle b) {
            if (state == OFF || muted) return;
            ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (l == null || l.isEmpty() || l.get(0).trim().isEmpty()) { listenSoon(150); return; }
            lastVoice = SystemClock.elapsedRealtime();
            answer(ChloeActivity.best(l));
        }
    };

    // ------------------------------------------------------------------ pensar y contestar
    void answer(String q) {
        heard = q;
        partial = "";
        if (q.matches("(?i).*\\b(cuelga|colgar|adi[oó]s chloe|hasta luego chloe|termina la llamada|riattacca|hang up)\\b.*")) {
            said = L.t("¡Hasta luego! Aquí estaré.");
            speakThen(said, this::stopSelf);
            return;
        }
        Actions.Result r = Actions.parse(this, q);
        if (r != null) {
            boolean ok = Actions.run(this, r);
            said = ok ? r.say : L.t("No he podido abrirlo en este teléfono.");
            speak(said);
            return;
        }
        if (Mood.nonsense(q)) { said = Mood.confused(); speak(said); return; }
        state = THINKING;
        notifyNow();
        final int my = ++turn;
        final Voice.Streamer vs = new Voice.Streamer(this);      // v1.6: empieza a hablar con la primera frase
        new Thread(() -> {
            String raw = Brain.ask(this, q, so -> {
                if (my != turn || state == OFF) return;
                boolean was = vs.started;
                String t = vs.partial(so);
                if (!was && vs.started) h.post(() -> { if (my == turn && state != OFF) { state = SPEAKING; said = t; notifyNow(); } });
            });
            String cmd = Brain.cmdOf(raw);
            String ans = Brain.speech(raw);
            h.post(() -> {
                if (state == OFF || my != turn) { if (vs.started) Voice.stop(); return; }
                if (cmd != null) {
                    Actions.Result rc = Actions.parse(this, cmd);
                    if (rc != null && rc.intent != null) Actions.run(this, rc);
                }
                said = ans.isEmpty() ? Mood.confused() : ans;
                if (vs.started && !ans.isEmpty()) { vs.finish(said); waitThen(() -> listenSoon(250)); }
                else speak(said);
            });
        }, "live").start();
    }

    void speak(String text) { speakThen(text, () -> listenSoon(250)); }

    /** Habla y, cuando termina, hace «after». */
    void speakThen(String text, Runnable after) {
        Voice.say(this, text);
        waitThen(after);
    }

    /** v1.6: espera a que termine de hablar y hace «after». */
    void waitThen(Runnable after) {
        state = SPEAKING;
        notifyNow();
        final int my = turn;
        final long t0 = SystemClock.elapsedRealtime();
        h.postDelayed(new Runnable() {
            public void run() {
                if (state == OFF) return;
                if (my != turn) return;                                  // la interrumpiste
                boolean started = Voice.speaking || SystemClock.elapsedRealtime() - t0 > 2500;
                if (!started || Voice.speaking) { h.postDelayed(this, 150); return; }
                after.run();
            }
        }, 400);
    }

    // ------------------------------------------------------------------ notificación (como una llamada)
    Notification notification() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, LiveActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent hang = PendingIntent.getService(this, 1, new Intent(this, LiveService.class).setAction("hang"), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent mute = PendingIntent.getService(this, 2, new Intent(this, LiveService.class).setAction("mute"), PendingIntent.FLAG_IMMUTABLE);
        String st = state == THINKING ? L.t("Pensando…") : state == SPEAKING ? L.t("Hablando…") : muted ? L.t("Micrófono silenciado") : L.t("Escuchando…");
        Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "live") : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(L.t("Live con Chloe"))
                .setContentText(st)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_CALL)
                .setUsesChronometer(true)
                .setWhen(System.currentTimeMillis() - (SystemClock.elapsedRealtime() - startedAt))
                .setContentIntent(open)
                .setColor(Neon.color(this));
        if (android.os.Build.VERSION.SDK_INT >= 31 && !plain) {
            android.app.Person chloe = new android.app.Person.Builder().setName(Brain.botName(this)).setImportant(true).build();
            b.setStyle(Notification.CallStyle.forOngoingCall(chloe, hang));
            b.addAction(new Notification.Action.Builder(null, muted ? L.t("Activar micro") : L.t("Silenciar"), mute).build());
        } else {
            b.addAction(new Notification.Action.Builder(null, L.t("Colgar"), hang).build());
            b.addAction(new Notification.Action.Builder(null, muted ? L.t("Activar micro") : L.t("Silenciar"), mute).build());
        }
        return b.build();
    }

    void notifyNow() { if (nm != null && state != OFF) try { nm.notify(41, notification()); } catch (Exception ignored) {} }

    @Override
    public void onDestroy() {
        state = OFF;
        turn++;
        h.removeCallbacksAndMessages(null);
        cancelListen();
        resetRecognizer();
        ShieldService.yieldMic = false;
        super.onDestroy();
    }
}
