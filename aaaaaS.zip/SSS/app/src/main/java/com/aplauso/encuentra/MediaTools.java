package com.aplauso.encuentra;

import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Procesado de video y audio sin librerías externas (solo lo que trae Android). */
public class MediaTools {

    public interface Progress { void on(float fraction); }

    static long durationMs(Context c, Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(c, uri);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            return d == null ? 0 : Long.parseLong(d);
        } catch (Exception e) {
            return 0;
        } finally {
            try { r.release(); } catch (Exception ignored) {}
        }
    }

    static int rotation(Context c, Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(c, uri);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            return d == null ? 0 : Integer.parseInt(d);
        } catch (Exception e) {
            return 0;
        } finally {
            try { r.release(); } catch (Exception ignored) {}
        }
    }

    /**
     * Recorta un video (o saca su audio) copiando los datos tal cual, sin recomprimir: rápido y sin perder calidad.
     * El corte empieza en el fotograma clave más cercano anterior al inicio elegido.
     * Devuelve false si no hay pistas que se puedan copiar (p. ej. un audio que no es AAC).
     */
    static boolean remux(Context c, Uri src, File out, long startUs, long endUs,
                         boolean keepVideo, boolean keepAudio, Progress prog) throws IOException {
        MediaExtractor ex = new MediaExtractor();
        MediaMuxer mux = null;
        try {
            ex.setDataSource(c, src, null);
            mux = new MediaMuxer(out.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int n = ex.getTrackCount();
            int[] map = new int[n];
            Arrays.fill(map, -1);
            int maxSize = 4 * 1024 * 1024;
            int selected = 0;
            for (int i = 0; i < n; i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime == null) continue;
                boolean v = mime.startsWith("video/"), a = mime.startsWith("audio/");
                if ((v && keepVideo) || (a && keepAudio)) {
                    try {
                        map[i] = mux.addTrack(f);
                        ex.selectTrack(i);
                        selected++;
                        if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))
                            maxSize = Math.max(maxSize, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE));
                    } catch (Exception ignored) {
                        map[i] = -1; // formato que el contenedor MP4 no admite
                    }
                }
            }
            if (selected == 0) return false;
            if (keepVideo) mux.setOrientationHint(rotation(c, src));
            mux.start();

            ByteBuffer buf = ByteBuffer.allocate(maxSize);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            long base = ex.getSampleTime();
            if (base < 0) base = 0;
            long span = Math.max(1, endUs - base);
            while (true) {
                int size = ex.readSampleData(buf, 0);
                if (size < 0) break;
                long pts = ex.getSampleTime();
                int ti = ex.getSampleTrackIndex();
                if (pts < base || pts > endUs || ti < 0 || map[ti] < 0) { ex.advance(); continue; }
                info.offset = 0;
                info.size = size;
                info.presentationTimeUs = pts - base;
                info.flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                        ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                mux.writeSampleData(map[ti], buf, info);
                if (prog != null) prog.on(Math.min(1f, (pts - base) / (float) span));
                ex.advance();
            }
            mux.stop();
            return true;
        } finally {
            if (mux != null) try { mux.release(); } catch (Exception ignored) {}
            ex.release();
        }
    }

    /**
     * Decodifica el audio (de un audio o de un video) a WAV, aplicando recorte, volumen y fundidos.
     * Funciona con MP3, AAC, OGG, FLAC, AMR… lo que el teléfono sepa reproducir.
     */
    static void toWav(Context c, Uri src, File out, long startUs, long endUs, float gain,
                      long fadeInUs, long fadeOutUs, Progress prog) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec dec = null;
        RandomAccessFile raf = null;
        try {
            ex.setDataSource(c, src, null);
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) { track = i; fmt = f; break; }
            }
            if (track < 0) throw new Exception("El archivo no tiene audio");
            ex.selectTrack(track);
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);

            String mime = fmt.getString(MediaFormat.KEY_MIME);
            dec = MediaCodec.createDecoderByType(mime);
            dec.configure(fmt, null, null, 0);
            dec.start();

            int rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            int ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            boolean isFloat = false;

            raf = new RandomAccessFile(out, "rw");
            raf.setLength(0);
            raf.write(new byte[44]);
            long dataBytes = 0;
            long span = Math.max(1, endUs - startUs);

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inDone = false, outDone = false;
            while (!outDone) {
                if (!inDone) {
                    int ii = dec.dequeueInputBuffer(10_000);
                    if (ii >= 0) {
                        ByteBuffer ib = dec.getInputBuffer(ii);
                        int sz = ib == null ? -1 : ex.readSampleData(ib, 0);
                        long t = ex.getSampleTime();
                        if (sz < 0 || t > endUs) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            dec.queueInputBuffer(ii, 0, sz, t, 0);
                            ex.advance();
                        }
                    }
                }
                int oi = dec.dequeueOutputBuffer(info, 10_000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = dec.getOutputFormat();
                    rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    if (of.containsKey(MediaFormat.KEY_PCM_ENCODING))
                        isFloat = of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT;
                } else if (oi >= 0) {
                    ByteBuffer ob = dec.getOutputBuffer(oi);
                    if (ob != null && info.size > 0) {
                        ByteBuffer slice = ob.duplicate();
                        slice.position(info.offset);
                        slice.limit(info.offset + info.size);
                        ByteBuffer data = slice.slice().order(ByteOrder.nativeOrder());
                        int samples = isFloat ? info.size / 4 : info.size / 2;
                        int frames = samples / ch;
                        byte[] outB = new byte[frames * ch * 2];
                        int w = 0;
                        ShortBuffer sb = isFloat ? null : data.asShortBuffer();
                        FloatBuffer fb = isFloat ? data.asFloatBuffer() : null;
                        for (int f = 0; f < frames; f++) {
                            long t = info.presentationTimeUs + (long) f * 1_000_000L / rate;
                            boolean keep = t >= startUs && t <= endUs;
                            float g = gain;
                            if (fadeInUs > 0 && t - startUs < fadeInUs) g *= Math.max(0, (t - startUs) / (float) fadeInUs);
                            if (fadeOutUs > 0 && endUs - t < fadeOutUs) g *= Math.max(0, (endUs - t) / (float) fadeOutUs);
                            for (int k = 0; k < ch; k++) {
                                float s = isFloat ? fb.get() * 32767f : sb.get();
                                if (!keep) continue;
                                int v = Math.round(s * g);
                                if (v > 32767) v = 32767;
                                if (v < -32768) v = -32768;
                                outB[w++] = (byte) (v & 0xff);
                                outB[w++] = (byte) ((v >> 8) & 0xff);
                            }
                        }
                        if (w > 0) {
                            raf.write(outB, 0, w);
                            dataBytes += w;
                        }
                        if (prog != null) prog.on(Math.min(1f, Math.max(0, (info.presentationTimeUs - startUs) / (float) span)));
                    }
                    dec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                }
            }
            writeWavHeader(raf, rate, ch, dataBytes);
        } finally {
            if (dec != null) try { dec.stop(); dec.release(); } catch (Exception ignored) {}
            ex.release();
            if (raf != null) try { raf.close(); } catch (Exception ignored) {}
        }
    }

    static void writeWavHeader(RandomAccessFile f, int rate, int ch, long dataLen) throws IOException {
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes(StandardCharsets.US_ASCII));
        b.putInt((int) (36 + dataLen));
        b.put("WAVE".getBytes(StandardCharsets.US_ASCII));
        b.put("fmt ".getBytes(StandardCharsets.US_ASCII));
        b.putInt(16);
        b.putShort((short) 1);
        b.putShort((short) ch);
        b.putInt(rate);
        b.putInt(rate * ch * 2);
        b.putShort((short) (ch * 2));
        b.putShort((short) 16);
        b.put("data".getBytes(StandardCharsets.US_ASCII));
        b.putInt((int) dataLen);
        f.seek(0);
        f.write(b.array());
    }
}
