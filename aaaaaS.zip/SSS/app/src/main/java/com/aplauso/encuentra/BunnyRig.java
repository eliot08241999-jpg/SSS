package com.aplauso.encuentra;

/** v1.4.2 · El «esqueleto» de la Chloe conejita: cómo se deforma la imagen (sin Android, se puede probar). */
public class BunnyRig {
    public static final class Face {
        float lx, ly, rx, ry, mx, my; boolean mouth = true;
        float elx = 208, ely = 108, erx = 292, ery = 106;    // base de cada oreja (los pompones de la diadema)
        boolean earLeft = true;                               // en verano la izquierda va detrás del sombrero
        float earTop = 0;
        float lidBand = 32;                                   // cuánta mejilla se usa para pintar el párpado (invierno: la bufanda está cerca)                                      // verano: solo se mueve lo que asoma por encima
    }
    public static Face face(String o) {
        Face f = new Face();
        switch (o) {
            case "winter": f.lx = 224.3f; f.ly = 195f; f.rx = 275f; f.ry = 195.5f; f.mx = 248; f.my = 229; f.mouth = false; f.lidBand = 17; f.elx = 210; f.ely = 103; f.erx = 299; f.ery = 100; break;
            case "spring": f.lx = 223.3f; f.ly = 194.5f; f.rx = 275.8f; f.ry = 195f; f.mx = 247.5f; f.my = 231; f.elx = 205; f.ely = 108; f.erx = 291; f.ery = 105; break;
            case "summer": f.lx = 222.5f; f.ly = 194.3f; f.rx = 275f; f.ry = 195f; f.mx = 248.8f; f.my = 228.8f; f.earLeft = false; f.erx = 304; f.ery = 66; f.earTop = 1; break;
            default: f.lx = 222f; f.ly = 197.5f; f.rx = 275f; f.ry = 197f; f.mx = 245.8f; f.my = 230.5f;
        }
        return f;
    }


    static float smooth(float v) { v = Math.max(0, Math.min(1, v)); return v * v * (3 - 2 * v); }

    /** Posición de cada punto de la malla (MW+1)×(MH+1) para el fotograma actual. */
    public static void mesh(Face fc, Life lf, float W, float H, int MW, int MH, float[] mesh) {
        float px = W / 2, py = 300;
        double ang = Math.toRadians(lf.tilt);
        float ca = (float) Math.cos(ang), sa = (float) Math.sin(ang);
        double angL = Math.toRadians(lf.earL), angR = Math.toRadians(-lf.earR);
        float cL = (float) Math.cos(angL), sL = (float) Math.sin(angL), cR = (float) Math.cos(angR), sR = (float) Math.sin(angR);
        float fcx = (fc.lx + fc.rx) / 2, fcy = fc.ly + 10;
        int k = 0;
        for (int j = 0; j <= MH; j++) for (int i = 0; i <= MW; i++) {
            float x = W * i / MW, y = H * j / MH, X = x, Y = y;
            // orejas (rotación rígida sobre la base, más fuerte arriba)
            if (fc.earLeft && x < W / 2 && y < fc.ely) {
                float w = smooth((fc.ely - y) / 28f);
                float dx = x - fc.elx, dy = y - fc.ely;
                X += (dx * cL - dy * sL + fc.elx - x) * w; Y += (dx * sL + dy * cL + fc.ely - y) * w;
            } else if (x >= W / 2 && y < fc.ery && (fc.earTop == 0 || y < fc.ery - 6)) {
                float w = smooth((fc.ery - y) / (fc.earTop == 0 ? 28f : 18f));
                float dx = x - fc.erx, dy = y - fc.ery;
                X += (dx * cR - dy * sR + fc.erx - x) * w; Y += (dx * sR + dy * cR + fc.ery - y) * w;
            }
            // cara: se desplaza al girar / mirar arriba (más en el centro que en el pelo de fuera)
            float fd = (float) Math.hypot((x - fcx) / 70f, (y - fcy) / 62f);
            float fw = fd < 1 ? (1 - fd * fd) : 0;
            X += lf.turn * 7f * fw;
            Y += (lf.lookY * -2.2f) * fw;
            // ojos: el iris se mueve dentro del ojo
            for (int e = 0; e < 2; e++) {
                float ex = e == 0 ? fc.lx : fc.rx, ey = e == 0 ? fc.ly : fc.ry;
                float ed = (float) Math.hypot((x - ex) / 15f, (y - ey) / 13f);
                if (ed < 1) { float ew = (1 - ed) * (1 - ed); X += lf.lookX * 3.2f * ew; Y += lf.lookY * 2.6f * ew; }
            }
            // cabeza: gira y asiente sobre el cuello; el cuerpo casi no
            float hw = y < 250 ? 1 : y > 330 ? 0 : 1 - (y - 250) / 80f;
            if (hw > 0) {
                float dx = X - px, dy = Y - py;
                X += (dx * ca - dy * sa + px - X) * hw;
                Y += (dx * sa + dy * ca + py - Y) * hw + lf.nod * hw;
            }
            // mechones de los lados: brisa suave; el de la izquierda se enrosca si juega con él
            boolean sideL = x < fcx - 60, sideR = x > fcx + 60;
            if ((sideL || sideR) && y > 140) {
                float w = smooth((y - 140) / 220f) * smooth((Math.abs(x - fcx) - 60) / 50f);
                X += lf.hairSway * 6f * w;
                Y += Math.abs(lf.hairSway) * 1.2f * w;
            }
            if (lf.hairHand > 0.01f) {
                float hx = fc.lx - 50, hy = fc.ly + 56;
                float d = (float) Math.hypot(x - hx, (y - hy) * 0.7f);
                if (d < 60 && x < fcx - 30) {
                    float w = (1 - d / 60f) * lf.hairHand;
                    X += (float) Math.sin(lf.twirl) * 5f * w;
                    Y += ((float) Math.cos(lf.twirl) * 3f - 4f) * w;
                }
            }
            // pecho: respira
            if (y > H * 0.58f) { float bw = (y - H * 0.58f) / (H * 0.42f); Y -= lf.breath * 2.6f * bw; X += (x - W / 2) * lf.breath * 0.005f * bw; }
            mesh[k++] = X; mesh[k++] = Y;
        }
    }
}
