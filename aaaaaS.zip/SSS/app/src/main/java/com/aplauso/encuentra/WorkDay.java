package com.aplauso.encuentra;

import android.content.Context;
import android.content.Intent;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v1.3: «¿Qué asistencias tengo hoy?»: Chloe abre la app del trabajo (HomeCareOSA), lee la lista del día en
 * pantalla y te la dice: hora, persona, cuánto dura y dónde. Lo lee en el momento, no guarda nada.
 * Necesita el permiso de accesibilidad «Chloe · leer pantalla» (en la pantalla del asistente).
 */
public class WorkDay {
    static boolean asks(String said) {
        String s = Actions.norm(said);
        return s.matches(".*\\b(?:que|cuales|cuantas|cuantos|dime|dime las|dime mis|leeme|lee) ?(?:mis |las |los )?(?:asistencias|visitas|intervenciones|interventos|servicios|turnos de trabajo|pacientes|interventi)\\b.*")
                || s.matches(".*\\b(?:mis|las) (?:asistencias|visitas|intervenciones) (?:de hoy|del dia|para hoy|de manana|para manana)\\b.*")
                || s.matches("^(?:asistencias|interventi giornalieri|mis asistencias)$")
                || s.matches(".*\\b(?:asistencias|visitas|intervenciones) (?:hay )?en (?:la )?pantalla\\b.*");
    }

    static String appName(Context c) {
        String a = c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("work_app", "").trim();
        return a.isEmpty() ? "homecare" : a;
    }

    /** Bloquea unos segundos (abrir la app y leer): llamar desde un hilo. */
    static String handle(Context c, String said) {
        if (!asks(said)) return null;
        Intent app = Actions.appIntent(c, appName(c));
        if (app == null) return L.t("No encuentro la app de tus asistencias (HomeCareOSA). Si se llama de otra forma, escríbela en la pantalla del asistente.");
        String pkg = app.getComponent() != null ? app.getComponent().getPackageName() : app.getPackage();
        try { app.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.getApplicationContext().startActivity(app); } catch (Exception e) { return L.t("No he podido abrir la app de tus asistencias."); }
        if (!ScreenReader.on())
            return L.t("Te abro tus asistencias. Para leértelas en voz alta necesito el permiso «Chloe · leer pantalla»: actívalo en la pantalla del asistente, apartado TRABAJO.");
        // esperar a que cargue la lista (hasta 8 s)
        List<String> t = new ArrayList<>();
        for (int i = 0; i < 32; i++) {
            try { Thread.sleep(250); } catch (InterruptedException ignored) {}
            if (!pkg.equals(ScreenReader.packageInFront())) continue;
            t = ScreenReader.texts();
            if (joined(t).toLowerCase(Locale.ROOT).contains("orario")) break;
        }
        int off = Math.max(0, Routines.dayOf(Actions.norm(said)));
        if (off == 0) return summarize(t, "");
        return otherDay(t, off);
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }

    /** Espera hasta que en pantalla aparezca el texto (como mucho «ms»). */
    static boolean waitFor(String regex, long ms) {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(regex, java.util.regex.Pattern.CASE_INSENSITIVE);
        for (long w = 0; w < ms; w += 250) {
            if (p.matcher(joined(ScreenReader.texts())).find()) return true;
            sleep(250);
        }
        return false;
    }

    /**
     * v1.3: otro día (mañana, pasado mañana, el viernes…), como lo harías a mano en HomeCareOSA:
     * ☰ → «Calendario Assistenza» → (mes siguiente si hace falta) → tocar el día → leer la lista.
     */
    static String otherDay(List<String> today, int off) {
        Calendar d = Calendar.getInstance();
        int curMonth = d.get(Calendar.MONTH);
        d.add(Calendar.DAY_OF_YEAR, off);
        int day = d.get(Calendar.DAY_OF_MONTH);
        String want = new java.text.SimpleDateFormat("dd/MM/yyyy", Locale.ROOT).format(d.getTime());
        String word = off == 1 ? L.t("Mañana") : off == 2 ? L.t("Pasado mañana") : Routines.dayName(off);
        // 1) menú ☰
        if (!ScreenReader.click("navigat|drawer|apri|open|menu|navigazione|navegaci")) ScreenReader.swipeFromLeft();
        sleep(700);
        // 2) «Calendario Assistenza»
        if (!ScreenReader.click("calendario")) return L.t("He abierto tu app, pero no encuentro el «Calendario Assistenza» en el menú.");
        if (!waitFor("calendario assistenza|lun|mar|gen|feb|nov|dic|\\b1\\b", 5000)) return L.t("El calendario de tu app no ha cargado. Prueba otra vez en un momento.");
        sleep(500);
        // 3) si el día cae en el mes siguiente, avanzar el mes
        if (d.get(Calendar.MONTH) != curMonth) {
            ScreenReader.click("mese successivo|next month|successiv|avanti|forward|chevron_right|arrow_forward|^\\s*[>›»]\\s*$");
            sleep(800);
        }
        // 4) tocar el día
        if (!ScreenReader.click("^\\s*" + day + "\\s*$")) return L.t("No consigo tocar el día") + " " + day + " " + L.t("en el calendario de tu app.");
        // 5) leer la lista de ese día
        String before = joined(today);
        List<String> t = new ArrayList<>();
        for (int i = 0; i < 32; i++) {
            sleep(250);
            t = ScreenReader.texts();
            String now = joined(t);
            if (now.toLowerCase(Locale.ROOT).contains("orario") && !now.equals(before)) break;
        }
        String shown = joined(t);
        if (!shown.toLowerCase(Locale.ROOT).contains("orario")) {
            if (shown.contains(want) || shown.contains(want.substring(0, 5))) return word + " (" + want + ") " + L.t("no tienes asistencias.");
            return L.t("He abierto el día") + " " + day + ", " + L.t("pero no veo ninguna asistencia. Mira la pantalla, por si acaso.");
        }
        String r = summarize(t, word);
        if (!shown.contains(want) && !shown.contains(want.replaceFirst("^0", "")))
            r = L.t("No estoy segura de que sea el día") + " " + want + ", " + L.t("pero en pantalla aparece esto:") + " " + r;
        return r;
    }

    static String joined(List<String> t) { StringBuilder b = new StringBuilder(); for (String s : t) b.append(s).append('\n'); return b.toString(); }

    static final class Visit { String who = "", time = "", place = ""; int mins; }

    static final Pattern FIELD = Pattern.compile("^(Orario|Durata|Indirizzo|Codice Fiscale|Commessa|Ora|Hora|Duración|Dirección)\\s*:\\s*(.*)$", Pattern.CASE_INSENSITIVE);

    /** Convierte lo que se ve en pantalla en una frase para decir en voz alta. */
    static String summarize(List<String> t) { return summarize(t, ""); }

    static String summarize(List<String> t, String dayWord) {
        List<Visit> vs = new ArrayList<>();
        Visit cur = null;
        String date = "";
        for (int i = 0; i < t.size(); i++) {
            String line = t.get(i).trim();
            Matcher d = Pattern.compile("(\\d{1,2}/\\d{1,2}/\\d{2,4})").matcher(line);
            if (date.isEmpty() && line.toLowerCase(Locale.ROOT).contains("interventi") && d.find()) { date = d.group(1); continue; }
            Matcher f = FIELD.matcher(line);
            if (f.matches()) {
                String key = f.group(1).toLowerCase(Locale.ROOT), val = f.group(2).trim();
                if (val.isEmpty() && i + 1 < t.size()) val = t.get(++i).trim();
                if (cur == null) { cur = new Visit(); vs.add(cur); }
                if (key.startsWith("orario") || key.equals("ora") || key.equals("hora")) cur.time = val;
                else if (key.startsWith("durat")) { Matcher m = Pattern.compile("(\\d+)").matcher(val); if (m.find()) cur.mins = Integer.parseInt(m.group(1)); }
                else if (key.startsWith("indiri") || key.startsWith("direcc")) cur.place = val;
                continue;
            }
            // un nombre: mayúsculas, sin «:», dos palabras o más
            if (!line.contains(":") && line.matches("[A-ZÀ-ÝÑ' ]{5,}") && line.trim().split("\\s+").length >= 2
                    && !line.matches("(?i).*(homecare|benvenuto|interventi).*")) {
                cur = new Visit();
                cur.who = title(line);
                vs.add(cur);
            }
        }
        vs.removeIf(v -> v.time.isEmpty());
        if (vs.isEmpty()) return L.t("He abierto tus asistencias, pero no consigo leer la lista. Mira la pantalla.");
        StringBuilder b = new StringBuilder();
        b.append(dayWord.isEmpty() ? L.t("Hoy") : dayWord).append(date.isEmpty() ? "" : " (" + date + ")").append(" ")
                .append(vs.size() == 1 ? L.t("tienes una asistencia") : L.t("tienes") + " " + vs.size() + " " + L.t("asistencias")).append(". ");
        for (Visit v : vs) {
            b.append(L.t("A las")).append(' ').append(v.time);
            if (!v.who.isEmpty()) b.append(", ").append(v.who);
            if (v.mins > 0) b.append(", ").append(duration(v.mins));
            if (!v.place.isEmpty()) b.append(", ").append(L.t("en")).append(' ').append(title(v.place));
            b.append(". ");
        }
        if (!dayWord.isEmpty()) return b.toString().trim();
        // la siguiente
        Calendar now = Calendar.getInstance();
        int nowM = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        for (Visit v : vs) {
            Matcher m = Pattern.compile("(\\d{1,2})[:.](\\d{2})").matcher(v.time);
            if (m.find() && Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2)) > nowM) {
                b.append(L.t("La siguiente es a las")).append(' ').append(v.time).append(v.who.isEmpty() ? "" : " " + L.t("con") + " " + v.who).append('.');
                break;
            }
        }
        return b.toString().trim();
    }

    static String duration(int m) {
        int h = m / 60, r = m % 60;
        String s = h == 0 ? "" : h == 1 ? L.t("1 hora") : h + " " + L.t("horas");
        if (r > 0) s += (s.isEmpty() ? "" : " " + L.t("y") + " ") + r + " " + L.t("minutos");
        return s;
    }

    static String title(String s) {
        StringBuilder b = new StringBuilder();
        for (String w : s.toLowerCase(Locale.ROOT).split("\\s+")) {
            if (w.isEmpty()) continue;
            if (b.length() > 0) b.append(' ');
            b.append(w.matches("de|di|del|della|la|el|da|y|e") && b.length() > 0 ? w : Character.toUpperCase(w.charAt(0)) + w.substring(1));
        }
        return b.toString();
    }
}
