package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.SystemClock;

import java.io.DataInputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.LongBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

/**
 * v1.5 · LA VOZ PROPIA DE CHLOE. Un modelo de voz libre (Kokoro, 82 M) que funciona dentro del teléfono, sin internet
 * y gratis. La voz es ORIGINAL: se hace mezclando voces sintéticas del modelo en las proporciones que tú pongas
 * (no se copia la voz de ninguna persona) y luego se retoca: tono, aire, eses, brillo…
 * De momento habla español; en italiano e inglés Chloe sigue con la voz del teléfono.
 */
public class KokoroVoice {
    static final String BASE = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/";
    /**
     * v1.5.3: el modelo COMPLETO (325 MB). El «int8» (114 MB) de antes dejaba un silbido metálico (dos pitidos fijos, a 4800
     * y 9600 Hz) y borroneaba la voz; además, en el móvil el completo va unas 4 veces más rápido.
     */
    static final String MODEL = "kokoro-v1.0.onnx", MODEL_OLD = "kokoro-v1.0.int8.onnx", VOICES = "voices-v1.0.bin";
    static final String[] FILES = {MODEL, VOICES};
    static final long MIN_MODEL = 250L << 20, MIN_OLD = 80L << 20, MIN_VOICES = 20L << 20;

    static boolean hq(Context c) { File m = new File(dir(c), MODEL); return FastDownload.complete(m) && m.length() > MIN_MODEL; }
    static boolean oldOnly(Context c) { File m = new File(dir(c), MODEL_OLD); return !hq(c) && FastDownload.complete(m) && m.length() > MIN_OLD; }

    /** Lo que falta por bajar. */
    static List<String> needed(Context c) {
        List<String> n = new ArrayList<>();
        if (!hq(c)) n.add(MODEL);
        File v = new File(dir(c), VOICES);
        if (!(FastDownload.complete(v) && v.length() > MIN_VOICES)) n.add(VOICES);
        return n;
    }
    static final int ROWS = 510, DIM = 256;

    /** Voces que salen primero en el mezclador (femeninas y suaves). */
    static final String[] MAIN = {"ef_dora", "af_nicole", "af_heart", "af_bella", "af_sky", "af_sarah", "jf_alpha", "jf_tebukuro", "if_sara", "ff_siwis", "bf_emma"};
    /** Las que dan «expresión» (se usa solo su manera de entonar, no su timbre). */
    static final String[] LIVELY = {"af_bella", "af_heart"};

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static File dir(Context c) { return new File(c.getExternalFilesDir(null), "kokoro"); }

    static boolean filesReady(Context c) {
        File d = dir(c);
        File v = new File(d, VOICES);
        return (hq(c) || oldOnly(c)) && FastDownload.complete(v) && v.length() > MIN_VOICES;
    }

    static boolean on(Context c) { return prefs(c).getBoolean("kv_on", false); }

    /** ¿Se usa esta voz para un texto en ese idioma? */
    static boolean use(Context c, String lang) {
        return "es".equals(lang) && on(c) && failures < 2 && filesReady(c) && !FastDownload.running("kokoro");
    }

    // ------------------------------------------------------------------ el modelo
    static OrtEnvironment env;
    static OrtSession sess;
    static String tokensName = "input_ids";
    static ZipFile zip;
    static final Map<String, float[]> voiceCache = new HashMap<>();
    static float[] meanPros;                 // media de la entonación de las voces femeninas [ROWS][128]
    static volatile String error = "";
    static volatile int failures;
    static volatile boolean loading;
    /** Con el modelo viejo se quitan sus dos pitidos con filtros. */
    static volatile boolean usingOld;
    /** Lo que tardó la última frase y lo que dura (para saber si tu teléfono va sobrado). */
    static volatile float lastMakeSec, lastAudioSec, firstSoundSec;

    static boolean loaded() { return sess != null; }

    static synchronized void load(Context c) throws Exception {
        if (sess != null) return;
        loading = true;
        try {
            File d = dir(c);
            usingOld = !hq(c);
            File m = new File(d, usingOld ? MODEL_OLD : MODEL);
            if (usingOld) OnnxPatch.fixConvInteger(m);   // solo el modelo viejo lo necesita
            if (env == null) env = OrtEnvironment.getEnvironment();
            OrtSession.SessionOptions o = new OrtSession.SessionOptions();
            o.setIntraOpNumThreads(Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors() - 2)));
            o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
            sess = env.createSession(m.getAbsolutePath(), o);
            tokensName = sess.getInputInfo().containsKey("input_ids") ? "input_ids" : "tokens";
            zip = new ZipFile(new File(d, VOICES));
            error = "";
        } finally { loading = false; }
    }

    static synchronized void unload() {
        stop();
        if (sess != null) try { sess.close(); } catch (Exception ignored) {}
        sess = null;
        if (zip != null) try { zip.close(); } catch (Exception ignored) {}
        zip = null;
        voiceCache.clear();
        meanPros = null;
    }

    static void delete(Context c) {
        unload();
        File[] fs = dir(c).listFiles();
        if (fs != null) for (File f : fs) f.delete();
        failures = 0;
    }

    /** Nombres de las voces del archivo (sin «.npy»). */
    static List<String> voiceNames(Context c) {
        List<String> out = new ArrayList<>();
        try (ZipFile z = new ZipFile(new File(dir(c), VOICES))) {
            java.util.Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) { String n = en.nextElement().getName(); if (n.endsWith(".npy")) out.add(n.substring(0, n.length() - 4)); }
        } catch (Exception ignored) {}
        java.util.Collections.sort(out);
        return out;
    }

    /** Una voz entera: ROWS filas de DIM números (un archivo .npy dentro del zip). */
    static float[] voice(String name) throws Exception {
        float[] v = voiceCache.get(name);
        if (v != null) return v;
        ZipEntry e = zip.getEntry(name + ".npy");
        if (e == null) throw new Exception("no está la voz " + name);
        try (InputStream in = zip.getInputStream(e)) {
            v = readNpy(in);
        }
        if (voiceCache.size() > 12) voiceCache.clear();
        voiceCache.put(name, v);
        return v;
    }

    static float[] readNpy(InputStream in0) throws Exception {
        DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(in0, 1 << 16));
        byte[] h = new byte[10];
        in.readFully(h);
        if ((h[0] & 0xff) != 0x93 || h[1] != 'N') throw new Exception("voces: formato raro");
        int hl = (h[8] & 0xff) | (h[9] & 0xff) << 8;
        if (h[6] >= 2) { byte[] x = new byte[2]; in.readFully(x); hl |= (x[0] & 0xff) << 16 | (x[1] & 0xff) << 24; }
        byte[] head = new byte[hl];
        in.readFully(head);
        if (!new String(head, "US-ASCII").contains("<f4")) throw new Exception("voces: no son float32");
        byte[] raw = new byte[ROWS * DIM * 4];
        in.readFully(raw);
        float[] v = new float[ROWS * DIM];
        ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(v);
        return v;
    }

    /** Media de la «entonación» (segunda mitad del estilo) de las voces femeninas: el punto neutro para exagerar o calmar. */
    static float[] meanPros() throws Exception {
        if (meanPros != null) return meanPros;
        float[] m = new float[ROWS * 128];
        int n = 0;
        java.util.Enumeration<? extends ZipEntry> en = zip.entries();
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            String nm = e.getName();
            if (nm.length() < 3 || nm.charAt(1) != 'f' || !nm.endsWith(".npy")) continue;
            float[] v;
            try (InputStream in = zip.getInputStream(e)) { v = readNpy(in); }
            for (int r = 0; r < ROWS; r++) for (int k = 0; k < 128; k++) m[r * 128 + k] += v[r * DIM + 128 + k];
            n++;
        }
        if (n > 0) for (int i = 0; i < m.length; i++) m[i] /= n;
        return meanPros = m;
    }

    // ------------------------------------------------------------------ la mezcla
    /** Pesos de la mezcla guardados (voz → 0..100). Si no hay ninguno, la mezcla «Susurro» que elegiste. */
    static Map<String, Integer> weights(Context c) {
        Map<String, Integer> w = new LinkedHashMap<>();
        for (Map.Entry<String, ?> e : prefs(c).getAll().entrySet())
            if (e.getKey().startsWith("kv_w_") && e.getValue() instanceof Integer && (Integer) e.getValue() > 0) w.put(e.getKey().substring(5), (Integer) e.getValue());
        if (w.isEmpty()) { w.put("ef_dora", 40); w.put("af_nicole", 60); }
        return w;
    }

    /**
     * El «estilo» para una frase de n fonemas: mezcla de voces; y la entonación (segunda mitad) se acerca a voces
     * más vivas y se exagera según EXPRESIÓN.
     */
    static synchronized float[] style(Map<String, Integer> w, int n, float expr) throws Exception {
        int row = Math.max(0, Math.min(n, ROWS) - 1);
        float[] s = new float[DIM];
        float sum = 0;
        for (Map.Entry<String, Integer> e : w.entrySet()) {
            float[] v;
            try { v = voice(e.getKey()); } catch (Exception x) { continue; }
            float k = e.getValue();
            sum += k;
            for (int i = 0; i < DIM; i++) s[i] += k * v[row * DIM + i];
        }
        if (sum <= 0) { float[] v = voice("ef_dora"); System.arraycopy(v, row * DIM, s, 0, DIM); sum = 1; }
        for (int i = 0; i < DIM; i++) s[i] /= sum;
        if (expr > 0.01f) {
            float d = 0.5f * expr, k = 1 + 0.35f * expr;
            float[] live = new float[128];
            int nl = 0;
            for (String name : LIVELY) try { float[] v = voice(name); for (int i = 0; i < 128; i++) live[i] += v[row * DIM + 128 + i]; nl++; } catch (Exception ignored) {}
            float[] mean = meanPros();
            for (int i = 0; i < 128; i++) {
                float p = s[128 + i];
                if (nl > 0) p = (1 - d) * p + d * live[i] / nl;
                float m = mean[row * 128 + i];
                s[128 + i] = m + k * (p - m);
            }
        }
        return s;
    }

    static synchronized float[] infer(long[] ids, float[] style, float speed) throws Exception {
        OnnxTensor a = OnnxTensor.createTensor(env, LongBuffer.wrap(ids), new long[]{1, ids.length});
        OnnxTensor b = OnnxTensor.createTensor(env, FloatBuffer.wrap(style), new long[]{1, DIM});
        OnnxTensor s = OnnxTensor.createTensor(env, FloatBuffer.wrap(new float[]{speed}), new long[]{1});
        try {
            Map<String, OnnxTensor> m = new HashMap<>();
            m.put(tokensName, a);
            m.put("style", b);
            m.put("speed", s);
            try (OrtSession.Result r = sess.run(m)) { return SdEngine.floats(r.get(0)); }
        } finally { a.close(); b.close(); s.close(); }
    }

    // ------------------------------------------------------------------ hablar
    static volatile int gen;
    static volatile AudioTrack track;

    /** Ajustes de un golpe (para no leerlos a mitad de frase). */
    static final class Cfg {
        float pitch, speed, expr, pause;
        int maxLen;
        boolean quick;
        VoiceFx fx = new VoiceFx();
        Map<String, Integer> w;

        Cfg(Context c) {
            SharedPreferences p = prefs(c);
            pitch = p.getInt("kv_pitch", 108) / 100f;
            speed = p.getInt("kv_speed", 88) / 100f;
            expr = p.getInt("kv_expr", 40) / 100f;
            pause = p.getInt("kv_pause", 100) / 100f;
            int lat = p.getInt("kv_lat", 35);                 // 0 = empieza cuanto antes · 100 = frases enteras, más natural
            maxLen = 60 + lat * 2;
            quick = lat < 60;
            fx.air = p.getInt("kv_air", 35) / 100f;
            fx.softS = p.getInt("kv_s", 40) / 100f;
            fx.softT = p.getInt("kv_t", 30) / 100f;
            fx.bright = p.getInt("kv_bright", 10) / 100f;
            fx.volume = p.getInt("kv_vol", 100) / 100f;
            w = weights(c);
        }
    }

    /** Hace el sonido de un trozo ya retocado (sin reproducirlo). */
    static float[] make(Cfg g, KokoroText.Chunk ch) throws Exception {
        float sp = Math.max(0.5f, Math.min(2f, g.speed * ch.speedMul / g.pitch));   // al subir el tono se acelera: se compensa aquí
        float[] wav = infer(ch.ids, style(g.w, ch.ids.length - 2, g.expr), sp);
        float keep = g.fx.volume;
        g.fx.volume = keep * ch.volMul;
        g.fx.notch = usingOld;
        float[] out = g.fx.process(VoiceFx.trim(wav));
        g.fx.volume = keep;
        return out;
    }

    interface Done { void done(boolean ok); }

    /** Dice el texto. Si algo falla, avisa con ok=false para que hable la voz del teléfono. */
    static void speak(Context c0, String text, Done done) { speak(c0, text, done, false); }

    /** v1.6: lo que se añade mientras habla (la respuesta llega a trozos). */
    static final LinkedBlockingQueue<String> more = new LinkedBlockingQueue<>();
    static volatile boolean open;

    /** Añade texto a lo que está diciendo; «last» = ya no viene más. */
    static void more(String text, boolean last) {
        if (text != null && !text.trim().isEmpty()) more.offer(text);
        if (last) open = false;
    }

    static void speak(Context c0, String text, Done done, boolean keepOpen) {
        final Context c = c0.getApplicationContext();
        stop();
        more.clear();
        open = keepOpen;
        final int my = ++gen;
        Voice.speaking = true;
        final LinkedBlockingQueue<Object> q = new LinkedBlockingQueue<>(3);
        final Object END = new Object();
        final long t0 = SystemClock.elapsedRealtime();
        final Cfg g = new Cfg(c);
        final boolean[] failed = {false};

        Thread maker = new Thread(() -> {
            try {
                load(c);
                List<KokoroText.Chunk> chunks = new java.util.ArrayList<>(KokoroText.split(text, g.maxLen, g.quick, g.expr, g.pause, new java.util.Random()));
                for (int ci = 0; ; ci++) {
                    if (gen != my) break;
                    if (ci >= chunks.size()) {                          // v1.6: ¿llega más texto?
                        String nx = null;
                        while (gen == my && nx == null && (open || !more.isEmpty())) nx = more.poll(150, java.util.concurrent.TimeUnit.MILLISECONDS);
                        if (nx == null) break;
                        chunks.addAll(KokoroText.split(nx, g.maxLen, false, g.expr, g.pause, new java.util.Random()));
                        if (ci >= chunks.size()) { ci--; continue; }
                    }
                    KokoroText.Chunk ch = chunks.get(ci);
                    long t = SystemClock.elapsedRealtime();
                    float[] wav = make(g, ch);
                    lastMakeSec = (SystemClock.elapsedRealtime() - t) / 1000f;
                    lastAudioSec = wav.length / (VoiceFx.SR * g.pitch);
                    int sil = (int) (ch.pause * VoiceFx.SR * g.pitch);
                    short[] pcm = new short[wav.length + sil];
                    for (int i = 0; i < wav.length; i++) pcm[i] = (short) Math.max(-32767, Math.min(32767, Math.round(wav[i] * 32767)));
                    while (gen == my && !q.offer(pcm, 200, java.util.concurrent.TimeUnit.MILLISECONDS)) { /* espera a que haya sitio */ }
                }
                failures = 0;
            } catch (Throwable e) {
                failed[0] = true;
                failures++;
                error = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            try { while (gen == my && !q.offer(END, 200, java.util.concurrent.TimeUnit.MILLISECONDS)) { /* */ } } catch (InterruptedException ignored) {}
        }, "voz-chloe-hacer");
        maker.setPriority(Thread.MAX_PRIORITY - 1);
        maker.start();

        new Thread(() -> {
            AudioTrack tr = null;
            boolean any = false;
            try {
                int rate = Math.round(VoiceFx.SR * g.pitch);
                int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                tr = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                        .setBufferSizeInBytes(Math.max(min, rate / 4 * 2)).setTransferMode(AudioTrack.MODE_STREAM).build();
                track = tr;
                tr.play();
                long written = 0;
                int block = rate / 25;                                   // 40 ms
                float env = 0;
                while (gen == my) {
                    Object o = q.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS);
                    if (o == null) continue;
                    if (o == END) break;
                    short[] pcm = (short[]) o;
                    if (!any) { any = true; firstSoundSec = (SystemClock.elapsedRealtime() - t0) / 1000f; }
                    for (int p = 0; p < pcm.length && gen == my; p += block) {
                        int n = Math.min(block, pcm.length - p);
                        // la boca de Chloe: cada vez que la voz sube (una sílaba), se avisa
                        float a = 0;
                        for (int i = p; i < p + n; i += 4) a += Math.abs(pcm[i]);
                        a /= Math.max(1, n / 4);
                        if (a > 900 && a > env * 1.25f) Voice.lastWord = SystemClock.uptimeMillis();
                        env = env * 0.6f + a * 0.4f;
                        int w = tr.write(pcm, p, n);
                        if (w < 0) throw new Exception("audio " + w);
                        written += w;
                    }
                }
                if (gen == my && any) {                                  // deja que suene lo que queda
                    tr.stop();
                    long limit = SystemClock.elapsedRealtime() + 1500;
                    while (gen == my && tr.getPlaybackHeadPosition() < written && SystemClock.elapsedRealtime() < limit) Thread.sleep(30);
                }
            } catch (Throwable e) {
                if (!any) failed[0] = true;
                error = e.getMessage() == null ? e.toString() : e.getMessage();
            } finally {
                if (tr != null) { try { tr.pause(); tr.flush(); } catch (Exception ignored) {} try { tr.release(); } catch (Exception ignored) {} }
                if (track == tr) track = null;
                if (gen == my) {
                    boolean ok = !(failed[0] && !any);
                    if (ok) Voice.speaking = false;
                    if (done != null) done.done(ok);
                }
            }
        }, "voz-chloe-sonar").start();
    }

    static void stop() {
        gen++;
        open = false;
        more.clear();
        AudioTrack t = track;
        if (t != null) try { t.pause(); t.flush(); } catch (Exception ignored) {}
    }

    /** Carga el modelo por adelantado para que la primera frase no tarde. */
    static void warm(Context c0) {
        final Context c = c0.getApplicationContext();
        if (loaded() || loading || !filesReady(c)) return;
        new Thread(() -> { try { load(c); } catch (Throwable e) { error = e.getMessage() == null ? e.toString() : e.getMessage(); } }, "voz-chloe-cargar").start();
    }
}
