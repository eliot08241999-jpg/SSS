package com.aplauso.encuentra;

import java.util.Random;

/**
 * v1.3: cuando Chloe no entiende algo, en vez de inventarse una respuesta lo dice con gracia
 * y te pide que lo repitas. Una frase distinta cada vez (no repite la última).
 */
public class Mood {
    static final String[] CONFUSED = {
            "¿Perdona? Eso no me ha entrado ni de lado. ¿Me lo repites?",
            "Vale, me he quedado en blanco… ¿Qué me estás pidiendo exactamente?",
            "Juraría que has dicho algo importante, pero solo he oído «bla, bla, bla». Otra vez, porfa.",
            "Mi oído acaba de hacer cortocircuito. ¿Me lo dices de otra forma?",
            "Eso suena a orden secreta… y no tengo la clave. ¿Me lo explicas?",
            "Estoy intentando procesarlo y me sale humo. ¿Lo repetimos más despacio?",
            "Ni idea de qué me pides, pero me ha encantado tu entusiasmo. ¿Otra vez?",
    };
    static final String[] NOT_HEARD = {
            "Hola… ¿hay alguien? No te he oído. Toca el micrófono y prueba otra vez.",
            "Silencio total. O me hablas muy bajito o me has dejado plantada. 🎤",
            "No he pillado nada. Acércame un poco más y vuelve a intentarlo.",
    };
    static int last = -1;
    static final Random R = new Random();

    static String pick(String[] a) {
        int i;
        do i = R.nextInt(a.length); while (a.length > 1 && i == last);
        last = i;
        return L.t(a[i]);
    }

    static String confused() { return pick(CONFUSED); }
    static String notHeard() { return pick(NOT_HEARD); }

    /** ¿Lo que ha llegado parece ruido del reconocedor y no una frase? («a la», «eh», «mm»…) */
    static boolean nonsense(String q) {
        boolean r = nonsense0(q);
        if (r) Brain.note(q, L.t("(No te he entendido.)"));   // v1.6: que quede en la conversación (si no, retoma la pregunta anterior)
        return r;
    }

    static boolean nonsense0(String q) {
        if (q != null && q.matches("(?s).*\\d.*") && q.matches("(?s).*[-+*/^=x×÷²³%?].*|(?s).*\\d.*\\d.*")) return false;   // v1.6: «1+1?» es una cuenta
        String s = Actions.norm(q).replaceAll("[^a-z0-9 ]", " ").trim();
        if (s.replace(" ", "").length() < 3) return true;
        String[] w = s.split("\\s+");
        if (w.length == 1 && w[0].length() <= 3 && !w[0].matches("\\d+|hora|sos|si|no")) return true;
        return s.matches("^(?:e+h*|m+|a+h*|u+m+|o+h*|a la|y la|de la|el la|que que|la la)$");
    }
}
