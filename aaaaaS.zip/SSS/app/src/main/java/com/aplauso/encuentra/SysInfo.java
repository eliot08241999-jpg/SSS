package com.aplauso.encuentra;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.os.StatFs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Locale;

/** Lectura de datos del sistema. Todo lo que el fabricante bloquee devuelve "no disponible". */
public class SysInfo {

    // ---------------- Batería ----------------
    static class Battery {
        int percent = -1;
        float tempC = Float.NaN;
        int voltageMv = -1;
        String health = "—", status = "—", plugged = "—", tech = "—";
        int cycles = -1;
        int capacityMah = -1;     // capacidad actual estimada
        int currentMa = Integer.MIN_VALUE;
        long chargeTimeLeftMs = -1;
        boolean charging;
    }

    static Battery battery(Context c) {
        Battery b = new Battery();
        Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return b;
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        if (level >= 0 && scale > 0) b.percent = Math.round(level * 100f / scale);
        int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
        if (t != Integer.MIN_VALUE) b.tempC = t / 10f;
        b.voltageMv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
        String tech = i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
        if (tech != null) b.tech = tech;
        if (Build.VERSION.SDK_INT >= 34) b.cycles = i.getIntExtra("android.os.extra.CYCLE_COUNT", -1);

        switch (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            case BatteryManager.BATTERY_HEALTH_GOOD: b.health = "Buena"; break;
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: b.health = "Sobrecalentada"; break;
            case BatteryManager.BATTERY_HEALTH_DEAD: b.health = "Agotada"; break;
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: b.health = "Sobretensión"; break;
            case BatteryManager.BATTERY_HEALTH_COLD: b.health = "Demasiado fría"; break;
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: b.health = "Fallo"; break;
            default: b.health = "Desconocida";
        }
        int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, 0);
        b.charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
        switch (st) {
            case BatteryManager.BATTERY_STATUS_CHARGING: b.status = "Cargando"; break;
            case BatteryManager.BATTERY_STATUS_DISCHARGING: b.status = "Descargando"; break;
            case BatteryManager.BATTERY_STATUS_FULL: b.status = "Llena"; break;
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING: b.status = "Sin cargar"; break;
            default: b.status = "Desconocido";
        }
        switch (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            case BatteryManager.BATTERY_PLUGGED_AC: b.plugged = "Cargador"; break;
            case BatteryManager.BATTERY_PLUGGED_USB: b.plugged = "USB"; break;
            case BatteryManager.BATTERY_PLUGGED_WIRELESS: b.plugged = "Inalámbrica"; break;
            default: b.plugged = "Desconectado";
        }

        BatteryManager bm = c.getSystemService(BatteryManager.class);
        if (bm != null) {
            int counter = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER); // µAh
            if (counter > 0 && b.percent > 5) {
                int mah = Math.round(counter / 1000f / (b.percent / 100f));
                if (mah > 500 && mah < 30000) b.capacityMah = mah;
            }
            int now = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW); // µA (algunos móviles mA)
            if (now != Integer.MIN_VALUE && now != 0) {
                b.currentMa = Math.abs(now) > 20000 ? now / 1000 : now;
            }
            if (Build.VERSION.SDK_INT >= 28 && b.charging) b.chargeTimeLeftMs = bm.computeChargeTimeRemaining();
        }
        return b;
    }

    // ---------------- Temperatura / estado térmico ----------------
    static String thermalStatus(Context c) {
        if (Build.VERSION.SDK_INT < 29) return "No disponible";
        PowerManager pm = c.getSystemService(PowerManager.class);
        switch (pm.getCurrentThermalStatus()) {
            case PowerManager.THERMAL_STATUS_NONE: return "Normal ❄";
            case PowerManager.THERMAL_STATUS_LIGHT: return "Templado";
            case PowerManager.THERMAL_STATUS_MODERATE: return "Caliente";
            case PowerManager.THERMAL_STATUS_SEVERE: return "Muy caliente ⚠";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "Crítico ⚠";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "Emergencia ⚠";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "Apagado térmico ⚠";
            default: return "Desconocido";
        }
    }

    /** Temperatura de la CPU leyendo los sensores del sistema; NaN si el fabricante lo bloquea. */
    static float cpuTempC() {
        float best = Float.NaN;
        for (int z = 0; z < 40; z++) {
            String type = readLine("/sys/class/thermal/thermal_zone" + z + "/type");
            if (type == null) { if (z > 3) break; else continue; }
            String tl = type.toLowerCase(Locale.ROOT);
            if (!(tl.contains("cpu") || tl.contains("soc") || tl.contains("tsens") || tl.contains("ap"))) continue;
            long v = readLong("/sys/class/thermal/thermal_zone" + z + "/temp");
            if (v <= 0) continue;
            float c = v > 1000 ? v / 1000f : v;
            if (c > 10 && c < 120 && (Float.isNaN(best) || c > best)) best = c;
        }
        return best;
    }

    // ---------------- CPU ----------------
    static int cores() { return Runtime.getRuntime().availableProcessors(); }

    static String chip() {
        if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL != null && !Build.SOC_MODEL.equals(Build.UNKNOWN))
            return Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL;
        return Build.HARDWARE;
    }

    /** Uso aproximado de la CPU según la frecuencia actual de cada núcleo (0..1), o -1. */
    static float cpuLoad() {
        int n = cores();
        float sum = 0;
        int ok = 0;
        for (int i = 0; i < n; i++) {
            long cur = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq");
            long max = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            if (cur > 0 && max > 0) { sum += Math.min(1f, cur / (float) max); ok++; }
        }
        return ok == 0 ? -1 : sum / ok;
    }

    static long maxFreqMhz() {
        long best = 0;
        for (int i = 0; i < cores(); i++) {
            long max = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            if (max > best) best = max;
        }
        return best / 1000;
    }

    // ---------------- RAM y almacenamiento ----------------
    static long[] ram(Context c) {
        ActivityManager am = c.getSystemService(ActivityManager.class);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return new long[]{mi.totalMem, mi.availMem};
    }

    static long[] storage() {
        StatFs s = new StatFs(Environment.getDataDirectory().getPath());
        return new long[]{s.getTotalBytes(), s.getAvailableBytes()};
    }

    // ---------------- Utilidades ----------------
    static String bytes(long b) {
        if (b < 1024) return b + " B";
        double v = b;
        String[] u = {"KB", "MB", "GB", "TB"};
        int i = -1;
        do { v /= 1024; i++; } while (v >= 1024 && i < u.length - 1);
        return String.format(Locale.US, v >= 100 ? "%.0f %s" : "%.1f %s", v, u[i]);
    }

    static String duration(long ms) {
        long m = ms / 60000;
        return m >= 60 ? (m / 60) + " h " + (m % 60) + " min" : m + " min";
    }

    static String readLine(String path) {
        File f = new File(path);
        if (!f.canRead()) return null;
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String s = r.readLine();
            return s == null ? null : s.trim();
        } catch (Exception e) {
            return null;
        }
    }

    static long readLong(String path) {
        String s = readLine(path);
        if (s == null) return -1;
        try { return Long.parseLong(s); } catch (Exception e) { return -1; }
    }
}
