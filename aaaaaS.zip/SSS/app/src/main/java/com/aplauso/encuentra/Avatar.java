package com.aplauso.encuentra;

/** v1.6 · Lo que sabe hacer cualquier Chloe en pantalla (la dibujada o la 3D). */
public interface Avatar {
    void setState(int s);
    void react(int s, long ms);
    void setOnPoke(ChloeAvatarView.OnPoke p);
    void refreshOutfit();
    android.view.View view();
}
