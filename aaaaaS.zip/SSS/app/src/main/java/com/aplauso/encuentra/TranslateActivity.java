package com.aplauso.encuentra;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Locale;

/**
 * v1.5 · TRADUCIR UN DOCUMENTO (español · italiano · inglés) con un botón, sin cambiar su estructura.
 * Se ve la traducción página a página (y el original, para comparar); si una página tiene algún error,
 * ↻ la vuelve a traducir de otra manera. 💾 guarda la copia traducida (el original no se toca).
 */
public class TranslateActivity extends NeonActivity {
    Uri uri;
    String name, srcType;
    DocIO.Doc doc;                 // el que se traduce
    Rich orig;                     // copia del original (para comparar y volver a traducir)
    String from, to;
    boolean busy, showOrig;

    TextView info, fromLbl, pageLbl, warn;
    LinearLayout langRow, viewer;
    ImageView img;
    TextView[] toBtns = new TextView[3];
    File trPdf, origPdf;
    DocPdf.Pages trPages, origPages;
    List<int[]> trMap;
    int page;
    final java.util.Map<Integer, Integer> tries = new java.util.HashMap<>();

    static final String[] NAMES = {"ESPAÑOL", "ITALIANO", "ENGLISH"};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        uri = getIntent().getData();
        if (uri == null) { finish(); return; }
        name = Media.nameOf(this, uri);
        srcType = DocIO.typeOf(name);
        LinearLayout col = screen(L.t("TRADUCIR DOCUMENTO"));

        LinearLayout top = panel(null);
        top.addView(neonText("◢ " + name, 13));
        info = text("Abriendo…", 13);
        top.addView(info);
        fromLbl = text("", 13);
        fromLbl.setTextColor(Color.rgb(170, 180, 200));
        top.addView(fromLbl, sp(6));
        top.addView(text("Traducir a:", 13), sp(8));
        langRow = new LinearLayout(this);
        for (int i = 0; i < 3; i++) {
            final String l = DocTranslate.LANGS[i];
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i < 2) lp.rightMargin = dpi(6);
            toBtns[i] = button(NAMES[i], v -> start(l));
            toBtns[i].setTextSize(12);
            langRow.addView(toBtns[i], lp);
        }
        top.addView(langRow, sp(6));
        top.addView(text("Usa el traductor de Google DENTRO del teléfono: gratis y, tras bajar cada idioma (unos 30 MB, una vez), sin internet. "
                + "El documento no sale del móvil y el original no se cambia.", 11), sp(8));
        col.addView(top, gapBelow(12));

        // visor
        viewer = panel("◢ VISTA PREVIA");
        img = new ImageView(this);
        img.setAdjustViewBounds(true);
        img.setBackgroundColor(Color.WHITE);
        viewer.addView(img, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.addView(circleButton("◀", v -> go(page - 1)), new LinearLayout.LayoutParams(dpi(46), dpi(46)));
        pageLbl = text("", 13);
        pageLbl.setGravity(Gravity.CENTER);
        nav.addView(pageLbl, new LinearLayout.LayoutParams(0, -2, 1));
        nav.addView(circleButton("▶", v -> go(page + 1)), new LinearLayout.LayoutParams(dpi(46), dpi(46)));
        viewer.addView(nav, sp(8));
        warn = text("", 12);
        warn.setTextColor(Color.rgb(255, 190, 90));
        viewer.addView(warn, sp(4));
        LinearLayout r2 = new LinearLayout(this);
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, -2, 3); a.rightMargin = dpi(6);
        TextView redo = button("↻ VOLVER A TRADUCIR ESTA PÁGINA", v -> redoPage());
        redo.setTextSize(12);
        r2.addView(redo, a);
        TextView cmp = button("👁 ORIGINAL", null);
        cmp.setTextSize(12);
        cmp.setOnClickListener(v -> { showOrig = !showOrig; cmp.setText(L.t(showOrig ? "👁 TRADUCCIÓN" : "👁 ORIGINAL")); if (showOrig) page = Math.min(page, origPages == null ? 0 : origPages.count() - 1); show(); });
        r2.addView(cmp, new LinearLayout.LayoutParams(0, -2, 2));
        viewer.addView(r2, sp(8));
        viewer.addView(button("💾 GUARDAR LA COPIA TRADUCIDA", v -> save()), sp(8));
        viewer.setVisibility(View.GONE);
        col.addView(viewer, gapBelow(12));

        busy = true;
        new Thread(() -> {
            try {
                DocIO.Doc d = DocPdf.load(this, uri);
                if (d.rich == null || d.rich.blocks.isEmpty()) d.rich = Rich.fromParas(d.title, d.paras);
                String det = DocTranslate.detect(d);
                runOnUiThread(() -> {
                    doc = d;
                    busy = false;
                    setFrom(det);
                    info.setText(L.t("Elige a qué idioma lo paso.") + ("pdf".equals(srcType) ? "\n" + L.t("De un PDF solo se puede sacar el texto: la copia tendrá un diseño sencillo.") : ""));
                });
            } catch (Throwable t) {
                runOnUiThread(() -> { busy = false; info.setText(L.t("No se pudo abrir: ") + t.getMessage()); });
            }
        }, "traducir-abrir").start();
    }

    LinearLayout.LayoutParams sp(int dp) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dpi(dp); return lp; }

    void setFrom(String l) {
        from = l;
        int i = java.util.Arrays.asList(DocTranslate.LANGS).indexOf(l);
        fromLbl.setText(L.t("Idioma del archivo: ") + NAMES[Math.max(0, i)] + "  ·  " + L.t("toca aquí si no es ese"));
        fromLbl.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(L.t("¿En qué idioma está?"))
                .setItems(NAMES, (dd, w) -> setFrom(DocTranslate.LANGS[w])).show());
        for (int k = 0; k < 3; k++) toBtns[k].setAlpha(DocTranslate.LANGS[k].equals(l) ? 0.35f : 1f);
    }

    // ------------------------------------------------------------------ traducir
    void start(String target) {
        if (busy) { if (doc != null) { DocTranslate.cancel = true; toast(L.t("Cancelando…")); } return; }
        if (doc == null) return;
        if (target.equals(from)) { toast(L.t("El archivo ya está en ese idioma.")); return; }
        busy = true;
        to = target;
        tries.clear();
        if (orig == null) orig = doc.rich.copy();
        else { doc.rich = orig.copy(); }                                 // otra vez desde el original
        final String title0 = doc.title;
        info.setText(L.t("Preparando el traductor…"));
        new Thread(() -> {
            DocTranslate.Session s = new DocTranslate.Session(from, target);
            String err = null;
            try {
                runOnUiThread(() -> info.setText(L.t("Bajando el idioma (solo la primera vez, unos 30 MB)…")));
                s.prepare();
                long t0 = System.currentTimeMillis();
                DocTranslate.run(doc, s, target, (done, total) -> runOnUiThread(() -> {
                    long el = System.currentTimeMillis() - t0;
                    String eta = done > 10 ? " · " + L.t("faltan") + " ~" + Math.max(1, (el * (total - done) / done) / 60000 + 1) + " min" : "";
                    info.setText(L.t("Traduciendo…") + " " + (done * 100 / Math.max(1, total)) + " %" + eta + "\n" + L.t("Toca un idioma para cancelar."));
                }));
                runOnUiThread(() -> info.setText(L.t("Preparando la vista previa…")));
                buildPreview(true);
            } catch (Throwable e) {
                err = e.getMessage() == null ? e.toString() : e.getMessage();
                doc.title = title0;
            } finally { s.close(); }
            String fe = err;
            runOnUiThread(() -> {
                busy = false;
                if (fe != null) { info.setText((DocTranslate.cancel ? L.t("Cancelado.") : L.t("No se pudo traducir: ") + fe)); doc.rich = orig.copy(); return; }
                int f = DocTranslate.failed.size();
                info.setText(L.t("✓ Traducido. Revisa las páginas y guarda la copia.") + (f > 0 ? "\n⚠ " + f + " " + L.t("trozos se quedaron sin traducir: ↻ en su página.") : ""));
                viewer.setVisibility(View.VISIBLE);
                page = 0;
                show();
            });
        }, "traducir").start();
    }

    /** Hace los PDF de la vista previa (la traducción y, una vez, el original). Fuera del hilo principal. */
    void buildPreview(boolean withOrig) throws Exception {
        File dir = getCacheDir();
        File nt = new File(dir, "trad_" + System.nanoTime() + ".pdf");
        List<int[]> map;
        try (FileOutputStream fo = new FileOutputStream(nt)) { map = DocPdf.writeRich(doc.rich, fo); }
        DocPdf.Pages np = new DocPdf.Pages(this, Uri.fromFile(nt));
        DocPdf.Pages op = origPages;
        File of = origPdf;
        if (withOrig && origPages == null) {
            of = new File(dir, "orig_" + System.nanoTime() + ".pdf");
            try (FileOutputStream fo = new FileOutputStream(of)) { DocPdf.writeRich(orig, fo); }
            op = new DocPdf.Pages(this, Uri.fromFile(of));
        }
        DocPdf.Pages oldTr = trPages;
        File oldF = trPdf;
        DocPdf.Pages fop = op;
        File fof = of;
        runOnUiThread(() -> {
            trPages = np; trPdf = nt; trMap = map; origPages = fop; origPdf = fof;
            if (oldTr != null) oldTr.close();
            if (oldF != null) oldF.delete();
        });
    }

    void go(int p) {
        DocPdf.Pages ps = showOrig ? origPages : trPages;
        if (ps == null) return;
        page = Math.max(0, Math.min(ps.count() - 1, p));
        show();
    }

    void show() {
        DocPdf.Pages ps = showOrig ? origPages : trPages;
        if (ps == null) return;
        page = Math.max(0, Math.min(ps.count() - 1, page));
        int w = Math.max(400, Math.min(1400, getResources().getDisplayMetrics().widthPixels));
        Bitmap bm = ps.render(page, w);
        if (bm != null) img.setImageBitmap(bm);
        pageLbl.setText((showOrig ? L.t("Original") + " · " : "") + L.t("Página") + " " + (page + 1) + " / " + ps.count());
        // trozos sin traducir en esta página
        int bad = 0;
        if (!showOrig && trMap != null && page < trMap.size()) {
            int[] r = trMap.get(page);
            synchronized (DocTranslate.failed) { for (int k : DocTranslate.failed) if (k >= r[0] && k <= r[1]) bad++; }
        }
        warn.setText(bad > 0 ? "⚠ " + bad + " " + L.t("trozos sin traducir en esta página. Pulsa ↻.") : "");
    }

    void redoPage() {
        if (busy || trMap == null || showOrig) { if (showOrig) toast(L.t("Pasa a la traducción para volver a traducirla.")); return; }
        if (page >= trMap.size()) return;
        int[] r = trMap.get(page);
        int n = tries.merge(page, 1, Integer::sum);
        int mode = n % 3 == 1 ? 1 : n % 3 == 2 ? 2 : 0;                  // cada vez de otra manera
        String[] how = {L.t("como la primera vez"), L.t("frase a frase"), L.t("el párrafo entero de una vez")};
        busy = true;
        info.setText(L.t("Volviendo a traducir la página") + " " + (page + 1) + " (" + how[mode] + ")…");
        final int first = r[0];
        new Thread(() -> {
            DocTranslate.Session s = new DocTranslate.Session(from, to);
            String err = null;
            int bad = 0;
            try {
                s.prepare();
                bad = DocTranslate.redo(doc.rich, orig, r[0], r[1], s, mode);
                doc.paras.clear();
                doc.paras.addAll(doc.rich.paras());
                buildPreview(false);
            } catch (Throwable e) { err = e.getMessage(); } finally { s.close(); }
            String fe = err;
            int fb = bad;
            runOnUiThread(() -> {
                busy = false;
                if (fe != null) { info.setText(L.t("No se pudo: ") + fe); return; }
                // la página que tiene ahora el primer bloque (el texto traducido puede ocupar otra cantidad)
                for (int i = 0; i < trMap.size(); i++) if (trMap.get(i)[0] <= first && trMap.get(i)[1] >= first) { page = i; break; }
                info.setText(L.t("✓ Página traducida otra vez") + " (" + how[mode] + ")." + (fb > 0 ? " ⚠ " + fb + " " + L.t("trozos siguen sin traducir.") : "")
                        + "\n" + L.t("Si aún no te gusta, pulsa ↻ otra vez: prueba otra manera."));
                show();
            });
        }, "traducir-pagina").start();
    }

    // ------------------------------------------------------------------ guardar
    void save() {
        if (busy || doc == null || to == null) return;
        String[] fmts = {"pdf", "epub", "docx", "txt"};
        String[] names = {"PDF", "EPUB", "DOCX (Word)", "TXT"};
        // el mismo formato que el original, primero
        int same = java.util.Arrays.asList(fmts).indexOf(srcType);
        String[] order = new String[4], labels = new String[4];
        int k = 0;
        if (same >= 0) { order[k] = fmts[same]; labels[k++] = names[same] + " · " + L.t("como el original"); }
        for (int i = 0; i < 4; i++) if (i != same) { order[k] = fmts[i]; labels[k++] = names[i]; }
        String[] fo = java.util.Arrays.copyOf(order, k), fl = java.util.Arrays.copyOf(labels, k);
        new AlertDialog.Builder(this).setTitle(L.t("Guardar la copia traducida como…")).setItems(fl, (d, w) -> doSave(fo[w])).show();
    }

    void doSave(String fmt) {
        busy = true;
        info.setText(L.t("Guardando…"));
        new Thread(() -> {
            Uri out = null;
            String err = null;
            try { out = DocPdf.saveAs(this, doc, fmt, "_" + to.toUpperCase(Locale.ROOT)); } catch (Throwable e) { err = e.getMessage(); }
            Uri fo = out;
            String fe = err;
            runOnUiThread(() -> {
                busy = false;
                if (fo == null) { info.setText(L.t("No se pudo guardar") + (fe != null ? ": " + fe : "")); return; }
                info.setText(L.t("✓ Copia traducida guardada en SSS+/Documentos") + " (" + fmt.toUpperCase(Locale.ROOT) + ")");
                new AlertDialog.Builder(this).setTitle(L.t("¡Guardada!"))
                        .setMessage(L.t("La copia traducida está en SSS+/Documentos. El original no se ha tocado."))
                        .setPositiveButton(L.t("Abrir"), (x, y) -> startActivity(new Intent(this, DocReaderActivity.class).setData(fo)))
                        .setNegativeButton(L.t("Cerrar"), null).show();
            });
        }, "traducir-guardar").start();
    }

    @Override
    protected void onDestroy() {
        DocTranslate.cancel = true;
        if (trPages != null) trPages.close();
        if (origPages != null) origPages.close();
        if (trPdf != null) trPdf.delete();
        if (origPdf != null) origPdf.delete();
        super.onDestroy();
    }
}
