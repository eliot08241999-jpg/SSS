package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Surface;
import android.view.WindowManager;

import java.io.File;
import java.nio.ByteBuffer;

/**
 * v1.6 · GRABADOR DE PANTALLA. Vídeo H.264 (hasta 60 fps) + sonido a elegir: ninguno, INTERNO (lo que suena en el móvil),
 * EXTERNO (micrófono) o HÍBRIDO (los dos, con un volumen para cada uno). Pausa y parar desde la notificación o por voz
 * («Chloe, para de grabar»). Se guarda en tus vídeos (SSS+). Android pide permiso cada vez que empieza: eso no se puede quitar.
 */
public class ScreenRec extends Service {
    String recCh = "screenrec";
    static final String STOP = "stop", PAUSE = "pause";
    static final int SR = 44100;

    static volatile boolean running, paused;
    static volatile long startedAt, pausedTotalMs, pausedAtMs;
    static volatile String status = "";
    static volatile android.net.Uri result;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    /** "none" | "internal" | "mic" | "hybrid" */
    static String audio(Context c) { return prefs(c).getString("rec_audio", "internal"); }

    static void stop(Context c) { if (running) c.startService(new Intent(c, ScreenRec.class).setAction(STOP)); }

    MediaProjection mp;
    VirtualDisplay vd;
    MediaCodec venc, aenc;
    MediaMuxer mux;
    AudioRecord arInt, arMic;
    Surface inSurf;
    File tmp;
    int vTrack = -1, aTrack = -1;
    boolean muxOn, wantAudio;
    final Object muxLock = new Object();
    NotificationManager nm;
    long t0Us;

    @Override public IBinder onBind(Intent i) { return null; }

    Notification notif(String text) {
        Notification.Builder b = new Notification.Builder(this, recCh).setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle(L.t("Grabando la pantalla (SSS+)")).setContentText(text).setOngoing(true).setOnlyAlertOnce(true)
                .setUsesChronometer(!paused).setWhen(System.currentTimeMillis() - (SystemClock.elapsedRealtime() - startedAt - pausedTotalMs));
        PendingIntent ps = PendingIntent.getService(this, 1, new Intent(this, ScreenRec.class).setAction(PAUSE), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent st = PendingIntent.getService(this, 2, new Intent(this, ScreenRec.class).setAction(STOP), PendingIntent.FLAG_IMMUTABLE);
        b.addAction(new Notification.Action.Builder(null, L.t(paused ? "▶ SEGUIR" : "⏸ PAUSA"), ps).build());
        b.addAction(new Notification.Action.Builder(null, L.t("⏹ PARAR"), st).build());
        b.setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, ScreenRecActivity.class), PendingIntent.FLAG_IMMUTABLE));
        return b.build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        nm = getSystemService(NotificationManager.class);
        recCh = Notif.ch(this, "screenrec", L.t("Grabar pantalla"), NotificationManager.IMPORTANCE_LOW);   // v1.6
        String act = intent == null ? null : intent.getAction();
        if (STOP.equals(act)) { finish(); return START_NOT_STICKY; }
        if (PAUSE.equals(act)) {
            if (running) {
                if (paused) { pausedTotalMs += SystemClock.elapsedRealtime() - pausedAtMs; paused = false; }
                else { pausedAtMs = SystemClock.elapsedRealtime(); paused = true; }
                nm.notify(51, notif(L.t(paused ? "En pausa" : "Grabando…")));
            }
            return START_NOT_STICKY;
        }
        if (running || intent == null) return START_NOT_STICKY;
        wantAudio = !"none".equals(audio(this));
        boolean mic = "mic".equals(audio(this)) || "hybrid".equals(audio(this));
        int type = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
        if (mic && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED)
            type |= android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
        startedAt = SystemClock.elapsedRealtime();
        pausedTotalMs = 0;
        paused = false;
        startForeground(51, notif(L.t("Grabando…")), type);
        try {
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            mp = getSystemService(MediaProjectionManager.class).getMediaProjection(code, data);
            if (mp == null) throw new Exception(L.t("Sin permiso para grabar"));
            begin();
            running = true;
            result = null;
            status = L.t("Grabando…");
        } catch (Throwable e) {
            status = L.t("No se pudo grabar: ") + e.getMessage();
            cleanup();
            stopForeground(true);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    void begin() throws Exception {
        SharedPreferences p = prefs(this);
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        int w = dm.widthPixels, h = dm.heightPixels, dpi = dm.densityDpi;
        int maxShort = p.getInt("rec_res", 1080);                      // lado corto: 720 · 1080 · 0 = como la pantalla
        int sh = Math.min(w, h);
        if (maxShort > 0 && sh > maxShort) { float k = maxShort / (float) sh; w = Math.round(w * k); h = Math.round(h * k); }
        w = w / 16 * 16; h = h / 16 * 16;
        int fps = p.getInt("rec_fps", 60);
        MediaFormat vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
        vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        vf.setInteger(MediaFormat.KEY_BIT_RATE, (int) Math.min(40_000_000L, (long) w * h * fps / 8));
        vf.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
        vf.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 1_000_000L / fps);   // pantalla quieta: sigue saliendo vídeo
        venc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        try { venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); }
        catch (Exception e) {                                          // 60 fps o tamaño no soportado: a lo seguro
            vf.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
            venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        }
        inSurf = venc.createInputSurface();
        tmp = new File(getCacheDir(), "rec_" + System.currentTimeMillis() + ".mp4");
        mux = new MediaMuxer(tmp.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        mp.registerCallback(new MediaProjection.Callback() { @Override public void onStop() { if (running) finish(); } }, null);
        t0Us = System.nanoTime() / 1000;
        venc.start();
        vd = mp.createVirtualDisplay("sss-rec", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, inSurf, null, null);
        if (wantAudio) startAudio();
        new Thread(this::videoLoop, "rec-video").start();
    }

    // ------------------------------------------------------------------ sonido
    void startAudio() throws Exception {
        String mode = audio(this);
        boolean in = mode.equals("internal") || mode.equals("hybrid"), mic = mode.equals("mic") || mode.equals("hybrid");
        boolean micOk = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED;
        int min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        AudioFormat fmt = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build();
        if (in && micOk) {                                              // el sonido interno también necesita el permiso de micrófono
            AudioPlaybackCaptureConfiguration cfg = new AudioPlaybackCaptureConfiguration.Builder(mp)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME).addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build();
            arInt = new AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(min * 4).setAudioPlaybackCaptureConfig(cfg).build();
        }
        if (mic && micOk) arMic = new AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT, min * 4);
        if (arInt == null && arMic == null) { wantAudio = false; return; }
        MediaFormat af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 2);
        af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        af.setInteger(MediaFormat.KEY_BIT_RATE, 192_000);
        af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
        aenc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        aenc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        aenc.start();
        if (arInt != null) arInt.startRecording();
        if (arMic != null) arMic.startRecording();
        new Thread(this::audioLoop, "rec-audio").start();
    }

    void audioLoop() {
        SharedPreferences p = prefs(this);
        float vIn = p.getInt("rec_vol_in", 100) / 100f, vMic = p.getInt("rec_vol_mic", 100) / 100f;
        int n = 2048;                                                    // muestras (estéreo: 1024 por canal)
        short[] a = new short[n], b = new short[n], mix = new short[n];
        long frames = 0;
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        try {
            while (running) {
                int ra = arInt != null ? arInt.read(a, 0, n) : 0, rb = arMic != null ? arMic.read(b, 0, n) : 0;
                int len = Math.max(ra, rb);
                if (len <= 0) { if (!running) break; continue; }
                if (paused) continue;
                for (int i = 0; i < len; i++) {
                    float v = (i < ra ? a[i] * vIn : 0) + (i < rb ? b[i] * vMic : 0);
                    mix[i] = (short) Math.max(-32768, Math.min(32767, v));
                }
                int ii = aenc.dequeueInputBuffer(10000);
                if (ii >= 0) {
                    ByteBuffer ib = aenc.getInputBuffer(ii);
                    ib.clear();
                    ib.asShortBuffer().put(mix, 0, len);
                    long pts = frames * 1_000_000L / SR;
                    aenc.queueInputBuffer(ii, 0, len * 2, pts, 0);
                    frames += len / 2;
                }
                drain(aenc, bi, false, false);
                if (!running) break;
            }
            int ii = aenc.dequeueInputBuffer(10000);
            if (ii >= 0) aenc.queueInputBuffer(ii, 0, 0, frames * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            drain(aenc, bi, false, true);
        } catch (Throwable ignored) {}
        audioDone = true;
    }

    volatile boolean audioDone, videoDone;

    // ------------------------------------------------------------------ vídeo
    void videoLoop() {
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        try {
            while (running || !stopRequested) {
                if (stopRequested) break;
                drain(venc, bi, true, false);
            }
            venc.signalEndOfInputStream();
            drain(venc, bi, true, true);
        } catch (Throwable ignored) {}
        videoDone = true;
    }

    volatile boolean stopRequested;
    long lastVPts = -1, pauseShiftUs, pauseStartUs = -1;

    /** Pasa al archivo lo que tenga listo un codificador. */
    void drain(MediaCodec enc, MediaCodec.BufferInfo bi, boolean video, boolean untilEnd) {
        while (true) {
            int r = enc.dequeueOutputBuffer(bi, untilEnd ? 20000 : 10000);
            if (r == MediaCodec.INFO_TRY_AGAIN_LATER) { if (untilEnd && (System.nanoTime() / 1000 - lastDrainUs) < 3_000_000) continue; return; }
            lastDrainUs = System.nanoTime() / 1000;
            if (r == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                synchronized (muxLock) {
                    if (video) vTrack = mux.addTrack(enc.getOutputFormat()); else aTrack = mux.addTrack(enc.getOutputFormat());
                    if (!muxOn && vTrack >= 0 && (!wantAudio || aTrack >= 0)) { mux.start(); muxOn = true; muxLock.notifyAll(); }
                }
                continue;
            }
            if (r < 0) continue;
            ByteBuffer ob = enc.getOutputBuffer(r);
            boolean eos = (bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
            if ((bi.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bi.size = 0;
            if (bi.size > 0 && ob != null) {
                synchronized (muxLock) {
                    long until = System.currentTimeMillis() + 3000;
                    while (!muxOn && System.currentTimeMillis() < until) try { muxLock.wait(100); } catch (InterruptedException ignored) {}
                    if (muxOn) {
                        if (video) {
                            // pausa: lo grabado mientras está en pausa no entra, y el tiempo se recorta
                            long pts = bi.presentationTimeUs - t0Us;
                            if (paused) { if (pauseStartUs < 0) pauseStartUs = pts; enc.releaseOutputBuffer(r, false); if (eos) return; continue; }
                            if (pauseStartUs >= 0) { pauseShiftUs += pts - pauseStartUs; pauseStartUs = -1; }
                            pts -= pauseShiftUs;
                            if (pts <= lastVPts) pts = lastVPts + 1;
                            lastVPts = pts;
                            bi.presentationTimeUs = Math.max(0, pts);
                        }
                        ob.position(bi.offset);
                        ob.limit(bi.offset + bi.size);
                        mux.writeSampleData(video ? vTrack : aTrack, ob, bi);
                    }
                }
            }
            enc.releaseOutputBuffer(r, false);
            if (eos) return;
        }
    }

    long lastDrainUs;

    // ------------------------------------------------------------------ terminar
    void finish() {
        if (!running) { stopForeground(true); stopSelf(); return; }
        running = false;
        stopRequested = true;
        status = L.t("Guardando…");
        new Thread(() -> {
            long until = SystemClock.elapsedRealtime() + 5000;
            while ((!videoDone || (aenc != null && !audioDone)) && SystemClock.elapsedRealtime() < until) SystemClock.sleep(50);
            boolean ok = muxOn;
            cleanup();
            if (ok && tmp != null && tmp.length() > 0) {
                result = Media.save(this, tmp, Media.TYPE_VIDEO, "Pantalla_" + Media.stamp() + ".mp4", "video/mp4");
                status = result != null ? L.t("✓ Guardado en tus vídeos (SSS+).") : L.t("No se pudo guardar el vídeo.");
            } else status = L.t("No se grabó nada.");
            if (tmp != null) tmp.delete();
            stopForeground(true);
            nm.notify(52, new Notification.Builder(this, recCh).setSmallIcon(android.R.drawable.presence_video_online)
                    .setContentTitle(L.t("Grabación de pantalla")).setContentText(status).setAutoCancel(true)
                    .setContentIntent(PendingIntent.getActivity(this, 3, new Intent(this, ScreenRecActivity.class), PendingIntent.FLAG_IMMUTABLE)).build());
            stopSelf();
        }, "rec-fin").start();
    }

    void cleanup() {
        try { if (vd != null) vd.release(); } catch (Throwable ignored) {}
        try { if (arInt != null) { arInt.stop(); arInt.release(); } } catch (Throwable ignored) {}
        try { if (arMic != null) { arMic.stop(); arMic.release(); } } catch (Throwable ignored) {}
        try { if (venc != null) { venc.stop(); venc.release(); } } catch (Throwable ignored) {}
        try { if (aenc != null) { aenc.stop(); aenc.release(); } } catch (Throwable ignored) {}
        try { if (muxOn) mux.stop(); } catch (Throwable ignored) {}
        try { if (mux != null) mux.release(); } catch (Throwable ignored) {}
        try { if (mp != null) mp.stop(); } catch (Throwable ignored) {}
        try { if (inSurf != null) inSurf.release(); } catch (Throwable ignored) {}
        vd = null; arInt = null; arMic = null; venc = null; aenc = null; mux = null; mp = null; inSurf = null;
        running = false;
    }

    @Override public void onDestroy() { if (running) { running = false; stopRequested = true; } super.onDestroy(); }
}
