package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 🌙 NOCHE DEL REBAÑO (v1.1): aguanta 10 minutos contra oleadas cada vez más grandes. Tus armas atacan solas;
 * tú solo te mueves. Recoge cristales de experiencia y, al subir de nivel, elige una mejora entre tres.
 * 3 heroínas, 3 escenarios con jefe final, 8 armas, 6 mejoras pasivas y tienda permanente.
 * Diseño original de SSS+ (por BLORP.eoac).
 */
public class SurviveView extends GameKit.GameView implements ArcadeActivity.Backable {
    static final int S_TITLE = 0, S_PICK = 1, S_PLAY = 2, S_LEVELUP = 3, S_PAUSE = 4, S_DEAD = 5, S_WIN = 6, S_SHOP = 7;
    int st = S_TITLE;
    float t, stT;
    final Random rnd = new Random();

    // ---------------- personajes (originales) ----------------
    static final Pix LANA = new Pix(Pix.pal('w', 0xFFF4F1EA, 'v', 0xFFD8D2C4, 'f', 0xFF3A3040, 'e', 0xFFFFFFFF, 'y', 0xFFFFD34A, 'p', 0xFFE24A8A),
            "..wwww....", ".wwwwww...", "wwffffww..", "wwfefeww..", "wwffffww..", ".wwyyww...", "wwwwwwww..", ".vwwwwv...", ".ff..ff...");
    static final Pix BIGOTES = new Pix(Pix.pal('o', 0xFFFF9A3D, 'q', 0xFFD9772A, 'w', 0xFFFFFFFF, 'k', 0xFF222222, 'p', 0xFFFF7BA6),
            "o.....o...", "oo...oo...", "ooooooo...", "owkowko...", "ooopooo...", ".ooooo..o.", ".qooooq.o.", ".qooooqoo.", ".q.q.q.q..");
    static final Pix NYX = new Pix(Pix.pal('k', 0xFF20304A, 'm', 0xFF3E6FD8, 'y', 0xFFBFE6FF, 'f', 0xFFF6D2B4, 'e', 0xFF1A1A2A, 'h', 0xFFE6ECFF, 'c', 0xFF5AA0FF),
            "....kk....", "...kmmk...", "..kmymmk..", ".kkkkkkkk.", "..hffffh..", "..hfefeh..", "..hffffh..", ".cmmmmmmc.", "..mmmmmm..", "..m....m..");
    static final Pix GHOST = new Pix(Pix.pal('w', 0xFFDDE6FF, 'k', 0xFF2A2A44, 'b', 0xFFAAB8E6),
            "..wwww..", ".wwwwww.", "wwkwwkww", "wwwwwwww", "wwwbbwww", "wwwwwwww", "w.ww.w.w");
    static final Pix BRUTE = new Pix(Pix.pal('r', 0xFFB8443A, 's', 0xFF8A2E28, 'w', 0xFFFFE07A, 'k', 0xFF222222),
            ".rr..rr.", "rrrrrrrr", "rwrrrwrr", "rrrrrrrr", "srkkkkrs", "rrrrrrrr", ".rr..rr.", "ss....ss");
    static final Pix[] HEROES = {LANA, BIGOTES, NYX};
    static final String[] HERO_N = {"Lana", "Bigotes", "Nyx"};
    static final String[] HERO_D = {"Oveja pastora. Empieza con el Cencerro (onda alrededor). +20 % vida.",
            "Gato veloz. Empieza con el Ovillo (bumerán). +15 % velocidad.",
            "Hechicera de estrellas. Empieza con Estrella (dispara sola). +15 % daño."};
    static final int[] HERO_W = {0, 1, 2};
    static final String[] MAPS = {"Pradera de Noche", "Cementerio de Ecos", "Castillo de la Luna"};
    static final int[][] MAP_COL = {{0xFF1E3A26, 0xFF27492F, 0xFF16301D}, {0xFF2A2633, 0xFF35303F, 0xFF211D28}, {0xFF2C2440, 0xFF3A3054, 0xFF221B33}};

    // ---------------- armas y mejoras ----------------
    static final String[] W_N = {"🔔 Cencerro", "🧶 Ovillo", "⭐ Estrella", "🪶 Plumas", "🌙 Lunas", "⚡ Rayo", "🔥 Brasas", "❄ Escarcha"};
    static final String[] W_D = {"Onda que daña todo a tu alrededor", "Bumerán que va y vuelve", "Dispara solo al enemigo más cercano",
            "Abanico de plumas hacia donde miras", "Lunas que giran a tu alrededor", "Rayo que cae sobre enemigos al azar",
            "Deja charcos de fuego al caminar", "Ralentiza y daña a los cercanos"};
    static final String[] P_N = {"💗 Corazón", "👟 Pezuñas veloces", "🧲 Imán", "💪 Fuerza", "⏱ Reloj", "🌿 Hierbabuena"};
    static final String[] P_D = {"+20 % vida máxima", "+10 % velocidad", "Atraes cristales desde más lejos", "+12 % daño", "Las armas atacan un 8 % más a menudo", "Recuperas vida poco a poco"};
    static final int MAXW = 5, MAXLV = 7;
    final int[] wLv = new int[W_N.length];
    final float[] wCd = new float[W_N.length];
    final int[] pLv = new int[P_N.length];
    int weaponsOwned;

    // ---------------- partida ----------------
    int hero, map;
    float px, py, face = 1, hp, maxHp, inv;
    int lvl, xp, xpNext, kills, goldRun;
    float timeLeft;
    static final float RUN = 600;          // 10 minutos
    boolean bossOut, bossDead;
    final String[] choices = new String[3];   // "w3" o "p1"

    static final class En { int type; float x, y, hp, max, spd, atk, size, hit, slow; boolean boss; }
    final List<En> ens = new ArrayList<>();
    static final class Shot { int w; float x, y, vx, vy, life, dmg, r; int pierce; float ox, oy; boolean back; }
    final List<Shot> shots = new ArrayList<>();
    static final class Gem { float x, y; int v; boolean gold; }
    final List<Gem> gems = new ArrayList<>();
    static final class Fx { float x, y, r, life, max; int c; String s; }
    final List<Fx> fx = new ArrayList<>();
    static final class Fire { float x, y, life, dmg; }
    final List<Fire> fires = new ArrayList<>();
    float spawnT, fireDrop;

    // control
    int joyId = -1;
    float jx, jy, jdx, jdy;
    final Paint pp = new Paint();

    SurviveView(Context c) {
        super(c);
        chip.play(Songs.RETRO_SHOOT);
    }

    @Override void computeScale(int w, int h) { vw = 360; scale = w / vw; vh = h / scale; }
    @Override void layout() {}
    @Override boolean navActive() { return st != S_PLAY; }
    @Override public boolean onBack() {
        if (st == S_PLAY) { st = S_PAUSE; return true; }
        if (st == S_PAUSE) { st = S_PLAY; return true; }
        return false;
    }

    int gold() { return prefs().getInt("sv_gold", 0); }
    int shopLv(int i) { return prefs().getInt("sv_shop" + i, 0); }
    int unlockedMaps() { return Math.max(1, prefs().getInt("sv_maps", 1)); }

    // ---------------- estadísticas ----------------
    float dmgMul() { return (1 + pLv[3] * 0.12f + shopLv(1) * 0.05f) * (hero == 2 ? 1.15f : 1); }
    float cdMul() { return 1f / (1 + pLv[4] * 0.08f); }
    float speed() { return 72 * (1 + pLv[1] * 0.1f + shopLv(2) * 0.04f) * (hero == 1 ? 1.15f : 1); }
    float magnet() { return 34 + pLv[2] * 22; }
    float maxHpCalc() { return 100 * (1 + pLv[0] * 0.2f + shopLv(0) * 0.08f) * (hero == 0 ? 1.2f : 1); }

    void startRun(int heroI, int mapI) {
        hero = heroI; map = mapI;
        java.util.Arrays.fill(wLv, 0);
        java.util.Arrays.fill(wCd, 0);
        java.util.Arrays.fill(pLv, 0);
        wLv[HERO_W[hero]] = 1;
        weaponsOwned = 1;
        maxHp = hp = maxHpCalc();
        px = py = 0; inv = 0;
        lvl = 1; xp = 0; xpNext = 6; kills = 0; goldRun = 0;
        timeLeft = RUN;
        bossOut = bossDead = false;
        ens.clear(); shots.clear(); gems.clear(); fx.clear(); fires.clear();
        spawnT = 0;
        st = S_PLAY;
        stT = 0;
        chip.play(map == 0 ? Songs.RETRO_SHOOT : map == 1 ? Songs.CEMENTERIO : Songs.CASTILLO);
    }

    // ---------------- enemigos ----------------
    void spawnEnemy(boolean boss) {
        float el = RUN - timeLeft;              // segundos jugados
        En e = new En();
        float a = rnd.nextFloat() * 6.283f, d = (float) Math.hypot(vw, vh) / 2 + 30;
        e.x = px + (float) Math.cos(a) * d; e.y = py + (float) Math.sin(a) * d;
        float k = 1 + el / 110f + map * 0.45f;
        if (boss) {
            e.type = 5; e.boss = true; e.max = e.hp = 900 * (1 + map * 0.8f); e.spd = 30; e.atk = 25; e.size = 5f;
        } else {
            float r = rnd.nextFloat();
            int type = 0;
            if (el > 60 && r < 0.3f) type = 1;
            if (el > 150 && r < 0.18f) type = 2;
            if (el > 240 && r < 0.12f) type = 3;
            if (el > 330 && r < 0.06f) type = 4;
            float[][] base = {{4, 34, 6, 2.4f}, {3, 52, 5, 2.2f}, {9, 30, 9, 2.5f}, {7, 42, 8, 2.6f}, {40, 24, 15, 3.4f}};
            e.type = type; e.max = e.hp = base[type][0] * k; e.spd = base[type][1] * (1 + el / 1200f); e.atk = base[type][2] * (1 + el / 400f); e.size = base[type][3];
            // minijefes a los 3 y 6 minutos
        }
        ens.add(e);
    }

    Pix sprite(En e) {
        switch (e.type) { case 0: return GuardView.SLIME; case 1: return GuardView.BAT; case 2: return GuardView.SKEL; case 3: return GHOST; case 4: return BRUTE; default: return GuardView.GOLEM; }
    }

    // ---------------- actualizar ----------------
    @Override void update(float dt) {
        t += dt; stT += dt;
        for (int i = fx.size() - 1; i >= 0; i--) { Fx f = fx.get(i); f.life -= dt; if (f.s != null) f.y -= 24 * dt; if (f.life <= 0) fx.remove(i); }
        if (st != S_PLAY) return;
        if (gp.enabled && gp.pressed(GameKit.G_START)) { onBack(); return; }
        timeLeft -= dt;
        float el = RUN - timeLeft;

        // ---- moverse ----
        float mx = 0, my = 0;
        if (joyId >= 0) { float l = (float) Math.hypot(jdx, jdy); if (l > 6) { mx = jdx / Math.max(l, 36); my = jdy / Math.max(l, 36); } }
        if (gp.enabled) {
            if (gp.down(GameKit.G_LEFT)) mx = -1; if (gp.down(GameKit.G_RIGHT)) mx = 1;
            if (gp.down(GameKit.G_UP)) my = -1; if (gp.down(GameKit.G_DOWN)) my = 1;
        }
        float l = (float) Math.hypot(mx, my);
        if (l > 1) { mx /= l; my /= l; }
        px += mx * speed() * dt; py += my * speed() * dt;
        if (mx != 0) face = Math.signum(mx);
        if (inv > 0) inv -= dt;
        if (pLv[5] > 0) hp = Math.min(maxHp, hp + pLv[5] * 0.4f * dt);

        // ---- aparecer enemigos ----
        spawnT -= dt;
        int cap = Math.min(170, 18 + (int) (el / 3.2f));
        float rate = Math.max(0.05f, 0.7f - el / 900f);
        while (spawnT <= 0 && ens.size() < cap) { spawnEnemy(false); spawnT += rate; }
        if (spawnT < 0) spawnT = 0;
        // minijefes (brutos grandes) y jefe final
        if ((int) (el) == 180 && stT > 0 && !mini1) { mini1 = true; for (int i = 0; i < 3; i++) { spawnEnemy(false); En e = ens.get(ens.size() - 1); e.type = 4; e.max = e.hp = 260 * (1 + map * 0.6f); e.size = 4.5f; e.spd = 34; } fx.add(text(px, py - 60, L.t("¡MINIJEFES!"), 0xFFFF4D5E)); }
        if ((int) (el) == 360 && !mini2) { mini2 = true; for (int i = 0; i < 4; i++) { spawnEnemy(false); En e = ens.get(ens.size() - 1); e.type = 4; e.max = e.hp = 520 * (1 + map * 0.6f); e.size = 4.8f; e.spd = 36; } fx.add(text(px, py - 60, L.t("¡MINIJEFES!"), 0xFFFF4D5E)); }
        if (timeLeft <= 0 && !bossOut) { bossOut = true; spawnEnemy(true); fx.add(text(px, py - 60, L.t("¡EL GÓLEM DE LA LUNA!"), 0xFFFF4D5E)); chip.play(Songs.BOSS); }
        if (timeLeft < 0) timeLeft = 0;

        // ---- enemigos ----
        for (int i = ens.size() - 1; i >= 0; i--) {
            En e = ens.get(i);
            if (e.hit > 0) e.hit -= dt;
            if (e.slow > 0) e.slow -= dt;
            float dx = px - e.x, dy = py - e.y, d = (float) Math.hypot(dx, dy);
            float sp = e.spd * (e.slow > 0 ? 0.45f : 1);
            if (d > 1) { e.x += dx / d * sp * dt; e.y += dy / d * sp * dt; }
            // muy lejos: reaparece cerca (no se pierden)
            if (d > 520 && !e.boss) { float a = rnd.nextFloat() * 6.283f; e.x = px + (float) Math.cos(a) * 300; e.y = py + (float) Math.sin(a) * 300; }
            if (d < (e.boss ? 30 : 13) && inv <= 0) {
                hp -= e.atk;
                inv = 0.5f;
                chip.sfx(Chip.SFX_HURT);
                if (hp <= 0) { hp = 0; die(); return; }
            }
        }
        // separar un poco a los enemigos (que no se amontonen en un punto)
        for (int i = 0; i < ens.size(); i += 2) {
            En a = ens.get(i);
            for (int j = i + 1; j < Math.min(ens.size(), i + 6); j++) {
                En b = ens.get(j);
                float dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy;
                if (d2 < 140 && d2 > 0.01f) { float d = (float) Math.sqrt(d2), push = (12 - d) * 0.5f; a.x += dx / d * push; a.y += dy / d * push; b.x -= dx / d * push; b.y -= dy / d * push; }
            }
        }

        weapons(dt);

        // ---- disparos ----
        for (int i = shots.size() - 1; i >= 0; i--) {
            Shot s = shots.get(i);
            s.life -= dt;
            if (s.w == 1) {           // ovillo: va y vuelve
                if (!s.back && s.life < 0.55f) s.back = true;
                if (s.back) { float dx = px - s.x, dy = py - s.y, d = (float) Math.hypot(dx, dy); s.vx = dx / Math.max(1, d) * 260; s.vy = dy / Math.max(1, d) * 260; if (d < 10) s.life = 0; }
            }
            if (s.w == 4) {           // lunas: giran
                float a = t * 3.2f + s.ox;
                s.x = px + (float) Math.cos(a) * s.oy; s.y = py + (float) Math.sin(a) * s.oy;
            } else { s.x += s.vx * dt; s.y += s.vy * dt; }
            if (s.life <= 0) { shots.remove(i); continue; }
            for (int j = ens.size() - 1; j >= 0; j--) {
                En e = ens.get(j);
                float rr = s.r + e.size * 4;
                if (Math.abs(e.x - s.x) < rr && Math.abs(e.y - s.y) < rr && e.hit <= 0) {
                    hurt(j, e, s.dmg);
                    if (s.w != 4 && s.w != 1 && --s.pierce < 0) { s.life = 0; break; }
                }
            }
        }
        // charcos de fuego
        for (int i = fires.size() - 1; i >= 0; i--) {
            Fire f = fires.get(i);
            f.life -= dt;
            if (f.life <= 0) { fires.remove(i); continue; }
            for (int j = ens.size() - 1; j >= 0; j--) { En e = ens.get(j); if (Math.hypot(e.x - f.x, e.y - f.y) < 16 && e.hit <= 0) hurt(j, e, f.dmg); }
        }

        // ---- cristales ----
        for (int i = gems.size() - 1; i >= 0; i--) {
            Gem g = gems.get(i);
            float dx = px - g.x, dy = py - g.y, d = (float) Math.hypot(dx, dy);
            if (d < magnet()) { g.x += dx / Math.max(1, d) * 260 * dt; g.y += dy / Math.max(1, d) * 260 * dt; }
            if (d < 10) {
                gems.remove(i);
                if (g.gold) { goldRun += g.v; chip.sfx(Chip.SFX_COIN); continue; }
                xp += Math.max(1, Math.round(g.v * (1 + shopLv(3) * 0.1f)));
                if (xp >= xpNext) { xp -= xpNext; lvl++; xpNext = (int) (5 + lvl * 3.5f + Math.pow(lvl, 1.25)); levelUp(); return; }
            }
        }
        if (gems.size() > 400) gems.remove(0);
    }

    boolean mini1, mini2;

    void hurt(int j, En e, float dmg) {
        e.hp -= dmg;
        e.hit = 0.12f;
        if (rnd.nextFloat() < 0.35f) fx.add(text(e.x, e.y - 10, String.valueOf(Math.max(1, Math.round(dmg))), Color.WHITE));
        if (e.hp <= 0) {
            ens.remove(j);
            kills++;
            Gem g = new Gem(); g.x = e.x; g.y = e.y; g.v = e.boss ? 0 : e.type == 4 ? 12 : 1 + e.type;
            if (e.boss || rnd.nextFloat() < 0.07f) { g.gold = true; g.v = e.boss ? 200 : 2 + map; }
            gems.add(g);
            if (e.boss) {
                bossDead = true;
                int bonus = 300 + map * 200;
                goldRun += bonus;
                if (unlockedMaps() < MAPS.length && map + 2 > unlockedMaps()) prefs().edit().putInt("sv_maps", map + 2).apply();
                endRun(true);
            }
        }
    }

    void weapons(float dt) {
        for (int w = 0; w < W_N.length; w++) {
            int lv = wLv[w];
            if (lv == 0) continue;
            wCd[w] -= dt;
            if (wCd[w] > 0) continue;
            float dmg = dmgMul();
            switch (w) {
                case 0: {   // cencerro: onda
                    float rad = 46 + lv * 9, d = (5 + lv * 2.5f) * dmg;
                    for (int j = ens.size() - 1; j >= 0; j--) { En e = ens.get(j); if (Math.hypot(e.x - px, e.y - py) < rad) hurt(j, e, d); }
                    fx.add(ring(px, py, 0xFFFFD34A, rad, 0.35f));
                    chip.sfx(Chip.SFX_TALK);
                    wCd[w] = (1.5f - lv * 0.08f) * cdMul();
                    break;
                }
                case 1: {   // ovillo
                    int n = 1 + lv / 3;
                    for (int k = 0; k < n; k++) { Shot s = shot(w, (8 + lv * 3) * dmg, 7); float a = (float) (face > 0 ? 0 : Math.PI) + (k - (n - 1) / 2f) * 0.5f; s.vx = (float) Math.cos(a) * 240; s.vy = (float) Math.sin(a) * 240; s.life = 1.2f; s.pierce = 99; }
                    wCd[w] = (1.6f - lv * 0.1f) * cdMul();
                    break;
                }
                case 2: {   // estrella al más cercano
                    int n = 1 + (lv - 1) / 2;
                    for (int k = 0; k < n; k++) {
                        En tgt = nearest(k);
                        if (tgt == null) break;
                        Shot s = shot(w, (6 + lv * 2.5f) * dmg, 5);
                        float dx = tgt.x - px, dy = tgt.y - py, d = (float) Math.max(1, Math.hypot(dx, dy));
                        s.vx = dx / d * 300; s.vy = dy / d * 300; s.life = 1.6f; s.pierce = lv >= 5 ? 1 : 0;
                    }
                    wCd[w] = (0.9f - lv * 0.06f) * cdMul();
                    break;
                }
                case 3: {   // plumas en abanico
                    int n = 2 + lv;
                    for (int k = 0; k < n; k++) { Shot s = shot(w, (5 + lv * 2) * dmg, 4); float a = (float) (face > 0 ? 0 : Math.PI) + (k - (n - 1) / 2f) * 0.18f; s.vx = (float) Math.cos(a) * 280; s.vy = (float) Math.sin(a) * 280; s.life = 0.9f; s.pierce = 1; }
                    wCd[w] = (1.3f - lv * 0.07f) * cdMul();
                    break;
                }
                case 4: {   // lunas que giran
                    int n = 1 + lv / 2 + (lv >= 7 ? 1 : 0);
                    for (int k = 0; k < n; k++) { Shot s = shot(w, (6 + lv * 2) * dmg, 7); s.ox = k * 6.283f / n; s.oy = 44 + lv * 3; s.life = 3.2f + lv * 0.3f; }
                    wCd[w] = 5.2f * cdMul();
                    break;
                }
                case 5: {   // rayo
                    int n = 1 + lv / 2;
                    for (int k = 0; k < n && !ens.isEmpty(); k++) {
                        int j = rnd.nextInt(ens.size());
                        En e = ens.get(j);
                        if (Math.abs(e.x - px) > vw / 2 || Math.abs(e.y - py) > vh / 2) continue;
                        fx.add(bolt(e.x, e.y));
                        hurt(j, e, (14 + lv * 5) * dmg);
                    }
                    chip.sfx(Chip.SFX_BOOM);
                    wCd[w] = (2.2f - lv * 0.15f) * cdMul();
                    break;
                }
                case 6: {   // brasas al caminar
                    Fire f = new Fire(); f.x = px; f.y = py; f.life = 2 + lv * 0.3f; f.dmg = (3 + lv * 1.5f) * dmg;
                    fires.add(f);
                    wCd[w] = (0.6f - lv * 0.04f) * cdMul();
                    break;
                }
                case 7: {   // escarcha
                    float rad = 60 + lv * 8;
                    for (int j = ens.size() - 1; j >= 0; j--) { En e = ens.get(j); if (Math.hypot(e.x - px, e.y - py) < rad) { e.slow = 1.5f; hurt(j, e, (2 + lv) * dmg); } }
                    fx.add(ring(px, py, 0xFF8FE6FF, rad, 0.5f));
                    wCd[w] = (2.4f - lv * 0.12f) * cdMul();
                    break;
                }
            }
        }
    }

    En nearest(int skip) {
        En best = null; float bd = 1e9f; int found = 0;
        // el k-ésimo más cercano (aprox.: el más cercano que no esté ya muy dañado por otra estrella)
        for (En e : ens) { float d = (float) Math.hypot(e.x - px, e.y - py); if (d < bd && d < 260) { bd = d; best = e; } }
        if (skip > 0 && ens.size() > skip) { En e = ens.get(rnd.nextInt(ens.size())); if (Math.hypot(e.x - px, e.y - py) < 260) return e; }
        return best;
    }

    Shot shot(int w, float dmg, float r) { Shot s = new Shot(); s.w = w; s.x = px; s.y = py; s.dmg = dmg; s.r = r; shots.add(s); return s; }

    void levelUp() {
        chip.sfx(Chip.SFX_LEVEL);
        List<String> pool = new ArrayList<>();
        for (int w = 0; w < W_N.length; w++) {
            if (wLv[w] > 0 && wLv[w] < MAXLV) pool.add("w" + w);
            else if (wLv[w] == 0 && weaponsOwned < MAXW) pool.add("w" + w);
        }
        for (int i = 0; i < P_N.length; i++) if (pLv[i] < 5) pool.add("p" + i);
        java.util.Collections.shuffle(pool, rnd);
        for (int i = 0; i < 3; i++) choices[i] = i < pool.size() ? pool.get(i) : "h";
        st = S_LEVELUP;
        stT = 0;
        joyId = -1;
    }

    void choose(String ch) {
        if (ch.startsWith("w")) { int w = Integer.parseInt(ch.substring(1)); if (wLv[w] == 0) weaponsOwned++; wLv[w]++; }
        else if (ch.startsWith("p")) {
            int i = Integer.parseInt(ch.substring(1)); pLv[i]++;
            if (i == 0) { float old = maxHp; maxHp = maxHpCalc(); hp += maxHp - old; }
        } else { hp = Math.min(maxHp, hp + maxHp * 0.3f); goldRun += 10; }
        st = S_PLAY;
    }

    void die() {
        chip.sfx(Chip.SFX_BOOM);
        endRun(false);
    }

    void endRun(boolean win) {
        prefs().edit().putInt("sv_gold", gold() + goldRun).apply();
        int surv = (int) (RUN - timeLeft);
        if (surv > prefs().getInt("best_survive", 0)) prefs().edit().putInt("best_survive", surv).apply();
        st = win ? S_WIN : S_DEAD;
        stT = 0;
        chip.play(Songs.ENDING);
    }

    Fx ring(float x, float y, int c, float r, float life) { Fx f = new Fx(); f.x = x; f.y = y; f.c = c; f.r = r; f.life = f.max = life; return f; }
    Fx text(float x, float y, String s, int c) { Fx f = new Fx(); f.x = x; f.y = y; f.c = c; f.s = s; f.life = f.max = 0.6f; return f; }
    Fx bolt(float x, float y) { Fx f = new Fx(); f.x = x; f.y = y; f.c = 0xFFBFE6FF; f.r = -1; f.life = f.max = 0.18f; return f; }

    // ---------------- dibujo ----------------
    @Override void render(Canvas c) {
        if (st == S_TITLE) { drawMenuBg(c); drawTitle(c); return; }
        if (st == S_PICK) { drawMenuBg(c); drawPick(c); return; }
        if (st == S_SHOP) { drawMenuBg(c); drawShop(c); return; }
        float cx = px - vw / 2, cy = py - vh / 2;     // cámara
        drawGround(c, cx, cy);
        c.save();
        c.translate(-cx, -cy);
        for (Fire f : fires) { pp.setColor(Color.argb((int) (120 * Math.min(1, f.life)), 255, 120, 40)); c.drawCircle(f.x, f.y, 12, pp); }
        for (Gem g : gems) {
            if (Math.abs(g.x - px) > vw / 2 + 10 || Math.abs(g.y - py) > vh / 2 + 10) continue;
            pp.setColor(g.gold ? 0xFFFFD34A : g.v >= 10 ? 0xFFFF6BD6 : g.v >= 3 ? 0xFF44E07A : 0xFF5AA0FF);
            c.save(); c.rotate(45, g.x, g.y); c.drawRect(g.x - 3, g.y - 3, g.x + 3, g.y + 3, pp); c.restore();
        }
        for (En e : ens) {
            if (Math.abs(e.x - px) > vw / 2 + 30 || Math.abs(e.y - py) > vh / 2 + 30) continue;
            sprite(e).draw(c, pp, e.x, e.y + (float) Math.sin(t * 8 + e.x) * 1.2f, e.size, e.x > px, e.hit > 0.05f ? Color.WHITE : e.slow > 0 ? 0 : 0);
            if (e.slow > 0) { pp.setColor(Color.argb(70, 140, 220, 255)); c.drawCircle(e.x, e.y, e.size * 4, pp); }
            if (e.boss || e.type == 4) {
                float w = e.boss ? 60 : 30;
                pp.setColor(0xAA000000); c.drawRect(e.x - w / 2, e.y - e.size * 5 - 6, e.x + w / 2, e.y - e.size * 5 - 2, pp);
                pp.setColor(0xFFFF4D5E); c.drawRect(e.x - w / 2, e.y - e.size * 5 - 6, e.x - w / 2 + w * Math.max(0, e.hp / e.max), e.y - e.size * 5 - 2, pp);
            }
        }
        for (Shot s : shots) {
            switch (s.w) {
                case 1: pp.setColor(0xFFFF7BA6); c.drawCircle(s.x, s.y, 6, pp); pp.setColor(0xFFFFB8CF); c.drawCircle(s.x - 1, s.y - 1, 2.5f, pp); break;
                case 2: pp.setColor(0xFFFFE680); star(c, s.x, s.y, 6); break;
                case 3: pp.setColor(0xFFE6ECFF); c.drawRect(s.x - 4, s.y - 1.5f, s.x + 4, s.y + 1.5f, pp); break;
                case 4: pp.setColor(0xFFBFE6FF); c.drawCircle(s.x, s.y, 7, pp); pp.setColor(0xFF7FA8D8); c.drawCircle(s.x + 2, s.y - 1, 4, pp); break;
            }
        }
        if (!(inv > 0 && ((int) (inv * 20)) % 2 == 0)) HEROES[hero].draw(c, pp, px, py - Math.abs((float) Math.sin(t * 10)) * (joyId >= 0 ? 2 : 0), 2.6f, face < 0, 0);
        for (Fx f : fx) {
            float k = f.life / f.max;
            if (f.s != null) { txt.setAlpha((int) (255 * Math.min(1, k * 2))); text(c, f.s, f.x, f.y, 11, f.c); txt.setAlpha(255); }
            else if (f.r < 0) { pp.setColor(f.c); pp.setStrokeWidth(3); pp.setStyle(Paint.Style.STROKE); c.drawLine(f.x - 6, f.y - 120, f.x + 4, f.y - 50, pp); c.drawLine(f.x + 4, f.y - 50, f.x - 3, f.y, pp); pp.setStyle(Paint.Style.FILL); }
            else { pp.setStyle(Paint.Style.STROKE); pp.setStrokeWidth(3 * k + 1); pp.setColor(f.c); pp.setAlpha((int) (200 * k)); c.drawCircle(f.x, f.y, f.r * (1.1f - k * 0.4f), pp); pp.setStyle(Paint.Style.FILL); pp.setAlpha(255); }
        }
        c.restore();
        drawHud(c);
        if (st == S_LEVELUP) drawLevelUp(c);
        if (st == S_PAUSE) drawPause(c);
        if (st == S_DEAD || st == S_WIN) drawEnd(c);
    }

    void star(Canvas c, float x, float y, float r) {
        android.graphics.Path s = new android.graphics.Path();
        for (int i = 0; i < 10; i++) { float a = (float) (i * Math.PI / 5 - Math.PI / 2 + t * 6), rr = i % 2 == 0 ? r : r * 0.45f; float xx = x + (float) Math.cos(a) * rr, yy = y + (float) Math.sin(a) * rr; if (i == 0) s.moveTo(xx, yy); else s.lineTo(xx, yy); }
        s.close();
        c.drawPath(s, pp);
    }

    void drawGround(Canvas c, float cx, float cy) {
        int[] col = MAP_COL[map];
        pp.setColor(col[0]);
        c.drawRect(0, 0, vw, vh, pp);
        int T = 32;
        int x0 = (int) Math.floor(cx / T), y0 = (int) Math.floor(cy / T);
        for (int ty = y0; ty <= y0 + (int) (vh / T) + 1; ty++) for (int tx = x0; tx <= x0 + (int) (vw / T) + 1; tx++) {
            int h = Math.abs(tx * 73856093 ^ ty * 19349663) % 17;
            float sx = tx * T - cx, sy = ty * T - cy;
            if (h < 4) { pp.setColor(col[1]); c.drawRect(sx + 6, sy + 8, sx + 12, sy + 11, pp); }
            else if (h == 7) { pp.setColor(col[2]); c.drawRect(sx + 14, sy + 16, sx + 20, sy + 22, pp); }
            else if (h == 11 && map == 1) { pp.setColor(0xFF4A4458); c.drawRect(sx + 10, sy + 6, sx + 20, sy + 20, pp); c.drawRect(sx + 13, sy + 2, sx + 17, sy + 6, pp); }
            else if (h == 11 && map == 2) { pp.setColor(0xFF4A3E66); c.drawRect(sx + 4, sy + 4, sx + 28, sy + 28, pp); }
        }
    }

    void drawHud(Canvas c) {
        pp.setColor(0xFF222230); c.drawRect(0, 0, vw, 8, pp);
        pp.setColor(0xFF5AA0FF); c.drawRect(0, 0, vw * Math.min(1, (float) xp / xpNext), 8, pp);
        pp.setColor(0xAA000000); c.drawRect(0, 8, vw, 44, pp);
        int s = (int) Math.ceil(timeLeft);
        text(c, bossOut ? L.t("¡JEFE!") : String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60), vw / 2, 32, 18, bossOut ? 0xFFFF4D5E : Color.WHITE);
        textLeft(c, L.t("NIV") + " " + lvl, 8, 24, 12, 0xFF5AA0FF);
        textLeft(c, "☠ " + kills + "  🪙 " + goldRun, 8, 39, 11, 0xFFB8C4D0);
        // vida
        pp.setColor(0xFF222230); c.drawRect(vw - 120, 16, vw - 52, 26, pp);
        pp.setColor(0xFF44E07A); c.drawRect(vw - 120, 16, vw - 120 + 68 * Math.max(0, hp / maxHp), 26, pp);
        if (st == S_PLAY && menuButton(c, new RectF(vw - 46, 12, vw - 6, 40), "II", Color.GRAY)) st = S_PAUSE;
        // armas
        float x = 8;
        for (int w = 0; w < W_N.length; w++) if (wLv[w] > 0) { textLeft(c, W_N[w].substring(0, W_N[w].indexOf(' ')) + wLv[w], x, 60, 11, Color.WHITE); x += 34; }
        if (joyId >= 0) {
            pp.setColor(Color.argb(50, 255, 255, 255)); c.drawCircle(jx, jy, 34, pp);
            float l = (float) Math.hypot(jdx, jdy), k = l > 34 ? 34 / l : 1;
            pp.setColor(Color.argb(110, 255, 255, 255)); c.drawCircle(jx + jdx * k, jy + jdy * k, 14, pp);
        }
    }

    void drawLevelUp(Canvas c) {
        pp.setColor(Color.argb(190, 0, 0, 10)); c.drawRect(0, 0, vw, vh, pp);
        text(c, L.t("¡SUBES DE NIVEL!"), vw / 2, vh * 0.2f, 24, 0xFFFFD34A);
        text(c, L.t("Elige una mejora"), vw / 2, vh * 0.2f + 26, 13, Color.WHITE);
        float y = vh * 0.28f;
        for (int i = 0; i < 3; i++) {
            String ch = choices[i];
            RectF r = new RectF(24, y, vw - 24, y + 78);
            String name, desc, lvTxt;
            if (ch.startsWith("w")) { int w = Integer.parseInt(ch.substring(1)); name = W_N[w]; desc = W_D[w]; lvTxt = wLv[w] == 0 ? L.t("¡NUEVA!") : L.t("niv.") + " " + (wLv[w] + 1); }
            else if (ch.startsWith("p")) { int p = Integer.parseInt(ch.substring(1)); name = P_N[p]; desc = P_D[p]; lvTxt = L.t("niv.") + " " + (pLv[p] + 1); }
            else { name = "🍎 " + L.t("Manzana"); desc = L.t("Recupera un 30 % de vida y 10 de oro"); lvTxt = ""; }
            box(c, r, ch.startsWith("w") ? 0xFFFF8A3D : 0xFF44E07A, 230);
            textLeft(c, L.t(name), 38, y + 30, 16, Color.WHITE);
            txt.setTextAlign(Paint.Align.RIGHT); txt.setTextSize(12); txt.setColor(0xFFFFD34A); c.drawText(lvTxt, vw - 36, y + 30, txt); txt.setTextAlign(Paint.Align.CENTER);
            textLeft(c, L.t(desc), 38, y + 56, 12, 0xFFB8C4D0);
            if (stT > 0.3f && tapIn(r)) { choose(ch); return; }
            y += 92;
        }
    }

    void drawPause(Canvas c) {
        pp.setColor(Color.argb(170, 0, 0, 0)); c.drawRect(0, 0, vw, vh, pp);
        text(c, L.t("PAUSA"), vw / 2, vh * 0.3f, 30, Color.WHITE);
        float y = vh * 0.38f;
        if (menuButton(c, new RectF(60, y, vw - 60, y + 48), L.t("▶ SEGUIR"), 0xFF44E07A)) st = S_PLAY;
        if (menuButton(c, new RectF(60, y + 60, vw - 60, y + 108), L.t("🏳 RENDIRSE"), 0xFFFF4D5E)) endRun(false);
    }

    void drawEnd(Canvas c) {
        pp.setColor(Color.argb(190, 0, 0, 0)); c.drawRect(0, 0, vw, vh, pp);
        boolean win = st == S_WIN;
        text(c, win ? L.t("¡HAS SOBREVIVIDO A LA NOCHE!") : L.t("TE HAN ALCANZADO"), vw / 2, vh * 0.3f, win ? 18 : 24, win ? 0xFFFFD34A : 0xFFFF4D5E);
        int surv = (int) (RUN - timeLeft);
        text(c, L.t("Tiempo:") + String.format(java.util.Locale.US, " %d:%02d", surv / 60, surv % 60) + "   ☠ " + kills, vw / 2, vh * 0.37f, 15, Color.WHITE);
        text(c, L.t("Nivel") + " " + lvl + "   🪙 +" + goldRun, vw / 2, vh * 0.42f, 15, 0xFFFFD34A);
        if (win && map + 1 < MAPS.length) text(c, L.t("Nuevo escenario:") + " " + L.t(MAPS[map + 1]), vw / 2, vh * 0.47f, 13, 0xFF44E07A);
        if (stT > 0.8f) {
            if (menuButton(c, new RectF(60, vh * 0.53f, vw - 60, vh * 0.53f + 48), L.t("↻ OTRA PARTIDA"), 0xFF44E07A)) { st = S_PICK; stT = 0; }
            if (menuButton(c, new RectF(60, vh * 0.53f + 60, vw - 60, vh * 0.53f + 108), L.t("☰ MENÚ"), Color.GRAY)) { st = S_TITLE; chip.play(Songs.RETRO_SHOOT); }
        }
    }

    void drawMenuBg(Canvas c) {
        pp.setColor(0xFF0E0B1A); c.drawRect(0, 0, vw, vh, pp);
        for (int i = 0; i < 40; i++) { pp.setColor(Color.argb(80 + (i * 37) % 120, 255, 255, 255)); c.drawCircle((i * 97) % vw, (i * 53 + t * 6) % vh, 1 + i % 2, pp); }
        pp.setColor(0xFFF2F0D8); c.drawCircle(vw - 70, 90, 30, pp);
        pp.setColor(0xFF0E0B1A); c.drawCircle(vw - 58, 82, 26, pp);
    }

    int pickHero;

    void drawTitle(Canvas c) {
        text(c, L.t("NOCHE DEL"), vw / 2, vh * 0.18f, 26, 0xFFBFE6FF);
        text(c, L.t("REBAÑO"), vw / 2, vh * 0.18f + 40, 40, 0xFFFFD34A);
        for (int i = 0; i < 3; i++) HEROES[i].draw(c, pp, vw / 2 + (i - 1) * 70, vh * 0.36f + (float) Math.sin(t * 4 + i) * 3, 4, false, 0);
        for (int i = 0; i < 8; i++) GuardView.SLIME.draw(c, pp, (i * 47 + t * 20) % (vw + 40) - 20, vh * 0.44f + (i % 2) * 14, 2.2f, false, 0);
        float y = vh * 0.52f;
        if (menuButton(c, new RectF(50, y, vw - 50, y + 50), L.t("▶ JUGAR"), 0xFF44E07A)) { st = S_PICK; stT = 0; }
        if (menuButton(c, new RectF(50, y + 62, vw - 50, y + 112), L.t("🛒 TIENDA") + "  🪙 " + gold(), 0xFFFFD34A)) { st = S_SHOP; stT = 0; }
        int b = prefs().getInt("best_survive", 0);
        text(c, L.t("🏆 Récord:") + String.format(java.util.Locale.US, " %d:%02d", b / 60, b % 60), vw / 2, vh - 110, 14, Color.WHITE);
        wrap(c, "Arrastra el dedo para moverte. Tus armas atacan solas. Aguanta 10 minutos y vence al jefe.", vw / 2, vh - 84, vw - 40, 12, 0xFFB8C4D0, true);
    }

    void drawPick(Canvas c) {
        text(c, L.t("ELIGE HEROÍNA"), vw / 2, 50, 20, Color.WHITE);
        float y = 70;
        for (int i = 0; i < 3; i++) {
            RectF r = new RectF(18, y, vw - 18, y + 82);
            box(c, r, i == pickHero ? 0xFFFFD34A : 0xFF555566, 220);
            HEROES[i].draw(c, pp, 52, y + 41, 3.4f, false, 0);
            textLeft(c, HERO_N[i], 88, y + 28, 17, Color.WHITE);
            wrapRaw(c, L.t(HERO_D[i]), 88, y + 48, vw - 120, 11, 0xFFB8C4D0, false);
            if (tapIn(r)) pickHero = i;
            y += 92;
        }
        text(c, L.t("ESCENARIO"), vw / 2, y + 16, 15, Color.WHITE);
        y += 26;
        for (int m = 0; m < MAPS.length; m++) {
            boolean open = m < unlockedMaps();
            RectF r = new RectF(30, y, vw - 30, y + 44);
            if (open) { if (menuButton(c, r, "▶ " + L.t(MAPS[m]), m == 0 ? 0xFF44E07A : m == 1 ? 0xFFB46BFF : 0xFFFF8A3D)) { startRun(pickHero, m); return; } }
            else { box(c, r, Color.DKGRAY, 200); text(c, "🔒 " + L.t("Vence al jefe del anterior"), r.centerX(), r.centerY() + 5, 12, Color.GRAY); }
            y += 52;
        }
        if (menuButton(c, new RectF(100, vh - 60, vw - 100, vh - 20), L.t("← VOLVER"), Color.GRAY)) st = S_TITLE;
    }

    static final String[] SHOP_N = {"💗 Vida", "💪 Daño", "👟 Velocidad", "✨ Experiencia"};
    static final String[] SHOP_D = {"+8 % vida máxima por nivel", "+5 % daño por nivel", "+4 % velocidad por nivel", "+10 % experiencia por nivel"};

    void drawShop(Canvas c) {
        text(c, L.t("🛒 TIENDA"), vw / 2, 50, 24, 0xFFFFD34A);
        text(c, "🪙 " + gold(), vw / 2, 76, 16, 0xFFFFD34A);
        float y = 100;
        for (int i = 0; i < 4; i++) {
            int lv = shopLv(i), cost = (int) (60 * Math.pow(lv + 1, 1.6));
            boolean can = gold() >= cost && lv < 10;
            RectF r = new RectF(18, y, vw - 18, y + 70);
            box(c, r, can ? 0xFFFFD34A : Color.DKGRAY, 220);
            textLeft(c, L.t(SHOP_N[i]) + "  " + L.t("niv.") + " " + lv, 32, y + 28, 15, Color.WHITE);
            textLeft(c, L.t(SHOP_D[i]), 32, y + 52, 11, 0xFFB8C4D0);
            txt.setTextAlign(Paint.Align.RIGHT); txt.setTextSize(14); txt.setColor(can ? 0xFFFFD34A : Color.GRAY);
            c.drawText(lv >= 10 ? "MAX" : "🪙 " + cost, vw - 32, y + 42, txt);
            txt.setTextAlign(Paint.Align.CENTER);
            if (tapIn(r) && can) { prefs().edit().putInt("sv_gold", gold() - cost).putInt("sv_shop" + i, lv + 1).apply(); chip.sfx(Chip.SFX_COIN); }
            y += 80;
        }
        if (menuButton(c, new RectF(100, vh - 60, vw - 100, vh - 20), L.t("← VOLVER"), Color.GRAY)) st = S_TITLE;
    }

    // ---------------- toques ----------------
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        super.onTouchEvent(e);
        if (st != S_PLAY) { joyId = -1; return true; }
        int a = e.getActionMasked(), i = e.getActionIndex();
        float x = e.getX(i) / scale, y = e.getY(i) / scale;
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            if (y < 44 && x > vw - 50) return true;
            if (joyId < 0) { joyId = e.getPointerId(i); jx = x; jy = y; jdx = jdy = 0; }
        } else if (a == MotionEvent.ACTION_MOVE && joyId >= 0) {
            int k = e.findPointerIndex(joyId);
            if (k >= 0) { jdx = e.getX(k) / scale - jx; jdy = e.getY(k) / scale - jy; }
        } else if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP || a == MotionEvent.ACTION_CANCEL) && e.getPointerId(i) == joyId) {
            joyId = -1; jdx = jdy = 0;
        }
        return true;
    }
}
