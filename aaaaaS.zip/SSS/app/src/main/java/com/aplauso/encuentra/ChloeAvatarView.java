package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

/**
 * v1.4 · Chloe animada en el chat: parpadea, respira, te mira cuando tocas la pantalla, escucha, piensa,
 * mueve la boca al hablar (siguiendo las palabras de la voz) y reacciona si la tocas.
 * Se duerme si no le haces caso un rato.
 */
public class ChloeAvatarView extends View implements AvatarArt.C, Avatar {
    public interface OnPoke { void poke(String line); }

    final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG);
    Path path = new Path();
    Canvas cv;
    final AvatarArt.Pose pose = new AvatarArt.Pose();
    final Random rnd = new Random();

    int base = AvatarArt.IDLE;           // lo que pide la pantalla
    int flash = -1; long flashUntil;      // una reacción corta (encima del estado)
    long start = SystemClock.uptimeMillis(), lastTouch = SystemClock.uptimeMillis(), nextBlink;
    float lookTX = Float.NaN, lookTY = Float.NaN;
    final Life life = new Life();
    final Deco deco = new Deco();
    float frameDt = 0.016f;
    long lastFrame;
    OnPoke onPoke;
    boolean running;

    public ChloeAvatarView(Context c) {
        super(c);
        fill.setStyle(Paint.Style.FILL);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        nextBlink = start + 2000;
        setClickable(true);
    }

    public void setOnPoke(OnPoke p) { onPoke = p; }

    /** El estado de fondo: IDLE, LISTEN, THINK, CONFUSED, SAD… (TALK se pone solo mientras habla). */
    public void setState(int s) { base = s; lastTouch = SystemClock.uptimeMillis(); invalidate(); }

    /** Una reacción de unos segundos (HAPPY, LOVE, CONFUSED…). */
    public void react(int s, long ms) { flash = s; flashUntil = SystemClock.uptimeMillis() + ms; lastTouch = SystemClock.uptimeMillis(); invalidate(); }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); running = true; postInvalidateOnAnimation(); }
    @Override protected void onDetachedFromWindow() { running = false; super.onDetachedFromWindow(); }

    @Override
    protected void onDraw(Canvas canvas) {
        long now = SystemClock.uptimeMillis();
        pose.t = (now - start) / 1000f;
        pose.neon = Neon.color(getContext());
        // estado que se ve
        int s = base;
        if (flash >= 0 && now < flashUntil) s = flash; else flash = -1;
        boolean talking = Voice.speaking;
        if (talking && (s == AvatarArt.IDLE || s == AvatarArt.THINK || s == AvatarArt.HAPPY || s == AvatarArt.SLEEP)) s = AvatarArt.TALK;
        if (s == AvatarArt.TALK && !talking) s = AvatarArt.IDLE;
        if (s == AvatarArt.IDLE && now - lastTouch > 90_000) s = AvatarArt.SLEEP;
        pose.state = s;
        // v1.4.2: la vida (muelles + ruido + gestos al azar)
        float dt = lastFrame == 0 ? 0.016f : (now - lastFrame) / 1000f;
        frameDt = Math.min(dt, 0.05f);
        lastFrame = now;
        boolean touching = now - lastTouch < 2500 && !Float.isNaN(lookTX);
        life.step(s, dt, Voice.lastWord, now, touching ? lookTX : Float.NaN, touching ? lookTY : Float.NaN);
        pose.blink = life.blink;
        pose.mouth = life.mouth;
        pose.lookX = life.lookX;
        pose.lookY = life.lookY;
        pose.tilt = life.tilt;

        if (bunny()) { drawBunny(canvas, now); if (running && getVisibility() == VISIBLE) postInvalidateOnAnimation(); return; }
        // dibujar escalado y centrado
        float sc = Math.min(getWidth() / 200f, getHeight() / 220f);
        canvas.save();
        canvas.translate((getWidth() - 200 * sc) / 2f, (getHeight() - 220 * sc) / 2f);
        canvas.scale(sc, sc);
        cv = canvas;
        AvatarArt.draw(this, pose);
        canvas.restore();
        if (running && getVisibility() == VISIBLE) postInvalidateOnAnimation();
    }

    // ---------- v1.4.1: la Chloe conejita (diseño de BLORP.eoac), con traje según la estación ----------
    static BunnyRig.Face face(String o) { return BunnyRig.face(o); }

    String outfit;
    android.graphics.Bitmap bmp;
    BunnyRig.Face fc;
    int lid = 0xFFF6EAEA;
    final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    static final int MW = 40, MH = 40;
    final float[] mesh = new float[(MW + 1) * (MH + 1) * 2];
    long checkedOutfit;

    boolean bunny() { return !"neon".equals(getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("avatar_skin", "bunny")); }

    void loadOutfit(long now) {
        if (bmp != null && now - checkedOutfit < 30_000) return;
        checkedOutfit = now;
        String o = Outfit.now(getContext());
        if (o.equals(outfit) && bmp != null) return;
        try (java.io.InputStream in = getContext().getAssets().open("chloe_" + o + ".webp")) {
            bmp = android.graphics.BitmapFactory.decodeStream(in);
            outfit = o;
            fc = face(o);
            // color del párpado: la piel justo debajo de cada ojo
            // 70 % la piel entre los ojos + 30 % la de debajo (un pelín rosada)
            float[] A = avg(new float[][]{{(fc.lx + fc.rx) / 2, (fc.ly + fc.ry) / 2 + 4}, {(fc.lx + fc.rx) / 2, (fc.ly + fc.ry) / 2 + 7}});
            float[] B = avg(new float[][]{{fc.lx, fc.ly + 15}, {fc.rx, fc.ry + 15}});
            lid = 0xFF000000 | ((int) (A[0] * 0.7f + B[0] * 0.3f) << 16) | ((int) (A[1] * 0.7f + B[1] * 0.3f) << 8) | (int) (A[2] * 0.7f + B[2] * 0.3f);
        } catch (Exception e) { bmp = null; }
    }

    float[] avg(float[][] pts) {
        float r = 0, g = 0, b = 0; int n = 0;
        for (float[] p : pts) for (int dx = -2; dx <= 2; dx += 2) {
            int px = bmp.getPixel((int) p[0] + dx, (int) p[1]);
            r += (px >> 16) & 255; g += (px >> 8) & 255; b += px & 255; n++;
        }
        return new float[]{r / n, g / n, b / n};
    }

    final Paint lidP = new Paint(Paint.ANTI_ALIAS_FLAG);
    { lidP.setMaskFilter(new android.graphics.BlurMaskFilter(1.6f, android.graphics.BlurMaskFilter.Blur.NORMAL)); }

    /** Fuerza a volver a mirar el traje (al cambiarlo en los ajustes). */
    @Override public android.view.View view() { return this; }

    public void refreshOutfit() { checkedOutfit = 0; outfit = null; invalidate(); }

    android.graphics.Bitmap arm;
    String armFor;
    static final float ARM_TIP_X = 12, ARM_TIP_Y = 52;          // punta de los dedos en el sprite del brazo

    void drawBunny(Canvas canvas, long now) {
        loadOutfit(now);
        if (bmp == null) return;
        if (!outfit.equals(armFor)) {
            try (java.io.InputStream in = getContext().getAssets().open("chloe_arm_" + outfit + ".webp")) { arm = android.graphics.BitmapFactory.decodeStream(in); } catch (Exception e) { arm = null; }
            armFor = outfit;
        }
        Life lf = life;
        int s = pose.state;
        // v1.4.6: decoración de la estación (detrás)
        deco.step(outfit, frameDt);
        cv = canvas;
        if (getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("avatar_deco", true)) deco.draw(this, getWidth(), getHeight(), false);
        float W = bmp.getWidth(), H = bmp.getHeight();
        float sc = Math.min(getWidth() / W, getHeight() / H) * 1.06f;
        float ox = (getWidth() - W * sc) / 2f, oy = (getHeight() - H * sc) / 2f + getHeight() * 0.03f;
        canvas.save();
        canvas.translate(ox, oy);
        canvas.scale(sc, sc);
        // halo neón detrás (respira con ella)
        fill.setShader(null);
        fill.setColor(AvatarArt.a(pose.neon, 0.10f + 0.02f * lf.breath)); canvas.drawCircle(W / 2, H * 0.47f, W * 0.46f, fill);
        fill.setColor(AvatarArt.a(pose.neon, 0.07f)); canvas.drawCircle(W / 2, H * 0.47f, W * 0.38f, fill);
        canvas.translate(0, lf.bob);

        // ---- malla: la cabeza gira sobre el cuello, la cara se desplaza (parece 3D), los ojos miran,
        //      las orejas giran sobre su base y el pecho respira ----
        float px = W / 2, py = 300;                                  // cuello
        BunnyRig.mesh(fc, lf, W, H, MW, MH, mesh);
        canvas.drawBitmapMesh(bmp, MW, MH, mesh, 0, null, 0, bp);

        // lo que va pegado a la cara sigue a la cabeza
        canvas.save();
        canvas.rotate(lf.tilt, px, py);
        canvas.translate(lf.turn * 7f, lf.nod + lf.lookY * -2.2f);
        // coloretes
        float bl = 0.15f + pose.blush * 0.5f + (s == AvatarArt.LOVE || s == AvatarArt.HAPPY ? 0.25f : 0) + lf.smile * 0.1f;
        fill.setColor(AvatarArt.a(0xFFFF8FA8, bl * 0.6f));
        canvas.drawOval(fc.lx - 15, fc.ly + 13, fc.lx + 13, fc.ly + 23, fill);
        canvas.drawOval(fc.rx - 13, fc.ry + 13, fc.rx + 15, fc.ry + 23, fill);
        // ojos (párpados encima; el iris ya se movió en la malla)
        canvas.save(); canvas.translate(lf.lookX * 1.2f, lf.lookY * 1.0f);
        bunnyEye(canvas, fc.lx, fc.ly, -1, s);
        bunnyEye(canvas, fc.rx, fc.ry, 1, s);
        canvas.restore();
        // boca
        if (fc.mouth) {
            boolean happyM = s == AvatarArt.HAPPY || s == AvatarArt.LOVE;
            if (pose.mouth > 0.04f) {
                fill.setColor(lid); canvas.drawOval(fc.mx - 7, fc.my - 3, fc.mx + 7, fc.my + 3, fill);
                float o = 1.0f + pose.mouth * 4.8f, w = 4.8f - pose.mouth * 0.8f + (float) Math.sin(lf.t * 13) * 0.4f;
                fill.setColor(0xFF9B3A50); canvas.drawOval(fc.mx - w, fc.my - o * 0.35f, fc.mx + w, fc.my + o, fill);
                fill.setColor(0xFFFF8C9C); canvas.drawOval(fc.mx - w * 0.65f, fc.my + o * 0.35f, fc.mx + w * 0.65f, fc.my + o * 0.9f, fill);
            } else if (happyM || lf.smile > 0.3f) {
                fill.setColor(lid); canvas.drawOval(fc.mx - 7, fc.my - 3, fc.mx + 7, fc.my + 3, fill);
                float sm = happyM ? 1 : lf.smile;
                path.reset(); path.moveTo(fc.mx - 6, fc.my - 1); path.quadTo(fc.mx, fc.my + 1, fc.mx + 6, fc.my - 1);
                path.quadTo(fc.mx, fc.my + 1 + 7 * sm, fc.mx - 6, fc.my - 1);
                fill.setColor(happyM ? 0xFF9B3A50 : AvatarArt.a(0xFF9B3A50, 0.35f + 0.5f * sm)); canvas.drawPath(path, fill);
            } else if (s == AvatarArt.CONFUSED || s == AvatarArt.SAD) {
                fill.setColor(lid); canvas.drawOval(fc.mx - 7, fc.my - 3, fc.mx + 7, fc.my + 3, fill);
                path.reset();
                if (s == AvatarArt.SAD) { path.moveTo(fc.mx - 5, fc.my + 2); path.quadTo(fc.mx, fc.my - 3, fc.mx + 5, fc.my + 2); }
                else { path.moveTo(fc.mx - 6, fc.my); path.quadTo(fc.mx - 3, fc.my - 3, fc.mx, fc.my); path.quadTo(fc.mx + 3, fc.my + 3, fc.mx + 6, fc.my); }
                line.setColor(0xFF8A6A70); line.setStrokeWidth(1.4f); canvas.drawPath(path, line);
            }
        }
        // mano a la barbilla (su propio brazo, girado) al pensar … o jugando con el pelo
        float armK = Math.max(lf.hand, lf.hairHand);
        boolean hairArm = lf.hairHand > lf.hand;
        if (arm != null && armK > 0.01f) {
            float e = 1 - (1 - armK) * (1 - armK) * (1 - armK);
            int layer = canvas.saveLayer(-W, -H, 2 * W, 2 * H, null);          // para desvanecer el brazo como el retrato
            canvas.save();
            if (hairArm) {
                canvas.translate(fc.lx - 50 + (float) Math.sin(lf.twirl) * 3f, fc.ly + 56 + (float) Math.cos(lf.twirl) * 2f + (1 - e) * 170);
                canvas.rotate(70 + (1 - e) * -20 + (float) Math.sin(lf.twirl) * 4f);
            } else {
                canvas.translate(fc.mx - 1, fc.my + 9 + (1 - e) * 170);
                canvas.rotate(100 + (1 - e) * -25);
            }
            bp.setAlpha((int) (255 * Math.min(1, armK * 2.5f)));
            canvas.drawBitmap(arm, -ARM_TIP_X, -ARM_TIP_Y, bp);
            bp.setAlpha(255);
            canvas.restore();
            // máscara: la misma forma ovalada del retrato (deshace el giro de la cabeza para que coincida con el cuerpo)
            canvas.save();
            canvas.translate(-lf.turn * 7f, -(lf.nod + lf.lookY * -2.2f));
            canvas.rotate(-lf.tilt, px, py);
            canvas.drawBitmap(fadeMask(), 0, 0, maskP);
            canvas.restore();
            canvas.restoreToCount(layer);
        }
        canvas.restore();
        canvas.restore();
        // efectos (bocadillo, ondas, corazones, «?», zZz) colocados sobre la cara
        canvas.save();
        float es = sc * (fc.rx - fc.lx) / 40f;
        canvas.translate(ox + (fc.lx + fc.rx) / 2f * sc - 100 * es, oy + fc.ly * sc - 106 * es);
        canvas.scale(es, es);
        cv = canvas;
        AvatarArt.effects(this, pose, pose.neon);
        canvas.restore();
        // decoración (delante: unas pocas, grandes y suaves)
        cv = canvas;
        if (getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("avatar_deco", true)) deco.draw(this, getWidth(), getHeight(), true);
    }

    final android.graphics.Rect lidSrc = new android.graphics.Rect();
    final android.graphics.RectF lidDst = new android.graphics.RectF();
    static android.graphics.Bitmap lidM;

    /** Óvalo con bordes suaves (38×32) para el párpado. */
    static android.graphics.Bitmap lidMask() {
        if (lidM != null) return lidM;
        int w = 38, h = 32;
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            double d = Math.sqrt(Math.pow((x + 0.5 - 19) / 17.0, 2) + Math.pow((y + 0.5 - 16.5) / 13.5, 2));
            double a = Math.max(0, Math.min(1, (1 - d) / 0.3));
            a = a * a * (3 - 2 * a);
            px[y * w + x] = (int) (a * 255) << 24;
        }
        lidM = android.graphics.Bitmap.createBitmap(px, w, h, android.graphics.Bitmap.Config.ARGB_8888);
        return lidM;
    }

    static android.graphics.Bitmap fade;
    final Paint maskP = new Paint();
    { maskP.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN)); }

    /** La misma silueta ovalada con la que se recortaron los retratos (480×480). */
    static android.graphics.Bitmap fadeMask() {
        if (fade != null) return fade;
        int n = 480;
        int[] px = new int[n * n];
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++) {
            double d = Math.sqrt(Math.pow((x - 240) / 165.0, 2) + Math.pow((y - 200) / 250.0, 2));
            double a = Math.max(0, Math.min(1, (1 - d) / 0.18)) * Math.max(0, Math.min(1, (470 - y) / 110.0));
            px[y * n + x] = ((int) (a * 255) << 24);
        }
        fade = android.graphics.Bitmap.createBitmap(px, n, n, android.graphics.Bitmap.Config.ARGB_8888);
        return fade;
    }

    static float smooth(float v) { v = Math.max(0, Math.min(1, v)); return v * v * (3 - 2 * v); }

    /** Párpado pintado encima del ojo: parpadeo, ojos cerrados, ^ ^ contenta, «>» despistada. */
    void bunnyEye(Canvas c, float x, float y, int side, int s) {
        float top = y - 12, bot = y + 15, rx = 17;
        boolean happy = s == AvatarArt.HAPPY || s == AvatarArt.LOVE;
        float b = s == AvatarArt.SLEEP || happy || (s == AvatarArt.CONFUSED && side == 1) ? 1f : pose.blink;
        if (b <= 0.02f) {
            if (s == AvatarArt.LOVE) { fill.setColor(0xFFFF4F8B); cv = c; AvatarArt.heart(this, x, y, 5f); }
            return;
        }
        // v1.4.3: el párpado se pinta con su propia piel (la mejilla de debajo, estirada), con bordes difuminados
        c.save();
        c.clipRect(x - rx - 3, top - 3, x + rx + 3, top - 3 + (bot - top + 6) * b);
        int layer = c.saveLayer(x - 19, y - 15, x + 19, y + 17, null);
        lidSrc.set((int) (x - 19), (int) (y + 11), (int) (x + 19), (int) (y + 11 + fc.lidBand));
        lidDst.set(x - 19, y - 15, x + 19, y + 17);
        c.drawBitmap(bmp, lidSrc, lidDst, bp);
        c.drawBitmap(lidMask(), null, lidDst, maskP);
        c.restoreToCount(layer);
        c.restore();
        line.setColor(0xFF4A3438);
        path.reset();
        if (b >= 0.98f) {
            if (happy) { path.moveTo(x - 9, y + 3); path.quadTo(x, y - 7, x + 9, y + 3); line.setStrokeWidth(2.2f); }
            else if (s == AvatarArt.CONFUSED && side == 1) { path.moveTo(x - 6, y - 5); path.lineTo(x + 5, y); path.lineTo(x - 6, y + 5); line.setStrokeWidth(2.2f); }
            else { path.moveTo(x - 12, y + 1); path.quadTo(x, y + 7, x + 12, y + 1); line.setStrokeWidth(2f); }
        } else {
            float ey = top - 3 + (bot - top + 6) * b;
            path.moveTo(x - 13, ey - 1); path.quadTo(x, ey + 2, x + 13, ey - 1); line.setStrokeWidth(2.2f);
        }
        c.drawPath(path, line);
    }

    // ---------- tocarla ----------
    static final String[] PAT = {"¡Eh, que me despeinas! 😄", "Je, je. ¿Necesitas algo?", "¡Aquí estoy!", "Mmm… eso me gusta. ¿Qué hacemos?",
            "¡Me has pillado pensando en música!", "¿Otra vez tú? ¡Hola! 👋"};
    static final String[] TICKLE = {"¡Jajaja, para, que tengo cosquillas!", "¡Oye! 🙈", "¡Que no soy un botón! Bueno… un poco sí."};
    static final String[] WAKE = {"¡Uy! Me había quedado frita. ¿Qué pasa?", "Mmm… ¿ya es de día? ¡Hola!"};

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float sc = Math.min(getWidth() / 200f, getHeight() / 220f);
        float vx = (e.getX() - (getWidth() - 200 * sc) / 2f) / sc, vy = (e.getY() - (getHeight() - 220 * sc) / 2f) / sc;
        if (bunny() && bmp != null) {                     // conejita: de la foto a las mismas zonas (cabeza, mejillas, ropa)
            float bs = Math.min(getWidth() / (float) bmp.getWidth(), getHeight() / (float) bmp.getHeight()) * 1.06f;
            float fx = (e.getX() - (getWidth() - bmp.getWidth() * bs) / 2f) / (bmp.getWidth() * bs);
            float fy = (e.getY() - (getHeight() - bmp.getHeight() * bs) / 2f - getHeight() * 0.03f) / (bmp.getHeight() * bs);
            vx = (fx - 0.5f) * 360 + 100; vy = (fy - 0.41f) * 260 + 106;
        }
        lookTX = Math.max(-1, Math.min(1, (vx - 100) / 60f));
        lookTY = Math.max(-1, Math.min(1, (vy - 106) / 60f));
        boolean wasAsleep = pose.state == AvatarArt.SLEEP;
        lastTouch = SystemClock.uptimeMillis();
        if (e.getAction() == MotionEvent.ACTION_UP) {
            String say;
            if (wasAsleep) { react(AvatarArt.CONFUSED, 1800); say = pick(WAKE); }
            else if (vy < 80) { react(AvatarArt.LOVE, 2200); say = pick(PAT); }                 // la cabeza
            else if (vy > 150) { react(AvatarArt.HAPPY, 1800); say = pick(TICKLE); }          // la sudadera
            else if (Math.abs(vx - 100) > 30 && vy > 110 && vy < 135) { pose.blush = 1f; react(AvatarArt.HAPPY, 1500); say = L.t("¡Ay! Me pongo roja. 😳"); }
            else { react(AvatarArt.HAPPY, 1200); say = null; }
            if (say != null && onPoke != null) onPoke.poke(L.t(say));
            performClick();
        }
        if (e.getAction() == MotionEvent.ACTION_DOWN) postDelayed(() -> pose.blush *= 0.5f, 2500);
        return true;
    }

    @Override public boolean performClick() { return super.performClick(); }

    String pick(String[] a) { return a[rnd.nextInt(a.length)]; }

    // ---------- AvatarArt.C sobre Canvas de Android ----------
    @Override public void save() { cv.save(); }
    @Override public void restore() { cv.restore(); }
    @Override public void translate(float x, float y) { cv.translate(x, y); }
    @Override public void rotate(float d, float px, float py) { cv.rotate(d, px, py); }
    @Override public void scale(float s, float px, float py) { cv.scale(s, s, px, py); }
    @Override public void color(int c) { fill.setShader(null); fill.setColor(c); line.setColor(c); }
    @Override public void colorFade(int c, float y0, float y1) {
        fill.setColor(0xFFFFFFFF);
        fill.setShader(new android.graphics.LinearGradient(0, y0, 0, y1, c, c & 0x00FFFFFF, android.graphics.Shader.TileMode.CLAMP));
    }
    @Override public void oval(float cx, float cy, float rx, float ry) { cv.drawOval(cx - rx, cy - ry, cx + rx, cy + ry, fill); }
    @Override public void ring(float cx, float cy, float rx, float ry, float w) { line.setStrokeWidth(w); cv.drawOval(cx - rx, cy - ry, cx + rx, cy + ry, line); }
    @Override public void begin() { path.reset(); }
    @Override public void moveTo(float x, float y) { path.moveTo(x, y); }
    @Override public void lineTo(float x, float y) { path.lineTo(x, y); }
    @Override public void quadTo(float a, float b, float x, float y) { path.quadTo(a, b, x, y); }
    @Override public void cubicTo(float a, float b, float c, float d, float x, float y) { path.cubicTo(a, b, c, d, x, y); }
    @Override public void close() { path.close(); }
    @Override public void fill() { cv.drawPath(path, fill); }
    @Override public void stroke(float w) { line.setStrokeWidth(w); cv.drawPath(path, line); }
    @Override public void text(String s, float x, float y, float size) { fill.setTextSize(size); cv.drawText(s, x, y, fill); }
}
