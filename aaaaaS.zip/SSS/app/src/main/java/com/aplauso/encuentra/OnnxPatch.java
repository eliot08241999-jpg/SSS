package com.aplauso.encuentra;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * v1.3.3 · Arreglo de los modelos int8 para ONNX Runtime en Android.
 * Estos modelos guardan los pesos de las convoluciones como int8 con signo, pero ONNX Runtime solo sabe hacer
 * «ConvInteger» con uint8 × uint8 → error ORT_NOT_IMPLEMENTED. La cuenta es la misma si a cada peso y a su
 * «punto cero» se le suma 128 y se marcan como uint8: (w + 128) − (z + 128) = w − z. Se hace UNA vez, en el sitio
 * (sin copiar los 800 MB), con un diario para que un corte a medias no estropee nada.
 */
public class OnnxPatch {
    static final int INT8 = 3, UINT8 = 2;

    static final class Tensor {
        String name = "";
        int dataType = -1;
        final java.util.List<Long> dims = new java.util.ArrayList<>();
        long typePos = -1;                 // posición del byte del tipo en el .onnx
        long rawPos = -1, rawLen = 0;      // datos dentro del .onnx
        boolean int32Data;
        String location;                   // datos fuera, en otro archivo
        long extOffset = 0, extLength = -1;
    }

    static final class Graph {
        final Map<String, Tensor> inits = new HashMap<>();
        final List<String[]> convInputs = new ArrayList<>();   // entradas de cada ConvInteger
        final Map<String, Integer> uses = new HashMap<>();      // cuántos nodos usan cada nombre
    }

    // ---------------- lector mínimo de protobuf ----------------
    static final class Buf {
        final byte[] b; int p;
        Buf(byte[] b, int p) { this.b = b; this.p = p; }
        long varint() {
            long r = 0; int s = 0;
            while (true) { int v = b[p++] & 0xff; r |= (long) (v & 0x7f) << s; if ((v & 0x80) == 0) return r; s += 7; }
        }
        void skip(int wt) {
            if (wt == 0) varint();
            else if (wt == 1) p += 8;
            else if (wt == 2) { int n = (int) varint(); p += n; }
            else if (wt == 5) p += 4;
            else throw new IllegalStateException("protobuf wire type " + wt);
        }
    }

    static Graph parse(byte[] b) {
        Graph g = new Graph();
        Buf m = new Buf(b, 0);
        while (m.p < b.length) {
            long key = m.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 7 && wt == 2) { int n = (int) m.varint(); graph(b, m.p, m.p + n, g); m.p += n; }
            else m.skip(wt);
        }
        return g;
    }

    static void graph(byte[] b, int from, int to, Graph g) {
        Buf r = new Buf(b, from);
        while (r.p < to) {
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (wt == 2 && (f == 1 || f == 5)) {
                int n = (int) r.varint();
                if (f == 1) node(b, r.p, r.p + n, g); else { Tensor t = tensor(b, r.p, r.p + n); g.inits.put(t.name, t); }
                r.p += n;
            } else r.skip(wt);
        }
    }

    static void node(byte[] b, int from, int to, Graph g) {
        Buf r = new Buf(b, from);
        List<String> in = new ArrayList<>();
        String op = "";
        while (r.p < to) {
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (wt == 2 && (f == 1 || f == 4)) {
                int n = (int) r.varint();
                String s = new String(b, r.p, n, java.nio.charset.StandardCharsets.UTF_8);
                r.p += n;
                if (f == 1) in.add(s); else op = s;
            } else r.skip(wt);
        }
        for (String s : in) g.uses.merge(s, 1, Integer::sum);
        if (op.equals("ConvInteger")) g.convInputs.add(in.toArray(new String[0]));
    }

    static Tensor tensor(byte[] b, int from, int to) {
        Tensor t = new Tensor();
        Buf r = new Buf(b, from);
        while (r.p < to) {
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 2 && wt == 0) { t.typePos = r.p; t.dataType = (int) r.varint(); }
            else if (f == 1 && wt == 0) t.dims.add(r.varint());
            else if (f == 1 && wt == 2) { int n = (int) r.varint(), end = r.p + n; while (r.p < end) t.dims.add(r.varint()); }
            else if (f == 8 && wt == 2) { int n = (int) r.varint(); t.name = new String(b, r.p, n, java.nio.charset.StandardCharsets.UTF_8); r.p += n; }
            else if (f == 9 && wt == 2) { int n = (int) r.varint(); t.rawPos = r.p; t.rawLen = n; r.p += n; }
            else if (f == 5) { t.int32Data = true; r.skip(wt); }
            else if (f == 13 && wt == 2) {
                int n = (int) r.varint(), end = r.p + n;
                String k = null, v = null;
                Buf e = new Buf(b, r.p);
                while (e.p < end) {
                    long kk = e.varint(); int ff = (int) (kk >>> 3), ww = (int) (kk & 7);
                    if (ww == 2 && (ff == 1 || ff == 2)) {
                        int m = (int) e.varint();
                        String s = new String(b, e.p, m, java.nio.charset.StandardCharsets.UTF_8);
                        e.p += m;
                        if (ff == 1) k = s; else v = s;
                    } else e.skip(ww);
                }
                if ("location".equals(k)) t.location = v;
                else if ("offset".equals(k)) t.extOffset = Long.parseLong(v);
                else if ("length".equals(k)) t.extLength = Long.parseLong(v);
                r.p = end;
            } else r.skip(wt);
        }
        return t;
    }

    // ---------------- escritura ----------------
    static void putVarint(java.io.ByteArrayOutputStream o, long v) {
        while (true) { if ((v & ~0x7FL) == 0) { o.write((int) v); return; } o.write((int) ((v & 0x7F) | 0x80)); v >>>= 7; }
    }

    /** Copia un campo tal cual (desde su clave hasta el final). */
    static void copy(java.io.ByteArrayOutputStream o, byte[] b, int from, int to) { o.write(b, from, to - from); }

    static byte[] rewriteModel(byte[] b, Set<String> targets) {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(b.length + 4096);
        Buf m = new Buf(b, 0);
        while (m.p < b.length) {
            int start = m.p;
            long key = m.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 7 && wt == 2) {
                int n = (int) m.varint();
                byte[] g = rewriteGraph(b, m.p, m.p + n, targets);
                m.p += n;
                putVarint(o, key); putVarint(o, g.length); o.write(g, 0, g.length);
            } else { m.skip(wt); copy(o, b, start, m.p); }
        }
        return o.toByteArray();
    }

    static int varintLen(long v) { int n = 1; while ((v & ~0x7FL) != 0) { n++; v >>>= 7; } return n; }
    static void putVarint(java.io.OutputStream o, long v) throws java.io.IOException {
        while (true) { if ((v & ~0x7FL) == 0) { o.write((int) v); return; } o.write((int) ((v & 0x7F) | 0x80)); v >>>= 7; }
    }

    /** v1.5: lo mismo que rewriteModel pero escribiendo según va (un modelo de 114 MB no cabe tres veces en memoria). */
    static void writeModel(byte[] b, Set<String> targets, java.io.OutputStream o) throws java.io.IOException {
        Buf m = new Buf(b, 0);
        while (m.p < b.length) {
            int start = m.p;
            long key = m.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 7 && wt == 2) {
                int n = (int) m.varint();
                int from = m.p, to = m.p + n;
                // 1.ª pasada: cuánto medirá el grafo nuevo
                long len = n;
                Buf r = new Buf(b, from);
                while (r.p < to) {
                    long k2 = r.varint(); int f2 = (int) (k2 >>> 3), w2 = (int) (k2 & 7);
                    if (f2 == 5 && w2 == 2) {
                        int tn = (int) r.varint();
                        Tensor t = tensor(b, r.p, r.p + tn);
                        if (targets.contains(t.name) && t.dataType == INT8) {
                            int nl = rewriteTensor(b, r.p, r.p + tn).length;
                            len += (varintLen(nl) + nl) - (varintLen(tn) + tn);
                        }
                        r.p += tn;
                    } else r.skip(w2);
                }
                putVarint(o, key); putVarint(o, len);
                // 2.ª pasada: escribirlo
                r = new Buf(b, from);
                while (r.p < to) {
                    int s2 = r.p;
                    long k2 = r.varint(); int f2 = (int) (k2 >>> 3), w2 = (int) (k2 & 7);
                    if (f2 == 5 && w2 == 2) {
                        int tn = (int) r.varint();
                        Tensor t = tensor(b, r.p, r.p + tn);
                        if (targets.contains(t.name) && t.dataType == INT8) {
                            byte[] nt = rewriteTensor(b, r.p, r.p + tn);
                            putVarint(o, k2); putVarint(o, nt.length); o.write(nt, 0, nt.length);
                        } else o.write(b, s2, r.p + tn - s2);
                        r.p += tn;
                    } else { r.skip(w2); o.write(b, s2, r.p - s2); }
                }
                m.p = to;
            } else { m.skip(wt); o.write(b, start, m.p - start); }
        }
    }

    static byte[] rewriteGraph(byte[] b, int from, int to, Set<String> targets) {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(to - from + 4096);
        Buf r = new Buf(b, from);
        while (r.p < to) {
            int start = r.p;
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 5 && wt == 2) {
                int n = (int) r.varint();
                Tensor t = tensor(b, r.p, r.p + n);
                if (targets.contains(t.name) && t.dataType == INT8) {
                    byte[] nt = rewriteTensor(b, r.p, r.p + n);
                    putVarint(o, key); putVarint(o, nt.length); o.write(nt, 0, nt.length);
                } else copy(o, b, start, r.p + n);
                r.p += n;
            } else { r.skip(wt); copy(o, b, start, r.p); }
        }
        return o.toByteArray();
    }

    /** Tipo → uint8 y +128 a los datos que van dentro (raw_data o int32_data). Los de fuera ya se cambiaron. */
    static byte[] rewriteTensor(byte[] b, int from, int to) {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(to - from + 64);
        Buf r = new Buf(b, from);
        while (r.p < to) {
            int start = r.p;
            long key = r.varint(); int f = (int) (key >>> 3), wt = (int) (key & 7);
            if (f == 2 && wt == 0) { r.varint(); putVarint(o, key); putVarint(o, UINT8); }
            else if (f == 9 && wt == 2) {
                int n = (int) r.varint();
                putVarint(o, key); putVarint(o, n);
                for (int i = 0; i < n; i++) o.write((b[r.p + i] ^ 0x80) & 0xff);
                r.p += n;
            } else if (f == 5 && wt == 2) {          // int32_data empaquetado
                int n = (int) r.varint(), end = r.p + n;
                java.io.ByteArrayOutputStream v = new java.io.ByteArrayOutputStream();
                while (r.p < end) putVarint(v, ((int) r.varint() + 128) & 0xff);
                putVarint(o, key); putVarint(o, v.size()); o.write(v.toByteArray(), 0, v.size());
            } else if (f == 5 && wt == 0) {          // int32_data suelto
                long x = r.varint();
                putVarint(o, key); putVarint(o, ((int) x + 128) & 0xff);
            } else { r.skip(wt); copy(o, b, start, r.p); }
        }
        return o.toByteArray();
    }

    // ---------------- el arreglo ----------------
    /** Deja el modelo listo para ONNX Runtime. Devuelve cuántos tensores ha cambiado (0 si no hacía falta). */
    static int fixConvInteger(File onnx) throws Exception {
        File done = new File(onnx.getParentFile(), ".u8ok");
        if (done.exists()) return 0;
        byte[] b = Files.readAllBytes(onnx.toPath());
        Graph g = parse(b);
        Set<String> targets = new HashSet<>();
        for (String[] in : g.convInputs) {
            if (in.length < 2) continue;
            Tensor w = g.inits.get(in[1]);
            if (w == null || w.dataType != INT8) continue;
            if (in.length < 4 || in[3].isEmpty() || !g.inits.containsKey(in[3]))
                throw new Exception("ConvInteger sin punto cero de pesos: " + in[1]);
            targets.add(in[1]);
            targets.add(in[3]);
        }
        if (targets.isEmpty()) { done.createNewFile(); return 0; }
        // seguridad: si un peso o punto cero lo usa además otro nodo que no es ConvInteger, no se toca nada
        Map<String, Integer> convUses = new HashMap<>();
        for (String[] in : g.convInputs) for (String s : in) convUses.merge(s, 1, Integer::sum);
        for (String t : targets)
            if (!g.uses.getOrDefault(t, 0).equals(convUses.getOrDefault(t, 0)))
                throw new Exception("tensor compartido con otro tipo de nodo: " + t);

        File journal = new File(onnx.getParentFile(), ".u8journal");
        Set<String> already = new HashSet<>();
        if (journal.exists()) for (String s : new String(Files.readAllBytes(journal.toPath()), "UTF-8").split("\n")) if (!s.isEmpty()) already.add(s);
        int changed = 0;
        try (java.io.FileWriter jw = new java.io.FileWriter(journal, true)) {
            Map<String, RandomAccessFile> files = new HashMap<>();
            try {
                for (String name : targets) {
                    Tensor t = g.inits.get(name);
                    if (!already.contains(name)) {
                        if (t.location != null) {
                            RandomAccessFile raf = files.get(t.location);
                            if (raf == null) { raf = new RandomAccessFile(new File(onnx.getParentFile(), t.location), "rw"); files.put(t.location, raf); }
                            long len = t.extLength >= 0 ? t.extLength : raf.length() - t.extOffset;
                            byte[] buf = new byte[1 << 20];
                            for (long pos = 0; pos < len; ) {
                                int n = (int) Math.min(buf.length, len - pos);
                                raf.seek(t.extOffset + pos);
                                raf.readFully(buf, 0, n);
                                for (int i = 0; i < n; i++) buf[i] ^= (byte) 0x80;      // +128 en uint8 = cambiar el bit alto
                                raf.seek(t.extOffset + pos);
                                raf.write(buf, 0, n);
                                pos += n;
                            }
                            raf.getFD().sync();
                        }
                        jw.write(name + "\n");
                        jw.flush();
                    }
                    changed++;
                }
            } finally { for (RandomAccessFile r : files.values()) r.close(); }
        }
        // v1.3.5: el .onnx se vuelve a escribir entero (los «puntos cero» guardados como int32_data cambian de tamaño)
        // el .onnx nuevo se escribe aparte y se cambia de golpe (v1.5: directo al archivo, sin copias en memoria)
        File tmp = new File(onnx.getPath() + ".tmp");
        try (java.io.OutputStream os = new java.io.BufferedOutputStream(new java.io.FileOutputStream(tmp), 1 << 16)) { writeModel(b, targets, os); }
        b = null;
        if (!tmp.renameTo(onnx)) { onnx.delete(); if (!tmp.renameTo(onnx)) throw new Exception("no puedo guardar el modelo arreglado"); }
        done.createNewFile();
        journal.delete();
        return changed;
    }
}
