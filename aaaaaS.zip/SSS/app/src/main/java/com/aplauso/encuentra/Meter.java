package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/** Barra de progreso neón (batería, RAM, almacenamiento...). */
public class Meter extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float value;     // 0..1
    private int color = Neon.DEFAULT_COLOR;
    private boolean warnHigh; // rojo cuando está muy lleno (RAM, almacenamiento)

    public Meter(Context c, boolean warnHigh) {
        super(c);
        this.warnHigh = warnHigh;
    }

    void set(float v, int c) {
        v = Math.max(0, Math.min(1, v));
        if (v != value || c != color) { value = v; color = c; invalidate(); }
    }

    @Override
    protected void onDraw(Canvas cv) {
        float h = getHeight(), w = getWidth(), r = h / 2f;
        p.setColor(Neon.withAlpha(color, 40));
        cv.drawRoundRect(0, 0, w, h, r, r, p);
        int fill = color;
        if (warnHigh && value > 0.9f) fill = Color.rgb(255, 60, 120);
        if (!warnHigh && value < 0.15f) fill = Color.rgb(255, 60, 120);
        p.setColor(fill);
        if (value > 0) cv.drawRoundRect(0, 0, Math.max(h, w * value), h, r, r, p);
    }
}
