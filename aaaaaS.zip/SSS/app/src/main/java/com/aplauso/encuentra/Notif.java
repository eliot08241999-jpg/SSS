package com.aplauso.encuentra;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;

/**
 * v1.6 · NOTIFICACIONES DISCRETAS: las que se quedan fijas mientras SSS+ escucha o trabaja (aplausos, «hola Chloe»,
 * descargas, vídeo, grabación) pasan a ser «mínimas»: sin icono en la barra de arriba, sin sonido, plegadas al final.
 * Android obliga a que exista una mientras escucha en segundo plano: así es lo más invisible posible.
 */
public class Notif {
    static boolean quiet(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("notif_quiet", false); }

    /** Crea (si hace falta) el canal y devuelve su id, discreto o normal según el ajuste. */
    static String ch(Context c, String id, String name, int importance) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        boolean q = quiet(c);
        String real = q ? id + "_min" : id;
        NotificationChannel ch = new NotificationChannel(real, q ? name + " · " + L.t("discreta") : name, q ? NotificationManager.IMPORTANCE_MIN : importance);
        if (q) { ch.setShowBadge(false); ch.setSound(null, null); ch.enableVibration(false); }
        nm.createNotificationChannel(ch);
        return real;
    }
}
