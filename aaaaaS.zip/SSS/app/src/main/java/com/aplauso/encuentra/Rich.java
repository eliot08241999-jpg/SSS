package com.aplauso.encuentra;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v1.5 · Documento CON DISEÑO (para convertir a PDF sin perderlo): bloques de texto con negrita, cursiva, tamaños,
 * colores, alineación (centrado, justificado), sangría, márgenes, listas, imágenes y saltos de página.
 * Se saca de EPUB/HTML (con su hoja de estilos CSS) y de DOCX. Java puro (se prueba fuera del teléfono).
 */
public class Rich {
    public static final int TEXT = 0, IMAGE = 1, PAGE = 2;
    public static final int LEFT = 0, CENTER = 1, RIGHT = 2, JUSTIFY = 3;

    public static final class Run {
        public int s, e;
        public boolean b, i, u, sup, sub;
        public float size = 1;          // × tamaño base
        public int color;               // 0 = el normal (negro)
        public int bg;                  // 0 = sin fondo
    }

    public static final class Block {
        public int kind = TEXT;
        public final StringBuilder text = new StringBuilder();
        public final List<Run> runs = new ArrayList<>();
        public int align = LEFT;
        public float indent, left, right;           // en «em» del tamaño base (sangría de 1.ª línea, márgenes)
        public float before, after;                 // espacio antes / después, en em
        public float lineH = 1.2f;
        public boolean heading, keepNext;
        public String image;                        // ruta dentro del libro
        public float imgW, imgH;                    // tamaño pedido en px (0 = el suyo)
        public boolean emptyLine;                   // párrafo vacío: deja una línea en blanco
    }

    public final List<Block> blocks = new ArrayList<>();
    public final Map<String, byte[]> images = new HashMap<>();
    /** Puntos que vale 1 em. */
    public float basePt = 12f;
    public boolean serif = true;
    /** Idioma del texto («es», «it»…), para partir bien las palabras al final de línea. */
    public String lang;

    // =====================================================================
    // CSS (lo justo)
    // =====================================================================
    static final class Style {
        final Map<String, String> p = new HashMap<>();
    }

    static final class Css {
        final Map<String, Map<String, String>> byTag = new HashMap<>(), byClass = new HashMap<>(), byTagClass = new HashMap<>();

        void parse(String css) {
            css = css.replaceAll("(?s)/\\*.*?\\*/", "").replaceAll("(?s)@media[^{]*\\{((?:[^{}]*\\{[^{}]*\\})*)[^{}]*\\}", "$1")
                    .replaceAll("(?s)@[a-z-]+[^{;]*\\{[^{}]*\\}", "").replaceAll("@[a-z-]+[^;{]*;", "");
            Matcher m = Pattern.compile("([^{}]+)\\{([^{}]*)\\}").matcher(css);
            while (m.find()) {
                Map<String, String> decl = decls(m.group(2));
                for (String sel : m.group(1).split(",")) {
                    sel = sel.trim();
                    if (sel.isEmpty()) continue;
                    String[] parts = sel.split("[\\s>+~]+");
                    String last = parts[parts.length - 1];
                    if (parts.length > 1 && !last.startsWith(".")) continue;   // «div p» y parecidos: demasiado generales
                    if (last.contains(":") || last.contains("[") || last.contains("#")) continue;
                    String tag = last, cls = null;
                    int dot = last.indexOf('.');
                    if (dot >= 0) { tag = last.substring(0, dot); cls = last.substring(dot + 1); if (cls.contains(".")) cls = cls.substring(0, cls.indexOf('.')); }
                    tag = tag.toLowerCase(Locale.ROOT);
                    Map<String, Map<String, String>> into = cls == null ? byTag : tag.isEmpty() || tag.equals("*") ? byClass : byTagClass;
                    String key = cls == null ? tag : tag.isEmpty() || tag.equals("*") ? cls : tag + "." + cls;
                    into.computeIfAbsent(key, k -> new HashMap<>()).putAll(decl);
                }
            }
        }

        Map<String, String> of(String tag, String classes, String inline) {
            Map<String, String> r = new HashMap<>();
            Map<String, String> t = byTag.get(tag);
            if (t != null) r.putAll(t);
            if (classes != null) for (String c : classes.trim().split("\\s+")) {
                Map<String, String> x = byClass.get(c);
                if (x != null) r.putAll(x);
                x = byTagClass.get(tag + "." + c);
                if (x != null) r.putAll(x);
            }
            if (inline != null) r.putAll(decls(inline));
            return r;
        }
    }

    static Map<String, String> decls(String s) {
        Map<String, String> d = new HashMap<>();
        for (String x : s.split(";")) {
            int k = x.indexOf(':');
            if (k <= 0) continue;
            String name = x.substring(0, k).trim().toLowerCase(Locale.ROOT), v = x.substring(k + 1).replace("!important", "").trim().toLowerCase(Locale.ROOT);
            if (name.equals("margin") || name.equals("padding")) {
                String[] q = v.split("\\s+");
                String top = q[0], right = q.length > 1 ? q[1] : top, bottom = q.length > 2 ? q[2] : top, left = q.length > 3 ? q[3] : right;
                d.put(name + "-top", top); d.put(name + "-right", right); d.put(name + "-bottom", bottom); d.put(name + "-left", left);
            } else if (name.equals("font")) {
                if (v.contains("bold")) d.put("font-weight", "bold");
                if (v.contains("italic")) d.put("font-style", "italic");
            } else d.put(name, v);
        }
        return d;
    }

    /** Longitud CSS → em (de la letra «actual» em). % se toma sobre un ancho de unos 40 em. */
    static float len(String v, float em, float pctOf) {
        if (v == null) return 0;
        v = v.trim();
        try {
            if (v.equals("0") || v.equals("auto") || v.equals("none")) return 0;
            if (v.endsWith("em") && !v.endsWith("rem")) return Float.parseFloat(v.substring(0, v.length() - 2)) * em;
            if (v.endsWith("rem")) return Float.parseFloat(v.substring(0, v.length() - 3));
            if (v.endsWith("pt")) return Float.parseFloat(v.substring(0, v.length() - 2)) / 12f;
            if (v.endsWith("px")) return Float.parseFloat(v.substring(0, v.length() - 2)) / 16f;
            if (v.endsWith("%")) return Float.parseFloat(v.substring(0, v.length() - 1)) / 100f * pctOf;
            if (v.endsWith("cm")) return Float.parseFloat(v.substring(0, v.length() - 2)) * 28.35f / 12f;
            if (v.endsWith("mm")) return Float.parseFloat(v.substring(0, v.length() - 2)) * 2.835f / 12f;
            if (v.endsWith("in")) return Float.parseFloat(v.substring(0, v.length() - 2)) * 6f;
            if (v.endsWith("ex")) return Float.parseFloat(v.substring(0, v.length() - 2)) * em * 0.5f;
            return Float.parseFloat(v) / 16f;
        } catch (Exception e) { return 0; }
    }

    static float fontSize(String v, float parent) {
        if (v == null) return parent;
        switch (v) {
            case "xx-small": return 0.6f; case "x-small": return 0.75f; case "small": return 0.89f; case "medium": return 1f;
            case "large": return 1.2f; case "x-large": return 1.5f; case "xx-large": return 2f;
            case "smaller": return parent * 0.83f; case "larger": return parent * 1.2f;
        }
        if (v.endsWith("%")) try { return parent * Float.parseFloat(v.substring(0, v.length() - 1)) / 100f; } catch (Exception e) { return parent; }
        float f = len(v, parent, parent);
        return f > 0 ? f : parent;
    }

    static final Map<String, Integer> NAMED = new HashMap<>();
    static {
        String[] n = {"black", "000000", "white", "ffffff", "red", "ff0000", "green", "008000", "blue", "0000ff", "gray", "808080", "grey", "808080",
                "navy", "000080", "maroon", "800000", "purple", "800080", "teal", "008080", "olive", "808000", "orange", "ffa500", "silver", "c0c0c0",
                "yellow", "ffff00", "aqua", "00ffff", "cyan", "00ffff", "fuchsia", "ff00ff", "lime", "00ff00", "darkred", "8b0000", "darkblue", "00008b",
                "darkgreen", "006400", "brown", "a52a2a", "pink", "ffc0cb", "gold", "ffd700"};
        for (int i = 0; i < n.length; i += 2) NAMED.put(n[i], 0xFF000000 | Integer.parseInt(n[i + 1], 16));
    }

    static int color(String v) {
        if (v == null) return 0;
        v = v.trim();
        try {
            if (v.startsWith("#")) {
                String h = v.substring(1);
                if (h.length() == 3) h = "" + h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
                if (h.length() == 6) return 0xFF000000 | Integer.parseInt(h, 16);
            }
            Matcher m = Pattern.compile("rgba?\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)").matcher(v);
            if (m.find()) return 0xFF000000 | Integer.parseInt(m.group(1)) << 16 | Integer.parseInt(m.group(2)) << 8 | Integer.parseInt(m.group(3));
            Integer c = NAMED.get(v);
            if (c != null) return c;
        } catch (Exception ignored) {}
        return 0;
    }

    // =====================================================================
    // HTML / EPUB
    // =====================================================================
    static final java.util.Set<String> BLOCKS = new java.util.HashSet<>(java.util.Arrays.asList(
            "p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "blockquote", "section", "article", "header", "footer", "aside",
            "ul", "ol", "dl", "dt", "dd", "table", "tr", "pre", "figure", "figcaption", "center", "body", "nav", "address", "hr", "main"));
    static final java.util.Set<String> SKIP = new java.util.HashSet<>(java.util.Arrays.asList("head", "script", "style", "title", "svg", "math", "noscript"));
    static final java.util.Set<String> VOID = new java.util.HashSet<>(java.util.Arrays.asList("br", "img", "hr", "meta", "link", "input", "col", "area", "base", "wbr", "image"));

    /** Estado de un elemento abierto. */
    static final class El {
        String tag;
        boolean block;
        float size = 1;            // em absolutos (respecto al cuerpo)
        boolean b, i, u, sup, sub, hidden;
        int color, bg, align = -1;
        float indent = Float.NaN, left, right, before, after, lineH = Float.NaN;
        boolean pageAfter, keepNext, heading;
        int listN = -1;            // contador si es <ol>
        boolean bullet;            // si es <ul>
        String listMark;           // para <li>
    }

    /** Lee un libro EPUB entero, con su diseño. */
    public static Rich fromEpub(Map<String, byte[]> files) throws Exception {
        byte[] cont = files.get("META-INF/container.xml");
        if (cont == null) throw new Exception("No es un EPUB válido");
        String opfPath = DocIO.find(new String(cont, StandardCharsets.UTF_8), "full-path=\"([^\"]+)\"");
        byte[] opfB = opfPath == null ? null : files.get(opfPath);
        if (opfB == null) throw new Exception("EPUB sin índice");
        String opf = new String(opfB, StandardCharsets.UTF_8);
        String base = dirOf(opfPath);
        Map<String, String> hrefs = new HashMap<>(), types = new HashMap<>();
        Matcher it = Pattern.compile("<item\\s[^>]*>", Pattern.DOTALL).matcher(opf);
        String coverId = DocIO.find(opf, "<meta[^>]*name=\"cover\"[^>]*content=\"([^\"]+)\"");
        if (coverId == null) coverId = DocIO.find(opf, "<meta[^>]*content=\"([^\"]+)\"[^>]*name=\"cover\"");
        String coverHref = null;
        while (it.find()) {
            String tag = it.group();
            String id = DocIO.attr(tag, "id"), href = DocIO.attr(tag, "href"), mt = DocIO.attr(tag, "media-type"), props = DocIO.attr(tag, "properties");
            if (id == null || href == null) continue;
            hrefs.put(id, href);
            if (mt != null) types.put(id, mt);
            if ((id.equals(coverId) || (props != null && props.contains("cover-image"))) && mt != null && mt.startsWith("image/")) coverHref = base + DocIO.decode(href);
        }
        Rich r = new Rich();
        String lg = DocIO.find(opf, "<dc:language[^>]*>([^<]+)</dc:language>");
        if (lg != null) r.lang = lg.trim();
        Css css = new Css();
        Map<String, Boolean> cssDone = new HashMap<>();
        Matcher sp = Pattern.compile("<itemref\\s[^>]*idref=\"([^\"]+)\"[^>]*>", Pattern.DOTALL).matcher(opf);
        boolean first = true, sawImage = false;
        int spineNo = 0;
        while (sp.find()) {
            if ("no".equals(DocIO.attr(sp.group(), "linear"))) continue;
            String href = hrefs.get(sp.group(1));
            if (href == null) continue;
            String path = base + DocIO.decode(href);
            byte[] page = files.get(path);
            if (page == null) continue;
            String html = new String(page, StandardCharsets.UTF_8);
            // sus hojas de estilo
            Matcher lk = Pattern.compile("<link\\s[^>]*>", Pattern.CASE_INSENSITIVE).matcher(html);
            while (lk.find()) {
                String l = lk.group(), h = DocIO.attr(l, "href");
                if (h == null || !l.toLowerCase(Locale.ROOT).contains("stylesheet")) continue;
                String cp = resolve(dirOf(path), h);
                if (cssDone.containsKey(cp)) continue;
                cssDone.put(cp, true);
                byte[] cb = files.get(cp);
                if (cb != null) css.parse(new String(cb, StandardCharsets.UTF_8));
            }
            Matcher st = Pattern.compile("(?is)<style[^>]*>(.*?)</style>").matcher(html);
            while (st.find()) css.parse(st.group(1));
            if (!first) r.pageBreak();
            int before = r.blocks.size();
            r.html(html, css, dirOf(path), files);
            if (spineNo++ < 2) for (int k = before; k < r.blocks.size(); k++) if (r.blocks.get(k).kind == IMAGE) sawImage = true;
            first = false;
        }
        // portada: si el libro no la enseña dentro, se pone delante
        if (coverHref != null && files.containsKey(coverHref) && !r.images.containsKey(coverHref) && !sawImage) {
            Block c = new Block();
            c.kind = IMAGE; c.image = coverHref; c.align = CENTER;
            r.images.put(coverHref, files.get(coverHref));
            r.blocks.add(0, c);
            Block pb = new Block(); pb.kind = PAGE;
            r.blocks.add(1, pb);
        }
        r.normalize();
        return r;
    }

    public static Rich fromHtml(String html) {
        Rich r = new Rich();
        Css css = new Css();
        Matcher st = Pattern.compile("(?is)<style[^>]*>(.*?)</style>").matcher(html);
        while (st.find()) css.parse(st.group(1));
        r.html(html, css, "", new HashMap<>());
        r.normalize();
        return r;
    }

    static String dirOf(String p) { return p.contains("/") ? p.substring(0, p.lastIndexOf('/') + 1) : ""; }

    static String resolve(String dir, String href) {
        href = DocIO.decode(href);
        int h = href.indexOf('#');
        if (h >= 0) href = href.substring(0, h);
        String p = href.startsWith("/") ? href.substring(1) : dir + href;
        List<String> out = new ArrayList<>();
        for (String s : p.split("/")) {
            if (s.isEmpty() || s.equals(".")) continue;
            if (s.equals("..")) { if (!out.isEmpty()) out.remove(out.size() - 1); } else out.add(s);
        }
        return String.join("/", out);
    }

    void pageBreak() {
        if (!blocks.isEmpty() && blocks.get(blocks.size() - 1).kind != PAGE) { Block b = new Block(); b.kind = PAGE; blocks.add(b); }
    }

    // ---- estado mientras se lee el HTML
    Block cur;
    boolean pendingSpace;

    static final Pattern TOKEN = Pattern.compile("<!--.*?-->|<!\\[CDATA\\[.*?\\]\\]>|<![^>]*>|<\\?.*?\\?>|</?([a-zA-Z][a-zA-Z0-9:-]*)((?:[^>\"']|\"[^\"]*\"|'[^']*')*)>|[^<]+", Pattern.DOTALL);

    void html(String html, Css css, String dir, Map<String, byte[]> files) {
        List<El> stack = new ArrayList<>();
        El root = new El();
        root.tag = "#root";
        root.block = true;
        stack.add(root);
        int skip = 0;
        cur = null;
        Matcher m = TOKEN.matcher(html);
        while (m.find()) {
            String tok = m.group();
            if (tok.startsWith("<!") || tok.startsWith("<?")) continue;
            if (tok.charAt(0) != '<') {
                if (skip > 0) continue;
                El top = stack.get(stack.size() - 1);
                if (top.hidden) continue;
                text(DocIO.unesc(tok), stack);
                continue;
            }
            String tag = m.group(1).toLowerCase(Locale.ROOT);
            if (tag.contains(":")) tag = tag.substring(tag.indexOf(':') + 1);
            boolean close = tok.startsWith("</");
            boolean selfClose = tok.endsWith("/>") || VOID.contains(tag);
            if (SKIP.contains(tag)) {
                if (close) skip = Math.max(0, skip - 1); else if (!selfClose) skip++;
                continue;
            }
            if (skip > 0) continue;
            if (close) {
                // cierra hasta el elemento que toca
                for (int k = stack.size() - 1; k > 0; k--) {
                    if (stack.get(k).tag.equals(tag)) {
                        while (stack.size() > k) closeEl(stack.remove(stack.size() - 1), stack);
                        break;
                    }
                }
                continue;
            }
            String attrs = m.group(2) == null ? "" : m.group(2);
            El parent = stack.get(stack.size() - 1);
            // <p> dentro de <p> abierto: el HTML lo cierra solo
            if ((tag.equals("p") || tag.startsWith("h") && tag.length() == 2) && parent.tag.equals("p")) {
                closeEl(stack.remove(stack.size() - 1), stack);
                parent = stack.get(stack.size() - 1);
            }
            if (tag.equals("li") && parent.tag.equals("li")) { closeEl(stack.remove(stack.size() - 1), stack); parent = stack.get(stack.size() - 1); }
            El e = open(tag, attrs, css, parent);
            if (tag.equals("br")) {
                if (!parent.hidden) { ensure(stack); cur.text.append('\n'); pendingSpace = false; }
                continue;
            }
            if (tag.equals("img") || tag.equals("image")) {
                if (parent.hidden || e.hidden) continue;
                String src = attr(attrs, "src");
                if (src == null) src = attr(attrs, "xlink:href");
                if (src == null) src = attr(attrs, "href");
                if (src == null) continue;
                String path = resolve(dir, src);
                byte[] img = files.get(path);
                if (img == null) continue;
                images.put(path, img);
                Block ib = new Block();
                ib.kind = IMAGE;
                ib.image = path;
                El blk = nearestBlock(stack);
                ib.align = blk.align >= 0 ? blk.align : CENTER;
                Map<String, String> s = css.of(tag, attr(attrs, "class"), attr(attrs, "style"));
                ib.imgW = px(s.get("width"), attr(attrs, "width"));
                ib.imgH = px(s.get("height"), attr(attrs, "height"));
                boolean inline = cur != null && cur.text.toString().trim().length() > 0;
                flush();
                if (inline) ib.align = CENTER;
                blocks.add(ib);
                continue;
            }
            if (tag.equals("hr")) { flush(); Block hb = new Block(); hb.text.append("⁂"); hb.align = CENTER; hb.before = 0.5f; hb.after = 0.5f; addRun(hb, 0, 1, e); blocks.add(hb); continue; }
            if (selfClose) continue;
            if (e.block) flush();
            if (e.block && e.listMark != null) {
                ensure(stack, e);
                int s0 = cur.text.length();
                cur.text.append(e.listMark).append('\u00A0');
                addRun(cur, s0, cur.text.length(), e);
            }
            stack.add(e);
            if (e.block && e.before > 0 && cur == null) { /* se aplica al crear el bloque */ }
        }
        while (stack.size() > 1) closeEl(stack.remove(stack.size() - 1), stack);
        flush();
    }

    static float px(String css, String attr) {
        String v = css != null ? css : attr;
        if (v == null) return 0;
        v = v.trim().toLowerCase(Locale.ROOT);
        try {
            if (v.endsWith("px")) return Float.parseFloat(v.substring(0, v.length() - 2));
            if (v.endsWith("%")) return -Float.parseFloat(v.substring(0, v.length() - 1));       // negativo = porcentaje
            if (v.endsWith("em")) return Float.parseFloat(v.substring(0, v.length() - 2)) * 16;
            if (v.endsWith("pt")) return Float.parseFloat(v.substring(0, v.length() - 2)) * 4 / 3f;
            return Float.parseFloat(v);
        } catch (Exception e) { return 0; }
    }

    static String attr(String attrs, String name) {
        Matcher a = Pattern.compile("(?:^|\\s)" + Pattern.quote(name) + "\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", Pattern.CASE_INSENSITIVE).matcher(attrs);
        if (!a.find()) return null;
        return DocIO.unesc(a.group(2) != null ? a.group(2) : a.group(3) != null ? a.group(3) : a.group(4));
    }

    El open(String tag, String attrs, Css css, El parent) {
        El e = new El();
        e.tag = tag;
        e.block = BLOCKS.contains(tag);
        e.size = parent.size;
        e.b = parent.b; e.i = parent.i; e.u = parent.u; e.color = parent.color; e.bg = parent.bg; e.hidden = parent.hidden;
        e.align = parent.align; e.indent = parent.indent; e.lineH = parent.lineH;
        e.sup = parent.sup; e.sub = parent.sub;
        // lo que trae cada etiqueta sin CSS
        switch (tag) {
            case "h1": e.size *= 2f; e.b = true; e.before = 0.67f * 2; e.after = 0.67f * 2; e.heading = true; break;
            case "h2": e.size *= 1.5f; e.b = true; e.before = 0.83f * 1.5f; e.after = 0.83f * 1.5f; e.heading = true; break;
            case "h3": e.size *= 1.17f; e.b = true; e.before = 1.17f; e.after = 1.17f; e.heading = true; break;
            case "h4": e.b = true; e.before = 1.33f; e.after = 1.33f; e.heading = true; break;
            case "h5": e.size *= 0.83f; e.b = true; e.heading = true; break;
            case "h6": e.size *= 0.67f; e.b = true; e.heading = true; break;
            case "p": e.before = 1f; e.after = 1f; break;
            case "b": case "strong": e.b = true; break;
            case "i": case "em": case "cite": case "var": case "dfn": e.i = true; break;
            case "u": case "ins": e.u = true; break;
            case "small": e.size *= 0.83f; break;
            case "big": e.size *= 1.2f; break;
            case "sup": e.sup = true; e.size *= 0.75f; break;
            case "sub": e.sub = true; e.size *= 0.75f; break;
            case "center": e.align = CENTER; break;
            case "blockquote": e.left += 2f; e.right += 2f; e.before = 1; e.after = 1; break;
            case "ul": e.bullet = true; e.left += 1.6f; e.before = 0.6f; e.after = 0.6f; break;
            case "ol": e.listN = 0; e.left += 1.6f; e.before = 0.6f; e.after = 0.6f; break;
            case "dd": e.left += 2.5f; break;
            case "pre": break;
            case "th": e.b = true; break;
        }
        if (tag.equals("li")) {
            if (parent.listN >= 0) { parent.listN++; e.listMark = parent.listN + "."; }
            else e.listMark = "•";
        }
        String cls = attr(attrs, "class"), inline = attr(attrs, "style");
        Map<String, String> s = css.of(tag, cls, inline);
        String v;
        if ((v = s.get("display")) != null) {
            if (v.equals("none")) e.hidden = true;
            else if (v.equals("block") || v.equals("list-item") || v.equals("table") || v.startsWith("table-r") || v.equals("flex")) e.block = true;
            else if (v.startsWith("inline")) e.block = false;
        }
        if ("hidden".equals(s.get("visibility"))) e.hidden = true;
        if ((v = s.get("font-size")) != null) e.size = fontSize(v, parent.size);
        if ((v = s.get("font-weight")) != null) e.b = v.equals("bold") || v.equals("bolder") || (v.matches("\\d+") && Integer.parseInt(v) >= 600);
        if ((v = s.get("font-style")) != null) e.i = v.contains("italic") || v.contains("oblique");
        if ((v = s.get("text-decoration")) != null || (v = s.get("text-decoration-line")) != null) e.u = v.contains("underline");
        if ((v = s.get("color")) != null) e.color = color(v);
        if ((v = s.get("background-color")) != null || (v = s.get("background")) != null) { int c = color(v); if (c != 0 && c != 0xFFFFFFFF) e.bg = c; }
        if ((v = s.get("vertical-align")) != null) { if (v.equals("super")) { e.sup = true; e.size *= 0.8f; } else if (v.equals("sub")) { e.sub = true; e.size *= 0.8f; } }
        if ((v = s.get("text-align")) != null) e.align = v.equals("center") ? CENTER : v.equals("right") || v.equals("end") ? RIGHT : v.startsWith("justify") ? JUSTIFY : LEFT;
        if ((v = s.get("text-indent")) != null) e.indent = len(v, e.size, 40);
        if ((v = s.get("line-height")) != null) {
            float lh;
            if (v.endsWith("%")) lh = len(v, 1, 1);
            else if (v.matches("[0-9.]+")) { try { lh = Float.parseFloat(v); } catch (Exception x) { lh = 1.2f; } }
            else lh = len(v, e.size, 1) / e.size;
            if (lh > 0.8f && lh < 3.5f) e.lineH = lh;
        }
        if (e.block) {
            if (s.containsKey("margin-top")) e.before = len(s.get("margin-top"), e.size, 40);
            if (s.containsKey("margin-bottom")) e.after = len(s.get("margin-bottom"), e.size, 40);
            e.before += len(s.get("padding-top"), e.size, 40);
            e.after += len(s.get("padding-bottom"), e.size, 40);
            float l = len(s.get("margin-left"), e.size, 40) + len(s.get("padding-left"), e.size, 40);
            float rr = len(s.get("margin-right"), e.size, 40) + len(s.get("padding-right"), e.size, 40);
            // listas: el margen lo pone la propia lista; el CSS de calibre ya trae el suyo
            e.left = (tag.equals("ul") || tag.equals("ol")) && (s.containsKey("margin-left") || s.containsKey("padding-left")) ? l : e.left + l;
            e.right += rr;
            if (e.left > 12) e.left = 12;
            if (e.right > 12) e.right = 12;
            String pb = s.get("page-break-before"), pb2 = s.get("break-before");
            if ("always".equals(pb) || "page".equals(pb2) || "left".equals(pb) || "right".equals(pb)) pageBreak();
            String pa = s.get("page-break-after"), pa2 = s.get("break-after");
            if ("always".equals(pa) || "page".equals(pa2)) e.pageAfter = true;
            if ("avoid".equals(pa) || "avoid".equals(pa2) || e.heading) e.keepNext = true;
        }
        return e;
    }

    static El nearestBlock(List<El> stack) {
        for (int k = stack.size() - 1; k >= 0; k--) if (stack.get(k).block) return stack.get(k);
        return stack.get(0);
    }

    float accLeft(List<El> stack) { float l = 0; for (El e : stack) if (e.block) l += e.left; return l; }
    float accRight(List<El> stack) { float r = 0; for (El e : stack) if (e.block) r += e.right; return r; }

    void ensure(List<El> stack) { ensure(stack, null); }

    void ensure(List<El> stack, El extra) {
        if (cur != null) return;
        cur = new Block();
        El blk = extra != null ? extra : nearestBlock(stack);
        cur.align = blk.align < 0 ? LEFT : blk.align;
        cur.indent = Float.isNaN(blk.indent) ? 0 : blk.indent;
        cur.left = accLeft(stack) + (extra != null ? extra.left : 0);
        cur.right = accRight(stack) + (extra != null ? extra.right : 0);
        cur.before = blk.before;
        cur.lineH = Float.isNaN(blk.lineH) ? 1.2f : blk.lineH;
        cur.heading = blk.heading;
        cur.keepNext = blk.keepNext;
        if (blk.listMark != null) cur.indent = 0;
        pendingSpace = false;
    }

    void text(String t, List<El> stack) {
        El top = stack.get(stack.size() - 1);
        boolean pre = false;
        for (El e : stack) if (e.tag.equals("pre")) pre = true;
        StringBuilder out = new StringBuilder();
        for (int k = 0; k < t.length(); k++) {
            char c = t.charAt(k);
            if (!pre && (c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == '\f')) { pendingSpace = true; continue; }
            if (pendingSpace) {
                boolean atStart = (cur == null || cur.text.length() == 0 || cur.text.charAt(cur.text.length() - 1) == '\n') && out.length() == 0;
                if (!atStart) out.append(' ');
                pendingSpace = false;
            }
            out.append(c);
        }
        if (out.length() == 0) return;
        ensure(stack);
        int s0 = cur.text.length();
        cur.text.append(out);
        addRun(cur, s0, cur.text.length(), top);
    }

    static void addRun(Block b, int s, int e, El st) {
        if (s >= e) return;
        Run last = b.runs.isEmpty() ? null : b.runs.get(b.runs.size() - 1);
        if (last != null && last.e == s && last.b == st.b && last.i == st.i && last.u == st.u && last.size == st.size && last.color == st.color
                && last.bg == st.bg && last.sup == st.sup && last.sub == st.sub) { last.e = e; return; }
        Run r = new Run();
        r.s = s; r.e = e; r.b = st.b; r.i = st.i; r.u = st.u; r.size = st.size; r.color = st.color; r.bg = st.bg; r.sup = st.sup; r.sub = st.sub;
        b.runs.add(r);
    }

    void closeEl(El e, List<El> stack) {
        if (e.block) {
            if (cur != null) cur.after = Math.max(cur.after, e.after);
            else if (!blocks.isEmpty()) { Block l = blocks.get(blocks.size() - 1); if (l.kind == TEXT) l.after = Math.max(l.after, e.after); }
            flush();
        }
        if (e.pageAfter) pageBreak();
    }

    void flush() {
        if (cur == null) return;
        Block b = cur;
        cur = null;
        pendingSpace = false;
        // quita los espacios del final
        int n = b.text.length();
        while (n > 0 && b.text.charAt(n - 1) == ' ') n--;
        b.text.setLength(n);
        for (int k = b.runs.size() - 1; k >= 0; k--) { Run r = b.runs.get(k); if (r.s >= n) b.runs.remove(k); else if (r.e > n) r.e = n; }
        String vis = b.text.toString().replace('\u00A0', ' ').replace('\u200B', ' ').trim();
        if (vis.isEmpty()) {
            if (b.text.length() == 0 || b.runs.isEmpty()) return;
            // un párrafo con solo un espacio duro: una línea en blanco, como en el libro
            b.emptyLine = true;
            b.text.setLength(0);
            b.text.append('\u00A0');
            Run r = b.runs.get(0);
            r.s = 0; r.e = 1;
            b.runs.clear();
            b.runs.add(r);
        }
        else for (int k = 0; k < b.text.length(); k++) if (b.text.charAt(k) == '\u00A0') b.text.setCharAt(k, ' ');   // si no, no se parte la línea ahí
        blocks.add(b);
    }

    /**
     * Ajusta los tamaños: el tamaño de letra más usado en el libro pasa a ser el normal (los libros convertidos a menudo
     * ponen todo el texto a «1.5em»; así no sale gigante ni diminuto). Los márgenes también se pasan a esa medida.
     */
    void normalize() {
        Map<Float, Integer> count = new HashMap<>();
        for (Block b : blocks) for (Run r : b.runs) count.merge(Math.round(r.size * 100) / 100f, r.e - r.s, Integer::sum);
        float body = 1;
        int best = -1;
        for (Map.Entry<Float, Integer> e : count.entrySet()) if (e.getValue() > best) { best = e.getValue(); body = e.getKey(); }
        if (body <= 0.2f) body = 1;
        for (Block b : blocks) {
            for (Run r : b.runs) r.size /= body;
            b.indent /= body; b.left /= body; b.right /= body; b.before /= body; b.after /= body;
            // los márgenes de antes/después que pone el navegador a los <p> (1em) son mucho en un PDF: se dejan a la mitad
            b.before = Math.min(b.before, 2.5f);
            b.after = Math.min(b.after, 2.5f);
        }
        // entre párrafos se juntan los márgenes (como en CSS: gana el mayor)
        for (int k = 1; k < blocks.size(); k++) {
            Block a = blocks.get(k - 1), b = blocks.get(k);
            if (a.kind == TEXT && b.kind == TEXT) { float m = Math.max(a.after, b.before); a.after = m; b.before = 0; }
        }
        // sin saltos de página seguidos ni al principio/final
        for (int k = blocks.size() - 1; k >= 0; k--) {
            Block b = blocks.get(k);
            if (b.kind != PAGE) continue;
            if (k == 0 || k == blocks.size() - 1 || blocks.get(k - 1).kind == PAGE) blocks.remove(k);
        }
    }

    // =====================================================================
    // DOCX
    // =====================================================================
    /** Lee un DOCX con su formato: estilos de párrafo (títulos), negrita, cursiva, tamaños, colores, alineación, sangrías, imágenes y saltos de página. */
    public static Rich fromDocx(Map<String, byte[]> files) throws Exception {
        byte[] xml = files.get("word/document.xml");
        if (xml == null) throw new Exception("No es un DOCX válido");
        Rich r = new Rich();
        r.serif = false;
        r.basePt = 1;                                     // en DOCX los tamaños van en puntos de verdad
        String doc = new String(xml, StandardCharsets.UTF_8);
        // estilos
        Map<String, String> pStyles = new HashMap<>(), rStyles = new HashMap<>(), basedOn = new HashMap<>(), names = new HashMap<>();
        float defSize = 11;
        byte[] sb = files.get("word/styles.xml");
        if (sb != null) {
            String st = new String(sb, StandardCharsets.UTF_8);
            String dd = DocIO.find(st, "<w:rPrDefault>(.*?)</w:rPrDefault>");
            if (dd != null) { String sz = DocIO.find(dd, "<w:sz w:val=\"(\\d+)\""); if (sz != null) defSize = Integer.parseInt(sz) / 2f; }
            Matcher sm = Pattern.compile("<w:style\\s([^>]*)>(.*?)</w:style>", Pattern.DOTALL).matcher(st);
            while (sm.find()) {
                String id = DocIO.attr(" " + sm.group(1), "w:styleId");
                if (id == null) continue;
                String body = sm.group(2);
                pStyles.put(id, nz(DocIO.find(body, "(<w:pPr>.*?</w:pPr>)")));
                rStyles.put(id, nz(DocIO.find(body, "(<w:rPr>.*?</w:rPr>)")));
                String bo = DocIO.find(body, "<w:basedOn w:val=\"([^\"]+)\"");
                if (bo != null) basedOn.put(id, bo);
                String nm = DocIO.find(body, "<w:name w:val=\"([^\"]+)\"");
                if (nm != null) names.put(id, nm.toLowerCase(Locale.ROOT));
            }
        }
        // imágenes
        Map<String, String> rels = new HashMap<>();
        byte[] rb = files.get("word/_rels/document.xml.rels");
        if (rb != null) {
            Matcher rm = Pattern.compile("<Relationship\\s[^>]*>").matcher(new String(rb, StandardCharsets.UTF_8));
            while (rm.find()) {
                String id = DocIO.attr(" " + rm.group(), "Id"), tg = DocIO.attr(" " + rm.group(), "Target");
                if (id != null && tg != null) rels.put(id, tg.startsWith("/") ? tg.substring(1) : resolve("word/", tg));
            }
        }
        Matcher pm = Pattern.compile("<w:p[ >].*?</w:p>|<w:p/>", Pattern.DOTALL).matcher(doc);
        while (pm.find()) {
            String p = pm.group();
            String pPr = nz(DocIO.find(p, "(<w:pPr>.*?</w:pPr>)"));
            String styleId = DocIO.find(pPr, "<w:pStyle w:val=\"([^\"]+)\"");
            // propiedades heredadas del estilo (y de los estilos en los que se basa)
            List<String> chainP = new ArrayList<>(), chainR = new ArrayList<>();
            String sid = styleId == null ? "Normal" : styleId;
            for (int guard = 0; sid != null && guard < 8; guard++) { chainP.add(0, nz(pStyles.get(sid))); chainR.add(0, nz(rStyles.get(sid))); sid = basedOn.get(sid); }
            String allP = String.join("", chainP) + pPr;
            String pRunDef = String.join("", chainR);
            String nm = styleId == null ? "" : nz(names.get(styleId));
            Block b = new Block();
            b.heading = nm.startsWith("heading") || nm.equals("title") || nm.equals("subtitle");
            b.keepNext = b.heading || allP.contains("<w:keepNext/>");
            String jc = last(allP, "<w:jc w:val=\"([a-z]+)\"");
            if (jc != null) b.align = jc.equals("center") ? CENTER : jc.equals("right") || jc.equals("end") ? RIGHT : jc.equals("both") || jc.equals("distribute") ? JUSTIFY : LEFT;
            String ind = lastTag(allP, "w:ind");
            if (ind != null) {
                b.left = twip(DocIO.attr(" " + ind, "w:left"), DocIO.attr(" " + ind, "w:start"));
                b.right = twip(DocIO.attr(" " + ind, "w:right"), DocIO.attr(" " + ind, "w:end"));
                String fl = DocIO.attr(" " + ind, "w:firstLine"), hg = DocIO.attr(" " + ind, "w:hanging");
                b.indent = fl != null ? twip(fl, null) : hg != null ? -twip(hg, null) : 0;
            }
            String spc = lastTag(allP, "w:spacing");
            if (spc != null) {
                b.before = twip(DocIO.attr(" " + spc, "w:before"), null);
                b.after = twip(DocIO.attr(" " + spc, "w:after"), null);
                String line = DocIO.attr(" " + spc, "w:line"), rule = DocIO.attr(" " + spc, "w:lineRule");
                if (line != null && (rule == null || rule.equals("auto"))) try { b.lineH = Math.max(0.9f, Math.min(3f, Integer.parseInt(line) / 240f * 1.15f)); } catch (Exception ignored) {}
            } else b.after = 8;
            if (allP.contains("<w:numPr>")) { b.left = Math.max(b.left, 18); String m0 = "•\u00A0"; b.text.append(m0); }
            if (allP.contains("<w:pageBreakBefore/>")) r.pageBreak();
            // trozos de texto
            Matcher rm = Pattern.compile("<w:r[ >].*?</w:r>|<w:hyperlink[^>]*>|</w:hyperlink>", Pattern.DOTALL).matcher(p);
            boolean any = false;
            while (rm.find()) {
                String run = rm.group();
                if (!run.startsWith("<w:r")) continue;
                String rPr = nz(DocIO.find(run, "(<w:rPr>.*?</w:rPr>)"));
                String rs = DocIO.find(rPr, "<w:rStyle w:val=\"([^\"]+)\"");
                String all = pRunDef + (rs != null ? nz(rStyles.get(rs)) : "") + rPr;
                El st = new El();
                st.b = on(all, "w:b");
                st.i = on(all, "w:i");
                String uu = last(all, "<w:u w:val=\"([a-zA-Z]+)\"");
                st.u = uu != null && !uu.equals("none");
                String sz = last(all, "<w:sz w:val=\"(\\d+)\"");
                st.size = sz != null ? Integer.parseInt(sz) / 2f : defSize;
                String col = last(all, "<w:color w:val=\"([0-9A-Fa-f]{6})\"");
                st.color = col != null && !col.equals("000000") ? 0xFF000000 | Integer.parseInt(col, 16) : 0;
                String hl = last(all, "<w:highlight w:val=\"([a-zA-Z]+)\"");
                if (hl != null && !hl.equals("none")) st.bg = color(hl.toLowerCase(Locale.ROOT).replace("dark", "dark"));
                String va = last(all, "<w:vertAlign w:val=\"([a-z]+)\"");
                if ("superscript".equals(va)) { st.sup = true; st.size *= 0.7f; }
                if ("subscript".equals(va)) { st.sub = true; st.size *= 0.7f; }
                if (on(all, "w:caps")) st.hidden = false;
                Matcher tm = Pattern.compile("<w:t(?: [^>]*)?>(.*?)</w:t>|<w:t/>|<w:tab/>|<w:br(?: [^>]*)?/>|<w:cr/>|<w:drawing>.*?</w:drawing>|<w:pict>.*?</w:pict>", Pattern.DOTALL).matcher(run);
                while (tm.find()) {
                    String g = tm.group();
                    if (g.startsWith("<w:drawing") || g.startsWith("<w:pict")) {
                        String rid = DocIO.find(g, "r:embed=\"([^\"]+)\"");
                        if (rid == null) rid = DocIO.find(g, "r:id=\"([^\"]+)\"");
                        String path = rid == null ? null : rels.get(rid);
                        if (path != null && files.containsKey(path)) {
                            if (b.text.length() > 0) { r.blocks.add(b); Block nb = new Block(); nb.align = b.align; nb.after = b.after; b = nb; }
                            Block ib = new Block();
                            ib.kind = IMAGE; ib.image = path; ib.align = b.align == LEFT ? CENTER : b.align;
                            String cx = DocIO.find(g, "<wp:extent cx=\"(\\d+)\""), cy = DocIO.find(g, "<wp:extent cx=\"\\d+\" cy=\"(\\d+)\"");
                            if (cx != null && cy != null) { ib.imgW = Long.parseLong(cx) / 9525f; ib.imgH = Long.parseLong(cy) / 9525f; }
                            r.images.put(path, files.get(path));
                            r.blocks.add(ib);
                            any = true;
                        }
                        continue;
                    }
                    int s0 = b.text.length();
                    if (g.startsWith("<w:tab")) b.text.append("    ");
                    else if (g.startsWith("<w:br")) {
                        if (g.contains("w:type=\"page\"")) {
                            if (b.text.length() > 0) { r.blocks.add(b); Block nb = new Block(); nb.align = b.align; nb.after = b.after; nb.left = b.left; b = nb; }
                            r.pageBreak();
                            continue;
                        }
                        b.text.append('\n');
                    } else if (g.startsWith("<w:cr")) b.text.append('\n');
                    else if (tm.group(1) != null) b.text.append(DocIO.unesc(tm.group(1)));
                    if (on(all, "w:caps")) { String up = b.text.substring(s0).toUpperCase(Locale.ROOT); b.text.replace(s0, b.text.length(), up); }
                    addRun(b, s0, b.text.length(), st);
                    any = true;
                }
            }
            if (b.text.length() == 0 || b.text.toString().trim().isEmpty()) {
                if (!any || b.text.length() == 0) {
                    // párrafo vacío: línea en blanco del tamaño normal
                    String sz = last(pRunDef, "<w:sz w:val=\"(\\d+)\"");
                    El st = new El(); st.size = sz != null ? Integer.parseInt(sz) / 2f : defSize;
                    b.text.setLength(0); b.text.append('\u00A0'); b.runs.clear(); addRun(b, 0, 1, st);
                    b.emptyLine = true;
                }
            }
            r.blocks.add(b);
        }
        // los espacios antes/después en DOCX ya están en puntos: se pasan a «em» de 1 pt (basePt = 1) → ya cuadran
        for (int k = r.blocks.size() - 1; k >= 0; k--) {
            Block b = r.blocks.get(k);
            if (b.kind == PAGE && (k == 0 || k == r.blocks.size() - 1 || r.blocks.get(k - 1).kind == PAGE)) r.blocks.remove(k);
        }
        return r;
    }

    static String nz(String s) { return s == null ? "" : s; }

    static String last(String s, String regex) {
        Matcher m = Pattern.compile(regex).matcher(s);
        String r = null;
        while (m.find()) r = m.group(1);
        return r;
    }

    static String lastTag(String s, String tag) {
        Matcher m = Pattern.compile("<" + tag + "\\s[^>]*?/?>").matcher(s);
        String r = null;
        while (m.find()) r = m.group();
        return r;
    }

    /** ¿Está activada la propiedad (por ejemplo <w:b/>), mirando la última vez que aparece? */
    static boolean on(String s, String tag) {
        Matcher m = Pattern.compile("<" + tag + "(?:\\s+w:val=\"([^\"]*)\")?\\s*/>").matcher(s);
        boolean r = false;
        while (m.find()) { String v = m.group(1); r = v == null || !(v.equals("0") || v.equals("false") || v.equals("none")); }
        return r;
    }

    /** twips (1/20 pt) → pt. */
    static float twip(String a, String b) {
        String v = a != null ? a : b;
        if (v == null) return 0;
        try { return Integer.parseInt(v) / 20f; } catch (Exception e) { return 0; }
    }

    /** Copia de los bloques (las imágenes se comparten). */
    public Rich copy() {
        Rich r = new Rich();
        r.basePt = basePt; r.serif = serif; r.lang = lang;
        r.images.putAll(images);
        for (Block b : blocks) r.blocks.add(copy(b));
        return r;
    }

    public static Block copy(Block b) {
        Block c = new Block();
        c.kind = b.kind; c.text.append(b.text); c.align = b.align; c.indent = b.indent; c.left = b.left; c.right = b.right;
        c.before = b.before; c.after = b.after; c.lineH = b.lineH; c.heading = b.heading; c.keepNext = b.keepNext;
        c.image = b.image; c.imgW = b.imgW; c.imgH = b.imgH; c.emptyLine = b.emptyLine;
        for (Run x : b.runs) {
            Run y = new Run();
            y.s = x.s; y.e = x.e; y.b = x.b; y.i = x.i; y.u = x.u; y.sup = x.sup; y.sub = x.sub; y.size = x.size; y.color = x.color; y.bg = x.bg;
            c.runs.add(y);
        }
        return c;
    }

    /** Documento sencillo a partir de párrafos (TXT, PDF): título y texto justificado. */
    public static Rich fromParas(String title, List<String> paras) {
        Rich r = new Rich();
        r.serif = false;
        if (title != null && !title.trim().isEmpty()) {
            Block t = new Block();
            t.text.append(title.trim());
            Run x = new Run(); x.s = 0; x.e = t.text.length(); x.b = true; x.size = 1.6f;
            t.runs.add(x);
            t.heading = true; t.keepNext = true; t.after = 1;
            r.blocks.add(t);
        }
        for (String p : paras) {
            Block b = new Block();
            b.text.append(p);
            Run x = new Run(); x.s = 0; x.e = p.length();
            b.runs.add(x);
            b.align = JUSTIFY; b.after = 0.6f; b.lineH = 1.3f;
            r.blocks.add(b);
        }
        return r;
    }

    /** Texto plano (para el editor y los demás formatos). */
    public List<String> paras() {
        List<String> out = new ArrayList<>();
        for (Block b : blocks) {
            if (b.kind != TEXT || b.emptyLine) continue;
            String t = b.text.toString().replace('\u00A0', ' ').trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }
}
