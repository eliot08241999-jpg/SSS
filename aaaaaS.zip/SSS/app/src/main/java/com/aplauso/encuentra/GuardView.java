package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 🛡 GUARDIÁN Y HECHICERA (v1.1): la Hechicera quedó convertida en piedra y los monstruos vienen a romperla.
 * Tú eres el Guardián: chocas contra los monstruos para atacarlos, recoges sus gotas de luz y se las llevas
 * a la Hechicera; con ellas despierta y lanza magia. Entre fases, la tienda. 50 fases en 5 tierras, con jefe
 * cada 10. Diseño original de SSS+ (por BLORP.eoac).
 */
public class GuardView extends GameKit.GameView implements ArcadeActivity.Backable {
    static final int S_TITLE = 0, S_PLAY = 1, S_PAUSE = 2, S_CLEAR = 3, S_LOST = 4, S_SHOP = 5, S_INTRO = 6, S_WIN = 7;
    int st = S_TITLE;
    float stT, t;
    final Random rnd = new Random();

    static final int STAGES = 50;
    static final String[] LANDS = {"Pradera Verde", "Bosque Susurro", "Desierto de Ámbar", "Montes Nevados", "Castillo Sombrío"};
    static final int[][] LAND_COL = {{0xFF5DAE4A, 0xFF4E9A3E, 0xFF77C25F}, {0xFF2F6B3A, 0xFF285C31, 0xFF3F8248},
            {0xFFD9B26A, 0xFFC9A05A, 0xFFE6C584}, {0xFFDDE6EE, 0xFFC9D4DE, 0xFFF2F6FA}, {0xFF4A4458, 0xFF3D384A, 0xFF5A536A}};

    // ---------------- progreso (se guarda) ----------------
    int stage = 1, gold, lvStr, lvShield, lvBoots, lvFire, lvWind, lvHeart;
    // ---------------- fase ----------------
    float hx, hy, hFace = 1, hHp, hMax, hDown, hInv;     // Guardián
    int carry;                                            // gotas de luz que lleva
    float wHp, wMax = 100, wEnergy, wCast;               // Hechicera
    float wx, wy;
    int toSpawn, killed, total;
    float spawnT;
    boolean boss;

    static final class Mob { int type; float x, y, hp, max, atk, spd, hit, wob, size; boolean flip; float bumpX, bumpY; }
    final List<Mob> mobs = new ArrayList<>();
    static final class Drop { float x, y, life; int kind, val; }       // kind 0 oro, 1 gota de luz
    final List<Drop> drops = new ArrayList<>();
    static final class Fx { float x, y, r, life, max; int c; String s; }
    final List<Fx> fx = new ArrayList<>();

    // ---------------- control: joystick flotante ----------------
    int joyId = -1;
    float jx, jy, jdx, jdy;
    RectF magicBtn = new RectF();
    float fieldTop = 46, fieldBot;

    // ---------------- sprites (originales) ----------------
    static final Pix HERO = new Pix(Pix.pal('h', 0xFFB8C4D0, 'd', 0xFF6B7684, 'f', 0xFFF2C9A0, 'e', 0xFF1A1A2A, 'b', 0xFF2F6FE0, 'c', 0xFF1E4AA0, 's', 0xFFE8EEF5, 'y', 0xFFFFD34A),
            "..hhhh....", ".hhddhh...", ".hffffh...", ".hfefef...", "..ffff..s.", ".bbybbb.s.", "bbbybbbbs.", ".bbybbb.y.", "..cc.cc...", "..c...c...");
    static final Pix WITCH = new Pix(Pix.pal('k', 0xFF3B2459, 'm', 0xFF6D3FB0, 'y', 0xFFFFD34A, 'f', 0xFFF6D2B4, 'e', 0xFF2A1A3A, 'r', 0xFFE24A8A, 'p', 0xFF8E4FD8, 'q', 0xFF5E2FA0),
            "....kk....", "...kmmk...", "..kmmmmk..", ".kkkykkkk.", "kkkkkkkkkk", "..rffffr..", "..fefeff..", "..ffffff..", ".pppppppp.", "pppqppqppp", ".pppppppp.", "..qq..qq..");
    static final Pix SLIME = new Pix(Pix.pal('g', 0xFF59D65E, 'h', 0xFF3CA845, 'w', 0xFFFFFFFF, 'k', 0xFF16301A),
            "..gggg..", ".gggggg.", "gwkggwkg", "gggggggg", "hgggggghg".substring(0, 8), "hhhhhhhh");
    static final Pix BAT = new Pix(Pix.pal('b', 0xFF5A3B7A, 'c', 0xFF3E2858, 'r', 0xFFFF4D5E),
            "b......b", "bb.bb.bb", "bbbbbbbb", "cbrbbrbc", ".bbbbbb.", "..c..c..");
    static final Pix SKEL = new Pix(Pix.pal('w', 0xFFEDEDE0, 'g', 0xFFB9B9A8, 'k', 0xFF222222),
            "..www...", ".wwwww..", ".wkwkw..", "..www...", ".wgwgw..", "w.www.w.", "..w.w...", ".ww.ww..");
    static final Pix WOLF = new Pix(Pix.pal('g', 0xFF8A8F9A, 'h', 0xFF6A6F7A, 'w', 0xFFFFE07A, 'k', 0xFF222222),
            "g.....g.", "gg...gg.", "ggggggg.", "gwgggwg.", "hggggg..", ".hgkgh..", "..h.h...");
    static final Pix ORC = new Pix(Pix.pal('g', 0xFF4F9A3A, 'h', 0xFF3A7A2A, 'w', 0xFFFFFFFF, 'k', 0xFF222222, 'b', 0xFF7A4A2A, 's', 0xFFB8C4D0),
            "..gggg..s", ".gwgwgg.s", ".gggggg.s", ".ghhhhg.b", "bbbbbbbbb", ".bbbbbb..", ".gg..gg..");
    static final Pix GOLEM = new Pix(Pix.pal('s', 0xFF8E8A80, 't', 0xFF6E6A60, 'r', 0xFFFF6A3A, 'm', 0xFF4CC2FF),
            "..ssss..", ".ssssss.", "ssrssrss", "ssssssss", "tsmmmmst", "ssssssss", "ss.ss.ss", "tt....tt");
    static final Pix[] MOB_SPR = {SLIME, BAT, SKEL, WOLF, ORC, GOLEM};
    static final String[] MOB_NAME = {"Limo", "Murciélago", "Esqueleto", "Lobo", "Orco", "Gólem"};

    final Paint pp = new Paint();

    GuardView(Context c) {
        super(c);
        load();
        chip.play(Songs.GUARDIAN_HECHI);
    }

    @Override void computeScale(int w, int h) { vw = 360; scale = w / vw; vh = h / scale; }
    @Override void layout() {
        fieldBot = vh - 96;
        wx = vw / 2; wy = (fieldTop + fieldBot) / 2;
        magicBtn = new RectF(vw - 128, vh - 86, vw - 12, vh - 18);
    }
    @Override boolean navActive() { return st != S_PLAY; }
    @Override public boolean onBack() {
        if (st == S_PLAY) { st = S_PAUSE; return true; }
        if (st == S_PAUSE) { st = S_PLAY; return true; }
        return false;
    }

    int land() { return Math.min(LANDS.length - 1, (Math.min(stage, STAGES) - 1) / 10); }

    // ---------------- guardar ----------------
    void load() {
        stage = Math.max(1, prefs().getInt("gh_stage", 1));
        gold = prefs().getInt("gh_gold", 0);
        lvStr = prefs().getInt("gh_str", 0); lvShield = prefs().getInt("gh_shield", 0); lvBoots = prefs().getInt("gh_boots", 0);
        lvFire = prefs().getInt("gh_fire", 0); lvWind = prefs().getInt("gh_wind", 0); lvHeart = prefs().getInt("gh_heart", 0);
    }
    void save() {
        prefs().edit().putInt("gh_stage", stage).putInt("gh_gold", gold).putInt("gh_str", lvStr).putInt("gh_shield", lvShield)
                .putInt("gh_boots", lvBoots).putInt("gh_fire", lvFire).putInt("gh_wind", lvWind).putInt("gh_heart", lvHeart).apply();
        if (stage - 1 > prefs().getInt("best_guard", 0)) prefs().edit().putInt("best_guard", stage - 1).apply();
    }

    float atk() { return 1 + lvStr * 0.8f; }
    float def() { return lvShield * 0.35f; }
    float spd() { return 78 + lvBoots * 9; }

    // ---------------- empezar fase ----------------
    void startStage() {
        mobs.clear(); drops.clear(); fx.clear();
        hMax = 10 + lvShield * 3;
        hHp = hMax; hDown = 0; hInv = 0;
        hx = wx; hy = wy + 40;
        carry = 0;
        wMax = 100 + lvHeart * 30;
        wHp = wMax;
        wEnergy = 0; wCast = 0;
        boss = stage % 10 == 0;
        total = 8 + stage * 2 + (boss ? 0 : 0);
        toSpawn = total;
        killed = 0;
        spawnT = 1.5f;
        if (boss) { spawn(5); toSpawn = Math.max(6, total / 2); total = toSpawn + 1; }
        st = S_INTRO;
        stT = 0;
        chip.sfx(Chip.SFX_LEVEL);
    }

    void spawn(int type) {
        Mob m = new Mob();
        m.type = type;
        int side = rnd.nextInt(4);
        float fx0 = 10, fx1 = vw - 10, fy0 = fieldTop + 10, fy1 = fieldBot - 10;
        m.x = side == 0 ? fx0 : side == 1 ? fx1 : fx0 + rnd.nextFloat() * (fx1 - fx0);
        m.y = side == 2 ? fy0 : side == 3 ? fy1 : fy0 + rnd.nextFloat() * (fy1 - fy0);
        float k = 1 + (stage - 1) * 0.09f;
        float[][] base = {{3, 1, 22}, {2, 1, 38}, {6, 2, 20}, {5, 2, 42}, {12, 3, 15}, {90, 6, 11}};   // vida, ataque, velocidad
        m.max = m.hp = base[type][0] * k * (type == 5 ? 1 + stage / 25f : 1);
        m.atk = base[type][1] * (1 + (stage - 1) * 0.05f);
        m.spd = base[type][2] * (1 + Math.min(0.5f, stage * 0.01f));
        m.size = type == 5 ? 4.2f : 2.6f;
        m.wob = rnd.nextFloat() * 6;
        mobs.add(m);
    }

    int pickType() {
        int s = Math.min(stage, STAGES);
        float r = rnd.nextFloat();
        if (s >= 30 && r < 0.12f) return 4;
        if (s >= 14 && r < 0.3f) return 3;
        if (s >= 6 && r < 0.48f) return 2;
        if (s >= 3 && r < 0.66f) return 1;
        return 0;
    }

    // ---------------- actualizar ----------------
    @Override void update(float dt) {
        t += dt; stT += dt;
        for (int i = fx.size() - 1; i >= 0; i--) { Fx f = fx.get(i); f.life -= dt; if (f.s != null) f.y -= 25 * dt; if (f.life <= 0) fx.remove(i); }
        if (st == S_INTRO && stT > 1.5f) { st = S_PLAY; stT = 0; }
        if (st != S_PLAY) return;
        if (gp.enabled && gp.pressed(GameKit.G_START)) { onBack(); return; }

        // ---- aparecer monstruos ----
        spawnT -= dt;
        int alive = mobs.size();
        if (toSpawn > 0 && spawnT <= 0 && alive < 6 + stage / 3) {
            spawn(pickType());
            toSpawn--;
            spawnT = Math.max(0.35f, 1.6f - stage * 0.025f) * (0.6f + rnd.nextFloat() * 0.8f);
        }

        // ---- Guardián ----
        float mx = 0, my = 0;
        if (joyId >= 0) { float l = (float) Math.hypot(jdx, jdy); if (l > 6) { mx = jdx / Math.max(l, 40); my = jdy / Math.max(l, 40); } }
        if (gp.enabled) {
            if (gp.down(GameKit.G_LEFT)) mx = -1; if (gp.down(GameKit.G_RIGHT)) mx = 1;
            if (gp.down(GameKit.G_UP)) my = -1; if (gp.down(GameKit.G_DOWN)) my = 1;
            if (gp.pressed(GameKit.G_A) || gp.pressed(GameKit.G_X)) cast();
        }
        if (hDown > 0) {
            hDown -= dt;
            if (hDown <= 0) { hHp = hMax; hx = wx; hy = wy + 30; hInv = 2; fx.add(text(hx, hy - 20, L.t("¡DE PIE!"), Color.WHITE)); }
        } else {
            float l = (float) Math.hypot(mx, my);
            if (l > 1) { mx /= l; my /= l; }
            hx = GameKit.clamp(hx + mx * spd() * dt, 10, vw - 10);
            hy = GameKit.clamp(hy + my * spd() * dt, fieldTop + 10, fieldBot - 10);
            if (mx != 0) hFace = Math.signum(mx);
            if (hInv > 0) hInv -= dt;
        }

        // ---- monstruos ----
        for (int i = mobs.size() - 1; i >= 0; i--) {
            Mob m = mobs.get(i);
            m.wob += dt * 6;
            if (m.hit > 0) m.hit -= dt;
            // empujón tras un golpe
            m.x += m.bumpX * dt; m.y += m.bumpY * dt;
            m.bumpX *= 0.86f; m.bumpY *= 0.86f;
            // objetivo: la Hechicera (los lobos a veces van a por ti)
            float tx = wx, ty = wy;
            if (m.type == 3 && hDown <= 0 && Math.hypot(hx - m.x, hy - m.y) < 110) { tx = hx; ty = hy; }
            float dx = tx - m.x, dy = ty - m.y, d = (float) Math.hypot(dx, dy);
            float stop = (m.type == 5 ? 30 : 18);
            if (d > stop) {
                float sp = m.spd * (m.type == 1 ? 1 + 0.4f * (float) Math.sin(m.wob) : 1);
                m.x += dx / d * sp * dt + (m.type == 1 ? (float) Math.cos(m.wob * 1.3f) * 30 * dt : 0);
                m.y += dy / d * sp * dt;
            } else if (tx == wx) {
                wHp -= m.atk * dt * (m.type == 5 ? 1.2f : 1);          // muerde a la Hechicera
                if (rnd.nextFloat() < dt * 2) fx.add(ring(wx, wy, 0xFFFF4D5E, 14, 0.25f));
            }
            m.flip = dx < 0;
            // choque con el Guardián
            if (hDown <= 0) {
                float hd = (float) Math.hypot(hx - m.x, hy - m.y);
                float rr = m.type == 5 ? 26 : 16;
                if (hd < rr && m.hit <= 0) {
                    m.hp -= atk();
                    m.hit = 0.28f;
                    float nx = (m.x - hx) / Math.max(1, hd), ny = (m.y - hy) / Math.max(1, hd);
                    float kb = m.type == 5 ? 60 : 220;
                    m.bumpX = nx * kb; m.bumpY = ny * kb;
                    hx -= nx * 6; hy -= ny * 6;
                    chip.sfx(Chip.SFX_HIT);
                    fx.add(text(m.x, m.y - 14, "-" + fmt(atk()), Color.WHITE));
                    if (hInv <= 0) {
                        float dmg = Math.max(0.2f, m.atk - def());
                        hHp -= dmg;
                        hInv = 0.35f;
                        if (hHp <= 0) { hDown = 3f; hHp = 0; chip.sfx(Chip.SFX_HURT); fx.add(text(hx, hy - 20, L.t("¡AY!"), 0xFFFF4D5E)); }
                    }
                    if (m.hp <= 0) kill(i, m);
                }
            }
        }

        // ---- recoger lo que sueltan ----
        for (int i = drops.size() - 1; i >= 0; i--) {
            Drop dr = drops.get(i);
            dr.life -= dt;
            if (dr.life <= 0) { drops.remove(i); continue; }
            float d = (float) Math.hypot(dr.x - hx, dr.y - hy);
            if (hDown <= 0 && d < 40) { dr.x += (hx - dr.x) * dt * 8; dr.y += (hy - dr.y) * dt * 8; }
            if (hDown <= 0 && d < 12) {
                if (dr.kind == 0) { gold += dr.val; chip.sfx(Chip.SFX_COIN); }
                else { carry++; chip.sfx(Chip.SFX_JUMP); }
                drops.remove(i);
            }
        }
        // ---- llevar la luz a la Hechicera ----
        if (carry > 0 && hDown <= 0 && Math.hypot(hx - wx, hy - wy) < 26) {
            wEnergy = Math.min(100, wEnergy + carry * 9);
            fx.add(text(wx, wy - 30, "+" + carry + " ✦", 0xFFFFD34A));
            fx.add(ring(wx, wy, 0xFFFFD34A, 30, 0.5f));
            carry = 0;
            chip.sfx(Chip.SFX_POWER);
        }
        if (wCast > 0) wCast -= dt;
        // Hechicera despierta del todo: dispara sola de vez en cuando
        if (wEnergy >= 100 && rnd.nextFloat() < dt * 0.8f && !mobs.isEmpty()) {
            Mob near = null; float bd = 1e9f;
            for (Mob m : mobs) { float d = (float) Math.hypot(m.x - wx, m.y - wy); if (d < bd) { bd = d; near = m; } }
            if (near != null) { near.hp -= 1 + lvFire; fx.add(ring(near.x, near.y, 0xFFFF8A3D, 12, 0.3f)); if (near.hp <= 0) kill(mobs.indexOf(near), near); }
        }

        // ---- fin de fase ----
        if (wHp <= 0) { wHp = 0; st = S_LOST; stT = 0; chip.sfx(Chip.SFX_BOOM); save(); return; }
        if (toSpawn == 0 && mobs.isEmpty()) {
            int bonus = 20 + stage * 6 + (int) (wHp / wMax * 30);
            gold += bonus;
            fx.add(text(vw / 2, vh / 2, "+" + bonus + " 🪙", 0xFFFFD34A));
            stage++;
            save();
            st = stage > STAGES && (stage - 1) == STAGES ? S_WIN : S_CLEAR;
            stT = 0;
            chip.sfx(Chip.SFX_LEVEL);
        }
    }

    void kill(int i, Mob m) {
        if (i < 0) return;
        mobs.remove(i);
        killed++;
        chip.sfx(Chip.SFX_BOOM);
        fx.add(ring(m.x, m.y, 0xFFFFFFFF, 16, 0.3f));
        Drop g = new Drop(); g.kind = 0; g.x = m.x + rnd.nextFloat() * 8 - 4; g.y = m.y; g.val = 1 + stage / 4 + (m.type == 5 ? 40 : m.type); g.life = 12;
        drops.add(g);
        int lights = m.type == 5 ? 6 : (rnd.nextFloat() < 0.6f ? 1 : 0);
        for (int k = 0; k < lights; k++) { Drop d = new Drop(); d.kind = 1; d.x = m.x + rnd.nextFloat() * 20 - 10; d.y = m.y + rnd.nextFloat() * 20 - 10; d.life = 14; drops.add(d); }
    }

    /** Magia de la Hechicera: un anillo de fuego (y viento si lo mejoraste) que daña a todo lo cercano. */
    void cast() {
        if (st != S_PLAY || wEnergy < 30 || wCast > 0) { if (st == S_PLAY && wEnergy < 30) fx.add(text(wx, wy - 34, L.t("¡Tráeme luz!"), 0xFFFFD34A)); return; }
        wEnergy -= 30;
        wCast = 0.5f;
        float rad = 70 + lvWind * 16, dmg = 3 + lvFire * 2.5f;
        fx.add(ring(wx, wy, 0xFFFF8A3D, rad, 0.6f));
        fx.add(ring(wx, wy, 0xFFFFD34A, rad * 0.6f, 0.45f));
        for (int i = mobs.size() - 1; i >= 0; i--) {
            Mob m = mobs.get(i);
            float d = (float) Math.hypot(m.x - wx, m.y - wy);
            if (d < rad) {
                m.hp -= dmg;
                float nx = (m.x - wx) / Math.max(1, d), ny = (m.y - wy) / Math.max(1, d);
                m.bumpX = nx * (120 + lvWind * 40); m.bumpY = ny * (120 + lvWind * 40);
                fx.add(text(m.x, m.y - 14, "-" + fmt(dmg), 0xFFFF8A3D));
                if (m.hp <= 0) kill(i, m);
            }
        }
        chip.sfx(Chip.SFX_POWER);
    }

    static String fmt(float v) { return v == Math.floor(v) ? String.valueOf((int) v) : String.format(java.util.Locale.US, "%.1f", v); }
    Fx ring(float x, float y, int c, float r, float life) { Fx f = new Fx(); f.x = x; f.y = y; f.c = c; f.r = r; f.life = f.max = life; return f; }
    Fx text(float x, float y, String s, int c) { Fx f = new Fx(); f.x = x; f.y = y; f.c = c; f.s = s; f.life = f.max = 0.9f; return f; }

    // ---------------- dibujo ----------------
    @Override void render(Canvas c) {
        drawGround(c);
        if (st == S_TITLE) { drawTitle(c); return; }
        if (st == S_SHOP) { drawShop(c); return; }
        // luz en el suelo
        for (Drop d : drops) {
            if (d.life < 3 && ((int) (d.life * 8)) % 2 == 0) continue;
            if (d.kind == 0) { pp.setColor(0xFFFFD34A); c.drawCircle(d.x, d.y, 4, pp); pp.setColor(0xFFB8860B); c.drawCircle(d.x, d.y, 2, pp); }
            else { pp.setColor(Color.argb(120, 255, 240, 150)); c.drawCircle(d.x, d.y, 7, pp); pp.setColor(0xFFFFF6B0); c.drawCircle(d.x, d.y, 3.5f, pp); }
        }
        // Hechicera (petrificada hasta que tiene luz)
        float bob = wEnergy >= 30 ? (float) Math.sin(t * 3) * 2 : 0;
        if (wEnergy >= 30) { pp.setColor(Color.argb(60, 200, 140, 255)); c.drawCircle(wx, wy, 24 + (float) Math.sin(t * 4) * 3, pp); }
        if (wEnergy >= 30) WITCH.draw(c, pp, wx, wy + bob, 2.6f, false, 0); else WITCH.drawStone(c, pp, wx, wy, 2.6f);
        // monstruos y Guardián, ordenados por altura
        List<Object> order = new ArrayList<>(mobs);
        order.add(this);
        order.sort((a, b) -> Float.compare(a == this ? hy : ((Mob) a).y, b == this ? hy : ((Mob) b).y));
        for (Object o : order) {
            if (o == this) drawHero(c);
            else {
                Mob m = (Mob) o;
                float by = (float) Math.sin(m.wob) * (m.type == 1 ? 3 : 1);
                MOB_SPR[m.type].draw(c, pp, m.x, m.y + by, m.size, m.flip, m.hit > 0.18f ? Color.WHITE : 0);
                if (m.hp < m.max) {
                    float w = m.type == 5 ? 40 : 18;
                    pp.setColor(0xAA000000); c.drawRect(m.x - w / 2, m.y - 16 - (m.type == 5 ? 10 : 0), m.x + w / 2, m.y - 13 - (m.type == 5 ? 10 : 0), pp);
                    pp.setColor(0xFFFF4D5E); c.drawRect(m.x - w / 2, m.y - 16 - (m.type == 5 ? 10 : 0), m.x - w / 2 + w * Math.max(0, m.hp / m.max), m.y - 13 - (m.type == 5 ? 10 : 0), pp);
                }
            }
        }
        // efectos
        for (Fx f : fx) {
            float k = f.life / f.max;
            if (f.s != null) { txt.setAlpha((int) (255 * Math.min(1, k * 2))); text(c, f.s, f.x, f.y, 13, f.c); txt.setAlpha(255); }
            else {
                pp.setStyle(Paint.Style.STROKE); pp.setStrokeWidth(4 * k + 1);
                pp.setColor(f.c); pp.setAlpha((int) (220 * k));
                c.drawCircle(f.x, f.y, f.r * (1.2f - k * 0.5f), pp);
                pp.setStyle(Paint.Style.FILL); pp.setAlpha(255);
            }
        }
        drawHud(c);
        if (st == S_INTRO) {
            box(c, new RectF(36, vh / 2 - 66, vw - 36, vh / 2 + 54), 0xFFFFD34A, 220);
            text(c, L.t(LANDS[land()]), vw / 2, vh / 2 - 36, 14, 0xFFFFD34A);
            text(c, (boss ? "⚠ " : "") + L.t("FASE") + " " + stage, vw / 2, vh / 2, 28, Color.WHITE);
            text(c, boss ? L.t("¡Viene un Gólem gigante!") : L.t("Protege a la Hechicera"), vw / 2, vh / 2 + 30, 13, boss ? 0xFFFF6A3D : 0xFFB8C4D0);
        }
        if (st == S_PAUSE) drawPause(c);
        if (st == S_CLEAR) drawClear(c);
        if (st == S_LOST) drawLost(c);
        if (st == S_WIN) drawWin(c);
    }

    void drawHero(Canvas c) {
        if (hDown > 0) { HERO.draw(c, pp, hx, hy + 6, 2.4f, hFace < 0, 0xFF666677); text(c, "💫", hx, hy - 18, 12, Color.WHITE); return; }
        if (hInv > 0 && ((int) (hInv * 20)) % 2 == 0) return;
        HERO.draw(c, pp, hx, hy + (float) Math.abs(Math.sin(t * 10)) * (joyId >= 0 ? -2 : 0), 2.4f, hFace < 0, 0);
        if (carry > 0) { pp.setColor(0xFFFFF6B0); c.drawCircle(hx + 12, hy - 14, 4, pp); text(c, "×" + carry, hx + 22, hy - 10, 10, 0xFFFFF6B0); }
    }

    void drawGround(Canvas c) {
        int[] col = LAND_COL[land()];
        pp.setColor(col[0]);
        c.drawRect(0, 0, vw, vh, pp);
        // baldosas tipo píxel
        for (int y = 0; y < vh; y += 24) for (int x = 0; x < vw; x += 24) {
            int h = (x * 73 + y * 31 + stage * 17) % 11;
            if (h < 3) { pp.setColor(col[1]); c.drawRect(x + 4, y + 6, x + 10, y + 9, pp); }
            else if (h == 5) { pp.setColor(col[2]); c.drawRect(x + 12, y + 14, x + 16, y + 17, pp); }
        }
    }

    void drawHud(Canvas c) {
        pp.setColor(0xCC000000);
        c.drawRect(0, 0, vw, fieldTop - 4, pp);
        c.drawRect(0, fieldBot, vw, vh, pp);
        textLeft(c, L.t("FASE") + " " + stage, 8, 18, 12, 0xFFFFD34A);
        textLeft(c, "🪙 " + gold, 8, 36, 12, 0xFFFFD34A);
        // vida de la Hechicera
        bar(c, 90, 8, vw - 140, 10, wHp / wMax, 0xFFE24A8A, L.t("Hechicera"));
        bar(c, 90, 24, vw - 140, 10, wEnergy / 100f, 0xFFFFD34A, L.t("Luz"));
        text(c, (total - toSpawn - mobs.size()) + "/" + total, vw - 30, 26, 12, Color.WHITE);
        RectF pz = new RectF(vw - 44, 2, vw - 4, 16);
        // abajo: vida del Guardián y botón de magia
        bar(c, 12, fieldBot + 12, 150, 12, hHp / hMax, 0xFF44E07A, L.t("Guardián"));
        textLeft(c, "⚔" + fmt(atk()) + "  🛡" + fmt(def()) + "  👢" + (int) spd(), 12, fieldBot + 44, 11, 0xFFB8C4D0);
        boolean ok = wEnergy >= 30;
        box(c, magicBtn, ok ? 0xFFFF8A3D : Color.DKGRAY, 220);
        text(c, "🔥 " + L.t("MAGIA"), magicBtn.centerX(), magicBtn.centerY() + 6, 16, ok ? Color.WHITE : Color.GRAY);
        if (st == S_PLAY && menuButton(c, new RectF(vw - 128, fieldBot + 4, vw - 12, fieldBot + 20), "II  " + L.t("PAUSA"), Color.GRAY)) st = S_PAUSE;
        if (joyId >= 0) {
            pp.setColor(Color.argb(60, 255, 255, 255)); c.drawCircle(jx, jy, 34, pp);
            pp.setColor(Color.argb(120, 255, 255, 255));
            float l = (float) Math.hypot(jdx, jdy), k = l > 34 ? 34 / l : 1;
            c.drawCircle(jx + jdx * k, jy + jdy * k, 14, pp);
        }
    }

    void bar(Canvas c, float x, float y, float w, float h, float k, int col, String label) {
        pp.setColor(0xFF222230); c.drawRect(x, y, x + w, y + h, pp);
        pp.setColor(col); c.drawRect(x, y, x + w * Math.max(0, Math.min(1, k)), y + h, pp);
        textLeft(c, label, x + 4, y + h - 1.5f, h - 1, Color.WHITE);
    }

    // ---------------- pantallas ----------------
    void drawTitle(Canvas c) {
        float y = vh * 0.18f;
        text(c, L.t("GUARDIÁN"), vw / 2, y, 34, 0xFF2F6FE0);
        text(c, L.t("y HECHICERA"), vw / 2, y + 34, 26, 0xFF8E4FD8);
        HERO.draw(c, pp, vw / 2 - 40, y + 90, 4, false, 0);
        WITCH.draw(c, pp, vw / 2 + 40, y + 90 + (float) Math.sin(t * 3) * 3, 4, false, 0);
        SLIME.draw(c, pp, vw / 2 - 110 + (float) Math.sin(t) * 10, y + 110, 3, false, 0);
        BAT.draw(c, pp, vw / 2 + 115, y + 70 + (float) Math.sin(t * 3) * 6, 3, true, 0);
        float by = vh * 0.48f;
        if (menuButton(c, new RectF(50, by, vw - 50, by + 50), (stage > 1 ? L.t("▶ CONTINUAR · FASE") + " " + Math.min(stage, STAGES + 99) : L.t("▶ EMPEZAR")), 0xFF44E07A)) {
            if (stage > 1) { st = S_SHOP; stT = 0; } else startStage();
        }
        if (stage > 1 && menuButton(c, new RectF(50, by + 62, vw - 50, by + 112), L.t("🛒 TIENDA"), 0xFFFFD34A)) { st = S_SHOP; stT = 0; }
        text(c, L.t("🏆 Récord: fase") + " " + prefs().getInt("best_guard", 0), vw / 2, vh - 130, 14, Color.WHITE);
        wrap(c, "Arrastra el dedo para moverte y choca contra los monstruos para golpearlos. Lleva las gotas de luz a la Hechicera para despertarla y pulsa MAGIA.",
                vw / 2, vh - 104, vw - 40, 12, Color.rgb(200, 210, 225), true);
    }

    static final String[] SHOP_N = {"⚔ Fuerza", "🛡 Escudo", "👢 Botas", "🔥 Fuego", "🌪 Torbellino", "💗 Corazón"};
    static final String[] SHOP_D = {"Golpeas más fuerte", "Más vida y menos daño", "Te mueves más rápido", "La magia hace más daño", "La magia llega más lejos y empuja", "La Hechicera aguanta más"};

    int lvOf(int i) { return i == 0 ? lvStr : i == 1 ? lvShield : i == 2 ? lvBoots : i == 3 ? lvFire : i == 4 ? lvWind : lvHeart; }
    int cost(int i) { int l = lvOf(i); return (int) (30 * Math.pow(l + 1, 1.55) * (i == 2 ? 0.8f : 1)); }
    void buy(int i) {
        if (i == 0) lvStr++; else if (i == 1) lvShield++; else if (i == 2) lvBoots++; else if (i == 3) lvFire++; else if (i == 4) lvWind++; else lvHeart++;
    }

    void drawShop(Canvas c) {
        pp.setColor(0xEE120E1A); c.drawRect(0, 0, vw, vh, pp);
        text(c, L.t("🛒 TIENDA"), vw / 2, 44, 24, 0xFFFFD34A);
        text(c, "🪙 " + gold, vw / 2, 70, 16, 0xFFFFD34A);
        float y = 92;
        for (int i = 0; i < 6; i++) {
            RectF r = new RectF(18, y, vw - 18, y + 64);
            int cst = cost(i);
            boolean can = gold >= cst && lvOf(i) < 25;
            box(c, r, can ? 0xFFFFD34A : Color.DKGRAY, 210);
            textLeft(c, L.t(SHOP_N[i]) + "  " + L.t("niv.") + " " + lvOf(i), 30, y + 24, 15, Color.WHITE);
            textLeft(c, L.t(SHOP_D[i]), 30, y + 46, 11, 0xFFB8C4D0);
            txt.setTextAlign(Paint.Align.RIGHT); txt.setTextSize(14); txt.setColor(can ? 0xFFFFD34A : Color.GRAY);
            c.drawText(lvOf(i) >= 25 ? "MAX" : "🪙 " + cst, vw - 30, y + 38, txt);
            txt.setTextAlign(Paint.Align.CENTER);
            if (tapIn(r) && can) { gold -= cst; buy(i); save(); chip.sfx(Chip.SFX_COIN); }
            y += 72;
        }
        if (menuButton(c, new RectF(50, vh - 120, vw - 50, vh - 70), L.t("▶ FASE") + " " + stage, 0xFF44E07A)) startStage();
        if (menuButton(c, new RectF(100, vh - 60, vw - 100, vh - 20), L.t("☰ MENÚ"), Color.GRAY)) st = S_TITLE;
    }

    void dim(Canvas c) { pp.setColor(Color.argb(170, 0, 0, 0)); c.drawRect(0, 0, vw, vh, pp); }

    void drawPause(Canvas c) {
        dim(c);
        text(c, L.t("PAUSA"), vw / 2, vh * 0.32f, 30, Color.WHITE);
        float y = vh * 0.4f;
        if (menuButton(c, new RectF(60, y, vw - 60, y + 48), L.t("▶ SEGUIR"), 0xFF44E07A)) st = S_PLAY;
        if (menuButton(c, new RectF(60, y + 60, vw - 60, y + 108), L.t("↻ REPETIR FASE"), 0xFFFFD34A)) startStage();
        if (menuButton(c, new RectF(60, y + 120, vw - 60, y + 168), L.t("☰ MENÚ"), Color.GRAY)) st = S_TITLE;
    }

    void drawClear(Canvas c) {
        dim(c);
        text(c, L.t("¡FASE SUPERADA!"), vw / 2, vh * 0.36f, 26, 0xFF44E07A);
        text(c, "🪙 " + gold, vw / 2, vh * 0.43f, 18, 0xFFFFD34A);
        if ((stage - 1) % 10 == 0) text(c, L.t("¡Has vencido al Gólem! Nueva tierra:") + " " + L.t(LANDS[land()]), vw / 2, vh * 0.48f, 12, 0xFFFFD34A);
        if (stT > 0.6f) {
            if (menuButton(c, new RectF(60, vh * 0.54f, vw - 60, vh * 0.54f + 48), L.t("🛒 TIENDA Y SIGUIENTE"), 0xFFFFD34A)) { st = S_SHOP; stT = 0; }
            if (menuButton(c, new RectF(60, vh * 0.54f + 60, vw - 60, vh * 0.54f + 108), L.t("▶ SIGUIENTE FASE"), 0xFF44E07A)) startStage();
        }
    }

    void drawLost(Canvas c) {
        dim(c);
        text(c, L.t("¡La Hechicera se ha roto!"), vw / 2, vh * 0.36f, 20, 0xFFFF4D5E);
        wrap(c, "Conservas tu oro y tus mejoras. Compra algo en la tienda e inténtalo otra vez.", vw / 2, vh * 0.42f, vw - 60, 13, Color.WHITE, true);
        if (stT > 0.6f) {
            if (menuButton(c, new RectF(60, vh * 0.52f, vw - 60, vh * 0.52f + 48), L.t("🛒 TIENDA"), 0xFFFFD34A)) { st = S_SHOP; stT = 0; }
            if (menuButton(c, new RectF(60, vh * 0.52f + 60, vw - 60, vh * 0.52f + 108), L.t("↻ REINTENTAR"), 0xFF44E07A)) startStage();
        }
    }

    void drawWin(Canvas c) {
        dim(c);
        text(c, L.t("¡LAS 5 TIERRAS ESTÁN A SALVO!"), vw / 2, vh * 0.34f, 18, 0xFFFFD34A);
        WITCH.draw(c, pp, vw / 2 + 24, vh * 0.45f, 4, false, 0);
        HERO.draw(c, pp, vw / 2 - 24, vh * 0.45f, 4, false, 0);
        wrap(c, "Puedes seguir jugando fases cada vez más difíciles.", vw / 2, vh * 0.55f, vw - 60, 13, Color.WHITE, true);
        if (stT > 1f && menuButton(c, new RectF(60, vh * 0.62f, vw - 60, vh * 0.62f + 48), L.t("▶ SEGUIR"), 0xFF44E07A)) { st = S_SHOP; stT = 0; }
    }

    // ---------------- toques ----------------
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        super.onTouchEvent(e);
        if (st != S_PLAY) return true;
        int a = e.getActionMasked(), i = e.getActionIndex();
        float x = e.getX(i) / scale, y = e.getY(i) / scale;
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            if (magicBtn.contains(x, y)) { cast(); return true; }
            if (y > fieldBot && y < fieldBot + 22 && x > vw - 130) return true;      // pausa
            if (joyId < 0 && y > fieldTop) { joyId = e.getPointerId(i); jx = x; jy = y; jdx = jdy = 0; }
        } else if (a == MotionEvent.ACTION_MOVE && joyId >= 0) {
            int k = e.findPointerIndex(joyId);
            if (k >= 0) { jdx = e.getX(k) / scale - jx; jdy = e.getY(k) / scale - jy; }
        } else if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP || a == MotionEvent.ACTION_CANCEL) && e.getPointerId(i) == joyId) {
            joyId = -1; jdx = jdy = 0;
        }
        return true;
    }
}
