package com.aplauso.encuentra;

import android.content.ContentUris;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Galería automática con pestañas Fotos / Videos / Audios; tocar abre el editor. */
public class GalleryActivity extends NeonActivity {
    static final int REQ_MEDIA = 30, REQ_PICK = 31, REQ_WRITE = 32, REQ_DELETE = 33;

    int type = Media.TYPE_IMAGE;
    List<Media.Item> items = new ArrayList<>();
    GridView grid;
    ListView list;
    TextView info, tabImg, tabVid, tabAud, tabDoc;
    Runnable pendingWrite;
    View allFilesBtn;
    View recordBtn;
    LinearLayout limitedBox;
    final ExecutorService pool = Executors.newFixedThreadPool(3);
    final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    final Adapter adapter = new Adapter();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(14), dpi(18), dpi(14), dpi(8));
        col.addView(topBar("EDITORES"), gapBelow(12));

        LinearLayout tabs = new LinearLayout(this);
        tabImg = button("🖼 FOTOS", v -> load(Media.TYPE_IMAGE));
        tabVid = button("🎬 VIDEOS", v -> load(Media.TYPE_VIDEO));
        tabAud = button("🎵 MÚSICA", v -> load(Media.TYPE_AUDIO));
        tabDoc = button("📄 DOCS", v -> load(Media.TYPE_DOC));
        for (TextView tb : new TextView[]{tabImg, tabVid, tabAud, tabDoc}) { tb.setTextSize(11); tb.setPadding(dpi(2), dpi(12), dpi(2), dpi(12)); }
        tabs.addView(tabImg, weight(true));
        tabs.addView(tabVid, weight(true));
        tabs.addView(tabAud, weight(true));
        tabs.addView(tabDoc, weight(false));
        col.addView(tabs, gapBelow(8));

        recordBtn = button("🎙 GRABAR SONIDO NUEVO", v ->
                startActivity(new Intent(this, AudioEditorActivity.class).putExtra("record", true)));
        col.addView(recordBtn, gapBelow(8));

        // Aviso de acceso limitado ("Seleccionar fotos")
        limitedBox = panel("⚠ ACCESO LIMITADO");
        limitedBox.addView(text("Android solo deja a SSS+ ver las fotos/videos que elegiste. "
                + "Para ver toda tu galería, permite el acceso a todas.", 13));
        TextView allow = button("✓ PERMITIR TODAS", v -> openAppSettings());
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2);
        alp.topMargin = dpi(8);
        limitedBox.addView(allow, alp);
        limitedBox.setVisibility(View.GONE);
        col.addView(limitedBox, gapBelow(8));

        col.addView(button("📂 ABRIR DESDE EL TELÉFONO", v -> pickFromPhone()), gapBelow(8));
        allFilesBtn = button("🔓 PERMITIR VER TODOS LOS DOCUMENTOS", v -> Media.requestAllFiles(this));
        allFilesBtn.setVisibility(View.GONE);
        col.addView(allFilesBtn, gapBelow(8));

        info = text("", 13);
        info.setGravity(Gravity.CENTER);
        col.addView(info, gapBelow(6));

        FrameLayout area = new FrameLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dpi(4));
        grid.setVerticalSpacing(dpi(4));
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(this::open);
        grid.setOnItemLongClickListener((par, v, pos, id) -> { actions(items.get(pos)); return true; });
        list = new ListView(this);
        list.setAdapter(adapter);
        list.setOnItemClickListener(this::open);
        list.setOnItemLongClickListener((par, v, pos, id) -> { actions(items.get(pos)); return true; });
        list.setDividerHeight(dpi(6));
        area.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        area.addView(list, new FrameLayout.LayoutParams(-1, -1));
        col.addView(area, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(makeRoot(col));

        load(type);
    }

    private void openAppSettings() {
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    android.net.Uri.fromParts("package", getPackageName(), null)));
            toast("Permisos → Fotos y videos → Permitir todo");
        } catch (Exception e) {
            toast("Ábrelo en Ajustes → Apps → SSS+ → Permisos");
        }
    }

    /** Selector del sistema: funciona siempre, aunque el permiso esté limitado. */
    private void pickFromPhone() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        if (type == Media.TYPE_DOC) {
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, DocsActivity.DOC_MIMES);
        } else i.setType(type == Media.TYPE_VIDEO ? "video/*" : type == Media.TYPE_AUDIO ? "audio/*" : "image/*");
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_PICK) {
            if (res != RESULT_OK || data == null || data.getData() == null) return;
            android.net.Uri u = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            Class<?> target = type == Media.TYPE_VIDEO ? VideoEditorActivity.class
                    : type == Media.TYPE_AUDIO ? AudioEditorActivity.class
                    : type == Media.TYPE_DOC ? DocReaderActivity.class : PhotoEditorActivity.class;
            startActivity(new Intent(this, target).setData(u));
            return;
        }
        if (req == REQ_WRITE || req == REQ_DELETE) {
            Runnable r = pendingWrite;
            pendingWrite = null;
            if (res == RESULT_OK) {
                if (req == REQ_WRITE && r != null) { try { r.run(); } catch (Exception e) { toast("No se pudo: " + e.getMessage()); } }
                else if (req == REQ_DELETE) toast("Eliminado ✓");
                load(type);
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    private LinearLayout.LayoutParams weight(boolean gap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        if (gap) lp.rightMargin = dpi(6);
        return lp;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code != REQ_MEDIA) return;
        load(type);
    }

    boolean asked = false;

    @Override
    protected void onResume() {
        super.onResume();
        load(type); // por si guardaste algo nuevo o cambiaste el permiso
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
    }

    void load(int t) {
        type = t;
        tabImg.setAlpha(t == Media.TYPE_IMAGE ? 1f : 0.45f);
        tabVid.setAlpha(t == Media.TYPE_VIDEO ? 1f : 0.45f);
        tabAud.setAlpha(t == Media.TYPE_AUDIO ? 1f : 0.45f);
        tabDoc.setAlpha(t == Media.TYPE_DOC ? 1f : 0.45f);
        recordBtn.setVisibility(t == Media.TYPE_AUDIO ? View.VISIBLE : View.GONE);
        allFilesBtn.setVisibility(View.GONE);
        if (t == Media.TYPE_DOC) { loadDocs(); return; }
        int acc = Media.access(this, t);
        limitedBox.setVisibility(acc == Media.ACCESS_PARTIAL ? View.VISIBLE : View.GONE);
        if (acc == Media.ACCESS_NONE) {
            items = new ArrayList<>();
            adapter.notifyDataSetChanged();
            if (!asked) { asked = true; Media.request(this, REQ_MEDIA); info.setText(L.t("Esperando permiso…")); }
            else {
                info.setText(L.t("Sin permiso no puedo mostrar tu galería. Toca aquí para abrir los permisos, "
                        + "o usa \"Abrir desde el teléfono\"."));
                info.setOnClickListener(v -> openAppSettings());
            }
            return;
        }
        info.setOnClickListener(null);
        info.setText(L.t("Cargando…"));
        pool.execute(() -> {
            List<Media.Item> got = Media.query(this, t, null, null, 800);
            runOnUiThread(() -> {
                if (t != type) return;
                items = got;
                grid.setVisibility(t == Media.TYPE_AUDIO ? View.GONE : View.VISIBLE);
                list.setVisibility(t == Media.TYPE_AUDIO ? View.VISIBLE : View.GONE);
                adapter.notifyDataSetChanged();
                String err = Media.lastError;
                if (err != null) info.setText(L.t("Error al leer la galería: " + err));
                else if (items.isEmpty()) info.setText(L.t(acc == Media.ACCESS_PARTIAL
                        ? "No has elegido ninguno todavía. Pulsa \"Permitir todas\"."
                        : "No hay archivos"));
                else info.setText(L.t(items.size() + " archivos · toca uno para editarlo"));
            });
        });
    }

    void loadDocs() {
        limitedBox.setVisibility(View.GONE);
        grid.setVisibility(View.GONE);
        list.setVisibility(View.VISIBLE);
        if (!Media.allFiles(this)) {
            items = new ArrayList<>();
            adapter.notifyDataSetChanged();
            allFilesBtn.setVisibility(View.VISIBLE);
            info.setText(L.t("Android solo deja ver documentos de otras apps con \"Acceso a todos los archivos\". "
                    + "Sin él, usa \"Abrir desde el teléfono\"."));
            return;
        }
        info.setText(L.t("Buscando documentos…"));
        pool.execute(() -> {
            List<Media.Item> got = Media.scanDocs(500);
            runOnUiThread(() -> {
                if (type != Media.TYPE_DOC) return;
                items = got;
                adapter.notifyDataSetChanged();
                info.setText(L.t(items.isEmpty() ? "No hay documentos" : items.size() + " documentos · mantén pulsado para más opciones"));
            });
        });
    }

    // ---------------- v1.1: poner una foto de fondo (app, inicio, bloqueo) sin apps externas ----------------
    void wallpaper(Media.Item it) {
        String[] where = {"📱 Fondo de SSS+", "🏠 Pantalla de inicio", "🔒 Pantalla de bloqueo", "🏠🔒 Inicio y bloqueo"};
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Poner de fondo")).setItems(L.ta(where), (d, w) -> {
            if (w == 0) {
                p.edit().putString("bg_uri", it.uri.toString()).apply();
                loadBackground();
                toast("Fondo de SSS+ cambiado ✓");
                return;
            }
            String[] part = {"⬛ Centro", "⬅ Parte izquierda", "➡ Parte derecha", "⬆ Parte de arriba", "⬇ Parte de abajo"};
            new android.app.AlertDialog.Builder(this).setTitle(L.t("¿Qué parte de la foto se ve?")).setItems(L.ta(part), (d2, w2) -> {
                int flags = w == 1 ? android.app.WallpaperManager.FLAG_SYSTEM : w == 2 ? android.app.WallpaperManager.FLAG_LOCK
                        : android.app.WallpaperManager.FLAG_SYSTEM | android.app.WallpaperManager.FLAG_LOCK;
                toast("Poniendo el fondo…");
                new Thread(() -> {
                    String msg;
                    try {
                        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
                        int sw = Math.min(dm.widthPixels, dm.heightPixels), sh = Math.max(dm.widthPixels, dm.heightPixels);
                        BitmapFactory.Options o = new BitmapFactory.Options();
                        o.inJustDecodeBounds = true;
                        try (java.io.InputStream in = getContentResolver().openInputStream(it.uri)) { BitmapFactory.decodeStream(in, null, o); }
                        int sample = 1;
                        while (o.outWidth / (sample * 2) >= sw && o.outHeight / (sample * 2) >= sh) sample *= 2;
                        BitmapFactory.Options o2 = new BitmapFactory.Options();
                        o2.inSampleSize = sample;
                        Bitmap bm;
                        try (java.io.InputStream in = getContentResolver().openInputStream(it.uri)) { bm = BitmapFactory.decodeStream(in, null, o2); }
                        // recorte con la forma de la pantalla, en la parte elegida
                        float target = (float) sw / sh;
                        int bw = bm.getWidth(), bh = bm.getHeight();
                        int cw = bw, ch = bh;
                        if ((float) bw / bh > target) cw = Math.round(bh * target); else ch = Math.round(bw / target);
                        int x = (bw - cw) / 2, y = (bh - ch) / 2;
                        if (w2 == 1) x = 0; else if (w2 == 2) x = bw - cw;
                        if (w2 == 3) y = 0; else if (w2 == 4) y = bh - ch;
                        Bitmap crop = Bitmap.createBitmap(bm, x, y, cw, ch);
                        android.app.WallpaperManager.getInstance(this).setBitmap(crop, null, true, flags);
                        msg = L.t("Fondo puesto ✓");
                    } catch (Exception e) {
                        msg = L.t("No se pudo poner el fondo: ") + e.getMessage();
                    }
                    String m = msg;
                    runOnUiThread(() -> toast(m));
                }, "fondo").start();
            }).show();
        }).show();
    }

    // ---------------- acciones: renombrar, mover, eliminar, detalles ----------------
    void actions(Media.Item it) {
        boolean doc = it.type == Media.TYPE_DOC;
        String[] ops = doc
                ? new String[]{"📖 Leer", "✏ Renombrar", "📁 Mover a…", "🗑 Eliminar", "ℹ Detalles", "📚 Añadir a la biblioteca", "🔄 Convertir"}
                : it.type == Media.TYPE_IMAGE
                ? new String[]{"✂ Editar", "✏ Renombrar", "📁 Mover a…", "🗑 Eliminar", "ℹ Detalles", "🖼 Poner de fondo"}
                : it.type == Media.TYPE_AUDIO
                ? new String[]{"✂ Editar", "✏ Renombrar", "📁 Mover a…", "🗑 Eliminar", "ℹ Detalles", "🏷 Título, autor y portada", "🔄 Cambiar formato"}
                : new String[]{"✂ Editar", "✏ Renombrar", "📁 Mover a…", "🗑 Eliminar", "ℹ Detalles"};
        new android.app.AlertDialog.Builder(this).setTitle(L.t(it.name)).setItems(L.ta(ops), (d, w) -> {
            switch (w) {
                case 0: openItem(it); break;
                case 1: rename(it); break;
                case 2: move(it); break;
                case 3: confirmDelete(it); break;
                case 4: details(it); break;
                case 5:
                    if (it.type == Media.TYPE_AUDIO) { startActivity(new Intent(this, AudioTagActivity.class).setData(it.uri)); break; }
                    if (!doc) { wallpaper(it); break; }
                    LibraryActivity.add(this, it.uri, it.name); toast("Añadido a tu biblioteca ✓"); break;
                case 6:
                    if (it.type == Media.TYPE_AUDIO) { startActivity(new Intent(this, AudioConvertActivity.class).setData(it.uri)); break; }
                    startActivity(new Intent(this, DocsActivity.class)); toast("Elige \"Convertir\" y abre este documento"); break;
            }
        }).show();
    }

    void openItem(Media.Item it) {
        Class<?> target = it.type == Media.TYPE_VIDEO ? VideoEditorActivity.class
                : it.type == Media.TYPE_AUDIO ? AudioEditorActivity.class
                : it.type == Media.TYPE_DOC ? DocReaderActivity.class : PhotoEditorActivity.class;
        startActivity(new Intent(this, target).setData(it.uri).putExtra("name", it.name));
    }

    /** Ejecuta un cambio; si Android pide permiso para tocar archivos de otra app, lo pide y repite. */
    void writeWithPermission(Media.Item it, Runnable change) {
        try {
            change.run();
            load(type);
        } catch (SecurityException e) {
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    java.util.List<android.net.Uri> l = new ArrayList<>();
                    l.add(it.uri);
                    android.app.PendingIntent pi = MediaStore.createWriteRequest(getContentResolver(), l);
                    pendingWrite = change;
                    startIntentSenderForResult(pi.getIntentSender(), REQ_WRITE, null, 0, 0, 0);
                } else if (Build.VERSION.SDK_INT == 29 && e instanceof android.app.RecoverableSecurityException) {
                    pendingWrite = change;
                    startIntentSenderForResult(((android.app.RecoverableSecurityException) e).getUserAction().getActionIntent().getIntentSender(),
                            REQ_WRITE, null, 0, 0, 0);
                } else toast("Android no permite cambiar este archivo");
            } catch (Exception x) {
                toast("No se pudo: " + x.getMessage());
            }
        } catch (Exception e) {
            toast("No se pudo: " + e.getMessage());
        }
    }

    static String ext(String name) {
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(i) : "";
    }

    void rename(Media.Item it) {
        android.widget.EditText et = new android.widget.EditText(this);
        et.setText(DocIO.baseName(it.name));
        et.setSelectAllOnFocus(true);
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Nuevo nombre")).setView(et)
                .setPositiveButton(L.t("Renombrar"), (d, w) -> {
                    String nn = et.getText().toString().trim().replaceAll("[\\\\/:*?\"<>|]", "_");
                    if (nn.isEmpty()) return;
                    String full = nn + ext(it.name);
                    if ("file".equals(it.uri.getScheme())) {
                        java.io.File f = new java.io.File(it.uri.getPath());
                        toast(f.renameTo(new java.io.File(f.getParentFile(), full)) ? "Renombrado ✓" : "No se pudo renombrar");
                        load(type);
                    } else writeWithPermission(it, () -> {
                        android.content.ContentValues v = new android.content.ContentValues();
                        v.put(MediaStore.MediaColumns.DISPLAY_NAME, full);
                        getContentResolver().update(it.uri, v, null, null);
                        toast("Renombrado ✓");
                    });
                }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    void move(Media.Item it) {
        String[] dirs;
        switch (it.type) {
            case Media.TYPE_IMAGE: dirs = new String[]{"SSS+/Fotos", "Pictures/SSS", "Pictures", "DCIM/Camera", "DCIM"}; break;
            case Media.TYPE_VIDEO: dirs = new String[]{"SSS+/Videos", "Movies/SSS", "Movies", "DCIM/Camera", "Pictures"}; break;
            case Media.TYPE_AUDIO: dirs = new String[]{"SSS+/Audios", "Music/SSS", "Music", "Ringtones", "Alarms", "Notifications", "Podcasts"}; break;
            default: dirs = new String[]{"SSS+/Documentos", "SSS+/3D", "Documents/SSS", "Documents", "Download", "Books"};
        }
        String[] labels = new String[dirs.length + 1];
        for (int i = 0; i < dirs.length; i++) labels[i] = "📁 " + dirs[i];
        labels[dirs.length] = "✏ Otra carpeta…";
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Mover a")).setItems(L.ta(labels), (d, w) -> {
            if (w < dirs.length) moveTo(it, dirs[w]);
            else {
                android.widget.EditText et = new android.widget.EditText(this);
                et.setHint(L.t(dirs[0].split("/")[0] + "/MiCarpeta"));
                et.setText(dirs[0].split("/")[0] + "/");
                new android.app.AlertDialog.Builder(this).setTitle(L.t("Carpeta")).setView(et)
                        .setPositiveButton(L.t("Mover"), (x, y) -> moveTo(it, et.getText().toString().trim()))
                        .setNegativeButton(L.t("Cancelar"), null).show();
            }
        }).show();
    }

    void moveTo(Media.Item it, String dir) {
        if (dir.isEmpty()) return;
        if ("file".equals(it.uri.getScheme())) {
            java.io.File f = new java.io.File(it.uri.getPath());
            java.io.File folder = new java.io.File(android.os.Environment.getExternalStorageDirectory(), dir);
            folder.mkdirs();
            toast(f.renameTo(new java.io.File(folder, f.getName())) ? "Movido a " + dir + " ✓" : "No se pudo mover");
            load(type);
            return;
        }
        if (Build.VERSION.SDK_INT < 29) { toast("Mover necesita Android 10 o superior"); return; }
        writeWithPermission(it, () -> {
            android.content.ContentValues v = new android.content.ContentValues();
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir.endsWith("/") ? dir : dir + "/");
            getContentResolver().update(it.uri, v, null, null);
            toast("Movido a " + dir + " ✓");
        });
    }

    void confirmDelete(Media.Item it) {
        new android.app.AlertDialog.Builder(this).setTitle(L.t("¿Eliminar?")).setMessage(L.t(it.name))
                .setPositiveButton(L.t("Eliminar"), (d, w) -> delete(it))
                .setNegativeButton(L.t("Cancelar"), null).show();
    }

    void delete(Media.Item it) {
        if ("file".equals(it.uri.getScheme())) {
            toast(new java.io.File(it.uri.getPath()).delete() ? "Eliminado ✓" : "No se pudo eliminar");
            load(type);
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                java.util.List<android.net.Uri> l = new ArrayList<>();
                l.add(it.uri);
                android.app.PendingIntent pi = MediaStore.createDeleteRequest(getContentResolver(), l);
                startIntentSenderForResult(pi.getIntentSender(), REQ_DELETE, null, 0, 0, 0);
            } else {
                writeWithPermission(it, () -> { getContentResolver().delete(it.uri, null, null); toast("Eliminado ✓"); });
            }
        } catch (Exception e) {
            toast("No se pudo eliminar");
        }
    }

    void details(Media.Item it) {
        String where = "";
        if ("file".equals(it.uri.getScheme())) where = it.uri.getPath();
        else if (Build.VERSION.SDK_INT >= 29) {
            try (android.database.Cursor c = getContentResolver().query(it.uri, new String[]{MediaStore.MediaColumns.RELATIVE_PATH}, null, null, null)) {
                if (c != null && c.moveToFirst()) where = c.getString(0);
            } catch (Exception ignored) {}
        }
        String msg = "Nombre: " + it.name + "\nTamaño: " + SysInfo.bytes(it.size)
                + "\nFecha: " + new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new java.util.Date(it.dateSec * 1000))
                + (it.durationMs > 0 ? "\nDuración: " + time(it.durationMs) : "")
                + (where.isEmpty() ? "" : "\nCarpeta: " + where);
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Detalles")).setMessage(L.t(msg)).setPositiveButton(L.t("OK"), null).show();
    }

    void open(AdapterView<?> parent, View v, int pos, long id) {
        Media.Item it = items.get(pos);
        if (it.type == Media.TYPE_DOC) { openItem(it); return; }
        Class<?> target = it.type == Media.TYPE_VIDEO ? VideoEditorActivity.class
                : it.type == Media.TYPE_AUDIO ? AudioEditorActivity.class : PhotoEditorActivity.class;
        startActivity(new Intent(this, target).setData(it.uri).putExtra("name", it.name));
    }

    static String time(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    Bitmap thumb(Media.Item it) {
        try {
            if (Build.VERSION.SDK_INT >= 29)
                return getContentResolver().loadThumbnail(it.uri, new Size(300, 300), null);
            long id = ContentUris.parseId(it.uri);
            if (it.type == Media.TYPE_VIDEO)
                return MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), id, MediaStore.Video.Thumbnails.MINI_KIND, null);
            return MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), id, MediaStore.Images.Thumbnails.MINI_KIND, null);
        } catch (Exception e) {
            return null;
        }
    }

    class Adapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            Media.Item it = items.get(pos);
            if (it.type == Media.TYPE_AUDIO || it.type == Media.TYPE_DOC) {
                TextView t = convert instanceof TextView ? (TextView) convert : button("", null);
                t.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                t.setClickable(false);
                t.setLongClickable(false);
                if (it.type == Media.TYPE_DOC)
                    t.setText(DocsActivity.icon(it.name) + "  " + it.name + "\n      " + SysInfo.bytes(it.size));
                else t.setText("🎵  " + it.name + "\n      " + time(it.durationMs) + " · " + SysInfo.bytes(it.size));
                return t;
            }
            FrameLayout cell;
            ImageView img;
            TextView dur;
            if (convert instanceof FrameLayout) {
                cell = (FrameLayout) convert;
                img = (ImageView) cell.getChildAt(0);
                dur = (TextView) cell.getChildAt(1);
            } else {
                cell = new FrameLayout(GalleryActivity.this);
                int size = (grid.getWidth() > 0 ? grid.getWidth() : getResources().getDisplayMetrics().widthPixels) / 3 - dpi(4);
                cell.setLayoutParams(new GridView.LayoutParams(-1, size));
                img = new ImageView(GalleryActivity.this);
                img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                img.setBackgroundColor(Color.argb(60, 255, 255, 255));
                cell.addView(img, new FrameLayout.LayoutParams(-1, -1));
                dur = text("", 11);
                dur.setBackgroundColor(Color.argb(150, 0, 0, 0));
                dur.setPadding(dpi(4), dpi(1), dpi(4), dpi(1));
                cell.addView(dur, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END));
            }
            dur.setVisibility(it.type == Media.TYPE_VIDEO ? View.VISIBLE : View.GONE);
            dur.setText("▶ " + time(it.durationMs));
            String key = it.uri.toString();
            img.setTag(key);
            Bitmap cached = cache.get(key);
            img.setImageBitmap(cached);
            if (cached == null) {
                final ImageView target = img;
                pool.execute(() -> {
                    Bitmap bm = thumb(it);
                    if (bm == null) return;
                    cache.put(key, bm);
                    runOnUiThread(() -> { if (key.equals(target.getTag())) target.setImageBitmap(bm); });
                });
            }
            return cell;
        }
    }
}
