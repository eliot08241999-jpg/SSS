package com.aplauso.encuentra;

/**
 * v1.4 · Chloe en persona: el dibujo de la mascota (diseño original de SSS+ por BLORP.eoac).
 * Chica chibi con melena corta neón, auriculares con micro y dos pinzas de rombo que brillan.
 * Todo vectorial (se dibuja a cualquier tamaño) sobre un lienzo virtual de 200 × 220.
 * No depende de Android: el lienzo es una interfaz, así se puede probar también en el ordenador.
 */
public class AvatarArt {
    /** Lo mínimo que necesita para dibujar. */
    public interface C {
        void save(); void restore();
        void translate(float x, float y); void rotate(float deg, float px, float py); void scale(float s, float px, float py);
        void color(int argb);
        /** Color que se desvanece hacia abajo (opaco en y0, transparente en y1). */
        void colorFade(int argb, float y0, float y1);
        void oval(float cx, float cy, float rx, float ry);                 // relleno
        void ring(float cx, float cy, float rx, float ry, float w);        // contorno
        void begin(); void moveTo(float x, float y); void lineTo(float x, float y);
        void quadTo(float x1, float y1, float x, float y);
        void cubicTo(float x1, float y1, float x2, float y2, float x, float y);
        void close(); void fill(); void stroke(float w);
        void text(String s, float x, float y, float size);
    }

    // estados
    public static final int IDLE = 0, LISTEN = 1, THINK = 2, TALK = 3, HAPPY = 4, CONFUSED = 5, SAD = 6, LOVE = 7, SLEEP = 8;

    /** Lo que cambia en cada fotograma. */
    public static final class Pose {
        public int state = IDLE;
        public float t;            // segundos
        public float blink;        // 0 abiertos … 1 cerrados
        public float mouth;        // 0 cerrada … 1 abierta (hablar)
        public float lookX, lookY; // -1…1 hacia dónde mira
        public float blush;        // 0…1
        public float tilt;         // grados
        public int neon = 0xFF00E5FF;
    }

    static int a(int c, float alpha) { return (Math.round(Math.max(0, Math.min(1, alpha)) * 255) << 24) | (c & 0xFFFFFF); }

    static int mix(int c1, int c2, float k) {
        int r = (int) (((c1 >> 16) & 255) * (1 - k) + ((c2 >> 16) & 255) * k);
        int g = (int) (((c1 >> 8) & 255) * (1 - k) + ((c2 >> 8) & 255) * k);
        int b = (int) ((c1 & 255) * (1 - k) + (c2 & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    static final int SKIN = 0xFFFFE6D6, SKIN_SH = 0xFFF5C9B4, LINE = 0xFF2A1E3A, HOODIE = 0xFF1A2140, HOODIE_D = 0xFF121833,
            IRIS = 0xFF7B4DFF, IRIS_D = 0xFF3B1E99, MOUTH = 0xFF8E2B45, TONGUE = 0xFFFF7A8E, WHITE = 0xFFFFFFFF;

    public static void draw(C c, Pose p) {
        int hair = p.neon, hairD = mix(p.neon, 0xFF0A1030, 0.45f), hairL = mix(p.neon, WHITE, 0.55f);
        float bob = (float) Math.sin(p.t * 2.1) * 1.6f;                     // respira
        float sway = (float) Math.sin(p.t * 0.9) * 1.5f + p.tilt;           // se balancea un poco
        if (p.state == HAPPY || p.state == LOVE) bob += (float) Math.abs(Math.sin(p.t * 6)) * -3f;   // saltitos

        // halo
        c.color(a(hair, 0.10f)); c.oval(100, 112, 92, 92);
        c.color(a(hair, 0.08f)); c.oval(100, 112, 76, 76);

        // ---- cuerpo (sudadera) ----
        c.save(); c.translate(0, bob * 0.4f);
        c.color(HOODIE);
        c.begin(); c.moveTo(34, 222); c.cubicTo(36, 190, 52, 172, 80, 166); c.lineTo(120, 166);
        c.cubicTo(148, 172, 164, 190, 166, 222); c.close(); c.fill();
        c.color(HOODIE_D);
        c.begin(); c.moveTo(70, 168); c.quadTo(100, 196, 130, 168); c.lineTo(122, 166); c.quadTo(100, 184, 78, 166); c.close(); c.fill();
        c.color(a(hair, 0.95f));                                               // ribete neón
        c.begin(); c.moveTo(74, 168); c.quadTo(100, 192, 126, 168); c.stroke(2.2f);
        c.begin(); c.moveTo(100, 186); c.lineTo(100, 222); c.stroke(1.6f);
        c.color(a(hair, 0.9f)); c.oval(93, 200, 2.2f, 2.2f); c.oval(107, 200, 2.2f, 2.2f);   // cordones
        c.restore();

        // ---- cabeza ----
        c.save();
        c.translate(0, bob);
        c.rotate(sway, 100, 150);
        // cuello
        c.color(SKIN_SH); c.begin(); c.moveTo(90, 146); c.lineTo(110, 146); c.lineTo(108, 170); c.lineTo(92, 170); c.close(); c.fill();
        // pelo de detrás (melena corta)
        c.color(hairD);
        c.begin(); c.moveTo(46, 100); c.cubicTo(40, 40, 160, 40, 154, 100); c.cubicTo(158, 130, 156, 150, 146, 160);
        c.quadTo(138, 150, 136, 138); c.lineTo(64, 138); c.quadTo(62, 150, 54, 160); c.cubicTo(44, 150, 42, 130, 46, 100); c.close(); c.fill();
        // cara
        c.color(SKIN); c.oval(100, 104, 46, 48);
        c.color(SKIN_SH); c.begin(); c.moveTo(62, 128); c.quadTo(100, 160, 138, 128); c.quadTo(100, 154, 62, 128); c.close(); c.fill();
        // coloretes
        float bl = 0.25f + p.blush * 0.55f + (p.state == LOVE || p.state == HAPPY ? 0.25f : 0);
        c.color(a(0xFFFF7FA0, bl)); c.oval(72, 122, 9, 5); c.oval(128, 122, 9, 5);
        if (bl > 0.6f) { c.color(a(0xFFFF5C85, bl * 0.7f)); for (int i = 0; i < 3; i++) { c.begin(); c.moveTo(66 + i * 5, 125); c.lineTo(69 + i * 5, 119); c.stroke(1.1f); c.begin(); c.moveTo(122 + i * 5, 125); c.lineTo(125 + i * 5, 119); c.stroke(1.1f); } }

        eyes(c, p);
        brows(c, p);
        mouth(c, p);

        // flequillo
        c.color(hair);
        c.begin(); c.moveTo(50, 104); c.cubicTo(44, 52, 92, 34, 116, 46); c.cubicTo(146, 52, 160, 78, 152, 108);
        c.quadTo(146, 92, 140, 84); c.quadTo(138, 98, 130, 104); c.quadTo(126, 86, 118, 76);
        c.quadTo(112, 94, 100, 98); c.quadTo(102, 84, 96, 74); c.quadTo(86, 92, 72, 98); c.quadTo(76, 86, 72, 78);
        c.quadTo(62, 92, 50, 104); c.close(); c.fill();
        // mechones laterales
        c.begin(); c.moveTo(52, 96); c.quadTo(46, 128, 58, 150); c.quadTo(60, 128, 62, 104); c.close(); c.fill();
        c.begin(); c.moveTo(148, 96); c.quadTo(154, 128, 142, 150); c.quadTo(140, 128, 138, 104); c.close(); c.fill();
        // brillo del pelo
        c.color(a(hairL, 0.85f));
        c.begin(); c.moveTo(70, 58); c.quadTo(96, 44, 124, 52); c.quadTo(98, 50, 74, 62); c.close(); c.fill();
        c.color(a(WHITE, 0.55f)); c.oval(88, 52, 5, 2.2f);
        // la «antena»: mechón rebelde
        c.color(hair);
        c.begin(); c.moveTo(104, 44); c.quadTo(110 + (float) Math.sin(p.t * 3) * 3, 26, 122, 24); c.quadTo(112, 32, 110, 46); c.close(); c.fill();

        // pinzas de rombo que brillan
        float glow = 0.55f + 0.45f * (float) Math.sin(p.t * 3.2);
        diamond(c, 136, 74, 6, 0xFFFF5CF0, glow);
        diamond(c, 127, 70, 4f, WHITE, 1.0f - glow * 0.5f);

        // auriculares
        c.color(0xFF262B4A);
        c.begin(); c.moveTo(50, 98); c.cubicTo(46, 34, 154, 34, 150, 98); c.stroke(5f);
        c.color(a(hair, 0.9f)); c.begin(); c.moveTo(50, 98); c.cubicTo(46, 34, 154, 34, 150, 98); c.stroke(1.4f);
        cup(c, 50, 106, hair, p);
        cup(c, 150, 106, hair, p);
        // micro
        c.color(0xFF262B4A); c.begin(); c.moveTo(46, 114); c.quadTo(52, 140, 76, 142); c.stroke(3f);
        c.color(p.state == LISTEN || p.state == TALK ? a(0xFFFF4F7A, 0.6f + 0.4f * glow) : a(hair, 0.8f));
        c.oval(78, 142, 4, 3.4f);
        c.restore();

        effects(c, p, hair);
    }

    static void diamond(C c, float x, float y, float r, int col, float glow) {
        c.color(a(col, 0.25f * glow)); c.oval(x, y, r * 2.2f, r * 2.2f);
        c.color(col);
        c.begin(); c.moveTo(x, y - r); c.lineTo(x + r * 0.7f, y); c.lineTo(x, y + r); c.lineTo(x - r * 0.7f, y); c.close(); c.fill();
        c.color(a(WHITE, 0.8f)); c.begin(); c.moveTo(x, y - r * 0.7f); c.lineTo(x + r * 0.25f, y); c.lineTo(x, y - r * 0.1f); c.close(); c.fill();
    }

    static void cup(C c, float x, float y, int neon, Pose p) {
        c.color(0xFF1C2140); c.oval(x, y, 10, 14);
        c.color(a(neon, 0.95f)); c.ring(x, y, 10, 14, 2f);
        c.color(a(neon, p.state == LISTEN ? 0.9f : 0.5f)); c.oval(x, y, 3.5f, 5f);
    }

    static void eyes(C c, Pose p) {
        float lx = p.lookX * 3.2f, ly = p.lookY * 3f;
        for (int side = -1; side <= 1; side += 2) {
            float ex = 100 + side * 20, ey = 106;
            boolean closedHappy = p.state == HAPPY || p.state == LOVE;
            if (p.state == SLEEP || (p.blink > 0.85f && !closedHappy)) {        // cerrados
                c.color(LINE); c.begin(); c.moveTo(ex - 9, ey + 1); c.quadTo(ex, ey + 6, ex + 9, ey + 1); c.stroke(2.4f);
                continue;
            }
            if (closedHappy) {                                                   // ^ ^
                c.color(LINE); c.begin(); c.moveTo(ex - 9, ey + 4); c.quadTo(ex, ey - 8, ex + 9, ey + 4); c.stroke(2.8f);
                continue;
            }
            if (p.state == CONFUSED && side == 1) {                              // un ojo «>»
                c.color(LINE); c.begin(); c.moveTo(ex - 7, ey - 6); c.lineTo(ex + 6, ey); c.lineTo(ex - 7, ey + 6); c.stroke(2.6f);
                continue;
            }
            float open = 1f - p.blink;
            float ry = 12.5f * open, rx = 9.5f;
            // blanco
            c.color(WHITE); c.oval(ex, ey, rx + 1.5f, ry + 1f);
            // iris
            c.color(IRIS_D); c.oval(ex + lx, ey + ly + 0.5f, rx * 0.86f, ry * 0.92f);
            c.color(IRIS); c.oval(ex + lx, ey + ly + 2f, rx * 0.72f, ry * 0.7f);
            c.color(mix(IRIS, WHITE, 0.45f)); c.oval(ex + lx, ey + ly + ry * 0.45f, rx * 0.5f, ry * 0.25f);
            c.color(0xFF1A0B40); c.oval(ex + lx, ey + ly, rx * 0.34f, ry * 0.4f);
            // brillos
            c.color(WHITE); c.oval(ex + lx - 3, ey + ly - ry * 0.42f, 3.2f, 3.6f * Math.max(0.3f, open));
            c.oval(ex + lx + 3.5f, ey + ly + ry * 0.3f, 1.6f, 1.6f * Math.max(0.3f, open));
            if (p.state == LOVE) {                                               // corazones en los ojos
                c.color(0xFFFF4F8B); heart(c, ex + lx, ey + ly, 5.5f);
            }
            // pestañas
            c.color(LINE);
            c.begin(); c.moveTo(ex - rx - 2, ey - ry * 0.35f); c.quadTo(ex, ey - ry - 3.5f, ex + rx + 2, ey - ry * 0.45f); c.stroke(2.8f);
            c.begin(); c.moveTo(ex + side * (rx + 1.5f), ey - ry * 0.4f); c.quadTo(ex + side * (rx + 3.5f), ey - ry * 0.45f, ex + side * (rx + 4.5f), ey - ry * 0.3f); c.stroke(1.5f);
        }
    }

    static void brows(C c, Pose p) {
        c.color(mix(p.neon, LINE, 0.55f));
        for (int side = -1; side <= 1; side += 2) {
            float x = 100 + side * 20, y = 88;
            float inner = 0, outer = 0;
            switch (p.state) {
                case CONFUSED: if (side == -1) { inner = -4; outer = -2; } else { inner = 2; outer = -1; } break;
                case SAD: inner = -4; outer = 2; break;
                case THINK: if (side == 1) { inner = -3; outer = -4; } break;
                case LISTEN: inner = -2; outer = -2; break;
                case HAPPY: case LOVE: inner = -2; outer = -1; break;
                default:
            }
            c.begin(); c.moveTo(x - side * 8, y + inner); c.quadTo(x, y - 3 + (inner + outer) / 2, x + side * 8, y + outer); c.stroke(2.2f);
        }
    }

    static void mouth(C c, Pose p) {
        float x = 100, y = 132;
        switch (p.state) {
            case TALK: {
                float o = 1.5f + p.mouth * 7f, w = 6.5f - p.mouth * 1.5f;
                c.color(MOUTH); c.oval(x, y, w, o);
                c.color(TONGUE); c.oval(x, y + o * 0.45f, w * 0.7f, o * 0.4f);
                c.color(WHITE); c.oval(x, y - o * 0.75f, w * 0.75f, Math.min(1.4f, o * 0.2f));
                break;
            }
            case HAPPY: case LOVE:
                c.color(MOUTH);
                c.begin(); c.moveTo(x - 9, y - 2); c.quadTo(x, y - 1, x + 9, y - 2); c.quadTo(x, y + 13, x - 9, y - 2); c.close(); c.fill();
                c.color(TONGUE); c.oval(x, y + 5.5f, 4.5f, 2.6f);
                break;
            case CONFUSED:
                c.color(LINE);
                c.begin(); c.moveTo(x - 8, y + 1); c.quadTo(x - 4, y - 3, x, y + 1); c.quadTo(x + 4, y + 5, x + 8, y + 1); c.stroke(2f);
                break;
            case SAD:
                c.color(LINE); c.begin(); c.moveTo(x - 7, y + 3); c.quadTo(x, y - 4, x + 7, y + 3); c.stroke(2.2f);
                break;
            case THINK:
                c.color(LINE); c.begin(); c.moveTo(x - 3, y + 1); c.quadTo(x + 2, y - 1, x + 7, y - 1); c.stroke(2f);
                break;
            case LISTEN:
                c.color(MOUTH); c.oval(x, y + 0.5f, 3.4f, 2.6f);
                break;
            case SLEEP:
                c.color(MOUTH); c.oval(x, y + 1, 2.4f, 1.8f + (float) Math.sin(p.t * 1.6) * 0.8f);
                break;
            default:
                c.color(LINE); c.begin(); c.moveTo(x - 7, y - 1); c.quadTo(x, y + 5, x + 7, y - 1); c.stroke(2.2f);
        }
    }

    /**
     * v1.4.2 · Mano que se lleva a la barbilla al pensar (la del retrato tiene los brazos en T).
     * (cx, cy) = punta del índice en la barbilla; k = 0 escondida abajo … 1 en su sitio.
     */
    public static void hand(C c, float cx, float cy, float k, int sleeve, int cuff, int skin, boolean bareArm) {
        if (k <= 0.01f) return;
        float e = 1 - (1 - k) * (1 - k) * (1 - k);                // sale suave
        c.save();
        c.translate(0, (1 - e) * 170);
        c.rotate((1 - e) * -10, cx - 40, cy + 200);
        int line = mix(skin, 0xFF3A2A32, 0.5f), shade = mix(skin, 0xFF8A7A90, 0.25f);
        int arm = bareArm ? skin : sleeve, armSh = mix(arm, 0xFF000000, 0.22f);
        // antebrazo: sube desde abajo a la izquierda hasta la muñeca, se desvanece abajo
        float wx = cx - 6, wy = cy + 34;
        c.colorFade(arm, cy + 120, cy + 210);
        c.begin(); c.moveTo(cx - 92, cy + 220); c.cubicTo(cx - 70, cy + 150, cx - 40, cy + 80, wx - 18, wy + 4);
        c.lineTo(wx + 16, wy + 14); c.cubicTo(cx - 10, cy + 100, cx - 30, cy + 160, cx - 42, cy + 220); c.close(); c.fill();
        c.colorFade(armSh, cy + 120, cy + 210);
        c.begin(); c.moveTo(cx - 42, cy + 220); c.cubicTo(cx - 30, cy + 160, cx - 10, cy + 100, wx + 16, wy + 14);
        c.lineTo(wx + 10, wy + 16); c.cubicTo(cx - 18, cy + 104, cx - 38, cy + 162, cx - 52, cy + 220); c.close(); c.fill();
        if (!bareArm) {                                            // puño de la manga
            c.color(cuff);
            c.begin(); c.moveTo(wx - 22, wy + 2); c.quadTo(wx - 2, wy - 10, wx + 20, wy + 10); c.lineTo(wx + 16, wy + 24);
            c.quadTo(wx - 4, wy + 8, wx - 24, wy + 16); c.close(); c.fill();
            c.color(mix(cuff, 0xFF000000, 0.15f));
            for (int i = 0; i < 4; i++) { float t = i / 3f; c.begin(); c.moveTo(wx - 20 + t * 38, wy + 2 + t * 8); c.lineTo(wx - 20 + t * 34, wy + 14 + t * 8); c.stroke(1f); }
        }
        // mano (puño con el índice en la barbilla), a escala de la cara
        c.save();
        c.scale(1.7f, cx, cy);
        c.color(skin); c.oval(cx + 1, cy + 15, 12, 10);
        c.color(shade); c.oval(cx + 3, cy + 19, 9, 5);
        c.color(skin); c.oval(cx + 1, cy + 14, 11, 8);
        c.color(line);
        c.begin(); c.moveTo(cx - 8, cy + 16); c.quadTo(cx + 1, cy + 19, cx + 11, cy + 15); c.stroke(0.8f);
        c.begin(); c.moveTo(cx - 6, cy + 20); c.quadTo(cx + 2, cy + 23, cx + 10, cy + 20); c.stroke(0.7f);
        c.begin(); c.moveTo(cx - 11, cy + 14); c.quadTo(cx - 12, cy + 24, cx + 1, cy + 25); c.quadTo(cx + 12, cy + 24, cx + 12, cy + 14); c.stroke(0.8f);
        // pulgar sobre el puño
        c.color(skin);
        c.begin(); c.moveTo(cx - 10, cy + 13); c.quadTo(cx - 9, cy + 7, cx - 2, cy + 8); c.quadTo(cx + 4, cy + 10, cx + 3, cy + 13); c.close(); c.fill();
        c.color(line); c.begin(); c.moveTo(cx - 10, cy + 13); c.quadTo(cx - 9, cy + 7, cx - 2, cy + 8); c.quadTo(cx + 4, cy + 10, cx + 3, cy + 13); c.stroke(0.8f);
        // índice doblado tocando la barbilla
        c.color(skin);
        c.begin(); c.moveTo(cx - 4, cy + 9); c.quadTo(cx - 5, cy + 1, cx, cy - 1); c.quadTo(cx + 5, cy, cx + 5, cy + 5); c.lineTo(cx + 5, cy + 10); c.close(); c.fill();
        c.color(line); c.begin(); c.moveTo(cx - 4, cy + 9); c.quadTo(cx - 5, cy + 1, cx, cy - 1); c.quadTo(cx + 5, cy, cx + 5, cy + 6); c.stroke(0.8f);
        c.color(0x66FFFFFF); c.oval(cx - 1, cy + 1.5f, 1.6f, 1.2f);
        c.restore();
        c.restore();
    }

    static void heart(C c, float x, float y, float s) {
        c.begin(); c.moveTo(x, y + s * 0.9f);
        c.cubicTo(x - s * 1.6f, y - s * 0.1f, x - s * 0.8f, y - s * 1.3f, x, y - s * 0.45f);
        c.cubicTo(x + s * 0.8f, y - s * 1.3f, x + s * 1.6f, y - s * 0.1f, x, y + s * 0.9f);
        c.close(); c.fill();
    }

    static void sparkle(C c, float x, float y, float r, int col) {
        c.color(col);
        c.begin(); c.moveTo(x, y - r); c.quadTo(x, y, x + r, y); c.quadTo(x, y, x, y + r); c.quadTo(x, y, x - r, y); c.quadTo(x, y, x, y - r); c.close(); c.fill();
    }

    static void effects(C c, Pose p, int neon) {
        float t = p.t;
        switch (p.state) {
            case LISTEN:
                for (int i = 0; i < 3; i++) {
                    float k = (t * 0.9f + i / 3f) % 1f;
                    c.color(a(neon, 0.8f * (1 - k)));
                    c.begin(); c.moveTo(22 - k * 10, 90 - k * 8); c.quadTo(12 - k * 14, 106, 22 - k * 10, 122 + k * 8); c.stroke(2f);
                    c.begin(); c.moveTo(178 + k * 10, 90 - k * 8); c.quadTo(188 + k * 14, 106, 178 + k * 10, 122 + k * 8); c.stroke(2f);
                }
                break;
            case THINK: {
                c.color(a(WHITE, 0.95f));
                c.oval(160, 50, 22, 15); c.oval(140, 66, 4, 4); c.oval(132, 76, 2.4f, 2.4f);
                for (int i = 0; i < 3; i++) {
                    float up = (float) Math.max(0, Math.sin(t * 5 - i * 0.7)) * 3f;
                    c.color(neon == 0 ? LINE : mix(neon, LINE, 0.5f)); c.oval(150 + i * 10, 51 - up, 2.6f, 2.6f);
                }
                break;
            }
            case HAPPY:
                for (int i = 0; i < 4; i++) {
                    float k = (t * 0.7f + i / 4f) % 1f;
                    float x = i % 2 == 0 ? 30 + i * 4 : 168 - i * 4, y = 80 - k * 50;
                    sparkle(c, x, y, 6 * (1 - k * 0.5f), a(i % 2 == 0 ? 0xFFFFE066 : neon, 1 - k));
                }
                break;
            case LOVE:
                for (int i = 0; i < 4; i++) {
                    float k = (t * 0.6f + i / 4f) % 1f;
                    c.color(a(0xFFFF4F8B, 1 - k));
                    heart(c, (i % 2 == 0 ? 34 : 166) + (float) Math.sin(t * 3 + i) * 5, 110 - k * 80, 6 + i);
                }
                break;
            case CONFUSED: {
                c.color(a(0xFF8FD8FF, 0.9f));                                      // gota de sudor
                c.begin(); c.moveTo(150, 70); c.quadTo(158, 84, 150, 88); c.quadTo(142, 84, 150, 70); c.close(); c.fill();
                c.color(a(WHITE, 0.95f)); c.text("?", 160, 52 + (float) Math.sin(t * 4) * 3, 30);
                break;
            }
            case SAD:
                c.color(a(0xFF8FD8FF, 0.85f));
                float k = (t * 0.8f) % 1f;
                c.begin(); c.moveTo(78, 116 + k * 20); c.quadTo(82, 124 + k * 20, 78, 127 + k * 20); c.quadTo(74, 124 + k * 20, 78, 116 + k * 20); c.close(); c.fill();
                break;
            case SLEEP:
                for (int i = 0; i < 3; i++) {
                    float q = (t * 0.4f + i / 3f) % 1f;
                    c.color(a(WHITE, 1 - q)); c.text("z", 150 + q * 25, 70 - q * 40, 12 + q * 12);
                }
                break;
            default:
        }
    }
}
