package com.aplauso.encuentra;

/**
 * v1.5.2 · El corazón de AMPLIAR VÍDEOS (y fotos): una red neuronal pequeña (Real-ESRGAN «SRVGGNetCompact», licencia BSD-3)
 * multiplica ×4 cada fotograma, reconstruyendo bordes y texturas en vez de solo estirar los píxeles. Aquí está lo que
 * no depende de Android: pasar colores, repartir el fotograma en trozos (para no gastar demasiada memoria) y
 * colocar el resultado al tamaño final (720p … 4K). Java puro.
 */
public class SrCore {
    /** Ejecuta la red: entra RGB plano 0..1 [3][h][w], sale [3][4h][4w]. */
    public interface Infer { float[] run(float[] chw, int w, int h) throws Exception; }

    public static final int SCALE = 4;

    /**
     * Amplía el fotograma «in» (RGB plano, w × h) y escribe el resultado (ARGB) en «out» de tw × th.
     * Se trabaja por trozos de «tile» píxeles con «pad» de margen (para que no se noten las costuras).
     */
    public static void upscale(float[] in, int w, int h, int[] out, int tw, int th, int tile, int pad, Infer f) throws Exception {
        if (w * h <= tile * tile * 1.3f) { tile = Math.max(w, h); pad = 0; }
        double fx = (double) w / tw, fy = (double) h / th;           // píxeles de origen por píxel final
        float ratio = (float) Math.min(tw / (double) (SCALE * w), th / (double) (SCALE * h));
        boolean ss = ratio < 0.7f;                                   // bajar mucho: 4 muestras por píxel
        for (int y0 = 0; y0 < h; y0 += tile) {
            int y1 = Math.min(h, y0 + tile);
            for (int x0 = 0; x0 < w; x0 += tile) {
                int x1 = Math.min(w, x0 + tile);
                int px0 = Math.max(0, x0 - pad), py0 = Math.max(0, y0 - pad), px1 = Math.min(w, x1 + pad), py1 = Math.min(h, y1 + pad);
                int pw = px1 - px0, ph = py1 - py0;
                float[] t = new float[3 * pw * ph];
                for (int c = 0; c < 3; c++)
                    for (int y = 0; y < ph; y++)
                        System.arraycopy(in, c * w * h + (py0 + y) * w + px0, t, c * pw * ph + y * pw, pw);
                float[] o = f.run(t, pw, ph);
                int ow = pw * SCALE, oh = ph * SCALE;
                // píxeles finales cuyo centro cae en la parte central de este trozo
                int X0 = (int) Math.ceil(x0 / fx - 0.5), X1 = (int) Math.ceil(x1 / fx - 0.5);
                int Y0 = (int) Math.ceil(y0 / fy - 0.5), Y1 = (int) Math.ceil(y1 / fy - 0.5);
                X0 = Math.max(0, X0); Y0 = Math.max(0, Y0); X1 = Math.min(tw, X1); Y1 = Math.min(th, Y1);
                float[] rgb = new float[3];
                for (int Y = Y0; Y < Y1; Y++) {
                    for (int X = X0; X < X1; X++) {
                        float r = 0, g = 0, b = 0;
                        if (ss) {
                            for (int k = 0; k < 4; k++) {
                                double sx = (X + 0.25 + 0.5 * (k & 1)) * fx * SCALE - 0.5 - px0 * SCALE;
                                double sy = (Y + 0.25 + 0.5 * (k >> 1)) * fy * SCALE - 0.5 - py0 * SCALE;
                                bilinear(o, ow, oh, sx, sy, rgb);
                                r += rgb[0]; g += rgb[1]; b += rgb[2];
                            }
                            r *= 0.25f; g *= 0.25f; b *= 0.25f;
                        } else {
                            double sx = (X + 0.5) * fx * SCALE - 0.5 - px0 * SCALE;
                            double sy = (Y + 0.5) * fy * SCALE - 0.5 - py0 * SCALE;
                            bilinear(o, ow, oh, sx, sy, rgb);
                            r = rgb[0]; g = rgb[1]; b = rgb[2];
                        }
                        out[Y * tw + X] = 0xFF000000 | c8(r) << 16 | c8(g) << 8 | c8(b);
                    }
                }
            }
        }
    }

    static int c8(float v) { int i = (int) (v * 255f + 0.5f); return i < 0 ? 0 : i > 255 ? 255 : i; }

    static void bilinear(float[] o, int w, int h, double x, double y, float[] rgb) {
        if (x < 0) x = 0; if (y < 0) y = 0;
        if (x > w - 1) x = w - 1; if (y > h - 1) y = h - 1;
        int x0 = (int) x, y0 = (int) y, x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
        float ax = (float) (x - x0), ay = (float) (y - y0);
        int n = w * h;
        for (int c = 0; c < 3; c++) {
            int b = c * n;
            float a = o[b + y0 * w + x0] * (1 - ax) + o[b + y0 * w + x1] * ax;
            float d = o[b + y1 * w + x0] * (1 - ax) + o[b + y1 * w + x1] * ax;
            rgb[c] = a * (1 - ay) + d * ay;
        }
    }

    /**
     * YUV 4:2:0 del vídeo (rango limitado, BT.601/709) → RGB plano 0..1.
     * Strides como los de android.media.Image; «hi» = 1 si las muestras son de 16 bits (vídeo de 10 bits): se toma el byte alto.
     */
    public static void yuvToRgb(byte[] Y, int yRow, int yPix, byte[] U, byte[] V, int uvRow, int uvPix, int hi,
                                int w, int h, boolean bt709, float[] out) {
        int n = w * h;
        float kr = bt709 ? 1.5748f : 1.402f, kgu = bt709 ? 0.1873f : 0.344136f, kgv = bt709 ? 0.4681f : 0.714136f, kb = bt709 ? 1.8556f : 1.772f;
        for (int y = 0; y < h; y++) {
            int yo = y * yRow, uo = (y >> 1) * uvRow;
            for (int x = 0; x < w; x++) {
                float yy = ((Y[yo + x * yPix + hi] & 0xff) - 16) * (1f / 219f);
                int ui = uo + (x >> 1) * uvPix + hi;
                float u = ((U[ui] & 0xff) - 128) * (1f / 224f), v = ((V[ui] & 0xff) - 128) * (1f / 224f);
                float r = yy + kr * v, g = yy - kgu * u - kgv * v, b = yy + kb * u;
                int i = y * w + x;
                out[i] = r < 0 ? 0 : r > 1 ? 1 : r;
                out[n + i] = g < 0 ? 0 : g > 1 ? 1 : g;
                out[2 * n + i] = b < 0 ? 0 : b > 1 ? 1 : b;
            }
        }
    }

    /** ARGB → planos Y, U, V (rango limitado BT.709, el normal de 720p para arriba), U y V a la mitad. */
    public static void argbToYuv(int[] px, int w, int h, byte[] Y, byte[] U, byte[] V) {
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int p = px[y * w + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                Y[y * w + x] = (byte) Math.max(16, Math.min(235, (int) (16.5f + 0.1826f * r + 0.6142f * g + 0.0620f * b)));
            }
        int cw = w / 2, ch = h / 2;
        for (int y = 0; y < ch; y++)
            for (int x = 0; x < cw; x++) {
                int r = 0, g = 0, b = 0;
                for (int k = 0; k < 4; k++) {
                    int p = px[(2 * y + (k >> 1)) * w + 2 * x + (k & 1)];
                    r += (p >> 16) & 255; g += (p >> 8) & 255; b += p & 255;
                }
                float R = r / 4f, G = g / 4f, B = b / 4f;
                U[y * cw + x] = (byte) Math.max(16, Math.min(240, (int) (128.5f - 0.1006f * R - 0.3386f * G + 0.4392f * B)));
                V[y * cw + x] = (byte) Math.max(16, Math.min(240, (int) (128.5f + 0.4392f * R - 0.3989f * G - 0.0403f * B)));
            }
    }

    /** Tamaño final: el lado corto pasa a «shortSide» (720, 1080, 1440, 2160), en números pares. */
    public static int[] target(int w, int h, int shortSide) {
        double s = shortSide / (double) Math.min(w, h);
        int tw = (int) Math.round(w * s / 2) * 2, th = (int) Math.round(h * s / 2) * 2;
        return new int[]{tw, th};
    }
}
