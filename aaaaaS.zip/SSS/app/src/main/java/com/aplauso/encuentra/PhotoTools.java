package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Herramientas de imagen compartidas por los dos editores (neón y clásico). */
public class PhotoTools {

    static final String[] FILTERS = {"Ninguno", "Vívido", "Playa", "Miel", "Bosque", "Atardecer",
            "B/N", "Sepia", "Frío", "Cálido", "Neón", "Invertir"};

    /** Carga la foto respetando la orientación de la cámara, con el lado mayor limitado. */
    static Bitmap load(Context ctx, Uri uri, int maxSide) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = ctx.getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > maxSide) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            Bitmap bm;
            try (InputStream in = ctx.getContentResolver().openInputStream(uri)) { bm = BitmapFactory.decodeStream(in, null, o); }
            if (bm == null) return null;
            int deg = 0;
            try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
                ExifInterface ex = new ExifInterface(in);
                int or = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (or == ExifInterface.ORIENTATION_ROTATE_90) deg = 90;
                else if (or == ExifInterface.ORIENTATION_ROTATE_180) deg = 180;
                else if (or == ExifInterface.ORIENTATION_ROTATE_270) deg = 270;
            } catch (Exception ignored) {}
            return deg == 0 ? bm : rotate(bm, deg);
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
    }

    static Bitmap rotate(Bitmap b, int deg) {
        Matrix m = new Matrix();
        m.postRotate(deg);
        return Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
    }

    static ColorMatrix scaleRGB(float r, float g, float b) {
        ColorMatrix m = new ColorMatrix();
        m.setScale(r, g, b, 1f);
        return m;
    }

    static ColorMatrix contrastBright(float contrast, float bright) {
        float t = (1 - contrast) * 128 + bright;
        return new ColorMatrix(new float[]{contrast, 0, 0, 0, t, 0, contrast, 0, 0, t, 0, 0, contrast, 0, t, 0, 0, 0, 1, 0});
    }

    /** Matriz de color de cada filtro de la interfaz clásica. */
    static ColorMatrix filter(int idx) {
        ColorMatrix m = new ColorMatrix();
        ColorMatrix s = new ColorMatrix();
        switch (idx) {
            case 1: s.setSaturation(1.5f); m.postConcat(s); m.postConcat(contrastBright(1.1f, 0)); break;
            case 2: m.postConcat(scaleRGB(1.08f, 1.02f, 0.92f)); m.postConcat(contrastBright(1f, 12)); break;
            case 3: s.setSaturation(0.8f); m.postConcat(s); m.postConcat(scaleRGB(1.12f, 1.0f, 0.8f)); break;
            case 4: m.postConcat(scaleRGB(0.9f, 1.1f, 0.95f)); s.setSaturation(1.1f); m.postConcat(s); break;
            case 5: m.postConcat(scaleRGB(1.2f, 0.95f, 0.85f)); m.postConcat(contrastBright(1.1f, 0)); break;
            case 6: s.setSaturation(0); m.postConcat(s); break;
            case 7: s.setSaturation(0); m.postConcat(s); m.postConcat(scaleRGB(1.07f, 0.95f, 0.78f)); break;
            case 8: m.postConcat(scaleRGB(0.9f, 1.0f, 1.15f)); break;
            case 9: m.postConcat(scaleRGB(1.15f, 1.0f, 0.85f)); break;
            case 10: s.setSaturation(1.9f); m.postConcat(s); break;
            case 11: m.set(new float[]{-1, 0, 0, 0, 255, 0, -1, 0, 0, 255, 0, 0, -1, 0, 255, 0, 0, 0, 1, 0}); break;
            default: break;
        }
        return m;
    }

    /** Aplica el color y redimensiona (w, h ≤ 0 = tamaño original). */
    static Bitmap render(Bitmap src, ColorMatrix cm, int w, int h) {
        int ow = w > 0 ? w : src.getWidth(), oh = h > 0 ? h : src.getHeight();
        Bitmap out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        if (cm != null) paint.setColorFilter(new ColorMatrixColorFilter(cm));
        Matrix m = new Matrix();
        m.setScale(ow / (float) src.getWidth(), oh / (float) src.getHeight());
        c.drawBitmap(src, m, paint);
        return out;
    }

    /** Peso aproximado del archivo final, en bytes. */
    static long estimate(Bitmap b, int quality, boolean png) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            b.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, quality, bos);
            return bos.size();
        } catch (Exception | OutOfMemoryError e) {
            return -1;
        }
    }

    /** Guarda la imagen en SSS+/Fotos. Devuelve la Uri o null. */
    static Uri save(Context ctx, Bitmap b, int quality, boolean png) {
        try {
            File tmp = new File(ctx.getCacheDir(), "edit_" + System.currentTimeMillis() + (png ? ".png" : ".jpg"));
            try (FileOutputStream fos = new FileOutputStream(tmp)) {
                b.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, quality, fos);
            }
            return Media.save(ctx, tmp, Media.TYPE_IMAGE, "SSS_" + Media.stamp() + (png ? ".png" : ".jpg"),
                    png ? "image/png" : "image/jpeg");
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
    }
}
