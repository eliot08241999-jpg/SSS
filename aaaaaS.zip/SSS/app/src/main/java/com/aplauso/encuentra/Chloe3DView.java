package com.aplauso.encuentra;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Random;

/**
 * v1.6 · CHLOE EN 3D. Tu modelo VRM (hecho en VRoid Studio, gratis) dentro de una vista web local (three.js): respira,
 * parpadea, mira, mueve los labios con su voz, hace gestos al azar y cambia de postura según lo que pasa.
 * Todo sale de dentro de la app (nada de internet).
 */
public class Chloe3DView extends WebView implements Avatar {
    static final String HOST = "https://chloe.sss/";

    static File model(Context c) { return new File(c.getFilesDir(), "chloe.vrm"); }

    /** ¿Hay modelo y está activada la Chloe 3D? */
    static boolean active(Context c) {
        return c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("avatar_3d", false) && model(c).length() > 1000;
    }

    /** La Chloe que toca: la 3D si la tienes, si no la dibujada. */
    static Avatar make(Context c) { return active(c) ? new Chloe3DView(c) : new ChloeAvatarView(c); }

    final Handler h = new Handler(Looper.getMainLooper());
    final Random rnd = new Random();
    ChloeAvatarView.OnPoke onPoke;
    boolean ready;
    int base = AvatarArt.IDLE;
    long lastWordSeen;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    public Chloe3DView(Context c) {
        super(c);
        setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        addJavascriptInterface(new Bridge(), "SSS");
        setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!u.toString().startsWith(HOST)) return new WebResourceResponse("text/plain", "utf-8", null);   // nada de fuera
                String path = u.getPath() == null ? "" : u.getPath().replaceFirst("^/", "");
                try {
                    InputStream in;
                    String mime;
                    if (path.equals("model.vrm")) { in = new FileInputStream(model(getContext())); mime = "model/gltf-binary"; }
                    else { in = getContext().getAssets().open("vrm/" + path); mime = path.endsWith(".js") ? "text/javascript" : path.endsWith(".html") ? "text/html" : "application/octet-stream"; }
                    return new WebResourceResponse(mime, "utf-8", in);
                } catch (Exception e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "no", null, null);
                }
            }
        });
        String frame = c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("avatar_3d_frame", "bust");
        loadUrl(HOST + "index.html?m=model.vrm&frame=" + frame);
        h.postDelayed(talkTick, 500);
    }

    final class Bridge {
        @JavascriptInterface public void ready() { h.post(() -> { ready = true; js("chloe.state('" + name(base) + "')"); }); }
        @JavascriptInterface public void error(String m) { }
        @JavascriptInterface public void poke(float x, float y) {
            h.post(() -> {
                react(rnd.nextBoolean() ? AvatarArt.HAPPY : AvatarArt.LOVE, 1800);
                if (onPoke != null && rnd.nextFloat() < 0.6f) { String[] l = rnd.nextFloat() < 0.3f ? ChloeAvatarView.TICKLE : ChloeAvatarView.PAT; onPoke.poke(L.t(l[rnd.nextInt(l.length)])); }
            });
        }
    }

    void js(String code) { if (ready) evaluateJavascript(code, null); }

    static String name(int s) {
        switch (s) {
            case AvatarArt.LISTEN: return "listen";
            case AvatarArt.THINK: return "think";
            case AvatarArt.TALK: return "talk";
            case AvatarArt.HAPPY: return "happy";
            case AvatarArt.CONFUSED: return "confused";
            case AvatarArt.SAD: return "sad";
            case AvatarArt.LOVE: return "love";
            case AvatarArt.SLEEP: return "sleep";
            default: return "idle";
        }
    }

    /** Su boca sigue a la voz: cada sílaba que dice, un golpecito. */
    final Runnable talkTick = new Runnable() {
        float level;
        public void run() {
            if (!isAttachedToWindow() && ready) return;
            boolean talking = Voice.speaking;
            boolean pulse = Voice.lastWord != lastWordSeen;
            lastWordSeen = Voice.lastWord;
            float want = talking ? (SystemClock.uptimeMillis() - Voice.lastWord < 400 ? 0.9f : 0.55f) : 0f;
            level += (want - level) * 0.5f;
            if (ready && (level > 0.01f || pulse)) js("chloe.talk(" + String.format(java.util.Locale.ROOT, "%.2f", level) + "," + (pulse && talking) + ")");
            h.postDelayed(this, 70);
        }
    };

    public void setFrame(String f) {
        getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString("avatar_3d_frame", f).apply();
        js("chloe.frame('" + f + "')");
    }

    @Override public void setState(int s) { base = s; js("chloe.state('" + name(s) + "')"); }
    @Override public void react(int s, long ms) { js("chloe.react('" + name(s) + "'," + ms + ")"); }
    @Override public void setOnPoke(ChloeAvatarView.OnPoke p) { onPoke = p; }
    @Override public void refreshOutfit() { }
    @Override public android.view.View view() { return this; }

    @Override protected void onDetachedFromWindow() { h.removeCallbacks(talkTick); super.onDetachedFromWindow(); }
}
