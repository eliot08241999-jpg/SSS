package com.aplauso.encuentra;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * v1.5 · Guarda un documento CON DISEÑO (Rich) como DOCX o EPUB: negrita, cursiva, tamaños, colores, alineación,
 * sangrías, espacios, imágenes y saltos de página. Así al convertir (o traducir) el archivo sigue pareciéndose al original.
 * Java puro.
 */
public class RichWrite {
    static String esc(String s) { return DocIO.esc(s); }

    static String hex(int c) { return String.format(Locale.ROOT, "%06X", c & 0xFFFFFF); }

    static String ext(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.endsWith(".png") ? "png" : p.endsWith(".gif") ? "gif" : p.endsWith(".webp") ? "webp" : p.endsWith(".svg") ? "svg" : "jpeg";
    }

    /** Tamaño en px de una imagen JPEG/PNG/GIF leyendo la cabecera (sin Android). */
    static int[] imageSize(byte[] b) {
        try {
            if (b.length > 24 && (b[0] & 0xff) == 0x89 && b[1] == 'P')
                return new int[]{((b[16] & 0xff) << 24) | ((b[17] & 0xff) << 16) | ((b[18] & 0xff) << 8) | (b[19] & 0xff),
                        ((b[20] & 0xff) << 24) | ((b[21] & 0xff) << 16) | ((b[22] & 0xff) << 8) | (b[23] & 0xff)};
            if (b.length > 10 && b[0] == 'G' && b[1] == 'I') return new int[]{(b[6] & 0xff) | (b[7] & 0xff) << 8, (b[8] & 0xff) | (b[9] & 0xff) << 8};
            if (b.length > 4 && (b[0] & 0xff) == 0xFF && (b[1] & 0xff) == 0xD8) {
                int i = 2;
                while (i + 9 < b.length) {
                    if ((b[i] & 0xff) != 0xFF) { i++; continue; }
                    int m = b[i + 1] & 0xff;
                    int len = ((b[i + 2] & 0xff) << 8) | (b[i + 3] & 0xff);
                    if (m >= 0xC0 && m <= 0xCF && m != 0xC4 && m != 0xC8 && m != 0xCC)
                        return new int[]{((b[i + 7] & 0xff) << 8) | (b[i + 8] & 0xff), ((b[i + 5] & 0xff) << 8) | (b[i + 6] & 0xff)};
                    i += 2 + len;
                }
            }
        } catch (Exception ignored) {}
        return new int[]{600, 800};
    }

    // =====================================================================
    // DOCX
    // =====================================================================
    public static void docx(Rich r, String title, OutputStream os) throws IOException {
        Map<String, String> imgIds = new LinkedHashMap<>();
        for (String p : r.images.keySet()) imgIds.put(p, "rImg" + (imgIds.size() + 1));
        float pt = r.basePt;                              // puntos por «em»
        StringBuilder b = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" "
                + "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" "
                + "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" "
                + "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:body>");
        boolean pendingBreak = false;
        int picN = 0;
        String font = r.serif ? "Georgia" : "Calibri";
        for (Rich.Block k : r.blocks) {
            if (k.kind == Rich.PAGE) { pendingBreak = true; continue; }
            b.append("<w:p><w:pPr>");
            if (pendingBreak) { b.append("<w:pageBreakBefore/>"); pendingBreak = false; }
            if (k.keepNext) b.append("<w:keepNext/>");
            b.append("<w:spacing w:before=\"").append(Math.round(k.before * pt * 20)).append("\" w:after=\"").append(Math.round(k.after * pt * 20))
                    .append("\" w:line=\"").append(Math.round(240 * k.lineH / 1.15f)).append("\" w:lineRule=\"auto\"/>");
            if (k.left != 0 || k.right != 0 || k.indent != 0) {
                b.append("<w:ind w:left=\"").append(Math.round(k.left * pt * 20)).append("\" w:right=\"").append(Math.round(k.right * pt * 20)).append('"');
                if (k.indent > 0) b.append(" w:firstLine=\"").append(Math.round(k.indent * pt * 20)).append('"');
                else if (k.indent < 0) b.append(" w:hanging=\"").append(Math.round(-k.indent * pt * 20)).append('"');
                b.append("/>");
            }
            String jc = k.align == Rich.CENTER ? "center" : k.align == Rich.RIGHT ? "right" : k.align == Rich.JUSTIFY ? "both" : null;
            if (jc != null) b.append("<w:jc w:val=\"").append(jc).append("\"/>");
            b.append("</w:pPr>");
            if (k.kind == Rich.IMAGE) {
                byte[] img = r.images.get(k.image);
                if (img != null) {
                    int[] sz = imageSize(img);
                    float w = k.imgW > 0 ? k.imgW * 0.75f : sz[0] * 0.75f, ar = sz[1] / (float) Math.max(1, sz[0]);
                    float maxW = 451, maxH = 680;                    // A4 con márgenes de 2,5 cm
                    if (k.imgW < 0) w = maxW * -k.imgW / 100f;
                    w = Math.min(w, maxW);
                    float h = w * ar;
                    if (h > maxH) { h = maxH; w = h / ar; }
                    long cx = Math.round(w * 12700), cy = Math.round(h * 12700);
                    picN++;
                    b.append("<w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"").append(cx).append("\" cy=\"").append(cy)
                            .append("\"/><wp:docPr id=\"").append(picN).append("\" name=\"Imagen ").append(picN).append("\"/>")
                            .append("<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:pic><pic:nvPicPr><pic:cNvPr id=\"")
                            .append(picN).append("\" name=\"img").append(picN).append("\"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed=\"")
                            .append(imgIds.get(k.image)).append("\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"")
                            .append(cx).append("\" cy=\"").append(cy).append("\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>");
                }
                b.append("</w:p>");
                continue;
            }
            String t = k.text.toString();
            List<Rich.Run> runs = k.runs.isEmpty() ? null : k.runs;
            if (runs == null) { Rich.Run x = new Rich.Run(); x.s = 0; x.e = t.length(); runs = new ArrayList<>(); runs.add(x); }
            for (Rich.Run x : runs) {
                if (x.s >= x.e || x.e > t.length()) continue;
                b.append("<w:r><w:rPr><w:rFonts w:ascii=\"").append(font).append("\" w:hAnsi=\"").append(font).append("\"/>");
                if (x.b) b.append("<w:b/>");
                if (x.i) b.append("<w:i/>");
                if (x.u) b.append("<w:u w:val=\"single\"/>");
                if (x.color != 0) b.append("<w:color w:val=\"").append(hex(x.color)).append("\"/>");
                if (x.bg != 0) b.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(hex(x.bg)).append("\"/>");
                float size = x.size * pt;
                if (x.sup || x.sub) { b.append("<w:vertAlign w:val=\"").append(x.sup ? "superscript" : "subscript").append("\"/>"); size /= 0.75f; }
                b.append("<w:sz w:val=\"").append(Math.max(2, Math.round(size * 2))).append("\"/></w:rPr>");
                String[] lines = t.substring(x.s, x.e).replace(' ', ' ').split("\n", -1);
                for (int i = 0; i < lines.length; i++) {
                    if (i > 0) b.append("<w:br/>");
                    if (!lines[i].isEmpty()) b.append("<w:t xml:space=\"preserve\">").append(esc(lines[i])).append("</w:t>");
                }
                b.append("</w:r>");
            }
            b.append("</w:p>");
        }
        b.append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1418\" w:right=\"1418\" w:bottom=\"1418\" w:left=\"1418\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr>");
        b.append("</w:body></w:document>");

        try (ZipOutputStream z = new ZipOutputStream(os)) {
            StringBuilder ct = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                    + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                    + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                    + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                    + "<Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/><Default Extension=\"png\" ContentType=\"image/png\"/>"
                    + "<Default Extension=\"gif\" ContentType=\"image/gif\"/><Default Extension=\"webp\" ContentType=\"image/webp\"/>"
                    + "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"
                    + "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/></Types>");
            DocIO.putText(z, "[Content_Types].xml", ct.toString());
            DocIO.putText(z, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                    + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                    + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>"
                    + "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
                    + "</Relationships>");
            DocIO.putText(z, "docProps/core.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                    + "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" "
                    + "xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:title>" + esc(title) + "</dc:title><dc:creator>SSS+</dc:creator></cp:coreProperties>");
            StringBuilder rels = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
            int n = 0;
            for (Map.Entry<String, String> e : imgIds.entrySet()) {
                String name = "media/img" + (++n) + "." + ext(e.getKey());
                rels.append("<Relationship Id=\"").append(e.getValue()).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"")
                        .append(name).append("\"/>");
                z.putNextEntry(new ZipEntry("word/" + name));
                z.write(r.images.get(e.getKey()));
                z.closeEntry();
            }
            rels.append("</Relationships>");
            DocIO.putText(z, "word/_rels/document.xml.rels", rels.toString());
            DocIO.putText(z, "word/document.xml", b.toString());
        }
    }

    // =====================================================================
    // EPUB (y HTML)
    // =====================================================================
    /** Un bloque como HTML con estilos en línea. */
    static void html(Rich r, Rich.Block k, StringBuilder x, Map<String, String> imgNames) {
        if (k.kind == Rich.IMAGE) {
            String n = imgNames.get(k.image);
            if (n == null) return;
            String al = k.align == Rich.LEFT ? "left" : k.align == Rich.RIGHT ? "right" : "center";
            x.append("<div style=\"text-align:").append(al).append(";margin:0.5em 0\"><img src=\"").append(n).append("\" alt=\"\" style=\"max-width:100%;");
            if (k.imgW > 0) x.append("width:").append(Math.round(k.imgW)).append("px;");
            else if (k.imgW < 0) x.append("width:").append(Math.round(-k.imgW)).append("%;");
            x.append("height:auto\"/></div>\n");
            return;
        }
        float body = r.basePt;
        StringBuilder st = new StringBuilder();
        st.append("margin:").append(f(k.before * body / 12)).append("em ").append(f(k.right * body / 12)).append("em ")
                .append(f(k.after * body / 12)).append("em ").append(f(k.left * body / 12)).append("em;");
        if (k.indent != 0) st.append("text-indent:").append(f(k.indent * body / 12)).append("em;");
        if (k.align != Rich.LEFT) st.append("text-align:").append(k.align == Rich.CENTER ? "center" : k.align == Rich.RIGHT ? "right" : "justify").append(';');
        st.append("line-height:").append(f(k.lineH)).append(';');
        if (k.keepNext) st.append("page-break-after:avoid;");
        x.append(k.heading ? "<p class=\"h\" style=\"" : "<p style=\"").append(st).append("\">");
        String t = k.text.toString();
        if (k.emptyLine) { x.append("&#160;</p>\n"); return; }
        for (Rich.Run u : k.runs) {
            if (u.s >= u.e || u.e > t.length()) continue;
            StringBuilder s = new StringBuilder();
            s.append("font-size:").append(f(u.size * body / 12)).append("em;");
            if (u.b) s.append("font-weight:bold;");
            if (u.i) s.append("font-style:italic;");
            if (u.u) s.append("text-decoration:underline;");
            if (u.color != 0) s.append("color:#").append(hex(u.color)).append(';');
            if (u.bg != 0) s.append("background-color:#").append(hex(u.bg)).append(';');
            if (u.sup) s.append("vertical-align:super;");
            if (u.sub) s.append("vertical-align:sub;");
            x.append("<span style=\"").append(s).append("\">").append(esc(t.substring(u.s, u.e)).replace("\n", "<br/>")).append("</span>");
        }
        x.append("</p>\n");
    }

    static String f(float v) {
        String s = String.format(Locale.ROOT, "%.2f", v);
        while (s.contains(".") && (s.endsWith("0") || s.endsWith("."))) s = s.substring(0, s.length() - 1);
        return s.isEmpty() || s.equals("-") ? "0" : s;
    }

    public static void epub(Rich r, String title, String lang, OutputStream os) throws IOException {
        if (lang == null || lang.isEmpty()) lang = "es";
        Map<String, String> imgNames = new LinkedHashMap<>();
        for (String p : r.images.keySet()) imgNames.put(p, "img" + (imgNames.size() + 1) + "." + ext(p));
        // capítulos: se corta en cada salto de página
        List<StringBuilder> ch = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (Rich.Block k : r.blocks) {
            if (k.kind == Rich.PAGE) { if (cur.length() > 0) { ch.add(cur); cur = new StringBuilder(); } continue; }
            html(r, k, cur, imgNames);
        }
        if (cur.length() > 0 || ch.isEmpty()) ch.add(cur);
        String font = r.serif ? "serif" : "sans-serif";
        try (ZipOutputStream z = new ZipOutputStream(os)) {
            byte[] mt = "application/epub+zip".getBytes(StandardCharsets.US_ASCII);
            ZipEntry me = new ZipEntry("mimetype");
            me.setMethod(ZipEntry.STORED);
            me.setSize(mt.length);
            me.setCompressedSize(mt.length);
            CRC32 crc = new CRC32();
            crc.update(mt);
            me.setCrc(crc.getValue());
            z.putNextEntry(me);
            z.write(mt);
            z.closeEntry();
            DocIO.putText(z, "META-INF/container.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + "<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\"><rootfiles>"
                    + "<rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles></container>");
            DocIO.putText(z, "OEBPS/style.css", "body{font-family:" + font + ";margin:0 4pt}p{margin:0}img{max-width:100%}");
            StringBuilder manifest = new StringBuilder(), spine = new StringBuilder(), nav = new StringBuilder(), ncx = new StringBuilder();
            for (int c = 0; c < ch.size(); c++) {
                String file = "cap" + (c + 1) + ".xhtml";
                DocIO.putText(z, "OEBPS/" + file, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\""
                        + lang + "\"><head><title>" + esc(title) + "</title><link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\"/></head><body>\n" + ch.get(c) + "</body></html>");
                manifest.append("<item id=\"c").append(c + 1).append("\" href=\"").append(file).append("\" media-type=\"application/xhtml+xml\"/>");
                spine.append("<itemref idref=\"c").append(c + 1).append("\"/>");
                String label = chapterLabel(ch.get(c).toString(), c + 1);
                nav.append("<li><a href=\"").append(file).append("\">").append(esc(label)).append("</a></li>");
                ncx.append("<navPoint id=\"n").append(c + 1).append("\" playOrder=\"").append(c + 1).append("\"><navLabel><text>").append(esc(label))
                        .append("</text></navLabel><content src=\"").append(file).append("\"/></navPoint>");
            }
            int n = 0;
            for (Map.Entry<String, String> e : imgNames.entrySet()) {
                String mtp = "image/" + ext(e.getKey()).replace("svg", "svg+xml");
                manifest.append("<item id=\"i").append(++n).append("\" href=\"").append(e.getValue()).append("\" media-type=\"").append(mtp).append('"')
                        .append(n == 1 ? " properties=\"cover-image\"" : "").append("/>");
                z.putNextEntry(new ZipEntry("OEBPS/" + e.getValue()));
                z.write(r.images.get(e.getKey()));
                z.closeEntry();
            }
            String uid = "sss-" + Math.abs((title + ch.size()).hashCode());
            DocIO.putText(z, "OEBPS/nav.xhtml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE html>\n"
                    + "<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\"><head><title>Índice</title></head><body>"
                    + "<nav epub:type=\"toc\"><ol>" + nav + "</ol></nav></body></html>");
            DocIO.putText(z, "OEBPS/toc.ncx", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + "<ncx xmlns=\"http://www.daisy.org/z3986/2005/ncx/\" version=\"2005-1\"><head><meta name=\"dtb:uid\" content=\"" + uid + "\"/></head>"
                    + "<docTitle><text>" + esc(title) + "</text></docTitle><navMap>" + ncx + "</navMap></ncx>");
            DocIO.putText(z, "OEBPS/content.opf", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + "<package xmlns=\"http://www.idpf.org/2007/opf\" version=\"3.0\" unique-identifier=\"uid\">"
                    + "<metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:identifier id=\"uid\">" + uid + "</dc:identifier>"
                    + "<dc:title>" + esc(title) + "</dc:title><dc:language>" + lang + "</dc:language>"
                    + "<meta property=\"dcterms:modified\">2026-01-01T00:00:00Z</meta>" + (imgNames.isEmpty() ? "" : "<meta name=\"cover\" content=\"i1\"/>") + "</metadata>"
                    + "<manifest><item id=\"nav\" href=\"nav.xhtml\" media-type=\"application/xhtml+xml\" properties=\"nav\"/>"
                    + "<item id=\"css\" href=\"style.css\" media-type=\"text/css\"/>"
                    + "<item id=\"ncx\" href=\"toc.ncx\" media-type=\"application/x-dtbncx+xml\"/>" + manifest + "</manifest>"
                    + "<spine toc=\"ncx\">" + spine + "</spine></package>");
        }
    }

    /** Nombre para el índice: el primer texto del capítulo. */
    static String chapterLabel(String html, int n) {
        String t = DocIO.unesc(html.replaceAll("<[^>]+>", " ")).replace(' ', ' ').replaceAll("\\s+", " ").trim();
        if (t.isEmpty()) return "Parte " + n;
        return t.length() > 60 ? t.substring(0, 57) + "…" : t;
    }
}
