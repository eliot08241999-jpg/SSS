package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Pestaña «N» (v1.1): qué versión es, qué trae de nuevo, qué se ha arreglado y todo lo que ya tenía antes.
 * El texto está en assets/changelog_es.txt (y _en, _it):
 *   # título de versión · ## apartado · = texto o subtítulo · + novedad · * arreglo · - detalle del punto anterior
 */
public class NewsActivity extends NeonActivity {

    static String version(Context c) {
        try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; } catch (Exception e) { return "?"; }
    }

    /** ¿Hay novedades sin ver? (para el círculo rojo de la «N»). */
    static boolean unseen(Context c) {
        return !version(c).equals(c.getSharedPreferences("cfg", MODE_PRIVATE).getString("news_seen", ""));
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p.edit().putString("news_seen", version(this)).apply();
        LinearLayout col = screen(L.t("Novedades"));
        TextView head = text("", 14);
        head.setText("SSS+ v" + version(this) + " · " + L.t("por") + " BLORP.eoac");
        col.addView(head, gapBelow(12));

        String lang = "en".equals(L.lang) || "it".equals(L.lang) ? L.lang : "es";
        LinearLayout card = null, body = null;
        boolean first = true;
        int versions = 0;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(getAssets().open("changelog_" + lang + ".txt"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.trim().isEmpty() || line.length() < 2) continue;
                char k = line.charAt(0);
                String t = line.substring(line.startsWith("##") ? 3 : 2).trim();
                if (line.startsWith("##")) {
                    if (body != null) body.addView(styled(t, 14, true, Color.rgb(140, 220, 255)), gapBelow(2));
                } else if (k == '#') {
                    card = panel(null);
                    col.addView(card, gapBelow(12));
                    body = new LinearLayout(this);
                    body.setOrientation(LinearLayout.VERTICAL);
                    boolean isVersion = t.startsWith("v");
                    TextView title = neonText((isVersion ? "" : "📦 ") + t + (isVersion ? (first ? "  ▼" : "  ▶") : ""), 15);
                    card.addView(title, gapBelow(6));
                    card.addView(body);
                    if (isVersion) {
                        versions++;
                        if (!first) body.setVisibility(View.GONE);
                        if (first) {
                            TextView now = styled(L.t("La versión que tienes instalada"), 11, false, Color.rgb(255, 210, 90));
                            card.addView(now, 1);
                        }
                        final LinearLayout bd = body;
                        final String tt = t;
                        title.setOnClickListener(v -> {
                            boolean open = bd.getVisibility() != View.VISIBLE;
                            bd.setVisibility(open ? View.VISIBLE : View.GONE);
                            title.setText(tt + (open ? "  ▼" : "  ▶"));
                        });
                        first = false;
                    }
                } else if (body != null) {
                    if (k == '+') body.addView(item("✨", t, 14, Color.rgb(225, 232, 245)), gapBelow(4));
                    else if (k == '*') body.addView(item("🔧", t, 14, Color.rgb(170, 255, 190)), gapBelow(4));
                    else if (k == '-') { TextView d = item("   •", t, 13, Color.rgb(190, 198, 215)); body.addView(d, gapBelow(3)); }
                    else if (k == '=') body.addView(styled(t, 13, line.length() < 60 && !t.contains("."), Color.rgb(225, 232, 245)), gapBelow(6));
                }
            }
        } catch (Exception e) {
            col.addView(text(L.t("No se pudieron cargar las novedades."), 13));
        }
        TextView leg = styled("✨ " + L.t("Nuevo") + "   🔧 " + L.t("Arreglado") + "   ·   " + versions + " " + L.t("versiones"), 12, false, Color.rgb(160, 168, 185));
        col.addView(leg, 1, gapBelow(12));
    }

    TextView styled(String s, float size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    TextView item(String icon, String s, float size, int color) {
        TextView t = styled(icon + "  " + s, size, false, color);
        t.setLineSpacing(0, 1.1f);
        return t;
    }
}
