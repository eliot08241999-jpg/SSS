package com.aplauso.encuentra;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v1.6 · CALCULADORA EXACTA de Chloe. Las cuentas no las hace el cerebro (los modelos pequeños se equivocan):
 * «¿cuánto es 1500000² × 36?», «2+2», «raíz cuadrada de 81», «el 20 % de 150», «7 por 8», «quanto fa 3 per 4»…
 * Java puro.
 */
public class Calc {
    static final MathContext MC = new MathContext(40, RoundingMode.HALF_EVEN);

    /** Si la pregunta es una cuenta, la respuesta (en el idioma del texto). Si no, null. */
    public static String answer(String q, String lang) {
        String expr = extract(q);
        if (expr == null) return null;
        BigDecimal r;
        try { r = new Parser(expr).parse(); } catch (ArithmeticException e) {
            return "es".equals(lang) ? "Eso no se puede calcular: " + e.getMessage() + "." : "it".equals(lang) ? "Non si può calcolare." : "That can't be calculated.";
        } catch (Exception e) { return null; }
        String shown = pretty(expr);
        String val = format(r, lang);
        String words = magnitude(r, lang);
        return shown + " = " + val + (words.isEmpty() ? "" : " (" + words + ")") + ".";
    }

    // ------------------------------------------------------------------ texto → expresión
    static final Pattern NUM_THOUSANDS = Pattern.compile("(?<![\\d.,])\\d{1,3}(?:([.,])\\d{3})(?:\\1\\d{3})*(?![\\d])");

    /** Saca la cuenta del texto, o null si no es una cuenta. */
    public static String extract(String q) {
        if (q == null) return null;
        String s = " " + q.toLowerCase(Locale.ROOT).replace('\u00A0', ' ') + " ";
        if (!s.matches("(?s).*\\d.*")) return null;
        s = s.replace("²", "^2").replace("³", "^3").replace("×", "*").replace("·", "*").replace("÷", "/").replace("−", "-")
                .replace("√", " raiz ").replace("**", "^");
        s = s.replaceAll("(?<=\\d)\\s*x\\s*(?=\\d)", "*");
        s = s.replaceAll("\\b(?:ra[ií]z cuadrada de|radice quadrata di|square root of|ra[ií]z de|raiz)\\s*", " sqrt ");
        s = s.replaceAll("\\b(?:elevado a la|elevado a|elevato alla|elevato a|to the power of|al cuadrado|al quadrato|squared)\\b", "^")
                .replaceAll("\\^\\s*(?=[^\\d(\\s])", "^2 ");                // «al cuadrado» sin número
        s = s.replaceAll("\\^\\s*$", "^2");
        s = s.replaceAll("(?<=\\d)\\s*(?:por ciento|percent|per cento|%)\\s*(?:de|of|di|del|della)\\s*", " %of ");
        s = s.replaceAll("(?<=\\d)\\s*(?:dividido (?:entre|por)|diviso|divided by|entre|fratto)\\s*(?=[\\d(s])", " / ");
        s = s.replaceAll("(?<=\\d)\\s*(?:multiplicado por|por|per|times|moltiplicato per)\\s*(?=[\\d(s])", " * ");
        s = s.replaceAll("(?<=\\d)\\s*(?:m[aá]s|piu|più|plus)\\s*(?=[\\d(s])", " + ");
        s = s.replaceAll("(?<=\\d)\\s*(?:menos|meno|minus)\\s*(?=[\\d(s])", " - ");
        // 1.500.000 / 1,500,000 → 1500000 (miles); 2,5 → 2.5
        Matcher m = NUM_THOUSANDS.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, m.group().replaceAll("[.,]", ""));
        m.appendTail(sb);
        s = sb.toString().replaceAll("(?<=\\d),(?=\\d)", ".");
        // el trozo con la cuenta
        Matcher e = Pattern.compile("(?:%of|sqrt|[-+*/^()\\d.\\s]){3,}").matcher(s);
        String best = null;
        while (e.find()) {
            String g = e.group().trim();
            if (!g.matches(".*\\d.*")) continue;
            boolean op = g.matches(".*\\d\\s*[-+*/^%].*|.*sqrt.*|.*[-+*/^]\\s*\\(.*");
            if (!op) continue;
            if (best == null || g.length() > best.length()) best = g;
        }
        if (best == null) return null;
        // lo que sobra tiene que ser «cuánto es», «calcula», «=?»… nada más
        String rest = s.replace(best, " ").replaceAll("[¿?¡!=:,.]", " ")
                .replaceAll("\\b(?:cu[aá]nto|cuanta|es|son|da|hace|calcula|calcular|calcul[ae]me|dime|resultado|de|el|la|quanto|fa|calcola|what|is|whats|how|much|calculate|the|please|por favor|chloe|hola|oye|y|e|and|a|ver)\\b", " ")
                .trim();
        if (rest.matches(".*\\d.*") || (rest.split("\\s+").length > 2 && !rest.isEmpty())) return null;
        best = best.replaceAll("\\s+", " ").trim();
        if (best.matches("^[-+*/^%].*") && !best.startsWith("-")) return null;
        return best;
    }

    static String pretty(String e) {
        return e.replace("%of", "% de").replace("sqrt", "√").replace("*", "×").replace("^2", "²").replace("^3", "³")
                .replaceAll("\\s*([×/+^=-])\\s*", " $1 ").replace("( ", "(").replace(" )", ")").replaceAll("\\s+", " ").replace("√ ", "√").replaceAll("\\s+([²³])", "$1").trim();
    }

    // ------------------------------------------------------------------ cuentas
    static final class Parser {
        final String s;
        int p;
        Parser(String s) { this.s = s.replace(" ", ""); }

        BigDecimal parse() {
            BigDecimal v = sum();
            if (p != s.length()) throw new IllegalArgumentException("sobra: " + s.substring(p));
            return v;
        }

        boolean eat(String t) { if (s.startsWith(t, p)) { p += t.length(); return true; } return false; }

        BigDecimal sum() {
            BigDecimal v = term();
            while (true) {
                if (eat("+")) v = v.add(term(), MC);
                else if (eat("-")) v = v.subtract(term(), MC);
                else return v;
            }
        }

        BigDecimal term() {
            BigDecimal v = power();
            while (true) {
                if (eat("*")) v = v.multiply(power(), MC);
                else if (eat("/")) { BigDecimal d = power(); if (d.signum() == 0) throw new ArithmeticException("división entre cero"); v = v.divide(d, MC); }
                else if (eat("%of")) v = v.multiply(power(), MC).divide(BigDecimal.valueOf(100), MC);
                else if (eat("%")) v = v.divide(BigDecimal.valueOf(100), MC);
                else return v;
            }
        }

        BigDecimal power() {
            BigDecimal b = unary();
            if (eat("^")) {
                BigDecimal e = power();                                   // a la derecha: 2^3^2 = 2^9
                try {
                    int n = e.intValueExact();
                    if (Math.abs(n) > 10000) throw new ArithmeticException("número demasiado grande");
                    return n >= 0 ? b.pow(n, MC) : BigDecimal.ONE.divide(b.pow(-n, MC), MC);
                } catch (ArithmeticException x) {
                    if (x.getMessage() != null && x.getMessage().startsWith("número")) throw x;
                    double r = Math.pow(b.doubleValue(), e.doubleValue());
                    if (Double.isNaN(r) || Double.isInfinite(r)) throw new ArithmeticException("resultado no real");
                    return new BigDecimal(r, MC);
                }
            }
            return b;
        }

        BigDecimal unary() {
            if (eat("-")) return unary().negate();
            if (eat("+")) return unary();
            if (eat("sqrt")) {
                BigDecimal v = unary();
                if (v.signum() < 0) throw new ArithmeticException("raíz de un número negativo");
                return sqrt(v);
            }
            if (eat("(")) { BigDecimal v = sum(); eat(")"); return v; }
            int a = p;
            while (p < s.length() && (Character.isDigit(s.charAt(p)) || s.charAt(p) == '.')) p++;
            if (a == p) throw new IllegalArgumentException("falta un número");
            return new BigDecimal(s.substring(a, p));
        }
    }

    static BigDecimal sqrt(BigDecimal v) {
        if (v.signum() == 0) return BigDecimal.ZERO;
        BigDecimal x = new BigDecimal(Math.sqrt(v.doubleValue()), MC);
        BigDecimal two = BigDecimal.valueOf(2);
        for (int i = 0; i < 8; i++) x = x.add(v.divide(x, MC), MC).divide(two, MC);   // Newton: exacta en 40 cifras
        return x;
    }

    // ------------------------------------------------------------------ mostrar
    static String format(BigDecimal r, String lang) {
        BigDecimal v = r.setScale(Math.max(0, Math.min(10, r.scale())), RoundingMode.HALF_UP).stripTrailingZeros();
        if (v.abs().compareTo(new BigDecimal("1e30")) > 0) return String.format(Locale.ROOT, "%.6e", v.doubleValue());
        String plain = v.toPlainString();
        boolean neg = plain.startsWith("-");
        if (neg) plain = plain.substring(1);
        String ip = plain, fp = "";
        int d = plain.indexOf('.');
        if (d >= 0) { ip = plain.substring(0, d); fp = plain.substring(d + 1); }
        char th = "en".equals(lang) ? ',' : '.', dec = "en".equals(lang) ? '.' : ',';
        StringBuilder g = new StringBuilder();
        for (int i = 0; i < ip.length(); i++) {
            if (i > 0 && (ip.length() - i) % 3 == 0) g.append(th);
            g.append(ip.charAt(i));
        }
        return (neg ? "-" : "") + g + (fp.isEmpty() ? "" : dec + fp);
    }

    /** «81 billones», «2,25 mil millones»… para números grandes. */
    static String magnitude(BigDecimal r, String lang) {
        BigDecimal a = r.abs();
        if (a.compareTo(BigDecimal.valueOf(1_000_000)) < 0) return "";
        String[][] es = {{"1e18", "trillón", "trillones"}, {"1e12", "billón", "billones"}, {"1e9", "mil millones", "mil millones"}, {"1e6", "millón", "millones"}};
        String[][] it = {{"1e18", "trilione", "trilioni"}, {"1e12", "bilione", "bilioni"}, {"1e9", "miliardo", "miliardi"}, {"1e6", "milione", "milioni"}};
        String[][] en = {{"1e18", "quintillion", "quintillion"}, {"1e15", "quadrillion", "quadrillion"}, {"1e12", "trillion", "trillion"}, {"1e9", "billion", "billion"}, {"1e6", "million", "million"}};
        String[][] t = "it".equals(lang) ? it : "en".equals(lang) ? en : es;
        for (String[] u : t) {
            BigDecimal unit = new BigDecimal(u[0]);
            if (a.compareTo(unit) >= 0) {
                BigDecimal q = r.divide(unit, MC);
                if (q.abs().compareTo(BigDecimal.valueOf(1_000_000)) >= 0) return "";
                BigDecimal sh = q.setScale(2, RoundingMode.HALF_UP).stripTrailingZeros();
                String n = format(sh, lang);
                boolean one = sh.abs().compareTo(BigDecimal.ONE) == 0;
                return n + " " + (one ? u[1] : u[2]);
            }
        }
        return "";
    }
}
