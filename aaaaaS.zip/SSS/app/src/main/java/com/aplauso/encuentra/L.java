package com.aplauso.encuentra;

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Idiomas de SSS+: español (original), inglés e italiano.
 * Los textos se escriben en español en el código y se traducen al mostrarse, con el diccionario de
 * assets/i18n.tsv (español · inglés · italiano). Si una frase lleva números u otras piezas, se traducen
 * los trozos conocidos que contiene.
 */
public class L {
    static final String[] CODES = {"es", "en", "it"};
    static final String[] NAMES = {"Español", "English", "Italiano"};

    static volatile String lang = "es";
    private static Context app;
    private static final Map<String, String[]> DICT = new HashMap<>();
    private static List<String> frags = new ArrayList<>();      // claves para trozos (en minúsculas, de más larga a más corta)
    private static final Map<String, String> LOWER = new HashMap<>();
    private static final Map<String, String> CACHE = new HashMap<>();
    private static boolean loaded;

    static synchronized void init(Context c) {
        if (app == null && c != null) app = c.getApplicationContext();
        if (app == null) return;
        String def = Locale.getDefault().getLanguage();
        if (!"en".equals(def) && !"it".equals(def)) def = "es";
        lang = app.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("lang", def);
        if (!"es".equals(lang)) load();
    }

    static synchronized void set(Context c, String code) {
        if (app == null && c != null) app = c.getApplicationContext();
        lang = code;
        if (app != null) app.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString("lang", code).apply();
        synchronized (CACHE) { CACHE.clear(); }
        if (!"es".equals(code)) load();
    }

    static int index() {
        for (int i = 0; i < CODES.length; i++) if (CODES[i].equals(lang)) return i;
        return 0;
    }

    private static void load() {
        if (loaded || app == null) return;
        try (InputStream in = app.getAssets().open("i18n.tsv")) {
            loadFrom(in);
            loaded = true;
        } catch (Exception ignored) {}
    }

    /** Lee el diccionario: una línea por frase, "español\tinglés\titaliano". */
    static void loadFrom(InputStream in) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        String line;
        List<String> keys = new ArrayList<>();
        while ((line = r.readLine()) != null) {
            if (line.isEmpty() || line.startsWith("#")) continue;
            String[] p = line.split("\t", -1);
            if (p.length < 3) continue;
            String es = unesc(p[0]);
            DICT.put(es, new String[]{es, unesc(p[1]), unesc(p[2])});
            String low = es.toLowerCase(Locale.ROOT);
            LOWER.put(low, es);
            if (es.length() >= 4 && hasLetter(es)) keys.add(low);
        }
        Collections.sort(keys, (a, b) -> b.length() - a.length());
        frags = keys;
    }

    static String unesc(String s) { return s.replace("\\n", "\n").replace("\\t", "\t"); }

    static boolean hasLetter(String s) {
        for (int i = 0; i < s.length(); i++) if (Character.isLetter(s.charAt(i))) return true;
        return false;
    }

    /** Traduce un texto al idioma elegido (el español se devuelve tal cual). */
    static String t(String s) {
        if (s == null || s.isEmpty() || "es".equals(lang) || DICT.isEmpty()) return s;
        String r;
        synchronized (CACHE) { r = CACHE.get(s); }
        if (r != null) return r;
        int li = index();
        String[] e = DICT.get(s);
        if (e == null) {
            String trimmed = s.trim();
            e = DICT.get(trimmed);
            if (e != null) r = s.replace(trimmed, pick(e, li));
        } else r = pick(e, li);
        if (r == null) r = pieces(s, li);
        synchronized (CACHE) {
            if (CACHE.size() > 4000) CACHE.clear();
            CACHE.put(s, r);
        }
        return r;
    }

    /** Traduce una lista de opciones (diálogos); devuelve una copia. */
    static String[] ta(String[] a) {
        if (a == null) return null;
        String[] r = new String[a.length];
        for (int i = 0; i < a.length; i++) r[i] = t(a[i]);
        return r;
    }

    static String pick(String[] e, int li) { return e[li] == null || e[li].isEmpty() ? e[0] : e[li]; }

    /** Traduce los trozos conocidos de una frase compuesta (respetando mayúsculas). */
    static String pieces(String s, int li) {
        String low = s.toLowerCase(Locale.ROOT);
        StringBuilder out = new StringBuilder();
        boolean[] used = new boolean[s.length()];
        String[] repl = new String[s.length()];
        int[] len = new int[s.length()];
        boolean any = false;
        for (String k : frags) {
            int from = 0;
            while (true) {
                int i = low.indexOf(k, from);
                if (i < 0) break;
                int end = i + k.length();
                from = i + 1;
                if (i > 0 && Character.isLetter(low.charAt(i - 1))) continue;
                if (end < low.length() && Character.isLetter(low.charAt(end))) continue;
                boolean free = true;
                for (int j = i; j < end; j++) if (used[j]) { free = false; break; }
                if (!free) continue;
                for (int j = i; j < end; j++) used[j] = true;
                String src = s.substring(i, end);
                String tr = pick(DICT.get(LOWER.get(k)), li);
                if (src.equals(src.toUpperCase(Locale.ROOT)) && !src.equals(src.toLowerCase(Locale.ROOT))) tr = tr.toUpperCase(Locale.ROOT);
                repl[i] = tr;
                len[i] = end - i;
                any = true;
            }
        }
        if (!any) return s;
        for (int i = 0; i < s.length(); ) {
            if (repl[i] != null) { out.append(repl[i]); i += len[i]; }
            else { out.append(s.charAt(i)); i++; }
        }
        return out.toString();
    }
}
