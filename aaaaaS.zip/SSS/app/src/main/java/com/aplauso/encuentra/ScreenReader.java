package com.aplauso.encuentra;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * v1.3: «ojos» de Chloe. Solo lee el texto de la pantalla cuando se lo pides (por ejemplo, tus asistencias de
 * HomeCareOSA) para decírtelo en voz alta. No guarda nada ni lo envía a ningún sitio.
 */
public class ScreenReader extends AccessibilityService {
    static volatile ScreenReader inst;

    @Override protected void onServiceConnected() { inst = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { if (inst == this) inst = null; super.onDestroy(); }

    static boolean on() { return inst != null; }

    /** Textos visibles de la app que está delante, en orden de pantalla. */
    static List<String> texts() {
        List<String> out = new ArrayList<>();
        ScreenReader s = inst;
        if (s == null) return out;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root != null) walk(root, out, 0);
        return out;
    }

    static String packageInFront() {
        ScreenReader s = inst;
        if (s == null) return "";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        return root == null || root.getPackageName() == null ? "" : root.getPackageName().toString();
    }

    /** Pulsa el primer botón cuyo texto o descripción coincida (por ejemplo «domani», «›», «siguiente»). */
    static boolean click(String regex) {
        ScreenReader s = inst;
        if (s == null) return false;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        return root != null && clickIn(root, java.util.regex.Pattern.compile(regex, java.util.regex.Pattern.CASE_INSENSITIVE), 0);
    }

    static boolean clickIn(AccessibilityNodeInfo n, java.util.regex.Pattern p, int depth) {
        if (n == null || depth > 40) return false;
        CharSequence t = n.getText(), d = n.getContentDescription(), id = n.getViewIdResourceName();
        String all = (t == null ? "" : t) + " " + (d == null ? "" : d) + " " + (id == null ? "" : id);
        if (p.matcher(all.trim()).find()) {
            AccessibilityNodeInfo c = n;
            while (c != null && !c.isClickable()) c = c.getParent();
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        }
        for (int i = 0; i < n.getChildCount(); i++) if (clickIn(n.getChild(i), p, depth + 1)) return true;
        return false;
    }

    /** Desliza desde el borde izquierdo (abre el menú lateral si no hay botón ☰ accesible). */
    static boolean swipeFromLeft() {
        ScreenReader s = inst;
        if (s == null || android.os.Build.VERSION.SDK_INT < 24) return false;
        android.util.DisplayMetrics dm = s.getResources().getDisplayMetrics();
        android.graphics.Path p = new android.graphics.Path();
        p.moveTo(4, dm.heightPixels / 2f);
        p.lineTo(dm.widthPixels * 0.7f, dm.heightPixels / 2f);
        android.accessibilityservice.GestureDescription g = new android.accessibilityservice.GestureDescription.Builder()
                .addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(p, 0, 300)).build();
        return s.dispatchGesture(g, null, null);
    }

    static void walk(AccessibilityNodeInfo n, List<String> out, int depth) {
        if (n == null || depth > 40) return;
        CharSequence t = n.getText();
        if (t == null || t.length() == 0) t = n.getContentDescription();
        if (t != null && t.length() > 0) for (String line : t.toString().split("\n")) if (!line.trim().isEmpty()) out.add(line.trim());
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), out, depth + 1);
    }
}
