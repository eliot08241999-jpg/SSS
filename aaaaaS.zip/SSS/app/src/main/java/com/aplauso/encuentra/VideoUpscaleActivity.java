package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/**
 * v1.5.2 · AMPLIAR VÍDEOS: de 360p/480p/720p a 720p, 1080p, 1440p o 4K con una red neuronal, dentro del teléfono.
 * Antes de empezar se puede PROBAR CON UN FOTOGRAMA (se ve el antes y el después, y cuánto va a tardar).
 */
public class VideoUpscaleActivity extends NeonActivity {
    static final int REQ_PICK = 95;
    static final int[] SIDES = {720, 1080, 1440, 2160};
    static final String[] SIDE_NAMES = {"720p", "1080p", "1440p", "4K"};

    Uri uri;
    String name = "";
    int vw, vh, side = 2160, model = 0;
    float fps = 30;
    long durMs;
    TextView info, est, status, startBtn;
    TextView[] sideBtns = new TextView[4], modelBtns = new TextView[2];
    LinearLayout opts, cmp;
    ImageView before, after;
    boolean testing;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen(L.t("🎬 AMPLIAR VÍDEOS"));

        LinearLayout a = panel("◢ VÍDEO");
        info = text("Elige un vídeo y lo paso a más resolución: hasta 4K.", 13);
        a.addView(info);
        a.addView(button("🎞 ELEGIR VÍDEO", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_PICK);
        }), sp(8));
        col.addView(a, gapBelow(12));

        opts = panel("◢ RESULTADO");
        opts.addView(text("Tamaño final:", 13));
        LinearLayout r = new LinearLayout(this);
        for (int i = 0; i < 4; i++) {
            final int k = i;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i < 3) lp.rightMargin = dpi(5);
            sideBtns[i] = button(SIDE_NAMES[i], v -> { side = SIDES[k]; marks(); });
            sideBtns[i].setTextSize(12);
            r.addView(sideBtns[i], lp);
        }
        opts.addView(r, sp(6));
        opts.addView(text("Manera:", 13), sp(10));
        LinearLayout r2 = new LinearLayout(this);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1); l1.rightMargin = dpi(6);
        modelBtns[0] = button("⚡ RÁPIDA", v -> { model = 0; marks(); });
        modelBtns[1] = button("🔬 DETALLADA", v -> { model = 1; marks(); });
        modelBtns[0].setTextSize(12); modelBtns[1].setTextSize(12);
        r2.addView(modelBtns[0], l1);
        r2.addView(modelBtns[1], new LinearLayout.LayoutParams(0, -2, 1));
        opts.addView(r2, sp(6));
        opts.addView(text("Rápida: pensada para vídeo (dibujos, anime y también grabaciones normales). Detallada: más textura en vídeos reales, pero tarda el doble.", 11), sp(6));
        est = text("", 13);
        est.setTextColor(Color.rgb(255, 210, 120));
        opts.addView(est, sp(10));
        opts.addView(button("👁 PROBAR CON UN FOTOGRAMA", v -> test()), sp(8));
        cmp = new LinearLayout(this);
        cmp.setOrientation(LinearLayout.VERTICAL);
        TextView tb = text("ANTES (estirado)", 11);
        cmp.addView(tb);
        before = new ImageView(this);
        before.setAdjustViewBounds(true);
        cmp.addView(before, new LinearLayout.LayoutParams(-1, -2));
        cmp.addView(text("DESPUÉS (con IA)", 11), sp(6));
        after = new ImageView(this);
        after.setAdjustViewBounds(true);
        cmp.addView(after, new LinearLayout.LayoutParams(-1, -2));
        cmp.setVisibility(View.GONE);
        opts.addView(cmp, sp(8));
        startBtn = button("▶ AMPLIAR EL VÍDEO", v -> go());
        opts.addView(startBtn, sp(10));
        opts.addView(text("Va en segundo plano, también con la pantalla apagada (mejor con el móvil cargando). El vídeo original no se toca: "
                + "el nuevo se guarda aparte, con el sonido.", 11), sp(6));
        opts.setVisibility(View.GONE);
        col.addView(opts, gapBelow(12));

        LinearLayout st = panel("◢ PROGRESO");
        status = text("", 13);
        st.addView(status);
        st.addView(button("✕ CANCELAR", v -> { VideoSR.cancel = true; toast(L.t("Cancelando…")); }), sp(8));
        st.addView(button("▶ VER EL VÍDEO NUEVO", v -> {
            if (VideoSR.result == null) { toast(L.t("Todavía no hay vídeo nuevo.")); return; }
            try { startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(VideoSR.result, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)); }
            catch (Exception e) { toast(L.t("Está en tus vídeos (SSS+).")); }
        }), sp(8));
        col.addView(st, gapBelow(12));

        TextView note = text("Cómo funciona: una red neuronal (Real-ESRGAN, libre) reconstruye bordes y texturas en cada fotograma. "
                + "No puede inventar lo que el vídeo nunca grabó: un 360p no se vuelve un 4K de cámara, pero se ve mucho más nítido que estirado.", 11);
        note.setTextColor(Color.rgb(140, 150, 170));
        col.addView(note, gapBelow(12));

        if (getIntent().getData() != null) open(getIntent().getData());
        h.post(tick);
    }

    LinearLayout.LayoutParams sp(int dp) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dpi(dp); return lp; }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) {
            try { getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            open(data.getData());
        }
    }

    void open(Uri u) {
        uri = u;
        name = Media.nameOf(this, u);
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(this, u, null);
            vw = 0;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m == null || !m.startsWith("video/")) continue;
                vw = f.getInteger(MediaFormat.KEY_WIDTH);
                vh = f.getInteger(MediaFormat.KEY_HEIGHT);
                try { fps = f.containsKey(MediaFormat.KEY_FRAME_RATE) ? f.getInteger(MediaFormat.KEY_FRAME_RATE) : 30; }
                catch (ClassCastException e) { fps = f.getFloat(MediaFormat.KEY_FRAME_RATE); }
                if (fps < 1 || fps > 240) fps = 30;
                durMs = f.containsKey(MediaFormat.KEY_DURATION) ? f.getLong(MediaFormat.KEY_DURATION) / 1000 : MediaTools.durationMs(this, u);
                break;
            }
        } catch (Exception e) { vw = 0; } finally { ex.release(); }
        if (vw <= 0) { info.setText(L.t("No puedo leer ese vídeo.")); opts.setVisibility(View.GONE); return; }
        int ss = Math.min(vw, vh);
        info.setText(name + "\n" + vw + " × " + vh + " (" + ss + "p) · " + fmtDur(durMs / 1000) + " · " + Math.round(fps) + " fps");
        // el primer tamaño que de verdad es más grande
        side = 2160;
        for (int s : SIDES) if (s > ss * 1.2f) { side = Math.max(s, Math.min(2160, ss * 3)); break; }
        side = closest(side);
        cmp.setVisibility(View.GONE);
        lastFrameSec = 0;
        opts.setVisibility(View.VISIBLE);
        marks();
    }

    static int closest(int v) { int best = SIDES[0]; for (int s : SIDES) if (Math.abs(s - v) < Math.abs(best - v)) best = s; return best; }

    float lastFrameSec;        // lo que tardó el fotograma de prueba
    int lastFrameSide = -1, lastFrameModel = -1;

    void marks() {
        int ss = Math.min(vw, vh);
        for (int i = 0; i < 4; i++) {
            boolean ok = SIDES[i] > ss * 1.2f;
            sideBtns[i].setAlpha(!ok ? 0.25f : SIDES[i] == side ? 1f : 0.5f);
            sideBtns[i].setEnabled(ok);
        }
        for (int i = 0; i < 2; i++) modelBtns[i].setAlpha(model == i ? 1f : 0.5f);
        long frames = (long) (durMs / 1000f * fps);
        int[] tg = SrCore.target(vw, vh, side);
        String t = L.t("Saldrá de") + " " + tg[0] + " × " + tg[1] + " · " + frames + " " + L.t("fotogramas");
        if (lastFrameSec > 0 && lastFrameSide == side && lastFrameModel == model) {
            long sec = (long) (frames * lastFrameSec * 1.08f);
            t += "\n" + L.t("Tardará más o menos") + " " + fmtDur(sec) + ".";
        } else t += "\n" + L.t("Pulsa PROBAR para saber cuánto tardará en tu teléfono.");
        if (side >= 2160 && ss <= 480) t += "\n" + L.t("De tan poco a 4K: se ve más nítido, pero un 1440p ya da casi lo mismo y tarda menos.");
        est.setText(t);
    }

    static String fmtDur(long s) {
        if (s >= 3600) return s / 3600 + " h " + (s % 3600) / 60 + " min";
        if (s >= 60) return s / 60 + " min " + (s % 60 > 0 ? s % 60 + " s" : "");
        return s + " s";
    }

    void test() {
        if (uri == null || testing) return;
        if (VideoSR.running) { toast(L.t("Espera a que termine el vídeo que se está ampliando.")); return; }
        testing = true;
        est.setText(L.t("Probando con un fotograma…"));
        final int sd = side, md = model;
        new Thread(() -> {
            String err = null;
            Bitmap fb = null, fa = null;
            float sec = 0;
            MediaMetadataRetriever mr = new MediaMetadataRetriever();
            try {
                mr.setDataSource(this, uri);
                Bitmap f = mr.getFrameAtTime(durMs * 500, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if (f == null) throw new Exception(L.t("No pude sacar un fotograma."));
                // del tamaño real del vídeo (girado si hace falta)
                boolean rot = (f.getWidth() > f.getHeight()) != (vw > vh);
                int fw = rot ? vh : vw, fh = rot ? vw : vh;
                if (f.getWidth() != fw || f.getHeight() != fh) f = Bitmap.createScaledBitmap(f, fw, fh, true);
                if (f.getConfig() != Bitmap.Config.ARGB_8888) f = f.copy(Bitmap.Config.ARGB_8888, false);
                int[] tg = SrCore.target(fw, fh, sd);
                VideoSR.session(this, md);                                    // cargar la red no cuenta en el tiempo
                long t0 = SystemClock.elapsedRealtime();
                Bitmap big = VideoSR.upscaleBitmap(this, f, tg[0], tg[1], md);
                sec = (SystemClock.elapsedRealtime() - t0) / 1000f + 0.04f * tg[0] * tg[1] / 8.3e6f;   // + pasar a vídeo
                Bitmap stretch = Bitmap.createScaledBitmap(f, tg[0], tg[1], true);
                // un recorte del centro, a tamaño real, para ver la diferencia
                int cw = Math.min(tg[0], 640), ch = Math.min(tg[1], 480);
                int cx = (tg[0] - cw) / 2, cy = Math.max(0, (tg[1] - ch) / 3);
                fb = Bitmap.createBitmap(stretch, cx, cy, cw, ch);
                fa = Bitmap.createBitmap(big, cx, cy, cw, ch);
            } catch (Throwable e) {
                err = e.getMessage() == null ? e.toString() : e.getMessage();
            } finally {
                try { mr.release(); } catch (Exception ignored) {}
                VideoSR.release();
            }
            String fe = err;
            Bitmap b1 = fb, b2 = fa;
            float fs = sec;
            runOnUiThread(() -> {
                testing = false;
                if (fe != null) { est.setText(L.t("No se pudo probar: ") + fe); return; }
                lastFrameSec = fs; lastFrameSide = sd; lastFrameModel = md;
                before.setImageBitmap(b1);
                after.setImageBitmap(b2);
                cmp.setVisibility(View.VISIBLE);
                marks();
                est.append("\n" + String.format(Locale.ROOT, L.t("Un fotograma: %.1f s."), fs));
            });
        }, "probar-fotograma").start();
    }

    void go() {
        if (uri == null) return;
        if (VideoSR.running) { toast(L.t("Ya hay un vídeo ampliándose.")); return; }
        if (Math.min(vw, vh) * 1.2f >= side) { toast(L.t("El vídeo ya tiene ese tamaño o más.")); return; }
        VideoSR.start(this, uri, side, model, name);
        toast(L.t("¡Empezado! Puedes salir: te aviso con una notificación."));
    }

    final Runnable tick = new Runnable() {
        public void run() {
            if (isFinishing()) return;
            if (VideoSR.running) {
                status.setText(VideoSR.srcName + "\n" + VideoSR.progressText() + " (" + (VideoSR.done * 100 / Math.max(1, VideoSR.total)) + " %)");
                startBtn.setEnabled(false);
                startBtn.setAlpha(0.4f);
            } else {
                status.setText(VideoSR.status.isEmpty() ? L.t("Nada en marcha.") : VideoSR.srcName + "\n" + VideoSR.status);
                startBtn.setEnabled(true);
                startBtn.setAlpha(1f);
            }
            h.postDelayed(this, 1000);
        }
    };

    @Override protected void onDestroy() { h.removeCallbacks(tick); super.onDestroy(); }
}
