package com.aplauso.encuentra;

import java.util.Random;

/**
 * v1.4.6 · Decoración de fondo según la estación (la misma que su traje):
 * otoño = hojas que caen dando vueltas, invierno = nieve, primavera = pétalos de cerezo con brisa,
 * verano = luciérnagas y destellos que suben. Unas pocas pasan por delante (más grandes y desenfocadas).
 */
public class Deco {
    static final int N = 34;
    final Random rnd = new Random();
    final float[] x = new float[N], y = new float[N], vx = new float[N], vy = new float[N], rot = new float[N], vr = new float[N],
            size = new float[N], ph = new float[N];
    final int[] col = new int[N];
    final boolean[] front = new boolean[N];
    String season = "";
    float t;

    void reset(String s) {
        season = s;
        for (int i = 0; i < N; i++) spawn(i, true);
    }

    void spawn(int i, boolean anywhere) {
        front[i] = rnd.nextFloat() < 0.15f;
        float k = front[i] ? 1.7f : 0.7f + rnd.nextFloat() * 0.6f;
        x[i] = rnd.nextFloat();
        ph[i] = rnd.nextFloat() * 6.28f;
        rot[i] = rnd.nextFloat() * 360;
        switch (season) {
            case "winter":
                y[i] = anywhere ? rnd.nextFloat() : -0.05f;
                vx[i] = (rnd.nextFloat() - 0.5f) * 0.02f; vy[i] = (0.025f + rnd.nextFloat() * 0.03f) * k;
                vr[i] = (rnd.nextFloat() - 0.5f) * 40; size[i] = (1.5f + rnd.nextFloat() * 2.2f) * k;
                col[i] = 0xFFFFFFFF; break;
            case "spring":
                y[i] = anywhere ? rnd.nextFloat() : -0.05f;
                x[i] = anywhere ? x[i] : rnd.nextFloat() * 0.8f - 0.2f;
                vx[i] = (0.02f + rnd.nextFloat() * 0.03f) * k; vy[i] = (0.03f + rnd.nextFloat() * 0.03f) * k;
                vr[i] = (rnd.nextFloat() - 0.5f) * 160; size[i] = (3.2f + rnd.nextFloat() * 2f) * k;
                col[i] = rnd.nextBoolean() ? 0xFFFFC4DA : 0xFFFFDDE9; break;
            case "summer":
                y[i] = anywhere ? rnd.nextFloat() : 1.05f;
                vx[i] = (rnd.nextFloat() - 0.5f) * 0.02f; vy[i] = -(0.012f + rnd.nextFloat() * 0.02f) * k;
                vr[i] = 0; size[i] = (1.4f + rnd.nextFloat() * 1.5f) * (front[i] ? 1.2f : k);
                col[i] = rnd.nextFloat() < 0.7f ? 0xFFFFE27A : 0xFFFFFFFF; break;
            default:                                    // otoño
                y[i] = anywhere ? rnd.nextFloat() : -0.06f;
                vx[i] = (rnd.nextFloat() - 0.5f) * 0.03f; vy[i] = (0.03f + rnd.nextFloat() * 0.03f) * k;
                vr[i] = (rnd.nextFloat() - 0.5f) * 200; size[i] = (4.5f + rnd.nextFloat() * 2.5f) * k;
                int[] c = {0xFFE0662C, 0xFFC9452B, 0xFFF0A23A, 0xFFB5602A, 0xFFE8C04A};
                col[i] = c[rnd.nextInt(c.length)];
        }
    }

    void step(String s, float dt) {
        if (!s.equals(season)) reset(s);
        t += dt;
        for (int i = 0; i < N; i++) {
            float sway = (float) Math.sin(t * (season.equals("winter") ? 0.9f : 1.6f) + ph[i]);
            x[i] += (vx[i] + sway * (season.equals("summer") ? 0.012f : 0.02f)) * dt;
            y[i] += vy[i] * dt;
            rot[i] += vr[i] * dt * (0.6f + 0.4f * sway);
            if (y[i] > 1.08f || y[i] < -0.1f || x[i] < -0.15f || x[i] > 1.15f) spawn(i, false);
        }
    }

    /** Dibuja en un lienzo de w × h (las de delante o las de detrás). */
    void draw(AvatarArt.C c, float w, float h, boolean front) {
        float u = Math.min(w, h) / 200f;               // escala de los dibujitos
        if (!front && season.equals("summer")) {        // un sol suave arriba
            c.color(0x22FFE9A0); c.oval(w * 0.86f, h * 0.08f, 70 * u, 70 * u);
            c.color(0x18FFE9A0); c.oval(w * 0.86f, h * 0.08f, 44 * u, 44 * u);
        }
        for (int i = 0; i < N; i++) {
            if (this.front[i] != front) continue;
            float px = x[i] * w, py = y[i] * h, s = size[i] * u;
            int cl = col[i];
            if (front) cl = AvatarArt.a(cl, 0.55f);
            c.save();
            c.rotate(rot[i], px, py);
            switch (season) {
                case "winter":
                    c.color(AvatarArt.a(cl, front ? 0.45f : 0.85f)); c.oval(px, py, s, s);
                    if (s > 2.6f * u) { c.color(AvatarArt.a(0xFFFFFFFF, 0.5f)); for (int k = 0; k < 3; k++) { c.begin(); c.moveTo(px - s * 1.6f, py); c.lineTo(px + s * 1.6f, py); c.stroke(0.6f * u); c.rotate(60, px, py); } }
                    break;
                case "spring":                              // pétalo de cerezo con muesca
                    c.color(cl);
                    c.begin(); c.moveTo(px, py + s); c.cubicTo(px - s * 1.1f, py + s * 0.2f, px - s * 0.7f, py - s, px - s * 0.15f, py - s * 0.8f);
                    c.lineTo(px, py - s * 0.45f); c.lineTo(px + s * 0.15f, py - s * 0.8f);
                    c.cubicTo(px + s * 0.7f, py - s, px + s * 1.1f, py + s * 0.2f, px, py + s); c.close(); c.fill();
                    c.color(AvatarArt.a(0xFFFF8FB4, 0.5f)); c.begin(); c.moveTo(px, py + s * 0.8f); c.lineTo(px, py - s * 0.2f); c.stroke(0.5f * u);
                    break;
                case "summer": {
                    float gl = 0.5f + 0.5f * (float) Math.sin(t * 3 + ph[i] * 3);
                    c.color(AvatarArt.a(cl, (front ? 0.07f : 0.16f) * gl)); c.oval(px, py, s * 2.6f, s * 2.6f);
                    c.color(AvatarArt.a(cl, 0.35f + 0.6f * gl)); c.oval(px, py, s, s);
                    break;
                }
                default: {                                  // hoja de arce sencilla
                    c.color(cl);
                    c.begin();
                    c.moveTo(px, py - s * 1.2f);
                    c.lineTo(px + s * 0.35f, py - s * 0.5f); c.lineTo(px + s * 1.1f, py - s * 0.7f); c.lineTo(px + s * 0.7f, py - s * 0.05f);
                    c.lineTo(px + s * 1.0f, py + s * 0.25f); c.lineTo(px + s * 0.3f, py + s * 0.35f); c.lineTo(px + s * 0.2f, py + s * 0.8f);
                    c.lineTo(px, py + s * 0.55f);
                    c.lineTo(px - s * 0.2f, py + s * 0.8f); c.lineTo(px - s * 0.3f, py + s * 0.35f); c.lineTo(px - s * 1.0f, py + s * 0.25f);
                    c.lineTo(px - s * 0.7f, py - s * 0.05f); c.lineTo(px - s * 1.1f, py - s * 0.7f); c.lineTo(px - s * 0.35f, py - s * 0.5f);
                    c.close(); c.fill();
                    c.color(AvatarArt.a(0xFF5A2A12, 0.55f)); c.begin(); c.moveTo(px, py - s * 0.9f); c.lineTo(px, py + s * 1.3f); c.stroke(0.5f * u);
                }
            }
            c.restore();
        }
    }
}
