package com.aplauso.encuentra;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Modelo editable para el editor 3D: vértices con UV, partes con material/textura, esqueleto y pesos.
 * Lee GLB / glTF / VRM (0.x y 1.0) con huesos y texturas; STL, OBJ y FBX solo la forma (vía Mesh3D).
 * Escribe GLB con esqueleto, pesos y texturas, y VRM 0.x (GLB + datos de avatar humanoide).
 * Todo en Java puro (sin Android) para poder probarlo fuera del teléfono.
 */
public class Model3D {
    // ---------- malla ----------
    float[] pos = new float[0];   // reposo, 3 por vértice (espacio del modelo)
    float[] uv;                   // 2 por vértice (o null)
    int[] idx = new int[0];       // triángulos
    int[] triPart = new int[0];   // parte de cada triángulo
    int nv;

    static class Part {
        String name = "parte";
        int tex = -1;               // textura (o -1)
        int color = 0xFFDDDDDD;     // color base ARGB
    }

    static class Tex {
        byte[] data;                // PNG o JPG tal cual
        String mime = "image/png";
        String name = "textura";
    }

    final List<Part> parts = new ArrayList<>();
    final List<Tex> textures = new ArrayList<>();

    // ---------- esqueleto ----------
    static class Bone {
        String name;
        int parent = -1;
        float[] rest = Mat4.identity();   // matriz de mundo en reposo (por filas)
        float[] pose = Mat4.identity();   // giro local de la pose de prueba (solo rotación)

        float hx() { return rest[3]; }
        float hy() { return rest[7]; }
        float hz() { return rest[11]; }
    }

    final List<Bone> bones = new ArrayList<>();
    int[] jIdx;      // 4 huesos por vértice
    float[] jW;      // 4 pesos por vértice
    final Map<String, Integer> human = new HashMap<>();   // hueso humanoide VRM → índice de hueso
    String title = "modelo", author = "";

    int tris() { return idx.length / 3; }

    // =====================================================================
    // Cargar
    // =====================================================================
    static Model3D load(byte[] data, String name) throws IOException {
        String n = name.toLowerCase(Locale.ROOT);
        Model3D m;
        if (n.endsWith(".glb") || n.endsWith(".vrm") || n.endsWith(".gltf")) m = GltfIn.read(data);
        else m = fromSoup(Mesh3D.loadRaw(data, name, true));
        int dot = name.lastIndexOf('.');
        if (m.title == null || m.title.isEmpty() || m.title.equals("modelo")) m.title = dot > 0 ? name.substring(0, dot) : name;
        if (m.tris() == 0) throw new IOException("El modelo no tiene triángulos");
        return m;
    }

    /** Convierte triángulos sueltos en malla con vértices compartidos. */
    static Model3D fromSoup(Mesh3D s) {
        Model3D m = new Model3D();
        Mesh3D.Indexed ix = s.indexed();
        m.pos = ix.pos;
        m.nv = ix.nv;
        m.idx = ix.idx;
        m.triPart = new int[m.idx.length / 3];
        m.parts.add(new Part());
        return m;
    }

    // =====================================================================
    // Medidas
    // =====================================================================
    float[] bounds() {
        float[] b = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        for (int i = 0; i < nv; i++)
            for (int k = 0; k < 3; k++) { b[k] = Math.min(b[k], pos[i * 3 + k]); b[k + 3] = Math.max(b[k + 3], pos[i * 3 + k]); }
        if (nv == 0) return new float[]{0, 0, 0, 1, 1, 1};
        return b;
    }

    int childCount(int b) {
        int n = 0;
        for (Bone x : bones) if (x.parent == b) n++;
        return n;
    }

    int boneByName(String n) {
        for (int i = 0; i < bones.size(); i++) if (bones.get(i).name.equals(n)) return i;
        return -1;
    }

    // =====================================================================
    // Pose y deformación (en la CPU)
    // =====================================================================
    /** Matrices de mundo con la pose de prueba aplicada. */
    float[][] poseWorld() {
        int n = bones.size();
        float[][] w = new float[n][];
        for (int i = 0; i < n; i++) world(i, w);
        return w;
    }

    private float[] world(int i, float[][] w) {
        if (w[i] != null) return w[i];
        Bone b = bones.get(i);
        float[] parentRest = b.parent >= 0 ? bones.get(b.parent).rest : Mat4.identity();
        float[] parentPose = b.parent >= 0 ? world(b.parent, w) : Mat4.identity();
        float[] local = Mat4.mul(Mat4.invert(parentRest), b.rest);
        w[i] = Mat4.mul(parentPose, Mat4.mul(local, b.pose));
        return w[i];
    }

    boolean posed() {
        for (Bone b : bones) if (!Mat4.isIdentity(b.pose)) return true;
        return false;
    }

    /** Posiciones deformadas por la pose (o las de reposo si no hay pose). */
    float[] skinned() {
        if (bones.isEmpty() || jIdx == null || !posed()) return pos;
        float[][] w = poseWorld();
        float[][] sk = new float[bones.size()][];
        for (int i = 0; i < sk.length; i++) sk[i] = Mat4.mul(w[i], Mat4.invert(bones.get(i).rest));
        float[] out = new float[nv * 3];
        for (int v = 0; v < nv; v++) {
            float x = pos[v * 3], y = pos[v * 3 + 1], z = pos[v * 3 + 2], ox = 0, oy = 0, oz = 0, tw = 0;
            for (int k = 0; k < 4; k++) {
                float wt = jW[v * 4 + k];
                if (wt <= 0) continue;
                float[] m = sk[jIdx[v * 4 + k]];
                ox += wt * (m[0] * x + m[1] * y + m[2] * z + m[3]);
                oy += wt * (m[4] * x + m[5] * y + m[6] * z + m[7]);
                oz += wt * (m[8] * x + m[9] * y + m[10] * z + m[11]);
                tw += wt;
            }
            if (tw <= 0) { ox = x; oy = y; oz = z; } else if (tw < 0.999f) { ox += x * (1 - tw); oy += y * (1 - tw); oz += z * (1 - tw); }
            out[v * 3] = ox; out[v * 3 + 1] = oy; out[v * 3 + 2] = oz;
        }
        return out;
    }

    void resetPose() { for (Bone b : bones) b.pose = Mat4.identity(); }

    /** Gira el hueso b un ángulo (radianes) alrededor de un eje dado en espacio del mundo. */
    void rotateBone(int b, float ax, float ay, float az, float angle) {
        float[][] w = poseWorld();
        Bone bone = bones.get(b);
        float[] parentRest = bone.parent >= 0 ? bones.get(bone.parent).rest : Mat4.identity();
        float[] parentPose = bone.parent >= 0 ? w[bone.parent] : Mat4.identity();
        float[] frame = Mat4.rotOnly(Mat4.mul(parentPose, Mat4.mul(Mat4.invert(parentRest), bone.rest)));
        float[] d = Mat4.axisAngle(ax, ay, az, angle);
        // nueva pose local = frame⁻¹ · giro · frame · pose
        bone.pose = Mat4.rotOnly(Mat4.mul(Mat4.transpose(frame), Mat4.mul(d, Mat4.mul(frame, bone.pose))));
    }

    // =====================================================================
    // Editar huesos
    // =====================================================================
    int addBone(String name, int parent, float x, float y, float z) {
        Bone b = new Bone();
        b.name = uniqueName(name);
        b.parent = parent;
        b.rest = Mat4.translate(x, y, z);
        if (parent >= 0) {           // hereda el giro de reposo del padre
            float[] pr = Mat4.rotOnly(bones.get(parent).rest);
            pr[3] = x; pr[7] = y; pr[11] = z;
            b.rest = pr;
        }
        bones.add(b);
        ensureWeights();
        return bones.size() - 1;
    }

    String uniqueName(String n) {
        String base = n == null || n.trim().isEmpty() ? "hueso" : n.trim();
        if (boneByName(base) < 0) return base;
        for (int i = 2; ; i++) if (boneByName(base + "." + i) < 0) return base + "." + i;
    }

    /** Mueve la cabeza del hueso (posición de reposo); los hijos no se mueven. */
    void moveBone(int b, float x, float y, float z) {
        float[] r = bones.get(b).rest;
        r[3] = x; r[7] = y; r[11] = z;
    }

    /** Borra un hueso: sus hijos pasan a su padre y sus pesos también. */
    void deleteBone(int b) {
        Bone dead = bones.get(b);
        for (Bone x : bones) if (x.parent == b) x.parent = dead.parent;
        if (jIdx != null) {
            for (int v = 0; v < nv; v++) {
                for (int k = 0; k < 4; k++) {
                    int j = jIdx[v * 4 + k];
                    if (j == b) {
                        if (dead.parent >= 0) jIdx[v * 4 + k] = dead.parent;
                        else jW[v * 4 + k] = 0;
                    }
                }
                mergeDup(v);
            }
            for (int i = 0; i < jIdx.length; i++) if (jIdx[i] > b) jIdx[i]--;
        }
        for (Bone x : bones) if (x.parent > b) x.parent--;
        bones.remove(b);
        Map<String, Integer> nh = new HashMap<>();
        for (Map.Entry<String, Integer> e : human.entrySet()) {
            int i = e.getValue();
            if (i == b) continue;
            nh.put(e.getKey(), i > b ? i - 1 : i);
        }
        human.clear();
        human.putAll(nh);
        normalizeAll();
    }

    /** ¿Ponerle este padre crearía un bucle? */
    boolean wouldLoop(int b, int newParent) {
        for (int p = newParent; p >= 0; p = bones.get(p).parent) if (p == b) return true;
        return false;
    }

    private void mergeDup(int v) {
        for (int a = 0; a < 4; a++)
            for (int c = a + 1; c < 4; c++)
                if (jW[v * 4 + a] > 0 && jW[v * 4 + c] > 0 && jIdx[v * 4 + a] == jIdx[v * 4 + c]) {
                    jW[v * 4 + a] += jW[v * 4 + c];
                    jW[v * 4 + c] = 0;
                }
    }

    void ensureWeights() {
        if (jIdx == null || jIdx.length != nv * 4) { jIdx = new int[nv * 4]; jW = new float[nv * 4]; }
    }

    void normalizeAll() {
        if (jW == null) return;
        for (int v = 0; v < nv; v++) {
            float t = 0;
            for (int k = 0; k < 4; k++) t += jW[v * 4 + k];
            if (t > 0) for (int k = 0; k < 4; k++) jW[v * 4 + k] /= t;
        }
    }

    /** Peso del hueso b en el vértice v. */
    float weight(int v, int b) {
        if (jIdx == null) return 0;
        float w = 0;
        for (int k = 0; k < 4; k++) if (jIdx[v * 4 + k] == b) w += jW[v * 4 + k];
        return w;
    }

    /** Suma (o resta) influencia del hueso b en el vértice v y renormaliza. */
    void paintWeight(int v, int b, float amount) {
        ensureWeights();
        int slot = -1;
        for (int k = 0; k < 4; k++) if (jIdx[v * 4 + k] == b && jW[v * 4 + k] > 0) slot = k;
        if (slot < 0 && amount > 0) {        // ocupa el hueco más flojo
            float min = Float.MAX_VALUE;
            for (int k = 0; k < 4; k++) if (jW[v * 4 + k] < min) { min = jW[v * 4 + k]; slot = k; }
            jIdx[v * 4 + slot] = b;
            jW[v * 4 + slot] = 0;
        }
        if (slot < 0) return;
        float old = jW[v * 4 + slot];
        float nw = Math.max(0, Math.min(1, old + amount));
        float others = 0;
        for (int k = 0; k < 4; k++) if (k != slot) others += jW[v * 4 + k];
        jW[v * 4 + slot] = nw;
        float rest = 1 - nw;
        if (others > 0) {
            for (int k = 0; k < 4; k++) if (k != slot) jW[v * 4 + k] = jW[v * 4 + k] / others * rest;
        } else {
            // era el único hueso: lo que se quita pasa a su padre (o se queda si no tiene)
            int par = b >= 0 && b < bones.size() ? bones.get(b).parent : -1;
            if (par < 0 || amount > 0) { jW[v * 4 + slot] = 1; return; }
            int free = slot == 0 ? 1 : 0;
            jIdx[v * 4 + free] = par;
            jW[v * 4 + free] = rest;
        }
    }

    // =====================================================================
    // Pesos automáticos: cada vértice se reparte entre los huesos más cercanos
    // =====================================================================
    void autoWeights() {
        ensureWeights();
        int nb = bones.size();
        if (nb == 0) return;
        // segmento de cada hueso: de su cabeza a la media de sus hijos (o un trocito siguiendo al padre)
        float[][] seg = new float[nb][6];
        float[] bb = bounds();
        float size = Math.max(bb[3] - bb[0], Math.max(bb[4] - bb[1], bb[5] - bb[2]));
        for (int i = 0; i < nb; i++) {
            Bone b = bones.get(i);
            float tx = 0, ty = 0, tz = 0;
            int kids = 0;
            for (Bone c : bones) if (c.parent == i) { tx += c.hx(); ty += c.hy(); tz += c.hz(); kids++; }
            if (kids > 0) { tx /= kids; ty /= kids; tz /= kids; }
            else if (b.parent >= 0) {
                Bone p = bones.get(b.parent);
                float dx = b.hx() - p.hx(), dy = b.hy() - p.hy(), dz = b.hz() - p.hz();
                float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                float l = Math.min(len * 0.6f, size * 0.12f);
                if (len > 1e-6f) { tx = b.hx() + dx / len * l; ty = b.hy() + dy / len * l; tz = b.hz() + dz / len * l; }
                else { tx = b.hx(); ty = b.hy() + size * 0.05f; tz = b.hz(); }
            } else { tx = b.hx(); ty = b.hy() + size * 0.05f; tz = b.hz(); }
            seg[i] = new float[]{b.hx(), b.hy(), b.hz(), tx, ty, tz};
        }
        // las puntas ("...End", sin hijos) solo marcan dónde acaba el hueso padre: no reciben peso
        boolean[] tip = new boolean[nb];
        int usable = 0;
        for (int i = 0; i < nb; i++) {
            tip[i] = bones.get(i).name.endsWith("End") && childCount(i) == 0 && bones.get(i).parent >= 0;
            if (!tip[i]) usable++;
        }
        if (usable == 0) java.util.Arrays.fill(tip, false);
        float[] d = new float[nb];
        Integer[] order = new Integer[nb];
        float eps = size * 0.002f + 1e-6f;
        for (int v = 0; v < nv; v++) {
            float x = pos[v * 3], y = pos[v * 3 + 1], z = pos[v * 3 + 2];
            for (int i = 0; i < nb; i++) { d[i] = tip[i] ? Float.MAX_VALUE : segDist(x, y, z, seg[i]); order[i] = i; }
            final float[] dd = d;
            java.util.Arrays.sort(order, (a, b) -> Float.compare(dd[a], dd[b]));
            float t = 0;
            int use = Math.min(4, usable == 0 ? nb : usable);
            float near = d[order[0]];
            for (int k = 0; k < 4; k++) {
                if (k < use) {
                    int b = order[k];
                    // solo huesos casi tan cercanos como el más cercano (evita que un brazo arrastre la cadera)
                    float w = d[b] <= near * 1.8f + eps ? 1f / (float) Math.pow(d[b] + eps, 4) : 0;
                    jIdx[v * 4 + k] = b;
                    jW[v * 4 + k] = w;
                    t += w;
                } else { jIdx[v * 4 + k] = 0; jW[v * 4 + k] = 0; }
            }
            if (t > 0) for (int k = 0; k < 4; k++) jW[v * 4 + k] /= t;
        }
    }

    static float segDist(float x, float y, float z, float[] s) {
        float ax = s[0], ay = s[1], az = s[2], bx = s[3] - ax, by = s[4] - ay, bz = s[5] - az;
        float l2 = bx * bx + by * by + bz * bz;
        float t = l2 > 0 ? ((x - ax) * bx + (y - ay) * by + (z - az) * bz) / l2 : 0;
        t = Math.max(0, Math.min(1, t));
        float px = ax + bx * t - x, py = ay + by * t - y, pz = az + bz * t - z;
        return (float) Math.sqrt(px * px + py * py + pz * pz);
    }

    // =====================================================================
    // Esqueleto humanoide (nombres de VRM) colocado según el tamaño del modelo
    // =====================================================================
    static final String[] HUMAN_REQUIRED = {"hips", "spine", "chest", "neck", "head",
            "leftUpperArm", "leftLowerArm", "leftHand", "rightUpperArm", "rightLowerArm", "rightHand",
            "leftUpperLeg", "leftLowerLeg", "leftFoot", "rightUpperLeg", "rightLowerLeg", "rightFoot"};

    /**
     * Crea un esqueleto humanoide para un personaje de pie mirando hacia +Z (como en glTF / VRM 1.0).
     * Si los brazos están abiertos (pose en T) los coloca en horizontal; si no, caídos.
     * @param leftIsPlusX true: la izquierda del personaje es +X
     */
    void humanoidTemplate(boolean leftIsPlusX) {
        bones.clear();
        human.clear();
        float[] b = bounds();
        float h = b[4] - b[1], y0 = b[1], cx = (b[0] + b[3]) / 2, cz = (b[2] + b[5]) / 2;
        float halfW = (b[3] - b[0]) / 2;
        boolean tpose = halfW > h * 0.32f;
        float L = leftIsPlusX ? 1 : -1;
        int hips = hb("hips", -1, cx, y0 + h * 0.53f, cz);
        int spine = hb("spine", hips, cx, y0 + h * 0.60f, cz);
        int chest = hb("chest", spine, cx, y0 + h * 0.69f, cz);
        int upper = hb("upperChest", chest, cx, y0 + h * 0.75f, cz);
        int neck = hb("neck", upper, cx, y0 + h * 0.83f, cz);
        int head = hb("head", neck, cx, y0 + h * 0.87f, cz);
        hb("headEnd", head, cx, y0 + h * 0.99f, cz);
        for (int s = 0; s < 2; s++) {
            float sg = s == 0 ? L : -L;
            String side = s == 0 ? "left" : "right";
            float shy = y0 + h * 0.80f;
            int sh = hb(side + "Shoulder", upper, cx + sg * h * 0.035f, shy, cz);
            int ua = hb(side + "UpperArm", sh, cx + sg * h * 0.10f, shy - h * 0.005f, cz);
            int la, hand;
            if (tpose) {
                float reach = Math.max(halfW, h * 0.35f);
                la = hb(side + "LowerArm", ua, cx + sg * (h * 0.10f + (reach - h * 0.10f) * 0.42f), shy - h * 0.01f, cz);
                hand = hb(side + "Hand", la, cx + sg * (h * 0.10f + (reach - h * 0.10f) * 0.80f), shy - h * 0.015f, cz);
                hb(side + "HandEnd", hand, cx + sg * (reach * 0.98f), shy - h * 0.02f, cz);
            } else {
                la = hb(side + "LowerArm", ua, cx + sg * h * 0.13f, y0 + h * 0.63f, cz);
                hand = hb(side + "Hand", la, cx + sg * h * 0.15f, y0 + h * 0.48f, cz);
                hb(side + "HandEnd", hand, cx + sg * h * 0.16f, y0 + h * 0.41f, cz);
            }
            int ul = hb(side + "UpperLeg", hips, cx + sg * h * 0.06f, y0 + h * 0.50f, cz);
            int ll = hb(side + "LowerLeg", ul, cx + sg * h * 0.06f, y0 + h * 0.28f, cz);
            int ft = hb(side + "Foot", ll, cx + sg * h * 0.06f, y0 + h * 0.05f, cz);
            hb(side + "Toes", ft, cx + sg * h * 0.06f, y0 + h * 0.015f, cz + h * 0.06f);
        }
        jIdx = null;
        ensureWeights();
        autoWeights();
    }

    private int hb(String name, int parent, float x, float y, float z) {
        Bone b = new Bone();
        b.name = name;
        b.parent = parent;
        b.rest = Mat4.translate(x, y, z);
        bones.add(b);
        int i = bones.size() - 1;
        if (!name.endsWith("End")) human.put(name, i);
        return i;
    }

    /** Cambia izquierda ↔ derecha en los nombres y en el mapa humanoide. */
    void swapSides() {
        for (Bone b : bones) {
            if (b.name.startsWith("left")) b.name = "right" + b.name.substring(4);
            else if (b.name.startsWith("right")) b.name = "left" + b.name.substring(5);
        }
        Map<String, Integer> nh = new HashMap<>();
        for (Map.Entry<String, Integer> e : human.entrySet()) {
            String k = e.getKey();
            if (k.startsWith("left")) k = "right" + k.substring(4);
            else if (k.startsWith("right")) k = "left" + k.substring(5);
            nh.put(k, e.getValue());
        }
        human.clear();
        human.putAll(nh);
    }

    /** Huesos humanoides que faltan para poder guardar como VRM. */
    List<String> missingHuman() {
        List<String> m = new ArrayList<>();
        for (String h : HUMAN_REQUIRED) {
            Integer i = human.get(h);
            if (i == null || i < 0 || i >= bones.size()) {
                int byName = boneByName(h);       // también vale si el hueso se llama exactamente así
                if (byName >= 0) human.put(h, byName); else m.add(h);
            }
        }
        return m;
    }

    // =====================================================================
    // Exportar
    // =====================================================================
    /** Triángulos sueltos (para STL, OBJ y FBX: solo la forma, en reposo). */
    Mesh3D toSoup() {
        Mesh3D s = new Mesh3D();
        s.tris = tris();
        s.originalTris = s.tris;
        s.v = new float[s.tris * 9];
        for (int i = 0; i < idx.length; i++) {
            int v = idx[i];
            s.v[i * 3] = pos[v * 3]; s.v[i * 3 + 1] = pos[v * 3 + 1]; s.v[i * 3 + 2] = pos[v * 3 + 2];
        }
        return s;
    }

    byte[] export(String ext) throws IOException {
        switch (ext) {
            case "glb": return GltfOut.write(this, false);
            case "vrm": return GltfOut.write(this, true);
            default: return toSoup().export(ext);
        }
    }

    // =====================================================================
    // Matrices 4×4 por filas
    // =====================================================================
    static class Mat4 {
        static float[] identity() { return new float[]{1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}; }
        static float[] translate(float x, float y, float z) { float[] m = identity(); m[3] = x; m[7] = y; m[11] = z; return m; }
        static float[] mul(float[] a, float[] b) { return Mesh3D.Mat.mul(a, b); }

        static boolean isIdentity(float[] m) {
            float[] i = identity();
            for (int k = 0; k < 16; k++) if (Math.abs(m[k] - i[k]) > 1e-6f) return false;
            return true;
        }

        static float[] transpose(float[] m) {
            float[] r = new float[16];
            for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) r[i * 4 + j] = m[j * 4 + i];
            return r;
        }

        /** Solo la parte de giro (normalizada), sin traslación. */
        static float[] rotOnly(float[] m) {
            float[] r = identity();
            for (int c = 0; c < 3; c++) {
                float x = m[c], y = m[4 + c], z = m[8 + c];
                float l = (float) Math.sqrt(x * x + y * y + z * z);
                if (l < 1e-9f) l = 1;
                r[c] = x / l; r[4 + c] = y / l; r[8 + c] = z / l;
            }
            return r;
        }

        static float[] axisAngle(float x, float y, float z, float a) {
            float l = (float) Math.sqrt(x * x + y * y + z * z);
            if (l < 1e-9f) return identity();
            x /= l; y /= l; z /= l;
            float c = (float) Math.cos(a), s = (float) Math.sin(a), t = 1 - c;
            return new float[]{
                    t * x * x + c, t * x * y - s * z, t * x * z + s * y, 0,
                    t * x * y + s * z, t * y * y + c, t * y * z - s * x, 0,
                    t * x * z - s * y, t * y * z + s * x, t * z * z + c, 0,
                    0, 0, 0, 1};
        }

        static float[] invert(float[] m) {
            float[] inv = new float[16];
            float[] a = new float[16];
            // por columnas para la fórmula clásica
            for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) a[j * 4 + i] = m[i * 4 + j];
            inv[0] = a[5] * a[10] * a[15] - a[5] * a[11] * a[14] - a[9] * a[6] * a[15] + a[9] * a[7] * a[14] + a[13] * a[6] * a[11] - a[13] * a[7] * a[10];
            inv[4] = -a[4] * a[10] * a[15] + a[4] * a[11] * a[14] + a[8] * a[6] * a[15] - a[8] * a[7] * a[14] - a[12] * a[6] * a[11] + a[12] * a[7] * a[10];
            inv[8] = a[4] * a[9] * a[15] - a[4] * a[11] * a[13] - a[8] * a[5] * a[15] + a[8] * a[7] * a[13] + a[12] * a[5] * a[11] - a[12] * a[7] * a[9];
            inv[12] = -a[4] * a[9] * a[14] + a[4] * a[10] * a[13] + a[8] * a[5] * a[14] - a[8] * a[6] * a[13] - a[12] * a[5] * a[10] + a[12] * a[6] * a[9];
            inv[1] = -a[1] * a[10] * a[15] + a[1] * a[11] * a[14] + a[9] * a[2] * a[15] - a[9] * a[3] * a[14] - a[13] * a[2] * a[11] + a[13] * a[3] * a[10];
            inv[5] = a[0] * a[10] * a[15] - a[0] * a[11] * a[14] - a[8] * a[2] * a[15] + a[8] * a[3] * a[14] + a[12] * a[2] * a[11] - a[12] * a[3] * a[10];
            inv[9] = -a[0] * a[9] * a[15] + a[0] * a[11] * a[13] + a[8] * a[1] * a[15] - a[8] * a[3] * a[13] - a[12] * a[1] * a[11] + a[12] * a[3] * a[9];
            inv[13] = a[0] * a[9] * a[14] - a[0] * a[10] * a[13] - a[8] * a[1] * a[14] + a[8] * a[2] * a[13] + a[12] * a[1] * a[10] - a[12] * a[2] * a[9];
            inv[2] = a[1] * a[6] * a[15] - a[1] * a[7] * a[14] - a[5] * a[2] * a[15] + a[5] * a[3] * a[14] + a[13] * a[2] * a[7] - a[13] * a[3] * a[6];
            inv[6] = -a[0] * a[6] * a[15] + a[0] * a[7] * a[14] + a[4] * a[2] * a[15] - a[4] * a[3] * a[14] - a[12] * a[2] * a[7] + a[12] * a[3] * a[6];
            inv[10] = a[0] * a[5] * a[15] - a[0] * a[7] * a[13] - a[4] * a[1] * a[15] + a[4] * a[3] * a[13] + a[12] * a[1] * a[7] - a[12] * a[3] * a[5];
            inv[14] = -a[0] * a[5] * a[14] + a[0] * a[6] * a[13] + a[4] * a[1] * a[14] - a[4] * a[2] * a[13] - a[12] * a[1] * a[6] + a[12] * a[2] * a[5];
            inv[3] = -a[1] * a[6] * a[11] + a[1] * a[7] * a[10] + a[5] * a[2] * a[11] - a[5] * a[3] * a[10] - a[9] * a[2] * a[7] + a[9] * a[3] * a[6];
            inv[7] = a[0] * a[6] * a[11] - a[0] * a[7] * a[10] - a[4] * a[2] * a[11] + a[4] * a[3] * a[10] + a[8] * a[2] * a[7] - a[8] * a[3] * a[6];
            inv[11] = -a[0] * a[5] * a[11] + a[0] * a[7] * a[9] + a[4] * a[1] * a[11] - a[4] * a[3] * a[9] - a[8] * a[1] * a[7] + a[8] * a[3] * a[5];
            inv[15] = a[0] * a[5] * a[10] - a[0] * a[6] * a[9] - a[4] * a[1] * a[10] + a[4] * a[2] * a[9] + a[8] * a[1] * a[6] - a[8] * a[2] * a[5];
            float det = a[0] * inv[0] + a[1] * inv[4] + a[2] * inv[8] + a[3] * inv[12];
            if (Math.abs(det) < 1e-12f) return identity();
            det = 1f / det;
            float[] r = new float[16];
            for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) r[i * 4 + j] = inv[j * 4 + i] * det;
            return r;
        }

        /** De glTF (16 números por columnas) a nuestra matriz por filas. */
        static float[] fromColumns(float[] c, int off) {
            float[] r = new float[16];
            for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) r[i * 4 + j] = c[off + j * 4 + i];
            return r;
        }

        static void toColumns(float[] m, float[] out, int off) {
            for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) out[off + j * 4 + i] = m[i * 4 + j];
        }

        /** Matriz → traslación, giro (cuaternión x,y,z,w) y escala. */
        static float[][] decompose(float[] m) {
            float sx = (float) Math.sqrt(m[0] * m[0] + m[4] * m[4] + m[8] * m[8]);
            float sy = (float) Math.sqrt(m[1] * m[1] + m[5] * m[5] + m[9] * m[9]);
            float sz = (float) Math.sqrt(m[2] * m[2] + m[6] * m[6] + m[10] * m[10]);
            float[] r = rotOnly(m);
            float tr = r[0] + r[5] + r[10], qx, qy, qz, qw;
            if (tr > 0) {
                float s = (float) Math.sqrt(tr + 1) * 2;
                qw = 0.25f * s; qx = (r[9] - r[6]) / s; qy = (r[2] - r[8]) / s; qz = (r[4] - r[1]) / s;
            } else if (r[0] > r[5] && r[0] > r[10]) {
                float s = (float) Math.sqrt(1 + r[0] - r[5] - r[10]) * 2;
                qw = (r[9] - r[6]) / s; qx = 0.25f * s; qy = (r[1] + r[4]) / s; qz = (r[2] + r[8]) / s;
            } else if (r[5] > r[10]) {
                float s = (float) Math.sqrt(1 + r[5] - r[0] - r[10]) * 2;
                qw = (r[2] - r[8]) / s; qx = (r[1] + r[4]) / s; qy = 0.25f * s; qz = (r[6] + r[9]) / s;
            } else {
                float s = (float) Math.sqrt(1 + r[10] - r[0] - r[5]) * 2;
                qw = (r[4] - r[1]) / s; qx = (r[2] + r[8]) / s; qy = (r[6] + r[9]) / s; qz = 0.25f * s;
            }
            float ql = (float) Math.sqrt(qx * qx + qy * qy + qz * qz + qw * qw);
            return new float[][]{{m[3], m[7], m[11]}, {qx / ql, qy / ql, qz / ql, qw / ql}, {sx, sy, sz}};
        }
    }

    // =====================================================================
    // Lectura glTF / GLB / VRM con texturas, huesos y pesos
    // =====================================================================
    static class GltfIn {
        static Model3D read(byte[] d) throws IOException {
            try {
                JSONObject json;
                byte[] bin = null;
                ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
                if (d.length >= 20 && b.getInt(0) == 0x46546C67) {
                    int p = 12;
                    String js = null;
                    while (p + 8 <= d.length) {
                        int len = b.getInt(p), type = b.getInt(p + 4);
                        if (type == 0x4E4F534A) js = new String(d, p + 8, len, StandardCharsets.UTF_8);
                        else if (type == 0x004E4942) { bin = new byte[len]; System.arraycopy(d, p + 8, bin, 0, len); }
                        p += 8 + len;
                    }
                    if (js == null) throw new IOException("GLB sin JSON");
                    json = new JSONObject(js);
                } else json = new JSONObject(new String(d, StandardCharsets.UTF_8));

                JSONArray buffersJ = json.optJSONArray("buffers");
                byte[][] buffers = new byte[buffersJ == null ? 0 : buffersJ.length()][];
                for (int i = 0; i < buffers.length; i++) {
                    String uri = buffersJ.getJSONObject(i).optString("uri", "");
                    if (uri.isEmpty()) buffers[i] = bin;
                    else if (uri.startsWith("data:")) buffers[i] = Mesh3D.Base64Lite.decode(uri.substring(uri.indexOf(',') + 1));
                    else throw new IOException("Este .gltf usa un archivo .bin aparte (" + uri + "). Ábrelo como .glb.");
                }
                Model3D m = new Model3D();
                JSONObject asset = json.optJSONObject("asset");
                // ---- texturas ----
                JSONArray images = json.optJSONArray("images");
                if (images != null) for (int i = 0; i < images.length(); i++) {
                    JSONObject im = images.getJSONObject(i);
                    Tex t = new Tex();
                    t.name = im.optString("name", "textura" + i);
                    t.mime = im.optString("mimeType", "image/png");
                    if (im.has("bufferView")) {
                        JSONObject bv = json.getJSONArray("bufferViews").getJSONObject(im.getInt("bufferView"));
                        byte[] buf = buffers[bv.optInt("buffer", 0)];
                        t.data = new byte[bv.getInt("byteLength")];
                        System.arraycopy(buf, bv.optInt("byteOffset", 0), t.data, 0, t.data.length);
                    } else {
                        String uri = im.optString("uri", "");
                        if (uri.startsWith("data:")) {
                            t.data = Mesh3D.Base64Lite.decode(uri.substring(uri.indexOf(',') + 1));
                            if (uri.startsWith("data:image/jpeg")) t.mime = "image/jpeg";
                        }
                    }
                    if (t.data != null && t.data.length > 3 && (t.data[0] & 0xff) == 0xFF && (t.data[1] & 0xff) == 0xD8) t.mime = "image/jpeg";
                    m.textures.add(t);
                }
                JSONArray texJ = json.optJSONArray("textures");
                // ---- materiales → partes ----
                JSONArray mats = json.optJSONArray("materials");
                Map<Integer, Integer> matPart = new HashMap<>();

                // ---- nodos y esqueleto ----
                JSONArray nodes = json.optJSONArray("nodes");
                int nn = nodes == null ? 0 : nodes.length();
                float[][] local = new float[nn][];
                int[] parentOf = new int[nn];
                java.util.Arrays.fill(parentOf, -1);
                for (int i = 0; i < nn; i++) {
                    JSONObject n = nodes.getJSONObject(i);
                    local[i] = nodeMatrix(n);
                    JSONArray kids = n.optJSONArray("children");
                    if (kids != null) for (int k = 0; k < kids.length(); k++) parentOf[kids.getInt(k)] = i;
                }
                float[][] world = new float[nn][];
                for (int i = 0; i < nn; i++) nodeWorld(i, local, parentOf, world);

                JSONArray skins = json.optJSONArray("skins");
                Map<Integer, Integer> nodeBone = new HashMap<>();   // nodo → hueso
                if (skins != null) for (int s = 0; s < skins.length(); s++) {
                    JSONObject sk = skins.getJSONObject(s);
                    JSONArray joints = sk.getJSONArray("joints");
                    float[] ibm = sk.has("inverseBindMatrices") ? Mesh3D.accessorFloats(json, buffers, sk.getInt("inverseBindMatrices")) : null;
                    for (int j = 0; j < joints.length(); j++) {
                        int node = joints.getInt(j);
                        if (nodeBone.containsKey(node)) continue;
                        Bone bone = new Bone();
                        bone.name = nodes.getJSONObject(node).optString("name", "hueso" + node);
                        bone.rest = ibm != null && ibm.length >= (j + 1) * 16 ? Mat4.invert(Mat4.fromColumns(ibm, j * 16)) : world[node];
                        m.bones.add(bone);
                        nodeBone.put(node, m.bones.size() - 1);
                    }
                }
                // nombres repetidos → únicos
                Map<String, Integer> seenNames = new HashMap<>();
                for (Bone bone : m.bones) {
                    Integer c = seenNames.get(bone.name);
                    seenNames.put(bone.name, c == null ? 1 : c + 1);
                    if (c != null) bone.name = bone.name + "." + (c + 1);
                }
                for (Map.Entry<Integer, Integer> e : nodeBone.entrySet()) {
                    int p = parentOf[e.getKey()];
                    while (p >= 0 && !nodeBone.containsKey(p)) p = parentOf[p];
                    m.bones.get(e.getValue()).parent = p >= 0 ? nodeBone.get(p) : -1;
                }

                // ---- mallas ----
                FloatListX P = new FloatListX(), UV = new FloatListX(), W = new FloatListX();
                IntListX I = new IntListX(), TP = new IntListX(), J = new IntListX();
                boolean anyUv = false, anySkin = false;
                Map<String, Integer> sharedBase = new HashMap<>();
                if (nodes != null) for (int ni = 0; ni < nn; ni++) {
                    JSONObject n = nodes.getJSONObject(ni);
                    if (!n.has("mesh")) continue;
                    JSONObject mesh = json.getJSONArray("meshes").getJSONObject(n.getInt("mesh"));
                    int[] jointMap = null;
                    if (n.has("skin") && skins != null) {
                        JSONArray joints = skins.getJSONObject(n.getInt("skin")).getJSONArray("joints");
                        jointMap = new int[joints.length()];
                        for (int k = 0; k < jointMap.length; k++) jointMap[k] = nodeBone.get(joints.getInt(k));
                    }
                    float[] mw = jointMap != null ? null : world[ni];
                    JSONArray prims = mesh.optJSONArray("primitives");
                    if (prims == null) continue;
                    for (int pi = 0; pi < prims.length(); pi++) {
                        JSONObject pr = prims.getJSONObject(pi);
                        int mode = pr.optInt("mode", 4);
                        if (mode != 4 && mode != 5 && mode != 6) continue;
                        JSONObject at = pr.optJSONObject("attributes");
                        if (at == null || !at.has("POSITION")) continue;
                        String key = ni + ":" + at.getInt("POSITION") + ":" + at.optInt("TEXCOORD_0", -1) + ":" + at.optInt("JOINTS_0", -1);
                        Integer shared = sharedBase.get(key);       // varias primitivas con los mismos vértices
                        float[] pp = Mesh3D.accessorFloats(json, buffers, at.getInt("POSITION"));
                        int cnt = pp.length / 3, base = shared != null ? shared : P.size / 3;
                        if (shared == null) sharedBase.put(key, base);
                        float[] tuv = at.has("TEXCOORD_0") ? Mesh3D.accessorFloats(json, buffers, at.getInt("TEXCOORD_0")) : null;
                        float[] jj = jointMap != null && at.has("JOINTS_0") ? Mesh3D.accessorFloats(json, buffers, at.getInt("JOINTS_0")) : null;
                        float[] ww = jointMap != null && at.has("WEIGHTS_0") ? Mesh3D.accessorFloats(json, buffers, at.getInt("WEIGHTS_0")) : null;
                        float[] q = new float[3];
                        if (shared == null) for (int v = 0; v < cnt; v++) {
                            q[0] = pp[v * 3]; q[1] = pp[v * 3 + 1]; q[2] = pp[v * 3 + 2];
                            if (mw != null) Mesh3D.Mat.apply(mw, q);
                            P.add(q[0]); P.add(q[1]); P.add(q[2]);
                            if (tuv != null) { UV.add(tuv[v * 2]); UV.add(tuv[v * 2 + 1]); } else { UV.add(0); UV.add(0); }
                            for (int k = 0; k < 4; k++) {
                                if (jj != null && ww != null) {
                                    int ji = (int) jj[v * 4 + k];
                                    J.add(ji >= 0 && ji < jointMap.length ? jointMap[ji] : 0);
                                    W.add(ji >= 0 && ji < jointMap.length ? ww[v * 4 + k] : 0);
                                } else { J.add(0); W.add(0); }
                            }
                        }
                        if (tuv != null && shared == null) anyUv = true;
                        if (jj != null && shared == null) anySkin = true;
                        // parte según el material
                        int mat = pr.optInt("material", -1);
                        Integer part = matPart.get(mat);
                        if (part == null) {
                            Part pt = new Part();
                            if (mat >= 0 && mats != null && mat < mats.length()) {
                                JSONObject mo = mats.getJSONObject(mat);
                                pt.name = mo.optString("name", "material" + mat);
                                JSONObject pbr = mo.optJSONObject("pbrMetallicRoughness");
                                if (pbr != null) {
                                    JSONArray f = pbr.optJSONArray("baseColorFactor");
                                    if (f != null && f.length() >= 3)
                                        pt.color = argb(f.length() > 3 ? f.getDouble(3) : 1, f.getDouble(0), f.getDouble(1), f.getDouble(2));
                                    JSONObject bct = pbr.optJSONObject("baseColorTexture");
                                    if (bct != null && texJ != null) {
                                        int ti = bct.optInt("index", -1);
                                        if (ti >= 0 && ti < texJ.length()) pt.tex = texJ.getJSONObject(ti).optInt("source", -1);
                                    }
                                }
                            } else pt.name = mesh.optString("name", "malla");
                            m.parts.add(pt);
                            part = m.parts.size() - 1;
                            matPart.put(mat, part);
                        }
                        int[] ix;
                        if (pr.has("indices")) ix = Mesh3D.accessorInts(json, buffers, pr.getInt("indices"));
                        else { ix = new int[cnt]; for (int k = 0; k < cnt; k++) ix[k] = k; }
                        List<int[]> tris = new ArrayList<>();
                        if (mode == 4) for (int k = 0; k + 2 < ix.length; k += 3) tris.add(new int[]{ix[k], ix[k + 1], ix[k + 2]});
                        else if (mode == 5) for (int k = 0; k + 2 < ix.length; k++)
                            tris.add(k % 2 == 0 ? new int[]{ix[k], ix[k + 1], ix[k + 2]} : new int[]{ix[k + 1], ix[k], ix[k + 2]});
                        else for (int k = 1; k + 1 < ix.length; k++) tris.add(new int[]{ix[0], ix[k], ix[k + 1]});
                        for (int[] t : tris) {
                            if (t[0] >= cnt || t[1] >= cnt || t[2] >= cnt) continue;
                            I.add(base + t[0]); I.add(base + t[1]); I.add(base + t[2]);
                            TP.add(part);
                        }
                    }
                }
                m.pos = P.trim();
                m.nv = m.pos.length / 3;
                m.uv = anyUv ? UV.trim() : null;
                m.idx = I.trim();
                m.triPart = TP.trim();
                if (!m.bones.isEmpty()) {
                    m.jIdx = J.trim();
                    m.jW = W.trim();
                    if (!anySkin) m.jW = new float[m.nv * 4];
                    m.normalizeAll();
                }
                if (m.parts.isEmpty()) m.parts.add(new Part());

                // ---- VRM: huesos humanoides y datos ----
                JSONObject ext = json.optJSONObject("extensions");
                if (ext != null) {
                    JSONObject vrm0 = ext.optJSONObject("VRM");
                    JSONObject vrm1 = ext.optJSONObject("VRMC_vrm");
                    if (vrm0 != null) {
                        JSONObject hum = vrm0.optJSONObject("humanoid");
                        JSONArray hb = hum == null ? null : hum.optJSONArray("humanBones");
                        if (hb != null) for (int i = 0; i < hb.length(); i++) {
                            JSONObject o = hb.getJSONObject(i);
                            Integer bi = nodeBone.get(o.optInt("node", -1));
                            if (bi != null) m.human.put(o.optString("bone", ""), bi);
                        }
                        JSONObject meta = vrm0.optJSONObject("meta");
                        if (meta != null) { m.title = meta.optString("title", m.title); m.author = meta.optString("author", ""); }
                    } else if (vrm1 != null) {
                        JSONObject hum = vrm1.optJSONObject("humanoid");
                        JSONObject hb = hum == null ? null : hum.optJSONObject("humanBones");
                        if (hb != null) for (java.util.Iterator<String> it = hb.keys(); it.hasNext(); ) {
                            String k = it.next();
                            Integer bi = nodeBone.get(hb.getJSONObject(k).optInt("node", -1));
                            if (bi != null) m.human.put(k, bi);
                        }
                        JSONObject meta = vrm1.optJSONObject("meta");
                        if (meta != null) {
                            m.title = meta.optString("name", m.title);
                            JSONArray au = meta.optJSONArray("authors");
                            if (au != null && au.length() > 0) m.author = au.getString(0);
                        }
                    }
                }
                return m;
            } catch (IOException e) {
                throw e;
            } catch (Exception e) {
                throw new IOException("glTF/VRM no válido: " + e.getMessage());
            }
        }

        static int argb(double a, double r, double g, double b) {
            int A = (int) Math.round(Math.max(0, Math.min(1, a)) * 255), R = (int) Math.round(Math.max(0, Math.min(1, r)) * 255);
            int G = (int) Math.round(Math.max(0, Math.min(1, g)) * 255), B = (int) Math.round(Math.max(0, Math.min(1, b)) * 255);
            return (A << 24) | (R << 16) | (G << 8) | B;
        }

        static float[] nodeMatrix(JSONObject n) throws Exception {
            JSONArray mat = n.optJSONArray("matrix");
            if (mat != null && mat.length() == 16) {
                float[] c = new float[16];
                for (int i = 0; i < 16; i++) c[i] = (float) mat.getDouble(i);
                return Mat4.fromColumns(c, 0);
            }
            JSONArray t = n.optJSONArray("translation"), r = n.optJSONArray("rotation"), s = n.optJSONArray("scale");
            float[] T = t == null ? Mat4.identity() : Mat4.translate((float) t.getDouble(0), (float) t.getDouble(1), (float) t.getDouble(2));
            float[] R = r == null ? Mat4.identity() : Mesh3D.Mat.quat((float) r.getDouble(0), (float) r.getDouble(1), (float) r.getDouble(2), (float) r.getDouble(3));
            float[] S = s == null ? Mat4.identity() : Mesh3D.Mat.scale((float) s.getDouble(0), (float) s.getDouble(1), (float) s.getDouble(2));
            return Mat4.mul(T, Mat4.mul(R, S));
        }

        static float[] nodeWorld(int i, float[][] local, int[] parent, float[][] world) {
            if (world[i] != null) return world[i];
            world[i] = parent[i] >= 0 && parent[i] != i ? Mat4.mul(nodeWorld(parent[i], local, parent, world), local[i]) : local[i];
            return world[i];
        }
    }

    // =====================================================================
    // Escritura GLB (y VRM 0.x)
    // =====================================================================
    static class GltfOut {
        static byte[] write(Model3D m, boolean vrm) throws IOException {
            try {
                if (vrm) {
                    List<String> miss = m.missingHuman();
                    if (!miss.isEmpty()) throw new IOException("Faltan huesos humanoides para VRM: " + miss);
                }
                Bin bin = new Bin();
                JSONArray accessors = new JSONArray(), views = new JSONArray();
                // posiciones
                float[] mn = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE}, mx = {-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
                for (int i = 0; i < m.nv; i++) for (int k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], m.pos[i * 3 + k]); mx[k] = Math.max(mx[k], m.pos[i * 3 + k]); }
                int posAcc = addFloats(bin, views, accessors, m.pos, "VEC3", 34962, mn, mx);
                int nrmAcc = addFloats(bin, views, accessors, normals(m), "VEC3", 34962, null, null);
                int uvAcc = m.uv != null ? addFloats(bin, views, accessors, m.uv, "VEC2", 34962, null, null) : -1;
                boolean skin = !m.bones.isEmpty() && m.jIdx != null;
                int jAcc = -1, wAcc = -1;
                if (skin) {
                    m.normalizeAll();
                    ByteBuffer jb = ByteBuffer.allocate(m.nv * 8).order(ByteOrder.LITTLE_ENDIAN);
                    for (int i = 0; i < m.nv * 4; i++) jb.putShort((short) (m.jW[i] > 0 ? m.jIdx[i] : 0));
                    int v = bin.add(jb.array());
                    views.put(view(v, jb.capacity(), 34962));
                    accessors.put(new JSONObject().put("bufferView", views.length() - 1).put("componentType", 5123).put("count", m.nv).put("type", "VEC4"));
                    jAcc = accessors.length() - 1;
                    float[] w = m.jW.clone();
                    for (int i = 0; i < m.nv; i++) {       // si un vértice no tiene peso, va entero al primer hueso
                        float t = w[i * 4] + w[i * 4 + 1] + w[i * 4 + 2] + w[i * 4 + 3];
                        if (t <= 0) w[i * 4] = 1;
                    }
                    wAcc = addFloats(bin, views, accessors, w, "VEC4", 34962, null, null);
                }
                // texturas
                JSONArray images = new JSONArray(), textures = new JSONArray(), materials = new JSONArray();
                for (int i = 0; i < m.textures.size(); i++) {
                    Tex t = m.textures.get(i);
                    if (t.data == null) t.data = new byte[0];
                    int v = bin.add(t.data);
                    views.put(new JSONObject().put("buffer", 0).put("byteOffset", v).put("byteLength", t.data.length));
                    images.put(new JSONObject().put("bufferView", views.length() - 1).put("mimeType", t.mime).put("name", t.name));
                    textures.put(new JSONObject().put("source", i).put("sampler", 0));
                }
                // primitivas: una por parte
                JSONArray prims = new JSONArray();
                for (int pi = 0; pi < m.parts.size(); pi++) {
                    IntListX ix = new IntListX();
                    for (int t = 0; t < m.tris(); t++) if (m.triPart[t] == pi) { ix.add(m.idx[t * 3]); ix.add(m.idx[t * 3 + 1]); ix.add(m.idx[t * 3 + 2]); }
                    Part p = m.parts.get(pi);
                    JSONObject mat = new JSONObject().put("name", p.name);
                    JSONObject pbr = new JSONObject();
                    pbr.put("baseColorFactor", new JSONArray().put(((p.color >> 16) & 255) / 255.0).put(((p.color >> 8) & 255) / 255.0)
                            .put((p.color & 255) / 255.0).put(((p.color >>> 24) & 255) / 255.0));
                    if (p.tex >= 0 && p.tex < m.textures.size()) pbr.put("baseColorTexture", new JSONObject().put("index", p.tex));
                    pbr.put("metallicFactor", 0.0).put("roughnessFactor", 0.9);
                    mat.put("pbrMetallicRoughness", pbr);
                    if (((p.color >>> 24) & 255) < 255) mat.put("alphaMode", "BLEND");
                    else if (p.tex >= 0) mat.put("alphaMode", "MASK").put("alphaCutoff", 0.5);
                    mat.put("doubleSided", true);
                    materials.put(mat);
                    if (ix.size == 0) continue;
                    ByteBuffer ib = ByteBuffer.allocate(ix.size * 4).order(ByteOrder.LITTLE_ENDIAN);
                    for (int i = 0; i < ix.size; i++) ib.putInt(ix.a[i]);
                    int v = bin.add(ib.array());
                    views.put(view(v, ib.capacity(), 34963));
                    accessors.put(new JSONObject().put("bufferView", views.length() - 1).put("componentType", 5125).put("count", ix.size).put("type", "SCALAR"));
                    JSONObject attrs = new JSONObject().put("POSITION", posAcc).put("NORMAL", nrmAcc);
                    if (uvAcc >= 0) attrs.put("TEXCOORD_0", uvAcc);
                    if (skin) { attrs.put("JOINTS_0", jAcc); attrs.put("WEIGHTS_0", wAcc); }
                    prims.put(new JSONObject().put("attributes", attrs).put("indices", accessors.length() - 1).put("material", pi).put("mode", 4));
                }
                // nodos: 0 = malla, luego los huesos
                JSONArray nodes = new JSONArray();
                JSONObject meshNode = new JSONObject().put("name", m.title).put("mesh", 0);
                nodes.put(meshNode);
                JSONArray sceneRoots = new JSONArray().put(0);
                JSONArray skinsOut = null;
                int boneBase = 1;
                if (skin) {
                    for (int i = 0; i < m.bones.size(); i++) {
                        Bone b = m.bones.get(i);
                        float[] local = b.parent >= 0 ? Mat4.mul(Mat4.invert(m.bones.get(b.parent).rest), b.rest) : b.rest;
                        float[][] trs = Mat4.decompose(local);
                        JSONObject n = new JSONObject().put("name", b.name);
                        n.put("translation", arr(trs[0]));
                        if (Math.abs(trs[1][3]) < 0.999999f) n.put("rotation", arr(trs[1]));
                        if (Math.abs(trs[2][0] - 1) > 1e-5 || Math.abs(trs[2][1] - 1) > 1e-5 || Math.abs(trs[2][2] - 1) > 1e-5) n.put("scale", arr(trs[2]));
                        JSONArray kids = new JSONArray();
                        for (int k = 0; k < m.bones.size(); k++) if (m.bones.get(k).parent == i) kids.put(boneBase + k);
                        if (kids.length() > 0) n.put("children", kids);
                        nodes.put(n);
                        if (b.parent < 0) sceneRoots.put(boneBase + i);
                    }
                    float[] ibm = new float[m.bones.size() * 16];
                    for (int i = 0; i < m.bones.size(); i++) Mat4.toColumns(Mat4.invert(m.bones.get(i).rest), ibm, i * 16);
                    int ibmAcc = addFloats(bin, views, accessors, ibm, "MAT4", -1, null, null);
                    JSONArray joints = new JSONArray();
                    for (int i = 0; i < m.bones.size(); i++) joints.put(boneBase + i);
                    int root = -1;
                    for (int i = 0; i < m.bones.size() && root < 0; i++) if (m.bones.get(i).parent < 0) root = i;
                    JSONObject sk = new JSONObject().put("joints", joints).put("inverseBindMatrices", ibmAcc);
                    if (root >= 0) sk.put("skeleton", boneBase + root);
                    meshNode.put("skin", 0);
                    skinsOut = new JSONArray().put(sk);
                }

                JSONObject j = new JSONObject();
                j.put("asset", new JSONObject().put("version", "2.0").put("generator", "SSS+ (BLORP.eoac)"));
                j.put("scene", 0);
                j.put("scenes", new JSONArray().put(new JSONObject().put("nodes", sceneRoots)));
                j.put("nodes", nodes);
                j.put("meshes", new JSONArray().put(new JSONObject().put("name", m.title).put("primitives", prims)));
                if (skinsOut != null) j.put("skins", skinsOut);
                j.put("materials", materials);
                if (images.length() > 0) {
                    j.put("images", images);
                    j.put("textures", textures);
                    j.put("samplers", new JSONArray().put(new JSONObject().put("magFilter", 9729).put("minFilter", 9987).put("wrapS", 10497).put("wrapT", 10497)));
                }
                j.put("accessors", accessors);
                j.put("bufferViews", views);
                j.put("buffers", new JSONArray().put(new JSONObject().put("byteLength", bin.size())));
                if (vrm) addVrm0(j, m, boneBase);
                return glb(j.toString().getBytes(StandardCharsets.UTF_8), bin.bytes());
            } catch (IOException e) {
                throw e;
            } catch (Exception e) {
                throw new IOException(e.getMessage());
            }
        }

        static JSONArray arr(float[] f) throws Exception {
            JSONArray a = new JSONArray();
            for (float x : f) a.put((double) x);
            return a;
        }

        static JSONObject view(int off, int len, int target) throws Exception {
            JSONObject v = new JSONObject().put("buffer", 0).put("byteOffset", off).put("byteLength", len);
            if (target > 0) v.put("target", target);
            return v;
        }

        static int addFloats(Bin bin, JSONArray views, JSONArray accessors, float[] f, String type, int target, float[] mn, float[] mx) throws Exception {
            ByteBuffer b = ByteBuffer.allocate(f.length * 4).order(ByteOrder.LITTLE_ENDIAN);
            for (float x : f) b.putFloat(x);
            int off = bin.add(b.array());
            views.put(view(off, b.capacity(), target));
            int comps = Mesh3D.typeCount(type);
            JSONObject a = new JSONObject().put("bufferView", views.length() - 1).put("componentType", 5126).put("count", f.length / comps).put("type", type);
            if (mn != null) a.put("min", arr(mn)).put("max", arr(mx));
            accessors.put(a);
            return accessors.length() - 1;
        }

        static float[] normals(Model3D m) {
            float[] n = new float[m.nv * 3];
            for (int t = 0; t < m.tris(); t++) {
                int a = m.idx[t * 3], b = m.idx[t * 3 + 1], c = m.idx[t * 3 + 2];
                float ux = m.pos[b * 3] - m.pos[a * 3], uy = m.pos[b * 3 + 1] - m.pos[a * 3 + 1], uz = m.pos[b * 3 + 2] - m.pos[a * 3 + 2];
                float vx = m.pos[c * 3] - m.pos[a * 3], vy = m.pos[c * 3 + 1] - m.pos[a * 3 + 1], vz = m.pos[c * 3 + 2] - m.pos[a * 3 + 2];
                float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
                for (int v : new int[]{a, b, c}) { n[v * 3] += nx; n[v * 3 + 1] += ny; n[v * 3 + 2] += nz; }
            }
            for (int i = 0; i < m.nv; i++) {
                float l = (float) Math.sqrt(n[i * 3] * n[i * 3] + n[i * 3 + 1] * n[i * 3 + 1] + n[i * 3 + 2] * n[i * 3 + 2]);
                if (l > 0) { n[i * 3] /= l; n[i * 3 + 1] /= l; n[i * 3 + 2] /= l; } else n[i * 3 + 1] = 1;
            }
            return n;
        }

        /** Datos de avatar VRM 0.x (los que piden UniVRM, VRoid, VSeeFace...). */
        static void addVrm0(JSONObject j, Model3D m, int boneBase) throws Exception {
            JSONArray hb = new JSONArray();
            for (Map.Entry<String, Integer> e : m.human.entrySet()) {
                if (e.getValue() < 0 || e.getValue() >= m.bones.size()) continue;
                hb.put(new JSONObject().put("bone", e.getKey()).put("node", boneBase + e.getValue()).put("useDefaultValues", true));
            }
            JSONObject humanoid = new JSONObject().put("humanBones", hb)
                    .put("armStretch", 0.05).put("legStretch", 0.05).put("upperArmTwist", 0.5).put("lowerArmTwist", 0.5)
                    .put("upperLegTwist", 0.5).put("lowerLegTwist", 0.5).put("feetSpacing", 0).put("hasTranslationDoF", false);
            JSONObject meta = new JSONObject().put("title", m.title).put("version", "1.0")
                    .put("author", m.author == null || m.author.isEmpty() ? "SSS+" : m.author).put("contactInformation", "").put("reference", "")
                    .put("allowedUserName", "OnlyAuthor").put("violentUssageName", "Disallow").put("sexualUssageName", "Disallow")
                    .put("commercialUssageName", "Disallow").put("otherPermissionUrl", "").put("licenseName", "Redistribution_Prohibited")
                    .put("otherLicenseUrl", "");
            int head = m.human.get("head");
            JSONObject firstPerson = new JSONObject().put("firstPersonBone", boneBase + head)
                    .put("firstPersonBoneOffset", new JSONObject().put("x", 0).put("y", 0.06).put("z", 0))
                    .put("meshAnnotations", new JSONArray().put(new JSONObject().put("mesh", 0).put("firstPersonFlag", "Auto")))
                    .put("lookAtTypeName", "Bone");
            JSONObject curve = new JSONObject().put("curve", new JSONArray().put(0).put(0).put(0).put(1).put(1).put(1).put(1).put(0))
                    .put("xRange", 90).put("yRange", 10);
            firstPerson.put("lookAtHorizontalInner", curve).put("lookAtHorizontalOuter", curve).put("lookAtVerticalDown", curve).put("lookAtVerticalUp", curve);
            JSONArray matProps = new JSONArray();
            for (Part p : m.parts) {
                JSONObject tp = new JSONObject();
                if (p.tex >= 0) tp.put("_MainTex", p.tex);
                matProps.put(new JSONObject().put("name", p.name).put("shader", "VRM_USE_GLTFSHADER").put("renderQueue", 2000)
                        .put("floatProperties", new JSONObject()).put("vectorProperties", new JSONObject()).put("textureProperties", tp)
                        .put("keywordMap", new JSONObject()).put("tagMap", new JSONObject()));
            }
            JSONObject vrmExt = new JSONObject().put("exporterVersion", "SSS+-0.7").put("specVersion", "0.0")
                    .put("meta", meta).put("humanoid", humanoid).put("firstPerson", firstPerson)
                    .put("blendShapeMaster", new JSONObject().put("blendShapeGroups", new JSONArray()))
                    .put("secondaryAnimation", new JSONObject().put("boneGroups", new JSONArray()).put("colliderGroups", new JSONArray()))
                    .put("materialProperties", matProps);
            j.put("extensionsUsed", new JSONArray().put("VRM"));
            j.put("extensions", new JSONObject().put("VRM", vrmExt));
        }

        static byte[] glb(byte[] js, byte[] bin) {
            int jsLen = Mesh3D.pad4(js.length), binLen = Mesh3D.pad4(bin.length);
            int total = 12 + 8 + jsLen + 8 + binLen;
            ByteBuffer o = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);
            o.putInt(0x46546C67).putInt(2).putInt(total);
            o.putInt(jsLen).putInt(0x4E4F534A).put(js);
            for (int i = js.length; i < jsLen; i++) o.put((byte) ' ');
            o.putInt(binLen).putInt(0x004E4942).put(bin);
            for (int i = bin.length; i < binLen; i++) o.put((byte) 0);
            return o.array();
        }
    }

    /** Búfer binario con cada bloque alineado a 4 bytes. */
    static class Bin {
        final java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();

        int add(byte[] b) {
            while (o.size() % 4 != 0) o.write(0);
            int off = o.size();
            o.write(b, 0, b.length);
            return off;
        }

        int size() { return Mesh3D.pad4(o.size()); }

        byte[] bytes() {
            while (o.size() % 4 != 0) o.write(0);
            return o.toByteArray();
        }
    }

    static class FloatListX {
        float[] a = new float[4096];
        int size;
        void add(float f) { if (size == a.length) a = java.util.Arrays.copyOf(a, a.length * 2); a[size++] = f; }
        float[] trim() { return java.util.Arrays.copyOf(a, size); }
    }

    static class IntListX {
        int[] a = new int[4096];
        int size;
        void add(int f) { if (size == a.length) a = java.util.Arrays.copyOf(a, a.length * 2); a[size++] = f; }
        int[] trim() { return java.util.Arrays.copyOf(a, size); }
    }
}
