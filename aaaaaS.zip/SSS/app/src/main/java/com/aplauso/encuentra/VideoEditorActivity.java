package com.aplauso.encuentra;

import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.VideoView;

import java.io.File;

/** Editor de video: recortar inicio/fin, quitar el sonido y extraer el audio. Sin recomprimir. */
public class VideoEditorActivity extends NeonActivity {
    Uri uri;
    VideoView video;
    TextView playBtn, status, range;
    SeekBar startBar, endBar;
    Switch mute;
    long durMs;
    int startS = 0, endS;
    boolean busy;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("VIDEO");
        uri = getIntent().getData();
        durMs = uri == null ? 0 : MediaTools.durationMs(this, uri);
        if (uri == null || durMs <= 0) {
            col.addView(text("No se pudo abrir el video.", 16));
            return;
        }
        String name = getIntent().getStringExtra("name");
        if (name != null) col.addView(text(name, 13), gapBelow(6));

        FrameLayout box = new FrameLayout(this);
        box.setBackground(frame(14));
        video = new VideoView(this);
        box.addView(video, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        int h = (int) (getResources().getDisplayMetrics().heightPixels * 0.34f);
        col.addView(box, new LinearLayout.LayoutParams(-1, h));
        video.setVideoURI(uri);
        video.setOnPreparedListener(mp -> video.seekTo(1));

        playBtn = button("▶ VER TRAMO", v -> togglePlay());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dpi(8);
        lp.bottomMargin = dpi(12);
        col.addView(playBtn, lp);

        int totalS = (int) Math.max(1, durMs / 1000);
        endS = totalS;
        LinearLayout cut = panel("◢ RECORTAR");
        range = text("", 15);
        cut.addView(range);
        startBar = plainSlider(cut, "Inicio (s)", 0, totalS, 0, "", v -> {
            startS = Math.min(v, endS - 1);
            if (startS != v) startBar.setProgress(startS);
            video.seekTo(startS * 1000);
            showRange();
        });
        endBar = plainSlider(cut, "Final (s)", 0, totalS, totalS, "", v -> {
            endS = Math.max(v, startS + 1);
            if (endS != v) endBar.setProgress(endS);
            video.seekTo(endS * 1000);
            showRange();
        });
        TextView note = text("El corte empieza en el fotograma clave más cercano, así que puede adelantarse 1-2 segundos.", 12);
        note.setPadding(0, dpi(4), 0, 0);
        cut.addView(note);
        col.addView(cut, gapBelow(12));

        LinearLayout opt = panel("◢ SONIDO");
        mute = neonSwitch("Quitar el sonido del video");
        opt.addView(mute);
        col.addView(opt, gapBelow(12));

        col.addView(button("💾 GUARDAR VIDEO", v -> saveVideo()), gapBelow(8));
        col.addView(button("🎵 EXTRAER AUDIO DEL TRAMO", v -> extractAudio()), gapBelow(8));
        col.addView(button("🔍 AMPLIAR RESOLUCIÓN (HASTA 4K)", v -> startActivity(new android.content.Intent(this, VideoUpscaleActivity.class).setData(uri))), gapBelow(8));
        status = text("Se guarda en SSS+/Videos (video) o SSS+/Audios (audio). El original no se toca.", 12);
        col.addView(status);
        showRange();
    }

    private void showRange() {
        range.setText(L.t("Tramo: " + GalleryActivity.time(startS * 1000L) + " → " + GalleryActivity.time(endS * 1000L)
                + "  (" + (endS - startS) + " s)"));
    }

    private void togglePlay() {
        if (video.isPlaying()) {
            video.pause();
            playBtn.setText(L.t("▶ VER TRAMO"));
        } else {
            if (video.getCurrentPosition() < startS * 1000 || video.getCurrentPosition() >= endS * 1000)
                video.seekTo(startS * 1000);
            video.start();
            playBtn.setText(L.t("❚❚ PAUSA"));
        }
    }

    @Override
    protected void onTick() {
        if (video != null && video.isPlaying() && video.getCurrentPosition() >= endS * 1000) {
            video.pause();
            playBtn.setText(L.t("▶ VER TRAMO"));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (video != null && video.isPlaying()) { video.pause(); playBtn.setText(L.t("▶ VER TRAMO")); }
    }

    private void saveVideo() {
        if (busy) return;
        busy = true;
        boolean keepAudio = !mute.isChecked();
        long s = startS * 1_000_000L, e = endS * 1_000_000L;
        status.setText(L.t("Guardando… 0 %"));
        new Thread(() -> {
            String msg;
            try {
                File tmp = new File(getCacheDir(), "cut_" + System.currentTimeMillis() + ".mp4");
                boolean ok = MediaTools.remux(this, uri, tmp, s, e, true, keepAudio, f -> progress(f));
                Uri saved = ok ? Media.save(this, tmp, Media.TYPE_VIDEO, "SSS_" + Media.stamp() + ".mp4", "video/mp4") : null;
                msg = saved != null ? "Video guardado en SSS+/Videos ✓" : "No se pudo guardar este video";
            } catch (Exception ex) {
                msg = "Error: " + ex.getMessage();
            }
            finishTask(msg);
        }).start();
    }

    private void extractAudio() {
        if (busy) return;
        busy = true;
        long s = startS * 1_000_000L, e = endS * 1_000_000L;
        status.setText(L.t("Extrayendo audio… 0 %"));
        new Thread(() -> {
            String msg;
            try {
                // 1º intento: copiar el audio tal cual (rápido, .m4a)
                File m4a = new File(getCacheDir(), "aud_" + System.currentTimeMillis() + ".m4a");
                boolean ok = MediaTools.remux(this, uri, m4a, s, e, false, true, f -> progress(f));
                Uri saved;
                if (ok) {
                    saved = Media.save(this, m4a, Media.TYPE_AUDIO, "SSS_" + Media.stamp() + ".m4a", "audio/mp4");
                } else {
                    // 2º intento: convertir a WAV (funciona con cualquier audio)
                    m4a.delete();
                    File wav = new File(getCacheDir(), "aud_" + System.currentTimeMillis() + ".wav");
                    MediaTools.toWav(this, uri, wav, s, e, 1f, 0, 0, f -> progress(f));
                    saved = Media.save(this, wav, Media.TYPE_AUDIO, "SSS_" + Media.stamp() + ".wav", "audio/wav");
                }
                msg = saved != null ? "Audio guardado en SSS+/Audios ✓ (ábrelo en la pestaña Audios para editarlo)"
                        : "No se pudo guardar el audio";
            } catch (Exception ex) {
                msg = "Este video no tiene audio o no se pudo leer";
            }
            finishTask(msg);
        }).start();
    }

    private volatile int lastPct = -1;

    private void progress(float f) {
        int pct = Math.round(f * 100);
        if (pct == lastPct) return;   // solo actualiza cuando cambia el número
        lastPct = pct;
        runOnUiThread(() -> status.setText(L.t("Procesando… " + pct + " %")));
    }

    private void finishTask(String msg) {
        runOnUiThread(() -> {
            busy = false;
            status.setText(msg);
            toast(msg);
        });
    }
}
