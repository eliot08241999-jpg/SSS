package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** PDF: leer el texto (PdfBox), crear PDF nuevos (Android) y dibujar páginas (PdfRenderer). */
public class DocPdf {
    private static boolean inited;

    static DocIO.Doc read(Context ctx, Uri uri, String title) throws Exception {
        if (!inited) { PDFBoxResourceLoader.init(ctx.getApplicationContext()); inited = true; }
        String text;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri); PDDocument pd = PDDocument.load(in)) {
            text = new PDFTextStripper().getText(pd);
        }
        DocIO.Doc d = new DocIO.Doc();
        d.title = title;
        d.type = "pdf";
        // une las líneas cortadas del PDF en párrafos
        StringBuilder cur = new StringBuilder();
        for (String raw : text.replace("\r", "").split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) { flush(d, cur); continue; }
            if (cur.length() > 0) {
                if (cur.charAt(cur.length() - 1) == '-') cur.setLength(cur.length() - 1);
                else cur.append(' ');
            }
            cur.append(line);
            char last = line.charAt(line.length() - 1);
            if ((last == '.' || last == '!' || last == '?' || last == ':') && line.length() < 70) flush(d, cur);
        }
        flush(d, cur);
        return d;
    }

    private static void flush(DocIO.Doc d, StringBuilder cur) {
        String t = cur.toString().trim();
        if (!t.isEmpty()) d.paras.add(t);
        cur.setLength(0);
    }

    /** Crea un PDF A4 con el texto del documento, paginado automáticamente. */
    static void write(DocIO.Doc d, OutputStream os) throws Exception {
        if (d.rich != null && !d.rich.blocks.isEmpty()) { writeRich(d.rich, os); return; }      // v1.5: con su diseño
        int pageW = 595, pageH = 842, margin = 54, width = pageW - margin * 2, contentH = pageH - margin * 2 - 20;
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (d.title != null && !d.title.isEmpty()) {
            sb.append(d.title);
            sb.setSpan(new StyleSpan(Typeface.BOLD), 0, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new RelativeSizeSpan(1.6f), 0, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append("\n\n");
        }
        for (String p : d.paras) sb.append(p).append("\n\n");
        TextPaint tp = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
        tp.setColor(Color.BLACK);
        tp.setTextSize(12);
        StaticLayout layout = StaticLayout.Builder.obtain(sb, 0, sb.length(), tp, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(2f, 1f)
                .build();
        PdfDocument pdf = new PdfDocument();
        TextPaint foot = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
        foot.setColor(Color.GRAY);
        foot.setTextSize(9);
        int line = 0, total = layout.getLineCount(), pageNo = 1;
        while (line < total) {
            int top = layout.getLineTop(line);
            int end = layout.getLineForVertical(top + contentH);
            if (layout.getLineBottom(end) > top + contentH && end > line) end--;
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create());
            Canvas c = page.getCanvas();
            c.save();
            c.translate(margin, margin - top);
            c.clipRect(0, top, width, layout.getLineBottom(end));
            layout.draw(c);
            c.restore();
            c.drawText(String.valueOf(pageNo), pageW / 2f, pageH - 24, foot);
            pdf.finishPage(page);
            line = end + 1;
            pageNo++;
        }
        if (total == 0) {
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, 1).create());
            pdf.finishPage(page);
        }
        pdf.writeTo(os);
        pdf.close();
    }

    // ---------------- v1.5: PDF con el diseño del original ----------------
    /** Dibuja con Android (StaticLayout) lo que RichLayout reparte en páginas. */
    static final class AndroidEngine implements RichLayout.Engine {
        final Rich r;
        final PdfDocument pdf = new PdfDocument();
        PdfDocument.Page page;
        Canvas c;
        final Typeface reg, bold, ital, boldIt;
        final TextPaint foot = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);

        AndroidEngine(Rich r) {
            this.r = r;
            Typeface f = r.serif ? Typeface.SERIF : Typeface.SANS_SERIF;
            reg = Typeface.create(f, Typeface.NORMAL);
            bold = Typeface.create(f, Typeface.BOLD);
            ital = Typeface.create(f, Typeface.ITALIC);
            boldIt = Typeface.create(f, Typeface.BOLD_ITALIC);
            foot.setColor(Color.GRAY);
            foot.setTextSize(9);
            foot.setTextAlign(android.graphics.Paint.Align.CENTER);
        }

        public RichLayout.Para layout(Rich rr, Rich.Block b, float width) {
            SpannableStringBuilder sb = new SpannableStringBuilder(b.text);
            float main = b.runs.isEmpty() ? 1 : b.runs.get(0).size;
            int longest = -1;
            for (Rich.Run x : b.runs) {
                if (x.e - x.s > longest) { longest = x.e - x.s; main = x.size; }
                int fl = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE;
                sb.setSpan(new android.text.style.AbsoluteSizeSpan(Math.max(1, Math.round(x.size * r.basePt))), x.s, x.e, fl);
                Typeface tf = x.b && x.i ? boldIt : x.b ? bold : x.i ? ital : reg;
                if (tf != reg) sb.setSpan(new TypefaceSpan2(tf), x.s, x.e, fl);
                if (x.u) sb.setSpan(new android.text.style.UnderlineSpan(), x.s, x.e, fl);
                if (x.color != 0) sb.setSpan(new android.text.style.ForegroundColorSpan(x.color), x.s, x.e, fl);
                if (x.bg != 0) sb.setSpan(new android.text.style.BackgroundColorSpan(x.bg), x.s, x.e, fl);
                if (x.sup) sb.setSpan(new android.text.style.SuperscriptSpan(), x.s, x.e, fl);
                if (x.sub) sb.setSpan(new android.text.style.SubscriptSpan(), x.s, x.e, fl);
            }
            float ind = b.indent * r.basePt;
            if (Math.abs(ind) > 0.5f && b.text.length() > 0)
                sb.setSpan(new android.text.style.LeadingMarginSpan.Standard(Math.round(Math.max(0, ind)), Math.round(Math.max(0, -ind))), 0, b.text.length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE);
            TextPaint tp = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
            tp.setColor(Color.BLACK);
            tp.setTypeface(reg);
            tp.setTextSize(main * r.basePt);
            if (r.lang != null) try { tp.setTextLocale(java.util.Locale.forLanguageTag(r.lang)); } catch (Exception ignored) {}
            Layout.Alignment al = b.align == Rich.CENTER ? Layout.Alignment.ALIGN_CENTER : b.align == Rich.RIGHT ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL;
            StaticLayout.Builder lb = StaticLayout.Builder.obtain(sb, 0, sb.length(), tp, Math.max(10, Math.round(width)))
                    .setAlignment(al).setIncludePad(false).setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
                    .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NORMAL)
                    .setLineSpacing(0, Math.max(0.9f, Math.min(2.6f, b.lineH / 1.17f)));
            if (b.align == Rich.JUSTIFY) lb.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD);
            StaticLayout l = lb.build();
            return new RichLayout.Para() {
                public int lines() { return l.getLineCount(); }
                public float top(int i) { return l.getLineTop(i); }
                public float bottom(int i) { return l.getLineBottom(i); }
                public void draw(int from, int to, float x, float y) {
                    float t0 = l.getLineTop(from);
                    c.save();
                    c.translate(x, y - t0);
                    c.clipRect(-2, t0, width + 2, l.getLineBottom(to));
                    l.draw(c);
                    c.restore();
                }
            };
        }

        final java.util.Map<String, int[]> sizes = new java.util.HashMap<>();

        public int[] imageSize(String path) {
            int[] s = sizes.get(path);
            if (s != null) return s;
            byte[] b = r.images.get(path);
            if (b == null) return null;
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeByteArray(b, 0, b.length, o);
            s = new int[]{o.outWidth, o.outHeight};
            sizes.put(path, s);
            return s;
        }

        public void beginPage(int n, float w, float h) {
            page = pdf.startPage(new PdfDocument.PageInfo.Builder(Math.round(w), Math.round(h), n).create());
            c = page.getCanvas();
            c.drawColor(Color.WHITE);
        }

        public void endPage(int n, boolean num) {
            if (num) c.drawText(String.valueOf(n), page.getInfo().getPageWidth() / 2f, page.getInfo().getPageHeight() - 26, foot);
            pdf.finishPage(page);
        }

        public void drawImage(String path, float x, float y, float w, float h) {
            byte[] b = r.images.get(path);
            int[] s = imageSize(path);
            if (b == null || s == null) return;
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            int target = Math.round(w * 2.2f);                 // ~160 ppp: nítida sin hacer el PDF enorme
            o.inSampleSize = 1;
            while (s[0] / (o.inSampleSize * 2) >= target) o.inSampleSize *= 2;
            Bitmap bm = null;
            try { bm = android.graphics.BitmapFactory.decodeByteArray(b, 0, b.length, o); } catch (OutOfMemoryError ignored) {}
            if (bm == null) return;
            android.graphics.Paint pp = new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG | android.graphics.Paint.ANTI_ALIAS_FLAG);
            c.drawBitmap(bm, null, new android.graphics.RectF(x, y, x + w, y + h), pp);
            bm.recycle();
        }
    }

    /** Cambia la letra (negrita/cursiva de la misma familia). */
    static final class TypefaceSpan2 extends android.text.style.MetricAffectingSpan {
        final Typeface tf;
        TypefaceSpan2(Typeface tf) { this.tf = tf; }
        @Override public void updateDrawState(TextPaint p) { p.setTypeface(tf); }
        @Override public void updateMeasureState(TextPaint p) { p.setTypeface(tf); }
    }

    /** Devuelve qué bloques hay en cada página. */
    static java.util.List<int[]> writeRich(Rich r, OutputStream os) throws Exception {
        AndroidEngine e = new AndroidEngine(r);
        RichLayout lay = new RichLayout();
        lay.render(r, e);
        e.pdf.writeTo(os);
        e.pdf.close();
        return lay.pages;
    }

    // ---------------- páginas como imágenes ----------------
    static class Pages {
        ParcelFileDescriptor fd;
        PdfRenderer renderer;

        Pages(Context ctx, Uri uri) throws Exception {
            if ("file".equals(uri.getScheme())) {
                fd = ParcelFileDescriptor.open(new File(uri.getPath()), ParcelFileDescriptor.MODE_READ_ONLY);
            } else {
                fd = ctx.getContentResolver().openFileDescriptor(uri, "r");
            }
            renderer = new PdfRenderer(fd);
        }

        int count() { return renderer.getPageCount(); }

        synchronized Bitmap render(int index, int width) {
            try (PdfRenderer.Page page = renderer.openPage(index)) {
                int h = Math.round(width * page.getHeight() / (float) page.getWidth());
                Bitmap b = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888);
                b.eraseColor(Color.WHITE);
                page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                return b;
            } catch (Exception | OutOfMemoryError e) {
                return null;
            }
        }

        void close() {
            try { renderer.close(); } catch (Exception ignored) {}
            try { fd.close(); } catch (Exception ignored) {}
        }
    }

    // ---------------- abrir cualquier documento ----------------
    static DocIO.Doc load(Context ctx, Uri uri) throws Exception {
        String name = Media.nameOf(ctx, uri);
        String type = DocIO.typeOf(name);
        if (type == null) type = "txt";
        String title = DocIO.baseName(name);
        if (type.equals("pdf")) return read(ctx, uri, title);
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            switch (type) {
                case "epub": return DocIO.readEpub(in, title);
                case "docx": return DocIO.readDocx(in, title);
                case "html": return DocIO.readHtml(in, title);
                default: return DocIO.readTxt(in, title);
            }
        }
    }

    /** Guarda el documento en el formato pedido dentro de SSS+/Documentos. */
    static Uri saveAs(Context ctx, DocIO.Doc d, String format) throws Exception { return saveAs(ctx, d, format, ""); }

    /** «suffix» se añade al nombre (por ejemplo «_IT» para la copia traducida). */
    static Uri saveAs(Context ctx, DocIO.Doc d, String format, String suffix) throws Exception {
        String name = (d.title == null || d.title.trim().isEmpty() ? "documento" : d.title.trim().replaceAll("[\\\\/:*?\"<>|]", "_"))
                + suffix + "_" + Media.stamp() + "." + format;
        File tmp = new File(ctx.getCacheDir(), "doc_" + System.currentTimeMillis() + "." + format);
        try (FileOutputStream fos = new FileOutputStream(tmp)) {
            switch (format) {
                case "pdf": write(d, fos); break;
                // v1.5: si se sabe el diseño del original, se conserva
                case "epub": if (d.rich != null && !d.rich.blocks.isEmpty()) RichWrite.epub(d.rich, d.title, d.rich.lang, fos); else DocIO.writeEpub(d, fos); break;
                case "docx": if (d.rich != null && !d.rich.blocks.isEmpty()) RichWrite.docx(d.rich, d.title, fos); else DocIO.writeDocx(d, fos); break;
                default: DocIO.writeTxt(d, fos);
            }
        }
        return Media.saveDoc(ctx, tmp, name, DocIO.mime(format));
    }
}
