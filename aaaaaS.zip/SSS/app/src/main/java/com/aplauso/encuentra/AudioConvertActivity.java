package com.aplauso.encuentra;

import android.content.Intent;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * 🔄 CAMBIAR FORMATO DE AUDIO (v1.2), sin apps externas: cualquier audio que el teléfono sepa reproducir
 * (MP3, M4A, OGG, FLAC, WAV, AMR… y el sonido de un vídeo) a WAV, M4A (AAC), OGG (Opus) o FLAC.
 * Todo con los codificadores que trae Android.
 */
public class AudioConvertActivity extends NeonActivity {
    static final int REQ_AUDIO = 81;
    static final String[] FORMATS = {"WAV (sin pérdida, pesa mucho)", "M4A · AAC (como en iPhone/YouTube)", "OGG · Opus (muy ligero)", "FLAC (sin pérdida, pesa menos que WAV)"};
    static final String[] EXT = {"wav", "m4a", "ogg", "flac"};
    static final String[] MIME = {"audio/wav", "audio/mp4", "audio/ogg", "audio/flac"};
    static final int[] KBPS = {96, 128, 192, 256, 320};
    int fmt = 1, q = 2;
    Uri src;
    String name = "audio";
    TextView info, fmtBtn, qBtn;
    volatile boolean busy;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🔄 CAMBIAR FORMATO");
        LinearLayout pn = panel("◢ AUDIO");
        info = text(L.t("Elige un audio (o un vídeo, para sacar su sonido)."), 13);
        pn.addView(info);
        pn.addView(button("🎵 ELEGIR AUDIO O VÍDEO", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                    .putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
            startActivityForResult(i, REQ_AUDIO);
        }), gapBelow(10));
        fmtBtn = button("", v -> { fmt = (fmt + 1) % FORMATS.length; labels(); });
        pn.addView(fmtBtn, gapBelow(8));
        qBtn = button("", v -> { q = (q + 1) % KBPS.length; labels(); });
        pn.addView(qBtn, gapBelow(8));
        pn.addView(button("✨ CONVERTIR", v -> convert()), gapBelow(8));
        pn.addView(text("MP3: Android no trae un codificador de MP3, así que por ahora se puede convertir DESDE MP3 pero no A MP3. "
                + "M4A suena igual o mejor que un MP3 del mismo tamaño y lo abren todos los reproductores.", 11));
        col.addView(pn, gapBelow(14));
        labels();
        Uri in = getIntent().getData();
        if (in != null) setSrc(in);
    }

    void labels() {
        fmtBtn.setText(L.t("Formato: ") + L.t(FORMATS[fmt]));
        boolean lossy = fmt == 1 || fmt == 2;
        qBtn.setText(lossy ? L.t("Calidad: ") + KBPS[q] + " kbps" : L.t("Calidad: máxima (sin pérdida)"));
        qBtn.setAlpha(lossy ? 1f : 0.5f);
    }

    @Override
    protected void onActivityResult(int req, int res, android.content.Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_AUDIO && res == RESULT_OK && data != null && data.getData() != null) setSrc(data.getData());
    }

    void setSrc(Uri u) {
        src = u;
        name = Media.nameOf(this, u).replaceAll("\\.[^.]+$", "");
        long ms = MediaTools.durationMs(this, u);
        info.setText("🎵 " + Media.nameOf(this, u) + (ms > 0 ? String.format(java.util.Locale.US, "  ·  %d:%02d", ms / 60000, ms / 1000 % 60) : ""));
    }

    void convert() {
        if (src == null) { toast("Primero elige un audio."); return; }
        if (busy) return;
        if (fmt == 2 && Build.VERSION.SDK_INT < 29) { toast("OGG necesita Android 10 o superior."); return; }
        busy = true;
        info.setText(L.t("Convirtiendo… 0 %"));
        final int f = fmt, kb = KBPS[q];
        new Thread(() -> {
            File wav = new File(getCacheDir(), "conv_" + System.currentTimeMillis() + ".wav");
            File out = new File(getCacheDir(), "conv_out_" + System.currentTimeMillis() + "." + EXT[f]);
            String msg;
            try {
                long ms = Math.max(1, MediaTools.durationMs(this, src));
                MediaTools.toWav(this, src, wav, 0, ms * 1000 + 1_000_000, 1f, 0, 0, fr -> progress(fr * 0.5f));
                if (f == 0) { wav.renameTo(out); }
                else if (f == 1) encodeMux(wav, out, "audio/mp4a-latm", kb, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4, 0);
                else if (f == 2) encodeMux(wav, out, "audio/opus", kb, 2 /* MUXER_OUTPUT_OGG */, 48000);
                else encodeFlac(wav, out);
                Uri saved = Media.save(this, out, Media.TYPE_AUDIO, name + "." + EXT[f], MIME[f]);
                msg = saved != null ? L.t("✓ Guardado en SSS+/Música: ") + name + "." + EXT[f] : L.t("No se pudo guardar.");
            } catch (Throwable e) {
                msg = L.t("No se pudo convertir: ") + e.getMessage();
            } finally {
                wav.delete();
                if (out.exists()) out.delete();
            }
            String m = msg;
            runOnUiThread(() -> { info.setText(m); busy = false; });
        }, "convertir").start();
    }

    void progress(float k) { runOnUiThread(() -> info.setText(L.t("Convirtiendo… ") + Math.round(k * 100) + " %")); }

    // ---------------- WAV de entrada (16 bits) ----------------
    static final class Wav { int rate, ch; long dataPos, dataLen; }

    static Wav readHeader(RandomAccessFile f) throws Exception {
        byte[] h = new byte[12];
        f.seek(0);
        f.readFully(h);
        Wav w = new Wav();
        long pos = 12;
        byte[] ck = new byte[8];
        while (pos + 8 <= f.length()) {
            f.seek(pos);
            f.readFully(ck);
            ByteBuffer b = ByteBuffer.wrap(ck).order(ByteOrder.LITTLE_ENDIAN);
            int id = b.getInt(0), len = b.getInt(4);
            if (id == 0x20746d66) {
                byte[] fm = new byte[16];
                f.readFully(fm);
                ByteBuffer m = ByteBuffer.wrap(fm).order(ByteOrder.LITTLE_ENDIAN);
                w.ch = m.getShort(2);
                w.rate = m.getInt(4);
            } else if (id == 0x61746164) {
                w.dataPos = pos + 8;
                w.dataLen = Math.min(len & 0xFFFFFFFFL, f.length() - w.dataPos);
                return w;
            }
            pos += 8 + (len & 0xFFFFFFFFL) + (len & 1);
        }
        throw new Exception("WAV sin datos");
    }

    /** Codifica con MediaCodec y lo mete en un contenedor (M4A u OGG). outRate > 0 = cambiar la frecuencia (Opus usa 48 kHz). */
    void encodeMux(File wavF, File out, String mime, int kbps, int container, int outRate) throws Exception {
        try (RandomAccessFile in = new RandomAccessFile(wavF, "r")) {
            Wav w = readHeader(in);
            int ch = Math.min(2, Math.max(1, w.ch));
            int rate = outRate > 0 ? outRate : w.rate;
            MediaFormat mf = MediaFormat.createAudioFormat(mime, rate, ch);
            mf.setInteger(MediaFormat.KEY_BIT_RATE, kbps * 1000);
            if (mime.equals("audio/mp4a-latm")) mf.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            mf.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 << 16);
            MediaCodec enc = MediaCodec.createEncoderByType(mime);
            enc.configure(mf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();
            MediaMuxer mux = new MediaMuxer(out.getAbsolutePath(), container);
            int trackIdx = -1;
            boolean muxing = false;
            Resampler rs = new Resampler(w.rate, rate, w.ch, ch);
            long fed = 0, totalIn = w.dataLen;
            in.seek(w.dataPos);
            byte[] raw = new byte[8192 * Math.max(1, w.ch)];
            long outFrames = 0;
            boolean inDone = false, outDone = false;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            byte[] pending = new byte[0];
            int pendingOff = 0;
            try {
                while (!outDone) {
                    if (!inDone) {
                        int ii = enc.dequeueInputBuffer(5000);
                        if (ii >= 0) {
                            ByteBuffer ib = enc.getInputBuffer(ii);
                            ib.clear();
                            if (pendingOff >= pending.length && fed < totalIn) {
                                int n = in.read(raw, 0, (int) Math.min(raw.length, totalIn - fed));
                                if (n > 0) { fed += n; pending = rs.process(raw, n); pendingOff = 0; }
                                else fed = totalIn;
                            }
                            int len = Math.min(ib.remaining(), pending.length - pendingOff);
                            len -= len % (2 * ch);
                            long pts = outFrames * 1_000_000L / rate;
                            if (len > 0) {
                                ib.put(pending, pendingOff, len);
                                pendingOff += len;
                                outFrames += len / (2 * ch);
                                enc.queueInputBuffer(ii, 0, len, pts, 0);
                            } else if (fed >= totalIn) {
                                enc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inDone = true;
                            } else enc.queueInputBuffer(ii, 0, 0, pts, 0);
                            if (totalIn > 0 && (fed & 0xFFFF) < raw.length) progress(0.5f + 0.5f * fed / totalIn);
                        }
                    }
                    int oi = enc.dequeueOutputBuffer(info, 5000);
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        trackIdx = mux.addTrack(enc.getOutputFormat());
                        mux.start();
                        muxing = true;
                    } else if (oi >= 0) {
                        ByteBuffer ob = enc.getOutputBuffer(oi);
                        if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                        if (info.size > 0 && muxing) {
                            ob.position(info.offset);
                            ob.limit(info.offset + info.size);
                            mux.writeSampleData(trackIdx, ob, info);
                        }
                        enc.releaseOutputBuffer(oi, false);
                        if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                    }
                }
            } finally {
                try { enc.stop(); } catch (Exception ignored) {}
                enc.release();
                try { if (muxing) mux.stop(); } catch (Exception ignored) {}
                mux.release();
            }
        }
    }

    /** FLAC: el codificador de Android ya da el archivo completo (cabecera «fLaC» + tramas): se escribe tal cual. */
    void encodeFlac(File wavF, File out) throws Exception {
        try (RandomAccessFile in = new RandomAccessFile(wavF, "r"); FileOutputStream fo = new FileOutputStream(out)) {
            Wav w = readHeader(in);
            int ch = Math.min(2, Math.max(1, w.ch));
            MediaFormat mf = MediaFormat.createAudioFormat("audio/flac", w.rate, ch);
            mf.setInteger(MediaFormat.KEY_FLAC_COMPRESSION_LEVEL, 5);
            mf.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 << 16);
            MediaCodec enc = MediaCodec.createEncoderByType("audio/flac");
            enc.configure(mf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();
            Resampler rs = new Resampler(w.rate, w.rate, w.ch, ch);
            long fed = 0, total = w.dataLen, frames = 0;
            in.seek(w.dataPos);
            byte[] raw = new byte[8192 * Math.max(1, w.ch)];
            byte[] pending = new byte[0];
            int off = 0;
            boolean inDone = false, outDone = false;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            byte[] tmp = new byte[1 << 16];
            try {
                while (!outDone) {
                    if (!inDone) {
                        int ii = enc.dequeueInputBuffer(5000);
                        if (ii >= 0) {
                            ByteBuffer ib = enc.getInputBuffer(ii);
                            ib.clear();
                            if (off >= pending.length && fed < total) {
                                int n = in.read(raw, 0, (int) Math.min(raw.length, total - fed));
                                if (n > 0) { fed += n; pending = rs.process(raw, n); off = 0; } else fed = total;
                            }
                            int len = Math.min(ib.remaining(), pending.length - off);
                            len -= len % (2 * ch);
                            long pts = frames * 1_000_000L / w.rate;
                            if (len > 0) { ib.put(pending, off, len); off += len; frames += len / (2 * ch); enc.queueInputBuffer(ii, 0, len, pts, 0); }
                            else if (fed >= total) { enc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true; }
                            else enc.queueInputBuffer(ii, 0, 0, pts, 0);
                            if (total > 0) progress(0.5f + 0.5f * fed / total);
                        }
                    }
                    int oi = enc.dequeueOutputBuffer(info, 5000);
                    if (oi >= 0) {
                        ByteBuffer ob = enc.getOutputBuffer(oi);
                        if (info.size > 0) {
                            ob.position(info.offset);
                            if (tmp.length < info.size) tmp = new byte[info.size];
                            ob.get(tmp, 0, info.size);
                            fo.write(tmp, 0, info.size);
                        }
                        enc.releaseOutputBuffer(oi, false);
                        if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                    }
                }
            } finally {
                try { enc.stop(); } catch (Exception ignored) {}
                enc.release();
            }
        }
        // comprobar que empieza por «fLaC»
        try (java.io.FileInputStream fi = new java.io.FileInputStream(out)) {
            byte[] h = new byte[4];
            if (fi.read(h) < 4 || h[0] != 'f' || h[1] != 'L' || h[2] != 'a' || h[3] != 'C') throw new Exception(L.t("este teléfono no crea FLAC válidos; prueba con WAV o M4A"));
        }
    }

    /** Pasa de 16 bits entrelazados a otra frecuencia y a mono/estéreo (interpolación lineal, por trozos). */
    static final class Resampler {
        final int inRate, outRate, inCh, outCh;
        double pos;                  // posición en muestras de entrada (relativa al trozo)
        short[] last;                // última muestra del trozo anterior
        Resampler(int ir, int or, int ic, int oc) { inRate = ir; outRate = or; inCh = ic; outCh = oc; }

        byte[] process(byte[] raw, int n) {
            int frames = n / (2 * inCh);
            short[] s = new short[(frames + 1) * outCh];
            ByteBuffer b = ByteBuffer.wrap(raw, 0, n).order(ByteOrder.LITTLE_ENDIAN);
            // muestras de entrada convertidas a los canales de salida, con la última del trozo anterior delante
            int off = last == null ? 0 : 1;
            int total = frames + off;
            short[] f = new short[total * outCh];
            if (last != null) System.arraycopy(last, 0, f, 0, outCh);
            for (int i = 0; i < frames; i++) {
                int l = b.getShort((i * inCh) * 2), r = inCh > 1 ? b.getShort((i * inCh + 1) * 2) : l;
                if (outCh == 1) f[(i + off)] = (short) ((l + r) / 2);
                else { f[(i + off) * 2] = (short) l; f[(i + off) * 2 + 1] = (short) r; }
            }
            if (inRate == outRate) {
                last = null;
                ByteBuffer o = ByteBuffer.allocate(frames * outCh * 2).order(ByteOrder.LITTLE_ENDIAN);
                for (int i = off * outCh; i < total * outCh; i++) o.putShort(f[i]);
                return o.array();
            }
            double step = (double) inRate / outRate;
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(frames * outCh * 2 * outRate / inRate + 16);
            double p = pos;
            while (p + 1 < total) {
                int a = (int) p;
                double k = p - a;
                for (int c = 0; c < outCh; c++) {
                    int v = (int) Math.round(f[a * outCh + c] * (1 - k) + f[(a + 1) * outCh + c] * k);
                    bo.write(v & 0xFF);
                    bo.write((v >> 8) & 0xFF);
                }
                p += step;
            }
            pos = p - (total - 1);
            last = new short[outCh];
            System.arraycopy(f, (total - 1) * outCh, last, 0, outCh);
            return bo.toByteArray();
        }
    }
}
