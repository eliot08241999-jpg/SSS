package com.aplauso.encuentra;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * v1.6 · CEREBRO GEMINI (opcional, en la nube). Con internet y tu clave gratuita de Google AI Studio, Chloe piensa con
 * Gemini (mucho más lista, y busca en Google mientras contesta); sin internet, o si se acaba el cupo, vuelve sola al
 * cerebro del teléfono. Lo del trabajo (tus asistencias) nunca se manda.
 */
public class Gemini {
    static final String[] MODELS = {"gemini-flash-latest", "gemini-2.5-flash", "gemini-2.0-flash"};
    static volatile String workingModel;

    static boolean on(Context c) { return Brain.prefs(c).getBoolean("ai_cloud", false) && !key(c).isEmpty(); }
    static String key(Context c) { return Brain.prefs(c).getString("ai_gemini_key", "").trim(); }

    public static final class Reply { public String text; public final java.util.ArrayList<String[]> sources = new java.util.ArrayList<>(); }

    /**
     * Pregunta a Gemini. hist = la conversación ({rol, texto[, "p"]}); las entradas marcadas «p» (privadas) no se mandan.
     * search = que pueda buscar en Google.
     */
    static Reply ask(Context c, String system, List<String[]> hist, String user, boolean search, int maxTokens) throws Exception {
        JSONObject body = new JSONObject();
        body.put("system_instruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system))));
        JSONArray contents = new JSONArray();
        int from = Math.max(0, hist.size() - 16);
        String lastRole = null;
        for (int i = from; i < hist.size(); i++) {
            String[] h = hist.get(i);
            if (h.length > 2) continue;                                   // del trabajo: no sale del teléfono
            String role = h[0].equals("model") ? "model" : "user";
            String t = Brain.speech(h[1]);
            if (t.isEmpty()) continue;
            if (role.equals(lastRole)) {                                   // Gemini quiere turnos alternos
                JSONObject prev = contents.getJSONObject(contents.length() - 1);
                JSONObject part = prev.getJSONArray("parts").getJSONObject(0);
                part.put("text", part.getString("text") + "\n" + t);
                continue;
            }
            if (contents.length() == 0 && role.equals("model")) continue;
            contents.put(new JSONObject().put("role", role).put("parts", new JSONArray().put(new JSONObject().put("text", t))));
            lastRole = role;
        }
        if ("user".equals(lastRole)) {
            JSONObject prev = contents.getJSONObject(contents.length() - 1);
            JSONObject part = prev.getJSONArray("parts").getJSONObject(0);
            part.put("text", part.getString("text") + "\n" + user);
        } else contents.put(new JSONObject().put("role", "user").put("parts", new JSONArray().put(new JSONObject().put("text", user))));
        body.put("contents", contents);
        if (search) body.put("tools", new JSONArray().put(new JSONObject().put("google_search", new JSONObject())));
        body.put("generationConfig", new JSONObject().put("maxOutputTokens", maxTokens).put("temperature", 0.8));
        JSONArray safety = new JSONArray();
        for (String cat : new String[]{"HARM_CATEGORY_HARASSMENT", "HARM_CATEGORY_HATE_SPEECH", "HARM_CATEGORY_DANGEROUS_CONTENT", "HARM_CATEGORY_SEXUALLY_EXPLICIT"})
            safety.put(new JSONObject().put("category", cat).put("threshold", "BLOCK_ONLY_HIGH"));
        body.put("safetySettings", safety);

        Exception last = null;
        String[] order = workingModel != null ? new String[]{workingModel} : MODELS;
        for (String m : order) {
            try {
                Reply r = call(c, m, body.toString());
                workingModel = m;
                return r;
            } catch (NotFound e) { last = e; }
        }
        if (workingModel != null) { workingModel = null; return ask(c, system, hist, user, search, maxTokens); }
        throw last != null ? last : new Exception("sin modelo");
    }

    static final class NotFound extends Exception { NotFound(String m) { super(m); } }

    static Reply call(Context c, String model, String json) throws Exception {
        URL u = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
        HttpURLConnection con = (HttpURLConnection) u.openConnection();
        con.setConnectTimeout(8000);
        con.setReadTimeout(40000);
        con.setRequestMethod("POST");
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        con.setRequestProperty("x-goog-api-key", key(c));
        try (OutputStream os = con.getOutputStream()) { os.write(json.getBytes(StandardCharsets.UTF_8)); }
        int code = con.getResponseCode();
        String resp = Brain.read(code >= 400 ? con.getErrorStream() : con.getInputStream());
        if (code == 404) throw new NotFound(model);
        if (code == 429) throw new Exception(L.t("Gemini: se acabó el cupo gratis por ahora"));
        if (code == 400 && resp.contains("API_KEY_INVALID")) throw new Exception(L.t("Gemini: la clave no es válida"));
        if (code >= 400) {
            String msg = resp;
            try { msg = new JSONObject(resp).getJSONObject("error").optString("message", resp); } catch (Exception ignored) {}
            throw new Exception("Gemini " + code + ": " + (msg.length() > 160 ? msg.substring(0, 160) : msg));
        }
        JSONObject o = new JSONObject(resp);
        JSONArray cands = o.optJSONArray("candidates");
        if (cands == null || cands.length() == 0) throw new Exception(L.t("Gemini no ha respondido"));
        JSONObject cand = cands.getJSONObject(0);
        Reply r = new Reply();
        StringBuilder t = new StringBuilder();
        JSONObject content = cand.optJSONObject("content");
        JSONArray parts = content == null ? null : content.optJSONArray("parts");
        if (parts != null) for (int i = 0; i < parts.length(); i++) t.append(parts.getJSONObject(i).optString("text"));
        r.text = t.toString().trim();
        JSONObject gm = cand.optJSONObject("groundingMetadata");
        if (gm != null) {
            JSONArray ch = gm.optJSONArray("groundingChunks");
            if (ch != null) for (int i = 0; i < ch.length() && r.sources.size() < 4; i++) {
                JSONObject w = ch.getJSONObject(i).optJSONObject("web");
                if (w != null) r.sources.add(new String[]{w.optString("title"), w.optString("uri")});
            }
        }
        if (r.text.isEmpty()) throw new Exception(L.t("Gemini no ha respondido") + " (" + cand.optString("finishReason") + ")");
        return r;
    }

    /** Para el botón PROBAR de los ajustes. */
    static String test(Context c) throws Exception {
        Reply r = ask(c, "Responde en una frase corta.", new java.util.ArrayList<>(), "Di hola y qué modelo eres.", false, 60);
        return "✓ " + workingModel + ": " + r.text;
    }
}
