package com.aplauso.encuentra;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * 📸 CÁMARA CON TEMPORIZADOR (v1.3): «Hola Chloe, hazme una foto en 5 segundos».
 * Deja el teléfono apuntándote, y Chloe cuenta en voz alta y con pitidos y dispara sola: así sale todo el mundo en la foto.
 * Guarda en la galería (Imágenes/SSS+). Funciona también con el teléfono bloqueado, como la cámara del sistema.
 */
public class ChloeCamActivity extends Activity {
    static final String EXTRA_SECONDS = "seconds", EXTRA_FRONT = "front", EXTRA_COUNT = "count";
    static final int REQ_CAM = 61;

    TextureView view;
    TextView big, status;
    CameraDevice cam;
    CameraCaptureSession session;
    ImageReader reader;
    HandlerThread bgT;
    Handler bg;
    final Handler ui = new Handler(Looper.getMainLooper());
    boolean front;
    int seconds, shotsLeft, sensorDeg;
    Size jpegSize;
    ToneGenerator tone;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        L.init(this);
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        seconds = Math.max(0, Math.min(60, getIntent().getIntExtra(EXTRA_SECONDS, 5)));
        front = getIntent().getBooleanExtra(EXTRA_FRONT, false);
        shotsLeft = Math.max(1, Math.min(10, getIntent().getIntExtra(EXTRA_COUNT, 1)));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        view = new TextureView(this);
        root.addView(view, new FrameLayout.LayoutParams(-1, -1));
        big = new TextView(this);
        big.setTextColor(Color.WHITE);
        big.setTextSize(140);
        big.setGravity(Gravity.CENTER);
        big.setShadowLayer(18, 0, 0, Color.BLACK);
        root.addView(big, new FrameLayout.LayoutParams(-1, -1));
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(0x88000000);
        status.setPadding(20, 24, 20, 24);
        root.addView(status, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER);
        bar.setBackgroundColor(0x88000000);
        bar.setPadding(10, 16, 10, 16);
        bar.addView(btn("🔄", v -> { front = !front; reopen(); }));
        bar.addView(btn("⏱ " + seconds + " s", v -> { seconds = seconds >= 10 ? 3 : seconds == 3 ? 5 : 10; ((TextView) v).setText("⏱ " + seconds + " s"); }));
        bar.addView(btn("📸", v -> countdown()));
        bar.addView(btn("✕", v -> finish()));
        root.addView(bar, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        setContentView(root);
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 90); } catch (Exception ignored) {}
    }

    TextView btn(String s, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(24);
        t.setPadding(36, 12, 36, 12);
        t.setOnClickListener(l);
        return t;
    }

    @Override
    protected void onResume() {
        super.onResume();
        bgT = new HandlerThread("camara");
        bgT.start();
        bg = new Handler(bgT.getLooper());
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM);
            return;
        }
        startWhenReady();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] p, int[] r) {
        super.onRequestPermissionsResult(req, p, r);
        if (req == REQ_CAM && r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) startWhenReady();
        else { status.setText(L.t("Necesito permiso de cámara.")); }
    }

    boolean autoStarted;

    void startWhenReady() {
        if (view.isAvailable()) open();
        else view.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { open(); }
            public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) {}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { return true; }
            public void onSurfaceTextureUpdated(SurfaceTexture s) {}
        });
    }

    @Override
    protected void onPause() {
        ui.removeCallbacksAndMessages(null);
        close();
        if (bgT != null) { bgT.quitSafely(); bgT = null; }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (tone != null) tone.release();
        super.onDestroy();
    }

    void reopen() { close(); open(); }

    void close() {
        try { if (session != null) session.close(); } catch (Exception ignored) {}
        try { if (cam != null) cam.close(); } catch (Exception ignored) {}
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        session = null; cam = null; reader = null;
    }

    @SuppressWarnings("MissingPermission")
    void open() {
        try {
            CameraManager cm = getSystemService(CameraManager.class);
            String id = null;
            for (String c : cm.getCameraIdList()) {
                Integer f = cm.getCameraCharacteristics(c).get(CameraCharacteristics.LENS_FACING);
                if (f != null && f == (front ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK)) { id = c; break; }
            }
            if (id == null) id = cm.getCameraIdList()[0];
            CameraCharacteristics ch = cm.getCameraCharacteristics(id);
            Integer so = ch.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorDeg = so == null ? 90 : so;
            StreamConfigurationMap map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size[] js = map.getOutputSizes(ImageFormat.JPEG);
            Arrays.sort(js, (a, b2) -> Long.compare((long) b2.getWidth() * b2.getHeight(), (long) a.getWidth() * a.getHeight()));
            jpegSize = js[0];
            for (Size s : js) if ((long) s.getWidth() * s.getHeight() <= 13_000_000L) { jpegSize = s; break; }   // hasta ~12 MP
            Size prev = new Size(1920, 1080);
            for (Size s : map.getOutputSizes(SurfaceTexture.class)) {
                float r = (float) s.getWidth() / s.getHeight(), jr = (float) jpegSize.getWidth() / jpegSize.getHeight();
                if (Math.abs(r - jr) < 0.05f && s.getWidth() <= 1920) { prev = s; break; }
            }
            reader = ImageReader.newInstance(jpegSize.getWidth(), jpegSize.getHeight(), ImageFormat.JPEG, 2);
            reader.setOnImageAvailableListener(this::saveImage, bg);
            final Size pv = prev;
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice d) { cam = d; startPreview(pv); }
                @Override public void onDisconnected(CameraDevice d) { d.close(); }
                @Override public void onError(CameraDevice d, int e) { d.close(); ui.post(() -> status.setText(L.t("No puedo abrir la cámara."))); }
            }, bg);
        } catch (Exception e) {
            status.setText(L.t("No puedo abrir la cámara: ") + e.getMessage());
        }
    }

    void startPreview(Size pv) {
        try {
            SurfaceTexture st = view.getSurfaceTexture();
            st.setDefaultBufferSize(pv.getWidth(), pv.getHeight());
            Surface s = new Surface(st);
            CaptureRequest.Builder rb = cam.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            rb.addTarget(s);
            rb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            cam.createCaptureSession(Arrays.asList(s, reader.getSurface()), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession cs) {
                    session = cs;
                    try { cs.setRepeatingRequest(rb.build(), null, bg); } catch (Exception ignored) {}
                    ui.post(() -> {
                        fitPreview(pv);
                        if (!autoStarted) { autoStarted = true; countdown(); }
                        else status.setText(L.t("Pulsa 📸 o dile a Chloe «hazme otra foto»."));
                    });
                }
                @Override public void onConfigureFailed(CameraCaptureSession cs) { ui.post(() -> status.setText(L.t("No puedo abrir la cámara."))); }
            }, bg);
        } catch (Exception e) {
            ui.post(() -> status.setText(L.t("No puedo abrir la cámara: ") + e.getMessage()));
        }
    }

    /** Ajusta la vista previa para que no se vea estirada (vertical). */
    void fitPreview(Size pv) {
        int vw = view.getWidth(), vh = view.getHeight();
        if (vw == 0 || vh == 0) return;
        float pw = pv.getHeight(), ph = pv.getWidth();       // en vertical van girados
        float k = Math.max(vw / pw, vh / ph);
        android.graphics.Matrix m = new android.graphics.Matrix();
        m.setScale(pw * k / vw, ph * k / vh, vw / 2f, vh / 2f);
        view.setTransform(m);
    }

    // ---------------- cuenta atrás y disparo ----------------
    void countdown() {
        if (session == null) return;
        ui.removeCallbacksAndMessages(null);
        status.setText(seconds > 0 ? L.t("¡Colocaos! Disparo en") + " " + seconds + " s" : "");
        tick(seconds);
    }

    void tick(int n) {
        if (n <= 0) { big.setText(""); shoot(); return; }
        big.setText(String.valueOf(n));
        big.setScaleX(1.4f); big.setScaleY(1.4f);
        big.animate().scaleX(1f).scaleY(1f).setDuration(400).start();
        if (tone != null) tone.startTone(n <= 3 ? ToneGenerator.TONE_PROP_BEEP2 : ToneGenerator.TONE_PROP_BEEP, n <= 3 ? 220 : 120);
        if (n <= 3) Voice.say(this, String.valueOf(n));
        ui.postDelayed(() -> tick(n - 1), 1000);
    }

    void shoot() {
        try {
            CaptureRequest.Builder cb = cam.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            cb.addTarget(reader.getSurface());
            cb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            cb.set(CaptureRequest.JPEG_ORIENTATION, jpegRotation());
            cb.set(CaptureRequest.JPEG_QUALITY, (byte) 95);
            session.capture(cb.build(), null, bg);
            if (tone != null) tone.startTone(ToneGenerator.TONE_PROP_ACK, 150);
            // destello blanco
            View flash = new View(this);
            flash.setBackgroundColor(Color.WHITE);
            ((FrameLayout) view.getParent()).addView(flash, new FrameLayout.LayoutParams(-1, -1));
            flash.animate().alpha(0f).setDuration(350).withEndAction(() -> ((FrameLayout) view.getParent()).removeView(flash)).start();
        } catch (Exception e) {
            status.setText(L.t("No se pudo hacer la foto: ") + e.getMessage());
        }
    }

    int jpegRotation() {
        int disp = 0;   // la app va en vertical
        return front ? (sensorDeg + disp) % 360 : (sensorDeg - disp + 360) % 360;
    }

    void saveImage(ImageReader r) {
        try (Image img = r.acquireLatestImage()) {
            if (img == null) return;
            ByteBuffer buf = img.getPlanes()[0].getBuffer();
            byte[] data = new byte[buf.remaining()];
            buf.get(data);
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "SSS_foto_" + Media.stamp() + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SSS+");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            try (OutputStream os = getContentResolver().openOutputStream(u)) { os.write(data); }
            shotsLeft--;
            ui.post(() -> {
                status.setText(L.t("✓ Foto guardada en Imágenes/SSS+") + (shotsLeft > 0 ? " · " + L.t("otra en") + " " + Math.max(3, seconds) + " s" : ""));
                Voice.say(this, shotsLeft > 0 ? L.t("¡Otra!") : L.t("¡Listo! Foto guardada."));
                if (shotsLeft > 0) ui.postDelayed(() -> tick(Math.max(3, Math.min(seconds, 5))), 1200);
            });
        } catch (Exception e) {
            ui.post(() -> status.setText(L.t("No se pudo guardar la foto: ") + e.getMessage()));
        }
    }
}
