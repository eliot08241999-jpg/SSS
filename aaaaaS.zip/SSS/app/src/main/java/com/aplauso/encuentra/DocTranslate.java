package com.aplauso.encuentra;

import android.content.Context;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * v1.5 · TRADUCIR UN DOCUMENTO entre español, italiano e inglés sin romper su estructura: se traduce bloque a bloque
 * (cada párrafo, título, línea…), y cada trozo conserva su formato (negrita, tamaño, color, alineación…), sus imágenes y
 * sus saltos de página. Usa el traductor de Google que funciona DENTRO del teléfono (ML Kit): gratis, y después de bajar
 * cada idioma (unos 30 MB, una sola vez) funciona sin internet; el documento no sale del móvil.
 */
public class DocTranslate {
    public interface Fn { String tr(String s) throws Exception; }
    public interface Progress { void at(int done, int total); }
    static volatile boolean cancel;

    static final String[] LANGS = {"es", "it", "en"};

    static String mk(String l) { return "it".equals(l) ? TranslateLanguage.ITALIAN : "en".equals(l) ? TranslateLanguage.ENGLISH : TranslateLanguage.SPANISH; }

    /** Idioma del documento (es, it o en), mirando un buen trozo de su texto. */
    static String detect(DocIO.Doc d) {
        StringBuilder sb = new StringBuilder();
        List<String> ps = d.rich != null ? d.rich.paras() : d.paras;
        for (String p : ps) { if (p.length() > 40) sb.append(p).append(' '); if (sb.length() > 6000) break; }
        if (sb.length() < 200) for (String p : ps) { sb.append(p).append(' '); if (sb.length() > 6000) break; }
        // sin preferencia por el idioma de la app: aquí cuenta solo el texto
        String n = Brain.langOf(sb.toString());
        return n.equals("español") ? "es" : n.equals("italiano") ? "it" : "en";
    }

    /** Un traductor abierto (de «from» a «to»); se cierra con close(). */
    static final class Session implements Fn {
        final Translator t;
        Session(String from, String to) {
            t = Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(mk(from)).setTargetLanguage(mk(to)).build());
        }
        /** Baja el idioma si hace falta (unos 30 MB, solo la primera vez). */
        void prepare() throws Exception { Tasks.await(t.downloadModelIfNeeded(new DownloadConditions.Builder().build())); }
        public String tr(String s) throws Exception {
            Exception last = null;
            for (int k = 0; k < 2; k++) {                               // un reintento si falla
                try { String r = Tasks.await(t.translate(s), 60, java.util.concurrent.TimeUnit.SECONDS); if (r != null) return r; }
                catch (Exception e) { last = e; }
            }
            throw last != null ? last : new Exception("sin respuesta");
        }
        void close() { try { t.close(); } catch (Exception ignored) {} }
    }

    /** Trozos que no se pudieron traducir (quedan en el idioma original), por número de bloque. */
    static final java.util.Set<Integer> failed = java.util.Collections.synchronizedSet(new java.util.HashSet<>());

    /** La parte que no depende de Android (se prueba con un traductor de mentira). */
    static void run(DocIO.Doc d, Fn fn, String to, Progress p) throws Exception {
        cancel = false;
        Map<String, String> cache = new HashMap<>();
        Fn f = s -> {
            if (cancel) throw new Exception(L.t("Cancelado"));
            String r = cache.get(s);
            if (r == null) { r = piece(s, fn); cache.put(s, r); }
            return r;
        };
        if (d.title != null && !d.title.trim().isEmpty()) try { d.title = f.tr(d.title); } catch (Exception e) { if (cancel) throw e; }
        if (d.rich != null) {
            List<Rich.Block> bs = d.rich.blocks;
            int total = 0;
            for (Rich.Block b : bs) if (b.kind == Rich.TEXT) total++;
            int done = 0;
            failed.clear();
            for (int k = 0; k < bs.size(); k++) {
                Rich.Block b = bs.get(k);
                if (b.kind != Rich.TEXT) continue;
                try { block(b, f, 0); } catch (Exception e) { if (cancel) throw e; failed.add(k); }
                done++;
                if (p != null && (done % 5 == 0 || done == total)) p.at(done, total);
            }
            d.rich.lang = to;
            d.paras.clear();
            d.paras.addAll(d.rich.paras());
        } else {
            for (int i = 0; i < d.paras.size(); i++) {
                d.paras.set(i, lines(d.paras.get(i), f));
                if (p != null && (i % 5 == 0 || i == d.paras.size() - 1)) p.at(i + 1, d.paras.size());
            }
        }
    }

    /** Un bloque: se agrupan sus trozos de formato en frases, se traduce cada grupo y se le da el formato que más tenía. */
    /**
     * @param mode 0 = por frases con su formato (lo normal) · 1 = frase a frase, una por una · 2 = el párrafo entero de una vez.
     *             Al «volver a traducir» una página se prueba otra manera: a veces sale mejor.
     */
    static void block(Rich.Block b, Fn f0, int mode) throws Exception {
        if (b.emptyLine) return;
        String t = b.text.toString();
        if (!hasLetters(t)) return;
        Fn f = mode == 1 ? s -> sentences(s, f0) : f0;
        List<Rich.Run> runs = b.runs;
        if (runs.isEmpty() || mode == 2) {
            // todo de una vez, con el formato que más tenga
            Rich.Run best = null;
            for (Rich.Run r : runs) if (best == null || r.e - r.s > best.e - best.s) best = r;
            Rich.Run x = best == null ? new Rich.Run() : copy(best);
            x.s = 0; x.e = t.length();
            runs = new ArrayList<>();
            runs.add(x);
        }
        // grupos: se corta donde un trozo con otro formato empieza después de un punto, dos puntos, etc.
        List<int[]> groups = new ArrayList<>();          // índices de runs [desde, hasta)
        int g0 = 0;
        for (int k = 1; k < runs.size(); k++) {
            String before = t.substring(runs.get(g0).s, runs.get(k).s).trim();
            char last = before.isEmpty() ? '.' : before.charAt(before.length() - 1);
            boolean cut = ".:!?;…»\"".indexOf(last) >= 0 || t.charAt(Math.max(0, runs.get(k).s - 1)) == '\n';
            if (cut) { groups.add(new int[]{g0, k}); g0 = k; }
        }
        groups.add(new int[]{g0, runs.size()});
        StringBuilder out = new StringBuilder();
        List<Rich.Run> nr = new ArrayList<>();
        int pos = 0;
        for (int[] g : groups) {
            int s = runs.get(g[0]).s, e = runs.get(g[1] - 1).e;
            // huecos entre trozos (no debería haber, pero por si acaso)
            if (s > pos) out.append(t, pos, s);
            String src = t.substring(s, e);
            // el formato que más letras tiene en el grupo
            Rich.Run best = runs.get(g[0]);
            int bl = -1;
            for (int k = g[0]; k < g[1]; k++) { Rich.Run r = runs.get(k); if (r.e - r.s > bl) { bl = r.e - r.s; best = r; } }
            String dst = hasLetters(src) ? lines(src, f) : src;
            Rich.Run x = copy(best);
            x.s = out.length();
            out.append(dst);
            x.e = out.length();
            if (x.e > x.s) nr.add(x);
            pos = e;
        }
        if (pos < t.length()) out.append(t.substring(pos));
        b.text.setLength(0);
        b.text.append(out);
        b.runs.clear();
        b.runs.addAll(nr);
    }

    /** Frase a frase. */
    static String sentences(String s, Fn f) throws Exception {
        String[] ps = s.split("(?<=[.!?…;:])\\s+");
        if (ps.length <= 1) return f.tr(s);
        StringBuilder o = new StringBuilder();
        for (String x : ps) { if (o.length() > 0) o.append(' '); o.append(hasLetters(x) ? f.tr(x) : x); }
        return o.toString();
    }

    /** Vuelve a traducir los bloques [from, to] desde el original, de otra manera (mode). Devuelve cuántos fallaron. */
    static int redo(Rich tr, Rich orig, int from, int to, Fn f, int mode) throws Exception {
        cancel = false;
        int bad = 0;
        for (int k = Math.max(0, from); k <= to && k < tr.blocks.size() && k < orig.blocks.size(); k++) {
            Rich.Block o = orig.blocks.get(k);
            if (o.kind != Rich.TEXT) continue;
            Rich.Block c = Rich.copy(o);
            try { block(c, f, mode); tr.blocks.set(k, c); failed.remove(k); }
            catch (Exception e) { bad++; failed.add(k); }
        }
        return bad;
    }

    static Rich.Run copy(Rich.Run a) {
        Rich.Run x = new Rich.Run();
        x.b = a.b; x.i = a.i; x.u = a.u; x.sup = a.sup; x.sub = a.sub; x.size = a.size; x.color = a.color; x.bg = a.bg;
        return x;
    }

    static boolean hasLetters(String s) {
        for (int i = 0; i < s.length(); i++) if (Character.isLetter(s.charAt(i))) return true;
        return false;
    }

    /** Respeta los saltos de línea y los espacios de los bordes. */
    static String lines(String s, Fn f) throws Exception {
        String[] ls = s.split("\n", -1);
        StringBuilder o = new StringBuilder();
        for (int i = 0; i < ls.length; i++) {
            if (i > 0) o.append('\n');
            String l = ls[i];
            int a = 0, z = l.length();
            while (a < z && Character.isWhitespace(l.charAt(a)) || a < z && l.charAt(a) == ' ') a++;
            while (z > a && (Character.isWhitespace(l.charAt(z - 1)) || l.charAt(z - 1) == ' ')) z--;
            o.append(l, 0, a);
            String core = l.substring(a, z);
            o.append(hasLetters(core) ? f.tr(core) : core);
            o.append(l.substring(z));
        }
        return o.toString();
    }

    /** Textos muy largos se mandan por frases (el traductor va mejor con trozos de menos de ~1500 letras). */
    static String piece(String s, Fn fn) throws Exception {
        if (s.length() <= 1500) { String r = fn.tr(s); return r == null ? s : r; }
        StringBuilder o = new StringBuilder(), cur = new StringBuilder();
        for (String sent : s.split("(?<=[.!?…])\\s+")) {
            if (cur.length() + sent.length() > 1200 && cur.length() > 0) { o.append(fn.tr(cur.toString())).append(' '); cur.setLength(0); }
            cur.append(sent).append(' ');
        }
        if (cur.length() > 0) o.append(fn.tr(cur.toString().trim()));
        return o.toString().trim();
    }
}
