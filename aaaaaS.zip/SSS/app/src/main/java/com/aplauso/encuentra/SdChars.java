package com.aplauso.encuentra;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * v1.4 · PERSONAJES para el Estudio de dibujo (lo que la comunidad llama «embeddings» o «textual inversion»).
 * Un personaje son unos pocos vectores de 768 números que el modelo entiende como «palabras nuevas».
 * Se importan de .safetensors o .pt (Stable Diffusion 1.5) y se activan escribiendo su nombre en el prompt.
 *
 * Por dentro: se reservan fichas raras del vocabulario (las del final) y en la tabla de palabras del
 * codificador de texto se escriben los vectores del personaje en esas filas. Se guarda una copia de las filas
 * originales para dejarlas como estaban si borras el personaje.
 */
public class SdChars {
    static final int DIM = 768, FIRST_SLOT = 49000, LAST_SLOT = 49399;

    static final class Char { String name; int n; int slot; }

    static File dir(Context c) { File d = new File(c.getFilesDir(), "sd_chars"); d.mkdirs(); return d; }

    static List<Char> all(Context c) {
        List<Char> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(SdEngine.prefs(c).getString("sd_chars", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Char ch = new Char(); ch.name = o.getString("name"); ch.n = o.getInt("n"); ch.slot = o.getInt("slot");
                out.add(ch);
            }
        } catch (Exception ignored) {}
        return out;
    }

    static void save(Context c, List<Char> l) {
        JSONArray a = new JSONArray();
        try { for (Char ch : l) a.put(new JSONObject().put("name", ch.name).put("n", ch.n).put("slot", ch.slot)); } catch (Exception ignored) {}
        SdEngine.prefs(c).edit().putString("sd_chars", a.toString()).apply();
        if (SdEngine.loadedId != null) SdEngine.unload();      // el codificador de texto se vuelve a preparar
    }

    static String clean(String name) { return name.trim().replaceAll("\\s+", " "); }

    /** Importa un personaje; devuelve null si va bien o el motivo del error. */
    static String add(Context c, String name, byte[] file, String fileName) {
        name = clean(name);
        if (name.length() < 2) return L.t("Ponle un nombre de al menos 2 letras.");
        List<Char> l = all(c);
        for (Char ch : l) if (ch.name.equalsIgnoreCase(name)) return L.t("Ya tienes un personaje con ese nombre.");
        float[][] v;
        try { v = read(file, fileName); } catch (Exception e) { return e.getMessage(); }
        if (v.length == 0) return L.t("El archivo no tiene ningún vector.");
        if (v.length > 75) return L.t("Demasiado grande para el modelo del móvil.");
        // hueco libre
        int slot = FIRST_SLOT;
        boolean moved = true;
        while (moved) {
            moved = false;
            for (Char ch : l) if (slot < ch.slot + ch.n && ch.slot < slot + v.length) { slot = ch.slot + ch.n; moved = true; }
        }
        if (slot + v.length - 1 > LAST_SLOT) return L.t("No caben más personajes: borra alguno.");
        try {
            ByteBuffer bb = ByteBuffer.allocate(v.length * DIM * 4).order(ByteOrder.LITTLE_ENDIAN);
            for (float[] row : v) for (float x : row) bb.putFloat(x);
            java.nio.file.Files.write(new File(dir(c), slot + ".vec").toPath(), bb.array());
        } catch (Exception e) { return e.getMessage(); }
        Char ch = new Char(); ch.name = name; ch.n = v.length; ch.slot = slot;
        l.add(ch);
        save(c, l);
        return null;
    }

    static void remove(Context c, String name) {
        List<Char> l = all(c);
        for (int i = 0; i < l.size(); i++) if (l.get(i).name.equalsIgnoreCase(name)) {
            new File(dir(c), l.get(i).slot + ".vec").delete();
            l.remove(i);
            break;
        }
        save(c, l);
    }

    static float[][] vectors(Context c, Char ch) throws Exception {
        byte[] b = java.nio.file.Files.readAllBytes(new File(dir(c), ch.slot + ".vec").toPath());
        ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
        float[][] v = new float[ch.n][DIM];
        for (int i = 0; i < ch.n; i++) for (int k = 0; k < DIM; k++) v[i][k] = bb.getFloat();
        return v;
    }

    // ------------------------------------------------------------------ leer archivos
    static float[][] read(byte[] b, String fileName) throws Exception {
        if (b.length > 8 && b[0] == 'P' && b[1] == 'K') return readPt(b);
        return readSafetensors(b);
    }

    static float[][] readSafetensors(byte[] b) throws Exception {
        ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
        long hl = bb.getLong();
        if (hl <= 0 || hl > b.length - 8) throw new Exception(L.t("No es un archivo .safetensors válido."));
        JSONObject h = new JSONObject(new String(b, 8, (int) hl, StandardCharsets.UTF_8));
        int base = 8 + (int) hl;
        for (java.util.Iterator<String> it = h.keys(); it.hasNext(); ) {
            String k = it.next();
            if (k.equals("__metadata__")) continue;
            JSONObject t = h.getJSONObject(k);
            JSONArray sh = t.getJSONArray("shape");
            int last = sh.getInt(sh.length() - 1);
            if (last == 1280 || k.contains("clip_g")) throw new Exception(L.t("Este personaje es para SDXL: el modelo del móvil es Stable Diffusion 1.5."));
            if (last == 1024) throw new Exception(L.t("Este personaje es para Stable Diffusion 2: el del móvil es el 1.5."));
            if (last != DIM) continue;
            int n = sh.length() == 1 ? 1 : sh.getInt(0);
            JSONArray off = t.getJSONArray("data_offsets");
            return decode(b, base + off.getInt(0), n, t.getString("dtype"));
        }
        throw new Exception(L.t("No encuentro un personaje de Stable Diffusion 1.5 en este archivo."));
    }

    /** .pt de A1111: un zip con data.pkl y los datos en archive/data/N. */
    static float[][] readPt(byte[] b) throws Exception {
        String pkl = "";
        List<byte[]> blobs = new ArrayList<>();
        try (ZipInputStream z = new ZipInputStream(new java.io.ByteArrayInputStream(b))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                byte[] buf = new byte[65536]; int k;
                while ((k = z.read(buf)) > 0) o.write(buf, 0, k);
                if (e.getName().endsWith("data.pkl")) pkl = new String(o.toByteArray(), StandardCharsets.ISO_8859_1);
                else if (e.getName().matches(".*/data/\\d+$")) blobs.add(o.toByteArray());
            }
        }
        String dtype = pkl.contains("HalfStorage") ? "F16" : pkl.contains("BFloat16Storage") ? "BF16" : "F32";
        int es = dtype.equals("F32") ? 4 : 2;
        for (byte[] d : blobs) {
            if (d.length % (1280 * es) == 0 && d.length % (DIM * es) != 0) throw new Exception(L.t("Este personaje es para SDXL: el modelo del móvil es Stable Diffusion 1.5."));
            if (d.length % (DIM * es) == 0 && d.length >= DIM * es) return decode(d, 0, d.length / (DIM * es), dtype);
        }
        throw new Exception(L.t("No encuentro un personaje de Stable Diffusion 1.5 en este archivo."));
    }

    static float[][] decode(byte[] b, int off, int n, String dtype) {
        ByteBuffer bb = ByteBuffer.wrap(b, off, b.length - off).order(ByteOrder.LITTLE_ENDIAN);
        float[][] v = new float[n][DIM];
        for (int i = 0; i < n; i++) for (int k = 0; k < DIM; k++) {
            switch (dtype) {
                case "F16": v[i][k] = SdEngine.half(bb.getShort()); break;
                case "BF16": v[i][k] = Float.intBitsToFloat((bb.getShort() & 0xffff) << 16); break;
                default: v[i][k] = bb.getFloat();
            }
        }
        return v;
    }

    // ------------------------------------------------------------------ escribir en el modelo
    /** Pone los personajes en la tabla de palabras del codificador de texto (antes de abrirlo). */
    static void apply(Context c, File textEncOnnx) throws Exception {
        List<Char> l = all(c);
        List<float[][]> vs = new ArrayList<>();
        for (Char ch : l) vs.add(vectors(c, ch));
        apply(l, vs, textEncOnnx);
    }

    static void apply(List<Char> l, List<float[][]> vs, File textEncOnnx) throws Exception {
        File dirM = textEncOnnx.getParentFile(), state = new File(dirM, ".chars"), bak = new File(dirM, ".chars_backup");
        StringBuilder want = new StringBuilder();
        for (int i = 0; i < l.size(); i++) { Char ch = l.get(i); want.append(ch.slot).append(':').append(ch.n).append(':').append(java.util.Arrays.deepHashCode(vs.get(i))).append(':').append(ch.name).append('\n'); }
        String have = state.exists() ? new String(java.nio.file.Files.readAllBytes(state.toPath()), StandardCharsets.UTF_8) : "";
        if (have.equals(want.toString())) return;

        byte[] g = java.nio.file.Files.readAllBytes(textEncOnnx.toPath());
        OnnxPatch.Graph gr = OnnxPatch.parse(g);
        OnnxPatch.Tensor table = null;
        for (OnnxPatch.Tensor t : gr.inits.values())
            if (t.dims.size() == 2 && t.dims.get(1) == DIM && t.dims.get(0) >= 49408) { table = t; break; }
        if (table == null) throw new Exception(L.t("Este modelo no deja añadir personajes."));
        int es;
        float scale = 1, zp = 0;
        switch (table.dataType) {
            case 1: es = 4; break;               // float32
            case 10: es = 2; break;              // float16
            case 2: case 3: {                    // cuantizada: busca su escala
                es = 1;
                OnnxPatch.Tensor sc = gr.inits.get(table.name + "_scale"), z = gr.inits.get(table.name + "_zero_point");
                if (sc == null) throw new Exception(L.t("Este modelo no deja añadir personajes."));
                scale = scalar(g, dirM, sc);
                zp = z == null ? 0 : scalar(g, dirM, z);
                if (scale == 0) throw new Exception(L.t("Este modelo no deja añadir personajes."));
                break;
            }
            default: throw new Exception(L.t("Este modelo no deja añadir personajes."));
        }
        bak.mkdirs();
        try (RandomAccessFile raf = table.location != null ? new RandomAccessFile(new File(dirM, table.location), "rw") : null) {
            // 1) devolver a su sitio las filas de personajes que ya no están
            File[] olds = bak.listFiles();
            java.util.Set<Integer> used = new java.util.HashSet<>();
            for (Char ch : l) for (int i = 0; i < ch.n; i++) used.add(ch.slot + i);
            if (olds != null) for (File f : olds) {
                int id = Integer.parseInt(f.getName().replace(".row", ""));
                if (used.contains(id)) continue;
                writeRow(g, raf, table, id, java.nio.file.Files.readAllBytes(f.toPath()), es);
                f.delete();
            }
            // 2) escribir los personajes (guardando antes la fila original)
            for (int ci = 0; ci < l.size(); ci++) {
                Char ch = l.get(ci);
                float[][] v = vs.get(ci);
                for (int i = 0; i < ch.n; i++) {
                    int id = ch.slot + i;
                    File bf = new File(bak, id + ".row");
                    if (!bf.exists()) java.nio.file.Files.write(bf.toPath(), readRow(g, raf, table, id, es));
                    writeRow(g, raf, table, id, encodeRow(v[i], table.dataType, scale, zp), es);
                }
            }
        }
        if (table.location == null) {                // la tabla iba dentro del .onnx: guardarlo
            File tmp = new File(textEncOnnx.getPath() + ".tmp");
            java.nio.file.Files.write(tmp.toPath(), g);
            if (!tmp.renameTo(textEncOnnx)) { textEncOnnx.delete(); tmp.renameTo(textEncOnnx); }
        }
        java.nio.file.Files.write(state.toPath(), want.toString().getBytes(StandardCharsets.UTF_8));
    }

    static long rowPos(OnnxPatch.Tensor t, int id, int es) { return (t.location != null ? t.extOffset : t.rawPos) + (long) id * DIM * es; }

    static byte[] readRow(byte[] g, RandomAccessFile raf, OnnxPatch.Tensor t, int id, int es) throws Exception {
        byte[] r = new byte[DIM * es];
        long p = rowPos(t, id, es);
        if (raf != null) { raf.seek(p); raf.readFully(r); } else System.arraycopy(g, (int) p, r, 0, r.length);
        return r;
    }

    static void writeRow(byte[] g, RandomAccessFile raf, OnnxPatch.Tensor t, int id, byte[] r, int es) throws Exception {
        long p = rowPos(t, id, es);
        if (raf != null) { raf.seek(p); raf.write(r); } else System.arraycopy(r, 0, g, (int) p, r.length);
    }

    static byte[] encodeRow(float[] v, int type, float scale, float zp) {
        ByteBuffer bb = ByteBuffer.allocate(DIM * (type == 1 ? 4 : type == 10 ? 2 : 1)).order(ByteOrder.LITTLE_ENDIAN);
        for (float x : v) {
            if (type == 1) bb.putFloat(x);
            else if (type == 10) bb.putShort(toHalf(x));
            else {
                int q = Math.round(x / scale + zp);
                q = type == 2 ? Math.max(0, Math.min(255, q)) : Math.max(-128, Math.min(127, q));
                bb.put((byte) q);
            }
        }
        return bb.array();
    }

    static short toHalf(float f) {
        int b = Float.floatToIntBits(f), s = (b >>> 16) & 0x8000, e = ((b >>> 23) & 0xff) - 127 + 15, m = b & 0x7fffff;
        if (e <= 0) return (short) s;
        if (e >= 31) return (short) (s | 0x7c00);
        return (short) (s | (e << 10) | (m >> 13));
    }

    /** Lee un número suelto (escala o punto cero) de un tensor pequeño. */
    static float scalar(byte[] g, File dir, OnnxPatch.Tensor t) throws Exception {
        byte[] d;
        if (t.rawPos >= 0) { d = new byte[(int) t.rawLen]; System.arraycopy(g, (int) t.rawPos, d, 0, d.length); }
        else if (t.location != null) {
            try (RandomAccessFile r = new RandomAccessFile(new File(dir, t.location), "r")) { d = new byte[4]; r.seek(t.extOffset); r.readFully(d, 0, (int) Math.min(4, t.extLength < 0 ? 4 : t.extLength)); }
        } else return 0;      // int32_data/float_data: rara vez; se asume 0
        ByteBuffer bb = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        switch (t.dataType) {
            case 1: return bb.getFloat();
            case 2: return d[0] & 0xff;
            case 3: return d[0];
            case 10: return SdEngine.half(bb.getShort());
            default: return 0;
        }
    }

    /** Para el tokenizador: nombre → fichas reservadas. */
    static java.util.Map<String, int[]> tokens(Context c) {
        java.util.Map<String, int[]> m = new java.util.LinkedHashMap<>();
        for (Char ch : all(c)) {
            int[] ids = new int[ch.n];
            for (int i = 0; i < ch.n; i++) ids[i] = ch.slot + i;
            m.put(ch.name.toLowerCase(Locale.ROOT), ids);
        }
        return m;
    }
}
