package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;

import java.io.File;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

/**
 * v1.5.2 · AMPLIAR LA RESOLUCIÓN DE UN VÍDEO (por ejemplo de 360p a 4K), dentro del teléfono y sin internet.
 * Cada fotograma pasa por una red neuronal que lo hace ×4 reconstruyendo detalle (Real-ESRGAN, BSD-3) y luego se
 * ajusta al tamaño elegido. El sonido se copia tal cual. Va en segundo plano (con la pantalla apagada también):
 * es un trabajo largo, y la notificación dice cuánto falta.
 */
public class VideoSR extends Service {
    String srCh = "video_sr";
    static final String[] MODELS = {"sr_anime.onnx", "sr_general.onnx"};

    // ---- estado para la pantalla
    static volatile boolean running, cancel;
    static volatile int done, total;
    static volatile long startMs;
    static volatile String status = "", error = "";
    static volatile Uri result;
    static volatile String srcName = "";

    static void start(Context c, Uri src, int shortSide, int model, String name) {
        if (running) return;
        Intent i = new Intent(c, VideoSR.class).setData(src).putExtra("side", shortSide).putExtra("model", model).putExtra("name", name);
        if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    // ------------------------------------------------------------------ la red
    static OrtEnvironment env;
    static OrtSession sess;
    static int sessModel = -1;

    static synchronized OrtSession session(Context c, int model) throws Exception {
        if (sess != null && sessModel == model) return sess;
        if (sess != null) try { sess.close(); } catch (Exception ignored) {}
        sess = null;
        if (env == null) env = OrtEnvironment.getEnvironment();
        byte[] m;
        try (InputStream in = c.getAssets().open(MODELS[model])) { m = DocIO.readAll(in); }
        int cores = Runtime.getRuntime().availableProcessors();
        try {                                   // XNNPACK: bastante más rápido en los procesadores del móvil
            OrtSession.SessionOptions o = new OrtSession.SessionOptions();
            Map<String, String> x = new HashMap<>();
            x.put("intra_op_num_threads", String.valueOf(Math.max(2, Math.min(6, cores - 2))));
            o.addXnnpack(x);
            o.setIntraOpNumThreads(1);
            o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
            sess = env.createSession(m, o);
        } catch (Throwable t) {
            OrtSession.SessionOptions o = new OrtSession.SessionOptions();
            o.setIntraOpNumThreads(Math.max(2, Math.min(6, cores - 2)));
            o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
            sess = env.createSession(m, o);
        }
        sessModel = model;
        return sess;
    }

    static float[] infer(OrtSession s, float[] chw, int w, int h) throws Exception {
        try (OnnxTensor t = OnnxTensor.createTensor(env, FloatBuffer.wrap(chw), new long[]{1, 3, h, w});
             OrtSession.Result r = s.run(Collections.singletonMap("input", t))) {
            return SdEngine.floats(r.get(0));
        }
    }

    static synchronized void release() {
        if (sess != null) try { sess.close(); } catch (Exception ignored) {}
        sess = null;
        sessModel = -1;
    }

    /** Amplía una sola imagen (para la vista previa y para fotos). */
    static Bitmap upscaleBitmap(Context c, Bitmap src, int tw, int th, int model) throws Exception {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        float[] in = new float[3 * w * h];
        int n = w * h;
        for (int i = 0; i < n; i++) { int p = px[i]; in[i] = ((p >> 16) & 255) / 255f; in[n + i] = ((p >> 8) & 255) / 255f; in[2 * n + i] = (p & 255) / 255f; }
        int[] out = new int[tw * th];
        OrtSession s = session(c, model);
        SrCore.upscale(in, w, h, out, tw, th, 256, 12, (t, ww, hh) -> infer(s, t, ww, hh));
        return Bitmap.createBitmap(out, tw, th, Bitmap.Config.ARGB_8888);
    }

    // ------------------------------------------------------------------ el servicio
    NotificationManager nm;
    PowerManager.WakeLock wl;

    @Override public IBinder onBind(Intent i) { return null; }

    Notification notif(String text, int pc) {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, VideoUpscaleActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, srCh) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_slideshow).setContentTitle(L.t("Ampliando vídeo (SSS+)"))
                .setContentText(text).setProgress(100, Math.max(0, pc), pc < 0).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi).build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        nm = getSystemService(NotificationManager.class);
        srCh = Notif.ch(this, "video_sr", L.t("Ampliar vídeos"), NotificationManager.IMPORTANCE_LOW);   // v1.6
        Notification n = notif(L.t("Preparando…"), -1);
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(41, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(41, n);
        if (intent == null || intent.getData() == null || running) { if (!running) stopSelf(); return START_NOT_STICKY; }
        final Uri src = intent.getData();
        final int side = intent.getIntExtra("side", 1080), model = intent.getIntExtra("model", 0);
        srcName = intent.getStringExtra("name") == null ? "video" : intent.getStringExtra("name");
        running = true; cancel = false; done = 0; total = 0; error = ""; result = null; status = L.t("Preparando…");
        startMs = SystemClock.elapsedRealtime();
        wl = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sss:videosr");
        wl.acquire(12L * 3600 * 1000);
        new Thread(() -> {
            File tmp = new File(getCacheDir(), "sr_" + System.currentTimeMillis() + ".mp4");
            try {
                process(src, tmp, side, model);
                if (cancel) { status = L.t("Cancelado."); tmp.delete(); }
                else {
                    status = L.t("Guardando…");
                    String base = srcName.replaceAll("\\.[A-Za-z0-9]+$", "").replaceAll("[\\\\/:*?\"<>|]", "_");
                    result = Media.save(this, tmp, Media.TYPE_VIDEO, base + "_" + side + "p_" + Media.stamp() + ".mp4", "video/mp4");
                    status = result != null ? L.t("✓ ¡Listo! Guardado en tus vídeos (SSS+).") : L.t("No se pudo guardar el vídeo.");
                    if (result == null) error = status;
                }
            } catch (Throwable e) {
                error = e.getMessage() == null ? e.toString() : e.getMessage();
                status = L.t("Error: ") + error;
                tmp.delete();
            } finally {
                running = false;
                release();
                if (wl != null && wl.isHeld()) wl.release();
                stopForeground(true);
                Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, srCh) : new Notification.Builder(this);
                nm.notify(42, b.setSmallIcon(android.R.drawable.ic_menu_slideshow).setContentTitle(L.t("Ampliar vídeo (SSS+)")).setContentText(status)
                        .setAutoCancel(true).setContentIntent(PendingIntent.getActivity(this, 1, new Intent(this, VideoUpscaleActivity.class), PendingIntent.FLAG_IMMUTABLE)).build());
                stopSelf();
            }
        }, "ampliar-video").start();
        return START_NOT_STICKY;
    }

    /** Encuentra un codificador que pueda con ese tamaño. */
    static String encoderFor(String mime, int w, int h) {
        for (MediaCodecInfo ci : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
            if (!ci.isEncoder()) continue;
            for (String t : ci.getSupportedTypes()) {
                if (!t.equalsIgnoreCase(mime)) continue;
                try {
                    MediaCodecInfo.VideoCapabilities vc = ci.getCapabilitiesForType(t).getVideoCapabilities();
                    if (vc != null && vc.isSizeSupported(w, h)) return ci.getName();
                } catch (Exception ignored) {}
            }
        }
        return null;
    }

    void process(Uri src, File out, int side, int model) throws Exception {
        MediaExtractor vx = new MediaExtractor(), ax = new MediaExtractor();
        MediaCodec dec = null, enc = null;
        MediaMuxer mux = null;
        try {
            vx.setDataSource(this, src, null);
            int vt = -1, at = -1;
            for (int i = 0; i < vx.getTrackCount(); i++) {
                String m = vx.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                if (m == null) continue;
                if (vt < 0 && m.startsWith("video/")) vt = i;
            }
            if (vt < 0) throw new Exception(L.t("El archivo no tiene vídeo."));
            vx.selectTrack(vt);
            MediaFormat vf = vx.getTrackFormat(vt);
            int w = vf.getInteger(MediaFormat.KEY_WIDTH), h = vf.getInteger(MediaFormat.KEY_HEIGHT);
            if (vf.containsKey("crop-right") && vf.containsKey("crop-left")) w = vf.getInteger("crop-right") - vf.getInteger("crop-left") + 1;
            if (vf.containsKey("crop-bottom") && vf.containsKey("crop-top")) h = vf.getInteger("crop-bottom") - vf.getInteger("crop-top") + 1;
            long durUs = vf.containsKey(MediaFormat.KEY_DURATION) ? vf.getLong(MediaFormat.KEY_DURATION) : MediaTools.durationMs(this, src) * 1000;
            float fps = 30;
            try { if (vf.containsKey(MediaFormat.KEY_FRAME_RATE)) fps = vf.getInteger(MediaFormat.KEY_FRAME_RATE); } catch (ClassCastException e) { fps = vf.getFloat(MediaFormat.KEY_FRAME_RATE); }
            if (fps < 1 || fps > 240) fps = 30;
            total = (int) Math.max(1, durUs / 1e6 * fps);

            // tamaño final y codificador
            int[] tg = SrCore.target(w, h, side);
            int tw = tg[0], th = tg[1];
            String mime = MediaFormat.MIMETYPE_VIDEO_AVC, encName = encoderFor(mime, tw, th);
            if (encName == null) { mime = MediaFormat.MIMETYPE_VIDEO_HEVC; encName = encoderFor(mime, tw, th); }
            if (encName == null) { tw = tw / 16 * 16; th = th / 16 * 16; mime = MediaFormat.MIMETYPE_VIDEO_AVC; encName = encoderFor(mime, tw, th); }
            if (encName == null) throw new Exception(L.t("Este teléfono no puede guardar vídeo de ese tamaño. Prueba uno más pequeño."));
            boolean hevc = mime.equals(MediaFormat.MIMETYPE_VIDEO_HEVC);
            MediaFormat ef = MediaFormat.createVideoFormat(mime, tw, th);
            ef.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            long br = (long) (tw * (long) th * fps * (hevc ? 0.09 : 0.14));
            ef.setInteger(MediaFormat.KEY_BIT_RATE, (int) Math.max(2_000_000, Math.min(80_000_000, br)));
            ef.setInteger(MediaFormat.KEY_FRAME_RATE, Math.round(fps));
            ef.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            enc = MediaCodec.createByCodecName(encName);
            enc.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();

            dec = MediaCodec.createDecoderByType(vf.getString(MediaFormat.KEY_MIME));
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            dec.configure(vf, null, null, 0);
            dec.start();

            // el sonido, tal cual
            mux = new MediaMuxer(out.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            mux.setOrientationHint(MediaTools.rotation(this, src));
            ax.setDataSource(this, src, null);
            int muxA = -1;
            for (int i = 0; i < ax.getTrackCount(); i++) {
                MediaFormat f = ax.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) {
                    try { muxA = mux.addTrack(f); at = i; ax.selectTrack(i); } catch (Exception ignored) { muxA = -1; }
                    break;
                }
            }
            muxVTrack = -1;
            muxOn = false;

            OrtSession s = session(this, model);
            boolean bt709 = h >= 720;
            float[] rgb = new float[3 * w * h];
            int[] argb = new int[tw * th];
            byte[] Y = new byte[tw * th], U = new byte[tw * th / 4], V = new byte[tw * th / 4];
            byte[] py = null, pu = null, pv = null;

            MediaCodec.BufferInfo di = new MediaCodec.BufferInfo(), ei = new MediaCodec.BufferInfo();
            boolean inDone = false, decDone = false, encDone = false;
            long lastNotif = 0;
            while (!encDone && !cancel) {
                // 1) dar datos al decodificador
                if (!inDone) {
                    int ii = dec.dequeueInputBuffer(5000);
                    if (ii >= 0) {
                        ByteBuffer ib = dec.getInputBuffer(ii);
                        int sz = vx.readSampleData(ib, 0);
                        if (sz < 0) { dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true; }
                        else { dec.queueInputBuffer(ii, 0, sz, vx.getSampleTime(), 0); vx.advance(); }
                    }
                }
                // 2) sacar fotogramas, ampliarlos y pasarlos al codificador
                if (!decDone) {
                    int oi = dec.dequeueOutputBuffer(di, 5000);
                    if (oi >= 0) {
                        boolean eos = (di.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                        if (di.size > 0 || !eos) {
                            Image img = dec.getOutputImage(oi);
                            if (img != null) {
                                Rect cr = img.getCropRect();
                                int fw = Math.min(w, cr.width()), fh = Math.min(h, cr.height());
                                Image.Plane[] pl = img.getPlanes();
                                int hi = pl[0].getPixelStride() == 2 ? 1 : 0;           // vídeo de 10 bits
                                py = grab(pl[0].getBuffer(), py);
                                pu = grab(pl[1].getBuffer(), pu);
                                pv = grab(pl[2].getBuffer(), pv);
                                int yOff = cr.top * pl[0].getRowStride() + cr.left * pl[0].getPixelStride();
                                int cOff = (cr.top / 2) * pl[1].getRowStride() + (cr.left / 2) * pl[1].getPixelStride();
                                if (fw != w || fh != h) { w = fw; h = fh; rgb = new float[3 * w * h]; }
                                SrCore.yuvToRgb(shift(py, yOff), pl[0].getRowStride(), pl[0].getPixelStride(), shift(pu, cOff), shift(pv, cOff),
                                        pl[1].getRowStride(), pl[1].getPixelStride(), hi, w, h, bt709, rgb);
                                img.close();
                                final int fw2 = w, fh2 = h;
                                SrCore.upscale(rgb, fw2, fh2, argb, tw, th, 256, 12, (t, ww, hh) -> infer(s, t, ww, hh));
                                SrCore.argbToYuv(argb, tw, th, Y, U, V);
                                long pts = di.presentationTimeUs;
                                dec.releaseOutputBuffer(oi, false);
                                feed(enc, mux, Y, U, V, tw, th, pts, ei);
                                done++;
                            } else dec.releaseOutputBuffer(oi, false);
                        } else dec.releaseOutputBuffer(oi, false);
                        if (eos) {
                            decDone = true;
                            int ii;
                            while ((ii = enc.dequeueInputBuffer(10000)) < 0) drain(enc, mux, ei, 0);
                            enc.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        }
                    }
                }
                // 3) sacar lo codificado al archivo
                if (drain(enc, mux, ei, decDone ? 10000 : 0)) encDone = true;
                long now = SystemClock.elapsedRealtime();
                if (now - lastNotif > 2000) {
                    lastNotif = now;
                    status = progressText();
                    nm.notify(41, notif(status, done * 100 / Math.max(1, total)));
                }
            }
            if (cancel) return;
            // el sonido al final (el MP4 lo coloca en su sitio)
            if (muxA >= 0 && muxOn) {
                status = L.t("Copiando el sonido…");
                ByteBuffer buf = ByteBuffer.allocate(1 << 20);
                MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
                while (!cancel) {
                    int sz = ax.readSampleData(buf, 0);
                    if (sz < 0) break;
                    bi.offset = 0; bi.size = sz; bi.presentationTimeUs = ax.getSampleTime();
                    bi.flags = (ax.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                    mux.writeSampleData(muxA, buf, bi);
                    ax.advance();
                }
            }
            if (muxOn) mux.stop();
            else throw new Exception(L.t("No salió ningún fotograma."));
        } finally {
            if (dec != null) try { dec.stop(); } catch (Exception ignored) {}
            if (dec != null) try { dec.release(); } catch (Exception ignored) {}
            if (enc != null) try { enc.stop(); } catch (Exception ignored) {}
            if (enc != null) try { enc.release(); } catch (Exception ignored) {}
            if (mux != null) try { mux.release(); } catch (Exception ignored) {}
            vx.release();
            ax.release();
        }
    }

    static String progressText() {
        long el = SystemClock.elapsedRealtime() - startMs;
        String eta = "";
        if (done > 3) {
            long left = el * (total - done) / done / 1000;
            eta = " · " + L.t("faltan") + " " + (left >= 3600 ? left / 3600 + " h " + (left % 3600) / 60 + " min" : left >= 60 ? left / 60 + " min" : left + " s");
        }
        return L.t("Fotograma") + " " + done + " / " + total + eta;
    }

    static byte[] grab(ByteBuffer b, byte[] reuse) {
        ByteBuffer d = b.duplicate();
        d.rewind();
        int n = d.remaining();
        if (reuse == null || reuse.length != n) reuse = new byte[n];
        d.get(reuse);
        return reuse;
    }

    /** Desplaza (para el recorte de la imagen) sin copiar si no hace falta. */
    static byte[] shift(byte[] a, int off) {
        if (off == 0) return a;
        return java.util.Arrays.copyOfRange(a, Math.min(off, a.length), a.length);
    }

    /** Mete un fotograma YUV en el codificador (esperando hueco y vaciándolo mientras tanto). */
    void feed(MediaCodec enc, MediaMuxer mux, byte[] Y, byte[] U, byte[] V, int w, int h, long pts, MediaCodec.BufferInfo ei) throws Exception {
        int ii;
        while ((ii = enc.dequeueInputBuffer(10000)) < 0) { if (cancel) return; drain(enc, mux, ei, 0); }
        Image img = enc.getInputImage(ii);
        if (img == null) throw new Exception("codificador sin imagen");
        Image.Plane[] pl = img.getPlanes();
        put(pl[0], Y, w, h);
        put(pl[1], U, w / 2, h / 2);
        put(pl[2], V, w / 2, h / 2);
        enc.queueInputBuffer(ii, 0, w * h * 3 / 2, pts, 0);
    }

    static void put(Image.Plane p, byte[] src, int w, int h) {
        ByteBuffer b = p.getBuffer();
        int rs = p.getRowStride(), ps = p.getPixelStride();
        if (ps == 1) {
            for (int y = 0; y < h; y++) { b.position(y * rs); b.put(src, y * w, w); }
        } else {
            int lim = b.limit();
            for (int y = 0; y < h; y++) {
                int o = y * rs, s = y * w;
                for (int x = 0; x < w; x++) { int i = o + x * ps; if (i < lim) b.put(i, src[s + x]); }
            }
        }
    }

    int muxVTrack = -1;
    boolean muxOn;

    /** Pasa al archivo todo lo que el codificador tenga listo. Devuelve true al llegar al final. */
    boolean drain(MediaCodec enc, MediaMuxer mux, MediaCodec.BufferInfo ei, long timeoutUs) {
        while (true) {
            int r = enc.dequeueOutputBuffer(ei, timeoutUs);
            if (r == MediaCodec.INFO_TRY_AGAIN_LATER) return false;
            if (r == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (!muxOn) { muxVTrack = mux.addTrack(enc.getOutputFormat()); mux.start(); muxOn = true; }
                continue;
            }
            if (r < 0) continue;
            ByteBuffer ob = enc.getOutputBuffer(r);
            if ((ei.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) ei.size = 0;
            if (ei.size > 0 && muxOn && ob != null) { ob.position(ei.offset); ob.limit(ei.offset + ei.size); mux.writeSampleData(muxVTrack, ob, ei); }
            enc.releaseOutputBuffer(r, false);
            if ((ei.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true;
        }
    }

    @Override public void onDestroy() { cancel = true; super.onDestroy(); }
}
