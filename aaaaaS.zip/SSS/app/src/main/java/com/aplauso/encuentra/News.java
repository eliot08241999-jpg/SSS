package com.aplauso.encuentra;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v1.6 · NOTICIAS DE VERDAD: Google Noticias (gratis, sin clave) por secciones (ciencia, tecnología, salud…) o
 * buscando un tema, en el idioma en que le hablas. Chloe te cuenta los titulares y de qué periódico salen;
 * nunca se inventa noticias.
 */
public class News {
    public static final class Item { public String title, source, link; public long when; }

    static final Map<String, String> TOPICS = new LinkedHashMap<>();
    static {
        TOPICS.put("tecnolog|tech|informatic|movil|moviles|ordenador|inteligencia artificial|\\bia\\b|\\bai\\b|gadget|smartphone", "TECHNOLOGY");
        TOPICS.put("cienc|scien|espacio|astronom|fisic|biolog|nasa|planeta", "SCIENCE");
        TOPICS.put("medic|salud|sanidad|health|salute|sanita|enfermedad|hospital|farmac|vacuna", "HEALTH");
        TOPICS.put("deport|futbol|sport|calcio|football|soccer|baloncesto|tenis|formula 1", "SPORTS");
        TOPICS.put("econom|bolsa|negocio|business|finanz|empresa|mercado", "BUSINESS");
        TOPICS.put("cine|pelicul|serie|musica|famos|entreten|spettacol|entertainment|videojueg|gaming", "ENTERTAINMENT");
        TOPICS.put("mundo|internacional|world|esteri|mondo", "WORLD");
    }

    /** ¿Piden noticias? */
    public static boolean asks(String n) {
        return n.matches(".*\\b(?:noticia|noticias|novedad|novedades|que hay de nuevo|que ha pasado|que esta pasando|titulares|actualidad|ultima hora|"
                + "news|headlines|whats new|notizia|notizie|novita|cosa e successo|ultime)\\b.*");
    }

    static String[] region(String lang) {
        if ("it".equals(lang)) return new String[]{"it", "IT", "IT:it"};
        if ("en".equals(lang)) return new String[]{"en-US", "US", "US:en"};
        return new String[]{"es", "ES", "ES:es"};
    }

    /** Las secciones que pide el texto (puede ser varias: «tecnología, ciencia o medicina»). */
    static List<String> sections(String n) {
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, String> e : TOPICS.entrySet())
            if (Pattern.compile("(?:" + e.getKey() + ")").matcher(n).find()) out.add(e.getValue());
        return out;
    }

    /** Lo que se busca si no es una sección: «noticias de Xiaomi» → «xiaomi». */
    static String query(String n) {
        Matcher m = Pattern.compile("\\b(?:noticias?|novedad(?:es)?|news|notizie|notizia|novita)\\s+(?:de|del|de la|sobre|acerca de|about|on|su|di|del|della|sul|sulla)\\s+(.+)").matcher(n);
        if (!m.find()) return null;
        String q = m.group(1).replaceAll("\\b(?:hoy|today|oggi|por favor|please|recientes?|ultimas?|nuevas?)\\b", "").trim();
        return q.length() < 2 ? null : q;
    }

    public static List<Item> fetch(String url, int max) throws Exception {
        String xml = Web.get(url);
        List<Item> out = new ArrayList<>();
        Matcher it = Pattern.compile("<item>(.*?)</item>", Pattern.DOTALL).matcher(xml);
        SimpleDateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.ENGLISH);
        while (it.find() && out.size() < max) {
            String b = it.group(1);
            Item i = new Item();
            i.title = DocIO.unesc(tag(b, "title"));
            i.link = DocIO.unesc(tag(b, "link"));
            i.source = DocIO.unesc(tag(b, "source"));
            try { i.when = df.parse(tag(b, "pubDate")).getTime(); } catch (Exception e) { i.when = 0; }
            // «Titular - Periódico» → sin el periódico al final
            if (!i.source.isEmpty() && i.title.endsWith(" - " + i.source)) i.title = i.title.substring(0, i.title.length() - i.source.length() - 3);
            if (i.title.isEmpty()) continue;
            out.add(i);
        }
        return out;
    }

    static String tag(String b, String t) {
        Matcher m = Pattern.compile("<" + t + "(?:\\s[^>]*)?>(.*?)</" + t + ">", Pattern.DOTALL).matcher(b);
        if (!m.find()) return "";
        return m.group(1).replace("<![CDATA[", "").replace("]]>", "").trim();
    }

    /** Fuentes de la última respuesta (para enseñarlas debajo). */
    static final List<String[]> lastSources = new ArrayList<>();

    /** La respuesta con titulares, o null si no piden noticias. Bloquea (red): llamar fuera del hilo principal. */
    public static String handle(String q) {
        String n = Actions.norm(q);
        if (!asks(n)) return null;
        String lang = Brain.langCode(q);
        String[] r = region(lang);
        String tail = "hl=" + r[0] + "&gl=" + r[1] + "&ceid=" + r[2];
        List<Item> all = new ArrayList<>();
        try {
            String qq = query(n);
            List<String> secs = sections(n);
            if (qq != null && secs.isEmpty()) {
                all.addAll(fetch("https://news.google.com/rss/search?q=" + URLEncoder.encode(qq + " when:7d", "UTF-8") + "&" + tail, 5));
            } else if (!secs.isEmpty()) {
                int each = secs.size() == 1 ? 4 : secs.size() == 2 ? 2 : 1;
                for (String s : secs) {
                    List<Item> l = fetch("https://news.google.com/rss/headlines/section/topic/" + s + "?" + tail, each + 2);
                    int k = 0;
                    for (Item i : l) if (k < each && !dup(all, i)) { all.add(i); k++; }
                }
            } else {
                all.addAll(fetch("https://news.google.com/rss?" + tail, 4));
            }
        } catch (Exception e) {
            return say(lang, "No he podido mirar las noticias ahora (¿hay internet?).", "Non riesco a leggere le notizie adesso (c'è internet?).",
                    "I couldn't check the news right now (is there internet?).");
        }
        if (all.isEmpty()) return say(lang, "No he encontrado noticias recientes sobre eso.", "Non ho trovato notizie recenti su questo.", "I found no recent news about that.");
        synchronized (lastSources) {
            lastSources.clear();
            for (Item i : all) lastSources.add(new String[]{i.source.isEmpty() ? Web.host(i.link) : i.source, i.link});
        }
        StringBuilder b = new StringBuilder(say(lang, "Esto es lo último que encuentro: ", "Ecco le ultime: ", "Here's the latest: "));
        for (int k = 0; k < all.size(); k++) {
            Item i = all.get(k);
            String t = i.title.trim();
            if (!t.matches(".*[.!?…]$")) t += ".";
            b.append(t);
            if (!i.source.isEmpty()) b.append(" (").append(i.source).append(ago(i.when, lang)).append(")");
            b.append(k + 1 < all.size() ? " " : "");
        }
        b.append(say(lang, " Si quieres más de alguna, dímelo.", " Se vuoi saperne di più su una, dimmelo.", " Tell me if you want more on any of them."));
        return b.toString();
    }

    static boolean dup(List<Item> l, Item i) { for (Item x : l) if (x.title.equals(i.title)) return true; return false; }

    static String ago(long when, String lang) {
        if (when <= 0) return "";
        long h = (System.currentTimeMillis() - when) / 3_600_000L;
        if (h < 0) return "";
        if (h < 1) return say(lang, ", hace un rato", ", poco fa", ", just now");
        if (h < 24) return say(lang, ", hace " + h + " h", ", " + h + " ore fa", ", " + h + "h ago");
        long d = h / 24;
        return say(lang, ", hace " + d + (d == 1 ? " día" : " días"), ", " + d + (d == 1 ? " giorno fa" : " giorni fa"), ", " + d + (d == 1 ? " day ago" : " days ago"));
    }

    static String say(String lang, String es, String it, String en) { return "it".equals(lang) ? it : "en".equals(lang) ? en : es; }

    static String date(long t) { return new SimpleDateFormat("dd/MM HH:mm", Locale.ROOT).format(new Date(t)); }
}
