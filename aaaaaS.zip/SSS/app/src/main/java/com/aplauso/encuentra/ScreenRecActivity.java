package com.aplauso.encuentra;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * v1.6 · GRABAR LA PANTALLA: sonido (ninguno · interno · micrófono · los dos con su volumen), calidad y fps.
 * Con «autostart» (desde la voz: «Chloe, graba la pantalla») pide el permiso de Android y empieza solo.
 */
public class ScreenRecActivity extends NeonActivity {
    static final int REQ_CAP = 61, REQ_MIC = 62;
    TextView status, go;
    TextView[] aBtn = new TextView[4], rBtn = new TextView[3], fBtn = new TextView[2];
    static final String[] AUDIO = {"none", "internal", "mic", "hybrid"};
    static final String[] AUDIO_L = {"🔇 SIN SONIDO", "🔊 INTERNO", "🎤 MICRÓFONO", "🎧 LOS DOS"};
    static final int[] RES = {720, 1080, 0};
    static final String[] RES_L = {"720p", "1080p", "MÁXIMA"};
    static final int[] FPS = {30, 60};
    LinearLayout vols;

    LinearLayout.LayoutParams sp(int dp) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dpi(dp); return lp; }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen(L.t("⏺ GRABAR PANTALLA"));
        LinearLayout a = panel("◢ SONIDO");
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this);
        for (int i = 0; i < 4; i++) {
            final int k = i;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i % 2 == 0) lp.rightMargin = dpi(6);
            aBtn[i] = button(AUDIO_L[i], v -> { p.edit().putString("rec_audio", AUDIO[k]).apply(); marks(); });
            aBtn[i].setTextSize(12);
            (i < 2 ? r1 : r2).addView(aBtn[i], lp);
        }
        a.addView(r1);
        a.addView(r2, sp(6));
        vols = new LinearLayout(this);
        vols.setOrientation(LinearLayout.VERTICAL);
        slider(vols, "Volumen del sonido interno", "rec_vol_in", 100, 0, 200, " %", null);
        slider(vols, "Volumen del micrófono", "rec_vol_mic", 100, 0, 200, " %", null);
        a.addView(vols, sp(8));
        a.addView(text("Interno = juegos, vídeos y música del móvil. Algunas apps (llamadas, WhatsApp, música protegida) no dejan grabar su sonido.", 11), sp(6));
        col.addView(a, gapBelow(12));

        LinearLayout q = panel("◢ CALIDAD");
        LinearLayout r3 = new LinearLayout(this), r4 = new LinearLayout(this);
        for (int i = 0; i < 3; i++) {
            final int k = i;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i < 2) lp.rightMargin = dpi(6);
            rBtn[i] = button(RES_L[i], v -> { p.edit().putInt("rec_res", RES[k]).apply(); marks(); });
            rBtn[i].setTextSize(12);
            r3.addView(rBtn[i], lp);
        }
        for (int i = 0; i < 2; i++) {
            final int k = i;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i < 1) lp.rightMargin = dpi(6);
            fBtn[i] = button(FPS[i] + " FPS", v -> { p.edit().putInt("rec_fps", FPS[k]).apply(); marks(); });
            fBtn[i].setTextSize(12);
            r4.addView(fBtn[i], lp);
        }
        q.addView(r3);
        q.addView(r4, sp(6));
        col.addView(q, gapBelow(12));

        LinearLayout g = panel(null);
        go = button("", v -> toggle());
        g.addView(go);
        status = text("", 13);
        status.setTextColor(Color.rgb(170, 180, 200));
        g.addView(status, sp(8));
        g.addView(text("Android te preguntará cada vez si dejas grabar la pantalla: es obligatorio. Pausa y parar están en la notificación, "
                + "o dile a Chloe «para de grabar».", 11), sp(6));
        g.addView(button("🎬 ABRIR EL ÚLTIMO VÍDEO", v -> {
            if (ScreenRec.result == null) { toast(L.t("Todavía no hay vídeo.")); return; }
            try { startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(ScreenRec.result, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)); }
            catch (Exception e) { toast(L.t("Está en tus vídeos (SSS+).")); }
        }), sp(8));
        col.addView(g, gapBelow(12));
        marks();
        h.post(tick);
        if (getIntent().getBooleanExtra("autostart", false) && !ScreenRec.running) h.postDelayed(this::start, 300);
    }

    void marks() {
        String au = ScreenRec.audio(this);
        for (int i = 0; i < 4; i++) aBtn[i].setAlpha(AUDIO[i].equals(au) ? 1f : 0.45f);
        int res = p.getInt("rec_res", 1080), fps = p.getInt("rec_fps", 60);
        for (int i = 0; i < 3; i++) rBtn[i].setAlpha(RES[i] == res ? 1f : 0.45f);
        for (int i = 0; i < 2; i++) fBtn[i].setAlpha(FPS[i] == fps ? 1f : 0.45f);
        float ai = au.equals("internal") || au.equals("hybrid") ? 1f : 0.3f, am = au.equals("mic") || au.equals("hybrid") ? 1f : 0.3f;
        vols.getChildAt(0).setAlpha(ai); vols.getChildAt(1).setAlpha(ai);
        vols.getChildAt(2).setAlpha(am); vols.getChildAt(3).setAlpha(am);
    }

    void toggle() { if (ScreenRec.running) ScreenRec.stop(this); else start(); }

    void start() {
        if (!"none".equals(ScreenRec.audio(this)) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        startActivityForResult(getSystemService(MediaProjectionManager.class).createScreenCaptureIntent(), REQ_CAP);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] pp, int[] r) {
        super.onRequestPermissionsResult(req, pp, r);
        if (req == REQ_MIC) {
            if (r.length == 0 || r[0] != PackageManager.PERMISSION_GRANTED) toast(L.t("Sin el micrófono, se graba sin sonido."));
            startActivityForResult(getSystemService(MediaProjectionManager.class).createScreenCaptureIntent(), REQ_CAP);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_CAP) return;
        if (res != RESULT_OK || data == null) { toast(L.t("No has dado permiso para grabar.")); return; }
        Intent i = new Intent(this, ScreenRec.class).putExtra("code", res).putExtra("data", data);
        startForegroundService(i);
        if (getIntent().getBooleanExtra("autostart", false)) moveTaskToBack(true);   // que se vea lo que quieres grabar
    }

    final Runnable tick = new Runnable() {
        public void run() {
            if (isFinishing()) return;
            if (ScreenRec.running) {
                long s = (android.os.SystemClock.elapsedRealtime() - ScreenRec.startedAt - ScreenRec.pausedTotalMs
                        - (ScreenRec.paused ? android.os.SystemClock.elapsedRealtime() - ScreenRec.pausedAtMs : 0)) / 1000;
                status.setText((ScreenRec.paused ? "⏸ " : "⏺ ") + s / 60 + ":" + String.format(java.util.Locale.ROOT, "%02d", s % 60));
                go.setText(L.t("⏹ PARAR Y GUARDAR"));
            } else {
                status.setText(ScreenRec.status);
                go.setText(L.t("⏺ EMPEZAR A GRABAR"));
            }
            h.postDelayed(this, 500);
        }
    };

    @Override protected void onDestroy() { h.removeCallbacks(tick); super.onDestroy(); }
}
