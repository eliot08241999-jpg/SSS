package com.aplauso.encuentra;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 * Modelo 3D en triángulos sueltos (x,y,z por vértice).
 * Lee STL (texto o binario), OBJ, FBX (binario y texto), glTF / GLB y VRM (que es un GLB con extras).
 * Escribe STL, OBJ, FBX (binario 7.4) y GLB.
 */
public class Mesh3D {
    float[] v = new float[0];      // 9 floats por triángulo
    int tris;
    int originalTris;
    float sizeX, sizeY, sizeZ;     // tamaño real antes de normalizar

    static final int MAX_TRIS = 150_000;
    static final String[] READ_EXT = {"stl", "obj", "fbx", "glb", "gltf", "vrm"};
    static final String[] WRITE_EXT = {"stl", "obj", "fbx", "glb"};

    /** Para ver: reduce los modelos enormes y los centra con tamaño 2. */
    static Mesh3D load(byte[] data, String name) throws IOException {
        Mesh3D m = loadRaw(data, name, false);
        if (m.tris == 0) throw new IOException("El modelo no tiene triángulos");
        m.decimate();
        m.normalize();
        return m;
    }

    /** Todos los triángulos con sus medidas originales (para convertir). */
    static Mesh3D loadRaw(byte[] data, String name, boolean full) throws IOException {
        String n = name.toLowerCase(Locale.ROOT);
        Mesh3D m;
        if (n.endsWith(".obj")) m = parseObj(new String(data, StandardCharsets.UTF_8));
        else if (n.endsWith(".fbx")) m = parseFbx(data);
        else if (n.endsWith(".glb") || n.endsWith(".vrm") || n.endsWith(".gltf")) m = parseGltf(data);
        else m = isBinaryStl(data) ? parseStlBinary(data, full) : parseStlAscii(new String(data, StandardCharsets.US_ASCII));
        if (m.tris == 0) throw new IOException("El modelo no tiene triángulos");
        return m;
    }

    static Mesh3D of(FloatList f) {
        Mesh3D m = new Mesh3D();
        m.tris = f.size / 9;
        m.originalTris = m.tris;
        m.v = f.trim(m.tris * 9);
        return m;
    }

    // =====================================================================
    // STL
    // =====================================================================
    static boolean isBinaryStl(byte[] d) {
        if (d.length < 84) return false;
        long count = ByteBuffer.wrap(d, 80, 4).order(ByteOrder.LITTLE_ENDIAN).getInt() & 0xffffffffL;
        if (84 + count * 50 == d.length) return true;
        String head = new String(d, 0, Math.min(d.length, 512), StandardCharsets.US_ASCII).trim().toLowerCase(Locale.ROOT);
        return !(head.startsWith("solid") && head.contains("facet"));
    }

    static Mesh3D parseStlBinary(byte[] d, boolean full) {
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        int count = (int) Math.min((d.length - 84) / 50, b.getInt(80) & 0xffffffffL);
        Mesh3D m = new Mesh3D();
        m.originalTris = count;
        int step = full ? 1 : Math.max(1, (count + MAX_TRIS - 1) / MAX_TRIS);
        m.v = new float[(count / step + 1) * 9];
        for (int i = 0; i < count; i += step) {
            int off = 84 + i * 50 + 12;
            for (int k = 0; k < 9; k++) m.v[m.tris * 9 + k] = b.getFloat(off + k * 4);
            m.tris++;
        }
        return m;
    }

    static Mesh3D parseStlAscii(String s) {
        FloatList f = new FloatList();
        int idx = 0;
        while ((idx = s.indexOf("vertex", idx)) >= 0) {
            idx += 6;
            int end = s.indexOf('\n', idx);
            if (end < 0) end = s.length();
            String[] t = s.substring(idx, end).trim().split("\\s+");
            if (t.length >= 3) {
                try { f.add(Float.parseFloat(t[0])); f.add(Float.parseFloat(t[1])); f.add(Float.parseFloat(t[2])); }
                catch (NumberFormatException ignored) {}
            }
        }
        return of(f);
    }

    // =====================================================================
    // OBJ
    // =====================================================================
    static Mesh3D parseObj(String s) {
        FloatList verts = new FloatList(), out = new FloatList();
        for (String raw : s.split("\n")) {
            String line = raw.trim();
            if (line.startsWith("v ")) {
                String[] t = line.split("\\s+");
                if (t.length >= 4) {
                    try { verts.add(Float.parseFloat(t[1])); verts.add(Float.parseFloat(t[2])); verts.add(Float.parseFloat(t[3])); }
                    catch (NumberFormatException e) { verts.add(0); verts.add(0); verts.add(0); }
                }
            } else if (line.startsWith("f ")) {
                String[] t = line.split("\\s+");
                int nv = verts.size / 3;
                int[] ids = new int[t.length - 1];
                int c = 0;
                for (int i = 1; i < t.length; i++) {
                    String tok = t[i];
                    int slash = tok.indexOf('/');
                    if (slash >= 0) tok = tok.substring(0, slash);
                    try {
                        int k = Integer.parseInt(tok);
                        k = k < 0 ? nv + k : k - 1;
                        if (k >= 0 && k < nv) ids[c++] = k;
                    } catch (NumberFormatException ignored) {}
                }
                for (int i = 1; i + 1 < c; i++) {     // abanico de triángulos
                    int[] tri = {ids[0], ids[i], ids[i + 1]};
                    for (int k : tri) { out.add(verts.a[k * 3]); out.add(verts.a[k * 3 + 1]); out.add(verts.a[k * 3 + 2]); }
                }
            }
        }
        return of(out);
    }

    // =====================================================================
    // FBX (binario y texto)
    // =====================================================================
    static class FbxNode {
        String name;
        final List<Object> props = new ArrayList<>();
        final List<FbxNode> kids = new ArrayList<>();

        FbxNode child(String n) { for (FbxNode k : kids) if (k.name.equals(n)) return k; return null; }

        List<FbxNode> all(String n) {
            List<FbxNode> r = new ArrayList<>();
            for (FbxNode k : kids) if (k.name.equals(n)) r.add(k);
            return r;
        }

        long id() { return props.isEmpty() || !(props.get(0) instanceof Number) ? 0 : ((Number) props.get(0)).longValue(); }
    }

    static final String FBX_MAGIC = "Kaydara FBX Binary  ";

    static Mesh3D parseFbx(byte[] d) throws IOException {
        if (d.length > 27 && new String(d, 0, 20, StandardCharsets.US_ASCII).equals(FBX_MAGIC)) return fbxBinary(d);
        return fbxAscii(new String(d, StandardCharsets.UTF_8));
    }

    static Mesh3D fbxBinary(byte[] d) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        int version = b.getInt(23);
        boolean wide = version >= 7500;
        FbxNode root = new FbxNode();
        root.name = "";
        int pos = 27;
        while (pos < d.length) {
            int[] next = {pos};
            FbxNode n = fbxReadNode(b, next, wide);
            if (n == null) break;
            root.kids.add(n);
            pos = next[0];
        }
        FbxNode objects = root.child("Objects");
        if (objects == null) throw new IOException("FBX sin objetos");
        // conexiones geometría → modelo, para aplicar posición, giro y escala
        Map<Long, Long> parent = new HashMap<>();
        FbxNode conns = root.child("Connections");
        if (conns != null) for (FbxNode c : conns.all("C")) {
            if (c.props.size() >= 3 && "OO".equals(c.props.get(0)) && c.props.get(1) instanceof Number && c.props.get(2) instanceof Number)
                parent.put(((Number) c.props.get(1)).longValue(), ((Number) c.props.get(2)).longValue());
        }
        Map<Long, FbxNode> models = new HashMap<>();
        for (FbxNode o : objects.all("Model")) models.put(o.id(), o);
        FloatList out = new FloatList();
        for (FbxNode g : objects.all("Geometry")) {
            FbxNode vn = g.child("Vertices"), in = g.child("PolygonVertexIndex");
            if (vn == null || in == null || vn.props.isEmpty() || in.props.isEmpty()) continue;
            double[] verts = toDoubles(vn.props.get(0));
            int[] idx = toInts(in.props.get(0));
            float[] m = null;
            Long pid = parent.get(g.id());
            if (pid != null && models.containsKey(pid)) m = fbxModelMatrix(models.get(pid), models, parent);
            fbxTriangulate(verts, idx, m, out);
        }
        return of(out);
    }

    /** Matriz del modelo (con la de sus padres): escala, giro XYZ en grados, traslación. */
    static float[] fbxModelMatrix(FbxNode model, Map<Long, FbxNode> models, Map<Long, Long> parent) {
        float[] m = Mat.identity();
        FbxNode cur = model;
        int guard = 0;
        while (cur != null && guard++ < 64) {
            double[] t = {0, 0, 0}, r = {0, 0, 0}, s = {1, 1, 1};
            FbxNode p70 = cur.child("Properties70");
            if (p70 != null) for (FbxNode p : p70.all("P")) {
                if (p.props.size() < 7 || !(p.props.get(0) instanceof String)) continue;
                String pn = (String) p.props.get(0);
                double[] val = {num(p.props.get(4)), num(p.props.get(5)), num(p.props.get(6))};
                if (pn.equals("Lcl Translation")) t = val;
                else if (pn.equals("Lcl Rotation")) r = val;
                else if (pn.equals("Lcl Scaling")) s = val;
            }
            float[] local = Mat.mul(Mat.translate((float) t[0], (float) t[1], (float) t[2]),
                    Mat.mul(Mat.eulerXYZ((float) Math.toRadians(r[0]), (float) Math.toRadians(r[1]), (float) Math.toRadians(r[2])),
                            Mat.scale((float) s[0], (float) s[1], (float) s[2])));
            m = Mat.mul(local, m);
            Long pid = parent.get(cur.id());
            cur = pid == null ? null : models.get(pid);
        }
        return m;
    }

    static double num(Object o) { return o instanceof Number ? ((Number) o).doubleValue() : 0; }

    static void fbxTriangulate(double[] verts, int[] idx, float[] m, FloatList out) {
        int nv = verts.length / 3;
        List<Integer> poly = new ArrayList<>();
        float[] p = new float[3];
        for (int raw : idx) {
            boolean end = raw < 0;
            int k = end ? ~raw : raw;
            if (k >= 0 && k < nv) poly.add(k);
            if (!end) continue;
            for (int i = 1; i + 1 < poly.size(); i++) {
                int[] tri = {poly.get(0), poly.get(i), poly.get(i + 1)};
                for (int t : tri) {
                    p[0] = (float) verts[t * 3]; p[1] = (float) verts[t * 3 + 1]; p[2] = (float) verts[t * 3 + 2];
                    if (m != null) Mat.apply(m, p);
                    out.add(p[0]); out.add(p[1]); out.add(p[2]);
                }
            }
            poly.clear();
        }
    }

    static FbxNode fbxReadNode(ByteBuffer b, int[] pos, boolean wide) throws IOException {
        int p = pos[0];
        long end, numProps;
        if (wide) { end = b.getLong(p); numProps = b.getLong(p + 8); p += 24; }
        else { end = b.getInt(p) & 0xffffffffL; numProps = b.getInt(p + 4) & 0xffffffffL; p += 12; }
        int nameLen = b.get(p) & 0xff;
        p++;
        if (end == 0) { pos[0] = p; return null; }          // registro nulo: fin de la lista
        if (end > b.capacity()) throw new IOException("FBX dañado");
        FbxNode n = new FbxNode();
        n.name = new String(b.array(), p, nameLen, StandardCharsets.US_ASCII);
        p += nameLen;
        for (long i = 0; i < numProps; i++) {
            char t = (char) b.get(p++);
            switch (t) {
                case 'Y': n.props.add((int) b.getShort(p)); p += 2; break;
                case 'C': n.props.add(b.get(p) != 0); p += 1; break;
                case 'I': n.props.add(b.getInt(p)); p += 4; break;
                case 'F': n.props.add(b.getFloat(p)); p += 4; break;
                case 'D': n.props.add(b.getDouble(p)); p += 8; break;
                case 'L': n.props.add(b.getLong(p)); p += 8; break;
                case 'S': case 'R': {
                    int len = b.getInt(p); p += 4;
                    n.props.add(t == 'S' ? new String(b.array(), p, len, StandardCharsets.UTF_8) : "raw");
                    p += len;
                    break;
                }
                case 'f': case 'd': case 'l': case 'i': case 'b': {
                    int count = b.getInt(p), enc = b.getInt(p + 4), clen = b.getInt(p + 8);
                    p += 12;
                    int esz = t == 'd' || t == 'l' ? 8 : t == 'b' ? 1 : 4;
                    byte[] raw;
                    if (enc == 1) {
                        Inflater inf = new Inflater();
                        inf.setInput(b.array(), p, clen);
                        raw = new byte[count * esz];
                        try {
                            int got = 0;
                            while (got < raw.length && !inf.finished()) {
                                int r = inf.inflate(raw, got, raw.length - got);
                                if (r == 0 && (inf.needsInput() || inf.needsDictionary())) break;
                                got += r;
                            }
                        } catch (DataFormatException e) {
                            throw new IOException("FBX: datos comprimidos dañados");
                        } finally { inf.end(); }
                    } else {
                        raw = new byte[count * esz];
                        System.arraycopy(b.array(), p, raw, 0, Math.min(raw.length, clen));
                    }
                    p += clen;
                    ByteBuffer a = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);
                    if (t == 'd') { double[] o = new double[count]; for (int k = 0; k < count; k++) o[k] = a.getDouble(k * 8); n.props.add(o); }
                    else if (t == 'f') { float[] o = new float[count]; for (int k = 0; k < count; k++) o[k] = a.getFloat(k * 4); n.props.add(o); }
                    else if (t == 'i') { int[] o = new int[count]; for (int k = 0; k < count; k++) o[k] = a.getInt(k * 4); n.props.add(o); }
                    else if (t == 'l') { long[] o = new long[count]; for (int k = 0; k < count; k++) o[k] = a.getLong(k * 8); n.props.add(o); }
                    else n.props.add(raw);
                    break;
                }
                default: throw new IOException("FBX: tipo desconocido " + t);
            }
        }
        while (p < end) {
            int[] q = {p};
            FbxNode k = fbxReadNode(b, q, wide);
            p = q[0];
            if (k == null) break;
            n.kids.add(k);
        }
        pos[0] = (int) end;
        return n;
    }

    static double[] toDoubles(Object o) {
        if (o instanceof double[]) return (double[]) o;
        if (o instanceof float[]) { float[] f = (float[]) o; double[] r = new double[f.length]; for (int i = 0; i < f.length; i++) r[i] = f[i]; return r; }
        if (o instanceof int[]) { int[] f = (int[]) o; double[] r = new double[f.length]; for (int i = 0; i < f.length; i++) r[i] = f[i]; return r; }
        return new double[0];
    }

    static int[] toInts(Object o) {
        if (o instanceof int[]) return (int[]) o;
        if (o instanceof long[]) { long[] f = (long[]) o; int[] r = new int[f.length]; for (int i = 0; i < f.length; i++) r[i] = (int) f[i]; return r; }
        if (o instanceof double[]) { double[] f = (double[]) o; int[] r = new int[f.length]; for (int i = 0; i < f.length; i++) r[i] = (int) f[i]; return r; }
        return new int[0];
    }

    /** FBX de texto: busca cada "Vertices:" y su "PolygonVertexIndex:". */
    static Mesh3D fbxAscii(String s) throws IOException {
        FloatList out = new FloatList();
        int from = 0;
        boolean any = false;
        while (true) {
            int vi = findKey(s, "Vertices:", from);
            if (vi < 0) break;
            int pi = findKey(s, "PolygonVertexIndex:", vi);
            if (pi < 0) break;
            double[] verts = asciiNumbers(s, vi + 9);
            double[] idxD = asciiNumbers(s, pi + 19);
            int[] idx = new int[idxD.length];
            for (int i = 0; i < idx.length; i++) idx[i] = (int) idxD[i];
            fbxTriangulate(verts, idx, null, out);
            any = true;
            from = pi + 19;
        }
        if (!any) throw new IOException("No se encontraron mallas en el FBX");
        return of(out);
    }

    /** Busca la clave al principio de una línea (para no confundir "Vertices:" con otras palabras). */
    static int findKey(String s, String key, int from) {
        int i = from;
        while ((i = s.indexOf(key, i)) >= 0) {
            int j = i - 1;
            while (j >= 0 && (s.charAt(j) == ' ' || s.charAt(j) == '\t')) j--;
            if (j < 0 || s.charAt(j) == '\n' || s.charAt(j) == '\r') return i;
            i += key.length();
        }
        return -1;
    }

    /** Lee números separados por comas: "*N { a: 1,2,3 }" o "1,2,3" en varias líneas. */
    static double[] asciiNumbers(String s, int p) {
        int n = s.length();
        while (p < n && Character.isWhitespace(s.charAt(p))) p++;
        boolean braces = false;
        if (p < n && s.charAt(p) == '*') {            // FBX 7: *N { a: ... }
            int br = s.indexOf('{', p);
            int a = s.indexOf("a:", br);
            if (br < 0 || a < 0) return new double[0];
            p = a + 2;
            braces = true;
        }
        List<Double> vals = new ArrayList<>();
        StringBuilder tok = new StringBuilder();
        for (; p < n; p++) {
            char ch = s.charAt(p);
            if (ch == '}' && braces) break;
            if ((ch >= '0' && ch <= '9') || ch == '-' || ch == '+' || ch == '.' || ch == 'e' || ch == 'E') { tok.append(ch); continue; }
            if (tok.length() > 0) {
                try { vals.add(Double.parseDouble(tok.toString())); } catch (NumberFormatException ignored) {}
                tok.setLength(0);
            }
            if (ch == ',' || Character.isWhitespace(ch)) {
                if (!braces && ch == '\n') {               // FBX 6: la lista sigue si la próxima línea empieza por coma o número
                    int q = p + 1;
                    while (q < n && (s.charAt(q) == ' ' || s.charAt(q) == '\t')) q++;
                    if (q < n && s.charAt(q) != ',' && !Character.isDigit(s.charAt(q)) && s.charAt(q) != '-') break;
                }
                continue;
            }
            if (!braces) break;
        }
        if (tok.length() > 0) try { vals.add(Double.parseDouble(tok.toString())); } catch (NumberFormatException ignored) {}
        double[] r = new double[vals.size()];
        for (int i = 0; i < r.length; i++) r[i] = vals.get(i);
        return r;
    }

    // =====================================================================
    // glTF / GLB / VRM
    // =====================================================================
    static Mesh3D parseGltf(byte[] d) throws IOException {
        try {
            JSONObject json;
            byte[] bin = null;
            ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
            if (d.length >= 20 && b.getInt(0) == 0x46546C67) {          // "glTF"
                int p = 12;
                String js = null;
                while (p + 8 <= d.length) {
                    int len = b.getInt(p), type = b.getInt(p + 4);
                    if (type == 0x4E4F534A) js = new String(d, p + 8, len, StandardCharsets.UTF_8);
                    else if (type == 0x004E4942) { bin = new byte[len]; System.arraycopy(d, p + 8, bin, 0, len); }
                    p += 8 + len;
                }
                if (js == null) throw new IOException("GLB sin JSON");
                json = new JSONObject(js);
            } else json = new JSONObject(new String(d, StandardCharsets.UTF_8));

            JSONArray buffersJ = json.optJSONArray("buffers");
            byte[][] buffers = new byte[buffersJ == null ? 0 : buffersJ.length()][];
            for (int i = 0; i < buffers.length; i++) {
                JSONObject bj = buffersJ.getJSONObject(i);
                String uri = bj.optString("uri", "");
                if (uri.isEmpty()) buffers[i] = bin;
                else if (uri.startsWith("data:")) buffers[i] = Base64Lite.decode(uri.substring(uri.indexOf(',') + 1));
                else throw new IOException("Este .gltf usa un archivo .bin aparte (" + uri + "). Ábrelo como .glb o con los datos incrustados.");
            }
            FloatList out = new FloatList();
            JSONArray meshes = json.optJSONArray("meshes");
            if (meshes == null) throw new IOException("El archivo no tiene mallas");
            JSONArray nodes = json.optJSONArray("nodes");
            JSONArray scenes = json.optJSONArray("scenes");
            boolean drawn = false;
            if (nodes != null && scenes != null && scenes.length() > 0) {
                JSONObject scene = scenes.getJSONObject(Math.max(0, Math.min(scenes.length() - 1, json.optInt("scene", 0))));
                JSONArray roots = scene.optJSONArray("nodes");
                if (roots != null) for (int i = 0; i < roots.length(); i++) {
                    gltfNode(json, buffers, nodes, roots.getInt(i), Mat.identity(), out, 0);
                    drawn = true;
                }
            }
            if (!drawn) for (int i = 0; i < meshes.length(); i++) gltfMesh(json, buffers, meshes.getJSONObject(i), null, out);
            return of(out);
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("glTF/VRM no válido: " + e.getMessage());
        }
    }

    static void gltfNode(JSONObject json, byte[][] buffers, JSONArray nodes, int ni, float[] parentM, FloatList out, int depth) throws Exception {
        if (depth > 64 || ni < 0 || ni >= nodes.length()) return;
        JSONObject n = nodes.getJSONObject(ni);
        float[] local;
        JSONArray mat = n.optJSONArray("matrix");
        if (mat != null && mat.length() == 16) {
            local = new float[16];
            for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) local[r * 4 + c] = (float) mat.getDouble(c * 4 + r);   // glTF es por columnas
        } else {
            JSONArray t = n.optJSONArray("translation"), r = n.optJSONArray("rotation"), s = n.optJSONArray("scale");
            float[] T = t == null ? Mat.identity() : Mat.translate((float) t.getDouble(0), (float) t.getDouble(1), (float) t.getDouble(2));
            float[] R = r == null ? Mat.identity() : Mat.quat((float) r.getDouble(0), (float) r.getDouble(1), (float) r.getDouble(2), (float) r.getDouble(3));
            float[] S = s == null ? Mat.identity() : Mat.scale((float) s.getDouble(0), (float) s.getDouble(1), (float) s.getDouble(2));
            local = Mat.mul(T, Mat.mul(R, S));
        }
        float[] world = Mat.mul(parentM, local);
        if (n.has("mesh")) {
            // las mallas con esqueleto (VRM) ya están en su pose de reposo: no se mueven con el nodo
            float[] m = n.has("skin") ? null : world;
            gltfMesh(json, buffers, json.getJSONArray("meshes").getJSONObject(n.getInt("mesh")), m, out);
        }
        JSONArray kids = n.optJSONArray("children");
        if (kids != null) for (int i = 0; i < kids.length(); i++) gltfNode(json, buffers, nodes, kids.getInt(i), world, out, depth + 1);
    }

    static void gltfMesh(JSONObject json, byte[][] buffers, JSONObject mesh, float[] m, FloatList out) throws Exception {
        JSONArray prims = mesh.optJSONArray("primitives");
        if (prims == null) return;
        float[] p = new float[3];
        for (int i = 0; i < prims.length(); i++) {
            JSONObject pr = prims.getJSONObject(i);
            int mode = pr.optInt("mode", 4);
            if (mode != 4 && mode != 5 && mode != 6) continue;      // solo triángulos
            JSONObject attrs = pr.optJSONObject("attributes");
            if (attrs == null || !attrs.has("POSITION")) continue;
            float[] pos = accessorFloats(json, buffers, attrs.getInt("POSITION"));
            int nv = pos.length / 3;
            int[] idx;
            if (pr.has("indices")) idx = accessorInts(json, buffers, pr.getInt("indices"));
            else { idx = new int[nv]; for (int k = 0; k < nv; k++) idx[k] = k; }
            List<int[]> tris = new ArrayList<>();
            if (mode == 4) for (int k = 0; k + 2 < idx.length; k += 3) tris.add(new int[]{idx[k], idx[k + 1], idx[k + 2]});
            else if (mode == 5) for (int k = 0; k + 2 < idx.length; k++)
                tris.add(k % 2 == 0 ? new int[]{idx[k], idx[k + 1], idx[k + 2]} : new int[]{idx[k + 1], idx[k], idx[k + 2]});
            else for (int k = 1; k + 1 < idx.length; k++) tris.add(new int[]{idx[0], idx[k], idx[k + 1]});
            for (int[] t : tris) {
                if (t[0] >= nv || t[1] >= nv || t[2] >= nv) continue;
                for (int vi : t) {
                    p[0] = pos[vi * 3]; p[1] = pos[vi * 3 + 1]; p[2] = pos[vi * 3 + 2];
                    if (m != null) Mat.apply(m, p);
                    out.add(p[0]); out.add(p[1]); out.add(p[2]);
                }
            }
        }
    }

    static int compSize(int ct) { return ct == 5126 || ct == 5125 ? 4 : ct == 5123 || ct == 5122 ? 2 : 1; }

    static int typeCount(String t) {
        switch (t) {
            case "SCALAR": return 1;
            case "VEC2": return 2;
            case "VEC3": return 3;
            case "VEC4": return 4;
            case "MAT4": return 16;
        }
        return 1;
    }

    static ByteBuffer viewOf(JSONObject json, byte[][] buffers, JSONObject acc, int[] strideOut) throws Exception {
        JSONObject bv = json.getJSONArray("bufferViews").getJSONObject(acc.getInt("bufferView"));
        byte[] buf = buffers[bv.optInt("buffer", 0)];
        if (buf == null) throw new IOException("faltan los datos binarios");
        int off = bv.optInt("byteOffset", 0) + acc.optInt("byteOffset", 0);
        strideOut[0] = bv.optInt("byteStride", 0);
        ByteBuffer b = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
        b.position(off);
        return b.slice().order(ByteOrder.LITTLE_ENDIAN);
    }

    static float[] accessorFloats(JSONObject json, byte[][] buffers, int ai) throws Exception {
        JSONObject acc = json.getJSONArray("accessors").getJSONObject(ai);
        int count = acc.getInt("count"), ct = acc.getInt("componentType"), nc = typeCount(acc.getString("type"));
        float[] r = new float[count * nc];
        if (!acc.has("bufferView")) return r;
        int[] st = {0};
        ByteBuffer b = viewOf(json, buffers, acc, st);
        int cs = compSize(ct), stride = st[0] > 0 ? st[0] : cs * nc;
        boolean norm = acc.optBoolean("normalized", false);
        for (int i = 0; i < count; i++)
            for (int k = 0; k < nc; k++) {
                int o = i * stride + k * cs;
                float val;
                switch (ct) {
                    case 5126: val = b.getFloat(o); break;
                    case 5123: val = b.getShort(o) & 0xffff; if (norm) val /= 65535f; break;
                    case 5122: val = b.getShort(o); if (norm) val = Math.max(-1, val / 32767f); break;
                    case 5121: val = b.get(o) & 0xff; if (norm) val /= 255f; break;
                    case 5120: val = b.get(o); if (norm) val = Math.max(-1, val / 127f); break;
                    default: val = b.getInt(o);
                }
                r[i * nc + k] = val;
            }
        return r;
    }

    static int[] accessorInts(JSONObject json, byte[][] buffers, int ai) throws Exception {
        JSONObject acc = json.getJSONArray("accessors").getJSONObject(ai);
        int count = acc.getInt("count"), ct = acc.getInt("componentType");
        int[] r = new int[count];
        int[] st = {0};
        ByteBuffer b = viewOf(json, buffers, acc, st);
        int cs = compSize(ct), stride = st[0] > 0 ? st[0] : cs;
        for (int i = 0; i < count; i++) {
            int o = i * stride;
            r[i] = ct == 5125 ? b.getInt(o) : ct == 5123 ? b.getShort(o) & 0xffff : b.get(o) & 0xff;
        }
        return r;
    }

    // =====================================================================
    // Exportar
    // =====================================================================
    /** Vértices sin repetir + índices (para OBJ, FBX y GLB). */
    static class Indexed {
        float[] pos;
        int[] idx;
        int nv;
    }

    Indexed indexed() {
        Map<Long, Integer> seen = new HashMap<>();
        FloatList pos = new FloatList();
        int[] idx = new int[tris * 3];
        int nv = 0;
        for (int i = 0; i < tris * 3; i++) {
            float x = v[i * 3], y = v[i * 3 + 1], z = v[i * 3 + 2];
            long key = ((long) Float.floatToIntBits(x) << 32) ^ (Float.floatToIntBits(y) & 0xffffffffL) ^ ((long) Float.floatToIntBits(z) * 0x9E3779B97F4A7C15L);
            Integer k = seen.get(key);
            if (k != null && (pos.a[k * 3] != x || pos.a[k * 3 + 1] != y || pos.a[k * 3 + 2] != z)) k = null;   // choque de claves
            if (k == null) {
                k = nv++;
                pos.add(x); pos.add(y); pos.add(z);
                if (!seen.containsKey(key)) seen.put(key, k);
            }
            idx[i] = k;
        }
        Indexed r = new Indexed();
        r.pos = pos.trim(nv * 3);
        r.idx = idx;
        r.nv = nv;
        return r;
    }

    byte[] export(String ext) throws IOException {
        switch (ext) {
            case "stl": return toStl();
            case "obj": return toObj();
            case "fbx": return toFbx();
            case "glb": return toGlb();
        }
        throw new IOException("Formato no soportado: " + ext);
    }

    byte[] toStl() {
        ByteBuffer b = ByteBuffer.allocate(84 + tris * 50).order(ByteOrder.LITTLE_ENDIAN);
        byte[] head = "SSS+ STL".getBytes(StandardCharsets.US_ASCII);
        b.put(head);
        b.position(80);
        b.putInt(tris);
        for (int t = 0; t < tris; t++) {
            int o = t * 9;
            float ux = v[o + 3] - v[o], uy = v[o + 4] - v[o + 1], uz = v[o + 5] - v[o + 2];
            float wx = v[o + 6] - v[o], wy = v[o + 7] - v[o + 1], wz = v[o + 8] - v[o + 2];
            float nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
            float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (len > 0) { nx /= len; ny /= len; nz /= len; }
            b.putFloat(nx); b.putFloat(ny); b.putFloat(nz);
            for (int k = 0; k < 9; k++) b.putFloat(v[o + k]);
            b.putShort((short) 0);
        }
        return b.array();
    }

    byte[] toObj() {
        Indexed ix = indexed();
        StringBuilder sb = new StringBuilder(ix.nv * 30 + tris * 20);
        sb.append("# Exportado con SSS+\n");
        sb.append("o modelo\n");
        for (int i = 0; i < ix.nv; i++)
            sb.append("v ").append(fmt(ix.pos[i * 3])).append(' ').append(fmt(ix.pos[i * 3 + 1])).append(' ').append(fmt(ix.pos[i * 3 + 2])).append('\n');
        for (int t = 0; t < tris; t++)
            sb.append("f ").append(ix.idx[t * 3] + 1).append(' ').append(ix.idx[t * 3 + 1] + 1).append(' ').append(ix.idx[t * 3 + 2] + 1).append('\n');
        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }

    static String fmt(float f) {
        if (f == (long) f && Math.abs(f) < 1e15) return String.valueOf((long) f);
        return Float.toString(f);       // exacto y rápido (puede usar notación E, que OBJ acepta)
    }

    /** GLB (glTF 2.0 binario): la base de los archivos VRM. */
    byte[] toGlb() throws IOException {
        Indexed ix = indexed();
        float[] mn = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE}, mx = {-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        for (int i = 0; i < ix.nv; i++)
            for (int k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], ix.pos[i * 3 + k]); mx[k] = Math.max(mx[k], ix.pos[i * 3 + k]); }
        int posBytes = ix.nv * 12, idxBytes = ix.idx.length * 4;
        ByteBuffer bin = ByteBuffer.allocate(pad4(posBytes + idxBytes)).order(ByteOrder.LITTLE_ENDIAN);
        for (float f : ix.pos) bin.putFloat(f);
        for (int i : ix.idx) bin.putInt(i);
        try {
            JSONObject j = new JSONObject();
            j.put("asset", new JSONObject().put("version", "2.0").put("generator", "SSS+"));
            j.put("scene", 0);
            j.put("scenes", new JSONArray().put(new JSONObject().put("nodes", new JSONArray().put(0))));
            j.put("nodes", new JSONArray().put(new JSONObject().put("mesh", 0).put("name", "modelo")));
            j.put("meshes", new JSONArray().put(new JSONObject().put("name", "modelo").put("primitives", new JSONArray().put(
                    new JSONObject().put("attributes", new JSONObject().put("POSITION", 0)).put("indices", 1).put("mode", 4)))));
            j.put("accessors", new JSONArray()
                    .put(new JSONObject().put("bufferView", 0).put("componentType", 5126).put("count", ix.nv).put("type", "VEC3")
                            .put("min", new JSONArray().put(mn[0]).put(mn[1]).put(mn[2]))
                            .put("max", new JSONArray().put(mx[0]).put(mx[1]).put(mx[2])))
                    .put(new JSONObject().put("bufferView", 1).put("componentType", 5125).put("count", ix.idx.length).put("type", "SCALAR")));
            j.put("bufferViews", new JSONArray()
                    .put(new JSONObject().put("buffer", 0).put("byteOffset", 0).put("byteLength", posBytes).put("target", 34962))
                    .put(new JSONObject().put("buffer", 0).put("byteOffset", posBytes).put("byteLength", idxBytes).put("target", 34963)));
            j.put("buffers", new JSONArray().put(new JSONObject().put("byteLength", bin.capacity())));
            byte[] js = j.toString().getBytes(StandardCharsets.UTF_8);
            int jsLen = pad4(js.length);
            int total = 12 + 8 + jsLen + 8 + bin.capacity();
            ByteBuffer o = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);
            o.putInt(0x46546C67).putInt(2).putInt(total);
            o.putInt(jsLen).putInt(0x4E4F534A).put(js);
            for (int i = js.length; i < jsLen; i++) o.put((byte) ' ');
            o.putInt(bin.capacity()).putInt(0x004E4942).put(bin.array());
            return o.array();
        } catch (org.json.JSONException e) {
            throw new IOException(e.getMessage());
        }
    }

    static int pad4(int n) { return (n + 3) & ~3; }

    // ---------- FBX binario 7.4 ----------
    byte[] toFbx() throws IOException {
        Indexed ix = indexed();
        double[] verts = new double[ix.nv * 3];
        for (int i = 0; i < verts.length; i++) verts[i] = ix.pos[i];
        int[] poly = new int[ix.idx.length];
        for (int i = 0; i < poly.length; i++) poly[i] = (i % 3 == 2) ? ~ix.idx[i] : ix.idx[i];   // el último de cada cara va negado
        long geomId = 1000001L, modelId = 1000002L;
        FbxW w = new FbxW();
        w.headerBytes();

        w.begin("FBXHeaderExtension");
        w.leaf("FBXHeaderVersion", 'I', 1003);
        w.leaf("FBXVersion", 'I', 7400);
        w.leaf("Creator", 'S', "SSS+");
        w.end();
        w.leafS("Creator", "SSS+");

        w.begin("GlobalSettings");
        w.leaf("Version", 'I', 1000);
        w.begin("Properties70");
        w.prop("UpAxis", "int", "Integer", "", 'I', 1);
        w.prop("UpAxisSign", "int", "Integer", "", 'I', 1);
        w.prop("FrontAxis", "int", "Integer", "", 'I', 2);
        w.prop("FrontAxisSign", "int", "Integer", "", 'I', 1);
        w.prop("CoordAxis", "int", "Integer", "", 'I', 0);
        w.prop("CoordAxisSign", "int", "Integer", "", 'I', 1);
        w.prop("UnitScaleFactor", "double", "Number", "", 'D', 1.0);
        w.end();
        w.end();

        w.begin("Definitions");
        w.leaf("Version", 'I', 100);
        w.leaf("Count", 'I', 2);
        w.begin("ObjectType", "Model"); w.leaf("Count", 'I', 1); w.end();
        w.begin("ObjectType", "Geometry"); w.leaf("Count", 'I', 1); w.end();
        w.end();

        w.begin("Objects");
        w.beginNode("Geometry", new Object[]{geomId, "modelo\u0000\u0001Geometry", "Mesh"});
        w.leaf("GeometryVersion", 'I', 124);
        w.arrayD("Vertices", verts);
        w.arrayI("PolygonVertexIndex", poly);
        w.end();
        w.beginNode("Model", new Object[]{modelId, "modelo\u0000\u0001Model", "Mesh"});
        w.leaf("Version", 'I', 232);
        w.begin("Properties70");
        w.end();
        w.leafS("Culling", "CullingOff");
        w.end();
        w.end();

        w.begin("Connections");
        w.beginNode("C", new Object[]{"OO", geomId, modelId}); w.end();
        w.beginNode("C", new Object[]{"OO", modelId, 0L}); w.end();
        w.end();

        w.footer(7400);
        return w.bytes();
    }

    /** Escritor mínimo de FBX binario (versión 7400, cabeceras de 32 bits). */
    static class FbxW {
        final ByteArrayOutputStream o = new ByteArrayOutputStream();
        final List<Integer> open = new ArrayList<>();
        byte[] buf = new byte[0];

        void raw(byte[] b) { o.write(b, 0, b.length); }
        void u8(int v) { o.write(v); }
        void u32(long v) { u8((int) (v & 0xff)); u8((int) ((v >> 8) & 0xff)); u8((int) ((v >> 16) & 0xff)); u8((int) ((v >> 24) & 0xff)); }
        void i64(long v) { for (int i = 0; i < 8; i++) u8((int) ((v >> (8 * i)) & 0xff)); }

        void headerBytes() {
            raw(FBX_MAGIC.getBytes(StandardCharsets.US_ASCII));
            u8(0); u8(0x1a); u8(0);
            u32(7400);
        }

        void begin(String name, Object... props) { beginNode(name, props); }

        void beginNode(String name, Object[] props) {
            ByteArrayOutputStream pb = new ByteArrayOutputStream();
            for (Object p : props) writeProp(pb, p);
            open.add(o.size());
            u32(0);                 // fin (se rellena al cerrar)
            u32(props.length);
            u32(pb.size());
            byte[] nb = name.getBytes(StandardCharsets.US_ASCII);
            u8(nb.length);
            raw(nb);
            raw(pb.toByteArray());
            // marca para saber si tiene hijos: se decide al cerrar
            childStart.add(o.size());
        }

        final List<Integer> childStart = new ArrayList<>();

        void end() {
            int start = open.remove(open.size() - 1);
            childStart.remove(childStart.size() - 1);
            for (int i = 0; i < 13; i++) u8(0);     // registro nulo que cierra la lista de hijos
            patch(start, o.size());
        }

        void leaf(String name, char type, Object value) {
            beginNode(name, new Object[]{type == 'I' ? (Object) Integer.valueOf(((Number) value).intValue())
                    : type == 'D' ? (Object) Double.valueOf(((Number) value).doubleValue()) : value});
            endLeaf();
        }

        void leafS(String name, String value) { beginNode(name, new Object[]{value}); endLeaf(); }

        /** Nodo sin hijos: no lleva registro nulo. */
        void endLeaf() {
            int start = open.remove(open.size() - 1);
            childStart.remove(childStart.size() - 1);
            patch(start, o.size());
        }

        void prop(String name, String type, String label, String flags, char vt, Object value) {
            beginNode("P", new Object[]{name, type, label, flags, vt == 'I' ? (Object) Integer.valueOf(((Number) value).intValue()) : (Object) Double.valueOf(((Number) value).doubleValue())});
            endLeaf();
        }

        void arrayD(String name, double[] a) {
            ByteBuffer b = ByteBuffer.allocate(a.length * 8).order(ByteOrder.LITTLE_ENDIAN);
            for (double d : a) b.putDouble(d);
            arrayNode(name, 'd', a.length, b.array());
        }

        void arrayI(String name, int[] a) {
            ByteBuffer b = ByteBuffer.allocate(a.length * 4).order(ByteOrder.LITTLE_ENDIAN);
            for (int d : a) b.putInt(d);
            arrayNode(name, 'i', a.length, b.array());
        }

        void arrayNode(String name, char t, int count, byte[] data) {
            byte[] z = deflate(data);
            ByteArrayOutputStream pb = new ByteArrayOutputStream();
            pb.write(t);
            wr32(pb, count);
            wr32(pb, 1);            // comprimido con zlib
            wr32(pb, z.length);
            pb.write(z, 0, z.length);
            open.add(o.size());
            u32(0);
            u32(1);
            u32(pb.size());
            byte[] nb = name.getBytes(StandardCharsets.US_ASCII);
            u8(nb.length);
            raw(nb);
            raw(pb.toByteArray());
            childStart.add(o.size());
            endLeaf();
        }

        static byte[] deflate(byte[] in) {
            Deflater d = new Deflater();
            d.setInput(in);
            d.finish();
            ByteArrayOutputStream out = new ByteArrayOutputStream(in.length / 2 + 64);
            byte[] tmp = new byte[65536];
            while (!d.finished()) {
                int n = d.deflate(tmp);
                out.write(tmp, 0, n);
            }
            d.end();
            return out.toByteArray();
        }

        static void wr32(ByteArrayOutputStream b, long v) {
            b.write((int) (v & 0xff)); b.write((int) ((v >> 8) & 0xff)); b.write((int) ((v >> 16) & 0xff)); b.write((int) ((v >> 24) & 0xff));
        }

        static void writeProp(ByteArrayOutputStream b, Object p) {
            if (p instanceof Integer) { b.write('I'); wr32(b, (Integer) p); }
            else if (p instanceof Long) {
                b.write('L');
                long v = (Long) p;
                for (int i = 0; i < 8; i++) b.write((int) ((v >> (8 * i)) & 0xff));
            } else if (p instanceof Double) {
                b.write('D');
                long v = Double.doubleToLongBits((Double) p);
                for (int i = 0; i < 8; i++) b.write((int) ((v >> (8 * i)) & 0xff));
            } else {
                byte[] s = String.valueOf(p).getBytes(StandardCharsets.UTF_8);
                b.write('S');
                wr32(b, s.length);
                b.write(s, 0, s.length);
            }
        }

        final List<int[]> patches = new ArrayList<>();
        void patch(int at, int value) { patches.add(new int[]{at, value}); }

        void footer(int version) {
            for (int i = 0; i < 13; i++) u8(0);     // fin de la lista principal
            raw(new byte[]{(byte) 0xfa, (byte) 0xbc, (byte) 0xab, 0x09, (byte) 0xd0, (byte) 0xc8, (byte) 0xd4, 0x66,
                    (byte) 0xb1, 0x76, (byte) 0xfb, (byte) 0x83, 0x1c, (byte) 0xf7, 0x26, 0x7e});
            u32(0);
            int ofs = o.size();
            int pad = ((ofs + 15) & ~15) - ofs;
            if (pad == 0) pad = 16;
            for (int i = 0; i < pad; i++) u8(0);
            u32(version);
            for (int i = 0; i < 120; i++) u8(0);
            raw(new byte[]{(byte) 0xf8, 0x5a, (byte) 0x8c, 0x6a, (byte) 0xde, (byte) 0xf5, (byte) 0xd9, 0x7e,
                    (byte) 0xec, (byte) 0xe9, 0x0c, (byte) 0xe3, 0x75, (byte) 0x8f, 0x29, 0x0b});
        }

        byte[] bytes() {
            byte[] r = o.toByteArray();
            for (int[] p : patches) {
                int at = p[0], v = p[1];
                r[at] = (byte) v; r[at + 1] = (byte) (v >> 8); r[at + 2] = (byte) (v >> 16); r[at + 3] = (byte) (v >> 24);
            }
            return r;
        }
    }

    // =====================================================================
    // Matrices 4×4 (por filas)
    // =====================================================================
    static class Mat {
        static float[] identity() { return new float[]{1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}; }

        static float[] translate(float x, float y, float z) { float[] m = identity(); m[3] = x; m[7] = y; m[11] = z; return m; }

        static float[] scale(float x, float y, float z) { float[] m = identity(); m[0] = x; m[5] = y; m[10] = z; return m; }

        static float[] mul(float[] a, float[] b) {
            float[] r = new float[16];
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++) {
                    float s = 0;
                    for (int k = 0; k < 4; k++) s += a[i * 4 + k] * b[k * 4 + j];
                    r[i * 4 + j] = s;
                }
            return r;
        }

        static float[] rotX(float a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0, 0, 0, 0, 1}; }
        static float[] rotY(float a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0, 0, 0, 0, 1}; }
        static float[] rotZ(float a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}; }

        /** Giro de FBX (orden XYZ: primero X, luego Y, luego Z). */
        static float[] eulerXYZ(float x, float y, float z) { return mul(rotZ(z), mul(rotY(y), rotX(x))); }

        static float[] quat(float x, float y, float z, float w) {
            return new float[]{
                    1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w), 0,
                    2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w), 0,
                    2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y), 0,
                    0, 0, 0, 1};
        }

        static void apply(float[] m, float[] p) {
            float x = p[0], y = p[1], z = p[2];
            p[0] = m[0] * x + m[1] * y + m[2] * z + m[3];
            p[1] = m[4] * x + m[5] * y + m[6] * z + m[7];
            p[2] = m[8] * x + m[9] * y + m[10] * z + m[11];
        }
    }

    /** Base64 sin depender de android.util (para glTF con datos incrustados). */
    static class Base64Lite {
        static byte[] decode(String s) {
            int[] map = new int[128];
            java.util.Arrays.fill(map, -1);
            String abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
            for (int i = 0; i < abc.length(); i++) map[abc.charAt(i)] = i;
            map['-'] = 62; map['_'] = 63;
            ByteArrayOutputStream out = new ByteArrayOutputStream(s.length() * 3 / 4);
            int acc = 0, bits = 0;
            for (int i = 0; i < s.length(); i++) {
                char ch = s.charAt(i);
                if (ch >= 128 || map[ch] < 0) continue;
                acc = (acc << 6) | map[ch];
                bits += 6;
                if (bits >= 8) { bits -= 8; out.write((acc >> bits) & 0xff); }
            }
            return out.toByteArray();
        }
    }

    /** Si el modelo es enorme, muestra un triángulo de cada N para que gire con fluidez. */
    void decimate() {
        if (tris <= MAX_TRIS) return;
        int step = (tris + MAX_TRIS - 1) / MAX_TRIS;
        int nt = tris / step;
        float[] nv = new float[nt * 9];
        for (int i = 0; i < nt; i++) System.arraycopy(v, i * step * 9, nv, i * 9, 9);
        v = nv;
        tris = nt;
    }

    /** Centra el modelo y lo escala para que su lado más largo mida 2. */
    void normalize() {
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, minZ = Float.MAX_VALUE;
        float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE, maxZ = -Float.MAX_VALUE;
        for (int i = 0; i < tris * 9; i += 3) {
            minX = Math.min(minX, v[i]); maxX = Math.max(maxX, v[i]);
            minY = Math.min(minY, v[i + 1]); maxY = Math.max(maxY, v[i + 1]);
            minZ = Math.min(minZ, v[i + 2]); maxZ = Math.max(maxZ, v[i + 2]);
        }
        sizeX = maxX - minX; sizeY = maxY - minY; sizeZ = maxZ - minZ;
        float cx = (minX + maxX) / 2, cy = (minY + maxY) / 2, cz = (minZ + maxZ) / 2;
        float s = 2f / Math.max(1e-6f, Math.max(sizeX, Math.max(sizeY, sizeZ)));
        for (int i = 0; i < tris * 9; i += 3) {
            v[i] = (v[i] - cx) * s;
            v[i + 1] = (v[i + 1] - cy) * s;
            v[i + 2] = (v[i + 2] - cz) * s;
        }
    }

    static class FloatList {
        float[] a = new float[1024];
        int size;
        void add(float f) {
            if (size == a.length) a = java.util.Arrays.copyOf(a, a.length * 2);
            a[size++] = f;
        }
        float[] trim(int n) { return java.util.Arrays.copyOf(a, n); }
    }
}
