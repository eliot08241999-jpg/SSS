package com.aplauso.encuentra;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;

/**
 * Editor de sonido: grabar con el micrófono, recortar, subir/bajar volumen, fundidos,
 * guardar como WAV y usarlo directamente como sonido de SSS+ (¡la oveja!).
 */
public class AudioEditorActivity extends NeonActivity {
    static final int REQ_MIC = 40;

    Uri uri;
    String name = "Sonido";
    long durMs;
    int startT = 0, endT = 0;         // décimas de segundo
    int gainPct = 100, fadeIn = 0, fadeOut = 0; // fundidos en décimas de segundo
    // efectos
    final float[] eqDb = new float[5];
    boolean use8d, fxPlaying;
    int period8d = 10, reverb8d = 30;
    TextView fxBtn;

    LinearLayout col, editArea;
    TextView recBtn, recInfo, title, range, playBtn, status;
    SeekBar startBar, endBar;
    MediaRecorder recorder;
    File recFile;
    long recStart;
    MediaPlayer player;
    boolean busy;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        col = screen("SONIDO");

        LinearLayout rec = panel("◢ GRABADORA");
        recBtn = button("🎙 GRABAR", v -> toggleRecord());
        rec.addView(recBtn);
        recInfo = text("Graba con el micrófono y luego edítalo aquí abajo.", 13);
        recInfo.setPadding(0, dpi(6), 0, 0);
        rec.addView(recInfo);
        col.addView(rec, gapBelow(12));

        editArea = new LinearLayout(this);
        editArea.setOrientation(LinearLayout.VERTICAL);
        col.addView(editArea);

        uri = getIntent().getData();
        String n = getIntent().getStringExtra("name");
        if (n != null) name = n;
        if (uri != null) buildEditor();
        else if (getIntent().getBooleanExtra("record", false)) toggleRecord();
    }

    // ---------------- Grabadora ----------------
    private void toggleRecord() {
        if (recorder != null) { stopRecording(); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        stopPreview();
        try {
            recFile = new File(getCacheDir(), "grabacion_" + Media.stamp() + ".m4a");
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128_000);
            recorder.setAudioSamplingRate(44_100);
            recorder.setOutputFile(recFile.getPath());
            recorder.prepare();
            recorder.start();
            recStart = SystemClock.elapsedRealtime();
            recBtn.setText(L.t("■ PARAR GRABACIÓN"));
        } catch (Exception e) {
            recorder = null;
            toast("No se pudo usar el micrófono");
        }
    }

    private void stopRecording() {
        try { recorder.stop(); } catch (Exception ignored) {}
        recorder.release();
        recorder = null;
        recBtn.setText(L.t("🎙 GRABAR OTRA VEZ"));
        if (recFile != null && recFile.length() > 0) {
            uri = Uri.fromFile(recFile);
            name = "Grabación " + Media.stamp();
            recInfo.setText(L.t("Grabación lista ✓ — edítala abajo y guárdala."));
            buildEditor();
        } else {
            recInfo.setText(L.t("La grabación fue demasiado corta."));
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_MIC && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            toggleRecord();
    }

    // ---------------- Editor ----------------
    private void buildEditor() {
        editArea.removeAllViews();
        durMs = MediaTools.durationMs(this, uri);
        if (durMs <= 0) {
            editArea.addView(text("No se pudo leer este audio.", 15));
            return;
        }
        int total = (int) Math.max(1, durMs / 100);
        startT = 0;
        endT = total;
        gainPct = 100;
        fadeIn = fadeOut = 0;

        title = neonText("🎵 " + name, 15);
        editArea.addView(title, gapBelow(8));

        playBtn = button("▶ ESCUCHAR TRAMO", v -> togglePreview());
        editArea.addView(playBtn, gapBelow(12));

        // v1.2: datos de la canción (título, autor, año, portada…)
        editArea.addView(button("🏷 TÍTULO, AUTOR, AÑO Y PORTADA", v -> startActivity(new Intent(this, AudioTagActivity.class).setData(uri))), gapBelow(8));
        editArea.addView(button("🔄 CAMBIAR FORMATO (WAV, M4A, OGG, FLAC)", v -> startActivity(new Intent(this, AudioConvertActivity.class).setData(uri))), gapBelow(12));
        LinearLayout cut = panel("◢ RECORTAR");
        range = text("", 15);
        cut.addView(range);
        startBar = plainSlider(cut, "Inicio (décimas de s)", 0, total, 0, "", v -> {
            startT = Math.min(v, endT - 1);
            if (startT != v) startBar.setProgress(startT);
            showRange();
        });
        endBar = plainSlider(cut, "Final (décimas de s)", 0, total, total, "", v -> {
            endT = Math.max(v, startT + 1);
            if (endT != v) endBar.setProgress(endT);
            showRange();
        });
        editArea.addView(cut, gapBelow(12));

        LinearLayout fx = panel("◢ VOLUMEN Y FUNDIDOS");
        plainSlider(fx, "Volumen", 10, 300, 100, " %", v -> gainPct = v);
        plainSlider(fx, "Fundido de entrada (décimas)", 0, 50, 0, "", v -> fadeIn = v);
        plainSlider(fx, "Fundido de salida (décimas)", 0, 50, 0, "", v -> fadeOut = v);
        TextView tip = text("Para la alarma de SSS+, mejor un tramo corto (1–5 s) y volumen alto.", 12);
        tip.setPadding(0, dpi(4), 0, 0);
        fx.addView(tip);
        editArea.addView(fx, gapBelow(12));

        LinearLayout ef = panel("◢ EFECTOS: 8D Y ECUALIZADOR");
        android.widget.Switch sw8 = neonSwitch("🎧 Audio 8D (mejor con auriculares)");
        sw8.setOnCheckedChangeListener((v, on) -> use8d = on);
        ef.addView(sw8);
        plainSlider(ef, "Una vuelta cada", 4, 20, period8d, " s", v -> period8d = v);
        plainSlider(ef, "Reverberación (8D)", 0, 100, reverb8d, " %", v -> reverb8d = v);
        TextView eqT = text("Ecualizador", 14);
        eqT.setPadding(0, dpi(12), 0, 0);
        ef.addView(eqT);
        for (int i = 0; i < 5; i++) {
            final int band = i;
            plainSlider(ef, AudioFx.EQ_NAMES[i], -12, 12, 0, " dB", v -> eqDb[band] = v);
        }
        fxBtn = button("▶ ESCUCHAR CON EFECTOS", v -> previewFx());
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
        flp.topMargin = dpi(10);
        ef.addView(fxBtn, flp);
        TextView efTip = text("Los efectos se aplican al guardar y al usarlo como sonido de SSS+.", 12);
        efTip.setPadding(0, dpi(6), 0, 0);
        ef.addView(efTip);
        editArea.addView(ef, gapBelow(12));

        editArea.addView(button("🐑 USAR COMO SONIDO DE SSS+", v -> process(true)), gapBelow(8));
        editArea.addView(button("💾 GUARDAR EN MÚSICA", v -> process(false)), gapBelow(8));
        status = text("Se guarda como WAV en SSS+/Audios. El original no se toca.", 12);
        editArea.addView(status);
        showRange();
    }

    private void showRange() {
        range.setText(L.t(String.format(java.util.Locale.US, "Tramo: %.1f s → %.1f s  (%.1f s)",
                startT / 10f, endT / 10f, (endT - startT) / 10f)));
    }

    private void togglePreview() {
        if (player != null) { stopPreview(); return; }
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA).build());
            player.setDataSource(this, uri);
            player.prepare();
            float vol = Math.min(1f, gainPct / 100f);
            player.setVolume(vol, vol);
            player.seekTo(startT * 100);
            player.setOnCompletionListener(m -> stopPreview());
            player.start();
            playBtn.setText(L.t("■ PARAR"));
        } catch (Exception e) {
            stopPreview();
            toast("No se puede reproducir");
        }
    }

    /** Procesa (máx. 30 s) con los efectos y lo reproduce. */
    private void previewFx() {
        if (fxPlaying || player != null) { stopPreview(); return; }
        if (busy) return;
        busy = true;
        fxBtn.setText(L.t("⏳ PREPARANDO…"));
        long s = startT * 100_000L, e = Math.min(endT * 100_000L, s + 30_000_000L);
        float g = gainPct / 100f;
        new Thread(() -> {
            File tmp = new File(getCacheDir(), "fx_preview.wav");
            boolean ok;
            try {
                MediaTools.toWav(this, uri, tmp, s, e, g, fadeIn * 100_000L, fadeOut * 100_000L, null);
                AudioFx.apply(tmp, eqDb, use8d, period8d, reverb8d / 100f);
                ok = true;
            } catch (Throwable t) { ok = false; }
            boolean fok = ok;
            runOnUiThread(() -> {
                busy = false;
                if (!fok) { fxBtn.setText(L.t("▶ ESCUCHAR CON EFECTOS")); toast("No se pudo procesar"); return; }
                try {
                    player = new MediaPlayer();
                    player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build());
                    player.setDataSource(tmp.getPath());
                    player.prepare();
                    player.setOnCompletionListener(m -> stopPreview());
                    player.start();
                    fxPlaying = true;
                    fxBtn.setText(L.t("■ PARAR"));
                } catch (Exception ex) {
                    stopPreview();
                    toast("No se puede reproducir");
                }
            });
        }).start();
    }

    private void stopPreview() {
        fxPlaying = false;
        if (fxBtn != null) fxBtn.setText(L.t("▶ ESCUCHAR CON EFECTOS"));
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
        if (playBtn != null) playBtn.setText(L.t("▶ ESCUCHAR TRAMO"));
    }

    @Override
    protected void onTick() {
        if (player != null) {
            try { if (!fxPlaying && player.getCurrentPosition() >= endT * 100) stopPreview(); } catch (Exception ignored) {}
        }
        if (recorder != null) {
            long s = (SystemClock.elapsedRealtime() - recStart) / 1000;
            recInfo.setText(L.t("● Grabando… " + GalleryActivity.time(s * 1000)));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopPreview();
        if (recorder != null) stopRecording();
    }

    /** Convierte el tramo a WAV con volumen y fundidos; lo guarda en Música o como alarma de SSS+. */
    private void process(boolean asAlarm) {
        if (busy) return;
        busy = true;
        stopPreview();
        long s = startT * 100_000L, e = endT * 100_000L;
        float g = gainPct / 100f;
        long fi = fadeIn * 100_000L, fo = fadeOut * 100_000L;
        status.setText(L.t("Procesando… 0 %"));
        new Thread(() -> {
            String msg;
            try {
                if (asAlarm) {
                    File out = new File(getFilesDir(), "alarma_sss.wav");
                    File tmp = new File(getCacheDir(), "alarma_tmp.wav");
                    MediaTools.toWav(this, uri, tmp, s, e, g, fi, fo, f -> progress(f));
                    AudioFx.apply(tmp, eqDb, use8d, period8d, reverb8d / 100f);
                    if (out.exists()) out.delete();
                    if (!tmp.renameTo(out)) throw new Exception("rename");
                    p.edit().putString("sound_uri", Uri.fromFile(out).toString())
                            .putString("sound_name", name + " (editado)").apply();
                    msg = "¡Listo! Ahora SSS+ suena con este sonido 🐑";
                } else {
                    File tmp = new File(getCacheDir(), "audio_" + System.currentTimeMillis() + ".wav");
                    MediaTools.toWav(this, uri, tmp, s, e, g, fi, fo, f -> progress(f));
                    AudioFx.apply(tmp, eqDb, use8d, period8d, reverb8d / 100f);
                    Uri saved = Media.save(this, tmp, Media.TYPE_AUDIO, "SSS_" + Media.stamp() + ".wav", "audio/wav");
                    msg = saved != null ? "Guardado en SSS+/Audios ✓" : "No se pudo guardar";
                }
            } catch (Exception ex) {
                msg = "No se pudo procesar este audio";
            }
            String fm = msg;
            runOnUiThread(() -> {
                busy = false;
                status.setText(fm);
                toast(fm);
            });
        }).start();
    }

    private volatile int lastPct = -1;

    private void progress(float f) {
        int pct = Math.round(f * 100);
        if (pct == lastPct) return;
        lastPct = pct;
        runOnUiThread(() -> status.setText(L.t("Procesando… " + pct + " %")));
    }
}
