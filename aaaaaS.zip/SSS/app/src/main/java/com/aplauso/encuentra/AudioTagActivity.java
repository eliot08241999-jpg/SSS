package com.aplauso.encuentra;

import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * 🏷 DATOS DEL AUDIO (v1.2): título, artista, álbum, año, género, pista, comentario y portada de una canción.
 * Escribe etiquetas ID3 (las que leen todos los reproductores) en archivos MP3. Se puede guardar una copia
 * o cambiar el archivo original.
 */
public class AudioTagActivity extends NeonActivity {
    static final int REQ_AUDIO = 71, REQ_COVER = 72, REQ_WRITE = 73;
    Uri uri;
    String fileName = "audio";
    EditText title, artist, album, year, genre, track, comment;
    ImageView coverView;
    byte[] cover;               // JPEG de la portada (null = sin portada)
    TextView info;
    boolean mp3;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🏷 DATOS DEL AUDIO");
        LinearLayout pn = panel("◢ CANCIÓN");
        info = text(L.t("Elige una canción en MP3 para ver y cambiar sus datos."), 13);
        pn.addView(info);
        pn.addView(button("🎵 ELEGIR AUDIO", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_AUDIO);
        }), gapBelow(10));
        title = field(pn, "Título");
        artist = field(pn, "Artista / autor");
        album = field(pn, "Álbum");
        year = field(pn, "Año");
        year.setInputType(InputType.TYPE_CLASS_NUMBER);
        genre = field(pn, "Género");
        track = field(pn, "Nº de pista");
        track.setInputType(InputType.TYPE_CLASS_NUMBER);
        comment = field(pn, "Comentario");
        col.addView(pn, gapBelow(12));

        LinearLayout cv = panel("◢ PORTADA");
        coverView = new ImageView(this);
        coverView.setAdjustViewBounds(true);
        coverView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        cv.addView(coverView, new LinearLayout.LayoutParams(-1, dpi(220)));
        cv.addView(button("🖼 ELEGIR IMAGEN DE PORTADA", v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, L.t("Elige la portada")), REQ_COVER);
        }), gapBelow(8));
        cv.addView(button("✕ QUITAR PORTADA", v -> { cover = null; coverView.setImageBitmap(null); }), gapBelow(8));
        col.addView(cv, gapBelow(12));

        LinearLayout sv = panel("◢ GUARDAR");
        sv.addView(button("💾 GUARDAR UNA COPIA (en SSS+/Música)", v -> save(false)), gapBelow(8));
        sv.addView(button("✏ CAMBIAR EL ARCHIVO ORIGINAL", v -> save(true)), gapBelow(8));
        sv.addView(text("Por ahora los datos se guardan en archivos MP3 (los más comunes). Los reproductores de música "
                + "y la galería pueden tardar un poco en mostrar los cambios.", 11));
        col.addView(sv, gapBelow(16));

        Uri in = getIntent().getData();
        if (in != null) open(in);
    }

    EditText field(LinearLayout pn, String hint) {
        pn.addView(text(hint, 12));
        EditText e = new EditText(this);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        e.setBackground(frame(dp(10)));
        e.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        pn.addView(e, gapBelow(8));
        return e;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_WRITE) { if (res == RESULT_OK) save(true); return; }
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == REQ_AUDIO) {
            try { getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }
            catch (Exception ignored) {}
            open(data.getData());
        } else if (req == REQ_COVER) {
            try (InputStream is = getContentResolver().openInputStream(data.getData())) {
                Bitmap bm = BitmapFactory.decodeStream(is);
                if (bm == null) throw new Exception();
                int max = 800;
                if (bm.getWidth() > max || bm.getHeight() > max) {
                    float k = (float) max / Math.max(bm.getWidth(), bm.getHeight());
                    bm = Bitmap.createScaledBitmap(bm, Math.round(bm.getWidth() * k), Math.round(bm.getHeight() * k), true);
                }
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 90, bo);
                cover = bo.toByteArray();
                coverView.setImageBitmap(bm);
            } catch (Exception e) { toast("No puedo abrir esa imagen."); }
        }
    }

    /** Lee los datos que ya tiene la canción. */
    void open(Uri u) {
        uri = u;
        fileName = Media.nameOf(this, u);
        mp3 = isMp3(u);
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, u);
            title.setText(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)));
            artist.setText(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)));
            album.setText(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)));
            String y = nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR));
            if (y.isEmpty()) { String d = nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DATE)); if (d.length() >= 4) y = d.substring(0, 4); }
            year.setText(y);
            genre.setText(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)));
            track.setText(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER)).replaceAll("/.*", ""));
            byte[] pic = r.getEmbeddedPicture();
            cover = pic;
            coverView.setImageBitmap(pic == null ? null : BitmapFactory.decodeByteArray(pic, 0, pic.length));
        } catch (Exception e) {
            toast("No puedo leer los datos de este audio.");
        } finally {
            try { r.release(); } catch (Exception ignored) {}
        }
        if (title.getText().length() == 0) title.setText(fileName.replaceAll("\\.[^.]+$", ""));
        info.setText("🎵 " + fileName + (mp3 ? "" : "\n" + L.t("⚠ No es un MP3: puedo leer sus datos, pero para guardarlos conviértelo antes a MP3.")));
    }

    static String nz(String s) { return s == null ? "" : s.trim(); }

    boolean isMp3(Uri u) {
        try (InputStream is = getContentResolver().openInputStream(u)) {
            byte[] h = new byte[3];
            if (is.read(h) < 3) return false;
            if (h[0] == 'I' && h[1] == 'D' && h[2] == '3') return true;
            return (h[0] & 0xFF) == 0xFF && (h[1] & 0xE0) == 0xE0;
        } catch (Exception e) { return false; }
    }

    // ---------------- guardar ----------------
    void save(boolean overwrite) {
        if (uri == null) { toast("Primero elige un audio."); return; }
        if (!mp3) { toast("Por ahora solo puedo guardar datos en MP3."); return; }
        File tmp = new File(getCacheDir(), "tag_" + System.currentTimeMillis() + ".mp3");
        try {
            byte[] tag = buildTag();
            try (InputStream is = getContentResolver().openInputStream(uri); OutputStream os = new FileOutputStream(tmp)) {
                os.write(tag);
                copyAudio(is, os);
            }
            if (overwrite) {
                try (OutputStream os = getContentResolver().openOutputStream(uri, "wt"); InputStream is = new java.io.FileInputStream(tmp)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
                }
                tmp.delete();
                toast("Datos guardados en el archivo original ✓");
            } else {
                String nm = (artist.getText().toString().trim().isEmpty() ? "" : artist.getText().toString().trim() + " - ")
                        + (title.getText().toString().trim().isEmpty() ? "audio" : title.getText().toString().trim());
                nm = nm.replaceAll("[\\\\/:*?\"<>|]", "_") + ".mp3";
                Uri out = Media.save(this, tmp, Media.TYPE_AUDIO, nm, "audio/mpeg");
                toast(out != null ? "Copia guardada en SSS+/Música ✓" : "No se pudo guardar.");
            }
        } catch (SecurityException se) {
            // Android 11+: pedir permiso para cambiar un archivo que no es de SSS+
            if (Build.VERSION.SDK_INT >= 30 && "content".equals(uri.getScheme()) && "media".equals(uri.getAuthority())) {
                try {
                    PendingIntent pi = MediaStore.createWriteRequest(getContentResolver(), java.util.Collections.singletonList(uri));
                    startIntentSenderForResult(pi.getIntentSender(), REQ_WRITE, null, 0, 0, 0);
                    return;
                } catch (Exception ignored) {}
            }
            toast("Android no me deja cambiar ese archivo. Guarda una copia.");
        } catch (Exception e) {
            toast(L.t("No se pudo guardar: ") + e.getMessage());
        } finally {
            if (tmp.exists() && overwrite) tmp.delete();
        }
    }

    /** Copia el sonido quitando las etiquetas viejas (ID3v2 al principio e ID3v1 al final). */
    static void copyAudio(InputStream is, OutputStream os) throws Exception {
        java.io.BufferedInputStream in = new java.io.BufferedInputStream(is, 65536);
        in.mark(10);
        byte[] h = new byte[10];
        int got = in.read(h);
        long skip = 0;
        if (got == 10 && h[0] == 'I' && h[1] == 'D' && h[2] == '3') {
            skip = ((h[6] & 0x7F) << 21) | ((h[7] & 0x7F) << 14) | ((h[8] & 0x7F) << 7) | (h[9] & 0x7F);
            if ((h[5] & 0x10) != 0) skip += 10;          // pie de página
        } else in.reset();
        while (skip > 0) { long s = in.skip(skip); if (s <= 0) break; skip -= s; }
        // copiar todo menos los últimos 128 bytes si son una etiqueta ID3v1 («TAG»)
        byte[] buf = new byte[65536];
        byte[] tail = new byte[0];
        int n;
        while ((n = in.read(buf)) > 0) {
            byte[] all = new byte[tail.length + n];
            System.arraycopy(tail, 0, all, 0, tail.length);
            System.arraycopy(buf, 0, all, tail.length, n);
            int keep = Math.min(128, all.length);
            os.write(all, 0, all.length - keep);
            tail = java.util.Arrays.copyOfRange(all, all.length - keep, all.length);
        }
        boolean v1 = tail.length == 128 && tail[0] == 'T' && tail[1] == 'A' && tail[2] == 'G';
        if (!v1) os.write(tail);
    }

    /** Etiqueta ID3v2.3 con los datos (texto en UTF-16 para que salgan bien las tildes) y la portada. */
    byte[] buildTag() throws Exception {
        ByteArrayOutputStream f = new ByteArrayOutputStream();
        text(f, "TIT2", title);
        text(f, "TPE1", artist);
        text(f, "TALB", album);
        text(f, "TYER", year);
        text(f, "TCON", genre);
        text(f, "TRCK", track);
        String cm = comment.getText().toString().trim();
        if (!cm.isEmpty()) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            b.write(1);
            b.write("spa".getBytes(StandardCharsets.ISO_8859_1));
            b.write(new byte[]{(byte) 0xFF, (byte) 0xFE, 0, 0});              // descripción vacía
            b.write(new byte[]{(byte) 0xFF, (byte) 0xFE});
            b.write(cm.getBytes(StandardCharsets.UTF_16LE));
            frame(f, "COMM", b.toByteArray());
        }
        String by = "SSS+ (BLORP.eoac)";
        { ByteArrayOutputStream b = new ByteArrayOutputStream(); b.write(0); b.write(by.getBytes(StandardCharsets.ISO_8859_1)); frame(f, "TENC", b.toByteArray()); }
        if (cover != null) {
            boolean png = cover.length > 4 && (cover[0] & 0xFF) == 0x89 && cover[1] == 'P';
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            b.write(0);
            b.write((png ? "image/png" : "image/jpeg").getBytes(StandardCharsets.ISO_8859_1));
            b.write(0);
            b.write(3);          // portada delantera
            b.write(0);          // sin descripción
            b.write(cover);
            frame(f, "APIC", b.toByteArray());
        }
        byte[] frames = f.toByteArray();
        int pad = 1024;
        int size = frames.length + pad;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(new byte[]{'I', 'D', '3', 3, 0, 0});
        out.write(new byte[]{(byte) ((size >> 21) & 0x7F), (byte) ((size >> 14) & 0x7F), (byte) ((size >> 7) & 0x7F), (byte) (size & 0x7F)});
        out.write(frames);
        out.write(new byte[pad]);
        return out.toByteArray();
    }

    static void text(ByteArrayOutputStream f, String id, EditText e) throws Exception {
        String v = e.getText().toString().trim();
        if (v.isEmpty()) return;
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        b.write(1);
        b.write(new byte[]{(byte) 0xFF, (byte) 0xFE});
        b.write(v.getBytes(StandardCharsets.UTF_16LE));
        frame(f, id, b.toByteArray());
    }

    static void frame(ByteArrayOutputStream f, String id, byte[] data) throws Exception {
        f.write(id.getBytes(StandardCharsets.ISO_8859_1));
        int n = data.length;
        f.write(new byte[]{(byte) (n >> 24), (byte) (n >> 16), (byte) (n >> 8), (byte) n, 0, 0});
        f.write(data);
    }
}
