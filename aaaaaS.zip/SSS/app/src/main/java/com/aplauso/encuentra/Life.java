package com.aplauso.encuentra;

import java.util.Random;

/**
 * v1.4.2 · Lo que hace que Chloe parezca viva y no un bucle: ruido suave (nunca se repite igual),
 * muelles (las orejas y la cabeza tienen inercia y rebotan un poco), parpadeos a destiempo (a veces dobles)
 * y pequeños gestos al azar cuando no hace nada (mirar a un lado, ladear la cabeza, sacudir una oreja, suspirar…).
 * No depende de Android: se puede probar en el ordenador.
 */
public class Life {
    final Random rnd = new Random();

    // ---- salida (lo que se dibuja) ----
    public float earL, earR;     // grados (+ = hacia el centro de la cabeza, − = hacia fuera)
    public float tilt;           // grados, cabeza
    public float turn;           // −1 … 1 gira la cara (izquierda/derecha)
    public float lookX, lookY;   // −1 … 1 hacia dónde miran los ojos
    public float nod;            // px, cabeza arriba/abajo
    public float bob;            // px, todo el cuerpo (saltitos)
    public float breath;         // −1 … 1
    public float mouth;          // 0 … 1
    public float blink;          // 0 abiertos … 1 cerrados
    public float hand;           // 0 … 1 mano en la barbilla
    public float smile;          // 0 … 1 sonrisa suave en reposo
    public float hairSway;       // −1 … 1 brisa en los mechones
    public float hairHand;       // 0 … 1 mano jugando con el pelo
    public float twirl;          // fase del giro del mechón

    // ---- muelles ----
    static final class Spring {
        float x, v;
        void step(float target, float k, float d, float dt) { v += (k * (target - x) - d * v) * dt; x += v * dt; }
    }
    final Spring sEarL = new Spring(), sEarR = new Spring(), sTilt = new Spring(), sTurn = new Spring(),
            sLX = new Spring(), sLY = new Spring(), sNod = new Spring(), sHand = new Spring(), sBob = new Spring(), sHair = new Spring();
    float hairUntil;

    // ---- ruido suave 1D (cada canal con su semilla) ----
    final float[][] lattice = new float[8][256];
    { for (float[] l : lattice) for (int i = 0; i < l.length; i++) l[i] = rnd.nextFloat() * 2 - 1; }

    float noise(int ch, float t) {
        int i = (int) Math.floor(t);
        float f = t - i, u = f * f * (3 - 2 * f);
        float a = lattice[ch][i & 255], b = lattice[ch][(i + 1) & 255];
        return a + (b - a) * u;
    }

    // ---- gestos al azar ----
    float nextIdle = 2.5f, idleEnd, idleTurn, idleTilt, idleLY;
    float nextBlink = 1.5f, blinkStart = -10;
    boolean doubleBlink;
    float flickL, flickR;        // impulsos de oreja
    long lastWordSeen;
    float t;

    /**
     * @param state  estado de AvatarArt
     * @param dt     segundos desde el último fotograma
     * @param nowMs  el mismo reloj que lastWord
     * @param touchX/touchY  −1…1 si te ha tocado hace poco (NaN si no)
     */
    public void step(int state, float dt, long lastWord, long nowMs, float touchX, float touchY) {
        dt = Math.min(dt, 0.05f);
        t += dt;
        boolean happy = state == AvatarArt.HAPPY || state == AvatarArt.LOVE;

        // --- objetivos según el estado ---
        float tEarL = 0, tEarR = 0, tTilt = 0, tTurn = 0, tLX = 0, tLY = 0, tNod = 0, tHand = 0, tBob = 0;
        switch (state) {
            case AvatarArt.LISTEN: tEarL = 6; tEarR = 6; tTilt = -4; tLX = 0; tLY = -0.1f; break;          // orejas atentas, hacia arriba
            case AvatarArt.THINK: tHand = 1; tLX = 0.55f; tLY = -0.95f; tTilt = 5; tNod = -3; tTurn = 0.25f;
                tEarL = -4 + noise(0, t * 0.7f) * 4; tEarR = 2 + noise(1, t * 0.7f) * 4; break;            // mano en la barbilla, mira arriba
            case AvatarArt.SAD: tEarL = -14; tEarR = -15; tTilt = -3; tLY = 0.6f; tNod = 4; break;          // orejas caídas
            case AvatarArt.SLEEP: tEarL = -17; tEarR = -13; tTilt = 9; tNod = 6; tLY = 0.4f; break;
            case AvatarArt.CONFUSED: tTilt = 9; tEarL = -14; tEarR = 4; tLX = -0.3f; tLY = -0.3f; break;   // cabeza ladeada, una oreja doblada
            case AvatarArt.TALK: tLX = 0; tLY = 0; break;
            default:
        }
        if (happy) { tBob = -3; tTilt = noise(2, t * 1.5f) * 4; }

        // --- reposo: pequeños gestos al azar (nunca iguales) ---
        if (state == AvatarArt.IDLE || state == AvatarArt.TALK) {
            if (t > nextIdle) {
                int g = rnd.nextInt(10);
                if (g == 9 && state == AvatarArt.IDLE && hairUntil < t - 12) { hairUntil = t + 3.5f + rnd.nextFloat() * 2.5f; g = -1; }   // juega con el pelo
                else if (g >= 6) g = rnd.nextBoolean() ? 0 : 1;                                                                       // más giros de cabeza
                idleEnd = t + 1.2f + rnd.nextFloat() * 2.2f;
                idleTurn = 0; idleTilt = 0; idleLY = 0;
                switch (g) {
                    case 0: idleTurn = (rnd.nextBoolean() ? 1 : -1) * (0.4f + rnd.nextFloat() * 0.4f); break;    // mira a un lado
                    case 1: idleTilt = (rnd.nextBoolean() ? 1 : -1) * (3 + rnd.nextFloat() * 4); break;          // ladea la cabeza
                    case 2: if (rnd.nextBoolean()) flickL = 1; else flickR = 1; break;                           // sacude una oreja
                    case 3: idleLY = -0.5f; idleTurn = (rnd.nextFloat() - 0.5f) * 0.6f; break;                  // mira arriba, pensativa
                    case 4: flickL = 0.7f; flickR = 0.7f; break;                                                // las dos orejas
                    default: smileT = t + 2.5f;                                                                   // sonríe un momento
                }
                nextIdle = t + 1.8f + rnd.nextFloat() * 3.5f;
            }
            if (t < idleEnd) { tTurn += idleTurn; tTilt += idleTilt; tLY += idleLY; tLX += idleTurn * 0.6f; }
        }
        // si te ha tocado, te mira
        if (!Float.isNaN(touchX)) { tLX = touchX; tLY = touchY; tTurn = touchX * 0.5f; }
        // jugando con el pelo: mira un poco hacia abajo y a un lado, cabeza hacia el mechón
        boolean hairPlay = t < hairUntil && state == AvatarArt.IDLE;
        if (hairPlay) { tTilt -= 4; tLX = -0.45f; tLY = 0.25f; tTurn = -0.2f; }

        // --- vida de fondo: ruido suave que nunca se repite ---
        float n1 = noise(3, t * 0.35f), n2 = noise(4, t * 0.5f), n3 = noise(5, t * 0.8f);
        tTilt += n1 * 2.2f;
        tTurn += n2 * 0.28f;
        tLX += n3 * 0.12f;
        tEarL += noise(6, t * 0.6f) * 3;
        tEarR += noise(7, t * 0.6f + 50) * 3;

        // al hablar: pequeños asentimientos con cada palabra
        if (state == AvatarArt.TALK && lastWord != lastWordSeen) {
            lastWordSeen = lastWord;
            if (rnd.nextFloat() < 0.45f) sNod.v += 18 + rnd.nextFloat() * 14;
            if (rnd.nextFloat() < 0.2f) { sEarL.v += 25; sEarR.v -= 25; }
        }
        // contenta: las orejitas aletean (impulsos a destiempo, no un vaivén fijo)
        if (happy && rnd.nextFloat() < dt * 5) { float k = 60 + rnd.nextFloat() * 70; if (rnd.nextBoolean()) sEarL.v += k; else sEarR.v += k; sBob.v -= 50; }
        if (flickL > 0) { sEarL.v -= 140 * flickL; flickL = 0; }
        if (flickR > 0) { sEarR.v -= 140 * flickR; flickR = 0; }

        // --- muelles ---
        float sleepy = state == AvatarArt.SLEEP ? 0.4f : 1f;
        sEarL.step(tEarL, 90, 7, dt);           // orejas: blanditas, rebotan
        sEarR.step(tEarR, 90, 7, dt);
        sTilt.step(tTilt, 30 * sleepy, 9, dt);
        sTurn.step(tTurn, 30, 10, dt);
        sLX.step(tLX, 120, 18, dt);             // ojos: rápidos
        sLY.step(tLY, 120, 18, dt);
        sNod.step(tNod, 60, 9, dt);
        sHand.step(tHand, 22, 9, dt);
        sBob.step(tBob, 70, 8, dt);
        sHair.step(hairPlay ? 1 : 0, 14, 7, dt);
        // la cabeza al moverse empuja las orejas (inercia)
        sEarL.v -= sTilt.v * 0.6f; sEarR.v += sTilt.v * 0.6f;

        earL = sEarL.x; earR = sEarR.x; tilt = sTilt.x; turn = sTurn.x; lookX = sLX.x; lookY = sLY.x;
        nod = sNod.x; bob = sBob.x; hand = Math.max(0, Math.min(1, sHand.x));
        hairHand = Math.max(0, Math.min(1, sHair.x));
        twirl += dt * 5.5f;
        hairSway = noise(2, t * 0.45f + 30) * 0.8f + noise(5, t * 1.3f + 70) * 0.25f;

        // --- respiración (ritmo que varía un poco) ---
        breathPhase += dt * (state == AvatarArt.SLEEP ? 1.3f : 2.0f + noise(0, t * 0.2f) * 0.3f);
        breath = (float) Math.sin(breathPhase);

        // --- parpadeo a destiempo, a veces doble ---
        if (t > nextBlink) {
            blinkStart = t;
            doubleBlink = rnd.nextFloat() < 0.18f;
            nextBlink = t + (state == AvatarArt.LISTEN ? 4 : 2) + rnd.nextFloat() * 4.5f;
        }
        float bt = t - blinkStart;
        blink = bt < 0.16f ? (float) Math.sin(bt / 0.16f * Math.PI) : (doubleBlink && bt > 0.24f && bt < 0.40f ? (float) Math.sin((bt - 0.24f) / 0.16f * Math.PI) : 0);

        // --- boca ---
        float tm = 0;
        if (state == AvatarArt.TALK) {
            float since = (nowMs - lastWord) / 1000f;
            float syl = 0.5f + 0.5f * noise(1, t * 11f);                      // sílabas irregulares
            tm = Math.max(0.15f, Math.min(1, syl * 0.85f + (since < 0.1f ? 0.35f : 0)));
        }
        mouth += (tm - mouth) * Math.min(1, dt * 22);
        float ts = t < smileT || happy ? 1 : 0;
        smile += (ts - smile) * Math.min(1, dt * 4);
    }

    float breathPhase, smileT;
}
