package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 🐠 ACUARIO DEL ECO (v1.1): cuida tus peces, dales de comer tocando el agua y recoge las monedas que sueltan.
 * Compra más peces, mejor comida y piezas del huevo dorado para pasar de nivel; cada 5 niveles sale una mascota.
 * Cuidado con los visitantes del abismo: tócalos para echarlos antes de que se coman tus peces.
 * 20 niveles en 4 peceras. Diseño original de SSS+ (por BLORP.eoac).
 */
public class AquaView extends GameKit.GameView implements ArcadeActivity.Backable {
    static final int S_TITLE = 0, S_PLAY = 1, S_PAUSE = 2, S_WIN = 3, S_OVER = 4, S_PET = 5, S_INTRO = 6;
    int st = S_TITLE;
    float t, stT;
    final Random rnd = new Random();
    static final int LEVELS = 20;
    static final String[] TANKS = {"Laguna Clara", "Arrecife de Coral", "Gruta Azul", "Fosa del Eco"};
    static final int[][] TANK_COL = {{0xFF4FC3E8, 0xFF1A6E9E}, {0xFF3FB6C9, 0xFF14608A}, {0xFF2A7FBF, 0xFF0E3260}, {0xFF1B3F7A, 0xFF060E26}};

    // ---------------- progreso ----------------
    int level = 1, unlocked = 1;
    final boolean[] petOwned = new boolean[4];
    int petA = -1;                 // mascota elegida para este nivel
    static final String[] PET_N = {"🐌 Caracol Coco", "🦪 Ostra Perla", "🐙 Pulpo Tinta", "🐢 Tortuga Tuga"};
    static final String[] PET_D = {"Recoge las monedas del fondo", "Cada rato abre su concha con una perla", "Si hay peces con hambre, les echa comida", "Muerde a los visitantes del abismo"};

    // ---------------- nivel ----------------
    int money, eggParts;
    int foodLv, foodMax, weaponLv;        // calidad de comida, comida a la vez, arma
    float alienT;
    float floor;                          // fondo de la pecera
    float top = 70;

    static final class Fish { int kind, stage; float x, y, vx, vy, hunger, eaten, coinT, size, wob; boolean flip, dead; float deadT; }
    // kind: 0 pez dorado (crece y suelta monedas), 1 carnívoro (come peces pequeños y suelta joyas), 2 pez perla (suelta perlas)
    final List<Fish> fish = new ArrayList<>();
    static final class Food { float x, y, vy; int q; }
    final List<Food> food = new ArrayList<>();
    static final class Coin { float x, y, vy, life; int v, kind; }    // 0 plata, 1 oro, 2 estrella, 3 joya, 4 perla, 5 cofre
    final List<Coin> coins = new ArrayList<>();
    static final class Alien { int kind; float x, y, vx, vy, hp, max, hit, wob; }
    final List<Alien> aliens = new ArrayList<>();
    static final class Fx { float x, y, r, life, max; int c; String s; }
    final List<Fx> fx = new ArrayList<>();
    final List<float[]> bubbles = new ArrayList<>();
    float petX, petY, petT, petVx = 20;

    final Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
    final RectF[] shop = new RectF[6];

    AquaView(Context c) {
        super(c);
        unlocked = Math.max(1, prefs().getInt("aq_unlock", 1));
        for (int i = 0; i < 4; i++) petOwned[i] = prefs().getBoolean("aq_pet" + i, false);
        chip.play(Songs.LAGO);
        for (int i = 0; i < 18; i++) bubbles.add(new float[]{rnd.nextFloat() * 360, rnd.nextFloat() * 700, 1 + rnd.nextFloat() * 3});
    }

    @Override void computeScale(int w, int h) { vw = 360; scale = w / vw; vh = h / scale; }
    @Override void layout() {
        floor = vh - 40;
        float bw = (vw - 14) / 6f;
        for (int i = 0; i < 6; i++) shop[i] = new RectF(4 + i * bw + 1, 4, 4 + (i + 1) * bw - 1, 62);
    }
    @Override boolean navActive() { return st != S_PLAY; }
    @Override public boolean onBack() {
        if (st == S_PLAY) { st = S_PAUSE; return true; }
        if (st == S_PAUSE) { st = S_PLAY; return true; }
        return false;
    }

    int tank() { return Math.min(3, (level - 1) / 5); }
    int eggCost() { return 600 + level * 150; }
    int fishCost() { return 100; }
    int foodQCost() { return foodLv == 0 ? 200 : foodLv == 1 ? 400 : 0; }
    int foodNCost() { return foodMax >= 9 ? 0 : 300; }
    int weaponCost() { return weaponLv >= 9 ? 0 : 1000 + weaponLv * 300; }
    int carnCost() { return 1000; }
    boolean aliensOn() { return (level - 1) % 5 >= 1 || level > 5; }

    // ---------------- empezar ----------------
    void startLevel(int lv) {
        level = lv;
        fish.clear(); food.clear(); coins.clear(); aliens.clear(); fx.clear();
        money = 200 + (lv - 1) * 30;
        eggParts = 0;
        foodLv = 0; foodMax = 1; weaponLv = 0;
        addFish(0); addFish(0);
        alienT = 70 + rnd.nextFloat() * 30;
        petX = vw / 2; petY = floor - 10; petT = 0;
        st = S_INTRO; stT = 0;
        chip.play(tank() == 3 ? Songs.ABISMO : tank() == 2 ? Songs.CRISTAL : Songs.LAGO);
    }

    Fish addFish(int kind) {
        Fish f = new Fish();
        f.kind = kind;
        f.x = 40 + rnd.nextFloat() * (vw - 80);
        f.y = top + 30;
        f.vx = (rnd.nextBoolean() ? 1 : -1) * (20 + rnd.nextFloat() * 20);
        f.hunger = 0;
        f.coinT = 4 + rnd.nextFloat() * 4;
        f.wob = rnd.nextFloat() * 6;
        fish.add(f);
        fx.add(ring(f.x, f.y, Color.WHITE, 18, 0.4f));
        return f;
    }

    float fishSize(Fish f) { return f.kind == 1 ? 22 : f.kind == 2 ? 15 : (f.stage == 0 ? 10 : f.stage == 1 ? 14 : f.stage == 2 ? 18 : 21); }

    // ---------------- actualizar ----------------
    @Override void update(float dt) {
        t += dt; stT += dt;
        for (float[] b : bubbles) { b[1] -= (20 + b[2] * 10) * dt; if (b[1] < top) { b[1] = vh; b[0] = rnd.nextFloat() * vw; } }
        for (int i = fx.size() - 1; i >= 0; i--) { Fx f = fx.get(i); f.life -= dt; if (f.s != null) f.y -= 26 * dt; if (f.life <= 0) fx.remove(i); }
        if (st == S_INTRO && stT > 1.4f) { st = S_PLAY; stT = 0; }
        if (st != S_PLAY) return;
        if (gp.enabled && gp.pressed(GameKit.G_START)) { onBack(); return; }

        // ---- comida que cae ----
        for (int i = food.size() - 1; i >= 0; i--) {
            Food f = food.get(i);
            f.y += 38 * dt;
            if (f.y > floor) { food.remove(i); }
        }
        // ---- peces ----
        int alive = 0;
        for (int i = fish.size() - 1; i >= 0; i--) {
            Fish f = fish.get(i);
            f.wob += dt * 5;
            if (f.dead) { f.deadT += dt; f.y -= 12 * dt; if (f.deadT > 3) fish.remove(i); continue; }
            alive++;
            f.hunger += dt / (f.kind == 1 ? 26f : 20f);
            if (f.hunger >= 1.6f) { f.dead = true; chip.sfx(Chip.SFX_HURT); fx.add(text(f.x, f.y - 16, L.t("💀 de hambre"), 0xFFFF8080)); continue; }
            boolean hungry = f.hunger > 0.6f;
            float sp = hungry ? 70 : 30;
            // ¿a dónde va?
            float tx = Float.NaN, ty = 0;
            if (hungry) {
                if (f.kind == 1) {                       // carnívoro: busca un pez pequeño
                    Fish best = null; float bd = 1e9f;
                    for (Fish o : fish) if (!o.dead && o.kind == 0 && o.stage == 0) { float d = (float) Math.hypot(o.x - f.x, o.y - f.y); if (d < bd) { bd = d; best = o; } }
                    if (best != null) { tx = best.x; ty = best.y; if (bd < 16) { best.dead = true; best.deadT = 3; f.hunger = 0; coin(f.x, f.y, 3); chip.sfx(Chip.SFX_POWER); } }
                } else {
                    Food best = null; float bd = 1e9f;
                    for (Food o : food) { float d = (float) Math.hypot(o.x - f.x, o.y - f.y); if (d < bd) { bd = d; best = o; } }
                    if (best != null) {
                        tx = best.x; ty = best.y;
                        if (bd < fishSize(f) * 0.8f + 4) {
                            food.remove(best);
                            f.hunger = Math.max(0, f.hunger - (0.6f + best.q * 0.25f));
                            f.eaten += 1 + best.q * 0.5f;
                            chip.sfx(Chip.SFX_JUMP);
                            if (f.kind == 0 && f.stage < 3 && f.eaten >= (f.stage + 1) * 3) { f.stage++; f.eaten = 0; fx.add(text(f.x, f.y - 18, L.t("¡Ha crecido!"), Color.WHITE)); }
                        }
                    }
                }
            }
            if (!Float.isNaN(tx)) {
                float dx = tx - f.x, dy = ty - f.y, d = (float) Math.hypot(dx, dy);
                f.vx += (dx / Math.max(1, d) * sp - f.vx) * dt * 3;
                f.vy += (dy / Math.max(1, d) * sp - f.vy) * dt * 3;
            } else {
                if (rnd.nextFloat() < dt * 0.4f) { f.vx = (rnd.nextBoolean() ? 1 : -1) * (15 + rnd.nextFloat() * 25); f.vy = (rnd.nextFloat() - 0.5f) * 20; }
                f.vy += (float) Math.sin(f.wob) * 2 * dt;
            }
            f.x += f.vx * dt; f.y += f.vy * dt;
            float s = fishSize(f);
            if (f.x < s) { f.x = s; f.vx = Math.abs(f.vx); }
            if (f.x > vw - s) { f.x = vw - s; f.vx = -Math.abs(f.vx); }
            if (f.y < top + s) { f.y = top + s; f.vy = Math.abs(f.vy); }
            if (f.y > floor - s) { f.y = floor - s; f.vy = -Math.abs(f.vy); }
            if (Math.abs(f.vx) > 2) f.flip = f.vx < 0;
            // monedas
            f.coinT -= dt;
            if (f.coinT <= 0) {
                f.coinT = 6 + rnd.nextFloat() * 5;
                if (f.kind == 0 && f.stage == 1) coin(f.x, f.y, 0);
                else if (f.kind == 0 && f.stage == 2) coin(f.x, f.y, 1);
                else if (f.kind == 0 && f.stage == 3) coin(f.x, f.y, rnd.nextFloat() < 0.2f ? 3 : 2);
                else if (f.kind == 2) coin(f.x, f.y, 4);
            }
        }
        // ---- monedas que caen ----
        for (int i = coins.size() - 1; i >= 0; i--) {
            Coin c = coins.get(i);
            if (c.y < floor - 6) c.y += c.vy * dt; else { c.life -= dt; if (c.life <= 0) { coins.remove(i); continue; } }
        }
        // ---- mascota ----
        pet(dt);
        // ---- visitantes del abismo ----
        if (aliensOn()) {
            alienT -= dt;
            if (alienT < 4 && alienT + dt >= 4) { fx.add(text(vw / 2, vh / 2, L.t("⚠ ¡Viene algo del abismo!"), 0xFFFF4D5E)); chip.sfx(Chip.SFX_DUCK); }
            if (alienT <= 0 && aliens.isEmpty()) {
                spawnAlien();
                alienT = Math.max(45, 90 - level * 2) + rnd.nextFloat() * 30;
            }
        }
        for (int i = aliens.size() - 1; i >= 0; i--) {
            Alien a = aliens.get(i);
            a.wob += dt * 4;
            if (a.hit > 0) a.hit -= dt;
            Fish tgt = null; float bd = 1e9f;
            for (Fish f : fish) if (!f.dead) { float d = (float) Math.hypot(f.x - a.x, f.y - a.y); if (d < bd) { bd = d; tgt = f; } }
            float sp = a.kind == 1 ? 60 : 32;
            if (tgt != null) {
                a.vx += ((tgt.x - a.x) / Math.max(1, bd) * sp - a.vx) * dt * 2;
                a.vy += ((tgt.y - a.y) / Math.max(1, bd) * sp - a.vy) * dt * 2;
                if (bd < 22 + (a.kind == 0 ? 8 : 0)) { tgt.dead = true; tgt.deadT = 3; chip.sfx(Chip.SFX_HURT); fx.add(text(a.x, a.y - 30, L.t("¡ÑAM!"), 0xFFFF4D5E)); }
            }
            a.x = GameKit.clamp(a.x + a.vx * dt, 20, vw - 20);
            a.y = GameKit.clamp(a.y + a.vy * dt, top + 20, floor - 20);
        }
        // ---- fin ----
        if (alive == 0 && money < fishCost() && coins.isEmpty()) { st = S_OVER; stT = 0; chip.sfx(Chip.SFX_BOOM); }
    }

    void pet(float dt) {
        if (petA < 0) return;
        petT += dt;
        switch (petA) {
            case 0: {   // caracol: va a por la moneda más cercana del fondo
                Coin best = null; float bd = 1e9f;
                for (Coin c : coins) if (c.y >= floor - 8) { float d = Math.abs(c.x - petX); if (d < bd) { bd = d; best = c; } }
                if (best != null) { petX += Math.signum(best.x - petX) * 45 * dt; if (bd < 8) { collect(best); } }
                break;
            }
            case 1:     // ostra: perla cada 25 s
                if (petT > 25) { petT = 0; coin(petX, petY - 10, 4); }
                break;
            case 2: {   // pulpo: si hay peces con hambre y no hay comida, echa comida
                boolean hungry = false;
                for (Fish f : fish) if (!f.dead && f.kind != 1 && f.hunger > 0.9f) hungry = true;
                petX += petVx * dt; if (petX < 30 || petX > vw - 30) petVx = -petVx;
                if (hungry && food.isEmpty() && petT > 6) { petT = 0; for (int i = 0; i < 2; i++) dropFood(petX + i * 14 - 7, top + 20, true); }
                break;
            }
            case 3: {   // tortuga: muerde visitantes
                petX += petVx * dt; if (petX < 30 || petX > vw - 30) petVx = -petVx;
                if (!aliens.isEmpty() && petT > 1.5f) { petT = 0; Alien a = aliens.get(0); hitAlien(a, 6); fx.add(ring(a.x, a.y, 0xFF44E07A, 20, 0.3f)); }
                break;
            }
        }
    }

    void spawnAlien() {
        Alien a = new Alien();
        a.kind = level >= 12 && rnd.nextBoolean() ? 1 : 0;
        a.x = rnd.nextBoolean() ? 30 : vw - 30; a.y = top + 40;
        a.max = a.hp = (a.kind == 1 ? 40 : 70) * (1 + level * 0.12f);
        aliens.add(a);
        chip.sfx(Chip.SFX_BOOM);
        if (level >= 15 && rnd.nextFloat() < 0.4f) { Alien b = new Alien(); b.kind = 1; b.x = vw - a.x; b.y = top + 40; b.max = b.hp = 40 * (1 + level * 0.12f); aliens.add(b); }
    }

    void hitAlien(Alien a, float dmg) {
        a.hp -= dmg;
        a.hit = 0.1f;
        if (a.hp <= 0) {
            aliens.remove(a);
            coin(a.x, a.y, 5);
            fx.add(text(a.x, a.y - 20, L.t("¡Fuera de aquí!"), 0xFF44E07A));
            chip.sfx(Chip.SFX_LEVEL);
            for (int k = 0; k < 10; k++) fx.add(ring(a.x + rnd.nextFloat() * 30 - 15, a.y + rnd.nextFloat() * 30 - 15, 0xFFB46BFF, 6, 0.5f));
        }
    }

    void coin(float x, float y, int kind) {
        Coin c = new Coin();
        c.x = x; c.y = y; c.kind = kind; c.vy = kind == 5 ? 30 : 40; c.life = 5;
        c.v = kind == 0 ? 15 : kind == 1 ? 35 : kind == 2 ? 40 : kind == 3 ? 200 : kind == 4 ? 250 : 500;
        coins.add(c);
    }

    void collect(Coin c) {
        coins.remove(c);
        money += c.v;
        fx.add(text(c.x, c.y - 10, "+" + c.v, 0xFFFFD34A));
        chip.sfx(Chip.SFX_COIN);
    }

    void dropFood(float x, float y, boolean free) {
        if (!free) {
            if (food.size() >= foodMax) return;
            if (money < 5) { fx.add(text(x, y, L.t("¡Sin dinero!"), 0xFFFF8080)); return; }
            money -= 5;
        }
        Food f = new Food(); f.x = x; f.y = Math.max(top + 4, y); f.q = foodLv;
        food.add(f);
    }

    void buy(int i) {
        switch (i) {
            case 0: if (money >= fishCost()) { money -= fishCost(); addFish(0); chip.sfx(Chip.SFX_COIN); } break;
            case 1: if (foodQCost() > 0 && money >= foodQCost()) { money -= foodQCost(); foodLv++; chip.sfx(Chip.SFX_POWER); } break;
            case 2: if (foodNCost() > 0 && money >= foodNCost()) { money -= foodNCost(); foodMax++; chip.sfx(Chip.SFX_POWER); } break;
            case 3: if (level >= 3 && money >= carnCost()) { money -= carnCost(); addFish(1); chip.sfx(Chip.SFX_COIN); }
                    else if (level >= 2 && level < 3 && money >= 400) { money -= 400; addFish(2); chip.sfx(Chip.SFX_COIN); } break;
            case 4: if (weaponCost() > 0 && money >= weaponCost()) { money -= weaponCost(); weaponLv++; chip.sfx(Chip.SFX_POWER); } break;
            case 5: if (money >= eggCost()) {
                money -= eggCost(); eggParts++; chip.sfx(Chip.SFX_LEVEL);
                fx.add(text(vw / 2, vh / 2, L.t("🥚 Pieza del huevo") + " " + eggParts + "/3", 0xFFFFD34A));
                if (eggParts >= 3) win();
            } break;
        }
    }

    void win() {
        int next = level + 1;
        if (next > unlocked) { unlocked = Math.min(LEVELS + 1, next); prefs().edit().putInt("aq_unlock", unlocked).apply(); }
        if (level > prefs().getInt("best_aqua", 0)) prefs().edit().putInt("best_aqua", level).apply();
        if (level % 5 == 0) { int p = level / 5 - 1; if (p < 4 && !petOwned[p]) { petOwned[p] = true; prefs().edit().putBoolean("aq_pet" + p, true).apply(); } }
        st = S_WIN; stT = 0;
        chip.sfx(Chip.SFX_LEVEL);
    }

    Fx ring(float x, float y, int c, float r, float life) { Fx f = new Fx(); f.x = x; f.y = y; f.c = c; f.r = r; f.life = f.max = life; return f; }
    Fx text(float x, float y, String s, int c) { Fx f = new Fx(); f.x = x; f.y = y; f.c = c; f.s = s; f.life = f.max = 1.1f; return f; }

    // ---------------- toques ----------------
    @Override
    public boolean onTouchEvent(android.view.MotionEvent e) {
        super.onTouchEvent(e);
        if (st != S_PLAY) return true;
        int a = e.getActionMasked();
        if (a != android.view.MotionEvent.ACTION_DOWN && a != android.view.MotionEvent.ACTION_POINTER_DOWN) return true;
        int i = e.getActionIndex();
        float x = e.getX(i) / scale, y = e.getY(i) / scale;
        if (y < 66) {
            for (int k = 0; k < 6; k++) if (shop[k].contains(x, y)) { buy(k); return true; }
            return true;
        }
        if (x > vw - 46 && y > vh - 36) { st = S_PAUSE; return true; }
        // 1) visitante: disparar
        for (Alien al : new ArrayList<>(aliens)) {
            if (Math.hypot(al.x - x, al.y - y) < 34) {
                hitAlien(al, 4 + weaponLv * 3);
                al.vx += (al.x - x) * 2; al.vy += (al.y - y) * 2;
                fx.add(ring(x, y, 0xFFFFE680, 12, 0.2f));
                chip.sfx(Chip.SFX_SHOOT);
                return true;
            }
        }
        // 2) moneda
        Coin best = null; float bd = 26;
        for (Coin c : coins) { float d = (float) Math.hypot(c.x - x, c.y - y); if (d < bd) { bd = d; best = c; } }
        if (best != null) { collect(best); return true; }
        // 3) si hay visitantes, tocar el agua no da comida (se dispara)
        if (!aliens.isEmpty()) { fx.add(ring(x, y, 0xFFFFE680, 8, 0.15f)); return true; }
        // 4) comida
        dropFood(x, y, false);
        return true;
    }

    // ---------------- dibujo ----------------
    @Override void render(Canvas c) {
        drawWater(c);
        if (st == S_TITLE) { drawTitle(c); return; }
        if (st == S_PET) { drawPetPick(c); return; }
        // comida
        for (Food f : food) { pp.setColor(f.q == 0 ? 0xFFC98A4B : f.q == 1 ? 0xFF7FD36B : 0xFFFF7BA6); c.drawCircle(f.x, f.y, 3 + f.q * 0.6f, pp); }
        // mascota
        drawPet(c);
        // peces
        for (Fish f : fish) drawFish(c, f);
        // monedas
        for (Coin co : coins) drawCoin(c, co);
        // visitantes
        for (Alien a : aliens) drawAlien(c, a);
        for (Fx f : fx) {
            float k = f.life / f.max;
            if (f.s != null) { txt.setAlpha((int) (255 * Math.min(1, k * 2))); text(c, f.s, f.x, f.y, 13, f.c); txt.setAlpha(255); }
            else { pp.setStyle(Paint.Style.STROKE); pp.setStrokeWidth(2); pp.setColor(f.c); pp.setAlpha((int) (220 * k)); c.drawCircle(f.x, f.y, f.r * (1.4f - k * 0.6f), pp); pp.setStyle(Paint.Style.FILL); pp.setAlpha(255); }
        }
        drawShop(c);
        if (st == S_INTRO) {
            box(c, new RectF(40, vh / 2 - 60, vw - 40, vh / 2 + 50), 0xFF4FC3E8, 220);
            text(c, L.t(TANKS[tank()]), vw / 2, vh / 2 - 26, 15, 0xFF8FE6FF);
            text(c, L.t("NIVEL") + " " + level, vw / 2, vh / 2 + 8, 28, Color.WHITE);
            text(c, L.t("Junta 3 piezas del huevo"), vw / 2, vh / 2 + 34, 12, 0xFFFFD34A);
        }
        if (st == S_PAUSE) drawPause(c);
        if (st == S_WIN) drawWin(c);
        if (st == S_OVER) drawOver(c);
    }

    void drawWater(Canvas c) {
        int[] col = TANK_COL[tank()];
        pp.setShader(new LinearGradient(0, 0, 0, vh, col[0], col[1], Shader.TileMode.CLAMP));
        c.drawRect(0, 0, vw, vh, pp);
        pp.setShader(null);
        // rayos de luz
        for (int i = 0; i < 4; i++) {
            Path r = new Path();
            float x = (i * 110 + t * 6) % (vw + 100) - 50;
            r.moveTo(x, 0); r.lineTo(x + 40, 0); r.lineTo(x + 110, vh); r.lineTo(x + 50, vh); r.close();
            pp.setColor(Color.argb(18, 255, 255, 255));
            c.drawPath(r, pp);
        }
        // arena y plantas
        pp.setColor(0xFFE2C98E); c.drawRect(0, floor, vw, vh, pp);
        pp.setColor(0xFFCDB178); for (int x = 0; x < vw; x += 18) c.drawCircle(x + 6, floor + 10 + (x % 3) * 5, 3, pp);
        for (int i = 0; i < 7; i++) {
            float x = 18 + i * 54;
            pp.setColor(i % 2 == 0 ? 0xFF3FA65A : 0xFF2E8A4A);
            pp.setStyle(Paint.Style.STROKE); pp.setStrokeWidth(5); pp.setStrokeCap(Paint.Cap.ROUND);
            Path pl = new Path(); pl.moveTo(x, floor);
            for (int k = 1; k <= 5; k++) pl.lineTo(x + (float) Math.sin(t * 1.5f + i + k) * 6, floor - k * 14);
            c.drawPath(pl, pp);
            pp.setStyle(Paint.Style.FILL);
        }
        // un cofre y una roca
        pp.setColor(0xFF8A5A2B); c.drawRect(vw - 70, floor - 18, vw - 36, floor, pp);
        pp.setColor(0xFFFFD34A); c.drawRect(vw - 56, floor - 12, vw - 50, floor - 6, pp);
        pp.setColor(0xFF7A8290); c.drawOval(20, floor - 20, 70, floor + 4, pp);
        for (float[] b : bubbles) { pp.setColor(Color.argb(90, 255, 255, 255)); c.drawCircle(b[0], b[1], b[2], pp); }
    }

    void drawFish(Canvas c, Fish f) {
        float s = fishSize(f), x = f.x, y = f.y + (float) Math.sin(f.wob) * 1.5f;
        int body, fin;
        if (f.kind == 1) { body = 0xFF5E6E8A; fin = 0xFF3E4A60; }
        else if (f.kind == 2) { body = 0xFFF2E6FF; fin = 0xFFC9A8FF; }
        else { body = 0xFFFFB13D; fin = 0xFFFF7A3D; }
        boolean hungry = f.hunger > 0.6f;
        if (f.dead) { body = 0xFF8A8A8A; fin = 0xFF666666; }
        else if (hungry) body = blend(body, 0xFF6BAA5A, Math.min(1, (f.hunger - 0.6f)));
        c.save();
        if (f.flip) c.scale(-1, 1, x, y);
        if (f.dead) c.rotate(180, x, y);
        // cola
        Path tail = new Path();
        float w = (float) Math.sin(f.wob * 2) * s * 0.2f;
        tail.moveTo(x - s * 0.7f, y); tail.lineTo(x - s * 1.35f, y - s * 0.55f + w); tail.lineTo(x - s * 1.25f, y + s * 0.55f + w); tail.close();
        pp.setColor(fin); c.drawPath(tail, pp);
        // aleta de arriba
        Path top = new Path(); top.moveTo(x - s * 0.3f, y - s * 0.5f); top.lineTo(x + s * 0.1f, y - s * 0.95f); top.lineTo(x + s * 0.35f, y - s * 0.45f); top.close();
        c.drawPath(top, pp);
        // cuerpo
        pp.setShader(new RadialGradient(x + s * 0.2f, y - s * 0.25f, s * 1.2f, blend(body, Color.WHITE, 0.35f), body, Shader.TileMode.CLAMP));
        c.drawOval(x - s, y - s * 0.62f, x + s * 0.85f, y + s * 0.62f, pp);
        pp.setShader(null);
        if (f.kind == 1) { pp.setColor(Color.WHITE); for (int k = 0; k < 3; k++) { Path th = new Path(); float tx = x + s * 0.45f + k * 4; th.moveTo(tx, y + s * 0.15f); th.lineTo(tx + 2, y + s * 0.38f); th.lineTo(tx + 4, y + s * 0.15f); th.close(); c.drawPath(th, pp); } }
        // ojo
        pp.setColor(Color.WHITE); c.drawCircle(x + s * 0.4f, y - s * 0.15f, s * 0.22f, pp);
        pp.setColor(f.dead ? 0xFF444444 : 0xFF1A1A2A); c.drawCircle(x + s * 0.45f, y - s * 0.13f, s * 0.11f, pp);
        if (f.kind == 0 && f.stage == 3) { pp.setColor(0xFFFFD34A); for (int k = 0; k < 3; k++) { c.drawRect(x - s * 0.6f + k * 4, y - s * 0.95f, x - s * 0.6f + k * 4 + 2.5f, y - s * 0.7f, pp); } }   // coronita del pez grande
        c.restore();
        if (hungry && !f.dead && ((int) (t * 3)) % 2 == 0) text(c, "🍽", x, y - s - 4, 10, Color.WHITE);
    }

    static int blend(int a, int b, float k) {
        k = Math.max(0, Math.min(1, k));
        return Color.rgb((int) (Color.red(a) + (Color.red(b) - Color.red(a)) * k), (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * k), (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k));
    }

    void drawCoin(Canvas c, Coin co) {
        if (co.y >= floor - 6 && co.life < 1.5f && ((int) (co.life * 10)) % 2 == 0) return;
        float x = co.x, y = co.y;
        switch (co.kind) {
            case 0: pp.setColor(0xFFC8CDD6); c.drawCircle(x, y, 7, pp); pp.setColor(0xFFE8ECF2); c.drawCircle(x - 1.5f, y - 1.5f, 3, pp); break;
            case 1: pp.setColor(0xFFFFC83A); c.drawCircle(x, y, 8, pp); pp.setColor(0xFFFFE68A); c.drawCircle(x - 2, y - 2, 3.5f, pp); break;
            case 2: pp.setColor(0xFFFFE07A); star(c, x, y, 9); break;
            case 3: { pp.setColor(0xFF4CE0FF); Path d = new Path(); d.moveTo(x, y - 9); d.lineTo(x + 8, y - 2); d.lineTo(x, y + 9); d.lineTo(x - 8, y - 2); d.close(); c.drawPath(d, pp); pp.setColor(0xFFCFF6FF); c.drawCircle(x - 2, y - 3, 2, pp); break; }
            case 4: pp.setColor(0xFFFFF2FA); c.drawCircle(x, y, 7, pp); pp.setColor(0xFFFFFFFF); c.drawCircle(x - 2, y - 2, 2.5f, pp); break;
            default: pp.setColor(0xFF8A5A2B); c.drawRect(x - 10, y - 7, x + 10, y + 7, pp); pp.setColor(0xFFFFD34A); c.drawRect(x - 10, y - 2, x + 10, y + 1, pp); break;
        }
    }

    void star(Canvas c, float x, float y, float r) {
        Path s = new Path();
        for (int i = 0; i < 10; i++) { float a = (float) (i * Math.PI / 5 - Math.PI / 2), rr = i % 2 == 0 ? r : r * 0.45f; float xx = x + (float) Math.cos(a) * rr, yy = y + (float) Math.sin(a) * rr; if (i == 0) s.moveTo(xx, yy); else s.lineTo(xx, yy); }
        s.close(); c.drawPath(s, pp);
    }

    /** Visitantes del abismo: una medusa gigante (lenta y dura) y una anguila de un ojo (rápida). */
    void drawAlien(Canvas c, Alien a) {
        float x = a.x, y = a.y + (float) Math.sin(a.wob) * 3;
        int col = a.hit > 0 ? Color.WHITE : a.kind == 0 ? 0xFFB46BFF : 0xFF3DDC84;
        if (a.kind == 0) {
            pp.setColor(col); c.drawArc(new RectF(x - 28, y - 26, x + 28, y + 20), 180, 180, true, pp);
            pp.setStyle(Paint.Style.STROKE); pp.setStrokeWidth(4);
            for (int k = 0; k < 5; k++) { float tx = x - 20 + k * 10; c.drawLine(tx, y - 3, tx + (float) Math.sin(a.wob + k) * 6, y + 26, pp); }
            pp.setStyle(Paint.Style.FILL);
            pp.setColor(Color.WHITE); c.drawCircle(x - 9, y - 12, 6, pp); c.drawCircle(x + 9, y - 12, 6, pp);
            pp.setColor(0xFFFF2244); c.drawCircle(x - 8, y - 11, 3, pp); c.drawCircle(x + 10, y - 11, 3, pp);
        } else {
            pp.setColor(col); c.drawOval(x - 26, y - 10, x + 26, y + 10, pp);
            pp.setColor(blend(col, Color.BLACK, 0.3f)); c.drawOval(x - 32, y - 5, x - 18, y + 5, pp);
            pp.setColor(Color.WHITE); c.drawCircle(x + 12, y - 2, 7, pp);
            pp.setColor(0xFF111111); c.drawCircle(x + 14, y - 2, 3.5f, pp);
        }
        float w = 46;
        pp.setColor(0xAA000000); c.drawRect(x - w / 2, y - 36, x + w / 2, y - 32, pp);
        pp.setColor(0xFFFF4D5E); c.drawRect(x - w / 2, y - 36, x - w / 2 + w * Math.max(0, a.hp / a.max), y - 32, pp);
    }

    void drawPet(Canvas c) {
        if (petA < 0) return;
        float x = petX, y = petA == 2 ? top + 26 + (float) Math.sin(t * 2) * 4 : floor - 8;
        petY = y;
        switch (petA) {
            case 0: pp.setColor(0xFFB98A5A); c.drawCircle(x, y - 4, 8, pp); pp.setColor(0xFF8A5A2B); c.drawCircle(x, y - 4, 4, pp); pp.setColor(0xFFE8C99A); c.drawRect(x - 12, y - 1, x + 12, y + 4, pp); break;
            case 1: pp.setColor(0xFF9AA4B4); c.drawArc(new RectF(x - 14, y - 12, x + 14, y + 6), 180, 180, true, pp); c.drawArc(new RectF(x - 14, y - 6, x + 14, y + 10), 0, 180, true, pp);
                    if (petT > 20) { pp.setColor(Color.WHITE); c.drawCircle(x, y - 2, 4, pp); } break;
            case 2: pp.setColor(0xFFFF7BA6); c.drawCircle(x, y, 11, pp); pp.setStyle(Paint.Style.STROKE); pp.setStrokeWidth(3);
                    for (int k = 0; k < 4; k++) c.drawLine(x - 8 + k * 5, y + 6, x - 8 + k * 5 + (float) Math.sin(t * 4 + k) * 3, y + 18, pp);
                    pp.setStyle(Paint.Style.FILL); pp.setColor(Color.WHITE); c.drawCircle(x - 4, y - 2, 2.5f, pp); c.drawCircle(x + 4, y - 2, 2.5f, pp); break;
            default: pp.setColor(0xFF4F9A3A); c.drawOval(x - 16, y - 12, x + 16, y + 4, pp); pp.setColor(0xFF7FCB5A); c.drawCircle(x + (petVx > 0 ? 18 : -18), y - 4, 6, pp); break;
        }
    }

    void drawShop(Canvas c) {
        pp.setColor(0xDD0A2A44); c.drawRect(0, 0, vw, 66, pp);
        String[] ic = {"🐟", "🍤", "➕", level >= 3 ? "🦈" : level >= 2 ? "🫧" : "🔒", "🔫", "🥚"};
        int[] cost = {fishCost(), foodQCost(), foodNCost(), level >= 3 ? carnCost() : level >= 2 ? 400 : 0, weaponCost(), eggCost()};
        String[] sub = {"", L.t("niv.") + " " + (foodLv + 1), "×" + foodMax, "", L.t("niv.") + " " + (weaponLv + 1), eggParts + "/3"};
        for (int i = 0; i < 6; i++) {
            RectF r = shop[i];
            boolean can = cost[i] > 0 && money >= cost[i];
            box(c, r, can ? 0xFFFFD34A : 0xFF3A5A7A, 220);
            text(c, ic[i], r.centerX(), r.top + 22, 17, Color.WHITE);
            text(c, cost[i] > 0 ? "$" + cost[i] : "—", r.centerX(), r.top + 40, 10, can ? 0xFFFFD34A : 0xFF8AA0B8);
            text(c, sub[i], r.centerX(), r.top + 53, 9, 0xFFBFE6FF);
        }
        // dinero y pausa abajo
        pp.setColor(0xAA000000); c.drawRect(0, vh - 34, vw, vh, pp);
        textLeft(c, "$ " + money, 10, vh - 12, 17, 0xFFFFD34A);
        text(c, L.t("NIV") + " " + level + " · " + L.t(TANKS[tank()]), vw / 2 + 10, vh - 13, 11, 0xFFBFE6FF);
        text(c, "II", vw - 22, vh - 12, 16, Color.WHITE);
    }

    void dim(Canvas c) { pp.setColor(Color.argb(170, 0, 10, 30)); c.drawRect(0, 0, vw, vh, pp); }

    void drawTitle(Canvas c) {
        Fish demo = new Fish();
        for (int i = 0; i < 5; i++) { demo.kind = i == 4 ? 1 : 0; demo.stage = i % 4; demo.x = (i * 90 + t * 30) % (vw + 60) - 30; demo.y = vh * 0.38f + (i % 3) * 30; demo.wob = t * 5 + i; demo.flip = false; drawFish(c, demo); }
        text(c, L.t("ACUARIO"), vw / 2, vh * 0.16f, 38, 0xFFFFD34A);
        text(c, L.t("DEL ECO"), vw / 2, vh * 0.16f + 34, 22, Color.WHITE);
        float y = vh * 0.52f;
        int cont = Math.min(unlocked, LEVELS);
        if (menuButton(c, new RectF(50, y, vw - 50, y + 50), L.t("▶ JUGAR · NIVEL") + " " + cont, 0xFF44E07A)) { petPickFor = cont; goPlay(cont); }
        float yy = y + 64;
        text(c, L.t("Elegir nivel:"), vw / 2, yy, 12, 0xFFBFE6FF);
        yy += 8;
        for (int lv = 1; lv <= LEVELS; lv++) {
            int col = (lv - 1) % 10, row = (lv - 1) / 10;
            RectF r = new RectF(16 + col * 33, yy + row * 36, 16 + col * 33 + 29, yy + row * 36 + 30);
            boolean open = lv <= unlocked;
            box(c, r, open ? 0xFF4FC3E8 : Color.DKGRAY, 200);
            text(c, open ? String.valueOf(lv) : "🔒", r.centerX(), r.centerY() + 5, 12, open ? Color.WHITE : Color.GRAY);
            if (open && tapIn(r)) { goPlay(lv); return; }
        }
        wrap(c, "Toca el agua para echar comida ($5). Toca las monedas antes de que desaparezcan. Compra piezas del huevo para pasar de nivel. Si viene algo del abismo, tócalo para echarlo.",
                vw / 2, vh - 110, vw - 40, 12, Color.WHITE, true);
    }

    int petPickFor;

    void goPlay(int lv) {
        petPickFor = lv;
        boolean any = false;
        for (boolean b : petOwned) any |= b;
        if (any) { st = S_PET; stT = 0; } else { petA = -1; startLevel(lv); }
    }

    void drawPetPick(Canvas c) {
        dim(c);
        text(c, L.t("ELIGE UNA MASCOTA"), vw / 2, vh * 0.18f, 20, Color.WHITE);
        float y = vh * 0.24f;
        for (int i = 0; i < 4; i++) {
            RectF r = new RectF(30, y, vw - 30, y + 62);
            box(c, r, petOwned[i] ? 0xFF44E07A : Color.DKGRAY, 220);
            textLeft(c, petOwned[i] ? L.t(PET_N[i]) : "🔒 " + L.t("Se gana en el nivel") + " " + ((i + 1) * 5), 44, y + 26, 15, petOwned[i] ? Color.WHITE : Color.GRAY);
            if (petOwned[i]) textLeft(c, L.t(PET_D[i]), 44, y + 48, 11, 0xFFBFE6FF);
            if (petOwned[i] && tapIn(r)) { petA = i; startLevel(petPickFor); return; }
            y += 72;
        }
        if (menuButton(c, new RectF(70, y + 10, vw - 70, y + 54), L.t("Sin mascota"), Color.GRAY)) { petA = -1; startLevel(petPickFor); }
    }

    void drawPause(Canvas c) {
        dim(c);
        text(c, L.t("PAUSA"), vw / 2, vh * 0.3f, 30, Color.WHITE);
        float y = vh * 0.38f;
        if (menuButton(c, new RectF(60, y, vw - 60, y + 48), L.t("▶ SEGUIR"), 0xFF44E07A)) st = S_PLAY;
        if (menuButton(c, new RectF(60, y + 60, vw - 60, y + 108), L.t("↻ REPETIR NIVEL"), 0xFFFFD34A)) goPlay(level);
        if (menuButton(c, new RectF(60, y + 120, vw - 60, y + 168), L.t("☰ MENÚ"), Color.GRAY)) st = S_TITLE;
    }

    void drawWin(Canvas c) {
        dim(c);
        text(c, L.t("¡EL HUEVO SE ABRE!"), vw / 2, vh * 0.3f, 24, 0xFFFFD34A);
        if (level % 5 == 0 && level / 5 - 1 < 4) {
            text(c, L.t("Nueva mascota:") + " " + L.t(PET_N[level / 5 - 1]), vw / 2, vh * 0.37f, 15, 0xFF44E07A);
            text(c, L.t(PET_D[level / 5 - 1]), vw / 2, vh * 0.41f, 12, Color.WHITE);
        } else text(c, L.t("¡Nivel superado!"), vw / 2, vh * 0.38f, 17, Color.WHITE);
        if (level >= LEVELS) text(c, L.t("¡Has completado las 4 peceras!"), vw / 2, vh * 0.46f, 14, 0xFFFFD34A);
        if (stT > 0.8f) {
            if (level < LEVELS && menuButton(c, new RectF(60, vh * 0.52f, vw - 60, vh * 0.52f + 48), L.t("▶ SIGUIENTE NIVEL"), 0xFF44E07A)) goPlay(level + 1);
            if (menuButton(c, new RectF(60, vh * 0.52f + 60, vw - 60, vh * 0.52f + 108), L.t("☰ MENÚ"), Color.GRAY)) st = S_TITLE;
        }
    }

    void drawOver(Canvas c) {
        dim(c);
        text(c, L.t("Tu pecera se ha quedado vacía"), vw / 2, vh * 0.36f, 18, 0xFFFF8080);
        if (stT > 0.8f) {
            if (menuButton(c, new RectF(60, vh * 0.45f, vw - 60, vh * 0.45f + 48), L.t("↻ OTRA VEZ"), 0xFFFFD34A)) goPlay(level);
            if (menuButton(c, new RectF(60, vh * 0.45f + 60, vw - 60, vh * 0.45f + 108), L.t("☰ MENÚ"), Color.GRAY)) st = S_TITLE;
        }
    }
}
