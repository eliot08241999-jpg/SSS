package com.aplauso.encuentra;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Editor de texto de documentos: abre PDF/EPUB/DOCX/TXT, deja editar y guarda en el formato que elijas. */
public class DocEditActivity extends NeonActivity {
    Uri uri;
    EditText title, body;
    TextView info;
    String srcType = "txt";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        uri = getIntent().getData();
        LinearLayout col = screen(uri == null ? "NUEVO DOC" : "EDITAR");
        col.addView(text("Título", 13));
        title = new EditText(this);
        title.setTextColor(Color.WHITE);
        title.setSingleLine(true);
        title.setBackground(frame(10));
        title.setPadding(dpi(12), dpi(10), dpi(12), dpi(10));
        col.addView(title, gapBelow(10));
        info = text(uri == null ? "Escribe tu documento y guárdalo como PDF, EPUB, DOCX o TXT." : "Cargando…", 12);
        col.addView(info, gapBelow(8));
        body = new EditText(this);
        body.setTextColor(Color.rgb(235, 238, 245));
        body.setTextSize(16);
        body.setGravity(Gravity.TOP | Gravity.START);
        body.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        body.setMinLines(16);
        body.setBackground(frame(10));
        body.setPadding(dpi(12), dpi(10), dpi(12), dpi(10));
        col.addView(body, gapBelow(12));
        col.addView(button("💾 GUARDAR COMO…", v -> chooseFormat()), gapBelow(8));
        TextView note = text("Se guarda en SSS+/Documentos. El archivo original no se modifica.", 12);
        col.addView(note);

        if (uri != null) {
            new Thread(() -> {
                try {
                    DocIO.Doc d = DocPdf.load(this, uri);
                    runOnUiThread(() -> {
                        srcType = d.type;
                        title.setText(d.title);
                        body.setText(d.text());
                        info.setText(L.t("pdf".equals(d.type)
                                ? "⚠ PDF: se ha sacado el texto para editarlo. Al guardar se crea un documento nuevo con el texto (sin el diseño original)."
                                : d.paras.size() + " párrafos · formato original: " + d.type.toUpperCase()));
                    });
                } catch (Throwable t) {
                    runOnUiThread(() -> info.setText(L.t("No se pudo abrir: " + t.getMessage())));
                }
            }).start();
        }
    }

    void chooseFormat() {
        String[] names = {"PDF", "EPUB (libro electrónico)", "DOCX (Word)", "TXT (texto)"};
        new AlertDialog.Builder(this)
                .setTitle(L.t("Guardar como"))
                .setItems(L.ta(names), (d, which) -> save(DocIO.FORMATS[which]))
                .show();
    }

    void save(String format) {
        String t = title.getText().toString().trim();
        DocIO.Doc d = DocIO.Doc.fromText(t.isEmpty() ? "Documento" : t, body.getText().toString());
        info.setText(L.t("Guardando…"));
        new Thread(() -> {
            Uri saved = null;
            String err = null;
            try { saved = DocPdf.saveAs(this, d, format); } catch (Throwable e) { err = e.getMessage(); }
            Uri fs = saved;
            String fe = err;
            runOnUiThread(() -> {
                if (fs == null) { info.setText(L.t("No se pudo guardar" + (fe != null ? ": " + fe : ""))); return; }
                info.setText(L.t("Guardado en SSS+/Documentos ✓ (" + format.toUpperCase() + ")"));
                new AlertDialog.Builder(this)
                        .setTitle(L.t("¡Guardado!"))
                        .setMessage(L.t("Documento guardado como " + format.toUpperCase() + " en SSS+/Documentos."))
                        .setPositiveButton(L.t("Abrir"), (x, y) -> startActivity(new Intent(this, DocReaderActivity.class).setData(fs)))
                        .setNegativeButton(L.t("Seguir editando"), null)
                        .show();
            });
        }).start();
    }
}
