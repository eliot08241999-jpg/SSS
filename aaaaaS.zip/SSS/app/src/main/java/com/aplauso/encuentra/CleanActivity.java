package com.aplauso.encuentra;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.storage.StorageManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Limpieza y optimización. Android no deja que una app borre la caché de otras,
 * así que aquí se hace lo que sí se puede: limpiar lo propio, borrar archivos que tú elijas
 * (con confirmación de Android) y abrir las herramientas del sistema.
 */
public class CleanActivity extends NeonActivity {
    static final int REQ_MEDIA = 20, REQ_DELETE = 21;
    static final int GREEN = Color.rgb(57, 255, 20), YELLOW = Color.rgb(255, 210, 0), RED = Color.rgb(255, 70, 110);

    LinearLayout col;
    TextView summary, cacheVal, shotsVal, videosVal, bigVal;
    List<Media.Item> oldShots = new ArrayList<>(), bigVideos = new ArrayList<>(), bigOther = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        col = screen("LIMPIEZA");

        LinearLayout sum = panel("◢ RECOMENDACIONES");
        summary = text("", 14);
        sum.addView(summary);
        col.addView(sum, gapBelow(14));

        // ----- RECOMENDADO -----
        LinearLayout rec = panel("◢ GENERAL");
        cacheVal = option(rec, "Caché de SSS+", "Archivos temporales de esta app.",
                "RECOMENDADO", GREEN, "LIMPIAR", v -> { clearOwnCache(); refresh(); });
        option(rec, "Liberar espacio de Android", "Herramienta del sistema: archivos basura, apps sin usar, copias…",
                "RECOMENDADO", GREEN, "ABRIR", v -> openStorageTool());
        shotsVal = option(rec, "Capturas antiguas", "Capturas de pantalla de hace más de 30 días.",
                "RECOMENDADO", GREEN, "REVISAR", v -> review(oldShots, "Capturas antiguas"));
        col.addView(rec, gapBelow(14));

        // ----- OPCIONAL -----
        LinearLayout opt = panel("◢ OPTIMIZACIÓN");
        option(opt, "Ahorro de batería", "Activa o programa el modo ahorro del sistema.",
                "OPCIONAL", YELLOW, "ABRIR", v -> openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        option(opt, "Optimización de batería por app", "Limita las apps que gastan en segundo plano.",
                "OPCIONAL", YELLOW, "ABRIR", v -> openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        videosVal = option(opt, "Videos grandes", "Videos de más de 100 MB.",
                "OPCIONAL", YELLOW, "REVISAR", v -> review(bigVideos, "Videos grandes"));
        col.addView(opt, gapBelow(14));

        // ----- CON CUIDADO -----
        LinearLayout care = panel("◢ AVANZADO");
        bigVal = option(care, "Fotos y audios grandes", "Fotos de más de 10 MB y audios de más de 30 MB.",
                "CON CUIDADO", RED, "REVISAR", v -> review(bigOther, "Fotos y audios grandes"));
        option(care, "Desinstalar apps", "Lista de apps instaladas; quita las que no uses.",
                "CON CUIDADO", RED, "ABRIR", v -> openSettings(Settings.ACTION_APPLICATION_SETTINGS));
        col.addView(care, gapBelow(14));

        TextView note = text("Nota: Android no permite que ninguna app borre la caché de otras apps. "
                + "Las limpiezas \"milagro\" de la Play Store solo abren estas mismas herramientas.", 12);
        note.setTextColor(Color.rgb(150, 160, 180));
        col.addView(note);

        if (!Media.hasPermission(this)) Media.request(this, REQ_MEDIA);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    /** Fila de opción: título, descripción, etiqueta de color, valor y botón. Devuelve el TextView del valor. */
    private TextView option(LinearLayout parent, String title, String desc, String tagText, int tagColor,
                            String action, android.view.View.OnClickListener l) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dpi(8), 0, dpi(10));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(title, 16);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(tag(tagText, tagColor));
        box.addView(head);

        TextView d = text(desc, 13);
        d.setTextColor(Color.rgb(170, 180, 200));
        box.addView(d);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dpi(6), 0, 0);
        TextView val = text("", 14);
        row.addView(val, new LinearLayout.LayoutParams(0, -2, 1));
        TextView btn = button(action, l);
        btn.setPadding(dpi(16), dpi(8), dpi(16), dpi(8));
        row.addView(btn);
        box.addView(row);
        parent.addView(box);
        return val;
    }

    private void refresh() {
        cacheVal.setText(SysInfo.bytes(dirSize(getCacheDir()) + dirSize(getExternalCacheDir())));

        if (Media.hasPermission(this)) {
            long monthAgo = System.currentTimeMillis() / 1000 - 30L * 24 * 3600;
            String shotSel = (Build.VERSION.SDK_INT >= 29 ? MediaStore.MediaColumns.RELATIVE_PATH : MediaStore.MediaColumns.DATA)
                    + " LIKE ? AND " + MediaStore.MediaColumns.DATE_MODIFIED + " < ?";
            oldShots = Media.query(this, Media.TYPE_IMAGE, shotSel, new String[]{"%Screenshot%", String.valueOf(monthAgo)}, 0);
            bigVideos = Media.query(this, Media.TYPE_VIDEO, MediaStore.MediaColumns.SIZE + " > ?",
                    new String[]{String.valueOf(100L * 1024 * 1024)}, 0);
            bigOther = new ArrayList<>(Media.query(this, Media.TYPE_IMAGE, MediaStore.MediaColumns.SIZE + " > ?",
                    new String[]{String.valueOf(10L * 1024 * 1024)}, 0));
            bigOther.addAll(Media.query(this, Media.TYPE_AUDIO, MediaStore.MediaColumns.SIZE + " > ?",
                    new String[]{String.valueOf(30L * 1024 * 1024)}, 0));
            shotsVal.setText(describe(oldShots));
            videosVal.setText(describe(bigVideos));
            bigVal.setText(describe(bigOther));
        } else {
            String msg = "Necesita permiso de fotos y videos";
            shotsVal.setText(msg);
            videosVal.setText(msg);
            bigVal.setText(msg);
        }

        // Recomendaciones según el estado del teléfono
        StringBuilder sb = new StringBuilder();
        long[] s = SysInfo.storage();
        float used = (s[0] - s[1]) / (float) s[0];
        sb.append(String.format(Locale.US, "• Almacenamiento: %d %% ocupado (%s libres). ", Math.round(used * 100), SysInfo.bytes(s[1])));
        sb.append(used > 0.9f ? "⚠ Libera espacio pronto.\n" : used > 0.8f ? "Conviene limpiar.\n" : "Todo bien.\n");
        SysInfo.Battery b = SysInfo.battery(this);
        if (!Float.isNaN(b.tempC))
            sb.append(String.format(Locale.US, "• Batería a %.1f °C. ", b.tempC))
                    .append(b.tempC > 40 ? "⚠ Caliente: deja de usarlo un rato.\n" : "Temperatura normal.\n");
        long[] r = SysInfo.ram(this);
        float ru = (r[0] - r[1]) / (float) r[0];
        sb.append(String.format(Locale.US, "• RAM: %d %% en uso. ", Math.round(ru * 100)))
                .append(ru > 0.9f ? "Cierra apps que no uses.\n" : "Bien.\n");
        if (!oldShots.isEmpty()) sb.append("• Tienes ").append(oldShots.size()).append(" capturas antiguas que puedes revisar.\n");
        summary.setText(sb.toString().trim());
    }

    private String describe(List<Media.Item> list) {
        if (list.isEmpty()) return "Nada que limpiar ✓";
        return list.size() + " archivos · " + SysInfo.bytes(Media.totalSize(list));
    }

    // ---------- Acciones ----------
    private void clearOwnCache() {
        long before = dirSize(getCacheDir()) + dirSize(getExternalCacheDir());
        deleteContents(getCacheDir());
        deleteContents(getExternalCacheDir());
        toast("Liberado: " + SysInfo.bytes(before));
    }

    private void openStorageTool() {
        try {
            startActivity(new Intent(StorageManager.ACTION_MANAGE_STORAGE));
        } catch (Exception e) {
            openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS);
        }
    }

    private void openSettings(String action) {
        try {
            startActivity(new Intent(action));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    /** Muestra la lista para elegir qué borrar; Android pide confirmación final. */
    private void review(List<Media.Item> list, String title) {
        if (!Media.hasPermission(this)) { Media.request(this, REQ_MEDIA); return; }
        if (list.isEmpty()) { toast("Nada que limpiar"); return; }
        if (Build.VERSION.SDK_INT < 30) {
            toast("Borrar desde aquí necesita Android 11 o superior");
            return;
        }
        String[] names = new String[list.size()];
        boolean[] checked = new boolean[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Media.Item it = list.get(i);
            names[i] = it.name + "  (" + SysInfo.bytes(it.size) + ")";
            checked[i] = true;
        }
        new AlertDialog.Builder(this)
                .setTitle(L.t(title + " — marca lo que quieras borrar"))
                .setMultiChoiceItems(names, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(L.t("Borrar"), (d, w) -> {
                    List<Uri> uris = new ArrayList<>();
                    for (int i = 0; i < list.size(); i++) if (checked[i]) uris.add(list.get(i).uri);
                    if (uris.isEmpty()) return;
                    try {
                        PendingIntent pi = MediaStore.createDeleteRequest(getContentResolver(), uris);
                        startIntentSenderForResult(pi.getIntentSender(), REQ_DELETE, null, 0, 0, 0);
                    } catch (Exception e) {
                        toast("No se pudo borrar");
                    }
                })
                .setNegativeButton(L.t("Cancelar"), null)
                .show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_DELETE) {
            if (res == RESULT_OK) toast("Borrado ✓");
            refresh();
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_MEDIA) refresh();
    }

    // ---------- Utilidades de archivos ----------
    static long dirSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long s = 0;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) s += dirSize(k);
        return s;
    }

    static void deleteContents(File dir) {
        if (dir == null) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            if (k.isDirectory()) deleteContents(k);
            k.delete();
        }
    }
}
