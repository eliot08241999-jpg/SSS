package com.aplauso.encuentra;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Sprites pixelados de los minijuegos nuevos (v1.1), dibujados con código: cada letra es un color de la paleta
 * y «.» es transparente. Todo es diseño original de SSS+.
 */
public class Pix {
    final String[] rows;
    final int[] pal;          // índice por letra a..z
    final int w, h;

    Pix(int[] palette, String... rows) {
        this.rows = rows;
        this.pal = palette;
        w = rows[0].length();
        h = rows.length;
    }

    /** Paleta: pares letra → color. */
    static int[] pal(Object... kv) {
        int[] p = new int[26];
        for (int i = 0; i < kv.length; i += 2) p[(Character) kv[i] - 'a'] = (Integer) kv[i + 1];
        return p;
    }

    /** Dibuja centrado en (cx, cy) con píxeles de tamaño px; flip = mirar a la izquierda; tint ≠ 0 lo pinta todo de ese color. */
    void draw(Canvas c, Paint p, float cx, float cy, float px, boolean flip, int tint) {
        float x0 = cx - w * px / 2, y0 = cy - h * px / 2;
        for (int y = 0; y < h; y++) {
            String r = rows[y];
            for (int x = 0; x < w; x++) {
                char ch = r.charAt(x);
                if (ch == '.') continue;
                int col = tint != 0 ? tint : pal[ch - 'a'];
                p.setColor(col);
                int xx = flip ? w - 1 - x : x;
                c.drawRect(x0 + xx * px, y0 + y * px, x0 + (xx + 1) * px + 0.3f, y0 + (y + 1) * px + 0.3f, p);
            }
        }
    }

    /** Igual pero en gris piedra (para la Hechicera petrificada). */
    void drawStone(Canvas c, Paint p, float cx, float cy, float px) {
        float x0 = cx - w * px / 2, y0 = cy - h * px / 2;
        for (int y = 0; y < h; y++) {
            String r = rows[y];
            for (int x = 0; x < w; x++) {
                char ch = r.charAt(x);
                if (ch == '.') continue;
                int col = pal[ch - 'a'];
                int g = (int) (0.3f * ((col >> 16) & 255) + 0.59f * ((col >> 8) & 255) + 0.11f * (col & 255));
                g = 70 + g * 110 / 255;
                p.setColor(0xFF000000 | (g << 16) | (g << 8) | g);
                c.drawRect(x0 + x * px, y0 + y * px, x0 + (x + 1) * px + 0.3f, y0 + (y + 1) * px + 0.3f, p);
            }
        }
    }
}
