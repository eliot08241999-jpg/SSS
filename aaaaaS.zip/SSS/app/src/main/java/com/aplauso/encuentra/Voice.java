package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.Locale;

/**
 * La voz del asistente (v0.9.2): usa los motores de voz instalados en el teléfono.
 * Se puede elegir el motor (Google, Samsung, RHVoice... los que instales desde Play Store),
 * la voz concreta, el tono y la velocidad.
 */
public class Voice {
    static TextToSpeech tts;
    static String engineNow;
    static volatile boolean ready, speaking;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    static void init(Context c, Runnable onReady) {
        Context app = c.getApplicationContext();
        if (KokoroVoice.on(app)) KokoroVoice.warm(app);          // v1.5: su voz propia, cargada por adelantado
        String eng = prefs(c).getString("tts_engine", "");
        if (tts != null && eng.equals(engineNow == null ? "" : engineNow) && ready) { if (onReady != null) onReady.run(); return; }
        shutdown();
        engineNow = eng;
        TextToSpeech.OnInitListener l = status -> {
            ready = status == TextToSpeech.SUCCESS;
            if (ready) apply(app);
            if (onReady != null) onReady.run();
        };
        tts = eng.isEmpty() ? new TextToSpeech(app, l) : new TextToSpeech(app, l, eng);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { speaking = true; lastWord = android.os.SystemClock.uptimeMillis(); }
            @Override public void onRangeStart(String id, int start, int end, int frame) { lastWord = android.os.SystemClock.uptimeMillis(); }   // v1.4: para mover la boca
            @Override public void onDone(String id) { speaking = false; }
            @Override public void onError(String id) { speaking = false; }
        });
    }

    /** v1.4: cuándo empezó la última palabra (para la boca de Chloe). */
    static volatile long lastWord;

    static void apply(Context c) { apply(c, L.lang); }

    /** v1.4.9: habla en el idioma del texto («es», «it», «en»). Tu voz elegida se usa si es de ese idioma; si no, la normal de ese idioma. */
    static void apply(Context c, String lang) {
        if (tts == null || !ready) return;
        SharedPreferences p = prefs(c);
        Locale loc = "en".equals(lang) ? Locale.US : "it".equals(lang) ? Locale.ITALY : new Locale("es", "ES");
        try { tts.setLanguage(loc); } catch (Exception ignored) {}
        String vn = p.getString("tts_voice", "");
        if (!vn.isEmpty()) {
            try {
                for (android.speech.tts.Voice v : tts.getVoices())
                    if (v.getName().equals(vn)) { if (v.getLocale() != null && v.getLocale().getLanguage().equals(loc.getLanguage())) tts.setVoice(v); break; }
            } catch (Exception ignored) {}
        }
        tts.setPitch(p.getInt("tts_pitch", 100) / 100f);
        tts.setSpeechRate(p.getInt("tts_rate", 100) / 100f);
    }

    static void say(Context c, String text) {
        // v1.5: la voz propia de Chloe (si está descargada y activada, y el texto es español)
        if (KokoroVoice.use(c, Brain.langCode(text))) {
            if (tts != null) try { tts.stop(); } catch (Exception ignored) {}
            final Context app = c.getApplicationContext();
            KokoroVoice.speak(c, text, ok -> { if (!ok) sayPhone(app, text); });
            return;
        }
        KokoroVoice.stop();
        sayPhone(c, text);
    }

    // ---------------- v1.6: hablar mientras la respuesta aún se está escribiendo ----------------
    static volatile boolean kokoroOpen;

    /** Empieza a decir el primer trozo; luego sayMore(…) con el resto. */
    static void sayStart(Context c, String first) {
        if (KokoroVoice.use(c, Brain.langCode(first))) {
            if (tts != null) try { tts.stop(); } catch (Exception ignored) {}
            final Context app = c.getApplicationContext();
            kokoroOpen = true;
            KokoroVoice.speak(c, first, ok -> { if (!ok) sayPhone(app, first); }, true);
            return;
        }
        kokoroOpen = false;
        KokoroVoice.stop();
        sayPhone(c, first);
    }

    /** El resto (o null si no hay más). */
    static void sayMore(Context c, String rest) {
        if (kokoroOpen) { KokoroVoice.more(rest, true); kokoroOpen = false; return; }
        if (rest == null || rest.trim().isEmpty()) return;
        init(c, () -> {
            if (!ready) return;
            speaking = true;
            tts.speak(rest, TextToSpeech.QUEUE_ADD, new Bundle(), "sss" + System.currentTimeMillis());
        });
    }

    /** v1.6: dice la respuesta según se va escribiendo: arranca con la primera frase y luego sigue. */
    static final class Streamer {
        final Context c;
        String spoken = "";
        boolean started;
        Streamer(Context c) { this.c = c.getApplicationContext(); }

        /** Lo que lleva escrito el cerebro (texto en bruto). Devuelve el texto limpio para enseñarlo. */
        String partial(String raw) {
            String t = raw;
            int k = t.indexOf("[[");
            if (k < 0) k = t.indexOf("[");
            if (k >= 0) t = t.substring(0, k);
            t = Brain.clean(t);
            if (!started) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(.{12,}?[.!…])\\s+\\S").matcher(t);
                if (m.find() && !raw.contains("[[buscar")) {
                    started = true;
                    spoken = m.group(1).trim();
                    sayStart(c, spoken);
                }
            }
            return t;
        }

        /** La respuesta final (ya limpia): dice lo que falta, o la entera si cambió. */
        void finish(String ans) {
            if (!started) { say(c, ans); return; }
            String a = ans.trim();
            if (a.startsWith(spoken)) sayMore(c, a.substring(spoken.length()).trim());
            else { stop(); say(c, a); }
        }
    }

    /** Con la voz del teléfono. */
    static void sayPhone(Context c, String text) {
        init(c, () -> {
            if (!ready) { speaking = false; return; }
            apply(c, Brain.langCode(text));
            speaking = true;
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), "sss" + System.currentTimeMillis());
        });
    }

    static void stop() { kokoroOpen = false; KokoroVoice.stop(); if (tts != null) try { tts.stop(); } catch (Exception ignored) {} speaking = false; }

    static void shutdown() {
        if (tts != null) try { tts.shutdown(); } catch (Exception ignored) {}
        tts = null;
        ready = false;
        speaking = false;
    }
}
