package com.aplauso.encuentra;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Operaciones de archivos: copiar, mover, borrar, comprimir y descomprimir ZIP/RAR. */
public class Archive {

    public interface Progress { void on(String what); }

    static String ext(String name) {
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(i + 1).toLowerCase(Locale.ROOT) : "";
    }

    /** Un nombre libre dentro de la carpeta ("foto (2).jpg" si ya existe). */
    static File unique(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        String base = name, e = "";
        int i = name.lastIndexOf('.');
        if (i > 0 && !new File(dir, name).isDirectory()) { base = name.substring(0, i); e = name.substring(i); }
        for (int n = 2; n < 10000; n++) {
            f = new File(dir, base + " (" + n + ")" + e);
            if (!f.exists()) return f;
        }
        return f;
    }

    static void copyStream(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[128 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    static void copy(File src, File dst, Progress p) throws IOException {
        if (dst.getAbsolutePath().startsWith(src.getAbsolutePath() + File.separator))
            throw new IOException("No se puede copiar una carpeta dentro de sí misma");
        if (src.isDirectory()) {
            if (!dst.exists() && !dst.mkdirs()) throw new IOException("No se pudo crear " + dst.getName());
            File[] kids = src.listFiles();
            if (kids != null) for (File k : kids) copy(k, new File(dst, k.getName()), p);
        } else {
            if (p != null) p.on(src.getName());
            try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                copyStream(in, out);
            }
            dst.setLastModified(src.lastModified());
        }
    }

    static void move(File src, File dst, Progress p) throws IOException {
        if (src.renameTo(dst)) return;          // misma unidad: instantáneo
        copy(src, dst, p);
        delete(src);
    }

    static boolean delete(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) delete(k);
        }
        return f.delete();
    }

    static long size(File f) {
        if (f.isFile()) return f.length();
        long s = 0;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) s += size(k);
        return s;
    }

    // ---------------- ZIP ----------------
    static File zip(File src, Progress p) throws IOException {
        File out = unique(src.getParentFile(), (src.isDirectory() ? src.getName() : DocIO.baseName(src.getName())) + ".zip");
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out)))) {
            addToZip(z, src, src.getName(), p);
        }
        return out;
    }

    private static void addToZip(ZipOutputStream z, File f, String path, Progress p) throws IOException {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            z.putNextEntry(new ZipEntry(path + "/"));
            z.closeEntry();
            if (kids != null) for (File k : kids) addToZip(z, k, path + "/" + k.getName(), p);
            return;
        }
        if (p != null) p.on(f.getName());
        ZipEntry e = new ZipEntry(path);
        e.setTime(f.lastModified());
        z.putNextEntry(e);
        try (InputStream in = new BufferedInputStream(new FileInputStream(f))) { copyStream(in, z); }
        z.closeEntry();
    }

    /** Descomprime un ZIP en una carpeta nueva junto al archivo. */
    static File unzip(File zip, Progress p) throws IOException {
        File dest = unique(zip.getParentFile(), DocIO.baseName(zip.getName()));
        if (!dest.mkdirs()) throw new IOException("No se pudo crear la carpeta");
        String root = dest.getCanonicalPath() + File.separator;
        try (ZipInputStream z = new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                File f = new File(dest, e.getName());
                if (!f.getCanonicalPath().startsWith(root)) continue;     // protección contra rutas peligrosas
                if (e.isDirectory()) { f.mkdirs(); continue; }
                File parent = f.getParentFile();
                if (parent != null) parent.mkdirs();
                if (p != null) p.on(f.getName());
                try (OutputStream out = new BufferedOutputStream(new FileOutputStream(f))) { copyStream(z, out); }
            }
        }
        return dest;
    }

    /** Descomprime un RAR (formato RAR4; los RAR5 no los admite la biblioteca junrar). */
    static File unrar(File rar, Progress p) throws Exception {
        File dest = unique(rar.getParentFile(), DocIO.baseName(rar.getName()));
        if (!dest.mkdirs()) throw new IOException("No se pudo crear la carpeta");
        if (p != null) p.on(rar.getName());
        com.github.junrar.Junrar.extract(rar, dest);
        return dest;
    }
}
