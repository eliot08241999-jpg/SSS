package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 🔮 ORBES DEL ECO (v1.1): una cadena de orbes avanza por un camino hacia el vórtice. El Tótem de cristal
 * dispara orbes: junta 3 o más del mismo color para romperlos. Si la cadena llega al vórtice, pierdes una vida.
 * 60 niveles en 6 templos + modo infinito. Diseño original de SSS+ (por BLORP.eoac).
 */
public class OrbeView extends GameKit.GameView implements ArcadeActivity.Backable {
    // ---------------- estado general ----------------
    static final int S_TITLE = 0, S_PLAY = 1, S_PAUSE = 2, S_CLEAR = 3, S_LOST = 4, S_OVER = 5, S_WORLD = 6, S_INTRO = 7;
    int st = S_TITLE;
    int level = 1, lives = 3, score = 0;
    float t;                    // tiempo total
    float stT;                  // tiempo en el estado actual
    final Random rnd = new Random();

    static final int LEVELS = 60, PER_WORLD = 10;
    static final String[] WORLDS = {"Templo del Alba", "Selva de Cristal", "Ruinas del Lago", "Cavernas de Fuego", "Ciudad de las Nubes", "Santuario del Eco"};
    static final int[][] WORLD_BG = {      // fondo arriba, fondo abajo, color del camino (brillo)
            {0xFF1B1530, 0xFF0B0A18, 0xFFFFC46B}, {0xFF0E2A22, 0xFF06120F, 0xFF6BFFC4}, {0xFF0D1F33, 0xFF050B14, 0xFF6BC8FF},
            {0xFF331208, 0xFF140604, 0xFFFF7A3D}, {0xFF2A2F4A, 0xFF10121F, 0xFFE6ECFF}, {0xFF240D33, 0xFF0C0414, 0xFFE07BFF}};
    static final int[] ORB = {0xFFFF4D5E, 0xFF3DA5FF, 0xFFFFD84A, 0xFF44E07A, 0xFFB46BFF, 0xFFFF9A3D, 0xFFEFEFEF};

    // ---------------- camino ----------------
    float[] px = new float[0], py = new float[0];   // puntos cada 1 unidad
    float pathLen;
    float sx, sy;                                    // tótem (tirador)
    static final float R = 11f, D = 22f;

    // ---------------- cadena ----------------
    static final class Orb { int c; float s, ds; int power; }     // power: 0 nada, 1 atrás, 2 lento, 3 bomba, 4 puntería
    final List<Orb> chain = new ArrayList<>();     // [0] el más adelantado (cerca del vórtice)
    int toSpawn, colors;
    float speed, rush, slowT, backT, aimT, dangerBeat;
    int combo;
    boolean sucking;

    // ---------------- disparo ----------------
    float ang = -(float) Math.PI / 2;
    int cur, next;
    boolean flying;
    float fx, fy, fvx, fvy;
    int fc;
    boolean aiming;
    float aimX, aimY;

    // ---------------- efectos ----------------
    static final class Part { float x, y, vx, vy, life; int c; }
    final List<Part> parts = new ArrayList<>();
    static final class Pop { float x, y, life; String s; int c; }
    final List<Pop> pops = new ArrayList<>();

    final Paint orbP = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    Path pathDraw;
    int bestLevel;

    OrbeView(Context c) {
        super(c);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        bestLevel = Math.max(1, prefs().getInt("orbe_level", 1));
        chip.play(Songs.ORBE);
    }

    @Override void computeScale(int w, int h) { vw = 360; scale = w / vw; vh = h / scale; }

    @Override void layout() { if (px.length == 0 || st == S_TITLE) buildPath(level); }

    @Override public boolean onBack() {
        if (st == S_PLAY) { st = S_PAUSE; stT = 0; return true; }
        if (st == S_PAUSE) { st = S_PLAY; return true; }
        return false;
    }

    @Override boolean navActive() { return st != S_PLAY; }

    int world() { return Math.min(WORLDS.length - 1, (Math.min(level, LEVELS) - 1) / PER_WORLD); }

    // =========================================================================================
    //                                        CAMINOS
    // =========================================================================================
    /** Cada nivel tiene su camino: espiral, serpiente, herradura, doble lazo, corazón o zigzag, con variaciones. */
    void buildPath(int lv) {
        Random r = new Random(lv * 7919L + 13);
        int fam = (lv - 1) % 6;
        if (lv > LEVELS) fam = r.nextInt(6);
        float W = vw, H = vh;
        float top = 70, bot = H - 40;
        float cx = W / 2, cy = (top + bot) / 2;
        List<float[]> raw = new ArrayList<>();
        boolean mirror = r.nextBoolean();
        switch (fam) {
            case 0: {   // espiral hacia el centro
                float turns = 1.6f + r.nextFloat() * 0.8f, a0 = r.nextFloat() * 6.28f;
                float rx = W / 2 - 22, ry = Math.min((bot - top) / 2 - 10, rx * 1.55f);
                for (int i = 0; i <= 2000; i++) {
                    float k = i / 2000f, rr = 1f - 0.62f * k, a = a0 + k * turns * 6.2832f;
                    raw.add(new float[]{cx + (float) Math.cos(a) * rx * rr, cy + (float) Math.sin(a) * ry * rr});
                }
                sx = cx; sy = cy;
                break;
            }
            case 1: {   // serpiente: baja de lado a lado; el tótem abajo
                int rows = 4 + r.nextInt(2);
                float y0 = top + 10, y1 = bot - 170, rowH = (y1 - y0) / (rows - 1);
                float xl = rowH / 2 + 14, xr = W - rowH / 2 - 14;
                for (int row = 0; row < rows; row++) {
                    float y = y0 + row * rowH;
                    boolean ltr = (row % 2 == 0);
                    for (int i = 0; i <= 200; i++) { float k = i / 200f; raw.add(new float[]{ltr ? xl + (xr - xl) * k : xr - (xr - xl) * k, y}); }
                    if (row < rows - 1) {
                        float ex = ltr ? xr : xl;
                        for (int i = 1; i < 60; i++) {
                            float a = (float) (-Math.PI / 2 + Math.PI * i / 60f);
                            raw.add(new float[]{ex + (ltr ? 1 : -1) * (float) Math.cos(a) * rowH / 2, y + rowH / 2 + (float) Math.sin(a) * rowH / 2});
                        }
                    }
                }
                sx = cx; sy = bot - 70;
                break;
            }
            case 2: {   // herradura grande alrededor del tótem
                float rx = W / 2 - 24, ry = (bot - top) / 2 - 8;
                float a0 = (float) Math.PI * (0.62f + r.nextFloat() * 0.1f), span = (float) Math.PI * (1.75f + r.nextFloat() * 0.15f);
                for (int i = 0; i <= 1500; i++) { float k = i / 1500f, a = a0 + span * k; raw.add(new float[]{cx + (float) Math.cos(a) * rx, cy + (float) Math.sin(a) * ry}); }
                // y se mete hacia dentro
                float[] last = raw.get(raw.size() - 1);
                for (int i = 1; i <= 300; i++) { float k = i / 300f, a = a0 + span + k * 2.4f, rr = 1 - 0.45f * k; raw.add(new float[]{cx + (float) Math.cos(a) * rx * rr, cy + (float) Math.sin(a) * ry * rr}); }
                sx = cx; sy = cy;
                break;
            }
            case 3: {   // doble lazo (un 8)
                float ax = W / 2 - 30, ay = (bot - top) / 4 - 8;
                for (int i = 0; i <= 2400; i++) {
                    float k = i / 2400f, a = (float) (k * 2 * Math.PI) - (float) Math.PI / 2;
                    float x = cx + (float) Math.sin(a * 2) * ax * 0.95f, y = cy + (float) Math.sin(a) * ay * 1.9f;
                    raw.add(new float[]{x, y});
                }
                // cortar el final para que no se cierre el lazo
                for (int i = 0; i < 250; i++) raw.remove(raw.size() - 1);
                sx = cx + (mirror ? -1 : 1) * ax * 0.55f; sy = cy;
                mirror = false;
                break;
            }
            case 4: {   // ondas que bajan hasta el tótem en el centro, en forma de corazón abierto
                float rx = W / 2 - 26, ry = (bot - top) / 2 - 10;
                for (int i = 0; i <= 2200; i++) {
                    float k = i / 2200f, a = (float) (Math.PI / 2 + k * Math.PI * 3.3f);
                    float rr = 1 - 0.55f * k + 0.08f * (float) Math.sin(k * 40);
                    raw.add(new float[]{cx + (float) Math.cos(a) * rx * rr, cy + (float) Math.sin(a) * ry * rr * 0.92f});
                }
                sx = cx; sy = cy + 10;
                break;
            }
            default: {  // zigzag con curvas por los bordes y final dentro
                float xl = 26, xr = W - 26;
                float[] ys = {top + 8, top + (bot - top) * 0.3f, top + (bot - top) * 0.62f, bot - 10};
                raw.add(new float[]{xl, ys[0]});
                for (int i = 0; i <= 300; i++) raw.add(new float[]{xl + (xr - xl) * i / 300f, ys[0] + (float) Math.sin(i / 300f * Math.PI) * 30});
                for (int i = 0; i <= 300; i++) raw.add(new float[]{xr, ys[0] + (ys[3] - ys[0]) * i / 300f});
                for (int i = 0; i <= 300; i++) raw.add(new float[]{xr - (xr - xl) * i / 300f, ys[3] - (float) Math.sin(i / 300f * Math.PI) * 30});
                for (int i = 0; i <= 300; i++) raw.add(new float[]{xl, ys[3] - (ys[3] - ys[1] - 40) * i / 300f});
                for (int i = 0; i <= 200; i++) raw.add(new float[]{xl + (cx - 40 - xl) * i / 200f, ys[1] + 40});
                sx = cx + 30; sy = cy + 30;
                break;
            }
        }
        if (mirror) for (float[] p : raw) p[0] = W - p[0];
        if (mirror) sx = W - sx;
        // remuestrear cada 1 unidad
        List<float[]> out = new ArrayList<>();
        out.add(raw.get(0));
        float acc = 0;
        float[] prev = raw.get(0);
        for (int i = 1; i < raw.size(); i++) {
            float[] q = raw.get(i);
            float seg = (float) Math.hypot(q[0] - prev[0], q[1] - prev[1]);
            while (acc + seg >= 1f) {
                float k = (1f - acc) / seg;
                float nx = prev[0] + (q[0] - prev[0]) * k, ny = prev[1] + (q[1] - prev[1]) * k;
                out.add(new float[]{nx, ny});
                seg -= (1f - acc);
                prev = new float[]{nx, ny};
                acc = 0;
            }
            acc += seg;
            prev = q;
        }
        px = new float[out.size()];
        py = new float[out.size()];
        for (int i = 0; i < out.size(); i++) { px[i] = out.get(i)[0]; py[i] = out.get(i)[1]; }
        pathLen = px.length - 1;
        pathDraw = new Path();
        pathDraw.moveTo(px[0], py[0]);
        for (int i = 4; i < px.length; i += 4) pathDraw.lineTo(px[i], py[i]);
        pathDraw.lineTo(px[px.length - 1], py[py.length - 1]);
    }

    float pX(float s) { int i = (int) Math.max(0, Math.min(pathLen, s)); return px[i]; }
    float pY(float s) { int i = (int) Math.max(0, Math.min(pathLen, s)); return py[i]; }

    // =========================================================================================
    //                                        NIVELES
    // =========================================================================================
    void startLevel(int lv) {
        level = lv;
        buildPath(lv);
        chain.clear();
        parts.clear();
        int k = Math.min(lv, LEVELS);
        colors = Math.min(6, 3 + (k + 4) / 10 + (lv > LEVELS ? 1 : 0));
        toSpawn = 34 + k * 2 + (lv > LEVELS ? (lv - LEVELS) * 3 : 0);
        speed = 20 + k * 0.45f + (lv > LEVELS ? (lv - LEVELS) * 0.8f : 0);
        speed *= Math.max(0.72f, Math.min(1f, pathLen / 1850f));      // caminos cortos, cadena más lenta
        rush = 2.4f;
        slowT = backT = aimT = 0;
        flying = false;
        sucking = false;
        combo = 0;
        cur = randColor();
        next = randColor();
        st = S_INTRO;
        stT = 0;
        chip.sfx(Chip.SFX_LEVEL);
    }

    int randColor() {
        // solo colores que siguen en la cadena (o cualquiera si aún no hay)
        boolean[] has = new boolean[colors];
        int n = 0;
        for (Orb o : chain) if (o.c < colors && !has[o.c]) { has[o.c] = true; n++; }
        if (n == 0) return rnd.nextInt(colors);
        int pick = rnd.nextInt(n);
        for (int i = 0; i < colors; i++) if (has[i] && pick-- == 0) return i;
        return 0;
    }

    void spawn() {
        while (toSpawn > 0 && (chain.isEmpty() || chain.get(chain.size() - 1).s >= D)) {
            Orb o = new Orb();
            Orb last = chain.isEmpty() ? null : chain.get(chain.size() - 1);
            // evita series largas del mismo color al nacer
            int c = rnd.nextInt(colors);
            if (last != null && rnd.nextFloat() < 0.45f) c = last.c;
            if (chain.size() >= 2 && chain.get(chain.size() - 1).c == c && chain.get(chain.size() - 2).c == c) c = (c + 1 + rnd.nextInt(colors - 1)) % colors;
            o.c = c;
            o.s = last == null ? 0 : last.s - D;
            o.ds = o.s;
            if (rnd.nextFloat() < 0.035f + level * 0.0004f) o.power = 1 + rnd.nextInt(4);
            chain.add(o);
            toSpawn--;
        }
    }

    // =========================================================================================
    //                                      ACTUALIZAR
    // =========================================================================================
    @Override void update(float dt) {
        t += dt;
        stT += dt;
        for (int i = parts.size() - 1; i >= 0; i--) {
            Part p = parts.get(i);
            p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 300 * dt; p.life -= dt;
            if (p.life <= 0) parts.remove(i);
        }
        for (int i = pops.size() - 1; i >= 0; i--) { Pop p = pops.get(i); p.y -= 30 * dt; p.life -= dt; if (p.life <= 0) pops.remove(i); }
        if (st == S_INTRO && stT > 1.6f) { st = S_PLAY; stT = 0; }
        if (st != S_PLAY) return;
        if (gp.enabled && gp.pressed(GameKit.G_START)) { onBack(); return; }

        // ---- tótem: apuntar con mando ----
        if (gp.enabled) {
            if (gp.down(GameKit.G_LEFT)) ang -= 2.6f * dt;
            if (gp.down(GameKit.G_RIGHT)) ang += 2.6f * dt;
            if (gp.pressed(GameKit.G_A)) shoot();
            if (gp.pressed(GameKit.G_B) || gp.pressed(GameKit.G_X)) swap();
        }

        // ---- la cadena avanza (solo el tramo de atrás empuja) ----
        if (sucking) {
            for (Orb o : chain) o.s += 420 * dt;
            for (int i = chain.size() - 1; i >= 0; i--) if (chain.get(i).s > pathLen + D) chain.remove(i);
            for (Orb o : chain) o.ds = o.s;
            if (chain.isEmpty() || stT > 3f) {
                lives--;
                chip.sfx(Chip.SFX_HURT);
                st = lives > 0 ? S_LOST : S_OVER;
                stT = 0;
                if (st == S_OVER) saveBest();
            }
            return;
        }
        float v = speed;
        if (rush > 0) { rush -= dt; v = 170; }
        if (slowT > 0) { slowT -= dt; v *= 0.35f; }
        if (backT > 0) { backT -= dt; v = -55; }
        if (aimT > 0) aimT -= dt;
        // cerca del final, más despacio (como un respiro)
        if (!chain.isEmpty() && chain.get(0).s > pathLen * 0.85f && v > 0) v *= 0.6f;
        if (!chain.isEmpty()) {
            Orb tail = chain.get(chain.size() - 1);
            if (!(v < 0 && tail.s < -D * 2)) tail.s += v * dt;
            if (v < 0) {   // al retroceder, todo el tramo de atrás va junto
                for (int i = chain.size() - 2; i >= 0; i--) {
                    if (chain.get(i).s - chain.get(i + 1).s <= D * 1.08f + 2) chain.get(i).s = chain.get(i + 1).s + D; else break;
                }
            }
            for (int i = chain.size() - 2; i >= 0; i--) {         // empujar hacia delante
                Orb a = chain.get(i), b = chain.get(i + 1);
                if (a.s < b.s + D) a.s = b.s + D;
            }
        }
        spawn();
        // tramos separados que se atraen si los extremos son del mismo color
        for (int i = 0; i < chain.size() - 1; i++) {
            Orb a = chain.get(i), b = chain.get(i + 1);
            float gap = a.s - b.s;
            if (gap > D + 0.5f && a.c == b.c) {
                int start = i;
                while (start > 0 && chain.get(start - 1).s - chain.get(start).s <= D + 0.6f) start--;
                float mv = Math.min(gap - D, 260 * dt);
                for (int j = start; j <= i; j++) chain.get(j).s -= mv;
                if (a.s - b.s <= D + 0.5f) {
                    for (int j = i; j >= start; j--) chain.get(j).s = chain.get(j + 1).s + D;
                    combo++;
                    if (!match(i)) combo = 0;
                    break;
                }
            }
        }
        for (Orb o : chain) o.ds += (o.s - o.ds) * Math.min(1f, dt * 16);

        // ---- proyectil ----
        if (flying) {
            float steps = 4;
            for (int k = 0; k < steps && flying; k++) {
                fx += fvx * dt / steps; fy += fvy * dt / steps;
                if (fx < -20 || fx > vw + 20 || fy < -20 || fy > vh + 20) { flying = false; break; }
                for (int i = 0; i < chain.size(); i++) {
                    Orb o = chain.get(i);
                    if (o.s < 0) continue;
                    float dx = fx - pX(o.ds), dy = fy - pY(o.ds);
                    if (dx * dx + dy * dy < (D * 0.92f) * (D * 0.92f)) { insert(i); flying = false; break; }
                }
            }
        }

        // ---- peligro y derrota ----
        if (!chain.isEmpty()) {
            float front = chain.get(0).s;
            if (front > pathLen * 0.82f) {
                dangerBeat -= dt;
                if (dangerBeat <= 0) { chip.sfx(Chip.SFX_DUCK); dangerBeat = 0.25f + (pathLen - front) / pathLen * 3; }
            }
            if (front >= pathLen) { sucking = true; stT = 0; flying = false; chip.sfx(Chip.SFX_BOOM); }
        } else if (toSpawn == 0 && !flying) {
            // ¡nivel superado!
            int bonus = 500 + level * 50;
            score += bonus;
            pops.add(pop(vw / 2, vh / 2, "+" + bonus, Color.WHITE));
            chip.sfx(Chip.SFX_LEVEL);
            st = S_CLEAR;
            stT = 0;
            if (level + 1 > bestLevel) { bestLevel = level + 1; prefs().edit().putInt("orbe_level", Math.min(bestLevel, LEVELS + 1)).apply(); }
            saveBest();
        }
        // el orbe del tótem siempre de un color que aún existe
        if (!chain.isEmpty()) {
            boolean okC = false, okN = false;
            for (Orb o : chain) { if (o.c == cur) okC = true; if (o.c == next) okN = true; }
            if (!okC && !flying) cur = randColor();
            if (!okN) next = randColor();
        }
    }

    void saveBest() {
        if (score > prefs().getInt("best_orbe", 0)) prefs().edit().putInt("best_orbe", score).apply();
    }

    void shoot() {
        if (flying || st != S_PLAY || sucking) return;
        flying = true;
        fc = cur;
        fx = sx + (float) Math.cos(ang) * 26;
        fy = sy + (float) Math.sin(ang) * 26;
        fvx = (float) Math.cos(ang) * 720;
        fvy = (float) Math.sin(ang) * 720;
        cur = next;
        next = randColor();
        chip.sfx(Chip.SFX_SHOOT);
    }

    void swap() { int k = cur; cur = next; next = k; chip.sfx(Chip.SFX_JUMP); }

    /** Mete el orbe disparado en la cadena junto al orbe i. */
    void insert(int i) {
        Orb hit = chain.get(i);
        // ¿delante o detrás? según la dirección del camino en ese punto
        int a = (int) Math.max(0, Math.min(pathLen - 1, hit.ds));
        float tx = px[Math.min(px.length - 1, a + 1)] - px[a], ty = py[Math.min(py.length - 1, a + 1)] - py[a];
        boolean front = (fx - pX(hit.ds)) * tx + (fy - pY(hit.ds)) * ty > 0;
        Orb o = new Orb();
        o.c = fc;
        int idx;
        if (front) { idx = i; o.s = hit.s + D; }
        else { idx = i + 1; o.s = hit.s; hit.s += D; }
        o.ds = o.s;
        // que aparezca donde chocó y se deslice a su sitio
        float best = o.s, bd = Float.MAX_VALUE;
        for (float s = o.s - D; s <= o.s + D; s += 2) { float dx = pX(s) - fx, dy = pY(s) - fy; float d2 = dx * dx + dy * dy; if (d2 < bd) { bd = d2; best = s; } }
        o.ds = best;
        chain.add(idx, o);
        int from = front ? idx - 1 : i - 1;
        for (int j = from; j >= 0; j--) {
            Orb x = chain.get(j), y = chain.get(j + 1);
            if (x.s < y.s + D) x.s = y.s + D; else break;
        }
        chip.sfx(Chip.SFX_HIT);
        combo = 0;
        match(idx);
    }

    /** Si el orbe idx forma un grupo de 3 o más del mismo color (pegados), lo rompe. */
    boolean match(int idx) {
        if (idx < 0 || idx >= chain.size()) return false;
        int c = chain.get(idx).c;
        int a = idx, b = idx;
        while (a > 0 && chain.get(a - 1).c == c && chain.get(a - 1).s - chain.get(a).s <= D + 1.5f) a--;
        while (b < chain.size() - 1 && chain.get(b + 1).c == c && chain.get(b).s - chain.get(b + 1).s <= D + 1.5f) b++;
        int n = b - a + 1;
        if (n < 3) return false;
        int mult = Math.max(1, combo + 1);
        int pts = n * 10 * mult + (n > 3 ? (n - 3) * 20 : 0);
        score += pts;
        float mx = pX(chain.get((a + b) / 2).ds), my = pY(chain.get((a + b) / 2).ds);
        pops.add(pop(mx, my - 14, "+" + pts + (mult > 1 ? "  ×" + mult : ""), ORB[c]));
        if (mult > 1) pops.add(pop(mx, my - 34, L.t("¡COMBO!"), Color.WHITE));
        for (int k = a; k <= b; k++) {
            Orb o = chain.get(k);
            burst(pX(o.ds), pY(o.ds), ORB[o.c], 8);
            if (o.power != 0) power(o.power, o);
        }
        boolean bomb = false;
        float bombS = 0;
        for (int k = a; k <= b; k++) if (chain.get(k).power == 3) { bomb = true; bombS = chain.get(k).s; }
        for (int k = b; k >= a; k--) chain.remove(k);
        if (bomb) {
            for (int k = chain.size() - 1; k >= 0; k--) {
                Orb o = chain.get(k);
                if (Math.abs(o.s - bombS) < D * 3.5f) { burst(pX(o.ds), pY(o.ds), ORB[o.c], 5); chain.remove(k); score += 10; }
            }
        }
        chip.sfx(mult > 1 ? Chip.SFX_POWER : Chip.SFX_COIN);
        return true;
    }

    void power(int pw, Orb o) {
        String[] names = {"", "⏪ ¡ATRÁS!", "🐢 ¡LENTO!", "💥 ¡BOMBA!", "🎯 ¡PUNTERÍA!"};
        pops.add(pop(pX(o.ds), pY(o.ds) - 40, L.t(names[pw]), Color.WHITE));
        if (pw == 1) backT = 2.2f;
        if (pw == 2) slowT = 6f;
        if (pw == 4) aimT = 10f;
        chip.sfx(Chip.SFX_POWER);
    }

    Pop pop(float x, float y, String s, int c) { Pop p = new Pop(); p.x = x; p.y = y; p.s = s; p.c = c; p.life = 1.1f; return p; }

    void burst(float x, float y, int c, int n) {
        for (int i = 0; i < n; i++) {
            Part p = new Part();
            float a = rnd.nextFloat() * 6.28f, sp = 60 + rnd.nextFloat() * 140;
            p.x = x; p.y = y; p.vx = (float) Math.cos(a) * sp; p.vy = (float) Math.sin(a) * sp - 60; p.life = 0.5f + rnd.nextFloat() * 0.4f; p.c = c;
            parts.add(p);
        }
    }

    // =========================================================================================
    //                                         DIBUJO
    // =========================================================================================
    @Override void render(Canvas c) {
        drawBackground(c);
        if (st == S_TITLE) { drawTitle(c); return; }
        if (st == S_WORLD) { drawWorlds(c); return; }
        drawPath(c);
        // cadena
        for (int i = chain.size() - 1; i >= 0; i--) {
            Orb o = chain.get(i);
            if (o.ds < -R) continue;
            drawOrb(c, pX(o.ds), pY(o.ds), R, o.c, o.power);
        }
        if (flying) drawOrb(c, fx, fy, R, fc, 0);
        drawTotem(c);
        for (Part p : parts) { this.p.setColor(p.c); this.p.setAlpha((int) (255 * Math.min(1, p.life * 2))); c.drawCircle(p.x, p.y, 3, this.p); }
        this.p.setAlpha(255);
        for (Pop p : pops) { txt.setAlpha((int) (255 * Math.min(1, p.life * 1.5f))); text(c, p.s, p.x, p.y, 15, p.c); }
        txt.setAlpha(255);
        drawHud(c);
        if (st == S_INTRO) {
            box(c, new RectF(40, vh / 2 - 60, vw - 40, vh / 2 + 50), WORLD_BG[world()][2], 220);
            text(c, level > LEVELS ? L.t("INFINITO") + " · " + (level - LEVELS) : L.t(WORLDS[world()]), vw / 2, vh / 2 - 22, 16, WORLD_BG[world()][2]);
            text(c, L.t("NIVEL") + " " + level, vw / 2, vh / 2 + 14, 30, Color.WHITE);
        }
        if (st == S_PAUSE) drawPause(c);
        if (st == S_CLEAR) drawClear(c);
        if (st == S_LOST) drawLost(c);
        if (st == S_OVER) drawOver(c);
    }

    void drawBackground(Canvas c) {
        int w = world();
        p.setShader(new LinearGradient(0, 0, 0, vh, WORLD_BG[w][0], WORLD_BG[w][1], Shader.TileMode.CLAMP));
        c.drawRect(0, 0, vw, vh, p);
        p.setShader(null);
        // baldosas con glifos tenues
        p.setColor(Color.argb(18, 255, 255, 255));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f);
        for (float y = 40; y < vh; y += 60) for (float x = (y / 60 % 2 == 0 ? 0 : 30); x < vw; x += 60) {
            c.drawRect(x + 6, y + 6, x + 54, y + 54, p);
            int g = (int) (x * 7 + y * 3) % 4;
            if (g == 0) c.drawCircle(x + 30, y + 30, 10, p);
            else if (g == 1) { c.drawLine(x + 20, y + 30, x + 40, y + 30, p); c.drawLine(x + 30, y + 20, x + 30, y + 40, p); }
            else if (g == 2) c.drawRect(x + 22, y + 22, x + 38, y + 38, p);
            else { c.drawLine(x + 20, y + 40, x + 30, y + 20, p); c.drawLine(x + 30, y + 20, x + 40, y + 40, p); }
        }
        p.setStyle(Paint.Style.FILL);
    }

    void drawPath(Canvas c) {
        if (pathDraw == null) return;
        int glow = WORLD_BG[world()][2];
        line.setShader(null);
        line.setStrokeWidth(D + 12);
        line.setColor(Color.argb(150, 0, 0, 0));
        c.drawPath(pathDraw, line);
        line.setStrokeWidth(D + 6);
        line.setColor(Color.argb(60, Color.red(glow), Color.green(glow), Color.blue(glow)));
        c.drawPath(pathDraw, line);
        line.setStrokeWidth(D);
        line.setColor(Color.argb(255, 22, 20, 30));
        c.drawPath(pathDraw, line);
        // vórtice al final
        float ex = px[px.length - 1], ey = py[py.length - 1];
        for (int i = 0; i < 4; i++) {
            float a = t * 3 + i * 1.57f;
            p.setColor(Color.argb(140 - i * 25, Color.red(glow), Color.green(glow), Color.blue(glow)));
            c.drawCircle(ex + (float) Math.cos(a) * 4, ey + (float) Math.sin(a) * 4, 20 - i * 4, p);
        }
        p.setColor(Color.BLACK);
        c.drawCircle(ex, ey, 9, p);
        // peligro: el final brilla en rojo
        if (!chain.isEmpty() && chain.get(0).s > pathLen * 0.82f) {
            p.setColor(Color.argb((int) (90 + 80 * Math.sin(t * 12)), 255, 40, 40));
            c.drawCircle(ex, ey, 26, p);
        }
    }

    void drawOrb(Canvas c, float x, float y, float r, int col, int power) {
        int base = ORB[col];
        orbP.setShader(new RadialGradient(x - r * 0.35f, y - r * 0.4f, r * 1.4f,
                new int[]{Color.WHITE, base, darker(base)}, new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, orbP);
        orbP.setShader(null);
        // símbolo para distinguir colores sin depender del color
        p.setColor(Color.argb(150, 255, 255, 255));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.6f);
        float k = r * 0.38f;
        switch (col) {
            case 0: c.drawCircle(x, y, k, p); break;
            case 1: c.drawRect(x - k, y - k, x + k, y + k, p); break;
            case 2: { Path tr = new Path(); tr.moveTo(x, y - k); tr.lineTo(x + k, y + k); tr.lineTo(x - k, y + k); tr.close(); c.drawPath(tr, p); break; }
            case 3: c.drawLine(x - k, y, x + k, y, p); c.drawLine(x, y - k, x, y + k, p); break;
            case 4: { Path dm = new Path(); dm.moveTo(x, y - k); dm.lineTo(x + k, y); dm.lineTo(x, y + k); dm.lineTo(x - k, y); dm.close(); c.drawPath(dm, p); break; }
            default: c.drawLine(x - k, y - k, x + k, y + k, p); c.drawLine(x - k, y + k, x + k, y - k, p); break;
        }
        p.setStyle(Paint.Style.FILL);
        if (power != 0) {
            String[] ic = {"", "⏪", "🐢", "💥", "🎯"};
            p.setColor(Color.argb((int) (120 + 100 * Math.sin(t * 8)), 255, 255, 255));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2);
            c.drawCircle(x, y, r + 2, p);
            p.setStyle(Paint.Style.FILL);
            txt.setTextSize(11);
            c.drawText(ic[power], x, y + 4, txt);
        }
    }

    static int darker(int c) { return Color.rgb(Color.red(c) * 2 / 5, Color.green(c) * 2 / 5, Color.blue(c) * 2 / 5); }

    /** El Tótem de cristal: un disco de piedra con un ojo de cristal que gira hacia donde apuntas. */
    void drawTotem(Canvas c) {
        int glow = WORLD_BG[world()][2];
        // línea de puntería
        if (st == S_PLAY && (aiming || aimT > 0)) {
            p.setColor(aimT > 0 ? Color.argb(170, 255, 255, 255) : Color.argb(90, 255, 255, 255));
            float len = aimT > 0 ? 700 : 140;
            for (float d = 34; d < len; d += 12) c.drawCircle(sx + (float) Math.cos(ang) * d, sy + (float) Math.sin(ang) * d, 1.8f, p);
        }
        p.setColor(Color.argb(90, Color.red(glow), Color.green(glow), Color.blue(glow)));
        c.drawCircle(sx, sy, 34, p);
        p.setShader(new RadialGradient(sx - 8, sy - 10, 40, 0xFF8A8478, 0xFF2B2822, Shader.TileMode.CLAMP));
        c.drawCircle(sx, sy, 28, p);
        p.setShader(null);
        // marcas talladas
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2);
        p.setColor(Color.argb(160, 20, 18, 14));
        for (int i = 0; i < 8; i++) {
            float a = i * 0.785f + t * 0.2f;
            c.drawLine(sx + (float) Math.cos(a) * 20, sy + (float) Math.sin(a) * 20, sx + (float) Math.cos(a) * 26, sy + (float) Math.sin(a) * 26, p);
        }
        p.setStyle(Paint.Style.FILL);
        // el cañón (cristal) hacia donde apunta
        float bx = sx + (float) Math.cos(ang) * 22, by = sy + (float) Math.sin(ang) * 22;
        p.setColor(glow);
        c.drawCircle(bx, by, 7, p);
        // orbe actual en el centro y el siguiente pequeño detrás
        drawOrb(c, sx, sy, R, cur, 0);
        drawOrb(c, sx - (float) Math.cos(ang) * 22, sy - (float) Math.sin(ang) * 22, 6, next, 0);
    }

    void drawHud(Canvas c) {
        p.setColor(Color.argb(170, 0, 0, 0));
        c.drawRect(0, 0, vw, 40, p);
        textLeft(c, (level > LEVELS ? "∞" + (level - LEVELS) : L.t("NIV") + " " + level), 10, 26, 14, WORLD_BG[world()][2]);
        text(c, String.valueOf(score), vw / 2, 27, 18, Color.WHITE);
        StringBuilder h = new StringBuilder();
        for (int i = 0; i < lives; i++) h.append("♥");
        txt.setTextAlign(Paint.Align.RIGHT);
        txt.setTextSize(16);
        txt.setColor(0xFFFF4D5E);
        c.drawText(h.toString(), vw - 52, 27, txt);
        txt.setTextAlign(Paint.Align.CENTER);
        RectF pz = new RectF(vw - 44, 4, vw - 6, 36);
        if (st == S_PLAY && menuButton(c, pz, "II", Color.GRAY)) { st = S_PAUSE; stT = 0; tapped = false; }
        // barra de progreso (orbes que faltan por salir)
        int total = 34 + Math.min(level, LEVELS) * 2 + (level > LEVELS ? (level - LEVELS) * 3 : 0);
        float k = 1f - (float) (toSpawn + chain.size()) / Math.max(1, total + 1);
        p.setColor(Color.argb(80, 255, 255, 255));
        c.drawRect(10, 36, vw - 10, 39, p);
        p.setColor(WORLD_BG[world()][2]);
        c.drawRect(10, 36, 10 + (vw - 20) * Math.max(0, Math.min(1, k)), 39, p);
        if (slowT > 0 || backT > 0 || aimT > 0) text(c, (slowT > 0 ? "🐢 " : "") + (backT > 0 ? "⏪ " : "") + (aimT > 0 ? "🎯" : ""), vw / 2, 58, 13, Color.WHITE);
    }

    // ---------------- menús ----------------
    void drawTitle(Canvas c) {
        float y = vh * 0.2f;
        // orbes decorativos girando
        for (int i = 0; i < 12; i++) {
            float a = t * 0.6f + i * 0.5236f;
            drawOrb(c, vw / 2 + (float) Math.cos(a) * 120, y + 30 + (float) Math.sin(a) * 50, 10, i % 6, 0);
        }
        text(c, "ORBES", vw / 2, y + 22, 44, 0xFFFFC46B);
        text(c, L.t("DEL ECO"), vw / 2, y + 52, 20, Color.WHITE);
        float by = vh * 0.48f;
        String cont = L.t("▶ JUGAR · NIVEL") + " " + Math.min(bestLevel, LEVELS);
        if (menuButton(c, new RectF(50, by, vw - 50, by + 50), cont, 0xFF44E07A)) { lives = 3; score = 0; startLevel(Math.min(bestLevel, LEVELS)); }
        if (menuButton(c, new RectF(50, by + 62, vw - 50, by + 112), L.t("🗺 ELEGIR NIVEL"), 0xFF3DA5FF)) { st = S_WORLD; stT = 0; }
        if (bestLevel > LEVELS && menuButton(c, new RectF(50, by + 124, vw - 50, by + 174), L.t("∞ MODO INFINITO"), 0xFFB46BFF)) { lives = 3; score = 0; startLevel(LEVELS + 1); }
        text(c, L.t("🏆 Récord:") + " " + prefs().getInt("best_orbe", 0), vw / 2, vh - 120, 15, Color.WHITE);
        wrap(c, "Desliza para apuntar y suelta para disparar. Toca el Tótem para cambiar de orbe. Junta 3 o más del mismo color.",
                vw / 2, vh - 92, vw - 40, 12, Color.rgb(170, 180, 200), true);
    }

    void drawWorlds(Canvas c) {
        text(c, L.t("ELIGE NIVEL"), vw / 2, 50, 22, Color.WHITE);
        float y = 74;
        for (int w = 0; w < WORLDS.length; w++) {
            text(c, L.t(WORLDS[w]), vw / 2, y + 14, 13, WORLD_BG[w][2]);
            y += 22;
            for (int i = 0; i < PER_WORLD; i++) {
                int lv = w * PER_WORLD + i + 1;
                float x = 14 + i * 33.2f;
                RectF r = new RectF(x, y, x + 29, y + 29);
                boolean open = lv <= bestLevel;
                box(c, r, open ? WORLD_BG[w][2] : Color.DKGRAY, 200);
                text(c, open ? String.valueOf(lv) : "🔒", r.centerX(), r.centerY() + 5, 12, open ? Color.WHITE : Color.GRAY);
                if (open && tapIn(r)) { lives = 3; score = 0; startLevel(lv); return; }
            }
            y += 38;
        }
        if (menuButton(c, new RectF(80, vh - 70, vw - 80, vh - 24), L.t("← VOLVER"), Color.GRAY)) { st = S_TITLE; }
    }

    void drawPause(Canvas c) {
        p.setColor(Color.argb(170, 0, 0, 0));
        c.drawRect(0, 0, vw, vh, p);
        text(c, L.t("PAUSA"), vw / 2, vh * 0.32f, 30, Color.WHITE);
        float y = vh * 0.4f;
        if (menuButton(c, new RectF(60, y, vw - 60, y + 48), L.t("▶ SEGUIR"), 0xFF44E07A)) st = S_PLAY;
        if (menuButton(c, new RectF(60, y + 60, vw - 60, y + 108), L.t("↻ REPETIR NIVEL"), 0xFFFFD84A)) startLevel(level);
        if (menuButton(c, new RectF(60, y + 120, vw - 60, y + 168), L.t("☰ MENÚ"), Color.GRAY)) { saveBest(); st = S_TITLE; }
    }

    void drawClear(Canvas c) {
        p.setColor(Color.argb(150, 0, 0, 0));
        c.drawRect(0, 0, vw, vh, p);
        text(c, L.t("¡NIVEL SUPERADO!"), vw / 2, vh * 0.36f, 26, 0xFF44E07A);
        text(c, L.t("Puntos:") + " " + score, vw / 2, vh * 0.43f, 18, Color.WHITE);
        if (level % PER_WORLD == 0 && level <= LEVELS)
            text(c, level == LEVELS ? L.t("¡Has completado los 6 templos! Modo infinito desbloqueado.") : L.t("¡Templo completado!"), vw / 2, vh * 0.49f, 13, 0xFFFFC46B);
        if (stT > 0.6f && menuButton(c, new RectF(60, vh * 0.56f, vw - 60, vh * 0.56f + 50), L.t("▶ SIGUIENTE"), 0xFF44E07A)) startLevel(level + 1);
    }

    void drawLost(Canvas c) {
        p.setColor(Color.argb(150, 0, 0, 0));
        c.drawRect(0, 0, vw, vh, p);
        text(c, L.t("¡El vórtice se los tragó!"), vw / 2, vh * 0.38f, 20, 0xFFFF4D5E);
        text(c, L.t("Vidas:") + " " + lives, vw / 2, vh * 0.45f, 18, Color.WHITE);
        if (stT > 0.6f && menuButton(c, new RectF(60, vh * 0.52f, vw - 60, vh * 0.52f + 50), L.t("↻ OTRA VEZ"), 0xFFFFD84A)) startLevel(level);
    }

    void drawOver(Canvas c) {
        p.setColor(Color.argb(180, 0, 0, 0));
        c.drawRect(0, 0, vw, vh, p);
        text(c, L.t("FIN DE LA PARTIDA"), vw / 2, vh * 0.34f, 26, 0xFFFF4D5E);
        text(c, L.t("Puntos:") + " " + score, vw / 2, vh * 0.41f, 18, Color.WHITE);
        text(c, L.t("🏆 Récord:") + " " + prefs().getInt("best_orbe", 0), vw / 2, vh * 0.46f, 15, Color.WHITE);
        if (stT > 0.8f) {
            if (menuButton(c, new RectF(60, vh * 0.52f, vw - 60, vh * 0.52f + 48), L.t("↻ REINTENTAR NIVEL") + " " + level, 0xFFFFD84A)) { lives = 3; score = 0; startLevel(level); }
            if (menuButton(c, new RectF(60, vh * 0.52f + 60, vw - 60, vh * 0.52f + 108), L.t("☰ MENÚ"), Color.GRAY)) st = S_TITLE;
        }
    }

    // ---------------- toques: deslizar para apuntar, soltar para disparar ----------------
    @Override
    public boolean onTouchEvent(android.view.MotionEvent e) {
        super.onTouchEvent(e);
        if (st != S_PLAY) return true;
        float x = e.getX() / scale, y = e.getY() / scale;
        int a = e.getActionMasked();
        if (a == android.view.MotionEvent.ACTION_DOWN) {
            if (y < 42) return true;                                   // barra de arriba (pausa)
            if (Math.hypot(x - sx, y - sy) < 34) { swap(); aiming = false; return true; }
            aiming = true;
        }
        if (aiming && (a == android.view.MotionEvent.ACTION_DOWN || a == android.view.MotionEvent.ACTION_MOVE)) {
            aimX = x; aimY = y;
            ang = (float) Math.atan2(y - sy, x - sx);
        }
        if (aiming && a == android.view.MotionEvent.ACTION_UP) { aiming = false; shoot(); }
        if (a == android.view.MotionEvent.ACTION_CANCEL) aiming = false;
        return true;
    }
}
