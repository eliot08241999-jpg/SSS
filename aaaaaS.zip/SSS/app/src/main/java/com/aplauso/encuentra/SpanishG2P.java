package com.aplauso.encuentra;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * v1.5 · De texto español a fonemas (alfabeto fonético, como los que espera la voz Kokoro).
 * El español se escribe casi como se pronuncia, así que bastan reglas: acentos, diptongos,
 * b/v → b o β, d → d o ð, g → ɡ o ɣ, ll/y → ʝ, c/z → s (seseo), j → x, r/rr, ñ, ch, qu/gu, h muda…
 * También dice los números («23» → «veintitrés»).
 */
public class SpanishG2P {
    static final String STRONG = "aeoáéó", VOWELS = "aeiouáéíóúü";
    static final java.util.Set<String> UNSTRESSED = new java.util.HashSet<>(java.util.Arrays.asList(
            "el", "la", "los", "las", "lo", "un", "una", "unos", "unas", "de", "del", "a", "al", "en", "y", "e", "o", "u", "que", "me", "te",
            "se", "le", "les", "nos", "os", "mi", "mis", "tu", "tus", "su", "sus", "con", "por", "para", "sin", "si", "ni", "pero", "como",
            "cuando", "donde", "porque", "mas"));

    /** Frase entera → fonemas (con espacios y la puntuación que entiende la voz). */
    public static String phonemize(String text) {
        String t = numbers(text.toLowerCase(Locale.ROOT))
                .replace("¿", "").replace("¡", "").replace("«", "\"").replace("»", "\"")
                .replace("...", "…").replace('–', '—').replaceAll("[\\-_/]+", " ");
        StringBuilder out = new StringBuilder();
        StringBuilder word = new StringBuilder();
        for (int i = 0; i <= t.length(); i++) {
            char c = i < t.length() ? t.charAt(i) : ' ';
            if (Character.isLetter(c)) { word.append(c); continue; }
            if (word.length() > 0) {
                char prev = out.length() == 0 ? ' ' : out.charAt(out.length() - 1);
                out.append(word(word.toString(), prev));
                word.setLength(0);
            }
            if (",.!?;:…\"()—".indexOf(c) >= 0) {
                while (out.length() > 0 && out.charAt(out.length() - 1) == ' ') out.setLength(out.length() - 1);
                out.append(c);
            } else if (Character.isWhitespace(c) || c == '\'') {
                if (out.length() > 0 && out.charAt(out.length() - 1) != ' ') out.append(' ');
            }
        }
        return out.toString().trim().replaceAll(" +", " ");
    }

    /** Palabras que no se leen como se escriben (nombres, marcas). */
    static final java.util.Map<String, String> LEX = new java.util.HashMap<>();
    static {
        String[][] l = {{"chloe", "klˈoe"}, {"cloe", "klˈoe"}, {"eliot", "ˈeljot"}, {"youtube", "ʝutˈuβ"}, {"whatsapp", "wˈatsap"}, {"spotify", "espˈotifaj"},
                {"google", "ɡˈuɣel"}, {"wifi", "wˈifi"}, {"bluetooth", "blˈutus"}, {"ok", "okˈej"}, {"sss", "ˈese ˈese ˈese"}, {"blorp", "blˈoɾp"},
                {"vidtube", "bitˈuβ"}, {"instagram", "ˈinstaɣɾam"}, {"tiktok", "tiktˈok"}, {"email", "imˈejl"}, {"app", "ˈap"}, {"apps", "ˈaps"},
                {"homecareosa", "xomkeɾˈosa"}, {"chatgpt", "ʧat ʝe pe tˈe"}, {"gemini", "ʝˈemini"}, {"claude", "klˈod"}, {"vale", "bˈale"}};
        for (String[] x : l) LEX.put(x[0], x[1]);
    }

    /** Una palabra → fonemas. «prevEnd» = último sonido de la palabra anterior (para b/d/g suaves). */
    static String word(String w, char prevEnd) {
        if (w.isEmpty()) return "";
        String lx = LEX.get(w);
        if (lx != null) return lx;
        // 1) letras → unidades de sonido (todavía con la letra de la vocal para saber el acento)
        List<String> u = new ArrayList<>();
        int n = w.length();
        for (int i = 0; i < n; i++) {
            char c = w.charAt(i), nx = i + 1 < n ? w.charAt(i + 1) : 0, nx2 = i + 2 < n ? w.charAt(i + 2) : 0;
            switch (c) {
                case 'h': break;                                             // muda («ch» se trata en la c)
                case 'c':
                    if (nx == 'h') { u.add("ʧ"); i++; }
                    else if ("eiéí".indexOf(nx) >= 0) u.add("s");
                    else u.add("k");
                    break;
                case 'q': u.add("k"); if (nx == 'u' && "eiéí".indexOf(nx2) >= 0) i++; break;
                case 'g':
                    if ("eiéí".indexOf(nx) >= 0) u.add("x");
                    else { u.add("G"); if (nx == 'u' && "eiéí".indexOf(nx2) >= 0) i++; }
                    break;
                case 'j': u.add("x"); break;
                case 'z': u.add("s"); break;
                case 'v': case 'b': u.add("B"); break;
                case 'd': u.add("D"); break;
                case 'l': if (nx == 'l') { u.add("ʝ"); i++; } else u.add("l"); break;
                case 'r':
                    if (nx == 'r') { u.add("r"); i++; }
                    else if (i == 0 || (i > 0 && "lns".indexOf(w.charAt(i - 1)) >= 0)) u.add("r");
                    else u.add("ɾ");
                    break;
                case 'ñ': u.add("ɲ"); break;
                case 'x': u.add(i == 0 ? "s" : "ks"); break;
                case 'w': u.add("w"); break;
                case 'k': u.add("k"); break;
                case 'y':
                    if (i == n - 1 && i > 0) u.add("V:i");                     // «hoy», «muy»
                    else if (n == 1) u.add("V:i");                            // «y»
                    else u.add("ʝ");
                    break;
                default:
                    if (VOWELS.indexOf(c) >= 0) u.add("V:" + c);
                    else if ("fmnpstl".indexOf(c) >= 0) u.add(String.valueOf(c));
                    else if (Character.isLetter(c)) u.add(String.valueOf(Character.toLowerCase(c)));
            }
        }
        // 2) núcleos (diptongos) y acento
        List<int[]> nuclei = new ArrayList<>();                  // [inicio, fin] en u
        for (int i = 0; i < u.size(); i++) {
            if (!u.get(i).startsWith("V:")) continue;
            int s = i;
            while (i + 1 < u.size() && u.get(i + 1).startsWith("V:") && joins(u.get(i).charAt(2), u.get(i + 1).charAt(2))) i++;
            nuclei.add(new int[]{s, i});
        }
        int stressed = -1;
        for (int k = 0; k < nuclei.size(); k++)
            for (int i = nuclei.get(k)[0]; i <= nuclei.get(k)[1]; i++) if ("áéíóú".indexOf(u.get(i).charAt(2)) >= 0) stressed = k;
        boolean noStress = UNSTRESSED.contains(w);
        if (stressed < 0 && !nuclei.isEmpty() && !noStress) {
            char last = w.charAt(n - 1);
            boolean llana = VOWELS.indexOf(last) >= 0 || last == 'n' || last == 's';
            stressed = nuclei.size() == 1 ? 0 : llana ? nuclei.size() - 2 : nuclei.size() - 1;
        }
        // 3) fonemas
        StringBuilder o = new StringBuilder();
        char prev = prevEnd;
        for (int i = 0; i < u.size(); i++) {
            String x = u.get(i);
            int nk = -1;
            for (int k = 0; k < nuclei.size(); k++) if (i >= nuclei.get(k)[0] && i <= nuclei.get(k)[1]) nk = k;
            if (x.startsWith("V:")) {
                int[] nu = nuclei.get(nk);
                char v = plain(x.charAt(2));
                boolean glide = nu[1] > nu[0] && (v == 'i' || v == 'u') && !isMain(u, nu, i);
                if (glide) { o.append(v == 'i' ? 'j' : 'w'); prev = v; continue; }
                if (nk == stressed && isMain(u, nu, i) && !noStress) o.append('ˈ');
                o.append(v);
                prev = v;
                continue;
            }
            boolean afterPause = prev == ' ' || prev == 0 || ",.!?;:…\"()—".indexOf(prev) >= 0;
            switch (x) {
                case "B": o.append(afterPause || prev == 'm' || prev == 'n' ? 'b' : 'β'); prev = 'b'; break;
                case "D": o.append(afterPause || prev == 'n' || prev == 'l' ? 'd' : 'ð'); prev = 'd'; break;
                case "G": o.append(afterPause || prev == 'n' || prev == 'ŋ' ? 'ɡ' : 'ɣ'); prev = 'g'; break;
                case "n": {
                    String next = i + 1 < u.size() ? u.get(i + 1) : "";
                    o.append(next.equals("k") || next.equals("G") || next.equals("x") ? "ŋ" : "n");
                    prev = 'n'; break;
                }
                default: o.append(x); prev = x.charAt(x.length() - 1);
            }
        }
        return o.toString();
    }

    static char plain(char v) {
        switch (v) { case 'á': return 'a'; case 'é': return 'e'; case 'í': return 'i'; case 'ó': return 'o'; case 'ú': case 'ü': return 'u'; default: return v; }
    }

    /** ¿Estas dos vocales van en la misma sílaba? (fuerte+fuerte no; las débiles con tilde rompen). */
    static boolean joins(char a, char b) {
        boolean sa = STRONG.indexOf(a) >= 0 || a == 'í' || a == 'ú', sb = STRONG.indexOf(b) >= 0 || b == 'í' || b == 'ú';
        if ((a == 'í' || a == 'ú') && STRONG.indexOf(b) >= 0) return false;      // «día», «río»
        if ((b == 'í' || b == 'ú') && STRONG.indexOf(a) >= 0) return false;      // «país», «baúl»
        return !(sa && sb);
    }

    /** La vocal que se oye más en el núcleo (la fuerte; si son dos débiles, la segunda). */
    static boolean isMain(List<String> u, int[] nu, int i) {
        if (nu[0] == nu[1]) return true;
        int main = nu[1];
        for (int k = nu[0]; k <= nu[1]; k++) { char v = u.get(k).charAt(2); if (STRONG.indexOf(v) >= 0 || v == 'í' || v == 'ú') { main = k; break; } }
        return i == main;
    }

    // ---------------- números ----------------
    static String numbers(String t) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)(?:[.,](\\d+))?").matcher(t);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String r;
            try {
                long v = Long.parseLong(m.group(1));
                r = v > 999_999_999L ? spellDigits(m.group(1)) : num(v);
                if (m.group(2) != null) r += " coma " + (m.group(2).length() > 3 ? spellDigits(m.group(2)) : num(Long.parseLong(m.group(2))));
            } catch (Exception e) { r = spellDigits(m.group()); }
            m.appendReplacement(sb, " " + r + " ");
        }
        m.appendTail(sb);
        return sb.toString().replace("%", " por ciento ").replace("€", " euros ").replace("$", " dólares ");
    }

    static String spellDigits(String d) {
        StringBuilder b = new StringBuilder();
        for (char c : d.toCharArray()) if (Character.isDigit(c)) b.append(num(c - '0')).append(' ');
        return b.toString().trim();
    }

    static final String[] U = {"cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce", "trece",
            "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve", "veinte", "veintiuno", "veintidós", "veintitrés",
            "veinticuatro", "veinticinco", "veintiséis", "veintisiete", "veintiocho", "veintinueve"};
    static final String[] T = {"", "", "", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa"};
    static final String[] H = {"", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos"};

    static String num(long v) {
        if (v < 30) return U[(int) v];
        if (v < 100) return T[(int) (v / 10)] + (v % 10 == 0 ? "" : " y " + U[(int) (v % 10)]);
        if (v == 100) return "cien";
        if (v < 1000) return H[(int) (v / 100)] + (v % 100 == 0 ? "" : " " + num(v % 100));
        if (v < 1_000_000) {
            long k = v / 1000, r = v % 1000;
            return (k == 1 ? "mil" : num(k).replaceAll("uno$", "un") + " mil") + (r == 0 ? "" : " " + num(r));
        }
        long mm = v / 1_000_000, r = v % 1_000_000;
        return (mm == 1 ? "un millón" : num(mm).replaceAll("uno$", "un") + " millones") + (r == 0 ? "" : " " + num(r));
    }
}
