package com.aplauso.encuentra;

/**
 * v1.5 · Reparte un documento con diseño (Rich) en páginas. No sabe dibujar: eso lo hace un «Engine»
 * (en el teléfono, Android; en las pruebas, Java del ordenador). Java puro.
 */
public class RichLayout {
    public interface Para {
        int lines();
        float top(int i);
        float bottom(int i);
        /** Dibuja las líneas [from, to] con la parte de arriba de la línea «from» en y. */
        void draw(int from, int to, float x, float y);
    }

    public interface Engine {
        Para layout(Rich r, Rich.Block b, float width);
        /** Tamaño en píxeles de la imagen (o null si no se puede leer). */
        int[] imageSize(String path);
        void beginPage(int n, float w, float h);
        void endPage(int n, boolean showNumber);
        void drawImage(String path, float x, float y, float w, float h);
    }

    public float pageW = 595, pageH = 842, mLeft = 56, mRight = 56, mTop = 56, mBottom = 62;

    Engine e;
    int page;
    /** Para cada página: el primer y el último bloque que tiene (para volver a traducir una página). */
    public final java.util.List<int[]> pages = new java.util.ArrayList<>();
    int curBlock;

    void mark() {
        while (pages.size() < page) pages.add(new int[]{curBlock, curBlock});
        int[] pg = pages.get(page - 1);
        if (pg[0] > curBlock) pg[0] = curBlock;
        if (pg[1] < curBlock) pg[1] = curBlock;
    }
    float y;
    boolean empty, onlyImage;

    float top() { return mTop; }
    float bottom() { return pageH - mBottom; }
    float width() { return pageW - mLeft - mRight; }

    void newPage() {
        if (page > 0) e.endPage(page, !onlyImage);
        page++;
        e.beginPage(page, pageW, pageH);
        y = top();
        empty = true;
        onlyImage = false;
    }

    /** Dibuja todo y devuelve cuántas páginas salieron. */
    public int render(Rich r, Engine eng) {
        e = eng;
        page = 0;
        pages.clear();
        newPage();
        float lineBase = r.basePt * 1.2f;
        for (int k = 0; k < r.blocks.size(); k++) {
            Rich.Block b = r.blocks.get(k);
            curBlock = k;
            if (b.kind == Rich.PAGE) { if (!empty) newPage(); continue; }
            if (b.kind == Rich.IMAGE) { image(r, b); continue; }
            float left = b.left * r.basePt, right = b.right * r.basePt;
            float w = Math.max(width() * 0.3f, width() - left - right);
            Para p = e.layout(r, b, w);
            int n = p.lines();
            if (n == 0) continue;
            float before = empty ? 0 : b.before * r.basePt, after = b.after * r.basePt;
            float h1 = p.bottom(0) - p.top(0);
            // un título no se queda solo al final de la página: con él tiene que caber algo de lo que sigue
            float need = before + h1;
            if (b.keepNext && k + 1 < r.blocks.size() && r.blocks.get(k + 1).kind == Rich.TEXT) need = before + (p.bottom(n - 1) - p.top(0)) + after + lineBase * 2.5f;
            else if (n >= 2 && !b.emptyLine) need = before + (p.bottom(1) - p.top(0));       // nunca una sola línea de un párrafo abajo
            if (!empty && y + need > bottom()) { newPage(); before = 0; }
            y += before;
            if (b.emptyLine && empty) continue;                                                  // las líneas en blanco no empiezan página
            int i = 0;
            while (i < n) {
                // cuántas líneas caben aquí
                float t0 = p.top(i);
                int j = i;
                while (j + 1 < n && y + (p.bottom(j + 1) - t0) <= bottom()) j++;
                if (y + (p.bottom(j) - t0) > bottom() && !empty) { newPage(); continue; }
                // que no se quede una sola línea en la página siguiente (si se puede)
                if (j + 1 == n - 1 && j > i + 1) j--;
                p.draw(i, j, mLeft + left, y);
                mark();
                y += p.bottom(j) - t0;
                empty = false;
                i = j + 1;
                if (i < n) newPage();
            }
            y += after;
        }
        e.endPage(page, !onlyImage);
        while (pages.size() < page) pages.add(new int[]{curBlock, curBlock});
        return page;
    }

    void image(Rich r, Rich.Block b) {
        int[] sz = e.imageSize(b.image);
        if (sz == null || sz[0] <= 0 || sz[1] <= 0) return;
        float ar = sz[1] / (float) sz[0];
        float w;
        if (b.imgW < 0) w = width() * -b.imgW / 100f;
        else if (b.imgW > 0) w = b.imgW * 0.75f;
        else if (b.imgH > 0) w = b.imgH * 0.75f / ar;
        else w = sz[0] * 0.75f;
        float maxH = bottom() - top();
        w = Math.min(w, width());
        float h = w * ar;
        if (h > maxH) { h = maxH; w = h / ar; }
        // casi una página entera (portadas, láminas): página propia, a todo lo que quepa
        boolean full = h > maxH * 0.7f;
        if (full) {
            if (!empty) newPage();
            w = width(); h = w * ar;
            if (h > maxH) { h = maxH; w = h / ar; }
            float x = mLeft + (width() - w) / 2, yy = top() + (maxH - h) / 2;
            e.drawImage(b.image, x, yy, w, h);
            mark();
            onlyImage = true;
            empty = false;
            y = bottom();
            return;
        }
        if (!empty && y + h > bottom()) newPage();
        float x = b.align == Rich.RIGHT ? mLeft + width() - w : b.align == Rich.LEFT ? mLeft : mLeft + (width() - w) / 2;
        y += empty ? 0 : r.basePt * 0.4f;
        e.drawImage(b.image, x, y, w, h);
        mark();
        y += h + r.basePt * 0.4f;
        empty = false;
    }
}
