package com.aplauso.encuentra;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Efectos de audio en Java puro sobre WAV de 16 bits:
 *  - Ecualizador de 5 bandas (60 Hz, 250 Hz, 1 kHz, 4 kHz, 12 kHz), ±12 dB.
 *  - Audio 8D: el sonido gira alrededor de la cabeza (paneo + retardo entre oídos + reverberación).
 */
public class AudioFx {
    static final float[] EQ_FREQS = {60, 250, 1000, 4000, 12000};
    static final String[] EQ_NAMES = {"Graves 60 Hz", "Bajos 250 Hz", "Medios 1 kHz", "Presencia 4 kHz", "Brillo 12 kHz"};

    static class Pcm {
        int rate, ch;
        float[][] s;     // [canal][muestra], de -1 a 1
        int frames() { return s[0].length; }
    }

    // ---------------- WAV ----------------
    static Pcm readWav(File f) throws IOException {
        byte[] all;
        try (FileInputStream in = new FileInputStream(f)) { all = DocIO.readAll(in); }
        ByteBuffer b = ByteBuffer.wrap(all).order(ByteOrder.LITTLE_ENDIAN);
        if (all.length < 44 || b.getInt(0) != 0x46464952) throw new IOException("No es WAV");
        int pos = 12, ch = 2, rate = 44100, bits = 16, dataPos = -1, dataLen = 0;
        while (pos + 8 <= all.length) {
            int id = b.getInt(pos), len = b.getInt(pos + 4);
            if (id == 0x20746d66) {          // "fmt "
                ch = b.getShort(pos + 10);
                rate = b.getInt(pos + 12);
                bits = b.getShort(pos + 22);
            } else if (id == 0x61746164) {   // "data"
                dataPos = pos + 8;
                dataLen = Math.min(len < 0 ? Integer.MAX_VALUE : len, all.length - dataPos);
                break;
            }
            pos += 8 + len + (len & 1);
        }
        if (dataPos < 0 || bits != 16 || ch < 1) throw new IOException("WAV no compatible");
        int frames = dataLen / (2 * ch);
        Pcm p = new Pcm();
        p.rate = rate;
        p.ch = ch;
        p.s = new float[ch][frames];
        for (int i = 0; i < frames; i++)
            for (int c = 0; c < ch; c++)
                p.s[c][i] = b.getShort(dataPos + (i * ch + c) * 2) / 32768f;
        return p;
    }

    static void writeWav(File f, Pcm p) throws IOException {
        int frames = p.frames(), ch = p.ch;
        long dataLen = (long) frames * ch * 2;
        // evitar saturación: normaliza si algún pico pasa de 1
        float peak = 0;
        for (float[] c : p.s) for (float v : c) peak = Math.max(peak, Math.abs(v));
        float g = peak > 0.98f ? 0.98f / peak : 1f;
        try (RandomAccessFile raf = new RandomAccessFile(f, "rw")) {
            raf.setLength(0);
            header(raf, p.rate, ch, dataLen);
            raf.seek(44);
            byte[] buf = new byte[8192];
            int bi = 0;
            for (int i = 0; i < frames; i++)
                for (int c = 0; c < ch; c++) {
                    int v = Math.round(p.s[c][i] * g * 32767);
                    if (v > 32767) v = 32767;
                    if (v < -32768) v = -32768;
                    buf[bi++] = (byte) (v & 0xff);
                    buf[bi++] = (byte) ((v >> 8) & 0xff);
                    if (bi == buf.length) { raf.write(buf); bi = 0; }
                }
            if (bi > 0) raf.write(buf, 0, bi);
        }
    }

    static void header(RandomAccessFile f, int rate, int ch, long dataLen) throws IOException {
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put(new byte[]{'R', 'I', 'F', 'F'});
        b.putInt((int) (36 + dataLen));
        b.put(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '});
        b.putInt(16);
        b.putShort((short) 1);
        b.putShort((short) ch);
        b.putInt(rate);
        b.putInt(rate * ch * 2);
        b.putShort((short) (ch * 2));
        b.putShort((short) 16);
        b.put(new byte[]{'d', 'a', 't', 'a'});
        b.putInt((int) dataLen);
        f.seek(0);
        f.write(b.array());
    }

    static Pcm toStereo(Pcm p) {
        if (p.ch == 2) return p;
        Pcm o = new Pcm();
        o.rate = p.rate;
        o.ch = 2;
        o.s = new float[][]{p.s[0].clone(), p.s[0].clone()};
        return o;
    }

    // ---------------- Ecualizador (filtros "peaking" RBJ) ----------------
    static void eq(Pcm p, float[] gainsDb) {
        for (int band = 0; band < EQ_FREQS.length; band++) {
            float gdb = gainsDb[band];
            if (Math.abs(gdb) < 0.1f) continue;
            double f0 = Math.min(EQ_FREQS[band], p.rate * 0.45);
            double A = Math.pow(10, gdb / 40.0), w0 = 2 * Math.PI * f0 / p.rate, q = band == 0 || band == 4 ? 0.7 : 1.0;
            double alpha = Math.sin(w0) / (2 * q), cos = Math.cos(w0);
            double b0 = 1 + alpha * A, b1 = -2 * cos, b2 = 1 - alpha * A, a0 = 1 + alpha / A, a1 = -2 * cos, a2 = 1 - alpha / A;
            b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;
            for (float[] x : p.s) {
                double x1 = 0, x2 = 0, y1 = 0, y2 = 0;
                for (int i = 0; i < x.length; i++) {
                    double in = x[i];
                    double y = b0 * in + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
                    x2 = x1; x1 = in; y2 = y1; y1 = y;
                    x[i] = (float) y;
                }
            }
        }
    }

    // ---------------- Audio 8D ----------------
    /**
     * @param period segundos que tarda el sonido en dar una vuelta completa
     * @param reverb cantidad de reverberación (0..1)
     */
    static Pcm eightD(Pcm in, float period, float reverb) {
        Pcm p = toStereo(in);
        int n = p.frames(), rate = p.rate;
        float[] mono = new float[n];
        for (int i = 0; i < n; i++) mono[i] = (p.s[0][i] + p.s[1][i]) * 0.5f;
        float[] L = new float[n], R = new float[n];
        int maxDelay = Math.max(1, Math.round(rate * 0.0006f));   // ~0,6 ms entre oídos
        for (int i = 0; i < n; i++) {
            double ang = 2 * Math.PI * i / (rate * period);
            float pan = (float) Math.sin(ang);                      // -1 izquierda … 1 derecha
            float front = (float) (0.85 + 0.15 * Math.cos(ang));    // detrás suena un poco más apagado
            double th = (pan + 1) * Math.PI / 4;
            float gl = (float) Math.cos(th) * front, gr = (float) Math.sin(th) * front;
            int dl = Math.round(Math.max(0, pan) * maxDelay), dr = Math.round(Math.max(0, -pan) * maxDelay);
            L[i] = gl * (i - dl >= 0 ? mono[i - dl] : 0) * 1.3f;
            R[i] = gr * (i - dr >= 0 ? mono[i - dr] : 0) * 1.3f;
        }
        if (reverb > 0.01f) {
            float[] wl = schroeder(L, rate, 0), wr = schroeder(R, rate, 23);
            for (int i = 0; i < n; i++) {
                L[i] = L[i] * (1 - reverb * 0.4f) + wl[i] * reverb * 0.6f;
                R[i] = R[i] * (1 - reverb * 0.4f) + wr[i] * reverb * 0.6f;
            }
        }
        p.s = new float[][]{L, R};
        return p;
    }

    /** Reverberación Schroeder: 4 filtros peine en paralelo + 2 pasa-todo. */
    static float[] schroeder(float[] x, int rate, int offset) {
        int n = x.length;
        float[] out = new float[n];
        int[] combMs = {29 + offset % 3, 37, 41, 44};
        float[] fb = {0.78f, 0.76f, 0.74f, 0.72f};
        for (int k = 0; k < 4; k++) {
            int d = Math.max(1, rate * (combMs[k] + offset / 10) / 1000);
            float[] buf = new float[d];
            int idx = 0;
            for (int i = 0; i < n; i++) {
                float y = buf[idx];
                buf[idx] = x[i] + y * fb[k];
                idx = (idx + 1) % d;
                out[i] += y * 0.25f;
            }
        }
        int[] apMs = {5, 2};
        for (int ms : apMs) {
            int d = Math.max(1, rate * ms / 1000);
            float[] buf = new float[d];
            int idx = 0;
            float g = 0.7f;
            for (int i = 0; i < n; i++) {
                float bv = buf[idx];
                float y = -g * out[i] + bv;
                buf[idx] = out[i] + g * y;
                idx = (idx + 1) % d;
                out[i] = y;
            }
        }
        return out;
    }

    /** Aplica los efectos elegidos a un WAV (lo sobrescribe). */
    static void apply(File wav, float[] eqDb, boolean eightD, float period, float reverb) throws IOException {
        boolean anyEq = false;
        for (float g : eqDb) if (Math.abs(g) >= 0.1f) anyEq = true;
        if (!anyEq && !eightD) return;
        Pcm p = readWav(wav);
        if (anyEq) eq(p, eqDb);
        if (eightD) p = eightD(p, period, reverb);
        writeWav(wav, p);
    }
}
