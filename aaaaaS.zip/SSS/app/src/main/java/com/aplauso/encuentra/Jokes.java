package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * v1.6 · LOS CHISTES DE CHLOE. Los cuenta TAL CUAL (el cerebro pequeño los destroza si los reescribe): los de serie y
 * los tuyos («Mis chistes», cada uno normal u oscuro). El humor negro: solo si lo pides o si está en «a veces»;
 * con «nunca» no sale. Si le pides que se INVENTE uno, el cerebro recibe la guía de humor y tus chistes como ejemplos.
 */
public class Jokes {
    static final Random rnd = new Random();

    // ---------------- de serie ----------------
    static final String[] ES = {
            "¿Qué le dice una iguana a su hermana gemela? Somos iguanitas.",
            "¿Por qué el libro de matemáticas está triste? Porque tiene demasiados problemas.",
            "—Doctor, doctor, tengo complejo de feo. —Hombre, de complejo nada.",
            "¿Qué hace una abeja en el gimnasio? ¡Zum-ba!",
            "Le dije a mi teléfono que necesitaba un descanso… y me puso el modo avión.",
            "¿Cómo se despiden los químicos? Ácido un placer.",
            "—Mamá, en el colegio me llaman despistado. —Niño, tú no vives aquí.",
            "¿Qué le dijo un techo a otro? Techo de menos.",
            "¿Cuál es el café más peligroso del mundo? El ex-preso.",
            "Van dos ciegos y le dice uno al otro: «Ojalá lloviera». Y el otro: «Ojalá yo también».",
            "¿Por qué los pájaros no usan Facebook? Porque ya tienen Twitter.",
            "—¿Cuál es tu plato favorito? —El hondo, que cabe más.",
            "¿Qué le dice un gusano a otro gusano? Voy a dar una vuelta a la manzana.",
            "—Camarero, este filete tiene muchos nervios. —Normal, es la primera vez que se lo comen.",
            "¿Qué hace un perro con un taladro? Taladrando.",
            "Mi jefe me dijo: «Ten un buen día». Así que me fui a casa.",
            "¿Por qué el tomate no toma té? Porque es tomate.",
            "—Papá, ¿qué se siente al tener un hijo tan guapo? —No sé, hijo, pregúntale a tu abuelo.",
            "¿Qué le dijo el 0 al 8? Bonito cinturón.",
            "Había un perro tan perezoso que en vez de ladrar, asentía.",
            "¿Cómo se llama el campeón de buceo japonés? Tokofondo. ¿Y el subcampeón? Kasitoko.",
            "—¿Sabes por qué el mar es salado? —Porque no le pusieron azúcar.",
            "¿Qué le dice una impresora a otra? ¿Esa hoja es tuya o es impresión mía?",
            "—Cariño, ¿tengo la nariz grande? —No… tienes una nariz común. —¿Común? —Sí, común-icada con el resto de la cara.",
    };
    static final String[] ES_DARK = {
            "¿Cómo se llama el campeón de escondite en un campo minado? Nadie lo sabe. Pero juega con ventaja.",
            "Mi abuelo murió en paz, durmiendo. No como los pasajeros de su autobús, que iban gritando.",
            "—Doctor, ¿cuánto me queda? —Diez. —¿Diez qué? ¿Años? ¿Meses? —Nueve, ocho, siete…",
            "¿Qué es lo mejor de tener noventa años? Que la presión de grupo es casi nula.",
            "El médico me dijo que me quedaban tres minutos de vida. Le pedí algo para el dolor y me puso un vídeo de dos minutos de anuncios.",
            "Mi tío dejó de fumar gracias a los parches. Se los pusieron en los ojos, antes de enterrarlo.",
            "¿Cuál es el colmo de un ciego? Enamorarse a primera vista.",
            "—Doctor, ¿es grave? —Digamos que yo de usted no empezaría ninguna serie de diez temporadas.",
            "Mi abuelo tenía el corazón de un león… y una orden de alejamiento del zoológico.",
            "Mi perro se escapó de casa. Normal: le dije que íbamos al veterinario.",
            "—Mamá, en el cole me llaman pirómano. —Hijo, no te enciendas.",
    };
    static final String[] IT = {
            "Qual è il colmo per un elettricista? Non fare scintille con la ragazza.",
            "Cosa fa una mucca in un terremoto? Il frappè.",
            "Perché il pomodoro non riesce a dormire? Perché l'insalata russa.",
            "Qual è il colmo per un giardiniere? Avere un figlio che si chiama Rosario e non poterlo innaffiare.",
            "Cosa dice un muro a un altro muro? Ci vediamo all'angolo.",
            "Ho detto al telefono che avevo bisogno di una pausa… e mi ha messo in modalità aereo.",
    };
    static final String[] IT_DARK = {
            "Come si chiama il campione di nascondino in un campo minato? Nessuno lo sa.",
            "Mio nonno è morto sereno, nel sonno. Non come i passeggeri del suo autobus.",
            "Qual è il colmo per un cieco? Innamorarsi a prima vista.",
    };
    static final String[] EN = {
            "Why don't skeletons fight each other? They don't have the guts.",
            "I told my phone I needed a break… it put me in airplane mode.",
            "Why did the scarecrow win an award? He was outstanding in his field.",
            "What do you call fake spaghetti? An impasta.",
            "I'm reading a book about anti-gravity. It's impossible to put down.",
            "Why can't you trust atoms? They make up everything.",
    };
    static final String[] EN_DARK = {
            "My grandfather died peacefully in his sleep. Not like the passengers in his bus.",
            "What's the best part about turning ninety? Almost no peer pressure.",
            "I have a joke about a minefield, but nobody ever finds the punchline.",
    };

    // ---------------- ajustes ----------------
    static SharedPreferences p(Context c) { return Brain.prefs(c); }

    /** «pedir» (solo si lo pides) · «aveces» (también de vez en cuando) · «nunca». */
    static String darkMode(Context c) { return p(c).getString("humor_dark", "pedir"); }

    static final class J { String t; boolean dark; J(String t, boolean d) { this.t = t; dark = d; } }

    static List<J> mine(Context c) {
        List<J> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("jokes_user", "[]"));
            for (int i = 0; i < a.length(); i++) { JSONObject o = a.getJSONObject(i); out.add(new J(o.optString("t"), o.optBoolean("dark"))); }
        } catch (Exception ignored) {}
        return out;
    }

    static void save(Context c, List<J> l) {
        JSONArray a = new JSONArray();
        try { for (J j : l) a.put(new JSONObject().put("t", j.t).put("dark", j.dark)); } catch (Exception ignored) {}
        p(c).edit().putString("jokes_user", a.toString()).apply();
    }

    // ---------------- contar ----------------
    static final List<String> recent = new ArrayList<>();
    static long lastJokeAt;

    static boolean asksDark(String n) {
        return n.matches(".*\\b(?:negro|negra|oscuro|oscura|humor negro|macabro|dark|nero|black humou?r|cattivo|pesado|fuerte|bestia|sin filtro)\\b.*");
    }

    static boolean asksJoke(String n) {
        return n.matches(".*\\b(?:chiste|chistes|broma|algo gracioso|hazme reir|joke|jokes|barzelletta|barzellette|fammi ridere|make me laugh)\\b.*")
                || (System.currentTimeMillis() - lastJokeAt < 120_000 && n.matches("^(?:otro|otra|uno mas|otro mas|another|one more|un altro|un'altra|ancora)\\b.*"));
    }

    static boolean asksInvent(String n) {
        return n.matches(".*\\b(?:inventa|inventate|invent|crea|creame|hazme uno nuevo|uno nuevo|uno tuyo|original|inventati)\\b.*");
    }

    /** Si piden un chiste (y no que se invente uno), el chiste. Si no, null. */
    static String handle(Context c, String q) {
        String n = Actions.norm(q);
        if (!asksJoke(n) || asksInvent(n)) return null;
        boolean wantDark = asksDark(n) || (System.currentTimeMillis() - lastJokeAt < 120_000 && lastWasDark && n.matches("^(?:otro|otra|uno mas|otro mas|another|one more|un altro|ancora).*"));
        String mode = darkMode(c);
        if (wantDark && mode.equals("nunca")) return L.t("El humor negro lo tengo apagado en los ajustes. ¿Te vale uno normal? ") + pick(c, false, Brain.langCode(q));
        boolean dark = wantDark || (mode.equals("aveces") && rnd.nextFloat() < 0.3f);
        return pick(c, dark, Brain.langCode(q));
    }

    static boolean lastWasDark;

    static String pick(Context c, boolean dark, String lang) {
        List<String> pool = new ArrayList<>();
        String[] base = "it".equals(lang) ? (dark ? IT_DARK : IT) : "en".equals(lang) ? (dark ? EN_DARK : EN) : (dark ? ES_DARK : ES);
        for (String s : base) pool.add(s);
        // los tuyos, con más peso (están en tu idioma)
        for (J j : mine(c)) if (j.dark == dark && !j.t.trim().isEmpty()) { pool.add(j.t.trim()); pool.add(j.t.trim()); }
        List<String> fresh = new ArrayList<>();
        for (String s : pool) if (!recent.contains(s)) fresh.add(s);
        if (fresh.isEmpty()) { recent.clear(); fresh = pool; }
        String j = fresh.get(rnd.nextInt(fresh.size()));
        recent.add(j);
        while (recent.size() > Math.max(4, pool.size() * 2 / 3)) recent.remove(0);
        lastJokeAt = System.currentTimeMillis();
        lastWasDark = dark;
        return j;
    }

    // ---------------- guía para que se los invente el cerebro ----------------
    static final String GUIDE =
            "GUÍA DE HUMOR. Un chiste = una PREPARACIÓN que lleva al oyente por un camino + un GIRO final inesperado que cambia el sentido. "
                    + "Sin giro no hay chiste; no expliques el chiste ni añadas moralejas. Cuéntalo en 1 a 3 frases. Moldes: "
                    + "(a) juego de palabras: una palabra con doble sentido; (b) «¿qué le dijo X a Y?»; (c) absurdo: algo imposible contado con total normalidad; "
                    + "(d) exageración; (e) diálogo corto «—Doctor, doctor…».";
    static final String DARK_GUIDE =
            " HUMOR NEGRO: bromea a propósito con lo que normalmente no se toca (la muerte, la enfermedad, las desgracias, la vejez). "
                    + "Lo «políticamente correcto» es evitar esos temas para no herir a nadie; el humor negro rompe esa norma A PROPÓSITO y por eso hace gracia: "
                    + "por el choque entre algo inocente y algo terrible, dicho con toda naturalidad. Es un juego entre adultos que lo han pedido: "
                    + "no te disculpes ni avises, cuéntalo seco. Si un chiste no tiene giro, no es humor negro, es solo algo triste.";

    /** Lo que se añade a la pregunta cuando piden que se invente un chiste. */
    static String inventPrompt(Context c, String q) {
        String n = Actions.norm(q);
        boolean dark = asksDark(n) && !darkMode(c).equals("nunca");
        StringBuilder b = new StringBuilder(GUIDE);
        if (dark) b.append(DARK_GUIDE);
        b.append(" Ejemplos:");
        int k = 0;
        List<J> m = mine(c);
        java.util.Collections.shuffle(m);
        for (J j : m) if (j.dark == dark && k < 3) { b.append("\n- ").append(j.t); k++; }
        String[] base = dark ? ES_DARK : ES;
        for (int i = 0; i < 4 - k; i++) b.append("\n- ").append(base[rnd.nextInt(base.length)]);
        b.append("\nAhora inventa uno NUEVO (no repitas los ejemplos), del tipo que te piden. Solo el chiste.");
        return b.toString();
    }
}
