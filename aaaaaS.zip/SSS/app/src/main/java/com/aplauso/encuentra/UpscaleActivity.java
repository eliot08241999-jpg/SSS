package com.aplauso.encuentra;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * AMPLIAR IMÁGENES (v1.0), sin internet: agranda fotos pequeñas sin que se vean "raras".
 * · Pixel art / iconos: Scale2x (redibuja los bordes siguiendo el patrón de píxeles, sin difuminar).
 * · Dibujos y fotos: bicúbica Catmull-Rom por pasos de ×2 + enfoque suave de bordes.
 * La imagen original no se toca: el resultado se guarda aparte en Imágenes/SSS+.
 */
public class UpscaleActivity extends NeonActivity {
    static final int REQ_PICK = 91;
    static final String[] MODES = {"Automático", "Pixel art / iconos", "Dibujo o foto", "IA · dibujos y anime", "IA · fotos reales"};
    int mode = 0, factor = 2;
    Bitmap src, out;
    ImageView preview;
    TextView info, modeBtn, factorBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🔍 AMPLIAR IMÁGENES");
        LinearLayout pn = panel("◢ IMAGEN");
        info = text(L.t("Elige una imagen pequeña y la agrando sin que se pixele ni se emborrone."), 13);
        pn.addView(info);
        pn.addView(button("🖼 ELEGIR IMAGEN", v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, L.t("Elige una imagen")), REQ_PICK);
        }), gapBelow(8));
        modeBtn = button("", v -> { mode = (mode + 1) % MODES.length; labels(); });
        pn.addView(modeBtn, gapBelow(8));
        factorBtn = button("", v -> { factor = factor == 2 ? 4 : factor == 4 ? 8 : 2; labels(); });
        pn.addView(factorBtn, gapBelow(8));
        pn.addView(button("✨ AMPLIAR", v -> run()), gapBelow(8));
        pn.addView(button("💾 GUARDAR EN LA GALERÍA", v -> save()), gapBelow(8));
        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pn.addView(preview, new LinearLayout.LayoutParams(-1, dpi(320)));
        pn.addView(text(L.t("Automático usa la IA (reconstruye bordes y texturas) salvo en pixel art. Todo se hace en el teléfono y sin internet."), 11));
        col.addView(pn, gapBelow(14));
        labels();
    }

    void labels() {
        modeBtn.setText(L.t("Tipo: ") + L.t(MODES[mode]));
        factorBtn.setText(L.t("Tamaño: ×") + factor);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            src = BitmapFactory.decodeStream(in, null, o);
            out = null;
            if (src == null) { toast(L.t("No puedo abrir esa imagen.")); return; }
            preview.setImageBitmap(src);
            info.setText(L.t("Original: ") + src.getWidth() + " × " + src.getHeight());
        } catch (Exception e) {
            toast(L.t("No puedo abrir esa imagen."));
        }
    }

    void run() {
        if (src == null) { toast(L.t("Primero elige una imagen.")); return; }
        long px = (long) src.getWidth() * src.getHeight() * factor * factor;
        int f = factor;
        while (px > 36_000_000L && f > 2) { f /= 2; px /= 4; }
        if (px > 36_000_000L) { toast(L.t("La imagen ya es demasiado grande para agrandarla más.")); return; }
        final int ff = f;
        info.setText(L.t("Ampliando… (puede tardar unos segundos)"));
        new Thread(() -> {
            try {
                boolean pixel = mode == 1 || (mode == 0 && looksPixelArt(src));
                boolean ia = !pixel && mode != 2;
                Bitmap r = src;
                if (ia) {
                    // v1.5.2: la red neuronal hace ×4 (hasta 16 MP); si se pide ×8, el último ×2 es clásico
                    int k = Math.min(ff, 4);
                    while ((long) src.getWidth() * src.getHeight() * k * k > 16_000_000L && k > 2) k /= 2;
                    r = VideoSR.upscaleBitmap(this, src, src.getWidth() * k, src.getHeight() * k, mode == 4 ? 1 : 0);
                    VideoSR.release();
                    for (int q = k; q < ff; q *= 2) r = sharpen(bicubic2x(r), 0.3f);
                } else {
                    for (int k = ff; k > 1; k /= 2) r = pixel ? scale2x(r) : bicubic2x(r);
                    if (!pixel) r = sharpen(r, 0.55f);
                }
                Bitmap done = r;
                boolean pa = pixel;
                runOnUiThread(() -> {
                    out = done;
                    preview.setImageBitmap(done);
                    info.setText((pa ? L.t("Pixel art") : L.t(MODES[mode == 0 ? 3 : mode])) + " · " + src.getWidth() + "×" + src.getHeight()
                            + " → " + done.getWidth() + "×" + done.getHeight() + ". " + L.t("Pulsa GUARDAR."));
                });
            } catch (OutOfMemoryError e) {
                runOnUiThread(() -> info.setText(L.t("No hay memoria suficiente: prueba con un tamaño menor.")));
            } catch (Exception e) {
                runOnUiThread(() -> info.setText(L.t("No se pudo: ") + e.getMessage()));
            }
        }, "ampliar").start();
    }

    void save() {
        if (out == null) { toast(L.t("Primero pulsa AMPLIAR.")); return; }
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "SSS_ampliada_" + System.currentTimeMillis() + ".png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (android.os.Build.VERSION.SDK_INT >= 29) v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SSS+");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            try (OutputStream os = getContentResolver().openOutputStream(u)) { out.compress(Bitmap.CompressFormat.PNG, 100, os); }
            toast(L.t("Guardada en Imágenes/SSS+"));
        } catch (Exception e) {
            toast(L.t("No se pudo guardar: ") + e.getMessage());
        }
    }

    /** Pocas tonalidades y bordes duros = pixel art. */
    static boolean looksPixelArt(Bitmap b) {
        if ((long) b.getWidth() * b.getHeight() > 512 * 512) return false;
        int w = b.getWidth(), h = b.getHeight();
        int[] p = new int[w * h];
        b.getPixels(p, 0, w, 0, 0, w, h);
        java.util.HashSet<Integer> set = new java.util.HashSet<>();
        for (int c : p) { set.add(c); if (set.size() > 256) return false; }
        return true;
    }

    /** Scale2x / EPX: duplica el tamaño copiando el patrón de los vecinos (bordes limpios, sin difuminar). */
    static Bitmap scale2x(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int[] s = new int[w * h], d = new int[w * h * 4];
        b.getPixels(s, 0, w, 0, 0, w, h);
        int W = w * 2;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int P = s[y * w + x];
            int A = s[Math.max(0, y - 1) * w + x], Bv = s[y * w + Math.min(w - 1, x + 1)];
            int C = s[y * w + Math.max(0, x - 1)], D = s[Math.min(h - 1, y + 1) * w + x];
            int e0 = P, e1 = P, e2 = P, e3 = P;
            if (C == A && C != D && A != Bv) e0 = A;
            if (A == Bv && A != C && Bv != D) e1 = Bv;
            if (D == C && D != Bv && C != A) e2 = C;
            if (Bv == D && Bv != A && D != C) e3 = D;
            int o = (y * 2) * W + x * 2;
            d[o] = e0; d[o + 1] = e1; d[o + W] = e2; d[o + W + 1] = e3;
        }
        return Bitmap.createBitmap(d, W, h * 2, Bitmap.Config.ARGB_8888);
    }

    static float cub(float t, float a, float b, float c, float d) {
        return b + 0.5f * t * (c - a + t * (2 * a - 5 * b + 4 * c - d + t * (3 * (b - c) + d - a)));
    }

    /** ×2 con interpolación bicúbica Catmull-Rom (más nítida que la normal). */
    static Bitmap bicubic2x(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight(), W = w * 2, H = h * 2;
        int[] s = new int[w * h], d = new int[W * H];
        b.getPixels(s, 0, w, 0, 0, w, h);
        float[] col = new float[4];
        for (int Y = 0; Y < H; Y++) {
            float fy = (Y + 0.5f) / 2 - 0.5f;
            int y0 = (int) Math.floor(fy);
            float ty = fy - y0;
            for (int X = 0; X < W; X++) {
                float fx = (X + 0.5f) / 2 - 0.5f;
                int x0 = (int) Math.floor(fx);
                float tx = fx - x0;
                int outc = 0;
                for (int ch = 0; ch < 4; ch++) {
                    int sh = ch * 8;
                    for (int j = -1; j <= 2; j++) {
                        int yy = Math.min(h - 1, Math.max(0, y0 + j)) * w;
                        float p0 = (s[yy + Math.min(w - 1, Math.max(0, x0 - 1))] >>> sh) & 255;
                        float p1 = (s[yy + Math.min(w - 1, Math.max(0, x0))] >>> sh) & 255;
                        float p2 = (s[yy + Math.min(w - 1, Math.max(0, x0 + 1))] >>> sh) & 255;
                        float p3 = (s[yy + Math.min(w - 1, Math.max(0, x0 + 2))] >>> sh) & 255;
                        col[j + 1] = cub(tx, p0, p1, p2, p3);
                    }
                    int v = Math.round(cub(ty, col[0], col[1], col[2], col[3]));
                    outc |= Math.max(0, Math.min(255, v)) << sh;
                }
                d[Y * W + X] = outc;
            }
        }
        return Bitmap.createBitmap(d, W, H, Bitmap.Config.ARGB_8888);
    }

    /** Enfoque (máscara de desenfoque 3×3) solo en color, sin tocar la transparencia. */
    static Bitmap sharpen(Bitmap b, float amount) {
        int w = b.getWidth(), h = b.getHeight();
        int[] s = new int[w * h], d = new int[w * h];
        b.getPixels(s, 0, w, 0, 0, w, h);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int c = s[y * w + x];
            int r = 0, g = 0, bl = 0;
            for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
                int q = s[Math.min(h - 1, Math.max(0, y + j)) * w + Math.min(w - 1, Math.max(0, x + i))];
                r += (q >> 16) & 255; g += (q >> 8) & 255; bl += q & 255;
            }
            int cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
            int nr = clamp(cr + amount * (cr - r / 9f)), ng = clamp(cg + amount * (cg - g / 9f)), nb = clamp(cb + amount * (cb - bl / 9f));
            d[y * w + x] = (c & 0xFF000000) | (nr << 16) | (ng << 8) | nb;
        }
        return Bitmap.createBitmap(d, w, h, Bitmap.Config.ARGB_8888);
    }

    static int clamp(float v) { return v < 0 ? 0 : v > 255 ? 255 : Math.round(v); }
}
