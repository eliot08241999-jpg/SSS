package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/** Copia de seguridad de partidas, récords y ajustes (todo lo de "cfg") en un archivo JSON. */
public class Backup {

    static byte[] export(Context c) throws Exception {
        SharedPreferences p = c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        JSONObject all = new JSONObject();
        for (Map.Entry<String, ?> e : p.getAll().entrySet()) {
            Object v = e.getValue();
            JSONObject o = new JSONObject();
            if (v instanceof Boolean) o.put("t", "b").put("v", v);
            else if (v instanceof Integer) o.put("t", "i").put("v", v);
            else if (v instanceof Long) o.put("t", "l").put("v", v);
            else if (v instanceof Float) o.put("t", "f").put("v", ((Float) v).doubleValue());
            else if (v instanceof String) o.put("t", "s").put("v", v);
            else if (v instanceof Set) {
                JSONArray a = new JSONArray();
                for (Object x : (Set<?>) v) a.put(String.valueOf(x));
                o.put("t", "set").put("v", a);
            } else continue;
            all.put(e.getKey(), o);
        }
        JSONObject root = new JSONObject();
        root.put("app", "SSS+");
        root.put("autor", "BLORP.eoac");
        root.put("version", 1);
        root.put("fecha", Media.stamp());
        root.put("prefs", all);
        return root.toString(1).getBytes("UTF-8");
    }

    /** Restaura una copia. Devuelve cuántos datos se recuperaron. */
    static int restore(Context c, byte[] data) throws Exception {
        JSONObject root = new JSONObject(new String(data, "UTF-8"));
        if (!"SSS+".equals(root.optString("app", ""))) throw new Exception("no es una copia de SSS+");
        JSONObject all = root.getJSONObject("prefs");
        SharedPreferences.Editor ed = c.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit();
        int n = 0;
        for (Iterator<String> it = all.keys(); it.hasNext(); ) {
            String k = it.next();
            JSONObject o = all.getJSONObject(k);
            switch (o.getString("t")) {
                case "b": ed.putBoolean(k, o.getBoolean("v")); break;
                case "i": ed.putInt(k, o.getInt("v")); break;
                case "l": ed.putLong(k, o.getLong("v")); break;
                case "f": ed.putFloat(k, (float) o.getDouble("v")); break;
                case "s": ed.putString(k, o.getString("v")); break;
                case "set": {
                    JSONArray a = o.getJSONArray("v");
                    java.util.Set<String> s = new java.util.HashSet<>();
                    for (int i = 0; i < a.length(); i++) s.add(a.getString(i));
                    ed.putStringSet(k, s);
                    break;
                }
                default: continue;
            }
            n++;
        }
        ed.apply();
        return n;
    }
}
