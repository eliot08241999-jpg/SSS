package com.aplauso.encuentra;

import java.util.ArrayList;
import java.util.List;

/**
 * v1.5 · Prepara el texto para la voz propia de Chloe: lo limpia, lo parte en trozos (frases; y la primera, corta,
 * para que empiece a hablar antes) y lo pasa a los números que entiende el modelo. Java puro.
 */
public class KokoroText {
    public static final class Chunk {
        public String text;
        public long[] ids;          // con el 0 al principio y al final
        public float pause;         // segundos de silencio después
        public float speedMul = 1, volMul = 1;
    }

    static final int[] SYMS = {59,58,44,46,33,63,8212,8230,34,40,41,8220,8221,32,771,675,677,678,680,7517,43879,65,73,79,81,83,84,87,89,7498,97,98,99,100,101,102,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,593,592,594,230,946,596,597,231,598,240,676,601,602,603,604,607,609,613,616,618,669,623,624,331,627,626,628,248,632,952,339,633,638,635,641,637,642,643,648,679,650,651,652,611,612,967,654,658,660,712,716,720,688,690,8595,8594,8599,8600,7547};   // letras del modelo (como números, para no liar al compilador)
    static final int[] IDS = {1,2,3,4,5,6,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,31,33,35,36,39,41,42,43,44,45,46,47,48,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,75,76,77,78,80,81,82,83,85,86,87,90,92,99,101,102,103,110,111,112,113,114,115,116,118,119,120,123,125,126,128,129,130,131,132,133,135,136,138,139,140,142,143,147,148,156,157,158,162,164,169,171,172,173,177};
    static final int[] MAP = new int[65536];
    static { for (int i = 0; i < IDS.length; i++) MAP[SYMS[i]] = IDS[i]; }

    public static long[] tokens(String phonemes) {
        long[] t = new long[Math.min(phonemes.length(), 508) + 2];
        int n = 1;
        for (int i = 0; i < phonemes.length() && n < t.length - 1; i++) { int id = MAP[phonemes.charAt(i)]; if (id > 0) t[n++] = id; }
        return java.util.Arrays.copyOf(t, n + 1);
    }

    /** Fuera emojis, asteriscos, enlaces y demás cosas que no se dicen. */
    public static String clean(String s) {
        s = s.replaceAll("https?://\\S+", " ").replaceAll("[*_#`~|<>\\[\\]{}]", " ").replace("\n", ". ");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (Character.isLetterOrDigit(cp) || Character.isWhitespace(cp) || ",.;:!?¡¿…\"'()-—%€$".indexOf(cp) >= 0) b.appendCodePoint(cp);
            else b.append(' ');
        }
        return b.toString().replace("%", " por ciento ").replace("€", " euros ").replace("$", " dólares ")
                .replaceAll("\\s+", " ").replaceAll("(\\. ?){2,}", "… ").replaceAll(" ([,.;:!?…])", "$1").trim();
    }

    /**
     * @param maxLen  letras como mucho por trozo (frases más largas se parten por las comas)
     * @param quick   primera parte corta, para empezar a sonar antes
     * @param expr    0..1: cuánto cambian velocidad y fuerza según la frase (¡…!, puntos suspensivos…)
     */
    public static List<Chunk> split(String text, int maxLen, boolean quick, float expr, float pauseMul, java.util.Random rnd) {
        String t = clean(text);
        List<String> parts = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            cur.append(c);
            boolean end = ".!?…".indexOf(c) >= 0 && (i + 1 >= t.length() || t.charAt(i + 1) == ' ')
                    && !(c == '.' && i > 0 && Character.isDigit(t.charAt(i - 1)) && i + 1 < t.length() && Character.isDigit(t.charAt(i + 1)));
            if (end) { add(parts, cur.toString(), maxLen); cur.setLength(0); }
        }
        add(parts, cur.toString(), maxLen);
        if (quick && !parts.isEmpty() && parts.get(0).length() > 28) {          // el primer trozo, hasta la primera coma
            String f = parts.get(0);
            int k = -1;
            for (int i = 6; i < Math.min(f.length() - 6, 60); i++) if (",;:".indexOf(f.charAt(i)) >= 0) { k = i; break; }
            if (k > 0) { parts.set(0, f.substring(0, k + 1)); parts.add(1, f.substring(k + 1).trim()); }
        }
        List<Chunk> out = new ArrayList<>();
        for (String s : parts) {
            String ph = SpanishG2P.phonemize(s);
            long[] ids = tokens(ph);
            if (ids.length <= 2) continue;
            boolean letters = false;
            for (int i = 0; i < ph.length(); i++) if (Character.isLetter(ph.charAt(i))) { letters = true; break; }
            if (!letters) continue;
            Chunk c = new Chunk();
            c.text = s;
            c.ids = ids;
            char last = s.charAt(s.length() - 1);
            c.pause = (".!?".indexOf(last) >= 0 ? 0.28f : last == '…' ? 0.45f : ",;:".indexOf(last) >= 0 ? 0.12f : 0.05f) * pauseMul;
            float j = rnd == null ? 0 : (rnd.nextFloat() - 0.5f) * 0.07f;         // nunca dos frases igual de rápidas
            if (last == '!') { c.speedMul = 1 + 0.05f * expr; c.volMul = 1 + 0.10f * expr; }
            else if (last == '…') { c.speedMul = 1 - 0.08f * expr; c.volMul = 1 - 0.08f * expr; }
            else if (last == '?') c.speedMul = 1 - 0.02f * expr;
            c.speedMul += j * expr;
            out.add(c);
        }
        return out;
    }

    static void add(List<String> parts, String s, int maxLen) {
        s = s.trim();
        if (s.isEmpty()) return;
        while (s.length() > maxLen) {
            int k = -1;
            for (int i = Math.min(maxLen, s.length() - 1); i > maxLen / 3; i--) if (",;:".indexOf(s.charAt(i)) >= 0) { k = i + 1; break; }
            if (k < 0) for (int i = Math.min(maxLen, s.length() - 1); i > maxLen / 3; i--) if (s.charAt(i) == ' ') { k = i; break; }
            if (k < 0) k = maxLen;
            parts.add(s.substring(0, k).trim());
            s = s.substring(k).trim();
        }
        if (!s.isEmpty()) parts.add(s);
    }
}
