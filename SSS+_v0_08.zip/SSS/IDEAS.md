# SSS+ · Ideas pendientes (de BLORP.eoac)

Lista de peticiones para las próximas versiones. Se va tachando al construirlas.

## v0.8 · Pack retro remasterizado ✅ (hecho en la v0.8)
- Remake moderno a color (neón, efectos, partículas) de los juegos de las maquinitas "Brick Game", con música chiptune propia de cada juego que se acelera con la dificultad.
- Juegos nuevos: Carreras (curvas, turbo, monedas), Tanques (enemigos variados, potenciadores, jefes), Disparos (oleadas, armas mejorables), Ranita (troncos, tortugas, día/noche), Rellenar huecos (combos, piezas especiales).
- Lavado de cara de Bloques, Culebrita y Rompeladrillos para que combinen.
- Botón opcional "como antes" (LCD verde), niveles y velocidades, récords, mando externo, zurdo, joystick.

## El Pastor de Ecos
### Progresión
- ~120 emblemas por familias (ataque, defensa, movimiento, curación/lana, economía), sets (como el vampírico) y raros/secretos. Pantalla con pestañas, filtros y buscador; más huecos para equipar con objetos permanentes.
- Objetos de mejora permanente de estadísticas: pequeños (+1, +2, +3) de daño, vida máxima, defensa, velocidad, ovillos máximos, etc. Recompensa de misiones, cofres, secretos y jefes; se acumulan (con límite total para no romper el equilibrio).
  - Ovillos: hoy el máximo es 9 (cada curación gasta 3). Los "Ovillo Extra" son pocos y contados en todo el mapa: 6 en total (+1 cada uno), para un máximo absoluto de 15 ovillos. Nunca más ni infinitos. 3 escondidos por el mapa (secretos) y 3 a la venta en vendedores concretos (uno cada uno, caros).
  - Vida: base 100; emblemas actuales dan como máximo 420. Pociones de vida permanentes: 10 en todo el mapa, +10 cada una = +100 como máximo. Máximo absoluto con todo: 520.
  - Sin sistema de niveles (decidido): se crece con forja, emblemas y objetos permanentes.
  - Jefes finales: LUMENIA 5000 de vida (ahora 3000) y Conde Vampis 3500 (ahora 2000). Medido en Modo Jefes con todo al máximo: Conde cae en 6 s y LUMENIA en 47 s → demasiado fácil. Además de la vida: fases que no se pueden saltar (el daño de más se pierde hasta que cambia de fase), daño completo solo en sus aberturas (fuera de ellas ~30 %), y objetivo de 3–4 min (Conde) y 5+ min (LUMENIA) incluso con el mejor equipo.
  - Música: Conde Vampis con tema épico de verdad; LUMENIA el tema más épico del juego, potente como una marcha imperial ("como pelear contra un dios"): tono menor, marcha pesada, bajo martilleante, "metales", timbales y coro. Composición propia (no copiar la Marcha Imperial de Star Wars).
  - Daño: hoy, con forja nv 10 y los mejores emblemas, cada onda llega a ~156 (437 con furia + crítico) y unas ~1500 de daño por segundo si todo acierta. Pendiente decidir el tope (propuesta: pociones de fuerza +1 de ataque ×10 = +10 como máximo; intensidad total de daño tope +100 %).
  - Cada mejora tiene un número fijo de piezas repartidas por el mapa (no se pueden farmear) y un tope por estadística.
- Habilidades por encontrar (santuarios, jefes, zonas secretas), muchas gastan ovillos de lana:
  Embestida de Lana (dash en aire y tierra), Gancho de Lana, Capullo (bloqueo), Plataforma de lana, Tormenta de Lana, Golpe de Cencerro Cargado (rompe muros);
  sin coste: Pezuñas de Cabra (trepar), Lana Impermeable (bucear), Eco Sonar (pasadizos ocultos), Salto Triple, Caída en Picado.
- Zonas que solo se abren con esas habilidades, marcadas en el mapa.

### Aspecto visual ✅ (aspecto OLED hecho en la v0.8)
- Pixel art con aspecto de "Game Boy con pantalla OLED": más brillo y color (saturación, negros profundos, bloom suave en luces, ecos y ojos), toque 3D ligero (sombras bajo personajes, bordes iluminados en suelos y plataformas, fondos con parallax), luz alrededor de la oveja en zonas oscuras, destellos al golpear. Opción en la pausa para volver al aspecto actual.

### Misiones secundarias (mínimo 25, cuantas más mejor)
- NPCs repartidos por las salas más vacías (pasillos tipo laberinto) que piden ayuda.
- Tipos: cazar X enemigos de un tipo; encontrar y devolver un objeto perdido; escoltar/rescatar a alguien; entregar algo a otro NPC en otra zona; superar un desafío (llegar a un sitio en tiempo, sin recibir daño); vencer a un mini-jefe; encontrar salas secretas.
- Recompensas: cascabeles, gemas, emblemas, objetos de mejora permanente, piezas de mapa.
- Diario de misiones en la pausa (activas / completadas) y marcas en el mapa (❗ misión disponible, ✔ entregar).

### Aldeas y vida
- Varios refugios crecen a pequeñas aldeas (casitas, vecinos haciendo vida normal: tender lana, pescar, cocinar, barrer, niños jugando). Propuesta: Eco Hondo ampliado, Aldea Minera, Pueblo del Hielo, Mercado de las Setas, Barrio Alto (Ciudad Sumergida), Ermita de los Cuervos (Viento), Último Refugio (Nido, supervivientes).
- Servicios (fardo, tienda, forja, curandera), origen de misiones secundarias, y las aldeas se animan al avanzar; tras vencer al Conde los supervivientes vuelven a casa.
- Escena antes del jefe final: las aldeas cercanas, vacías y con miedo toda la partida, aparecen con su gente esperándote a la entrada de su guarida, con banderitas de una oveja, saltando de alegría y llamándote héroe. La multitud crece según a cuántos ayudaste; Versión pequeña a las puertas del Palacio del Conde.
  - Música por tramos: afuera con la gente = música normal del mapa; al entrar = música de cueva neutral; corredor muy largo con zombis, enemigos y un Gólem (mini-jefe con mucha más vida que un jefe común, lanza piedras y embiste, no cuenta como jefe); si salvaste a mucha gente, durante el corredor la música de cueva se mezcla a volumen bajo con música alegre y vítores (más gente = más se oye); en la sala del jefe, música épica.
  - Final secreto: SOLO con el set vampírico completo (5 piezas) equipado al entrar en esa zona; si falta una, nada. El traje te consume, te conviertes en vampiro, das media vuelta y sales hacia la gente. Cinemática sin mostrar muertes directamente: con Sangre SÍ, siluetas a contraluz y salpicaduras rojas por todos lados; con Sangre NO, siluetas de animalitos de granja tiernos gritando y la oveja con colmillos mordiéndolos, sin sangre. Fin. Desbloquea el logro "Débil por la sangre" — Final secreto n.º 1.
- Finales (más adelante habrá otros):
  - Final verdadero (CANON y el mejor): vencer a LUMENIA con los 5 corderitos rescatados → en el último momento de la pelea llegan los corderitos con sus cencerros y entre todas las ovejas la vencen; al final todos celebran → logro "El Rebaño Unido".
  - Final del sacrificio (también bueno): vencer a LUMENIA sin los 5 corderitos → la oveja muere en el intento; epílogo: todos los animales con rosas en las manos celebran alrededor de una estatua de la gran oveja con el cencerro → logro "Pastor Temerario".
  - Final secreto n.º 1: "Débil por la sangre".
  - Final secreto n.º 2: vencer a LUMENIA con el Set de la Sinfonía completo (5 piezas) y elegir quedarte los ecos en vez de devolverlos al mundo → los ecos giran a tu alrededor, creces en tamaño y fuerza y te vuelves el nuevo jefe del silencio; corte al pueblo triste y en silencio, donde nace una nueva ovejita con un cencerro (el nuevo héroe). Logro: "Adicto al Eco".
  - ✅ HECHO en la v0.8: finales, logros, Coliseo y Set de la Sinfonía.
  - Cómo se consigue el Set de la Sinfonía (v0.8): llave AZUL de 1000 cascabeles (Agente Garduña) que abre la puerta azul del Coliseo del Eco (Cementerio de Campanas). El Presentador te inscribe (puedes retirarte). 5 tandas de 5 rivales que salen de uno en uno; al vencer al 5.º, el Presentador deja una pieza en el suelo y pregunta si sigues. 25 "Titanes del Coliseo" de 2500 de vida con las mejores mecánicas combinadas. Música de pelea estilo arcade de lucha.
  - Set de la Sinfonía: set de puro sonido que dispara el daño de las ondas; la oveja se vuelve adicta al sonido y por eso no suelta los ecos. Piezas (propuesta): Cencerro Resonante (+35 % daño de ondas), Diapasón del Abismo (atraviesan y vuelven a sonar), Campana Gemela (+1 onda), Oído Infinito (+50 % alcance, algo teledirigidas), Corazón de Eco (cada onda repite el golpe 0,5 s después). Set completo: cada 5.º disparo una onda gigante; precio de la adicción: 5 s sin hacer sonar el cencerro = pierdes vida poco a poco.
  - Descartado: logro por vencer a un jefe antes de tiempo.
- Tus acciones cambian a los personajes: felicitaciones y regalos al vencer al jefe de su zona o a un secuaz, supervivientes rescatados que reaparecen en aldeas, misiones encadenadas, frases nuevas según tus ecos y hazañas. Regalos posibles: pociones de vida/fuerza, emblemas de defensa, cascabeles (dentro de los topes ya fijados).

### Historia de los Vampis
- Los Vampis son un clan de rufianes que domina Lanaria a base de miedo; todos temen al Conde, incluso sus secuaces.
- ~10 supervivientes repartidos (tirados, llorando, heridos o escondidos) que cuentan la situación de su zona, dan pistas de dónde están las puertas carmesí y de cómo vencer a cada secuaz, hablan del clan y del Conde (bajan la voz al nombrarlo). Ayudarlos puede ser misión secundaria.

### Secuaces del Conde
- ✅ (v0.8) "Mapa de los Secuaces" a la venta en la Agente Garduña: marca con 🩸 cada puerta carmesí y quién hay detrás. Al comprar una llave carmesí, la policía dice dónde hay una puerta.
- Zombis vampíricos: personas que no sobrevivieron a la vampirización, piel verdosa, ropa rota y ojos rojos. Dibujo propio (no usar imágenes de bancos de imágenes).
- Cada guarida pasa a ser una ZONA GRANDE y temática, no una sola sala:
  - **Harold**: lugar lleno de cadáveres, esqueletos guardias y zombis medio comidos haciendo guardia. Su habitación: llena de arañazos (marcas de garras), paredes rotas y dañadas siempre; con 🩸 Sangre: SÍ además se ven manchas de sangre (manchas, no paredes cubiertas por completo); con Sangre: NO solo las paredes rotas y dañadas, sin nada de sangre (no a todos les gusta). Aplica a todas las zonas vampíricas. Música sepulcral, gótica y amenazante. En la pelea gruñe más y cada cierto tiempo lanza pedazos de pilares y muros.
  - **Planta Carnívora**: flores móviles, raíces retráctiles, furia. Música ambiental de naturaleza salvaje. Secuaces: flores que caminan con raíces como pies y pegan con las hojas (cuerpo a cuerpo), flores que disparan semillas como catapultas, y algún polinizador furioso.
  - **Aloii Vampis**: lugar lujoso con cuadros de él y del Conde, muchos espejos y oro por todas partes. Zombis refinados que pegan con látigos. Sabuesos del infierno en llamas: al aparecer su vida baja rápido por el fuego, viven unos 7 s; si te pegan, 25 % de prenderte fuego: −5 de vida cada 0,9 s durante 9 s.
  - **Sangre Joven**: habitación llena de cosas deportivas. Zombis con ropa deportiva (shorts, banda en la cabeza, zapatillas, ropa de fútbol y básquet). Cuerpo a cuerpo con bates y raquetas; a distancia lanzan pelotas de tenis, básquet y fútbol. Música energética.
  - **Conde Vampis**: un palacio grande, suelo teñido de rojo con huesos, cadáveres y zombis. Él aparece sentado en su trono de huesos; al acercarte se levanta y empieza la pelea.

## Más adelante (antes de la v1.3)
- Compilar desde la app vía GitHub, actualizador interno y copias de seguridad automáticas antes de actualizar.
- v1.0: versión de pulido (estilo unificado, pantalla de Novedades, logo propio).
