package com.aplauso.encuentra;

import java.util.HashMap;
import java.util.Map;

/**
 * Contenido de EL PASTOR DE ECOS: zonas, criaturas, jefes, emblemas, habilidades, tiendas y textos.
 * Todos los números de equilibrio están aquí.
 */
public class EcoData {

    // =====================================================================
    // ZONAS
    // =====================================================================
    static final int Z_PRADERA = 0, Z_MINAS = 1, Z_LAGO = 2, Z_HONGOS = 3, Z_JARDIN = 4, Z_CIUDAD = 5, Z_CRISTAL = 6,
            Z_VIENTO = 7, Z_CEMENTERIO = 8, Z_COLMENA = 9, Z_CLOACAS = 10, Z_NIDO = 11, Z_ABISMO = 12, Z_CASTILLO = 13;
    static final int NZ = 14;

    // fondos temáticos
    static final int BG_HILLS = 0, BG_MINE = 1, BG_ICE = 2, BG_FUNGI = 3, BG_THORNS = 4, BG_CITY = 5, BG_CRYSTAL = 6,
            BG_CLIFFS = 7, BG_GRAVES = 8, BG_HIVE = 9, BG_SEWER = 10, BG_WEB = 11, BG_VOID = 12, BG_CASTLE = 13;
    // partículas
    static final int PT_NONE = 0, PT_SNOW = 1, PT_SPORES = 2, PT_RAIN = 3, PT_SPARKS = 4, PT_PETALS = 5, PT_WIND = 6,
            PT_DUST = 7, PT_EMBERS = 8, PT_BUBBLES = 9, PT_LEAVES = 10;

    static class Zone {
        final String name, code;
        final int tier;            // ecos necesarios para entrar
        final int top, bot, rock, dark, edge, plat, map;
        final int bg, particles;
        final boolean darkness;
        final String[] kinds;
        Chip.Song music;

        Zone(String name, String code, int tier, int top, int bot, int rock, int dark, int edge, int plat, int map,
             int bg, int particles, boolean darkness, String... kinds) {
            this.name = name; this.code = code; this.tier = tier;
            this.top = top; this.bot = bot; this.rock = rock; this.dark = dark; this.edge = edge; this.plat = plat; this.map = map;
            this.bg = bg; this.particles = particles; this.darkness = darkness; this.kinds = kinds;
        }
    }

    static int rgb(int r, int g, int b) { return 0xff000000 | (r << 16) | (g << 8) | b; }

    static final Zone[] ZONES = {
            new Zone("Pradera Hundida", "p", 0, rgb(29, 59, 74), rgb(10, 22, 28), rgb(90, 61, 38), rgb(62, 42, 26), rgb(88, 192, 72), rgb(160, 112, 64), rgb(110, 190, 110), BG_HILLS, PT_LEAVES, false, "s", "b", "e"),
            new Zone("Minas de Cobre", "m", 1, rgb(40, 20, 12), rgb(10, 6, 4), rgb(106, 58, 36), rgb(64, 32, 15), rgb(216, 138, 64), rgb(150, 100, 60), rgb(220, 140, 80), BG_MINE, PT_SPARKS, false, "m", "z", "v"),
            new Zone("Lago Helado", "L", 2, rgb(30, 60, 100), rgb(8, 16, 34), rgb(70, 100, 140), rgb(40, 60, 96), rgb(200, 240, 255), rgb(150, 200, 230), rgb(140, 200, 255), BG_ICE, PT_SNOW, false, "L1", "L2", "L3"),
            new Zone("Bosque de Hongos", "H", 2, rgb(52, 36, 20), rgb(14, 10, 6), rgb(96, 70, 40), rgb(60, 42, 22), rgb(240, 180, 60), rgb(200, 140, 70), rgb(230, 180, 90), BG_FUNGI, PT_SPORES, false, "H1", "H2", "H3"),
            new Zone("Jardín de Espinas", "J", 4, rgb(20, 46, 30), rgb(4, 14, 8), rgb(50, 80, 50), rgb(26, 46, 28), rgb(120, 210, 100), rgb(100, 140, 70), rgb(120, 200, 120), BG_THORNS, PT_PETALS, false, "J1", "J2", "J3"),
            new Zone("Ciudad Sumergida", "C", 4, rgb(30, 34, 74), rgb(8, 8, 26), rgb(70, 74, 120), rgb(40, 42, 78), rgb(150, 160, 255), rgb(120, 120, 180), rgb(130, 140, 240), BG_CITY, PT_RAIN, false, "C1", "C2", "C3"),
            new Zone("Cumbres de Cristal", "K", 7, rgb(70, 40, 80), rgb(20, 8, 26), rgb(120, 80, 130), rgb(70, 40, 80), rgb(255, 160, 230), rgb(200, 140, 200), rgb(230, 150, 230), BG_CRYSTAL, PT_SPARKS, false, "K1", "K2", "K3"),
            new Zone("Acantilados del Viento", "V", 7, rgb(80, 96, 120), rgb(30, 36, 50), rgb(100, 100, 110), rgb(60, 60, 70), rgb(220, 220, 230), rgb(160, 150, 140), rgb(200, 200, 215), BG_CLIFFS, PT_WIND, false, "V1", "V2", "V3"),
            new Zone("Cementerio de Campanas", "R", 9, rgb(60, 36, 20), rgb(16, 8, 4), rgb(100, 76, 60), rgb(60, 44, 34), rgb(255, 170, 90), rgb(170, 120, 80), rgb(240, 160, 90), BG_GRAVES, PT_DUST, false, "R1", "R2", "R3"),
            new Zone("Colmena Dorada", "A", 11, rgb(80, 60, 10), rgb(24, 16, 2), rgb(140, 100, 20), rgb(90, 60, 10), rgb(255, 220, 80), rgb(220, 170, 50), rgb(250, 210, 70), BG_HIVE, PT_SPARKS, false, "A1", "A2", "A3"),
            new Zone("Cloacas Reales", "W", 11, rgb(16, 56, 56), rgb(4, 16, 18), rgb(50, 90, 86), rgb(28, 54, 52), rgb(100, 230, 200), rgb(90, 150, 140), rgb(100, 220, 200), BG_SEWER, PT_BUBBLES, false, "W1", "W2", "W3"),
            new Zone("Nido Profundo", "N", 13, rgb(30, 30, 36), rgb(6, 6, 8), rgb(60, 60, 70), rgb(30, 30, 36), rgb(170, 170, 190), rgb(110, 110, 120), rgb(150, 150, 170), BG_WEB, PT_DUST, true, "N1", "N2", "N3"),
            new Zone("Abismo del Silencio", "Z", 18, rgb(14, 14, 18), rgb(0, 0, 0), rgb(40, 40, 48), rgb(20, 20, 26), rgb(200, 200, 220), rgb(90, 90, 100), rgb(190, 190, 200), BG_VOID, PT_DUST, true, "Z1", "Z2", "Z3"),
            new Zone("Castillo Carmesí", "X", 99, rgb(60, 6, 14), rgb(12, 0, 2), rgb(70, 30, 40), rgb(40, 14, 20), rgb(220, 40, 60), rgb(140, 60, 70), rgb(230, 50, 70), BG_CASTLE, PT_EMBERS, false, "X1", "X2", "X3"),
    };

    static void initMusic() {
        Chip.Song[] m = {Songs.PRADERA, Songs.MINAS, Songs.LAGO, Songs.HONGOS, Songs.JARDIN, Songs.CIUDAD, Songs.CRISTAL,
                Songs.VIENTO, Songs.CEMENTERIO, Songs.COLMENA, Songs.CLOACAS, Songs.NIDO, Songs.ABISMO, Songs.CASTILLO};
        for (int i = 0; i < NZ; i++) ZONES[i].music = m[i];
    }

    static { initMusic(); }

    // =====================================================================
    // CRIATURAS
    // =====================================================================
    static final int A_WALK = 0, A_FLY = 1, A_SHOOT = 2, A_CHARGE = 3, A_FLOAT = 4, A_JUMP = 5, A_TURRET = 6,
            A_DIVE = 7, A_SPIDER = 8, A_GHOST = 9;
    static final int T_SLUG = 0, T_BAT = 1, T_BEETLE = 2, T_MOLE = 3, T_ORB = 4, T_FROG = 5, T_POD = 6, T_BIRD = 7,
            T_SPIDER = 8, T_GHOST = 9, T_KNIGHT = 10, T_QUAD = 11, T_FISH = 12, T_SHROOM = 13, T_EYE = 14;

    static class Kind {
        final String id, name, desc, tip;
        final int zone, arch, tpl, c1, c2, c3;
        final float hp, dmg, speed, w, h;
        final int bMin, bMax;

        Kind(String id, String name, int zone, int arch, int tpl, int c1, int c2, int c3, float hp, float dmg, float speed,
             int bMin, int bMax, float w, float h, String desc, String tip) {
            this.id = id; this.name = name; this.zone = zone; this.arch = arch; this.tpl = tpl;
            this.c1 = c1; this.c2 = c2; this.c3 = c3; this.hp = hp; this.dmg = dmg; this.speed = speed;
            this.bMin = bMin; this.bMax = bMax; this.w = w; this.h = h; this.desc = desc; this.tip = tip;
        }

        boolean flies() { return arch == A_FLY || arch == A_FLOAT || arch == A_DIVE || arch == A_GHOST || arch == A_SPIDER; }
    }

    static final Kind[] KINDS = {
            // ---- Pradera ----
            new Kind("s", "Babosa", Z_PRADERA, A_WALK, T_SLUG, rgb(96, 192, 96), rgb(16, 32, 16), rgb(176, 240, 176), 20, 10, 1.5f, 2, 4, 0.9f, 0.6f,
                    "Se arrastra de un lado a otro. Lenta, pegajosa y muy cabezota.", "SECRETO: dale por la espalda; se gira tarde y no puede contraatacar."),
            new Kind("b", "Murciélago", Z_PRADERA, A_FLY, T_BAT, rgb(106, 80, 160), rgb(255, 80, 80), 0, 15, 10, 3f, 2, 4, 0.9f, 0.6f,
                    "Vuela en ondas cerca del techo y baja a por ti cuando te ve.", "SECRETO: después de bajar en picado tarda un segundo en volver a subir. ¡Ahí!"),
            new Kind("e", "Escarabajo Roca", Z_PRADERA, A_SHOOT, T_BEETLE, rgb(42, 58, 112), rgb(74, 106, 192), rgb(17, 17, 17), 30, 12, 0.8f, 4, 7, 0.95f, 0.7f,
                    "Camina despacio y lanza piedras en arco cuando te tiene a tiro.", "SECRETO: entre piedra y piedra pasan 2,5 segundos. Cuenta y acércate."),
            // ---- Minas ----
            new Kind("m", "Topo Minero", Z_MINAS, A_CHARGE, T_MOLE, rgb(122, 80, 48), rgb(255, 208, 64), rgb(255, 160, 160), 40, 15, 1.2f, 5, 9, 1.0f, 0.8f,
                    "Cava por las minas. Si te ve en línea recta, embiste a toda velocidad.", "SECRETO: tras embestir se queda aturdido un momento. Golpéalo entonces."),
            new Kind("z", "Chispa", Z_MINAS, A_FLOAT, T_ORB, rgb(255, 230, 120), rgb(255, 160, 40), 0, 25, 12, 1.3f, 4, 7, 0.7f, 0.7f,
                    "Una chispa de cobre viva. Flota y te persigue sin prisa.", "SECRETO: la Trompeta de Brasas las apaga en un instante."),
            new Kind("v", "Murciélago de Cobre", Z_MINAS, A_FLY, T_BAT, rgb(208, 122, 48), rgb(255, 255, 96), 0, 25, 12, 4.5f, 3, 6, 0.9f, 0.6f,
                    "Primo minero del murciélago. Más rápido y más resistente.", "SECRETO: si te quedas quieto en una esquina, pasan de largo."),
            // ---- Lago Helado ----
            new Kind("L1", "Pingüino Patinador", Z_LAGO, A_CHARGE, T_KNIGHT, rgb(30, 30, 40), rgb(240, 240, 250), rgb(255, 170, 40), 30, 12, 1.4f, 4, 8, 0.85f, 0.95f,
                    "Se desliza por el hielo a toda velocidad en cuanto te ve.", "SECRETO: no sabe frenar. Salta y deja que se estrelle contra la pared."),
            new Kind("L2", "Copo Errante", Z_LAGO, A_FLOAT, T_ORB, rgb(230, 245, 255), rgb(140, 200, 255), 0, 24, 10, 1.6f, 4, 7, 0.7f, 0.7f,
                    "Un copo de nieve con malas pulgas. Flota hacia ti y te congela un poco.", "SECRETO: las ondas rebotantes lo deshacen antes de que llegue."),
            new Kind("L3", "Foca de Escarcha", Z_LAGO, A_SHOOT, T_FISH, rgb(150, 170, 200), rgb(60, 70, 90), rgb(255, 255, 255), 38, 12, 0.6f, 5, 9, 1.1f, 0.7f,
                    "Lanza bolas de nieve en arco y aplaude cuando te da.", "SECRETO: mientras aplaude no se mueve. Es tu momento."),
            // ---- Bosque de Hongos ----
            new Kind("H1", "Champiñón Saltarín", Z_HONGOS, A_JUMP, T_SHROOM, rgb(220, 70, 50), rgb(255, 240, 220), rgb(40, 20, 10), 30, 12, 3.5f, 4, 8, 0.85f, 0.85f,
                    "Da saltos enormes hacia donde estés. Muy pesado al caer.", "SECRETO: tarda medio segundo en agacharse antes de cada salto."),
            new Kind("H2", "Espora Flotante", Z_HONGOS, A_FLOAT, T_ORB, rgb(170, 230, 90), rgb(90, 160, 40), 0, 22, 10, 1.4f, 3, 6, 0.6f, 0.6f,
                    "Una bolita de esporas que flota y estornuda sobre ti.", "SECRETO: no atraviesa las plataformas. Ponte encima."),
            new Kind("H3", "Seta Escupidora", Z_HONGOS, A_TURRET, T_POD, rgb(160, 90, 200), rgb(230, 200, 255), rgb(60, 30, 80), 36, 12, 0, 5, 9, 0.9f, 0.9f,
                    "No se mueve, pero escupe esporas en línea recta.", "SECRETO: solo apunta a tu altura. Agáchate en otra plataforma."),
            // ---- Jardín de Espinas ----
            new Kind("J1", "Rosa Trepadora", Z_JARDIN, A_TURRET, T_POD, rgb(200, 40, 70), rgb(60, 140, 60), rgb(255, 200, 220), 40, 14, 0, 5, 10, 0.9f, 0.9f,
                    "Una rosa con muy mal genio que dispara espinas.", "SECRETO: después de 3 espinas se cierra un momento para recargar."),
            new Kind("J2", "Avispa del Rosal", Z_JARDIN, A_DIVE, T_BIRD, rgb(240, 200, 40), rgb(30, 30, 30), rgb(255, 255, 255), 26, 14, 6f, 4, 8, 0.8f, 0.6f,
                    "Se queda quieta en el aire y se lanza en picado contra ti.", "SECRETO: zumba fuerte justo antes de lanzarse."),
            new Kind("J3", "Caracol Espinoso", Z_JARDIN, A_WALK, T_SLUG, rgb(150, 110, 70), rgb(40, 30, 20), rgb(220, 180, 120), 55, 14, 1.0f, 5, 9, 1.0f, 0.7f,
                    "Lento como todos los caracoles, pero su concha pincha.", "SECRETO: la Nota Aguda atraviesa su concha."),
            // ---- Ciudad Sumergida ----
            new Kind("C1", "Guardia de Lluvia", Z_CIUDAD, A_CHARGE, T_KNIGHT, rgb(70, 90, 170), rgb(200, 210, 255), rgb(255, 230, 120), 45, 15, 1.3f, 6, 10, 0.85f, 1.0f,
                    "Patrulla las calles mojadas y carga con su lanza.", "SECRETO: después de cargar se apoya en la lanza para respirar."),
            new Kind("C2", "Medusa del Aire", Z_CIUDAD, A_GHOST, T_GHOST, rgb(200, 130, 255), rgb(120, 60, 200), rgb(255, 255, 255), 30, 14, 1.2f, 5, 9, 0.8f, 0.8f,
                    "Flota a través de las paredes. Su roce da calambre.", "SECRETO: se vuelve transparente cada pocos segundos; espera a que brille."),
            new Kind("C3", "Farolillo Maldito", Z_CIUDAD, A_FLY, T_ORB, rgb(255, 220, 90), rgb(255, 140, 40), 0, 28, 14, 3.5f, 5, 9, 0.7f, 0.7f,
                    "Un farol que se escapó de su poste y ahora persigue a los viajeros.", "SECRETO: la Trompeta de Brasas lo hace estallar."),
            // ---- Cumbres de Cristal ----
            new Kind("K1", "Cristalito", Z_CRISTAL, A_JUMP, T_FROG, rgb(255, 150, 220), rgb(160, 60, 140), rgb(255, 255, 255), 45, 16, 4f, 6, 10, 0.8f, 0.7f,
                    "Un trocito de cristal con patas que salta sin parar.", "SECRETO: al aterrizar brilla; es cuando más daño recibe."),
            new Kind("K2", "Láser de Cuarzo", Z_CRISTAL, A_TURRET, T_EYE, rgb(255, 120, 200), rgb(255, 255, 255), rgb(80, 20, 60), 50, 18, 0, 7, 12, 0.9f, 0.9f,
                    "Un ojo de cuarzo que dispara rayos rapidísimos.", "SECRETO: parpadea dos veces antes de disparar."),
            new Kind("K3", "Murciélago de Amatista", Z_CRISTAL, A_FLY, T_BAT, rgb(170, 90, 230), rgb(255, 120, 255), 0, 38, 16, 5f, 6, 10, 0.9f, 0.6f,
                    "Brilla en la oscuridad y vuela más rápido que ningún otro.", "SECRETO: el Eco Escarcha lo frena en seco."),
            // ---- Acantilados del Viento ----
            new Kind("V1", "Cuervo del Viento", Z_VIENTO, A_DIVE, T_BIRD, rgb(40, 40, 60), rgb(255, 200, 60), rgb(200, 200, 220), 40, 16, 7f, 6, 10, 0.9f, 0.6f,
                    "Planea alto y cae en picado con el viento a favor.", "SECRETO: después del picado se queda en el suelo un segundo."),
            new Kind("V2", "Cabra Montesa", Z_VIENTO, A_CHARGE, T_QUAD, rgb(230, 220, 200), rgb(120, 90, 60), rgb(40, 30, 20), 55, 18, 1.4f, 7, 11, 1.1f, 0.9f,
                    "Embiste con los cuernos y no se rinde nunca.", "SECRETO: si salta un muro detrás de ti, se da la vuelta despacio."),
            new Kind("V3", "Remolino", Z_VIENTO, A_FLOAT, T_ORB, rgb(220, 230, 240), rgb(150, 170, 190), 0, 35, 14, 2.2f, 5, 9, 0.8f, 0.8f,
                    "Un torbellino de aire que gira y empuja.", "SECRETO: se deshace con tres ondas seguidas."),
            // ---- Cementerio de Campanas ----
            new Kind("R1", "Alma en Pena", Z_CEMENTERIO, A_GHOST, T_GHOST, rgb(200, 230, 255), rgb(80, 120, 160), rgb(20, 30, 60), 40, 18, 1.5f, 7, 12, 0.8f, 0.9f,
                    "Atraviesa tumbas y paredes buscando su campana perdida.", "SECRETO: solo se puede golpear cuando es visible."),
            new Kind("R2", "Campanero Esqueleto", Z_CEMENTERIO, A_SHOOT, T_KNIGHT, rgb(230, 220, 200), rgb(90, 80, 70), rgb(255, 200, 80), 55, 18, 0.7f, 8, 13, 0.85f, 1.0f,
                    "Toca una campanita y lanza notas malditas en arco.", "SECRETO: si suenas tu cencerro cerca, se queda escuchando."),
            new Kind("R3", "Gusano de Tumba", Z_CEMENTERIO, A_JUMP, T_SLUG, rgb(200, 150, 140), rgb(80, 50, 40), rgb(255, 230, 220), 50, 18, 4f, 7, 12, 1.0f, 0.6f,
                    "Sale de la tierra de un salto y vuelve a esconderse.", "SECRETO: el montón de tierra avisa de dónde saldrá."),
            // ---- Colmena Dorada ----
            new Kind("A1", "Abeja Obrera", Z_COLMENA, A_DIVE, T_BIRD, rgb(255, 210, 40), rgb(40, 30, 10), rgb(255, 255, 255), 45, 18, 7f, 7, 12, 0.8f, 0.6f,
                    "Trabaja todo el día... y pica a los intrusos.", "SECRETO: siempre vuelve al mismo punto después de picar."),
            new Kind("A2", "Larva de Miel", Z_COLMENA, A_WALK, T_SLUG, rgb(255, 240, 200), rgb(200, 150, 60), rgb(255, 255, 255), 70, 18, 1.2f, 8, 13, 1.0f, 0.6f,
                    "Una larva gordita que deja un rastro pegajoso.", "SECRETO: si la golpeas tres veces seguidas se da la vuelta."),
            new Kind("A3", "Zángano Guardián", Z_COLMENA, A_CHARGE, T_BEETLE, rgb(230, 170, 30), rgb(60, 40, 10), rgb(255, 255, 255), 75, 20, 1.3f, 9, 14, 1.0f, 0.8f,
                    "Custodia las celdas de la reina. Embiste con su aguijón.", "SECRETO: mientras embiste no puede girarse."),
            new Kind("AS", "Hormiga Soldado", Z_COLMENA, A_WALK, T_BEETLE, rgb(120, 50, 30), rgb(220, 180, 120), rgb(20, 10, 5), 60, 18, 1.8f, 0, 2, 0.9f, 0.7f,
                    "Soldado de la Reina Nodriza. Lleva un escudo delante.", "SECRETO: si le das por delante con el cencerro, se confunde y va a por su reina."),
            // ---- Cloacas Reales ----
            new Kind("W1", "Rata de Alcantarilla", Z_CLOACAS, A_CHARGE, T_QUAD, rgb(120, 120, 130), rgb(255, 150, 160), rgb(20, 20, 20), 55, 18, 1.6f, 8, 13, 1.0f, 0.7f,
                    "Corre a ras de suelo y muerde los talones.", "SECRETO: se asusta con el ruido: dispara aunque no le des."),
            new Kind("W2", "Sapo Burbuja", Z_CLOACAS, A_JUMP, T_FROG, rgb(60, 160, 120), rgb(20, 70, 50), rgb(255, 255, 255), 60, 18, 3.5f, 8, 13, 0.9f, 0.7f,
                    "Salta de charco en charco soltando burbujas.", "SECRETO: si le das en el aire cae de espaldas."),
            new Kind("W3", "Anguila de Lodo", Z_CLOACAS, A_FLY, T_FISH, rgb(90, 110, 60), rgb(40, 50, 20), rgb(255, 255, 120), 50, 18, 3.5f, 8, 13, 1.1f, 0.6f,
                    "Nada por el aire húmedo de las cloacas como si fuera agua.", "SECRETO: no puede girar rápido. Rodéala."),
            // ---- Nido Profundo ----
            new Kind("N1", "Araña Colgante", Z_NIDO, A_SPIDER, T_SPIDER, rgb(40, 40, 50), rgb(255, 60, 60), rgb(200, 200, 210), 60, 20, 6f, 9, 14, 0.9f, 0.7f,
                    "Espera colgada del techo y baja de golpe cuando pasas.", "SECRETO: su hilo brilla un poco. Míralo antes de pasar."),
            new Kind("N2", "Ciempiés", Z_NIDO, A_WALK, T_BEETLE, rgb(150, 60, 40), rgb(60, 20, 10), rgb(255, 220, 120), 70, 20, 3.2f, 9, 14, 1.1f, 0.6f,
                    "Corre por el suelo con sus cien patitas. Rapidísimo.", "SECRETO: al llegar a un borde siempre se detiene un instante."),
            new Kind("N3", "Tejedora", Z_NIDO, A_SHOOT, T_SPIDER, rgb(200, 200, 210), rgb(90, 90, 110), rgb(255, 80, 80), 65, 20, 0.6f, 9, 15, 1.0f, 0.7f,
                    "Escupe telarañas pegajosas en arco.", "SECRETO: necesita 3 segundos para tejer otra."),
            // ---- Abismo ----
            new Kind("Z1", "Sombra", Z_ABISMO, A_GHOST, T_GHOST, rgb(30, 30, 40), rgb(200, 200, 230), rgb(255, 255, 255), 80, 24, 2f, 10, 16, 0.85f, 0.95f,
                    "Un trozo de silencio con forma. Atraviesa todo.", "SECRETO: la luz del Farolillo la debilita."),
            new Kind("Z2", "Ojo del Vacío", Z_ABISMO, A_TURRET, T_EYE, rgb(60, 60, 80), rgb(230, 230, 255), rgb(0, 0, 0), 90, 24, 0, 10, 16, 0.9f, 0.9f,
                    "Te mira fijamente desde la oscuridad y dispara.", "SECRETO: cierra el ojo para recargar; ahí no recibe daño."),
            new Kind("Z3", "Polilla Menor", Z_ABISMO, A_FLY, T_BAT, rgb(150, 150, 160), rgb(255, 255, 255), 0, 70, 22, 4.5f, 10, 16, 0.9f, 0.6f,
                    "Una hija de Lumenia. Se come los sonidos.", "SECRETO: va siempre hacia la luz."),
            // ---- Castillo Carmesí ----
            new Kind("X1", "Murciélago Vampiro", Z_CASTILLO, A_FLY, T_BAT, rgb(120, 20, 40), rgb(255, 230, 80), 0, 60, 20, 5f, 9, 14, 0.9f, 0.6f,
                    "Sirviente alado del Conde. Chupa un poquito de lana.", "SECRETO: huye de las ondas rebotantes."),
            new Kind("X2", "Armadura Hechizada", Z_CASTILLO, A_CHARGE, T_KNIGHT, rgb(150, 150, 170), rgb(200, 30, 40), rgb(255, 255, 255), 95, 22, 1.3f, 10, 16, 0.9f, 1.0f,
                    "Una armadura vacía que carga cuando oye pasos.", "SECRETO: por detrás no tiene coraza."),
            new Kind("X3", "Gárgola", Z_CASTILLO, A_DIVE, T_BIRD, rgb(110, 110, 120), rgb(255, 60, 60), rgb(60, 60, 70), 80, 22, 7f, 10, 16, 1.0f, 0.8f,
                    "Una estatua que cobra vida y se lanza en picado.", "SECRETO: al chocar con el suelo se queda de piedra."),
    };

    static final Map<String, Kind> KIND_BY_ID = new HashMap<>();
    static { for (Kind k : KINDS) KIND_BY_ID.put(k.id, k); }

    static Kind kind(String id) { return KIND_BY_ID.get(id); }

    // =====================================================================
    // JEFES (ecos 1–20, opcionales, minijefes de mazmorra y vampiros)
    // =====================================================================
    // movimientos del motor de jefes (EcoBoss)
    static final int MV_CHARGE = 0, MV_SLAM = 1, MV_FAN = 2, MV_RAIN = 3, MV_RING = 4, MV_SUMMON = 5, MV_DIVE = 6,
            MV_TELEPORT = 7, MV_LASER = 8, MV_HOP = 9, MV_MIRROR = 10, MV_VINES = 11;
    // plantillas grandes
    static final int BT_WALRUS = 0, BT_QUEEN = 1, BT_SHROOM = 2, BT_PLANT = 3, BT_KNIGHT = 4, BT_GOLEM = 5, BT_DRAGON = 6,
            BT_BIRD = 7, BT_SPIDER = 8, BT_BELL = 9, BT_MOTH = 10, BT_VAMP = 11, BT_SHEEP = 12, BT_RAT = 13, BT_CENTI = 14, BT_GHOST = 15, BT_SNAIL = 16,
            BT_YETI = 17, BT_DEER = 18, BT_TORTOISE = 19, BT_JELLY = 20, BT_OWL = 21, BT_ARMADILLO = 22, BT_FROGB = 23, BT_ANTQ = 24,
            BT_BULL = 25, BT_WOLF = 26, BT_BEAVER = 27, BT_WOODPECKER = 28, BT_RAM = 29, BT_MOLE = 30, BT_LUMENIA = 31;

    static class Boss {
        final String id, name, desc, tip;
        final int zone, eco, tpl, c1, c2, c3;
        final float hp, dmg, w, h, speed;
        final boolean flyer;
        final int[] moves;
        final String reward;      // emblema que deja (o "")
        final String summon;      // criatura que invoca

        Boss(String id, String name, int zone, int eco, int tpl, int c1, int c2, int c3, float hp, float dmg, float w, float h,
             boolean flyer, float speed, int[] moves, String summon, String reward, String desc, String tip) {
            this.id = id; this.name = name; this.zone = zone; this.eco = eco; this.tpl = tpl; this.c1 = c1; this.c2 = c2; this.c3 = c3;
            this.hp = hp; this.dmg = dmg; this.w = w; this.h = h; this.flyer = flyer; this.speed = speed; this.moves = moves;
            this.summon = summon; this.reward = reward; this.desc = desc; this.tip = tip;
        }
    }

    static int[] mv(int... m) { return m; }

    static final Boss[] BOSSES = {
            // los tres jefes originales tienen su propio código en EcoView
            new Boss("1", "Rey Topo Loco", Z_PRADERA, 1, -1, 0, 0, 0, 260, 15, 1.8f, 1.6f, false, 0, null, "", "",
                    "Señor de la Pradera Hundida. Se esconde bajo tierra y sale disparado.", "SECRETO: cuando sale de la tierra queda expuesto. Muévete en cuanto veas el montículo."),
            new Boss("2", "Vagoneta Fantasma", Z_MINAS, 2, -1, 0, 0, 0, 320, 15, 2.4f, 1.4f, false, 0, null, "", "",
                    "Una vagoneta que corre sola por los raíles, guiada por un fantasma.", "SECRETO: en la segunda mitad pasa dos veces seguidas. Espera la pausa larga."),
            new Boss("3", "Murciégalo Gemelo", Z_MINAS, 0, -1, 0, 0, 0, 150, 12, 1.4f, 1.0f, true, 0, null, "", "garra",
                    "Dos murciélagos que pelean como uno. Uno embiste, el otro chilla.", "SECRETO: si derribas a uno, el otro se enfurece. Bájalos parejos."),
            // ---- ecos 3 a 20 (jefes ideados por el creador de SSS+; cada uno tiene su truco con el cencerro: ver EcoBoss2) ----
            new Boss("B3", "El Titán de Hielo", Z_LAGO, 3, BT_YETI, rgb(220, 240, 255), rgb(120, 170, 220), rgb(40, 60, 90), 650, 16, 2.0f, 2.4f, false, 3f,
                    mv(MV_SLAM, MV_FAN, MV_CHARGE), "", "escarcha",
                    "Un yeti envuelto en placas de hielo denso.", "SECRETO: el sonido continuo de tu cencerro resquebraja su coraza. Si dejas de sonar, se vuelve a congelar."),
            new Boss("B4", "Claudio, el Sapo Cantor", Z_LAGO, 4, BT_FROGB, rgb(70, 150, 110), rgb(30, 60, 40), rgb(250, 250, 250), 720, 18, 2.4f, 1.9f, false, 4f,
                    mv(MV_HOP, MV_FAN, MV_SLAM), "", "",
                    "Un sapo de agallas gigantescas que canta en frecuencias graves. Se protege con un escudo de agua.", "SECRETO: justo después de cada CROAC, haz sonar el cencerro: la frecuencia opuesta rompe su escudo de agua."),
            new Boss("B5", "Sombraverde, el Silvanus", Z_HONGOS, 5, BT_DEER, rgb(90, 110, 60), rgb(60, 40, 20), rgb(180, 230, 120), 780, 18, 2.0f, 2.6f, false, 4f,
                    mv(MV_CHARGE, MV_FAN, MV_SUMMON), "H2", "",
                    "Un ciervo hecho de ramas secas y musgo podrido. Donde pisa, el sonido muere.", "SECRETO: dentro de sus zonas de silencio no le haces nada. Atráelo hacia las piedras del eco."),
            new Boss("B6", "Gargantúa, la Pavorosa", Z_HONGOS, 6, BT_CENTI, rgb(150, 190, 60), rgb(60, 80, 20), rgb(255, 230, 80), 860, 18, 3.2f, 1.4f, false, 3f,
                    mv(MV_FAN, MV_RAIN), "", "",
                    "Una oruga enorme que devora el escenario de abajo a arriba.", "SECRETO: cada repique de tu cencerro hace caer una estalactita sobre su armadura. ¡Sube y repica!"),
            new Boss("B7", "Madame Picadura", Z_JARDIN, 7, BT_QUEEN, rgb(250, 200, 40), rgb(40, 30, 10), rgb(255, 255, 255), 950, 20, 1.8f, 2.0f, true, 3f,
                    mv(MV_DIVE, MV_SUMMON, MV_FAN), "J2", "rosa",
                    "Una reina avispa que controla un enjambre en forma de látigo.", "SECRETO: si tu onda toca el enjambre, se dispersa y la reina queda sin protección."),
            new Boss("B8", "Don Caparazón, el Bastión", Z_CIUDAD, 8, BT_TORTOISE, rgb(80, 110, 70), rgb(150, 120, 80), rgb(220, 190, 110), 1040, 20, 2.8f, 1.9f, false, 1.5f,
                    mv(MV_SLAM, MV_FAN, MV_RAIN), "", "",
                    "Una tortuga de pantano con un campanario en ruinas sobre su lomo.", "SECRETO: cuando se encierre en la concha, súbete a su espalda y haz sonar el cencerro en la campana rota."),
            new Boss("B9", "Coralia, la Medusa del Mar Interior", Z_CIUDAD, 9, BT_JELLY, rgb(255, 140, 200), rgb(150, 80, 220), rgb(255, 255, 255), 1120, 20, 2.0f, 2.2f, true, 2.5f,
                    mv(MV_VINES, MV_RING, MV_FAN), "", "",
                    "Una medusa flotante que vive en una zona sumergida. Bajo el agua todo flota.", "SECRETO: bajo el agua tus ondas son lentas pero enormes, y cada golpe la empuja lejos de sus tentáculos."),
            new Boss("B10", "El Gran Búho Espía", Z_CRISTAL, 10, BT_OWL, rgb(160, 130, 90), rgb(230, 190, 80), rgb(80, 60, 40), 1250, 22, 2.0f, 2.2f, true, 3f,
                    mv(MV_DIVE, MV_LASER, MV_FAN), "", "",
                    "Un búho mecánico con engranajes a la vista. Es ciego, pero lo oye todo.", "SECRETO: ataca donde oyó el último sonido. Haz sonar los gongs de la sala para que sus engranajes le caigan encima."),
            new Boss("B11", "Turo, el Toro de Bronce", Z_CRISTAL, 11, BT_BULL, rgb(200, 140, 60), rgb(120, 70, 30), rgb(255, 230, 150), 1340, 24, 2.6f, 1.8f, false, 6f,
                    mv(MV_CHARGE, MV_CHARGE, MV_SLAM), "", "",
                    "Un toro autómata de bronce en constante embestida.", "SECRETO: si lo golpeas con el cencerro mientras embiste, se desvía y se estrella contra la trampa del otro lado."),
            new Boss("B12", "Barón Grajófono", Z_VIENTO, 12, BT_BIRD, rgb(30, 30, 50), rgb(210, 160, 60), rgb(230, 230, 240), 1400, 22, 2.2f, 1.8f, true, 4f,
                    mv(MV_FAN, MV_DIVE), "V1", "viento",
                    "Un cuervo elegante con un gramófono de bronce en el pecho.", "SECRETO: graba tus repiques y te los devuelve del revés. Si no suenas, no tiene nada que devolverte."),
            new Boss("B13", "Bruma, la Loba de Niebla", Z_CEMENTERIO, 13, BT_WOLF, rgb(200, 210, 230), rgb(90, 100, 130), rgb(255, 255, 255), 1500, 24, 2.2f, 1.6f, false, 7f,
                    mv(MV_CHARGE, MV_HOP, MV_FAN), "", "",
                    "Una loba fantasmal que se divide en tres en la niebla.", "SECRETO: los clones no tienen eco. Haz sonar el cencerro y la de verdad brillará."),
            new Boss("B14", "La Marquesa Polilla", Z_CEMENTERIO, 14, BT_MOTH, rgb(200, 170, 200), rgb(250, 240, 250), rgb(90, 60, 90), 1580, 24, 2.6f, 2.2f, true, 3f,
                    mv(MV_FAN, MV_DIVE, MV_RING), "", "",
                    "Una polilla gigantesca vestida con harapos de tela fina. Su polvo te hipnotiza.", "SECRETO: las vibraciones del cencerro disipan el polvo a tu alrededor: es tu único refugio."),
            new Boss("B15", "Reina Nodriza, la Hormiga Madre", Z_COLMENA, 15, BT_ANTQ, rgb(150, 60, 30), rgb(250, 200, 80), rgb(40, 20, 10), 1680, 24, 2.6f, 2.4f, false, 0,
                    mv(MV_FAN, MV_RAIN), "AS", "miel",
                    "Una hormiga reina gigante e inmóvil que manda oleadas de soldados con escudo.", "SECRETO: el cencerro confunde sus feromonas: las hormigas aturdidas por delante se vuelven contra la reina."),
            new Boss("B16", "Vortex, el Castor Arquitecto", Z_CLOACAS, 16, BT_BEAVER, rgb(140, 90, 50), rgb(230, 200, 150), rgb(200, 200, 210), 1760, 26, 2.2f, 1.7f, false, 4f,
                    mv(MV_FAN, MV_CHARGE, MV_HOP), "", "",
                    "Un castor gigante con prótesis de madera y sierras. Construye barricadas en plena pelea.", "SECRETO: tres repiques sobre una barricada la hacen caer. Si Vortex está al lado, le cae encima."),
            new Boss("B17", "Griselda, la Quimera de Lana", Z_NIDO, 17, BT_SPIDER, rgb(230, 220, 200), rgb(200, 60, 80), rgb(140, 120, 100), 1860, 26, 2.4f, 1.8f, true, 4f,
                    mv(MV_DIVE, MV_FAN, MV_SUMMON), "N1", "",
                    "Una araña tejedora gigante hecha de hilos de lana enredados.", "SECRETO: sus hilos elásticos atrapan tu cencerro y tiran de ti. Esquiva el hilo blanco."),
            new Boss("B18", "Don Baronio, el Patriarca de Escama", Z_NIDO, 18, BT_ARMADILLO, rgb(120, 110, 100), rgb(200, 190, 170), rgb(120, 200, 255), 1960, 28, 2.6f, 1.7f, false, 7f,
                    mv(MV_CHARGE, MV_HOP, MV_RAIN), "", "",
                    "Un armadillo blindado con placas de hierro viejo. Al frotarlas suelta electricidad.", "SECRETO: no lo golpees cuando chisporrotea: tu onda amplifica su campo y te electrocuta."),
            new Boss("B19", "Cabra Sombra, el Reflejo", Z_ABISMO, 19, BT_SHEEP, rgb(20, 20, 30), rgb(200, 200, 255), rgb(255, 255, 255), 2100, 28, 0.9f, 0.95f, false, 7f,
                    mv(MV_MIRROR), "", "",
                    "Una figura espectral con tu silueta, pero distorsionada. Repite todo lo que haces un segundo después.", "SECRETO: sus ondas rebotan y pueden darle a ella misma. Usa tu ritmo para que caiga en sus propios ataques."),
            new Boss("B20", "LUMENIA, la Polilla del Silencio Absoluto", Z_ABISMO, 20, BT_LUMENIA, rgb(30, 25, 40), rgb(190, 190, 230), rgb(240, 240, 255), 5000, 30, 3.2f, 2.6f, true, 5f,
                    mv(MV_FAN, MV_RING, MV_RAIN), "Z3", "",
                    "Una polilla gigantesca de alas de terciopelo negro. En sus capullos plateados guarda todos los sonidos robados del mundo. Solo le falta apagar tu cencerro.",
                    "SECRETO: justo antes de su emboscada, su capullo se abre un instante: haz sonar el cencerro en ese momento. En la segunda fase, repica al ritmo de tu corazón."),
            // ---- minijefes de mazmorra ----
            new Boss("D1", "Goliath, el Pájaro Carpintero", Z_JARDIN, 0, BT_WOODPECKER, rgb(60, 60, 70), rgb(200, 40, 40), rgb(220, 220, 230), 800, 20, 1.6f, 1.6f, true, 3f,
                    mv(MV_FAN, MV_RAIN), "", "roble", "Un ave de pico de titanio integrada en el tronco de un gran árbol. Cuando pica, la gravedad se da la vuelta.", "SECRETO: haz sonar el cencerro justo cuando va a picar: le bloqueas el pico."),
            new Boss("D2", "Ignis, el Herrero de la Pradera", Z_HONGOS, 0, BT_RAM, rgb(50, 40, 40), rgb(255, 120, 30), rgb(255, 220, 120), 720, 20, 2.2f, 1.8f, false, 3f,
                    mv(MV_FAN, MV_SLAM, MV_CHARGE), "", "triple", "Un carnero de carbón ardiente con un fuelle gigante. Calienta el aire de la sala.", "SECRETO: tu cencerro se calienta si lo usas sin parar, pero tus ondas apagan su fuego."),
            new Boss("D3", "Señor Topo, el Barrendero", Z_NIDO, 0, BT_MOLE, rgb(110, 80, 60), rgb(200, 200, 210), rgb(255, 160, 160), 1500, 24, 2.0f, 1.7f, false, 4f,
                    mv(MV_SLAM, MV_HOP, MV_SLAM), "", "acero", "Un topo ciego con garras de acero que viaja bajo tierra y golpea el suelo.", "SECRETO: haz sonar el cencerro en el aire: el impulso sónico te mantiene flotando sobre las grietas."),
            new Boss("D4", "Abejorro Guardián", Z_COLMENA, 0, BT_QUEEN, rgb(250, 190, 40), rgb(30, 30, 30), rgb(255, 255, 255), 1300, 22, 1.8f, 1.8f, true, 4f,
                    mv(MV_DIVE, MV_SUMMON, MV_FAN), "A1", "fenix", "Guarda el tesoro de la colmena desde hace generaciones.", "SECRETO: tras su picado zumba un rato en el suelo."),
            new Boss("D5", "Caballero Hueco", Z_CEMENTERIO, 0, BT_KNIGHT, rgb(60, 60, 70), rgb(230, 230, 240), rgb(255, 255, 255), 1200, 22, 1.4f, 2.0f, false, 5f,
                    mv(MV_CHARGE, MV_TELEPORT, MV_FAN, MV_SLAM), "", "escudo", "Una armadura vacía con una espada de clavo. Nadie sabe quién fue.", "SECRETO: después de teletransportarse tarda en atacar."),
            new Boss("D6", "Larva Devoradora", Z_NIDO, 0, BT_CENTI, rgb(230, 220, 180), rgb(120, 100, 60), rgb(255, 80, 80), 1400, 24, 3.0f, 1.4f, false, 5f,
                    mv(MV_CHARGE, MV_SUMMON, MV_HOP), "N2", "saltoextra", "Se come todo lo que encuentra, incluidas las plataformas.", "SECRETO: después de comer se queda quieta digiriendo."),
            new Boss("D7", "Espejo de Cuarzo", Z_CRISTAL, 0, BT_GOLEM, rgb(200, 230, 255), rgb(120, 160, 220), rgb(255, 255, 255), 1100, 22, 2.0f, 2.2f, false, 2f,
                    mv(MV_LASER, MV_MIRROR, MV_RING), "", "corona", "Un cristal enorme que refleja tus propios ataques.", "SECRETO: el rayo deja un hueco junto al suelo."),
            // ---- secuaces del Conde (código propio en EcoBoss) ----
            new Boss("V1", "Harold Vampis", Z_CASTILLO, 0, BT_VAMP, rgb(40, 40, 50), rgb(230, 220, 200), rgb(200, 20, 30), 1000, 30, 1.2f, 2.0f, false, 9f, null, "", "colmillos",
                    "Secuaz del Conde. Agresivo, salvaje... y bastante torpe. Corre para morderte.", "SECRETO: si choca contra un muro se queda atontado 2 segundos."),
            new Boss("V2", "Aloii Vampis", Z_CASTILLO, 0, BT_VAMP, rgb(60, 20, 80), rgb(255, 230, 210), rgb(255, 210, 60), 1000, 26, 1.2f, 2.0f, true, 7f, null, "", "capa",
                    "El secuaz más guapo (según él). Pasa más tiempo posando que peleando.", "SECRETO: cuanto más se enfada, peor apunta."),
            new Boss("V3", "Planta Carnívora", Z_JARDIN, 0, BT_PLANT, rgb(110, 30, 60), rgb(70, 140, 50), rgb(255, 230, 240), 1000, 28, 3.0f, 5.0f, false, 0, null, "", "",
                    "Una planta enorme que asoma entre las ruinas antiguas. Algo brilla detrás de ella.", "SECRETO: sus tallos salen en línea recta a una de las tres alturas."),
            new Boss("V4", "Sangre Joven", Z_CASTILLO, 0, BT_VAMP, rgb(120, 20, 30), rgb(255, 220, 200), rgb(255, 255, 255), 1000, 28, 0.9f, 1.3f, false, 6f, null, "", "botas_vamp",
                    "Es pequeño, pero no te fíes: intenta caerte encima.", "SECRETO: si cae y no estás debajo, se queda aturdido 2 segundos."),
            new Boss("V5", "Conde Vampis", Z_CASTILLO, 0, BT_VAMP, rgb(20, 10, 20), rgb(240, 230, 230), rgb(200, 10, 30), 3500, 25, 1.4f, 2.4f, false, 8f, null, "X1", "vial",
                    "Señor del Castillo Carmesí. Conoce todos los trucos de sus secuaces.", "SECRETO: con las Garras equipadas pelea cuerpo a cuerpo: lento, pero cada golpe quita 25."),
    };

    static final Map<String, Boss> BOSS_BY_ID = new HashMap<>();
    static { for (Boss b : BOSSES) BOSS_BY_ID.put(b.id, b); }

    static Boss boss(String id) { return BOSS_BY_ID.get(id); }

    static Boss bossForEco(int eco) {
        for (Boss b : BOSSES) if (b.eco == eco) return b;
        return null;
    }

    // =====================================================================
    // EMBLEMAS (hasta 12 a la vez, se cambian descansando en un fardo)
    // =====================================================================
    static final int MAX_EQUIP = 12;
    static final int M_HP = 0, M_ATK = 1, M_DMG = 2, M_STEAL = 3, M_EVADE = 4, M_REDUCE = 5, M_SPEED = 6, M_JUMP = 7,
            M_HEALSPD = 8, M_HEALAMT = 9, M_LANA = 10, M_BELLS = 11, M_MAGNET = 12, M_RANGE = 13, M_RATE = 14, M_SHOTS = 15,
            M_PIERCE = 16, M_BOUNCE = 17, M_CRIT = 18, M_THORNS = 19, M_REGEN = 20, M_INVUL = 21, M_FURY = 22, M_BOSS = 23,
            M_TROMP = 24, M_DASHDMG = 25, M_GLIDE = 26, M_FROST = 27, M_LUCK = 28, M_PHOENIX = 29, M_SHIELD = 30,
            M_AIRJUMP = 31, M_OWL = 32, M_LIGHT = 33, M_COMPASS = 34, M_KEEP = 35, M_CLAWS = 36, M_FAN3 = 37,
            M_WAVEDMG = 38, M_HOMING = 39, M_ECHO = 40;
    static final int NM = 41;

    static class Emblem {
        final String id, name, desc;
        final int price;           // 0 = no se vende
        final float[] m = new float[NM];
        final boolean vamp;

        Emblem(String id, String name, String desc, int price, boolean vamp, float... mods) {
            this.id = id; this.name = name; this.desc = desc; this.price = price; this.vamp = vamp;
            for (int i = 0; i + 1 < mods.length; i += 2) m[(int) mods[i]] = mods[i + 1];
        }
    }

    static final Emblem[] EMBLEMS = {
            new Emblem("corazon", "Corazón de Lana", "+40 de vida máxima", 150, false, M_HP, 40),
            new Emblem("iman", "Imán de Cascabeles", "Atrae los cascabeles cercanos", 120, false, M_MAGNET, 1),
            new Emblem("dobleeco", "Doble Eco", "Disparas dos ondas a la vez", 300, false, M_SHOTS, 1),
            new Emblem("pezuna", "Pezuña Ligera", "Saltas un 8 % más alto", 200, false, M_JUMP, 8),
            new Emblem("garra", "Garra Gemela", "+20 % de daño", 0, false, M_DMG, 20),
            new Emblem("corazon2", "Corazón Doble", "+60 de vida máxima", 400, false, M_HP, 60),
            new Emblem("roble", "Corazón de Roble", "+100 de vida máxima, pero 10 % más lenta", 0, false, M_HP, 100, M_SPEED, -10),
            new Emblem("gorro", "Gorro de Lana", "+20 de vida y 5 % de esquivar golpes", 180, false, M_HP, 20, M_EVADE, 5),
            new Emblem("lanarapida", "Lana Rápida", "Te curas un 40 % más rápido", 220, false, M_HEALSPD, 40),
            new Emblem("lanagorda", "Ovillo Gordo", "Cada curación da un 50 % más de vida", 260, false, M_HEALAMT, 50),
            new Emblem("lanaextra", "Esquilador", "Ganas el doble de lana al golpear", 0, false, M_LANA, 1),
            new Emblem("pesado", "Cencerro Pesado", "+30 % de daño, pero 10 % más lenta", 350, false, M_DMG, 30, M_SPEED, -10),
            new Emblem("lejano", "Eco Lejano", "Tus ondas llegan un 60 % más lejos", 200, false, M_RANGE, 60),
            new Emblem("veloz", "Eco Veloz", "Disparas un 30 % más rápido", 380, false, M_RATE, 30),
            new Emblem("triple", "Eco Triple", "Disparas tres ondas en abanico", 0, false, M_FAN3, 1),
            new Emblem("lince", "Ojo de Lince", "15 % de golpes críticos (daño doble)", 300, false, M_CRIT, 15),
            new Emblem("piedra", "Piel de Piedra", "Recibes un 15 % menos de daño", 320, false, M_REDUCE, 15),
            new Emblem("acero", "Lana de Acero", "Recibes un 25 % menos de daño, pero 15 % más lenta", 0, false, M_REDUCE, 25, M_SPEED, -15),
            new Emblem("rosa", "Espinas de Rosa", "Quien te toque recibe 40 de daño", 0, false, M_THORNS, 40),
            new Emblem("fantasma", "Paso Fantasma", "Más tiempo invulnerable tras un golpe", 250, false, M_INVUL, 0.6f),
            new Emblem("trebol", "Trébol", "+25 % de cascabeles", 200, false, M_BELLS, 25),
            new Emblem("bolsa", "Bolsa sin Fondo", "Al desmayarte solo pierdes la mitad de los cascabeles", 300, false, M_KEEP, 1),
            new Emblem("brujula", "Brújula del Pastor", "El mapa muestra los secretos (?) sin comprarlo", 120, false, M_COMPASS, 1),
            new Emblem("farolillo", "Farolillo", "Ilumina las zonas oscuras (Nido y Abismo)", 150, false, M_LIGHT, 1),
            new Emblem("viento", "Botas de Viento", "+15 % de velocidad", 0, false, M_SPEED, 15),
            new Emblem("pluma", "Pluma de Cuervo", "Mantén ⬆ en el aire para planear", 0, false, M_GLIDE, 1),
            new Emblem("escarcha", "Eco Escarcha", "Tus ondas congelan y frenan a los enemigos", 0, false, M_FROST, 1),
            new Emblem("brasas", "Chispa de Brasas", "La Trompeta hace un 50 % más de daño", 0, false, M_TROMP, 50),
            new Emblem("miel", "Miel Real", "Recuperas 2 de vida cada 3 segundos", 0, false, M_REGEN, 2),
            new Emblem("suerte", "Cascabel de la Suerte", "Los cofres dan el doble", 0, false, M_LUCK, 1),
            new Emblem("fenix", "Pluma de Fénix", "Una vez por descanso, vuelves con media vida al caer", 0, false, M_PHOENIX, 1),
            new Emblem("furia", "Furia del Rebaño", "+40 % de daño con menos del 30 % de vida", 280, false, M_FURY, 40),
            new Emblem("escudo", "Escudo de Lana", "Bloquea un golpe cada 20 segundos", 0, false, M_SHIELD, 1),
            new Emblem("saltoextra", "Salto Bendito", "Un salto más en el aire (necesita las botas)", 0, false, M_AIRJUMP, 1),
            new Emblem("embardiente", "Embestida Ardiente", "Tu embestida quema a los enemigos", 0, false, M_DASHDMG, 1),
            new Emblem("perforante", "Eco Perforante", "Las ondas atraviesan a los enemigos", 420, false, M_PIERCE, 1),
            new Emblem("rebote", "Eco Rebotante", "Las ondas rebotan dos veces en las paredes", 360, false, M_BOUNCE, 2),
            new Emblem("corona", "Corona del Topo", "+25 % de daño a los jefes", 0, false, M_BOSS, 25),
            new Emblem("buho", "Vista de Búho", "Las paredes falsas brillan un poco", 0, false, M_OWL, 1),
            // ---- SET VAMPÍRICO ----
            new Emblem("colmillos", "Colmillos de Bestia Nocturna", "+5 de ataque y 5 % de robo de vida", 0, true, M_ATK, 5, M_STEAL, 5),
            new Emblem("capa", "Capa del Conde", "+45 % de daño, pero −20 de vida máxima", 0, true, M_DMG, 45, M_HP, -20),
            new Emblem("garras", "Garras Vampíricas", "+6 de ataque y 25 % de robo de vida. Cambia el cencerro por zarpazos", 0, true, M_ATK, 6, M_STEAL, 25, M_CLAWS, 1),
            new Emblem("botas_vamp", "Botas de Chupasangre", "25 % de esquivar golpes", 0, true, M_EVADE, 25),
            new Emblem("vial", "Vial de Sangre Pura", "+100 de vida, +12 de ataque, −12 % de daño recibido y 12 % de robo de vida", 0, true,
                    M_HP, 100, M_ATK, 12, M_REDUCE, 12, M_STEAL, 12),
            // ---- SET DE LA SINFONÍA (Coliseo del Eco) ----
            new Emblem("sin_cencerro", "Cencerro Resonante", "+35 % de daño de las ondas", 0, false, M_WAVEDMG, 35),
            new Emblem("sin_diapason", "Diapasón del Abismo", "Las ondas atraviesan y vuelven a sonar al chocar con la pared", 0, false, M_PIERCE, 1, M_BOUNCE, 1),
            new Emblem("sin_gemela", "Campana Gemela", "Disparas una onda más", 0, false, M_SHOTS, 1),
            new Emblem("sin_oido", "Oído Infinito", "+50 % de alcance y las ondas buscan al enemigo", 0, false, M_RANGE, 50, M_HOMING, 1),
            new Emblem("sin_corazon", "Corazón de Eco", "Cada onda repite su golpe medio segundo después", 0, false, M_ECHO, 1),
    };

    /** Set de la Sinfonía: completo, cada 5.º disparo es una onda gigante... pero 5 s sin sonar te quitan vida. */
    static final String[] SYM_SET = {"sin_cencerro", "sin_diapason", "sin_gemela", "sin_oido", "sin_corazon"};
    static final String[] SYM_SET_DONE = {"Llevas puesto el SET DE LA SINFONÍA completo.",
            "Cada quinto toque suena como una catedral entera... y si dejas de sonar, el silencio te duele."};

    static final String[] VAMP_SET = {"colmillos", "capa", "garras", "botas_vamp", "vial"};

    static final Map<String, Emblem> EMBLEM_BY_ID = new HashMap<>();
    static { for (Emblem e : EMBLEMS) EMBLEM_BY_ID.put(e.id, e); }

    static Emblem emblem(String id) { return EMBLEM_BY_ID.get(id); }


    // =====================================================================
    // COLISEO DEL ECO: 25 titanes (5 tandas de 5), 2500 de vida, mezclas de los mejores ataques
    // =====================================================================
    static final Boss[] TITANS = {
            titan(1, "Brutus, el Yeti de Hierro", BT_YETI, rgb(180, 190, 210), rgb(90, 100, 130), rgb(255, 120, 60), false, 4f, MV_SLAM, MV_CHARGE, MV_FAN),
            titan(2, "Rana Trueno", BT_FROGB, rgb(60, 200, 220), rgb(20, 70, 90), rgb(255, 255, 120), false, 5f, MV_HOP, MV_RING, MV_SLAM),
            titan(3, "Astado Carmín", BT_DEER, rgb(170, 40, 50), rgb(60, 20, 20), rgb(255, 200, 120), false, 6f, MV_CHARGE, MV_FAN, MV_HOP),
            titan(4, "Avispa Verdugo", BT_QUEEN, rgb(120, 230, 90), rgb(20, 40, 20), rgb(255, 60, 60), true, 4f, MV_DIVE, MV_FAN, MV_RAIN),
            titan(5, "Muralla Andante", BT_TORTOISE, rgb(110, 110, 120), rgb(200, 160, 90), rgb(255, 230, 150), false, 2.5f, MV_SLAM, MV_RAIN, MV_LASER),
            titan(6, "Medusa Relámpago", BT_JELLY, rgb(255, 240, 90), rgb(120, 60, 220), rgb(255, 255, 255), true, 3f, MV_RING, MV_LASER, MV_DIVE),
            titan(7, "Búho Fantasma", BT_OWL, rgb(200, 210, 240), rgb(80, 90, 140), rgb(120, 255, 255), true, 4f, MV_TELEPORT, MV_LASER, MV_FAN),
            titan(8, "Minotauro Dorado", BT_BULL, rgb(255, 200, 60), rgb(140, 90, 20), rgb(255, 255, 220), false, 7f, MV_CHARGE, MV_SLAM, MV_CHARGE, MV_RING),
            titan(9, "Cuervo Tormenta", BT_BIRD, rgb(60, 60, 110), rgb(140, 200, 255), rgb(255, 255, 255), true, 5f, MV_DIVE, MV_RAIN, MV_FAN),
            titan(10, "Loba Sombría", BT_WOLF, rgb(50, 40, 70), rgb(200, 60, 200), rgb(255, 200, 255), false, 8f, MV_CHARGE, MV_TELEPORT, MV_HOP),
            titan(11, "Polilla Escarlata", BT_MOTH, rgb(220, 60, 70), rgb(255, 220, 200), rgb(90, 20, 30), true, 4f, MV_RING, MV_DIVE, MV_RAIN),
            titan(12, "Hormiga Coloso", BT_ANTQ, rgb(60, 60, 60), rgb(255, 120, 40), rgb(255, 230, 80), false, 3f, MV_RAIN, MV_FAN, MV_LASER),
            titan(13, "Castor Demoledor", BT_BEAVER, rgb(170, 80, 40), rgb(240, 220, 180), rgb(160, 200, 255), false, 6f, MV_CHARGE, MV_HOP, MV_SLAM, MV_FAN),
            titan(14, "Viuda de Seda", BT_SPIDER, rgb(30, 30, 40), rgb(255, 40, 70), rgb(240, 240, 240), true, 5f, MV_DIVE, MV_RING, MV_TELEPORT),
            titan(15, "Armadillo Voltaico", BT_ARMADILLO, rgb(90, 120, 160), rgb(220, 240, 255), rgb(120, 220, 255), false, 8f, MV_CHARGE, MV_LASER, MV_HOP),
            titan(16, "Caballero Negro", BT_KNIGHT, rgb(30, 30, 35), rgb(255, 80, 60), rgb(255, 220, 160), false, 6f, MV_TELEPORT, MV_CHARGE, MV_SLAM, MV_FAN),
            titan(17, "Gólem de Obsidiana", BT_GOLEM, rgb(40, 30, 50), rgb(255, 100, 40), rgb(255, 200, 80), false, 3f, MV_SLAM, MV_LASER, MV_RAIN, MV_RING),
            titan(18, "Carnero Volcán", BT_RAM, rgb(80, 20, 20), rgb(255, 140, 30), rgb(255, 240, 160), false, 7f, MV_CHARGE, MV_FAN, MV_SLAM, MV_RAIN),
            titan(19, "Dragón de Bronce", BT_DRAGON, rgb(200, 130, 60), rgb(255, 220, 120), rgb(255, 80, 40), true, 5f, MV_FAN, MV_DIVE, MV_RAIN, MV_RING),
            titan(20, "Topo Titán", BT_MOLE, rgb(120, 90, 70), rgb(220, 220, 230), rgb(255, 80, 80), false, 6f, MV_HOP, MV_SLAM, MV_CHARGE, MV_LASER),
            titan(21, "Pájaro Martillo", BT_WOODPECKER, rgb(40, 40, 60), rgb(255, 210, 40), rgb(255, 255, 255), true, 6f, MV_DIVE, MV_LASER, MV_RING, MV_FAN),
            titan(22, "Ciervo Espectral", BT_DEER, rgb(180, 255, 230), rgb(40, 120, 110), rgb(255, 255, 255), false, 8f, MV_TELEPORT, MV_CHARGE, MV_RING, MV_RAIN),
            titan(23, "Reina del Enjambre", BT_QUEEN, rgb(255, 120, 200), rgb(60, 10, 40), rgb(255, 240, 120), true, 6f, MV_DIVE, MV_RAIN, MV_RING, MV_TELEPORT),
            titan(24, "Yeti del Abismo", BT_YETI, rgb(40, 40, 70), rgb(140, 120, 255), rgb(255, 255, 255), false, 7f, MV_SLAM, MV_CHARGE, MV_LASER, MV_RING, MV_FAN),
            titan(25, "EL CAMPEÓN ETERNO", BT_DRAGON, rgb(250, 250, 255), rgb(255, 200, 40), rgb(80, 220, 255), true, 7f, MV_DIVE, MV_RING, MV_LASER, MV_RAIN, MV_TELEPORT, MV_FAN),
    };

    static Boss titan(int n, String name, int tpl, int c1, int c2, int c3, boolean flyer, float speed, int... moves) {
        float big = n == 25 ? 1.25f : 1f;
        float w = (tpl == BT_TORTOISE || tpl == BT_BEAVER || tpl == BT_ARMADILLO || tpl == BT_BULL || tpl == BT_FROGB) ? 2.4f : tpl == BT_ANTQ || tpl == BT_DRAGON ? 2.6f : 2.0f;
        float h = tpl == BT_YETI || tpl == BT_DEER || tpl == BT_GOLEM || tpl == BT_ANTQ ? 2.4f : 2.0f;
        return new Boss("T" + n, name, Z_CEMENTERIO, 0, tpl, c1, c2, c3, 2500, 30 + n * 0.6f, w * big, h * big, flyer, speed, moves, "", "",
                "Titán del Coliseo del Eco n.º " + n + ".", "SECRETO: entre ataque y ataque se queda quieto un instante. Ahí es cuando más le duele.");
    }

    static final String[] PRESENTADOR = {
            "¡Damas y caballeros, ovejas y corderos! ¡Bienvenida al COLISEO DEL ECO!",
            "Aquí pelean los TITANES: 25 bestias, 5 tandas de 5. Salen de una en una.",
            "Cada tanda que ganes te dará una pieza del legendario SET DE LA SINFONÍA.",
            "Puedes retirarte cuando quieras desde la pausa. ¡Pero el público quiere SANGRE... digo, ESPECTÁCULO!"
    };
    static final String[] PRESENTADOR_PUERTA = {"Una enorme puerta AZUL con un cencerro grabado. Detrás se oye un rugido de público.",
            "Necesitas una LLAVE AZUL (1000 🔔). Dicen que la Agente Garduña tiene una... muy bien guardada."};
    static final String[] PRESENTADOR_ABRE = {"🔷 La llave azul gira. La puerta del COLISEO DEL ECO se abre con un estruendo de aplausos."};
    static final String[] PRESENTADOR_CAMPEONA = {"¡LA CAMPEONA! ¡LA LEYENDA! Ya tienes el Set de la Sinfonía entero.",
            "El público aún corea tu nombre. Vuelve cuando quieras... aunque ya no queda nadie a quien ganar."};
    static final String[] PRESENTADOR_RONDA = {"¡INCREÍBLE! ¡Ha caído el quinto titán!", "Como prometí, aquí tienes tu premio: ¡una pieza del SET DE LA SINFONÍA!"};

    // =====================================================================
    // FINALES Y LOGROS (v0.8)
    // =====================================================================
    static final String[] LAMBS_ARRIVE = {"¡Clin, clin, clin! Se oyen cencerros a lo lejos...", "¡LOS 5 CORDERITOS han venido a ayudarte!"};
    static final String[] FINAL_CANON = {
            "En el último momento, los cinco corderitos llegan corriendo con sus cencerros.",
            "Todas las ovejas suenan a la vez. El núcleo de Lumenia colapsa por exceso de armonía pura.",
            "Campanas, grillos, risas, balidos... todos los sonidos robados vuelven al mundo.",
            "Lanaria entera celebra: hay fiesta en cada aldea, y Bee y sus corderitos bailan hasta el amanecer.",
            "★ FINAL VERDADERO: EL REBAÑO UNIDO ★  Gracias por jugar a EL PASTOR DE ECOS."
    };
    static final String[] FINAL_SACRIFICIO = {
            "El núcleo de Lumenia colapsa... pero Bee ha dado todo su sonido en el último repique.",
            "El eco definitivo recorre Lanaria. Los sonidos vuelven al mundo. Bee no se levanta.",
            "Meses después, en Eco Hondo, se alza una estatua: una gran oveja con su cencerro.",
            "Todos los animales le traen rosas y celebran a la heroína que les devolvió la voz.",
            "★ FINAL DEL SACRIFICIO: PASTOR TEMERARIO ★  (Con los 5 corderitos, quizá no habrías estado sola...)"
    };
    static final String[] FINAL_ADICTO = {
            "Los ecos giran a tu alrededor. Los puedes soltar... pero suenan TAN bien.",
            "Bee se los queda. Crece. Su lana se vuelve negra y su cencerro, enorme.",
            "Ahora es Bee quien guarda todos los sonidos del mundo. Es el nuevo jefe del silencio.",
            "En una aldea triste y callada, una ovejita recién nacida abre los ojos. Lleva un cencerro.",
            "★ FINAL SECRETO Nº 2: ADICTO AL ECO ★"
    };
    static final String[] SYM_CHOICE = {"Los 20 ecos flotan a tu alrededor. El Set de la Sinfonía vibra: QUIERE quedárselos."};

    // id, nombre, cómo se consigue
    static final String[][] ACHIEVEMENTS = {
            {"rebano", "El Rebaño Unido", "Vence a LUMENIA con los 5 corderitos (final verdadero)."},
            {"temerario", "Pastor Temerario", "Vence a LUMENIA sin los 5 corderitos."},
            {"sangre", "Débil por la sangre", "Final secreto n.º 1. Hay quien dice que cierto traje te cambia..."},
            {"adicto", "Adicto al Eco", "Final secreto n.º 2. Algo que suena demasiado bien..."},
            {"coliseo", "Campeona del Coliseo", "Vence a los 25 titanes del Coliseo del Eco."},
    };

    // Mapa de los Secuaces (Agente Garduña): quién hay detrás de cada puerta carmesí
    static final String MINION_MAP_TEXT = "Marca cada puerta carmesí 🩸 del mapa con el secuaz que hay detrás.";

    // =====================================================================
    // HABILIDADES (permanentes; no ocupan hueco)
    // =====================================================================
    static final String AB_DJ = "dj", AB_TROMP = "tromp", AB_DASH = "dash", AB_WALL = "wall", AB_CHARGE = "charge", AB_MIRROR = "mirror";
    static final String[] ABILITIES = {AB_DJ, AB_TROMP, AB_DASH, AB_WALL, AB_CHARGE, AB_MIRROR};
    static final String[] ABILITY_NAMES = {"Botas de Doble Salto", "Trompeta de Brasas", "Embestida", "Pezuñas Trepadoras", "Eco Cargado", "Eco Espejo"};
    static final String[][] ABILITY_TEXT = {
            {"¡BOTAS DE DOBLE SALTO! Pulsa ⬆ otra vez en el aire para saltar de nuevo."},
            {"¡Has encontrado la TROMPETA DE BRASAS! 🔥", "Mantén 🔔 para soltar una llamarada de corto alcance. Cambia de arma con ⇄."},
            {"¡EMBESTIDA! 💨", "Pulsa 💨 para lanzarte hacia delante. Mientras embistes, nada te hace daño."},
            {"¡PEZUÑAS TREPADORAS! 🧗", "Pégate a una pared en el aire y pulsa ⬆ para saltar desde ella."},
            {"¡ECO CARGADO! ✨", "Mantén 🔔 un segundo y suéltalo: sale una onda enorme que atraviesa todo y hace el triple de daño."},
            {"¡ECO ESPEJO! 🪞", "Ahora tus ondas deshacen los disparos de los enemigos."},
    };

    // dónde está cada habilidad (zona del mundo generado; las dos primeras están en salas hechas a mano)
    static final String[][] ABILITY_SPOTS = {{AB_DASH, "L"}, {AB_WALL, "H"}, {AB_CHARGE, "C"}, {AB_MIRROR, "K"}};
    // emblemas escondidos en cofres especiales
    static final String[][] EMBLEM_SPOTS = {{"lanaextra", "L"}, {"brasas", "H"}, {"buho", "J"}, {"pluma", "V"}, {"suerte", "W"}, {"embardiente", "A"}};

    // =====================================================================
    // TIENDAS
    // =====================================================================
    // Sapo Mercader: id de tienda -> emblemas que vende
    static final String[][] SHOPS = {
            {"corazon", "iman", "dobleeco", "pezuna", "gorro", "trebol", "farolillo"},      // 0: Eco Hondo
            {"lanarapida", "lejano", "fantasma", "brujula"},                                 // 1: Lago
            {"corazon2", "pesado", "lince", "bolsa"},                                        // 2: Ciudad
            {"veloz", "piedra", "furia", "lanagorda"},                                       // 3: Cristal
            {"perforante", "rebote"},                                                        // 4: Cementerio
    };
    static final String[] SHOP_ZONE = {"", "L", "C", "K", "R"};

    // Herrera: 10 niveles de cencerro
    static final int MAX_CLVL = 10;
    static final int[] FORGE_BELLS = {0, 100, 250, 450, 700, 1000, 1400, 1900, 2500, 3200};
    static final int[] FORGE_ORE = {0, 0, 1, 1, 2, 2, 3, 3, 4, 5};

    // Policía corrupta
    static final int KEY_PRICE = 180, CRIMSON_PRICE = 500, BLUE_PRICE = 1000, MINION_MAP_PRICE = 400;
    static int mapPrice(int zone) { return 60 + ZONES[zone].tier * 25; }

    // Equilibrio del jugador
    static final int BASE_HP = 100;
    static float waveBase(int lvl) { return 10 + 5 * (lvl - 1); }

    /** Dificultad según la distancia al inicio (en salas). */
    static float hpScale(float dist) { return 1 + 0.17f * dist; }
    static float dmgScale(float dist) { return 1 + 0.08f * dist; }

    // =====================================================================
    // TEXTOS NUEVOS
    // =====================================================================
    static final String[] POLICIA = {
            "Alto ahí, ovejita. Agente Garduña, de la Policía de Lanaria. ¿Papeles? Bah, da igual.",
            "Mira, entre tú y yo: confisqué unos MAPAS y unas LLAVES de mazmorras secretas. Te los dejo baratos... más o menos.",
            "Las llaves CARMESÍ son otra cosa. Abren las guaridas de los secuaces del Conde. 500 cascabeles y no me has visto."
    };
    static final String[] POLICIA_AGAIN = {"Garduña aquí. ¿Vienes a comprar o a mirar? Mirar también cuesta."};
    static final String[] SAPO2 = {"Croac. Emblemas, emblemas. Puedes llevar hasta 12, pero solo se cambian descansando en un fardo. Croac."};
    static final String[] PUERTA_LLAVE = {"Una puerta cerrada con una cerradura oxidada.", "Necesitas una LLAVE DE MAZMORRA. La Agente Garduña vende algunas... bajo cuerda."};
    static final String[] PUERTA_CARMESI = {"Una puerta de hierro negro con un murciélago grabado.", "Necesitas una LLAVE CARMESÍ (500 🔔). Pregunta a la Agente Garduña."};
    static final String[] CASTILLO_CERRADO = {"La puerta del CASTILLO CARMESÍ no se mueve.", "Dicen que solo se abre para quien reúna las cuatro reliquias de los secuaces del Conde."};
    static final String[] CASTILLO_ABIERTO = {"Un escalofrío recorre tu lana...", "Has reunido las cuatro reliquias. En el mapa ha aparecido el CASTILLO CARMESÍ, en lo alto de las Cumbres."};
    static final String[] GARRAS_PREGUNTA = {
            "Entre las zarzas hay un cadáver vampírico. En sus manos huesudas brillan unas GARRAS.",
            "Si te las pones, tu cencerro dejará de sonar: pelearás a zarpazos."
    };
    static final String[] GARRAS_SI = {"Te pones las GARRAS VAMPÍRICAS. Sientes frío... y hambre.", "(Puedes quitártelas descansando en un fardo.)"};
    static final String[] GARRAS_NO = {"Te guardas las garras en la lana. Podrás equiparlas descansando en un fardo."};

    static final String[] HAROLD_IN = {"¡GRRRAAAH! ¡HAROLD TIENE HAMBRE!", "¡Harold muerde ovejita! ¡Harold corre MUCHO!"};
    static final String[] HAROLD_WIN = {"Harold se tambalea, choca contra la pared por última vez y suelta algo...",
            "Has conseguido los COLMILLOS DE BESTIA NOCTURNA. (+5 ataque, 5 % robo de vida)"};
    static final String[] ALOII_IN = {"Oh. Una ovejita. Qué... vulgar.", "Contempla, criatura: soy ALOII VAMPIS, el más bello de los servidores del Conde."};
    static final String[] ALOII_POSES = {"¡Mírame bien!", "¡Qué perfil tan perfecto!", "¿Has visto esta capa?", "Ni el Conde es tan guapo.",
            "¡Admírame!", "Mi pelo... impecable.", "¿Te deslumbro? Es normal."};
    static final String[] ALOII_RAGE = {"¡¡MI TRAJE!! ¡¡ME HAS RASGADO EL TRAJE!!"};
    static final String[] ALOII_FLEE = {"¡¡NOOO!! ¡¡MI ROPA!! ¡¡TODOS ME VEN EN CALZONCILLOS!!",
            "Aloii te tira su capa a la cara y huye llorando. No volverá jamás.",
            "Has conseguido la CAPA DEL CONDE. (+45 % daño, −20 vida)"};
    static final String[] PLANTA_WIN = {"La Planta Carnívora se marchita entre las ruinas.", "Detrás de ella, el camino sigue..."};
    static final String[] SANGRE_IN = {"¡Eh, tú! ¡Sí, tú, la de la lana!", "Soy SANGRE JOVEN. Seré pequeño, ¡pero caigo fuerte!"};
    static final String[] SANGRE_WIN = {"Sangre Joven se queda aturdido para siempre... bueno, un buen rato.",
            "Has conseguido las BOTAS DE CHUPASANGRE. (25 % de esquivar)"};
    static final String[] CONDE_IN = {"Así que tú eres la ovejita que ha humillado a mis siervos...",
            "Soy el CONDE VAMPIS. Llevo siglos esperando un cuello tan... lanudo.", "¡Que empiece el baile!"};
    static final String[] CONDE_IN_GARRAS = {"Esas garras... ¿Te atreves a usar mis armas contra mí?",
            "Muy bien. Entonces pelearemos como bestias. Cuerpo a cuerpo."};
    static final String[] CONDE_WIN = {"El Conde Vampis se deshace en una nube de murciélagos...",
            "Entre la ceniza queda un frasco brillante: el VIAL DE SANGRE PURA.",
            "(+100 vida, +12 ataque, −12 % daño recibido, 12 % robo de vida)"};
    static final String[] VAMP_SET_DONE = {"Llevas puesto el SET VAMPÍRICO completo.", "Algo dentro de ti ha cambiado..."};

    static final String[] FINAL_NORMAL = {
            "El núcleo de Lumenia colapsa por exceso de armonía pura. Sus alas de sombra se desintegran.",
            "Bee hace sonar su cencerro una última vez: un eco definitivo que recorre todo Lanaria.",
            "Campanas, grillos, risas, balidos... todos los sonidos robados vuelven al mundo.",
            "Has recuperado los 20 ECOS. El valle vuelve a cantar.",
            "★ FIN ★  Gracias por jugar a EL PASTOR DE ECOS."
    };
    static final String[] FINAL_VAMP = {
            "Bee se detiene ante la guarida de Lumenia.",
            "Todo se vuelve rojo. Ve sombras. Ve colmillos. Oye una voz que no es suya.",
            "Algo rompe su lana por la espalda: dos alas negras se abren.",
            "La ovejita ya no busca ecos. Busca sangre.",
    };
    static final String[] FINAL_VAMP_2 = {
            "Esa noche, en Eco Hondo, nadie durmió.",
            "Una sombra alada cayó sobre la aldea. Los vecinos huyeron gritando.",
            "Bee se había convertido en un vampiro malvado.",
            "★ FINAL SECRETO Nº 1: LA OVEJA CARMESÍ ★",
            "¡Felicidades! Has completado EL PASTOR DE ECOS con el set vampírico."
    };
}
