package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * PACK RETRO REMASTERIZADO (v0.8): los juegos de las maquinitas "Brick Game" rehechos a color,
 * con neón, partículas, música propia que se acelera con la dificultad y un modo "como antes"
 * (pantalla LCD verde, con las casillas apagadas a la vista).
 * Todos comparten: elegir nivel y velocidad, récord, pausa, cruceta o joystick, zurdo y mando externo.
 */
public class Retro {

    // ======================================================================
    // Base común
    // ======================================================================
    abstract static class RetroView extends GameKit.GameView implements ArcadeActivity.Backable {
        static final int S_MENU = 0, S_PLAY = 1, S_PAUSE = 2, S_OVER = 3;
        static final int LCD_BG = Color.rgb(158, 173, 134), LCD_ON = Color.rgb(28, 38, 24), LCD_OFF = Color.argb(34, 20, 30, 15);

        final String key, title, help;
        final Random rnd = new Random();
        final GameKit.Ctrl ctrl;
        int W = 10, H = 20;
        float cs, fx, fy;                 // tamaño de casilla y origen del campo
        float fieldTop = 54, ctrlH = 210;
        int st = S_MENU;
        int level = 1, speed = 1, startLevel = 1, score, lives;
        float shake, flash, bannerT, t;
        String banner;
        boolean newRecord;
        GameKit.Btn bL, bR, bU, bD, bA, bB, bPause;
        final float[] rep = new float[4];
        final List<float[]> parts = new ArrayList<>();      // x, y, vx, vy, vida, color (en casillas)

        RetroView(Context c, String key, String title, String help) {
            super(c);
            this.key = key; this.title = title; this.help = help;
            ctrl = new GameKit.Ctrl(prefs(), key);
            startLevel = prefs().getInt(key + "_lvl", 1);
            speed = prefs().getInt(key + "_spd", 1);
            stick = new GameKit.Stick();
            applyCtrl();
        }

        boolean lcd() { return prefs().getBoolean("retro_lcd", false); }
        int best() { return prefs().getInt("best_" + key, 0); }
        boolean joy() { return ctrl.mode(0) == 1; }

        void applyCtrl() {
            gp.enabled = ctrl.gamepad();
            stick.alpha = ctrl.opacity() / 100f;
            pad.alpha = Math.min(1f, ctrl.opacity() / 100f + 0.3f);
        }

        // ---------------- tamaño y controles ----------------
        @Override void computeScale(int w, int h) {
            vw = 360;
            scale = w / vw;
            vh = h / scale;
        }

        @Override void layout() {
            float k = ctrl.size() / 100f;
            boolean lefty = ctrl.lefty();
            float cy = vh - 105, s = 58 * k;
            float cx = lefty ? vw - 100 : 100;
            bL = pad.add("◀", cx - 1.5f * s, cy - s / 2, cx - s / 2, cy + s / 2, 20);
            bR = pad.add("▶", cx + s / 2, cy - s / 2, cx + 1.5f * s, cy + s / 2, 20);
            bU = pad.add("▲", cx - s / 2, cy - 1.5f * s, cx + s / 2, cy - s / 2, 20);
            bD = pad.add("▼", cx - s / 2, cy + s / 2, cx + s / 2, cy + 1.5f * s, 20);
            float ax = lefty ? 82 : vw - 82, ra = 40 * k, rb = 31 * k;
            bA = pad.add("A", ax - ra, cy - 20 - ra, ax + ra, cy - 20 + ra, 22);
            float bx = lefty ? ax + 68 * k : ax - 68 * k;
            bB = pad.add("B", bx - rb, cy + 46 - rb, bx + rb, cy + 46 + rb, 18);
            bA.round = bB.round = true;
            bPause = pad.add("II", vw - 46, 8, vw - 8, 40, 14);
            gp.bind[GameKit.G_LEFT] = bL; gp.bind[GameKit.G_RIGHT] = bR; gp.bind[GameKit.G_UP] = bU; gp.bind[GameKit.G_DOWN] = bD;
            gp.bind[GameKit.G_A] = bA; gp.bind[GameKit.G_B] = bB; gp.bind[GameKit.G_X] = bB; gp.bind[GameKit.G_START] = bPause;
            stick.place(cx, cy, 44 * k);
            stick.zone.set(lefty ? vw / 2 : 0, vh - ctrlH, lefty ? vw : vw / 2, vh);
            float aw = vw - 20, ah = vh - fieldTop - ctrlH - 8;
            cs = Math.min(aw / W, ah / H);
            fx = (vw - cs * W) / 2;
            fy = fieldTop + (ah - cs * H) / 2;
            showCtrls();
        }

        void showCtrls() {
            boolean play = st == S_PLAY;
            boolean dpad = play && !joy();
            bL.visible = bR.visible = bU.visible = bD.visible = dpad;
            bA.visible = bB.visible = play;
            bA.visible = play;
            bB.visible = play && usesB();
            bPause.visible = play;
            stick.visible = play && joy();
            if (!stick.visible) stick.reset();
        }

        boolean usesB() { return false; }

        /** Dirección pulsada (0 izq, 1 der, 2 arriba, 3 abajo) con repetición al mantener. */
        boolean dir(int d, float dt) {
            GameKit.Btn b = d == 0 ? bL : d == 1 ? bR : d == 2 ? bU : bD;
            if (b.pressed()) { rep[d] = 0.2f; return true; }
            if (b.down) {
                rep[d] -= dt;
                if (rep[d] <= 0) { rep[d] = repeatTime(); return true; }
            }
            return false;
        }

        float repeatTime() { return 0.075f; }

        // ---------------- bucle ----------------
        @Override void update(float dt) {
            t += dt;
            if (shake > 0) shake -= dt;
            if (flash > 0) flash -= dt;
            if (bannerT > 0) bannerT -= dt;
            for (Iterator<float[]> it = parts.iterator(); it.hasNext(); ) {
                float[] q = it.next();
                q[0] += q[2] * dt; q[1] += q[3] * dt; q[3] += 14 * dt; q[4] -= dt;
                if (q[4] <= 0) it.remove();
            }
            if (st != S_PLAY) return;
            // joystick → cruceta
            if (stick.visible) {
                bL.setExt(GameKit.SRC_STICK, stick.ax < -0.45f);
                bR.setExt(GameKit.SRC_STICK, stick.ax > 0.45f);
                bU.setExt(GameKit.SRC_STICK, stick.ay < -0.45f);
                bD.setExt(GameKit.SRC_STICK, stick.ay > 0.45f);
            }
            if (bPause.pressed()) { pauseGame(); return; }
            play(dt);
        }

        abstract void reset();
        abstract void play(float dt);
        abstract void draw(Canvas c);
        abstract Chip.Song song();

        void startGame() {
            level = startLevel; score = 0; lives = 3; newRecord = false;
            parts.clear();
            st = S_PLAY;
            reset();
            showCtrls();
            pad.releaseAll();
            music();
            say("NIVEL " + level);
        }

        void music() {
            chip.tempoMul = 1 + (speed - 1) * 0.05f + (level - 1) * 0.025f;
            chip.play(song());
        }

        /** 0..1: lo rápido que va el juego (velocidad elegida + nivel). */
        float pace() { return Math.min(1, (speed - 1) / 9f * 0.6f + (level - 1) / 20f * 0.6f); }

        void levelUp() {
            level++;
            chip.sfx(Chip.SFX_LEVEL);
            say("¡NIVEL " + level + "!");
            flash = 0.25f;
            chip.tempoMul = 1 + (speed - 1) * 0.05f + (level - 1) * 0.025f;
        }

        void addScore(int n) {
            score += n;
            if (score > best() && !newRecord && best() > 0) { newRecord = true; say("🏆 ¡NUEVO RÉCORD!"); }
        }

        void loseLife() {
            lives--;
            shake = 0.4f;
            chip.sfx(Chip.SFX_HURT);
            if (lives <= 0) gameOver();
        }

        void gameOver() {
            st = S_OVER;
            if (score > best()) prefs().edit().putInt("best_" + key, score).apply();
            chip.silence();
            chip.sfx(Chip.SFX_BOOM);
            showCtrls();
        }

        void pauseGame() { st = S_PAUSE; showCtrls(); pad.releaseAll(); }

        @Override public boolean onBack() {
            if (st == S_PLAY) { pauseGame(); return true; }
            if (st == S_PAUSE || st == S_OVER) { st = S_MENU; chip.silence(); showCtrls(); return true; }
            return false;
        }

        @Override void onPauseGame() { if (st == S_PLAY) pauseGame(); }
        @Override void onResumeGame() { if (st == S_PLAY) music(); }

        void say(String s) { banner = s; bannerT = 1.6f; }

        void burst(float x, float y, int col, int n) {
            for (int i = 0; i < n; i++) {
                double a = rnd.nextDouble() * Math.PI * 2;
                float v = 2 + rnd.nextFloat() * 7;
                parts.add(new float[]{x, y, (float) Math.cos(a) * v, (float) Math.sin(a) * v - 3, 0.4f + rnd.nextFloat() * 0.5f, col});
            }
            if (parts.size() > 400) parts.subList(0, parts.size() - 400).clear();
        }

        // ---------------- dibujo ----------------
        @Override void render(Canvas c) {
            int neon = Neon.color(getContext());
            boolean l = lcd();
            if (l) c.drawColor(Color.rgb(60, 66, 52));
            else {
                p.setShader(new LinearGradient(0, 0, 0, vh, Color.rgb(10, 10, 26), Color.rgb(2, 2, 8), Shader.TileMode.CLAMP));
                c.drawRect(0, 0, vw, vh, p);
                p.setShader(null);
            }
            if (st == S_MENU) { drawMenu(c, neon); return; }
            // marcador
            text(c, L.t(title), vw / 2, 22, 15, l ? Color.rgb(200, 215, 170) : neon);
            textLeft(c, "PUNTOS " + score, 10, 44, 12, Color.WHITE);
            txt.setTextAlign(Paint.Align.RIGHT);
            text(c, "NIV " + level + " · VEL " + speed + "   ", vw - 50, 44, 12, Color.WHITE);
            txt.setTextAlign(Paint.Align.CENTER);
            c.save();
            if (shake > 0) c.translate((rnd.nextFloat() - 0.5f) * 6, (rnd.nextFloat() - 0.5f) * 6);
            // campo
            if (l) {
                p.setColor(LCD_BG);
                c.drawRoundRect(fx - 6, fy - 6, fx + cs * W + 6, fy + cs * H + 6, 8, 8, p);
                for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) lcdCell(c, x, y, LCD_OFF);
            } else {
                p.setColor(Color.argb(200, 4, 4, 14));
                c.drawRoundRect(fx - 6, fy - 6, fx + cs * W + 6, fy + cs * H + 6, 10, 10, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2);
                p.setColor(Neon.withAlpha(neon, 150));
                c.drawRoundRect(fx - 6, fy - 6, fx + cs * W + 6, fy + cs * H + 6, 10, 10, p);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.argb(22, 255, 255, 255));
                for (int y = 0; y <= H; y++) c.drawRect(fx, fy + y * cs - 0.5f, fx + W * cs, fy + y * cs + 0.5f, p);
                for (int x = 0; x <= W; x++) c.drawRect(fx + x * cs - 0.5f, fy, fx + x * cs + 0.5f, fy + H * cs, p);
            }
            c.save();
            c.clipRect(fx - 2, fy - 2, fx + cs * W + 2, fy + cs * H + 2);
            draw(c);
            // partículas
            for (float[] q : parts) {
                p.setColor(l ? LCD_ON : Neon.withAlpha((int) q[5], (int) (255 * Math.min(1, q[4] * 2))));
                float sz = cs * 0.22f;
                c.drawRect(fx + q[0] * cs - sz, fy + q[1] * cs - sz, fx + q[0] * cs + sz, fy + q[1] * cs + sz, p);
            }
            c.restore();
            if (flash > 0) {
                p.setColor(Color.argb((int) (flash * 400), 255, 255, 255));
                c.drawRect(fx, fy, fx + cs * W, fy + cs * H, p);
            }
            c.restore();
            // vidas
            StringBuilder hs = new StringBuilder();
            for (int i = 0; i < lives; i++) hs.append("♥");
            text(c, hs.toString(), vw / 2, 44, 12, Color.rgb(255, 90, 120));
            drawExtraHud(c);
            if (bannerT > 0 && banner != null) {
                RectF r = new RectF(vw / 2 - 130, fy + cs * H * 0.4f, vw / 2 + 130, fy + cs * H * 0.4f + 34);
                p.setColor(Color.argb((int) (180 * Math.min(1, bannerT)), 0, 0, 0));
                c.drawRoundRect(r, 8, 8, p);
                text(c, banner, vw / 2, r.centerY() + 6, 16, Neon.withAlpha(Color.WHITE, (int) (255 * Math.min(1, bannerT))));
            }
            if (st == S_PLAY) {
                pad.draw(c, l ? Color.rgb(200, 215, 170) : neon);
                stick.draw(c, neon);
            }
            if (st == S_PAUSE) drawPause(c, neon);
            if (st == S_OVER) drawOver(c, neon);
        }

        void drawExtraHud(Canvas c) {}

        /** Casilla encendida (con brillo neón, o negra si es LCD). */
        void cell(Canvas c, float x, float y, int col) {
            if (lcd()) { lcdCell(c, x, y, LCD_ON); return; }
            float l = fx + x * cs, tp = fy + y * cs, pad0 = Math.max(1, cs * 0.07f);
            p.setColor(Neon.withAlpha(col, 60));
            c.drawRoundRect(l - pad0, tp - pad0, l + cs + pad0, tp + cs + pad0, cs * 0.3f, cs * 0.3f, p);
            p.setColor(col);
            c.drawRoundRect(l + pad0, tp + pad0, l + cs - pad0, tp + cs - pad0, cs * 0.18f, cs * 0.18f, p);
            p.setColor(Color.argb(90, 255, 255, 255));
            c.drawRect(l + pad0 * 2, tp + pad0 * 2, l + cs - pad0 * 2, tp + pad0 * 2 + cs * 0.14f, p);
            p.setColor(Color.argb(70, 0, 0, 0));
            c.drawRect(l + pad0 * 2, tp + cs - pad0 * 2 - cs * 0.12f, l + cs - pad0 * 2, tp + cs - pad0 * 2, p);
        }

        /** Casilla al estilo de la maquinita: un cuadrado con borde y un cuadrado dentro. */
        void lcdCell(Canvas c, float x, float y, int col) {
            float l = fx + x * cs, tp = fy + y * cs, g = cs * 0.1f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1, cs * 0.09f));
            p.setColor(col);
            c.drawRect(l + g, tp + g, l + cs - g, tp + cs - g, p);
            p.setStyle(Paint.Style.FILL);
            c.drawRect(l + cs * 0.3f, tp + cs * 0.3f, l + cs * 0.7f, tp + cs * 0.7f, p);
        }

        /** Fondo de una fila (agua, carretera...). Solo en color. */
        void rowBg(Canvas c, int y, int col) {
            if (lcd()) return;
            p.setColor(col);
            c.drawRect(fx, fy + y * cs, fx + W * cs, fy + (y + 1) * cs, p);
        }

        void drawMenu(Canvas c, int neon) {
            boolean l = lcd();
            int acc = l ? Color.rgb(200, 215, 170) : neon;
            text(c, L.t(title), vw / 2, 60, 26, acc);
            text(c, "🏆 Récord: " + best(), vw / 2, 88, 14, Color.WHITE);
            float y = Math.max(190, wrap(c, help, vw / 2, 114, vw - 40, 12, Color.LTGRAY, true) + 8);
            // nivel
            text(c, "Nivel inicial", vw / 2, y, 13, Color.LTGRAY);
            if (menuButton(c, new RectF(40, y + 8, 100, y + 46), "−", acc)) setLvl(startLevel - 1);
            text(c, String.valueOf(startLevel), vw / 2, y + 36, 26, Color.WHITE);
            if (menuButton(c, new RectF(vw - 100, y + 8, vw - 40, y + 46), "+", acc)) setLvl(startLevel + 1);
            y += 66;
            text(c, "Velocidad", vw / 2, y, 13, Color.LTGRAY);
            if (menuButton(c, new RectF(40, y + 8, 100, y + 46), "−", acc)) setSpd(speed - 1);
            text(c, String.valueOf(speed), vw / 2, y + 36, 26, Color.WHITE);
            if (menuButton(c, new RectF(vw - 100, y + 8, vw - 40, y + 46), "+", acc)) setSpd(speed + 1);
            y += 66;
            String[] opts = {l ? "📟 Como antes (LCD): SÍ" : "📟 Como antes (LCD): NO",
                    joy() ? "🕹 Joystick: SÍ" : "🕹 Joystick: NO (cruceta)",
                    ctrl.lefty() ? "✋ Zurdo: SÍ" : "✋ Zurdo: NO",
                    ctrl.gamepad() ? "🎮 Mando externo: SÍ" : "🎮 Mando externo: NO",
                    Chip.musicOn(getContext()) ? "🎵 Música: SÍ" : "🎵 Música: NO"};
            for (int i = 0; i < opts.length; i++) {
                RectF r = new RectF(30, y + i * 42, vw - 30, y + i * 42 + 36);
                box(c, r, acc, 170);
                text(c, opts[i], r.centerX(), r.centerY() + 5, 13, Color.WHITE);
                if (tapIn(r)) {
                    switch (i) {
                        case 0: prefs().edit().putBoolean("retro_lcd", !l).apply(); break;
                        case 1: ctrl.setMode(joy() ? 0 : 1); break;
                        case 2: ctrl.setLefty(!ctrl.lefty()); pad.btns.clear(); layout(); break;
                        case 3: ctrl.setGamepad(!ctrl.gamepad()); applyCtrl(); break;
                        default: chip.toggleMusic(); break;
                    }
                }
            }
            y += opts.length * 42 + 10;
            if (menuButton(c, new RectF(60, y, vw - 60, y + 50), "▶ JUGAR", acc) || (gp.enabled && (gp.pressed(GameKit.G_A) || gp.pressed(GameKit.G_START))))
                startGame();
        }

        void setLvl(int v) { startLevel = Math.max(1, Math.min(10, v)); prefs().edit().putInt(key + "_lvl", startLevel).apply(); }
        void setSpd(int v) { speed = Math.max(1, Math.min(10, v)); prefs().edit().putInt(key + "_spd", speed).apply(); }

        void drawPause(Canvas c, int neon) {
            p.setColor(Color.argb(190, 0, 0, 0));
            c.drawRect(0, 0, vw, vh, p);
            text(c, "PAUSA", vw / 2, vh * 0.32f, 28, neon);
            if (menuButton(c, new RectF(70, vh * 0.4f, vw - 70, vh * 0.4f + 48), "▶ CONTINUAR", neon) || (gp.enabled && gp.pressed(GameKit.G_START))) {
                st = S_PLAY; showCtrls(); music();
            }
            if (menuButton(c, new RectF(70, vh * 0.4f + 60, vw - 70, vh * 0.4f + 108), "⟲ REINICIAR", neon)) startGame();
            if (menuButton(c, new RectF(70, vh * 0.4f + 120, vw - 70, vh * 0.4f + 168), "☰ MENÚ", neon)) { st = S_MENU; chip.silence(); showCtrls(); }
        }

        void drawOver(Canvas c, int neon) {
            p.setColor(Color.argb(190, 0, 0, 0));
            c.drawRect(0, 0, vw, vh, p);
            text(c, "FIN DE PARTIDA", vw / 2, vh * 0.3f, 28, neon);
            text(c, "Puntos: " + score + "   ·   Récord: " + best(), vw / 2, vh * 0.3f + 34, 15, Color.WHITE);
            if (newRecord || score >= best() && score > 0) text(c, "🏆 ¡NUEVO RÉCORD!", vw / 2, vh * 0.3f + 60, 15, Color.rgb(255, 220, 90));
            if (menuButton(c, new RectF(70, vh * 0.45f, vw - 70, vh * 0.45f + 48), "▶ OTRA VEZ", neon) || (gp.enabled && gp.pressed(GameKit.G_A))) startGame();
            if (menuButton(c, new RectF(70, vh * 0.45f + 60, vw - 70, vh * 0.45f + 108), "☰ MENÚ", neon)) { st = S_MENU; showCtrls(); }
        }

        // utilidades para formas de 3x3, etc.
        static boolean in(int x, int y, int w, int h) { return x >= 0 && y >= 0 && x < w && y < h; }
    }

    // ======================================================================
    // CARRERAS: esquiva coches, coge monedas, mantén A para el turbo
    // ======================================================================
    static class Race extends RetroView {
        static final int[][] CAR = {{1, 0}, {0, 1}, {1, 1}, {2, 1}, {1, 2}, {0, 3}, {2, 3}};
        int lane;                        // 0..2
        final List<int[]> cars = new ArrayList<>();     // x, y, color
        final List<int[]> coins = new ArrayList<>();
        float acc, fuel = 1, curve;
        int passed, stripe;
        float crashT;

        Race(Context c) { super(c, "race", "🏎 CARRERAS", "◀ ▶ cambia de carril. Mantén A para el TURBO (gasta gasolina, puntos dobles). Coge las monedas y no choques. Las curvas mueven la carretera."); W = 11; H = 20; }

        @Override Chip.Song song() { return Songs.RETRO_RACE; }

        @Override void reset() { lane = 1; cars.clear(); coins.clear(); acc = 0; fuel = 1; passed = 0; crashT = 0; }

        int laneX(int l) { return 1 + l * 3; }

        float tick() { return Math.max(0.045f, 0.3f - pace() * 0.22f) * (bA.down && fuel > 0 ? 0.5f : 1f); }

        @Override void play(float dt) {
            if (crashT > 0) { crashT -= dt; if (crashT <= 0) { cars.clear(); coins.clear(); } return; }
            if (dir(0, dt) && lane > 0) { lane--; chip.sfx(Chip.SFX_JUMP); }
            if (dir(1, dt) && lane < 2) { lane++; chip.sfx(Chip.SFX_JUMP); }
            boolean turbo = bA.down && fuel > 0;
            fuel = Math.max(0, Math.min(1, fuel + (turbo ? -0.22f : 0.08f) * dt));
            curve = (float) Math.sin(t * 0.7f) * (level >= 2 ? 0.6f : 0.25f);
            acc += dt;
            float tk = tick();
            while (acc >= tk) { acc -= tk; stepRoad(turbo); if (crashT > 0) return; }
        }

        void stepRoad(boolean turbo) {
            stripe++;
            for (Iterator<int[]> it = cars.iterator(); it.hasNext(); ) {
                int[] cr = it.next();
                cr[1]++;
                if (cr[1] >= H) { it.remove(); passed++; addScore(turbo ? 20 : 10); if (passed % 20 == 0) levelUp(); }
            }
            for (Iterator<int[]> it = coins.iterator(); it.hasNext(); ) { int[] co = it.next(); co[1]++; if (co[1] >= H) it.remove(); }
            // nuevos coches: nunca tapan los tres carriles
            boolean spaced = true;
            for (int[] cr : cars) if (cr[1] < 5) spaced = false;
            if (spaced && rnd.nextFloat() < 0.35f + pace() * 0.4f) {
                int l = rnd.nextInt(3);
                int[] cols = {Color.rgb(255, 70, 90), Color.rgb(255, 200, 40), Color.rgb(80, 160, 255), Color.rgb(200, 90, 255)};
                cars.add(new int[]{laneX(l), -4, cols[rnd.nextInt(cols.length)]});
                if (level >= 3 && rnd.nextFloat() < 0.25f) { int l2 = (l + 1 + rnd.nextInt(2)) % 3; cars.add(new int[]{laneX(l2), -4, cols[rnd.nextInt(cols.length)]}); }
            } else if (rnd.nextFloat() < 0.08f) coins.add(new int[]{laneX(rnd.nextInt(3)) + 1, -1});
            // ¿choque o moneda?
            int px = laneX(lane), py = H - 4;
            for (int[] co : coins)
                if (co[0] >= px && co[0] <= px + 2 && co[1] >= py && co[1] <= py + 3) { burst(co[0] + 0.5f, co[1] + 0.5f, Color.rgb(255, 220, 60), 10); co[1] = 999; addScore(50); chip.sfx(Chip.SFX_COIN); }
            for (int[] cr : cars) {
                if (cr[0] != px) continue;
                if (cr[1] + 3 >= py && cr[1] <= py + 3) {
                    burst(px + 1.5f, py + 1.5f, Color.rgb(255, 120, 40), 40);
                    crashT = 1.1f;
                    loseLife();
                    return;
                }
            }
        }

        @Override void draw(Canvas c) {
            c.save();
            if (!lcd()) c.translate(curve * cs, 0);
            // muros con rayas que corren
            for (int y = 0; y < H; y++) {
                if ((y + stripe) % 4 != 3) { cell(c, 0, y, Color.rgb(230, 230, 240)); cell(c, W - 1, y, Color.rgb(230, 230, 240)); }
            }
            for (int[] co : coins) if (co[1] >= 0 && co[1] < H) cell(c, co[0], co[1], Color.rgb(255, 215, 50));
            for (int[] cr : cars) for (int[] q : CAR) if (cr[1] + q[1] >= 0) cell(c, cr[0] + q[0], cr[1] + q[1], cr[2]);
            int px = laneX(lane), py = H - 4;
            boolean blink = crashT > 0 && ((int) (t * 12)) % 2 == 0;
            if (!blink) for (int[] q : CAR) cell(c, px + q[0], py + q[1], bA.down && fuel > 0 ? Color.rgb(120, 255, 255) : Color.rgb(80, 255, 140));
            c.restore();
        }

        @Override void drawExtraHud(Canvas c) {
            float x0 = 10, y0 = fy + cs * H + 8;
            p.setColor(Color.argb(120, 255, 255, 255));
            c.drawRect(x0, y0, x0 + 100, y0 + 6, p);
            p.setColor(fuel > 0.25f ? Color.rgb(120, 255, 255) : Color.rgb(255, 90, 90));
            c.drawRect(x0, y0, x0 + 100 * fuel, y0 + 6, p);
            textLeft(c, "TURBO", x0 + 106, y0 + 7, 9, Color.LTGRAY);
        }
    }

    // ======================================================================
    // TANQUES: muévete con la cruceta, dispara con A. Enemigos variados, potenciadores y jefes
    // ======================================================================
    static class Tank extends RetroView {
        static final class T { int x, y, d, hp, kind; float mv, cd; boolean dead; }   // kind: 0 jugador, 1 normal, 2 rápido, 3 blindado, 9 jefe
        static final class B { int x, y, d; boolean mine; float acc; }
        final List<T> foes = new ArrayList<>();
        final List<B> bullets = new ArrayList<>();
        final List<int[]> powers = new ArrayList<>();     // x, y, tipo (0 escudo, 1 triple, 2 velocidad, 3 vida), vida*10
        boolean[][] wall;
        T me;
        int toKill, spawned, killed;
        float spawnT, shieldT, tripleT, fastT, shotCd;
        static final int[][] DX = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};   // arriba, derecha, abajo, izquierda

        Tank(Context c) { super(c, "tank", "🪖 TANQUES", "La cruceta mueve el tanque y A dispara. Enemigos: verdes, rápidos (amarillos) y blindados (rojos). Potenciadores: escudo, triple disparo, velocidad y vida. Cada 5 niveles, un JEFE."); W = 13; H = 17; }

        @Override Chip.Song song() { return level % 5 == 0 ? Songs.RETRO_TANK_BOSS : Songs.RETRO_TANK; }

        @Override void reset() { buildLevel(); }

        void buildLevel() {
            foes.clear(); bullets.clear(); powers.clear();
            wall = new boolean[H][W];
            Random r = new Random(level * 77L);
            for (int i = 0; i < 6 + level; i++) {
                int x = 1 + r.nextInt(W - 2), y = 3 + r.nextInt(H - 7), len = 2 + r.nextInt(3);
                boolean hz = r.nextBoolean();
                for (int k = 0; k < len; k++) { int xx = hz ? x + k : x, yy = hz ? y : y + k; if (in(xx, yy, W, H)) wall[yy][xx] = true; }
            }
            me = new T(); me.x = W / 2; me.y = H - 2; me.d = 0; me.kind = 0;
            clearAround(me.x, me.y);
            toKill = level % 5 == 0 ? 1 : 5 + level;
            spawned = killed = 0;
            spawnT = 1;
            shieldT = 2;
            if (level % 5 == 0) { spawnBoss(); say("⚠ ¡JEFE!"); }
            music();
        }

        void clearAround(int cx, int cy) {
            for (int y = cy - 2; y <= cy + 2; y++) for (int x = cx - 2; x <= cx + 2; x++) if (in(x, y, W, H)) wall[y][x] = false;
        }

        void spawnBoss() {
            T b = new T(); b.kind = 9; b.x = W / 2; b.y = 2; b.d = 2; b.hp = 14 + level * 2; b.cd = 1;
            clearAround(b.x, b.y);
            for (int x = b.x - 3; x <= b.x + 3; x++) for (int y = 0; y <= 4; y++) if (in(x, y, W, H)) wall[y][x] = false;
            foes.add(b);
            spawned = 1;
        }

        int size(T k) { return k.kind == 9 ? 2 : 1; }      // radio

        /** Casillas de un tanque de 3x3 (o 5x5 el jefe) mirando en su dirección. */
        List<int[]> shape(T k) {
            List<int[]> out = new ArrayList<>();
            int r = size(k);
            for (int dy = -r; dy <= r; dy++)
                for (int dx = -r; dx <= r; dx++) {
                    // rotar a "mirando arriba"
                    int ux, uy;
                    switch (k.d) {
                        case 1: ux = dy; uy = -dx; break;
                        case 2: ux = -dx; uy = -dy; break;
                        case 3: ux = -dy; uy = dx; break;
                        default: ux = dx; uy = dy;
                    }
                    boolean on;
                    if (r == 1) on = (uy == -1 && ux == 0) || uy == 0 || (uy == 1 && ux != 0);
                    else on = (uy == -2 && ux == 0) || (uy == -1 && Math.abs(ux) <= 1) || uy == 0 || uy == 1 || (uy == 2 && Math.abs(ux) != 1);
                    if (on) out.add(new int[]{k.x + dx, k.y + dy});
                }
            return out;
        }

        boolean free(T k, int nx, int ny) {
            int r = size(k);
            for (int y = ny - r; y <= ny + r; y++)
                for (int x = nx - r; x <= nx + r; x++) {
                    if (!in(x, y, W, H) || wall[y][x]) return false;
                }
            List<T> all = new ArrayList<>(foes);
            all.add(me);
            for (T o : all) {
                if (o == k || o.dead) continue;
                int rr = size(o) + r;
                if (Math.abs(o.x - nx) <= rr && Math.abs(o.y - ny) <= rr) return false;
            }
            return true;
        }

        boolean step(T k, int d) {
            k.d = d;
            int nx = k.x + DX[d][0], ny = k.y + DX[d][1];
            if (free(k, nx, ny)) { k.x = nx; k.y = ny; return true; }
            return false;
        }

        void shoot(T k, int d) {
            B b = new B();
            int r = size(k) + 1;
            b.x = k.x + DX[d][0] * r; b.y = k.y + DX[d][1] * r; b.d = d; b.mine = k == me;
            bullets.add(b);
        }

        @Override void play(float dt) {
            if (shieldT > 0) shieldT -= dt;
            if (tripleT > 0) tripleT -= dt;
            if (fastT > 0) fastT -= dt;
            shotCd -= dt;
            // jugador
            me.mv -= dt;
            for (int d = 0; d < 4; d++) {
                int key = d == 0 ? 2 : d == 1 ? 1 : d == 2 ? 3 : 0;
                GameKit.Btn b = key == 0 ? bL : key == 1 ? bR : key == 2 ? bU : bD;
                if (b.pressed()) { me.d = d; me.mv = 0; }
                if (b.down && me.mv <= 0) { step(me, d); me.mv = fastT > 0 ? 0.07f : 0.13f; }
            }
            if ((bA.pressed() || (bA.down && shotCd <= -0.1f)) && shotCd <= 0) {
                shotCd = 0.28f;
                shoot(me, me.d);
                if (tripleT > 0) { shoot(me, (me.d + 1) % 4); shoot(me, (me.d + 3) % 4); }
                chip.sfx(Chip.SFX_SHOOT);
            }
            // aparecen enemigos
            spawnT -= dt;
            int alive = 0;
            for (T f : foes) if (!f.dead) alive++;
            if (spawnT <= 0 && spawned < toKill && alive < Math.min(4, 2 + level / 3)) {
                spawnT = Math.max(0.8f, 2.5f - pace() * 1.5f);
                int[] xs = {1, W / 2, W - 2};
                T f = new T();
                f.x = xs[rnd.nextInt(3)]; f.y = 1; f.d = 2;
                float rr = rnd.nextFloat();
                f.kind = rr < 0.2f + level * 0.02f ? 3 : rr < 0.45f ? 2 : 1;
                f.hp = f.kind == 3 ? 3 : 1;
                f.cd = 1 + rnd.nextFloat();
                if (free(f, f.x, f.y)) { foes.add(f); spawned++; }
            }
            // enemigos
            float sp = 1 - pace() * 0.5f;
            for (T f : foes) {
                if (f.dead) continue;
                f.mv -= dt; f.cd -= dt;
                float wait = (f.kind == 2 ? 0.22f : f.kind == 9 ? 0.5f : 0.38f) * sp;
                if (f.mv <= 0) {
                    f.mv = wait;
                    boolean aligned = f.x == me.x || f.y == me.y;
                    if (aligned && rnd.nextFloat() < 0.5f) f.d = f.x == me.x ? (me.y < f.y ? 0 : 2) : (me.x < f.x ? 3 : 1);
                    else if (rnd.nextFloat() < 0.2f) f.d = rnd.nextInt(4);
                    if (!step(f, f.d)) f.d = rnd.nextInt(4);
                }
                boolean aligned = Math.abs(f.x - me.x) <= size(f) || Math.abs(f.y - me.y) <= size(f);
                if (f.cd <= 0 && (aligned || rnd.nextFloat() < 0.01f)) {
                    f.cd = (f.kind == 9 ? 0.9f : 1.6f) * sp + rnd.nextFloat();
                    if (aligned) f.d = Math.abs(f.x - me.x) <= size(f) ? (me.y < f.y ? 0 : 2) : (me.x < f.x ? 3 : 1);
                    shoot(f, f.d);
                    if (f.kind == 9) { shoot(f, (f.d + 1) % 4); shoot(f, (f.d + 3) % 4); }
                }
            }
            // balas: 1 casilla cada 0,045 s
            for (B b : bullets) {
                b.acc += dt;
                while (b.acc >= 0.045f && b.d >= 0) {
                    b.acc -= 0.045f;
                    if (!in(b.x, b.y, W, H)) { b.d = -1; break; }
                    if (wall[b.y][b.x]) { wall[b.y][b.x] = false; b.d = -1; burst(b.x + 0.5f, b.y + 0.5f, Color.rgb(200, 120, 70), 6); chip.sfx(Chip.SFX_HIT); break; }
                    if (hitTank(b)) { b.d = -1; break; }
                    b.x += DX[b.d][0]; b.y += DX[b.d][1];
                }
            }
            // choques entre balas
            for (B a : bullets) for (B b : bullets) if (a != b && a.d >= 0 && b.d >= 0 && a.mine != b.mine && a.x == b.x && a.y == b.y) { a.d = -1; b.d = -1; }
            for (Iterator<B> it = bullets.iterator(); it.hasNext(); ) if (it.next().d < 0) it.remove();
            for (Iterator<T> it = foes.iterator(); it.hasNext(); ) if (it.next().dead) it.remove();
            // potenciadores
            for (Iterator<int[]> it = powers.iterator(); it.hasNext(); ) {
                int[] pw = it.next();
                pw[3] -= 1;
                if (pw[3] <= 0) { it.remove(); continue; }
                if (Math.abs(pw[0] - me.x) <= 1 && Math.abs(pw[1] - me.y) <= 1) {
                    it.remove();
                    chip.sfx(Chip.SFX_POWER);
                    switch (pw[2]) {
                        case 0: shieldT = 8; say("🛡 ESCUDO"); break;
                        case 1: tripleT = 10; say("✳ TRIPLE DISPARO"); break;
                        case 2: fastT = 10; say("⚡ VELOCIDAD"); break;
                        default: lives = Math.min(6, lives + 1); say("♥ +1 VIDA"); break;
                    }
                    addScore(50);
                }
            }
            if (killed >= toKill && foes.isEmpty()) { addScore(200 * level); levelUp(); buildLevel(); }
        }

        boolean hitTank(B b) {
            if (b.mine) {
                for (T f : foes) {
                    if (f.dead) continue;
                    int r = size(f);
                    if (Math.abs(b.x - f.x) <= r && Math.abs(b.y - f.y) <= r) {
                        f.hp--;
                        chip.sfx(Chip.SFX_HIT);
                        if (f.hp <= 0) {
                            f.dead = true;
                            killed++;
                            addScore(f.kind == 9 ? 1000 : f.kind == 3 ? 300 : f.kind == 2 ? 200 : 100);
                            burst(f.x + 0.5f, f.y + 0.5f, f.kind == 9 ? Color.rgb(255, 80, 200) : Color.rgb(255, 150, 40), f.kind == 9 ? 80 : 25);
                            shake = f.kind == 9 ? 0.6f : 0.2f;
                            chip.sfx(Chip.SFX_BOOM);
                            if (f.kind == 9) killed = toKill;
                            if (rnd.nextFloat() < 0.25f) powers.add(new int[]{f.x, f.y, rnd.nextInt(4), 600});
                        } else burst(b.x + 0.5f, b.y + 0.5f, Color.WHITE, 5);
                        return true;
                    }
                }
            } else if (Math.abs(b.x - me.x) <= 1 && Math.abs(b.y - me.y) <= 1) {
                if (shieldT > 0) { burst(b.x + 0.5f, b.y + 0.5f, Color.rgb(120, 220, 255), 6); return true; }
                burst(me.x + 0.5f, me.y + 0.5f, Color.rgb(80, 255, 140), 30);
                loseLife();
                if (lives > 0) { me.x = W / 2; me.y = H - 2; me.d = 0; clearAround(me.x, me.y); shieldT = 2.5f; }
                return true;
            }
            return false;
        }

        @Override void draw(Canvas c) {
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) if (wall[y][x]) cell(c, x, y, Color.rgb(190, 110, 70));
            for (int[] pw : powers) {
                if (pw[3] < 120 && (pw[3] / 8) % 2 == 0) continue;
                int[] cols = {Color.rgb(120, 220, 255), Color.rgb(255, 120, 255), Color.rgb(255, 240, 80), Color.rgb(255, 90, 120)};
                cell(c, pw[0], pw[1], cols[pw[2]]);
            }
            for (T f : foes) {
                int col = f.kind == 9 ? Color.rgb(255, 80, 200) : f.kind == 3 ? Color.rgb(255, 80, 80) : f.kind == 2 ? Color.rgb(255, 220, 60) : Color.rgb(120, 230, 120);
                if (f.kind == 3 && f.hp < 3) col = Color.rgb(255, 150, 150);
                for (int[] q : shape(f)) cell(c, q[0], q[1], col);
            }
            boolean blink = shieldT > 0 && ((int) (t * 10)) % 2 == 0;
            int mc = tripleT > 0 ? Color.rgb(255, 120, 255) : fastT > 0 ? Color.rgb(255, 240, 80) : Color.rgb(80, 200, 255);
            for (int[] q : shape(me)) cell(c, q[0], q[1], blink ? Color.WHITE : mc);
            for (B b : bullets) if (in(b.x, b.y, W, H)) cell(c, b.x, b.y, b.mine ? Color.WHITE : Color.rgb(255, 90, 60));
        }

        @Override void drawExtraHud(Canvas c) {
            textLeft(c, "Enemigos: " + Math.max(0, toKill - killed), 10, fy + cs * H + 16, 11, Color.LTGRAY);
        }
    }

    // ======================================================================
    // DISPAROS: oleadas que bajan, armas que mejoran
    // ======================================================================
    static class Shooter extends RetroView {
        int[][] g;                 // 0 vacío · 1 bloque · 2 enemigo (2 golpes) · 3 enemigo tocado · 4 caja de arma
        int gx;
        int weapon = 1, rows, destroyed;
        float acc, shotCd;
        final List<float[]> shots = new ArrayList<>();   // x, y
        final List<float[]> drops = new ArrayList<>();   // x, y

        Shooter(Context c) { super(c, "shoot", "🚀 DISPAROS", "◀ ▶ mueve el cañón y A dispara (mantén para ráfaga). Rompe la pared antes de que llegue abajo. Las cajas ★ sueltan mejoras de arma: doble, triple y láser."); W = 10; H = 20; }

        @Override Chip.Song song() { return Songs.RETRO_SHOOT; }
        @Override float repeatTime() { return 0.06f; }

        @Override void reset() {
            g = new int[H][W];
            gx = W / 2; weapon = 1; rows = 0; destroyed = 0; acc = 0;
            shots.clear(); drops.clear();
            for (int i = 0; i < 4 + Math.min(4, level / 2); i++) pushRow();
        }

        void pushRow() {
            for (int y = H - 1; y > 0; y--) g[y] = g[y - 1];
            g[0] = new int[W];
            float fill = 0.55f + Math.min(0.3f, level * 0.03f);
            for (int x = 0; x < W; x++) {
                if (rnd.nextFloat() > fill) continue;
                float r = rnd.nextFloat();
                g[0][x] = r < 0.04f ? 4 : r < 0.12f + level * 0.01f ? 2 : 1;
            }
            rows++;
        }

        float rowTime() { return Math.max(0.7f, 4.2f - pace() * 3.2f); }

        @Override void play(float dt) {
            if (dir(0, dt) && gx > 1) gx--;
            if (dir(1, dt) && gx < W - 2) gx++;
            shotCd -= dt;
            if ((bA.pressed() || bA.down) && shotCd <= 0) {
                shotCd = weapon >= 4 ? 0.35f : 0.16f;
                fire();
            }
            // la pared baja
            acc += dt;
            if (acc >= rowTime()) {
                acc = 0;
                pushRow();
                for (int x = 0; x < W; x++) if (g[H - 3][x] != 0) { gameOver(); return; }
            }
            // disparos: 1 casilla cada 0,03 s
            for (Iterator<float[]> it = shots.iterator(); it.hasNext(); ) {
                float[] s = it.next();
                s[1] -= dt / 0.03f;
                int x = (int) s[0], y = (int) Math.floor(s[1]);
                if (y < 0) { it.remove(); continue; }
                if (in(x, y, W, H) && g[y][x] != 0) { hit(x, y); it.remove(); }
            }
            // mejoras que caen
            for (Iterator<float[]> it = drops.iterator(); it.hasNext(); ) {
                float[] d = it.next();
                d[1] += dt * 7;
                if (d[1] >= H - 2 && Math.abs(d[0] - gx) <= 1) {
                    it.remove();
                    weapon = Math.min(4, weapon + 1);
                    chip.sfx(Chip.SFX_POWER);
                    say(weapon == 2 ? "ARMA: DOBLE" : weapon == 3 ? "ARMA: TRIPLE" : "ARMA: ¡LÁSER!");
                    addScore(100);
                } else if (d[1] >= H) it.remove();
            }
        }

        void fire() {
            chip.sfx(Chip.SFX_SHOOT);
            if (weapon >= 4) {          // láser: barre la columna entera
                for (int y = H - 3; y >= 0; y--) if (g[y][gx] != 0) hit(gx, y);
                flash = 0.08f;
                laserT = 0.12f;
                return;
            }
            if (weapon != 2) shots.add(new float[]{gx, H - 3});
            if (weapon >= 2) { if (gx > 0) shots.add(new float[]{gx - 1, H - 2}); if (gx < W - 1) shots.add(new float[]{gx + 1, H - 2}); }
        }

        float laserT;

        void hit(int x, int y) {
            int v = g[y][x];
            if (v == 2) { g[y][x] = 3; burst(x + 0.5f, y + 0.5f, Color.WHITE, 5); chip.sfx(Chip.SFX_HIT); return; }
            g[y][x] = 0;
            destroyed++;
            addScore(v == 3 ? 30 : v == 4 ? 50 : 10);
            burst(x + 0.5f, y + 0.5f, v == 4 ? Color.rgb(255, 230, 80) : v == 3 ? Color.rgb(255, 90, 200) : Color.rgb(90, 200, 255), 8);
            chip.sfx(Chip.SFX_HIT);
            if (v == 4) drops.add(new float[]{x, y});
            if (destroyed % 60 == 0) { levelUp(); flash = 0.3f; }
        }

        @Override void draw(Canvas c) {
            int[] wave = {Color.rgb(90, 200, 255), Color.rgb(120, 255, 160), Color.rgb(255, 170, 80), Color.rgb(200, 120, 255), Color.rgb(255, 110, 140)};
            int wc = wave[(level - 1) % wave.length];
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++) {
                    int v = g[y][x];
                    if (v == 0) continue;
                    cell(c, x, y, v == 1 ? wc : v == 2 ? Color.rgb(255, 70, 160) : v == 3 ? Color.rgb(255, 170, 220) : Color.rgb(255, 230, 80));
                }
            for (float[] s : shots) cell(c, s[0], (int) Math.floor(s[1]), Color.WHITE);
            for (float[] d : drops) if (((int) (t * 8)) % 2 == 0) cell(c, d[0], (int) d[1], Color.rgb(255, 230, 80));
            if (laserT > 0) {
                laserT -= 0.016f;
                p.setColor(Color.argb(160, 255, 255, 255));
                c.drawRect(fx + gx * cs + cs * 0.3f, fy, fx + gx * cs + cs * 0.7f, fy + (H - 2) * cs, p);
            }
            int gc = weapon >= 4 ? Color.rgb(255, 120, 255) : weapon == 3 ? Color.rgb(255, 230, 80) : weapon == 2 ? Color.rgb(120, 255, 255) : Color.rgb(80, 255, 140);
            cell(c, gx, H - 2, gc);
            cell(c, gx - 1, H - 1, gc); cell(c, gx, H - 1, gc); cell(c, gx + 1, H - 1, gc);
            // línea de peligro
            if (!lcd()) {
                p.setColor(Color.argb(70, 255, 60, 60));
                c.drawRect(fx, fy + (H - 3) * cs - 1, fx + W * cs, fy + (H - 3) * cs + 1, p);
            }
        }

        @Override void drawExtraHud(Canvas c) {
            String[] wn = {"", "SIMPLE", "DOBLE", "TRIPLE", "LÁSER"};
            textLeft(c, "Arma: " + wn[weapon], 10, fy + cs * H + 16, 11, Color.LTGRAY);
        }
    }

    // ======================================================================
    // RANITA: cruza la carretera y el río (troncos, tortugas que se hunden, día y noche)
    // ======================================================================
    static class Frog extends RetroView {
        // fila: tipo (0 meta, 1 río, 2 arcén, 3 carretera, 4 salida), dirección, velocidad (casillas/s), patrón
        static final class Lane { int type, dir; float speed, off; boolean[] pat; int len; boolean turtles; }
        Lane[] lanes;
        float frogX; int frogY;
        boolean[] goals;
        float timeLeft, deadT, diveT;
        int furthest;
        boolean night;
        static final int[] GOAL_X = {1, 4, 6, 8, 11};

        Frog(Context c) { super(c, "frog", "🐸 RANITA", "Cruza la carretera y el río saltando con la cruceta. Súbete a los troncos y a las tortugas (¡ojo, que se hunden!). Llena las 5 casitas de arriba. De día y de noche."); W = 13; H = 13; }

        @Override Chip.Song song() { return night ? Songs.RETRO_FROG_NIGHT : Songs.RETRO_FROG; }
        @Override void reset() { lives = 4; goals = new boolean[5]; buildLanes(); spawnFrog(); }

        void buildLanes() {
            night = (level % 2) == 0;
            lanes = new Lane[H];
            float k = 1 + pace() * 1.3f;
            for (int y = 0; y < H; y++) {
                Lane l = new Lane();
                l.dir = y % 2 == 0 ? 1 : -1;
                if (y == 0) l.type = 0;
                else if (y <= 5) {
                    l.type = 1;
                    l.turtles = y == 2 || y == 5;
                    l.speed = (0.9f + (y % 3) * 0.45f) * k;
                    l.len = l.turtles ? 3 : 3 + (y % 2);
                    l.pat = pattern(26, l.len, l.turtles ? 3 : 4);
                } else if (y == 6) l.type = 2;
                else if (y <= 11) {
                    l.type = 3;
                    l.speed = (1.2f + ((y * 3) % 4) * 0.5f) * k;
                    l.len = y == 8 ? 3 : y == 10 ? 2 : 1;
                    l.pat = pattern(26, l.len, 4 + (y % 3));
                } else l.type = 4;
                l.off = rnd.nextFloat() * 26;
                lanes[y] = l;
            }
        }

        boolean[] pattern(int n, int len, int gap) {
            boolean[] a = new boolean[n];
            int x = 0;
            while (x < n) {
                for (int i = 0; i < len && x < n; i++) a[x++] = true;
                x += gap + rnd.nextInt(3);
            }
            return a;
        }

        void spawnFrog() { frogX = W / 2; frogY = H - 1; furthest = H - 1; timeLeft = 30; deadT = 0; }

        /** ¿Hay objeto (tronco, coche...) en la casilla x de esa fila? */
        boolean occ(Lane l, float x) {
            if (l.pat == null) return false;
            int n = l.pat.length;
            int i = (int) Math.floor(x - l.off * l.dir);
            i = ((i % n) + n) % n;
            return l.pat[i];
        }

        boolean diving(Lane l, float x) {
            if (!l.turtles) return false;
            int n = l.pat.length;
            int i = (int) Math.floor(x - l.off * l.dir);
            i = ((i % n) + n) % n;
            int group = i / 6;
            return (group % 2 == 0) && ((diveT + group) % 6) > 4.4f;
        }

        @Override void play(float dt) {
            diveT += dt;
            for (Lane l : lanes) if (l.pat != null) l.off = (l.off + l.speed * dt) % l.pat.length;
            if (deadT > 0) { deadT -= dt; if (deadT <= 0) { if (lives <= 0) gameOver(); else spawnFrog(); } return; }
            timeLeft -= dt;
            if (timeLeft <= 0) { die(); return; }
            if (dir(2, dt) && frogY > 0) { frogY--; chip.sfx(Chip.SFX_JUMP); if (frogY < furthest) { furthest = frogY; addScore(10); } frogX = Math.round(frogX); }
            if (dir(3, dt) && frogY < H - 1) { frogY++; chip.sfx(Chip.SFX_JUMP); frogX = Math.round(frogX); }
            if (dir(0, dt) && frogX > 0.5f) { frogX = Math.round(frogX) - 1; chip.sfx(Chip.SFX_JUMP); }
            if (dir(1, dt) && frogX < W - 1.5f) { frogX = Math.round(frogX) + 1; chip.sfx(Chip.SFX_JUMP); }
            Lane l = lanes[frogY];
            float cx = frogX + 0.5f;
            if (l.type == 1) {
                if (!occ(l, cx) || diving(l, cx)) { splash(); return; }
                frogX += l.speed * l.dir * dt;           // te lleva el tronco
                if (frogX < -0.4f || frogX > W - 0.6f) { splash(); return; }
            } else if (l.type == 3) {
                if (occ(l, frogX + 0.15f) || occ(l, frogX + 0.85f)) { die(); return; }
            } else if (l.type == 0) {
                int slot = -1;
                for (int i = 0; i < 5; i++) if (Math.abs(cx - (GOAL_X[i] + 0.5f)) < 0.8f) slot = i;
                if (slot < 0 || goals[slot]) { die(); return; }
                goals[slot] = true;
                addScore(100 + (int) timeLeft * 5);
                chip.sfx(Chip.SFX_LEVEL);
                burst(GOAL_X[slot] + 0.5f, 0.5f, Color.rgb(120, 255, 120), 20);
                boolean all = true;
                for (boolean b : goals) all &= b;
                if (all) {
                    addScore(1000);
                    levelUp();
                    goals = new boolean[5];
                    buildLanes();
                    say(night ? "🌙 ¡NOCHE!" : "☀ ¡DÍA!");
                    music();
                }
                spawnFrog();
            }
        }

        void splash() { burst(frogX + 0.5f, frogY + 0.5f, Color.rgb(120, 180, 255), 18); die(); }

        void die() {
            if (deadT > 0) return;
            burst(frogX + 0.5f, frogY + 0.5f, Color.rgb(80, 255, 120), 16);
            deadT = 1f;
            lives--;
            shake = 0.3f;
            chip.sfx(Chip.SFX_HURT);
        }

        @Override void draw(Canvas c) {
            for (int y = 0; y < H; y++) {
                Lane l = lanes[y];
                int bg = l.type == 1 ? (night ? Color.rgb(10, 20, 60) : Color.rgb(20, 60, 140)) : l.type == 3 ? (night ? Color.rgb(18, 18, 24) : Color.rgb(45, 45, 55))
                        : l.type == 0 ? (night ? Color.rgb(10, 40, 20) : Color.rgb(30, 100, 50)) : (night ? Color.rgb(40, 30, 50) : Color.rgb(90, 70, 110));
                rowBg(c, y, bg);
                if (l.type == 0) {
                    for (int x = 0; x < W; x++) {
                        boolean slot = false;
                        for (int i = 0; i < 5; i++) if (GOAL_X[i] == x) { slot = true; if (goals[i]) cell(c, x, y, Color.rgb(120, 255, 120)); }
                        if (!slot) cell(c, x, y, night ? Color.rgb(40, 110, 60) : Color.rgb(60, 160, 80));
                    }
                }
                if (l.pat == null) continue;
                for (int x = 0; x < W; x++) {
                    float cx = x + 0.5f;
                    if (!occ(l, cx)) continue;
                    if (l.type == 1) {
                        if (diving(l, cx)) { if (((int) (t * 6)) % 2 == 0 && !lcd()) { p.setColor(Color.argb(90, 120, 255, 120)); c.drawRect(fx + x * cs, fy + y * cs + cs * 0.4f, fx + (x + 1) * cs, fy + y * cs + cs * 0.6f, p); } continue; }
                        cell(c, x, y, l.turtles ? Color.rgb(60, 200, 110) : Color.rgb(170, 110, 60));
                    } else {
                        int col = l.len >= 3 ? Color.rgb(230, 230, 240) : l.len == 2 ? Color.rgb(255, 200, 40) : Color.rgb(255, 70, 90);
                        cell(c, x, y, col);
                        if (night && !lcd()) {      // faros
                            p.setColor(Color.argb(60, 255, 250, 200));
                            float hx = fx + (x + (l.dir > 0 ? 1 : 0)) * cs;
                            c.drawRect(hx - (l.dir > 0 ? 0 : cs * 1.5f), fy + y * cs + cs * 0.25f, hx + (l.dir > 0 ? cs * 1.5f : 0), fy + y * cs + cs * 0.75f, p);
                        }
                    }
                }
            }
            if (deadT <= 0 || ((int) (t * 12)) % 2 == 0) {
                float l0 = frogX;
                cellF(c, l0, frogY, deadT > 0 ? Color.rgb(255, 80, 80) : Color.rgb(90, 255, 110));
            }
            if (night && !lcd()) {      // la noche: solo se ve cerca de la ranita y de los faros
                p.setShader(new android.graphics.RadialGradient(fx + (frogX + 0.5f) * cs, fy + (frogY + 0.5f) * cs, cs * 6,
                        new int[]{Color.TRANSPARENT, Color.argb(150, 0, 0, 20)}, new float[]{0.3f, 1}, Shader.TileMode.CLAMP));
                c.drawRect(fx, fy, fx + W * cs, fy + H * cs, p);
                p.setShader(null);
            }
        }

        /** Casilla en una x con decimales (la ranita sobre un tronco). */
        void cellF(Canvas c, float x, int y, int col) {
            if (lcd()) { lcdCell(c, Math.round(x), y, LCD_ON); return; }
            cell(c, x, y, col);
        }

        @Override void drawExtraHud(Canvas c) {
            float x0 = 10, y0 = fy + cs * H + 8;
            p.setColor(Color.argb(120, 255, 255, 255));
            c.drawRect(x0, y0, x0 + 120, y0 + 6, p);
            p.setColor(timeLeft > 8 ? Color.rgb(120, 255, 140) : Color.rgb(255, 90, 90));
            c.drawRect(x0, y0, x0 + 120 * Math.max(0, timeLeft) / 30f, y0 + 6, p);
            textLeft(c, "TIEMPO", x0 + 126, y0 + 7, 9, Color.LTGRAY);
            text(c, night ? "🌙" : "☀", vw - 24, y0 + 10, 14, Color.WHITE);
        }
    }

    // ======================================================================
    // RELLENAR HUECOS: dispara bloques para completar filas (combos y piezas especiales)
    // ======================================================================
    static class Fill extends RetroView {
        int[][] g;                 // 0 vacío · 1 pared · 2 tu bloque · 3 rayo
        int gx, next;              // next: 0 bloque · 1 bomba · 2 rayo
        int shots, cleared, combo;
        float acc, comboT;
        final List<float[]> flying = new ArrayList<>();   // x, y, tipo
        static int colOf(int v) { return v == 1 ? Color.rgb(120, 170, 255) : v == 2 ? Color.rgb(120, 255, 170) : Color.rgb(255, 240, 120); }

        Fill(Context c) { super(c, "fill", "🧩 RELLENAR HUECOS", "◀ ▶ mueve el cañón. A dispara un bloque que sube y tapa el hueco; si la fila queda llena, desaparece. B quita el bloque más bajo de la columna. Piezas especiales: 💣 bomba y ⚡ rayo. ¡Encadena filas para hacer combos!"); W = 10; H = 18; }

        @Override Chip.Song song() { return Songs.RETRO_FILL; }
        @Override boolean usesB() { return true; }

        @Override void reset() {
            g = new int[H][W];
            gx = W / 2; next = 0; shots = 0; cleared = 0; combo = 0; acc = 0;
            flying.clear();
            for (int i = 0; i < 3 + Math.min(4, level / 2); i++) pushRow();
        }

        void pushRow() {
            for (int y = H - 1; y > 0; y--) g[y] = g[y - 1];
            g[0] = new int[W];
            int gaps = 1 + rnd.nextInt(Math.min(4, 2 + level / 3));
            for (int x = 0; x < W; x++) g[0][x] = 1;
            for (int i = 0; i < gaps; i++) g[0][rnd.nextInt(W)] = 0;
        }

        int bottom() {       // fila más baja con bloques
            for (int y = H - 1; y >= 0; y--) for (int x = 0; x < W; x++) if (g[y][x] != 0) return y;
            return -1;
        }

        float rowTime() { return Math.max(1.1f, 7f - pace() * 5f); }

        @Override void play(float dt) {
            if (dir(0, dt) && gx > 1) gx--;
            if (dir(1, dt) && gx < W - 2) gx++;
            if (comboT > 0) { comboT -= dt; if (comboT <= 0) combo = 0; }
            if (bA.pressed()) {
                flying.add(new float[]{gx, H - 3, next});
                chip.sfx(Chip.SFX_SHOOT);
                shots++;
                next = shots % 15 == 14 ? 2 : shots % 9 == 8 ? 1 : 0;
            }
            if (bB.pressed()) {          // quitar el bloque más bajo de la columna
                for (int y = H - 4; y >= 0; y--) if (g[y][gx] != 0) { g[y][gx] = 0; burst(gx + 0.5f, y + 0.5f, Color.WHITE, 6); chip.sfx(Chip.SFX_HIT); break; }
            }
            acc += dt;
            if (acc >= rowTime()) {
                acc = 0;
                pushRow();
                if (bottom() >= H - 3) { gameOver(); return; }
            }
            for (Iterator<float[]> it = flying.iterator(); it.hasNext(); ) {
                float[] f = it.next();
                float ny = f[1] - dt / 0.022f;
                int x = (int) f[0];
                int cy = (int) Math.floor(ny);
                // sube hasta tocar un bloque (o el techo)
                if (cy < 0 || g[Math.max(0, cy)][x] != 0) {
                    int land = cy < 0 ? 0 : cy + 1;
                    while (land < H - 3 && g[land][x] != 0) land++;
                    if (land >= H - 3) { it.remove(); continue; }
                    it.remove();
                    land(x, land, (int) f[2]);
                    continue;
                }
                f[1] = ny;
            }
        }

        void land(int x, int y, int type) {
            if (type == 1) {         // bomba: revienta 3x3
                for (int yy = y - 1; yy <= y + 1; yy++) for (int xx = x - 1; xx <= x + 1; xx++)
                    if (in(xx, yy, W, H) && g[yy][xx] != 0) { g[yy][xx] = 0; addScore(15); }
                burst(x + 0.5f, y + 0.5f, Color.rgb(255, 140, 40), 40);
                shake = 0.35f;
                chip.sfx(Chip.SFX_BOOM);
                return;
            }
            if (type == 2) {         // rayo: completa la fila entera
                for (int xx = 0; xx < W; xx++) g[y][xx] = 3;
                flash = 0.15f;
            } else g[y][x] = 2;
            chip.sfx(Chip.SFX_HIT);
            int n = 0;
            for (int yy = H - 1; yy >= 0; yy--) {
                boolean full = true;
                for (int xx = 0; xx < W; xx++) if (g[yy][xx] == 0) { full = false; break; }
                if (!full) continue;
                n++;
                for (int xx = 0; xx < W; xx++) burst(xx + 0.5f, yy + 0.5f, colOf(g[yy][xx]), 2);
                // las filas de debajo suben una
                for (int k = yy; k < H - 1; k++) g[k] = g[k + 1];
                g[H - 1] = new int[W];
                yy++;
            }
            if (n > 0) {
                combo++;
                comboT = 3;
                int pts = 100 * n * n * combo;
                addScore(pts);
                cleared += n;
                chip.sfx(Chip.SFX_LEVEL);
                if (combo >= 2) say("¡COMBO x" + combo + "!  +" + pts);
                shake = 0.15f * n;
                if (cleared >= level * 8) levelUp();
            }
        }

        @Override void draw(Canvas c) {
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) if (g[y][x] != 0) cell(c, x, y, colOf(g[y][x]));
            for (float[] f : flying) cell(c, f[0], (int) Math.floor(f[1]), f[2] == 1 ? Color.rgb(255, 140, 40) : f[2] == 2 ? Color.rgb(255, 240, 120) : Color.rgb(120, 255, 170));
            int gc = next == 1 ? Color.rgb(255, 140, 40) : next == 2 ? Color.rgb(255, 240, 120) : Color.rgb(120, 255, 170);
            cell(c, gx, H - 2, gc);
            cell(c, gx - 1, H - 1, Color.rgb(80, 200, 255)); cell(c, gx, H - 1, Color.rgb(80, 200, 255)); cell(c, gx + 1, H - 1, Color.rgb(80, 200, 255));
            if (!lcd()) {
                p.setColor(Color.argb(70, 255, 60, 60));
                c.drawRect(fx, fy + (H - 3) * cs - 1, fx + W * cs, fy + (H - 3) * cs + 1, p);
            }
        }

        @Override void drawExtraHud(Canvas c) {
            textLeft(c, "Siguiente: " + (next == 1 ? "💣 BOMBA" : next == 2 ? "⚡ RAYO" : "bloque") + (combo >= 2 ? "   COMBO x" + combo : ""), 10, fy + cs * H + 16, 11, Color.LTGRAY);
        }
    }
}
