package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * EL PASTOR DE ECOS — aventura metroidvania.
 * Bee, una ovejita con un cencerro mágico, recorre Lanaria para recuperar los 20 Ecos robados por la Polilla Gris.
 */
public class EcoView extends GameKit.GameView implements ArcadeActivity.Backable {

    // ---------------- física (en casillas) ----------------
    static final float GRAV = 52, JUMP = 19, DJUMP = 17, SPEED = 7, MAXFALL = 20;

    // ---------------- modos ----------------
    static final int M_TITLE = 0, M_INTRO = 1, M_PLAY = 2, M_DIALOG = 3, M_SHOP = 4, M_FORGE = 5, M_MAP = 6,
            M_PAUSE = 7, M_BEAST = 8, M_AMULET = 9, M_DEAD = 10, M_POLICE = 11, M_REST = 12, M_CONFIRM = 13,
            M_ENDING = 14, M_VAMPEND = 15, M_CONTROLS = 16, M_BOSSRUSH = 17, M_ACHIEVE = 18;
    int mode = M_TITLE;

    static class Body {
        float x, y, w, h, vx, vy;
        boolean onGround, hitWall;
        Body(float w, float h) { this.w = w; this.h = h; }
    }

    static class Enemy {
        char type;                 // 'k' criatura · 'B' jefe del motor · '1' '2' '3' jefes originales
        EcoData.Kind kind;
        EcoData.Boss bdef;
        Body b;
        float hp, maxHp, t, t2, cd, cd2, flash, dir = 1, homeX, homeY, dmg, slow, stun, vis = 1, aux, aux2, laserY = -1, slashT, thornT;
        float shield = -1, hitT, winT, aux3, aux4;      // trucos de los jefes (EcoBoss2)
        float phaseLock;           // jefes finales: invulnerable mientras cambia de fase
        boolean decoy;
        int state, sub, role, bellsMin, bellsMax, cycle, move, hits;
        boolean boss, hidden, dead, phase2, enraged, flying, invuln;
        float[] lanes;
        String say;
        float sayT;
        Enemy partner;
    }

    static final int SH_WAVE = 0, SH_FLAME = 1, SH_PEBBLE = 2, SH_RING = 3, SH_ROCK = 4, SH_GHOSTFIRE = 5,
            SH_ORB = 6, SH_BEAM = 7, SH_SHOCK = 8, SH_EWAVE = 9, SH_VINE = 10, SH_ROSE = 11, SH_CAPE = 12, SH_WEB = 13, SH_SNOW = 14,
            SH_DUST = 15, SH_VOID = 16, SH_COCOON = 17, SH_THREAD = 18;

    static class Shot {
        float x, y, vx, vy, w, h, dmg, life, grav;
        int kind, bounces, color;
        boolean mine, pierce, dead, big, frost, selfHit, homing, echo;
        final List<Enemy> hit = new ArrayList<>();
    }

    static class Pick {
        float x, y, vy;
        char type;          // '$' cascabel, 'c' cofre, 'o' mineral, 'k' corderito, 'A' habilidad, 'E' emblema, 'D' tus cascabeles
        int value;
        String flag, data = "";
        boolean dead, settled;
    }

    static class Npc {
        char ch;
        float x, y;
        String data = "";
    }

    static class Mov {
        float x, y, w = 3, vx = 2.2f, minX, maxX;
    }

    static class Fx {
        float x, y, t, life = 0.8f;
        String s;
        int color;
    }

    static class Warn {
        float x, y, w, h, t;
    }

    static class Decal {
        float x, y, w, h;
        Bitmap sprite;
        boolean blood;
    }

    // ---------------- mundo ----------------
    EcoWorld.Room room;
    float T, ox, oy;
    Bitmap roomBmp, bgBmp;
    final Random rnd = new Random();
    float shake;

    // ---------------- jugador ----------------
    final Body pl = new Body(0.8f, 0.85f);
    boolean facingR = true;
    int airJumps, lana, weapon;
    float hp, invul, knockT, healHold, shootCd, flameCd, coyote, walk, dashT, dashCd, chargeT, regenT, shieldT, clawT, wallT;
    boolean prevShootDown;

    // ---------------- progreso (se guarda) ----------------
    int bells, ore, cLvl = 1, branch, ecos, lambs, keys, ckeys, bkeys;

    // ---------------- v0.8: Coliseo, Sinfonía, finales, aspecto OLED ----------------
    boolean coliseo;                       // peleando en el Coliseo del Eco
    int colRound, colIdx;                  // tanda (0-4) y rival dentro de la tanda (0-4)
    float colWait;                         // pausa antes del siguiente titán
    boolean colBetween;                    // tanda ganada: el Presentador espera tu respuesta
    EcoWorld.Room colBack, arena;
    float colBackX, colBackY;
    static final class Echo { Enemy e; float d, t; }
    final List<Echo> echoes = new ArrayList<>();
    int symShots;                          // Set de la Sinfonía: cada 5.º disparo es gigante
    float silentT, drainT;                 // ...y 5 s sin sonar quitan vida
    float lambsT = -1, lambsHitT;          // final verdadero: los corderitos llegan a la pelea
    int endKind;                           // 0 verdadero · 1 sacrificio · 2 adicto al eco
    Bitmap sPresenter, sBKey, sBDoor;
    Bitmap oledBmp, oledSmall;
    Canvas oledCanvas, oledSmallCanvas;
    final Paint oledPaint = new Paint(Paint.FILTER_BITMAP_FLAG), bloomPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    {
        android.graphics.ColorMatrix cm = new android.graphics.ColorMatrix();
        cm.setSaturation(1.45f);
        android.graphics.ColorMatrix con = new android.graphics.ColorMatrix(new float[]{
                1.12f, 0, 0, 0, -10, 0, 1.12f, 0, 0, -10, 0, 0, 1.12f, 0, -10, 0, 0, 0, 1, 0});
        cm.postConcat(con);
        oledPaint.setColorFilter(new android.graphics.ColorMatrixColorFilter(cm));
        bloomPaint.setAlpha(80);
        bloomPaint.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN));
    }
    boolean oled() { return prefs().getBoolean("eco_oled", true); }
    final Paint bgOledPaint = new Paint(Paint.FILTER_BITMAP_FLAG), sh3d = new Paint();
    {
        android.graphics.ColorMatrix bm = new android.graphics.ColorMatrix();
        bm.setSaturation(1.3f);
        bm.postConcat(new android.graphics.ColorMatrix(new float[]{0.8f, 0, 0, 0, -6, 0, 0.8f, 0, 0, -6, 0, 0, 0.85f, 0, -4, 0, 0, 0, 1, 0}));
        bgOledPaint.setColorFilter(new android.graphics.ColorMatrixColorFilter(bm));
        sh3d.setColorFilter(new android.graphics.PorterDuffColorFilter(Color.BLACK, android.graphics.PorterDuff.Mode.SRC_ATOP));
    }

    void shadow(Canvas c, float x, float y, float w, float h) {
        float g = groundBelow(x + w / 2, y + h - 0.05f);
        float dist = g - (y + h);
        if (dist > 4) return;
        float k = 1 - dist / 5f;
        c.drawOval(x - 0.05f, g - 0.14f * k, x + w + 0.05f, g + 0.1f * k, p);
    }
    Set<String> flags = new HashSet<>(), visited = new HashSet<>(), owned = new HashSet<>(), abilities = new HashSet<>();
    List<String> equipped = new ArrayList<>();
    Map<String, Integer> kills = new HashMap<>();
    String saveRoom = "0_0";
    float saveX = 5, saveY = 14;
    String dropRoom;
    float dropX, dropY;
    int dropBells;
    float playTime;
    boolean phoenixUsed;

    // ---------------- emblemas (suma de modificadores) ----------------
    final float[] M = new float[EcoData.NM];

    // ---------------- entidades de la sala ----------------
    final List<Enemy> enemies = new ArrayList<>();
    final List<Shot> shots = new ArrayList<>();
    final List<Pick> picks = new ArrayList<>();
    final List<Npc> npcs = new ArrayList<>();
    final List<Mov> movs = new ArrayList<>();
    final List<Fx> fx = new ArrayList<>();
    final List<Warn> warns = new ArrayList<>();
    final List<Decal> decals = new ArrayList<>();
    Paint corpsePaint;
    boolean fightActive, introShown;

    // ---------------- trucos de los jefes (EcoBoss2) ----------------
    float muteT, invertT, sonarT, ringT, heat, pullVX, pullT, beatT, beatMeter, lastSoundX, lastSoundY, lastSoundT = -99;
    boolean water, fog, canto, floatUsed, firedNow;
    int gravSign = 1;
    final List<float[]> silence = new ArrayList<>();      // x, y, radio, vida
    final List<float[]> statics = new ArrayList<>();      // x, y, ancho, vida, tipo (0 frena, 1 grieta)
    final List<float[]> barricades = new ArrayList<>();   // x, y, ancho, alto, golpes, vida
    final List<float[]> gongs = new ArrayList<>();        // x, y, recarga, brillo
    final List<float[]> shotLog = new ArrayList<>();      // x, y, vx, tiempo
    final List<float[]> stalactites = new ArrayList<>();  // x, y, vy
    final List<Enemy> decoys = new ArrayList<>();
    final float[] trailX = new float[90], trailY = new float[90];
    final boolean[] trailFace = new boolean[90], trailShot = new boolean[90];
    int trailI, trailN;

    void resetGimmicks() {
        muteT = invertT = sonarT = ringT = heat = pullVX = pullT = beatT = beatMeter = 0;
        water = fog = canto = false;
        gravSign = 1;
        silence.clear(); statics.clear(); barricades.clear(); gongs.clear(); shotLog.clear(); stalactites.clear();
        for (Enemy d : decoys) d.dead = true;
        decoys.clear();
        trailN = 0;
        chip.tempoMul = 1f;
    }

    /** Daño directo a un jefe (estalactitas, engranajes, trampas...), sin sus defensas. */
    void damageBoss(Enemy e, float d) {
        if (e.dead) return;
        if (e.type == 'B') d = finalBossDamage(e, d);
        if (d <= 0) return;
        e.hp -= d;
        e.flash = 0.15f;
        chip.sfx(Chip.SFX_HIT);
        float_(String.valueOf(Math.round(d)), e.b.x + e.b.w / 2, e.b.y - 0.4f, Color.rgb(255, 230, 120));
        if (e.hp <= 0) kill(e, false);
    }

    // ---------------- interfaz ----------------
    String[] dlg;
    int dlgIdx;
    float dlgChars;
    String dlgName;
    Bitmap dlgFace;
    Runnable dlgDone;
    String banner;
    float bannerT, deadT, roomNameT, gateMsgT, endT;
    int beastSel, beastPage, introIdx, shopId, emblemPage, endIdx;
    boolean restMode;
    String confirmText;
    Runnable confirmYes, confirmNo;
    Npc nearNpc;
    // mapa
    float mapZoom = 1, mapPanX, mapPanY, lastTouchX, lastTouchY, pinchD;
    boolean mapDrag;
    final Map<String, Bitmap> miniMaps = new HashMap<>();

    GameKit.Btn bL, bR, bUse, bJump, bShoot, bHeal, bSwap, bPause, bMap, bDash;
    // controles: joystick virtual (por defecto) o botones, opacidad y mando externo opcional
    GameKit.Ctrl ctrl;
    // Modo Jefes: pelear contra jefes ya vencidos con todo al máximo, sin tocar la partida
    boolean bossMode;
    String bossRunId, bossMsg;
    EcoWorld.Room bossRoom;
    float bossT;
    int bossPage;
    boolean joyMode, stickJump;
    static final int CTRL_JOY = 0, CTRL_BUTTONS = 1;

    // ---------------- sprites ----------------
    Bitmap sBee, sBeeRun, sBeeJump, sBeeL, sBeeRunL, sBeeJumpL;
    Bitmap sTopo, sSabio, sMapache, sSapo, sHerrera, sFantasma, sFardo, sPolice, sCorpse, sSkel, sKey, sCKey, sWings;
    Bitmap sBabosa, sBat, sBat2, sBeetle, sMinero, sBatCu, sBatCu2;
    Bitmap sReyTopo, sVagoneta, sGemelo, sGemelo2;
    Bitmap sChest, sOre, sLamb, sTromp, sBoots, sBell, sDrop;

    EcoView(Context c) {
        super(c);
        buildSprites();
        sPolice = EcoArt.police();
        sCorpse = EcoArt.corpse();
        sSkel = EcoArt.skeleton();
        sKey = EcoArt.key(false);
        sCKey = EcoArt.key(true);
        sWings = EcoArt.wings();
        sBKey = EcoArt.blueKey();
        sPresenter = EcoArt.presenter();
        sBDoor = EcoArt.blueDoor();
        ctrl = new GameKit.Ctrl(prefs(), "eco");
        stick = new GameKit.Stick();
        applyCtrl();
    }

    /** Recoloca los botones tras cambiar zurdo o tamaño. */
    void relayout() { pad.btns.clear(); layout(); showPad(false); }

    /** Aplica los ajustes de controles guardados. */
    void applyCtrl() {
        joyMode = ctrl.mode(CTRL_JOY) == CTRL_JOY;
        gp.enabled = ctrl.gamepad();
        float op = ctrl.opacity() / 100f;
        stick.alpha = op;
        pad.alpha = Math.min(1f, op + 0.25f);
        if (bL != null) showPad(mode == M_PLAY);
    }

    boolean blood() { return prefs().getBoolean("eco_blood", false); }

    // =====================================================================
    // Tamaño y botones
    // =====================================================================
    @Override
    void computeScale(int w, int h) {
        scale = h / 360f;
        vh = 360;
        vw = w / scale;
        // la sala ocupa el centro; a los lados quedan franjas oscuras para los botones y el marcador
        float band = Math.max(118, vw * 0.155f);
        T = Math.min((vw - 2 * band) / EcoWorld.W, (vh - 28) / EcoWorld.H);
        ox = (vw - EcoWorld.W * T) / 2;
        oy = (vh - 28 - EcoWorld.H * T) / 2 + 4;
    }

    @Override
    void layout() {
        float lw = ox, rx = ox + EcoWorld.W * T, rw = vw - rx;
        bL = pad.add("◀", 6, 264, lw / 2 - 3, 354, 28);
        bR = pad.add("▶", lw / 2 + 3, 264, lw - 6, 354, 28);
        bUse = pad.add("▲", lw / 2 + 3, 190, lw - 6, 254, 18);
        bDash = pad.add("💨", 6, 190, lw / 2 - 3, 254, 20);
        bDash.round = true;
        bJump = pad.add("⬆", rx + rw / 2 + 3, 264, vw - 6, 354, 28);
        bJump.round = true;
        bShoot = pad.add("🔔", rx + 6, 264, rx + rw / 2 - 3, 354, 24);
        bShoot.round = true;
        bHeal = pad.add("🧶", rx + rw / 2 + 3, 186, vw - 6, 254, 20);
        bHeal.round = true;
        bSwap = pad.add("⇄", rx + 6, 192, rx + rw / 2 - 3, 250, 18);
        bPause = pad.add("⏸", vw - 46, 6, vw - 8, 40, 16);
        bMap = pad.add("🗺", vw - 92, 6, vw - 54, 40, 16);
        // joystick: abajo en la franja izquierda; se puede agarrar en toda la parte baja izquierda
        float jr = Math.max(28, Math.min(46, (lw - 8) / 2.6f));
        float sz = ctrl.size() / 100f;
        jr *= sz;
        stick.place(lw / 2, vh - jr * 1.45f, jr);
        stick.zone.set(0, 150, Math.max(lw, vw * 0.3f), vh);
        // tamaño de los botones (desde su centro, sin salirse de la pantalla)
        if (sz != 1f) for (GameKit.Btn b : pad.btns) {
            if (b == bPause || b == bMap) continue;
            float cx = b.r.centerX(), cy = b.r.centerY(), hw = b.r.width() * sz / 2, hh = b.r.height() * sz / 2;
            cy = Math.min(cy, vh - 4 - hh);
            b.r.set(cx - hw, cy - hh, cx + hw, cy + hh);
            b.textSize *= sz;
        }
        // modo zurdo: espejo horizontal (pausa y mapa se quedan arriba a la derecha)
        if (ctrl.lefty()) {
            for (GameKit.Btn b : pad.btns) {
                if (b == bPause || b == bMap) continue;
                float l = vw - b.r.right, r = vw - b.r.left;
                b.r.left = l; b.r.right = r;
            }
            stick.place(vw - stick.homeX, stick.homeY, stick.r);
            stick.zone.set(vw - stick.zone.right, stick.zone.top, vw - stick.zone.left, stick.zone.bottom);
        }
        // mando externo: A saltar, X cencerro, B embestida, Y curar, ↑ hablar, LB/RB cambiar, START pausa, SELECT mapa
        gp.bind[GameKit.G_A] = bJump;
        gp.bind[GameKit.G_X] = bShoot;
        gp.bind[GameKit.G_B] = bDash;
        gp.bind[GameKit.G_Y] = bHeal;
        gp.bind[GameKit.G_UP] = bUse;
        gp.bind[GameKit.G_L1] = bSwap;
        gp.bind[GameKit.G_R1] = bSwap;
        gp.bind[GameKit.G_START] = bPause;
        gp.bind[GameKit.G_SELECT] = bMap;
        showPad(mode == M_PLAY);
    }

    void showPad(boolean v) {
        for (GameKit.Btn b : pad.btns) b.visible = v;
        if (bL != null) { bL.visible = v && !joyMode; bR.visible = v && !joyMode; }
        // joystick: se salta empujándolo hacia arriba, así que sobra el botón ⬆; ▲ solo aparece junto a alguien
        if (bJump != null && joyMode) bJump.visible = false;
        if (bUse != null) bUse.visible = v && (!joyMode || nearNpc != null);
        stick.visible = v && joyMode;
        // mando externo: fuera todos los controles táctiles salvo pausa y mapa
        if (gp.enabled) {
            for (GameKit.Btn b : pad.btns) if (b != bPause && b != bMap) b.visible = false;
            stick.visible = false;
        }
        if (!stick.visible) stick.reset();
        if (bSwap != null) bSwap.visible = v && has(EcoData.AB_TROMP) && !claws();
        if (bDash != null) bDash.visible = v && has(EcoData.AB_DASH);
        if (bShoot != null) bShoot.label = claws() ? "🐾" : "🔔";
    }

    // =====================================================================
    // Guardar / cargar
    // =====================================================================
    boolean hasSave() { return prefs().getString("eco_save", null) != null; }

    void saveGame(boolean atFardo) {
        if (bossMode) return;            // el Modo Jefes nunca toca tu partida
        if (coliseo && !atFardo) { /* en el Coliseo se guarda igual, pero vuelves al último fardo */ }
        try {
            JSONObject o = new JSONObject();
            if (atFardo && room != null) { saveRoom = room.key(); saveX = pl.x; saveY = pl.y; }
            o.put("room", saveRoom); o.put("sx", (double) saveX); o.put("sy", (double) saveY);
            o.put("bells", bells); o.put("ore", ore); o.put("lvl", cLvl); o.put("branch", branch);
            o.put("ecos", ecos); o.put("lambs", lambs); o.put("keys", keys); o.put("ckeys", ckeys); o.put("bkeys", bkeys);
            o.put("dj", has(EcoData.AB_DJ)); o.put("tromp", has(EcoData.AB_TROMP));
            o.put("time", (double) playTime);
            o.put("flags", new JSONArray(flags));
            o.put("visited", new JSONArray(visited));
            o.put("owned", new JSONArray(owned));
            o.put("abil", new JSONArray(abilities));
            o.put("equipped", new JSONArray(equipped));
            JSONObject k = new JSONObject();
            for (Map.Entry<String, Integer> e : kills.entrySet()) k.put(e.getKey(), e.getValue());
            o.put("kills", k);
            if (dropRoom != null) { o.put("dropRoom", dropRoom); o.put("dropX", (double) dropX); o.put("dropY", (double) dropY); o.put("dropBells", dropBells); }
            prefs().edit().putString("eco_save", o.toString()).apply();
        } catch (Exception ignored) {}
    }

    boolean loadGame() {
        try {
            JSONObject o = new JSONObject(prefs().getString("eco_save", "{}"));
            saveRoom = o.getString("room");
            saveX = (float) o.getDouble("sx"); saveY = (float) o.getDouble("sy");
            bells = o.getInt("bells"); ore = o.getInt("ore"); cLvl = o.getInt("lvl"); branch = o.getInt("branch");
            lambs = o.getInt("lambs");
            keys = o.optInt("keys", 0); ckeys = o.optInt("ckeys", 0); bkeys = o.optInt("bkeys", 0);
            playTime = (float) o.optDouble("time", 0);
            flags = toSet(o.getJSONArray("flags"));
            visited = toSet(o.getJSONArray("visited"));
            owned = toSet(o.getJSONArray("owned"));
            abilities = o.has("abil") ? toSet(o.getJSONArray("abil")) : new HashSet<String>();
            if (o.optBoolean("dj", false)) abilities.add(EcoData.AB_DJ);          // partidas antiguas
            if (o.optBoolean("tromp", false)) abilities.add(EcoData.AB_TROMP);
            equipped = new ArrayList<>();
            JSONArray eqa = o.getJSONArray("equipped");
            for (int i = 0; i < eqa.length(); i++) if (EcoData.emblem(eqa.getString(i)) != null) equipped.add(eqa.getString(i));
            kills = new HashMap<>();
            JSONObject k = o.getJSONObject("kills");
            Iterator<String> it = k.keys();
            while (it.hasNext()) { String key = it.next(); kills.put(key, k.getInt(key)); }
            dropRoom = o.has("dropRoom") ? o.getString("dropRoom") : null;
            if (dropRoom != null) { dropX = (float) o.getDouble("dropX"); dropY = (float) o.getDouble("dropY"); dropBells = o.getInt("dropBells"); }
            recalc();
            countEcos();
            for (String fl : flags) {
                if (fl.startsWith("boss_")) recordDex(fl.substring(5));
                else if (fl.equals("boss1") || fl.equals("boss2") || fl.equals("boss3")) recordDex(fl.substring(4));
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static Set<String> toSet(JSONArray a) throws Exception {
        Set<String> s = new HashSet<>();
        for (int i = 0; i < a.length(); i++) s.add(a.getString(i));
        return s;
    }

    void newGame() {
        bells = 0; ore = 0; cLvl = 1; branch = 0; ecos = 0; lambs = 0; keys = 0; ckeys = 0; bkeys = 0; weapon = 0; coliseo = false;
        flags = new HashSet<>(); visited = new HashSet<>(); owned = new HashSet<>(); abilities = new HashSet<>();
        equipped = new ArrayList<>(); kills = new HashMap<>();
        dropRoom = null; playTime = 0; phoenixUsed = false;
        recalc();
        saveRoom = "0_0"; saveX = 2; saveY = 14 + 1 - pl.h;
        prefs().edit().remove("eco_save").apply();
        introIdx = 0;
        mode = M_INTRO;
        chip.play(Songs.PUEBLO);
    }

    void continueGame() {
        if (!loadGame()) { newGame(); return; }
        respawn();
    }

    void respawn() {
        String[] k = saveRoom.split("_");
        EcoWorld.Room r = EcoWorld.at(Integer.parseInt(k[0]), Integer.parseInt(k[1]));
        if (r == null) r = EcoWorld.at(0, 0);
        recalc();
        hp = maxHp();
        invul = 1.5f;
        pl.vx = pl.vy = 0;
        enterRoom(r);
        pl.x = saveX; pl.y = saveY;
        unstick();
        mode = M_PLAY;
        showPad(true);
    }

    @Override
    void onPauseGame() {
        if (mode == M_PLAY) { mode = M_PAUSE; showPad(false); }
        if (room != null && mode != M_TITLE && mode != M_INTRO && mode != M_ENDING && mode != M_VAMPEND) saveGame(false);
    }

    @Override
    void onResumeGame() {
        if (mode == M_TITLE || mode == M_INTRO) chip.play(Songs.PUEBLO);
        else if (room != null) playRoomMusic();
    }

    @Override
    public boolean onBack() {
        if (mode == M_PLAY) { mode = M_PAUSE; showPad(false); return true; }
        if (mode == M_PAUSE) { mode = M_PLAY; showPad(true); return true; }
        if (mode == M_MAP || mode == M_BEAST || mode == M_CONTROLS || (mode == M_AMULET && !restMode)) { mode = M_PAUSE; return true; }
        if (mode == M_AMULET && bossMode) { saveBossEquip(); mode = M_BOSSRUSH; return true; }
        if (mode == M_AMULET) { mode = M_REST; return true; }
        if (mode == M_BOSSRUSH) { bossMode = false; mode = M_TITLE; return true; }
        if (mode == M_ACHIEVE) { mode = achFrom; return true; }
        if (mode == M_SHOP || mode == M_FORGE || mode == M_POLICE || mode == M_REST) { backToPlay(); return true; }
        if (mode == M_CONFIRM) { Runnable r = confirmNo; backToPlay(); if (r != null) r.run(); return true; }
        return false;
    }

    void backToPlay() {
        mode = M_PLAY;
        restMode = false;
        showPad(true);
        pad.releaseAll();
    }

    // =====================================================================
    // Estadísticas (emblemas)
    // =====================================================================
    boolean eq(String id) { return equipped.contains(id); }
    boolean has(String ability) { return abilities.contains(ability); }
    boolean claws() { return M[EcoData.M_CLAWS] > 0; }

    void recalc() {
        java.util.Arrays.fill(M, 0);
        for (String id : equipped) {
            EcoData.Emblem e = EcoData.emblem(id);
            if (e == null) continue;
            for (int i = 0; i < EcoData.NM; i++) M[i] += e.m[i];
        }
        if (claws()) weapon = 0;
        if (hp > maxHp()) hp = maxHp();
    }

    boolean symSetOn() {
        for (String id : EcoData.SYM_SET) if (!eq(id)) return false;
        return true;
    }

    int symOwned() {
        int n = 0;
        for (String id : EcoData.SYM_SET) if (owned.contains(id)) n++;
        return n;
    }

    // ---------------- logros (comunes a todas las partidas) ----------------
    Set<String> achievements() {
        Set<String> a = new HashSet<>();
        for (String id : prefs().getString("eco_ach", "").split(",")) if (!id.isEmpty()) a.add(id);
        return a;
    }

    void unlock(String id) {
        if (bossMode) return;
        Set<String> a = achievements();
        if (!a.add(id)) return;
        prefs().edit().putString("eco_ach", String.join(",", a)).apply();
        for (String[] ach : EcoData.ACHIEVEMENTS) if (ach[0].equals(id)) { banner = "🏆 LOGRO: " + ach[1]; bannerT = 4f; }
        chip.sfx(Chip.SFX_LEVEL);
    }

    boolean vampSetOn() {
        for (String id : EcoData.VAMP_SET) if (!eq(id)) return false;
        return true;
    }

    float maxHp() { return Math.max(20, EcoData.BASE_HP + M[EcoData.M_HP]); }

    float dmgMult() {
        float m = 1 + M[EcoData.M_DMG] / 100f;
        if (M[EcoData.M_FURY] > 0 && hp < maxHp() * 0.3f) m *= 1 + M[EcoData.M_FURY] / 100f;
        return m;
    }

    static final float ATK_BUFF = 2;   // v0.7: la oveja pega un poco más
    float waveDmg() { return (EcoData.waveBase(cLvl) + ATK_BUFF + M[EcoData.M_ATK]) * dmgMult() * (1 + M[EcoData.M_WAVEDMG] / 100f); }
    float flameDmg() { return (5 + 1 + 2.5f * (cLvl - 1) + M[EcoData.M_ATK] * 0.4f) * dmgMult() * (1 + M[EcoData.M_TROMP] / 100f); }
    float clawDmg() { return (EcoData.waveBase(cLvl) * 1.35f + ATK_BUFF + M[EcoData.M_ATK]) * dmgMult(); }
    float speed() { return SPEED * (1 + M[EcoData.M_SPEED] / 100f); }
    float jumpV() { return JUMP * (1 + M[EcoData.M_JUMP] / 100f); }
    int maxAirJumps() { return has(EcoData.AB_DJ) ? 1 + (int) M[EcoData.M_AIRJUMP] : 0; }
    float healTime() { return 0.8f / (1 + M[EcoData.M_HEALSPD] / 100f); }
    float healAmount() { return 25 * (1 + M[EcoData.M_HEALAMT] / 100f); }
    float shotCooldown() { return 0.3f / (1 + M[EcoData.M_RATE] / 100f); }
    boolean pierce() { return branch == 3 || M[EcoData.M_PIERCE] > 0; }
    int bounces() { return Math.max(branch == 2 ? 2 : 0, (int) M[EcoData.M_BOUNCE]); }
    boolean flag(String f) { return f != null && !f.isEmpty() && flags.contains(f); }

    /** ¿Ya derrotaste a este jefe? */
    boolean defeated(String id) {
        if (id == null) return false;
        if (id.equals("1") || id.equals("2") || id.equals("3")) return flag("boss" + id);
        return flag("boss_" + id);
    }

    void countEcos() {
        int n = 0;
        for (EcoData.Boss b : EcoData.BOSSES) if (b.eco > 0 && defeated(b.id)) n++;
        ecos = n;
    }

    /** Las rejas se abren con banderas ("boss1"), con ecos ("e:4") o con las 4 reliquias ("vamp4"). */
    boolean gateOpen(String g) {
        if (g == null || g.isEmpty()) return true;
        if (g.startsWith("e:")) return ecos >= Integer.parseInt(g.substring(2));
        return flag(g);
    }

    // =====================================================================
    // Salas
    // =====================================================================
    float roomDist() { return room == null ? 0 : room.dist + (room.dungeon > 0 ? 3 : 0) + (room.lair != 0 ? 4 : 0); }

    void enterRoom(EcoWorld.Room r) {
        if (bossMode && bossRoom != null && r != bossRoom) { finishBossRun(false); return; }
        room = r;
        enemies.clear(); shots.clear(); picks.clear(); npcs.clear(); movs.clear(); fx.clear(); warns.clear(); decals.clear();
        echoes.clear();
        resetGimmicks();
        fightActive = false;
        introShown = false;
        boolean firstVisit = r != arena && visited.add(r.key());
        roomNameT = firstVisit ? 3f : 1.6f;
        String bossHere = r.bossId();
        for (EcoWorld.Spawn s : r.spawns) {
            float x = s.x, y = s.y;
            String f = "it_" + r.key() + "_" + s.idx;
            switch (s.ch) {
                case 's': case 'b': case 'e': case 'm': case 'z': case 'v':
                    if (!r.safe) spawnKind(String.valueOf(s.ch), x, y);
                    break;
                case '%': if (!r.safe) spawnKind(s.data, x, y); break;
                case '1': if (!flag("boss1")) spawnBoss('1', x, y); break;
                case '2': if (!flag("boss2")) spawnBoss('2', x, y); break;
                case '3':
                    if (!flag("boss3")) {
                        Enemy a = spawnBoss('3', x - 4, y), b = spawnBoss('3', x + 4, y);
                        a.role = 0; b.role = 1; a.partner = b; b.partner = a;
                    }
                    break;
                case '!': {
                    EcoData.Boss d = EcoData.boss(s.data);
                    if (d != null && !defeated(d.id)) EcoBoss.spawn(this, d, x, y);
                    break;
                }
                case 'c':
                    if (s.data.equals("big")) {
                        if (defeated(bossHere) && !flag(f)) pick('c', x + 0.1f, y + 0.2f, 400, f);
                    } else if (!flag(f)) pick('c', x + 0.1f, y + 0.2f, s.data.equals("rich") ? 90 + rnd.nextInt(80) : 40 + rnd.nextInt(41), f);
                    break;
                case 'o': case 'k':
                    if (!flag(f)) pick(s.ch, x + 0.1f, y + 0.2f, 1, f);
                    break;
                case 'w': if (!has(EcoData.AB_TROMP)) pick('A', x + 0.1f, y + 0.2f, 0, f).data = EcoData.AB_TROMP; break;
                case 'j': if (!has(EcoData.AB_DJ)) pick('A', x + 0.1f, y + 0.2f, 0, f).data = EcoData.AB_DJ; break;
                case 'A': if (!has(s.data)) pick('A', x + 0.1f, y + 0.2f, 0, f).data = s.data; break;
                case 'E': if (!owned.contains(s.data)) pick('E', x + 0.1f, y + 0.2f, 0, f).data = s.data; break;
                case 'Y': if (!owned.contains("garras")) addNpc(s); break;
                case '~': {
                    Mov m = new Mov();
                    m.x = x; m.y = y; m.minX = Math.max(1, x - 4); m.maxX = Math.min(EcoWorld.W - 4, x + 4);
                    movs.add(m);
                    break;
                }
                case '@': break;
                default: addNpc(s);
            }
        }
        if (dropRoom != null && dropRoom.equals(r.key())) {
            Pick d = pick('D', dropX, dropY, dropBells, null);
            d.settled = true;
        }
        buildRoomBitmap();
        playRoomMusic();
        // FINAL SECRETO: con el set vampírico puesto, ante la Polilla Gris...
        if ("B20".equals(bossHere) && !defeated("B20") && vampSetOn()) startVampEnding();
    }

    void addNpc(EcoWorld.Spawn s) {
        Npc n = new Npc();
        n.ch = s.ch; n.x = s.x; n.y = s.y; n.data = s.data;
        npcs.add(n);
    }

    boolean bossAlive() {
        for (Enemy e : enemies) if (e.boss && !e.dead) return true;
        return false;
    }

    Enemy mainBoss() {
        for (Enemy e : enemies) if (e.boss && !e.dead) return e;
        return null;
    }

    Chip.Song bossSong() {
        Enemy e = mainBoss();
        if (e == null || e.bdef == null) return Songs.BOSS;
        switch (e.bdef.id) {
            case "V1": return Songs.HAROLD;
            case "V2": return Songs.ALOII;
            case "V3": return Songs.PLANTA;
            case "V4": return Songs.SANGRE;
            case "V5": return Songs.CONDE;
            case "B20": return Songs.POLILLA;
            default: return e.bdef.eco >= 10 ? Songs.GUARDIAN : Songs.BOSS;
        }
    }

    void playRoomMusic() {
        if (room == null) return;
        if (room.boss) {
            if (bossAlive() && fightActive) chip.play(bossSong());
            else if (bossAlive()) chip.silence();
            else chip.play(room.music);
        } else chip.play(room.music);
    }

    void go(int dx, int dy) {
        EcoWorld.Room n = EcoWorld.at(room.gx + dx, room.gy + dy);
        if (n == null) {   // no debería pasar: se queda dentro
            pl.x = GameKit.clamp(pl.x, 0.1f, EcoWorld.W - pl.w - 0.1f);
            pl.y = GameKit.clamp(pl.y, 0.1f, EcoWorld.H - pl.h - 0.1f);
            return;
        }
        float vy = pl.vy;
        enterRoom(n);
        if (mode != M_PLAY && mode != M_DIALOG) return;
        if (dx < 0) pl.x = EcoWorld.W - pl.w - 0.15f;
        if (dx > 0) pl.x = 0.15f;
        if (dy < 0) { pl.y = EcoWorld.H - pl.h - 0.05f; pl.vy = Math.min(vy, -17); }
        if (dy > 0) pl.y = 0.05f;
        unstick();
    }

    /** Si al entrar quedamos dentro de un muro, busca el hueco libre más cercano. */
    void unstick() {
        if (!boxSolid(pl.x, pl.y, pl.w, pl.h)) return;
        for (int r = 1; r < 6; r++) {
            float[][] tries = {{0, -r}, {0, r}, {-r, 0}, {r, 0}, {-r, -r}, {r, -r}};
            for (float[] t : tries) {
                if (!boxSolid(pl.x + t[0], pl.y + t[1], pl.w, pl.h)) { pl.x += t[0]; pl.y += t[1]; return; }
            }
        }
    }

    // ---------------- casillas ----------------
    static int doorDir(int tx, int ty) {
        if (tx == 0) return 0;
        if (tx == EcoWorld.W - 1) return 1;
        if (ty == 0) return 2;
        return 3;
    }

    boolean doorOpen(int tx, int ty) { return flag("door_" + room.key() + "_" + doorDir(tx, ty)); }

    boolean solid(int tx, int ty) {
        if (tx < 0 || tx >= EcoWorld.W || ty < 0 || ty >= EcoWorld.H) return false;
        char c = room.t[ty][tx];
        if (c == '#') return true;
        if (c == 'G') return !gateOpen(room.gateAt(tx, ty));
        if (c == 'B') return fightActive;
        if (c == 'K' || c == 'X') return !doorOpen(tx, ty);
        for (int i = 0; i < barricades.size(); i++) {
            float[] bq = barricades.get(i);
            if (tx + 1 > bq[0] && tx < bq[0] + bq[2] && ty + 1 > bq[1] && ty < bq[1] + bq[3]) return true;
        }
        return false;
    }

    boolean oneWay(int tx, int ty) {
        if (tx < 0 || tx >= EcoWorld.W || ty < 0 || ty >= EcoWorld.H) return false;
        return room.t[ty][tx] == '=';
    }

    char tileAt(float x, float y) {
        int tx = (int) Math.floor(x), ty = (int) Math.floor(y);
        if (tx < 0 || tx >= EcoWorld.W || ty < 0 || ty >= EcoWorld.H) return '.';
        return room.t[ty][tx];
    }

    boolean boxSolid(float x, float y, float w, float h) {
        for (int ty = (int) Math.floor(y); ty <= (int) Math.floor(y + h - 0.001f); ty++)
            for (int tx = (int) Math.floor(x); tx <= (int) Math.floor(x + w - 0.001f); tx++)
                if (solid(tx, ty)) return true;
        return false;
    }

    void moveBody(Body b, float dt, boolean useOneWay) {
        b.hitWall = false;
        b.x += b.vx * dt;
        int y0 = (int) Math.floor(b.y), y1 = (int) Math.floor(b.y + b.h - 0.001f);
        if (b.vx > 0) {
            int tx = (int) Math.floor(b.x + b.w);
            for (int ty = y0; ty <= y1; ty++) if (solid(tx, ty)) { b.x = tx - b.w - 0.001f; b.vx = 0; b.hitWall = true; break; }
        } else if (b.vx < 0) {
            int tx = (int) Math.floor(b.x);
            for (int ty = y0; ty <= y1; ty++) if (solid(tx, ty)) { b.x = tx + 1.001f; b.vx = 0; b.hitWall = true; break; }
        }
        float prevBottom = b.y + b.h;
        b.y += b.vy * dt;
        b.onGround = false;
        int x0 = (int) Math.floor(b.x), x1 = (int) Math.floor(b.x + b.w - 0.001f);
        if (b.vy > 0) {
            int ty = (int) Math.floor(b.y + b.h);
            for (int tx = x0; tx <= x1; tx++) {
                if (solid(tx, ty) || (useOneWay && oneWay(tx, ty) && prevBottom <= ty + 0.01f)) {
                    b.y = ty - b.h; b.vy = 0; b.onGround = true; break;
                }
            }
        } else if (b.vy < 0) {
            int ty = (int) Math.floor(b.y);
            for (int tx = x0; tx <= x1; tx++) if (solid(tx, ty)) { b.y = ty + 1; b.vy = 0; if (b == pl && gravSign < 0) b.onGround = true; break; }
        }
    }

    // =====================================================================
    // Creación de enemigos y objetos
    // =====================================================================
    Enemy spawnKind(String id, float x, float y) {
        EcoData.Kind k = EcoData.kind(id);
        if (k == null) return null;
        Enemy e = new Enemy();
        e.type = 'k';
        e.kind = k;
        e.b = new Body(k.w, k.h);
        float dist = roomDist();
        e.hp = e.maxHp = k.hp * EcoData.hpScale(dist);
        e.dmg = k.dmg * EcoData.dmgScale(dist);
        float bm = 1 + dist * 0.06f;
        e.bellsMin = Math.round(k.bMin * bm); e.bellsMax = Math.round(k.bMax * bm);
        e.flying = k.flies();
        e.b.x = x + (1 - e.b.w) / 2;
        e.b.y = k.arch == EcoData.A_SPIDER ? y : y + 1 - e.b.h;
        e.homeX = e.b.x; e.homeY = e.b.y;
        e.dir = rnd.nextBoolean() ? 1 : -1;
        e.t = rnd.nextFloat() * 5;
        e.cd = 1 + rnd.nextFloat() * 1.5f;
        enemies.add(e);
        return e;
    }

    Enemy spawnBoss(char t, float x, float y) {
        Enemy e = new Enemy();
        e.type = t;
        e.boss = true;
        switch (t) {
            case '1': e.b = new Body(1.8f, 1.6f); e.hp = 260; e.dmg = 15; e.bellsMin = 150; e.bellsMax = 150; break;
            case '2': e.b = new Body(2.4f, 1.4f); e.hp = 320; e.dmg = 15; e.bellsMin = 250; e.bellsMax = 250; break;
            default: e.b = new Body(1.4f, 1.0f); e.hp = 150; e.dmg = 12; e.bellsMin = 100; e.bellsMax = 100; e.flying = true; break;
        }
        e.maxHp = e.hp;
        e.b.x = x;
        e.b.y = y + 1 - e.b.h;
        e.homeX = x; e.homeY = e.b.y;
        e.cd = 1.5f;
        enemies.add(e);
        return e;
    }

    Pick pick(char type, float x, float y, int value, String f) {
        Pick p0 = new Pick();
        p0.type = type; p0.x = x; p0.y = y; p0.value = value; p0.flag = f;
        picks.add(p0);
        return p0;
    }

    void dropBellsAt(float x, float y, int total) {
        total = Math.round(total * (1 + M[EcoData.M_BELLS] / 100f));
        if (total <= 0) return;
        int n = Math.min(4, Math.max(1, total / 3));
        int left = total;
        for (int i = 0; i < n; i++) {
            int v = i == n - 1 ? left : total / n;
            left -= v;
            Pick c = pick('$', x + (rnd.nextFloat() - 0.5f) * 0.8f, y, v, null);
            c.vy = -6 - rnd.nextFloat() * 4;
        }
    }

    void float_(String s, float x, float y, int color) {
        Fx f = new Fx();
        f.s = s; f.x = x; f.y = y; f.color = color;
        fx.add(f);
    }

    void say(String s) {
        banner = s;
        bannerT = 3f;
    }

    void warn(float x, float y, float w, float h, float t) {
        Warn wn = new Warn();
        wn.x = x; wn.y = y; wn.w = w; wn.h = h; wn.t = t;
        warns.add(wn);
    }

    // =====================================================================
    // Diálogos
    // =====================================================================
    void dialog(String name, Bitmap face, String[] lines, Runnable done) {
        dlg = lines; dlgIdx = 0; dlgChars = 0; dlgName = name; dlgFace = face; dlgDone = done;
        mode = M_DIALOG;
        showPad(false);
    }

    void advanceDialog() {
        String cur = L.t(dlg[dlgIdx]);
        if (dlgChars < cur.length()) { dlgChars = cur.length(); return; }
        dlgIdx++;
        dlgChars = 0;
        if (dlgIdx >= dlg.length) {
            mode = M_PLAY;
            showPad(true);
            pad.releaseAll();
            Runnable r = dlgDone;
            dlgDone = null;
            if (r != null) r.run();
        }
    }

    void confirm(String text, Runnable yes, Runnable no) {
        confirmText = text; confirmYes = yes; confirmNo = no;
        mode = M_CONFIRM;
        showPad(false);
    }

    void interact(Npc n) {
        switch (n.ch) {
            case 'S':
                hp = maxHp();
                phoenixUsed = false;
                saveGame(true);
                chip.sfx(Chip.SFX_LEVEL);
                dialog("Fardo de heno", sFardo, EcoWorld.FARDO, () -> { mode = M_REST; restMode = true; showPad(false); });
                break;
            case 'T':
                dialog("Topo Abuelo", sTopo, flag("boss1") ? EcoWorld.TOPO_2 : EcoWorld.TOPO_1, () -> flags.add("talk_topo"));
                break;
            case 'O': {
                final String zf = "sabio_" + room.zone;
                boolean told = flag(zf);
                dialog("Sabelotodo", sSabio, told ? EcoWorld.SABIO_AGAIN : EcoWorld.sabio(room.zone), () -> flags.add(zf));
                break;
            }
            case 'M': {
                boolean met = flag("met_police");
                dialog("Agente Garduña", sPolice, met ? EcoData.POLICIA_AGAIN : EcoData.POLICIA,
                        () -> { flags.add("met_police"); mode = M_POLICE; showPad(false); });
                break;
            }
            case 'P':
                shopId = 0;
                try { if (!n.data.isEmpty()) shopId = Integer.parseInt(n.data); } catch (Exception ignored) {}
                dialog("Sapo Mercader", sSapo, EcoData.SAPO2, () -> { mode = M_SHOP; showPad(false); });
                break;
            case 'H': dialog("Herrera Topo", sHerrera, EcoWorld.HERRERA, () -> { mode = M_FORGE; showPad(false); }); break;
            case 'Q': dialog("Fantasma triste", sFantasma, EcoWorld.FANTASMA, null); break;
            case 'U': blueDoor(); break;
            case 'N': talkPresenter(); break;
            case 'Y':
                dialog("", sCorpse, EcoData.GARRAS_PREGUNTA, () -> confirm("¿Te pones las GARRAS VAMPÍRICAS?",
                        () -> takeClaws(true), () -> takeClaws(false)));
                break;
        }
    }

    void takeClaws(boolean equip) {
        owned.add("garras");
        for (Iterator<Npc> it = npcs.iterator(); it.hasNext(); ) if (it.next().ch == 'Y') it.remove();
        if (equip) {
            if (equipped.size() >= EcoData.MAX_EQUIP) {
                for (int i = equipped.size() - 1; i >= 0; i--) if (!EcoData.emblem(equipped.get(i)).vamp) { equipped.remove(i); break; }
            }
            equipped.add("garras");
            recalc();
            showPad(true);
        }
        chip.sfx(Chip.SFX_LEVEL);
        dialog("", sCorpse, equip ? EcoData.GARRAS_SI : EcoData.GARRAS_NO, () -> { checkVamp4(); saveGame(false); });
    }

    // =====================================================================
    // COLISEO DEL ECO (v0.8): 5 tandas de 5 titanes; cada tanda, una pieza del Set de la Sinfonía
    // =====================================================================
    static final String PRESENTER = "El Presentador";

    EcoWorld.Room arenaRoom() {
        if (arena != null) return arena;
        EcoWorld.Room r = new EcoWorld.Room();
        r.gx = 900; r.gy = 900;
        r.zone = EcoData.Z_CEMENTERIO;
        r.exits = new char[]{'#', '#', '#', '#'};
        r.name = "Coliseo del Eco";
        r.safe = true;
        r.music = Songs.COLISEO_LOBBY;
        int W = EcoWorld.W, H = EcoWorld.H;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
                r.t[y][x] = (y == 0 || y == H - 1 || x == 0 || x == W - 1) ? '#' : '.';
        for (int x = 4; x <= 8; x++) r.t[10][x] = '=';
        for (int x = 21; x <= 25; x++) r.t[10][x] = '=';
        for (int x = 12; x <= 17; x++) r.t[6][x] = '=';
        r.t[14][1] = r.t[14][W - 2] = '#';      // gradas
        EcoWorld.Spawn d = new EcoWorld.Spawn(); d.ch = 'U'; d.x = 2; d.y = 14; d.data = ""; d.idx = 0;
        EcoWorld.Spawn n = new EcoWorld.Spawn(); n.ch = 'N'; n.x = 14; n.y = 14; n.data = ""; n.idx = 1;
        r.spawns.add(d); r.spawns.add(n);
        arena = r;
        return r;
    }

    void blueDoor() {
        if (room == arena) {
            if (coliseo) { say("¡No puedes salir en mitad de una tanda! (Pausa → Retirarse)"); return; }
            confirm("¿Salir del Coliseo del Eco?", this::exitArena, null);
            return;
        }
        if (!flag("col_open")) {
            if (bkeys > 0) {
                bkeys--;
                flags.add("col_open");
                chip.sfx(Chip.SFX_DOOR);
                saveGame(false);
                dialog("", sBKey, EcoData.PRESENTADOR_ABRE, this::enterArena);
            } else dialog("", sBKey, EcoData.PRESENTADOR_PUERTA, null);
        } else enterArena();
    }

    void enterArena() {
        colBack = room; colBackX = pl.x; colBackY = pl.y;
        coliseo = false; colBetween = false;
        enterRoom(arenaRoom());
        pl.x = 3.6f; pl.y = 15 - pl.h; pl.vx = pl.vy = 0;
        unstick();
        if (mode != M_PLAY) backToPlay();
        say("🏟 COLISEO DEL ECO");
    }

    void exitArena() {
        coliseo = false; colBetween = false; fightActive = false;
        EcoWorld.Room b = colBack != null ? colBack : EcoWorld.at(0, 0);
        enterRoom(b);
        pl.x = colBackX; pl.y = colBackY; pl.vx = pl.vy = 0;
        unstick();
        backToPlay();
    }

    void talkPresenter() {
        final int done = symOwned();
        if (done >= 5) { dialog(PRESENTER, sPresenter, EcoData.PRESENTADOR_CAMPEONA, null); return; }
        String[] lines = flag("col_met") ? new String[]{"¡La tanda " + (done + 1) + " de 5 te espera! El público está que arde."} : EcoData.PRESENTADOR;
        flags.add("col_met");
        dialog(PRESENTER, sPresenter, lines, () -> confirm("¿Te inscribes en la tanda " + (done + 1) + " de 5? Son 5 titanes seguidos.", this::startColRound, null));
    }

    void startColRound() {
        colRound = symOwned();
        if (colRound >= 5) return;
        coliseo = true; colBetween = false; colIdx = 0; colWait = 2.2f;
        for (Iterator<Npc> it = npcs.iterator(); it.hasNext(); ) if (it.next().ch == 'N') it.remove();
        hp = maxHp();
        lana = 9;
        say("🏟 TANDA " + (colRound + 1) + " DE 5 · ¡QUE EMPIECE EL ESPECTÁCULO!");
        chip.play(colRound == 4 ? Songs.COLISEO_FINAL : Songs.COLISEO);
        shake = 0.3f;
    }

    void updateColiseo(float dt) {
        if (!coliseo || colBetween || bossAlive()) return;
        colWait -= dt;
        if (colWait > 0) return;
        EcoData.Boss d = EcoData.TITANS[colRound * 5 + colIdx];
        float sx = pl.x < EcoWorld.W / 2f ? 23 : 6;
        EcoBoss.spawn(this, d, sx, d.flyer ? 6 : 14);
        fightActive = true;
        introShown = true;
        chip.sfx(Chip.SFX_DOOR);
        shake = 0.4f;
        say("⚔ " + (colIdx + 1) + "/5 · " + d.name.toUpperCase());
    }

    void titanDown(Enemy e) {
        int prize = Math.round((150 + colRound * 60) * (1 + M[EcoData.M_BELLS] / 100f));
        bells += prize;
        float_("+" + prize + " 🔔", e.b.x + e.b.w / 2, e.b.y - 0.5f, Color.rgb(255, 230, 120));
        colIdx++;
        if (colIdx < 5) {
            colWait = 2.4f;
            say("¡" + e.bdef.name + " ha caído! · Siguiente rival...");
            return;
        }
        // tanda ganada: el Presentador vuelve y deja la pieza en el suelo
        String piece = EcoData.SYM_SET[colRound];
        coliseo = false; colBetween = true;
        owned.add(piece);
        if (symOwned() >= 5) unlock("coliseo");
        saveGame(false);
        Npc pr = new Npc(); pr.ch = 'N'; pr.x = 14; pr.y = 14; pr.data = "";
        npcs.add(pr);
        Pick pk = pick('E', 19.2f, 3, 0, null);
        pk.data = piece;
        chip.play(Songs.COLISEO_LOBBY);
        dialog(PRESENTER, sPresenter, EcoData.PRESENTADOR_RONDA, null);
    }

    // ---------------- final verdadero: los 5 corderitos llegan a la pelea contra LUMENIA ----------------
    static final float[] LAMB_X = {3, 7, 22, 25, 11};

    void updateLambs(float dt) {
        if (bossMode || !fightActive) { if (!fightActive) lambsT = -1; return; }
        Enemy e = mainBoss();
        if (e == null || e.bdef == null || !e.bdef.id.equals("B20")) return;
        if (lambsT < 0) {
            if (lambs >= 5 && e.hp < e.maxHp * 0.15f && e.phaseLock <= 0) {
                lambsT = 0; lambsHitT = 2.5f;
                chip.sfx(Chip.SFX_LEVEL);
                dialog("", sLamb, EcoData.LAMBS_ARRIVE, null);
            }
            return;
        }
        lambsT += dt;
        lambsHitT -= dt;
        if (lambsHitT <= 0 && !e.dead) {      // los cinco cencerros suenan a la vez
            lambsHitT = 1.1f;
            float d = Math.max(45, e.maxHp * 0.012f) * 5;
            e.hp -= d;
            e.flash = 0.15f;
            shake = 0.2f;
            chip.sfx(Chip.SFX_SHOOT);
            float_("🔔×5  " + Math.round(d), e.b.x + e.b.w / 2, e.b.y - 0.4f, Color.rgb(255, 240, 160));
            for (float lx : LAMB_X) {
                Fx f = new Fx();
                f.s = "♪"; f.x = lx + 0.4f; f.y = groundBelow(lx + 0.4f, 2) - 1.4f; f.color = Color.rgb(255, 240, 160);
                fx.add(f);
            }
            if (e.hp <= 0) kill(e, false);
        }
    }

    void drawLambs(Canvas c) {
        if (lambsT < 0 || !fightActive) return;
        for (int i = 0; i < LAMB_X.length; i++) {
            float tx = LAMB_X[i], from = tx < EcoWorld.W / 2f ? -1 : EcoWorld.W + 1;
            float k = Math.min(1, lambsT / 1.6f);
            float x = from + (tx - from) * k;
            float gy = groundBelow(tx + 0.4f, 2);
            float hop = (float) Math.abs(Math.sin(playTime * 9 + i)) * (k < 1 ? 0.3f : 0.15f);
            GameKit.draw(c, sLamb, x, gy - 0.75f - hop, 0.9f, 0.75f);
            if (k >= 1 && lambsHitT > 0.85f) {      // ¡clin! anillo de sonido
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.08f);
                p.setColor(Color.argb(200, 255, 240, 160));
                c.drawCircle(x + 0.45f, gy - 0.4f, 0.6f + (1.1f - lambsHitT) * 2.5f, p);
                p.setStyle(Paint.Style.FILL);
            }
        }
    }

    void askContinue() {
        if (symOwned() >= 5) { dialog(PRESENTER, sPresenter, EcoData.PRESENTADOR_CAMPEONA, null); return; }
        confirm("¿Quieres seguir peleando? Tanda " + (symOwned() + 1) + " de 5.", this::startColRound,
                () -> say("Habla con el Presentador cuando quieras, o sal por la puerta azul."));
    }

    void retireColiseo() {
        for (Enemy e : enemies) e.dead = true;
        enemies.clear();
        for (Shot sh : shots) sh.dead = true;
        coliseo = false; colBetween = false; fightActive = false;
        exitArena();
        say("🏳 Te retiras del Coliseo. El público aplaude igualmente.");
    }

    void checkVamp4() {
        if (flag("vamp4")) return;
        for (int i = 0; i < 4; i++) if (!owned.contains(EcoData.VAMP_SET[i])) return;
        flags.add("vamp4");
        chip.sfx(Chip.SFX_DOOR);
        dialog("", null, EcoData.CASTILLO_ABIERTO, () -> saveGame(false));
    }

    // =====================================================================
    // Bucle
    // =====================================================================
    @Override
    void update(float dt) {
        for (Iterator<Fx> it = fx.iterator(); it.hasNext(); ) {
            Fx f = it.next();
            f.t += dt; f.y -= dt * 0.8f;
            if (f.t > f.life) it.remove();
        }
        for (Iterator<Warn> it = warns.iterator(); it.hasNext(); ) if ((it.next().t -= dt) <= 0) it.remove();
        if (bannerT > 0) bannerT -= dt;
        if (roomNameT > 0) roomNameT -= dt;
        if (gateMsgT > 0) gateMsgT -= dt;
        if (shake > 0) shake -= dt;
        // mando externo fuera del juego: A = tocar (avanza diálogos), B = atrás, START = seguir
        if (gp.enabled && mode != M_PLAY) {
            if (gp.pressed(GameKit.G_A)) { tapped = true; tapX = -999; tapY = -999; }
            if (gp.pressed(GameKit.G_B)) { onBack(); return; }
            if (gp.pressed(GameKit.G_START) && mode == M_PAUSE) { backToPlay(); return; }
            if (gp.pressed(GameKit.G_SELECT) && mode == M_MAP) { mode = M_PAUSE; return; }
        }
        switch (mode) {
            case M_PLAY: play(dt); break;
            case M_DIALOG:
                dlgChars += dt * 45;
                if (tapped) { advanceDialog(); tapped = false; }   // el toque no pasa a la tienda que se abre después
                break;
            case M_DEAD:
                deadT += dt;
                if (bossMode && deadT > 1.6f) { finishBossRun(false); break; }
                if (deadT > 2.2f) respawn();
                break;
            case M_INTRO:
                if (tapped) {
                    tapped = false;
                    introIdx++;
                    if (introIdx >= EcoWorld.INTRO.length) {
                        recalc();
                        hp = maxHp();
                        enterRoom(EcoWorld.at(0, 0));
                        pl.x = 2.1f; pl.y = 15 - pl.h;
                        saveRoom = "0_0"; saveX = pl.x; saveY = pl.y;
                        mode = M_PLAY;
                        showPad(true);
                        saveGame(false);
                    }
                }
                break;
            case M_ENDING: case M_VAMPEND:
                endT += dt;
                if (tapped && endT > (mode == M_ENDING && endIdx == 0 ? 4f : 1.2f)) { tapped = false; advanceEnding(); }
                break;
        }
    }

    void play(float dt) {
        playTime += dt;
        if (bossMode && fightActive) bossT += dt;
        if (bPause.pressed()) { mode = M_PAUSE; showPad(false); return; }
        if (bMap.pressed()) { openMap(); return; }
        if (bSwap.pressed() && has(EcoData.AB_TROMP) && !claws()) { weapon = 1 - weapon; say(weapon == 0 ? "🔔 Cencerro" : "🔥 Trompeta de Brasas"); }

        // ---- regeneración y escudo ----
        if (M[EcoData.M_REGEN] > 0 && hp < maxHp()) {
            regenT += dt;
            if (regenT >= 3) { regenT = 0; hp = Math.min(maxHp(), hp + M[EcoData.M_REGEN]); }
        }
        if (shieldT > 0) shieldT -= dt;
        if (muteT > 0) muteT -= dt;
        if (invertT > 0) invertT -= dt;
        if (pullT > 0) pullT -= dt;
        if (ringT > 0) ringT -= dt;
        firedNow = false;
        boolean slowed = false;
        for (Iterator<float[]> it = statics.iterator(); it.hasNext(); ) {
            float[] st = it.next();
            st[3] -= dt;
            if (st[3] <= 0) { it.remove(); continue; }
            if (pl.x + pl.w > st[0] && pl.x < st[0] + st[2] && Math.abs(pl.y + pl.h - (st[1] + 0.4f)) < 0.7f) {
                if (st[4] == 1) hurt(10 + roomDist() * 0.5f, pl.x + pl.w / 2 + 1);
                else slowed = true;
            }
        }
        for (Iterator<float[]> it = silence.iterator(); it.hasNext(); ) if ((it.next()[3] -= dt) <= 0) it.remove();
        if (pl.onGround) floatUsed = false;

        // ---- curarse ----
        boolean healing = bHeal.down && pl.onGround && lana >= 3 && hp < maxHp();
        if (healing) {
            healHold += dt;
            if (healHold >= healTime()) {
                healHold = 0; lana -= 3;
                float h = Math.min(healAmount(), maxHp() - hp);
                hp += h;
                chip.sfx(Chip.SFX_POWER);
                float_("+" + Math.round(h), pl.x + 0.4f, pl.y - 0.3f, Color.rgb(255, 120, 150));
            }
        } else healHold = 0;

        // ---- movimiento ----
        float move = 0;
        if (!healing) {
            if (bL.down) move -= 1;
            if (bR.down) move += 1;
            float ax = joyMode && stick.active() ? stick.x(0.2f) : 0;
            if (ax == 0 && gp.enabled) { float g = gp.axisX(); if (Math.abs(g) > 0.25f) ax = Math.signum(g) * Math.min(1, (Math.abs(g) - 0.25f) / 0.6f + 0.2f); }
            if (ax != 0) move = ax;            // analógico: más inclinación = más rápido
        }
        if (invertT > 0) move = -move;           // hipnosis de la Marquesa
        if (move != 0 && dashT <= 0) facingR = move > 0;
        if (knockT > 0) knockT -= dt;
        else if (dashT <= 0) pl.vx = move * speed() * (slowed ? 0.5f : 1f) * (water ? 0.8f : 1f) + pullVX;
        pullVX = 0;
        walk += Math.abs(move) * dt * 9;

        // embestida
        if (dashCd > 0) dashCd -= dt;
        if (bDash.pressed() && has(EcoData.AB_DASH) && dashCd <= 0 && !healing) {
            dashT = 0.18f; dashCd = 0.55f;
            chip.sfx(Chip.SFX_DUCK);
            for (Enemy e : enemies) e.hits = 0;
        }
        boolean dashing = dashT > 0;
        if (dashing) {
            dashT -= dt;
            pl.vx = (facingR ? 1 : -1) * 21;
            pl.vy = 0;
            if (M[EcoData.M_DASHDMG] > 0) for (int i = 0; i < enemies.size(); i++) {
                Enemy e = enemies.get(i);
                if (!e.dead && e.hits == 0 && GameKit.overlap(pl.x, pl.y, pl.w, pl.h, e.b.x, e.b.y, e.b.w, e.b.h)) { e.hits = 1; damage(e, waveDmg() * 0.8f, false); }
            }
        }

        // salto, salto de pared y planeo
        coyote -= dt;
        if (pl.onGround) { coyote = 0.1f; airJumps = 0; }
        int wallDir = 0;
        if (has(EcoData.AB_WALL) && !pl.onGround) {
            if (boxSolid(pl.x - 0.08f, pl.y + 0.15f, 0.08f, pl.h - 0.3f)) wallDir = -1;
            else if (boxSolid(pl.x + pl.w, pl.y + 0.15f, 0.08f, pl.h - 0.3f)) wallDir = 1;
            if (wallDir != 0 && Math.signum(move) == wallDir && pl.vy > 3) pl.vy = 3;     // se desliza por la pared
        }
        float gs = gravSign, wf = water ? 0.8f : 1f;
        // empujar el joystick hacia arriba = saltar (mantenerlo = salto más alto)
        stickJump = joyMode && stick.active() && stick.ay < (stickJump ? -0.4f : -0.6f);
        bJump.setExt(GameKit.SRC_STICK, stickJump);
        if (bJump.pressed() && !healing) {
            if (coyote > 0) { pl.vy = -jumpV() * gs * wf; coyote = 0; chip.sfx(Chip.SFX_JUMP); }
            else if (wallDir != 0) {
                pl.vy = -jumpV() * 0.95f * gs;
                pl.vx = -wallDir * 8;
                knockT = 0.16f;
                facingR = wallDir < 0;
                chip.sfx(Chip.SFX_JUMP);
            } else if (airJumps < maxAirJumps()) { pl.vy = -DJUMP * gs * wf; airJumps++; chip.sfx(Chip.SFX_JUMP); }
        }
        if (!dashing) {
            float g = GRAV * (water ? 0.45f : 1f);
            pl.vy += g * gs * dt;
            if (!bJump.down && pl.vy * gs < -5) pl.vy += g * gs * dt * 1.4f;
            if (M[EcoData.M_GLIDE] > 0 && bJump.down && pl.vy * gs > 2.2f && !pl.onGround) pl.vy = 2.2f * gs;
            float mf = water ? 7 : MAXFALL;
            if (pl.vy * gs > mf) pl.vy = mf * gs;
        }

        float prevBottom = pl.y + pl.h;
        moveBody(pl, dt, true);
        // plataformas móviles
        for (Mov m : movs) {
            m.x += m.vx * dt;
            if (m.x < m.minX) { m.x = m.minX; m.vx = Math.abs(m.vx); }
            if (m.x > m.maxX) { m.x = m.maxX; m.vx = -Math.abs(m.vx); }
            boolean ox0 = pl.x + pl.w > m.x && pl.x < m.x + m.w;
            if (ox0 && pl.vy >= 0 && prevBottom <= m.y + 0.05f && pl.y + pl.h >= m.y) {
                pl.y = m.y - pl.h; pl.vy = 0; pl.onGround = true;
                pl.x += m.vx * dt;
            }
        }
        // pinchos
        if (tileAt(pl.x + pl.w / 2, pl.y + pl.h - 0.1f) == '^') { hurt(10 + roomDist() * 0.8f, pl.x - (facingR ? 1 : -1)); pl.vy = -13; }

        // ---- cambio de sala ----
        float cx = pl.x + pl.w / 2, cy = pl.y + pl.h / 2;
        if (cx < 0) { go(-1, 0); return; }
        if (cx > EcoWorld.W) { go(1, 0); return; }
        if (cy < 0) { go(0, -1); return; }
        if (cy > EcoWorld.H) { go(0, 1); return; }

        // ---- rejas y puertas cerradas ----
        checkDoors();
        if (mode != M_PLAY) return;

        // ---- empezar pelea de jefe ----
        if (room.boss && !fightActive && bossAlive() && pl.x > 2.5f && pl.x < EcoWorld.W - 3.5f && pl.y > 1.2f && pl.y < EcoWorld.H - 1.5f) {
            startFight();
            if (mode != M_PLAY) return;
        }

        updateColiseo(dt);
        updateLambs(dt);

        // ---- hablar / usar ----
        nearNpc = null;
        for (Npc n : npcs) if (Math.abs(n.x + 0.5f - cx) < 1.4f && Math.abs(n.y + 0.5f - cy) < 1.5f) nearNpc = n;
        bUse.label = nearNpc == null ? "▲" : (nearNpc.ch == 'S' ? "DESCANSAR" : nearNpc.ch == 'Y' ? "TOMAR" : nearNpc.ch == 'U' ? "ABRIR" : "HABLAR");
        bUse.textSize = nearNpc == null ? 18 : 11;
        if (joyMode && !gp.enabled) bUse.visible = nearNpc != null;
        // Sabelotodo habla solo la primera vez que entras en su zona
        if (nearNpc == null) for (Npc n : npcs)
            if (n.ch == 'O' && !flag("sabio_" + room.zone) && Math.abs(n.x - cx) < 5) { interact(n); return; }
        if (bUse.pressed() && nearNpc != null) { interact(nearNpc); return; }

        // ---- atacar ----
        shootCd -= dt; flameCd -= dt; clawT -= dt;
        if (muteT > 0) {
            if (bShoot.pressed()) float_("🔇", pl.x + pl.w / 2, pl.y - 0.4f, Color.rgb(200, 200, 255));
        } else if (claws()) {
            if (bShoot.pressed() && clawT <= 0 && !healing) clawSwipe();
        } else if (weapon == 0) {
            if (bShoot.pressed() && shootCd <= 0 && !healing) fireWaves();
            if (has(EcoData.AB_CHARGE)) {
                if (bShoot.down && !healing) {
                    chargeT += dt;
                    if (chargeT > 0.9f && ((int) (chargeT * 10)) % 3 == 0) float_("✦", pl.x + pl.w / 2 + (rnd.nextFloat() - 0.5f), pl.y, Color.rgb(255, 240, 160));
                } else {
                    if (prevShootDown && chargeT >= 0.9f) fireCharged();
                    chargeT = 0;
                }
            }
        } else if (bShoot.down && flameCd <= 0 && !healing) {
            flameCd = 0.07f;
            Shot s = new Shot();
            s.mine = true; s.kind = SH_FLAME;
            s.w = 0.4f; s.h = 0.4f;
            s.x = facingR ? pl.x + pl.w : pl.x - s.w;
            s.y = pl.y + pl.h / 2 - 0.2f;
            s.vx = (facingR ? 9 : -9) + pl.vx * 0.5f;
            s.vy = (rnd.nextFloat() - 0.5f) * 4;
            s.life = 0.3f;
            s.dmg = flameDmg();
            shots.add(s);
            if (rnd.nextFloat() < 0.3f) chip.sfx(Chip.SFX_HIT);
        }
        prevShootDown = bShoot.down;
        trailX[trailI] = pl.x; trailY[trailI] = pl.y; trailFace[trailI] = facingR; trailShot[trailI] = firedNow;
        trailI = (trailI + 1) % trailX.length; trailN++;

        // ---- Corazón de Eco: los golpes vuelven a sonar ----
        for (Iterator<Echo> it = echoes.iterator(); it.hasNext(); ) {
            Echo ec = it.next();
            ec.t -= dt;
            if (ec.t > 0) continue;
            it.remove();
            if (!ec.e.dead && enemies.contains(ec.e)) {
                damage(ec.e, ec.d, false);
                float_("♪", ec.e.b.x + ec.e.b.w / 2, ec.e.b.y - 0.3f, Color.rgb(140, 210, 255));
            }
        }
        // ---- adicción al sonido (Set de la Sinfonía completo) ----
        silentT += dt;
        if (symSetOn() && silentT > 5 && !room.safe && !bossMode) {
            drainT += dt;
            if (drainT >= 0.6f) {
                drainT = 0;
                if (hp > 1) { hp = Math.max(1, hp - 2); float_("-2 ♫", pl.x + 0.4f, pl.y - 0.3f, Color.rgb(140, 160, 255)); }
                if (silentT < 5.7f) say("♫ El silencio te duele... ¡haz sonar el cencerro!");
            }
        } else drainT = 0;

        // ---- enemigos ----
        if (invul > 0) invul -= dt;
        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);
            if (e.dead) continue;
            float edt = e.slow > 0 ? dt * 0.5f : dt;
            if (e.slow > 0) e.slow -= dt;
            if (e.thornT > 0) e.thornT -= dt;
            updateEnemy(e, edt);
            if (e.flash > 0) e.flash -= dt;
            if (e.slashT > 0) e.slashT -= dt;
            if (!e.decoy && !(e.kind != null && e.kind.id.equals("AS") && e.state == 9)
                    && !e.hidden && e.vis > 0.5f && GameKit.overlap(pl.x + 0.1f, pl.y + 0.1f, pl.w - 0.2f, pl.h - 0.1f, e.b.x + 0.1f, e.b.y + 0.1f, e.b.w - 0.2f, e.b.h - 0.2f)) {
                if (M[EcoData.M_THORNS] > 0 && e.thornT <= 0) { e.thornT = 0.6f; damage(e, M[EcoData.M_THORNS], false); }
                if (!e.dead) hurt(e.dmg, e.b.x + e.b.w / 2);
            }
        }

        // ---- disparos ----
        for (int i = 0; i < shots.size(); i++) {
            Shot s = shots.get(i);
            if (s.dead) continue;
            s.life -= dt;
            if (s.life <= 0) { s.dead = true; continue; }
            boolean still = s.kind == SH_BEAM || s.kind == SH_VINE;
            if (s.homing && s.mine) {           // Oído Infinito: la onda busca al enemigo
                Enemy best = null; float bd = 9;
                for (Enemy e : enemies) {
                    if (e.dead || e.hidden || e.decoy || s.hit.contains(e)) continue;
                    float ddx = e.b.x + e.b.w / 2 - s.x, ddy = e.b.y + e.b.h / 2 - s.y;
                    if (Math.signum(ddx) != Math.signum(s.vx)) continue;
                    float dd = (float) Math.hypot(ddx, ddy);
                    if (dd < bd) { bd = dd; best = e; }
                }
                if (best != null) s.vy += GameKit.clamp(best.b.y + best.b.h / 2 - (s.y + s.h / 2), -1, 1) * 30 * dt;
                s.vy = GameKit.clamp(s.vy, -8, 8);
            }
            if (!still) {
                s.vy += s.grav * dt;
                s.x += s.vx * dt;
                s.y += s.vy * dt;
                if (s.kind == SH_COCOON && s.vy > 0 && boxSolid(s.x, s.y + s.h, s.w, 0.1f)) {   // al caer deja estática
                    statics.add(new float[]{GameKit.clamp(s.x - 0.6f, 1, EcoWorld.W - 3), (float) Math.floor(s.y + s.h) - 0.4f, 1.8f, 5, 0});
                    s.dead = true;
                    continue;
                }
                boolean ghost = s.kind == SH_DUST || s.kind == SH_VOID;
                boolean wall = s.mine ? boxSolid(s.x + s.w / 2 - 0.05f, s.y + s.h / 2 - 0.1f, 0.1f, 0.2f)
                        : s.kind != SH_SHOCK && !ghost && boxSolid(s.x, s.y, s.w, s.h);
                if (ghost) { s.x = GameKit.clamp(s.x, 0.5f, EcoWorld.W - 1.5f); if (s.y > EcoWorld.H - 1.5f) s.vy = -Math.abs(s.vy) * 0.3f; }
                if (s.kind == SH_SHOCK && (s.x < 0.5f || s.x > EcoWorld.W - 1)) wall = true;
                if (wall) {
                    if (s.bounces > 0) { s.bounces--; s.vx = -s.vx; s.x += s.vx * dt * 2; }
                    else { s.dead = true; continue; }
                }
            }
            if (s.mine) {
                if (EcoBoss2.shotHook(this, s)) { s.dead = true; continue; }
                for (int j = 0; j < enemies.size(); j++) {
                    Enemy e = enemies.get(j);
                    if (e.dead || e.hidden || e.decoy || s.hit.contains(e)) continue;
                    if (GameKit.overlap(s.x, s.y, s.w, s.h, e.b.x, e.b.y, e.b.w, e.b.h)) {
                        if (s.frost) e.slow = 2f;
                        damage(e, s.dmg, false);
                        if (s.echo && !e.dead) { Echo ec = new Echo(); ec.e = e; ec.d = s.dmg * 0.5f; ec.t = 0.5f; echoes.add(ec); }
                        s.hit.add(e);
                        if (!s.pierce) { s.dead = true; break; }
                    }
                }
                if (has(EcoData.AB_MIRROR) && s.kind == SH_WAVE && !s.dead) {
                    for (Shot o : shots) if (!o.mine && !o.dead && o.kind != SH_BEAM && o.kind != SH_VINE && o.kind != SH_SHOCK
                            && GameKit.overlap(s.x, s.y, s.w, s.h, o.x, o.y, o.w, o.h)) { o.dead = true; float_("✧", o.x, o.y, Color.WHITE); }
                }
            } else if (GameKit.overlap(pl.x + 0.1f, pl.y + 0.1f, pl.w - 0.2f, pl.h - 0.2f, s.x, s.y, s.w, s.h)) {
                if (s.kind == SH_DUST && invul <= 0) invertT = 1.5f;
                if (s.kind == SH_VOID || s.kind == SH_THREAD) muteT = 2f;
                if (s.kind == SH_THREAD) pullT = 1f;
                hurt(s.dmg, s.x + s.w / 2);
                if (!still && s.kind != SH_SHOCK) s.dead = true;
            }
        }
        for (Iterator<Shot> it = shots.iterator(); it.hasNext(); ) if (it.next().dead) it.remove();

        // ---- objetos ----
        for (int i = 0; i < picks.size(); i++) {
            Pick k = picks.get(i);
            if (k.dead) continue;
            if (!k.settled) {
                k.vy += GRAV * 0.6f * dt;
                k.y += k.vy * dt;
                int ty = (int) Math.floor(k.y + 0.5f);
                if (k.vy > 0 && (solid((int) Math.floor(k.x + 0.25f), ty) || oneWay((int) Math.floor(k.x + 0.25f), ty))) {
                    k.y = ty - 0.5f; k.vy = 0;
                    if (k.type != '$') k.settled = true;
                }
                if (k.y > EcoWorld.H) k.dead = true;
            }
            if (k.type == '$' && M[EcoData.M_MAGNET] > 0) {
                float dx = pl.x + pl.w / 2 - k.x, dy = pl.y + pl.h / 2 - k.y;
                float d = (float) Math.hypot(dx, dy);
                if (d < 5 && d > 0.1f) { k.x += dx / d * 9 * dt; k.y += dy / d * 9 * dt; }
            }
            float kw = k.type == '$' ? 0.5f : 0.8f;
            if (GameKit.overlap(pl.x, pl.y, pl.w, pl.h, k.x, k.y, kw, kw)) { collect(k); if (mode != M_PLAY) break; }
        }
        for (Iterator<Pick> it = picks.iterator(); it.hasNext(); ) if (it.next().dead) it.remove();
        for (Iterator<Enemy> it = enemies.iterator(); it.hasNext(); ) if (it.next().dead) it.remove();
    }

    boolean inSilence() {
        for (float[] z : silence) if (Math.hypot(pl.x + pl.w / 2 - z[0], pl.y + pl.h / 2 - z[1]) < z[2]) return true;
        return false;
    }

    void rang() {
        firedNow = true;
        silentT = 0;
        EcoBoss2.onBell(this);
    }

    void fireWaves() {
        shootCd = shotCooldown();
        if (inSilence()) { float_("🔇", pl.x + pl.w / 2, pl.y - 0.4f, Color.LTGRAY); return; }
        boolean fan3 = M[EcoData.M_FAN3] > 0;
        int n = fan3 ? 3 : 1 + (int) M[EcoData.M_SHOTS];
        for (int i = 0; i < n; i++) {
            Shot s = new Shot();
            s.mine = true; s.kind = SH_WAVE;
            s.w = 0.5f; s.h = branch == 1 ? 1.1f : 0.55f;
            s.x = facingR ? pl.x + pl.w : pl.x - s.w;
            float off = fan3 ? 0 : (n >= 2 ? (i - (n - 1) / 2f) * 0.5f : 0);
            s.y = pl.y + pl.h / 2 - s.h / 2 + off;
            s.vx = facingR ? 16 : -16;
            if (fan3) s.vy = (i - 1) * 4.5f;
            s.life = (branch == 2 ? 0.9f : (branch == 3 ? 0.55f : 0.45f)) * (1 + M[EcoData.M_RANGE] / 100f);
            s.bounces = bounces();
            s.pierce = pierce();
            s.frost = M[EcoData.M_FROST] > 0;
            s.dmg = waveDmg();
            s.homing = M[EcoData.M_HOMING] > 0;
            s.echo = M[EcoData.M_ECHO] > 0;
            if (water) { s.vx *= 0.6f; s.h *= 1.5f; s.w *= 1.3f; s.life *= 1.6f; }
            shots.add(s);
        }
        chip.sfx(Chip.SFX_SHOOT);
        // Set de la Sinfonía: cada 5.º toque suena como una catedral
        if (symSetOn() && ++symShots % 5 == 0) {
            Shot g = new Shot();
            g.mine = true; g.kind = SH_WAVE; g.big = true;
            g.w = 1.4f; g.h = 2.8f;
            g.x = facingR ? pl.x + pl.w : pl.x - g.w;
            g.y = pl.y + pl.h / 2 - g.h / 2;
            g.vx = facingR ? 15 : -15;
            g.life = 0.9f * (1 + M[EcoData.M_RANGE] / 100f);
            g.pierce = true;
            g.echo = true;
            g.dmg = waveDmg() * 2.5f;
            shots.add(g);
            chip.sfx(Chip.SFX_BOOM);
            shake = 0.2f;
            float_("♫", pl.x + pl.w / 2, pl.y - 0.6f, Color.rgb(120, 200, 255));
        }
        rang();
    }

    void fireCharged() {
        Shot s = new Shot();
        s.mine = true; s.kind = SH_WAVE; s.big = true;
        s.w = 0.9f; s.h = 1.7f;
        s.x = facingR ? pl.x + pl.w : pl.x - s.w;
        s.y = pl.y + pl.h / 2 - s.h / 2;
        s.vx = facingR ? 18 : -18;
        s.life = 0.8f;
        s.pierce = true;
        s.frost = M[EcoData.M_FROST] > 0;
        s.dmg = waveDmg() * 3;
        shots.add(s);
        chip.sfx(Chip.SFX_BOOM);
        shake = 0.15f;
        rang();
    }

    void clawSwipe() {
        clawT = 0.32f;
        chip.sfx(Chip.SFX_SWORD);
        rang();
        float hx = facingR ? pl.x + pl.w - 0.1f : pl.x - 1.6f, hy = pl.y - 0.35f;
        Fx f = new Fx();
        f.s = "CLAW"; f.x = hx; f.y = hy; f.life = 0.16f; f.color = facingR ? 1 : -1;
        fx.add(f);
        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);
            if (e.dead || e.hidden) continue;
            if (GameKit.overlap(hx, hy, 1.7f, 1.5f, e.b.x, e.b.y, e.b.w, e.b.h)) damage(e, clawDmg(), true);
        }
    }

    /** Rejas que necesitan ecos y puertas con llave. */
    void checkDoors() {
        int x0 = (int) Math.floor(pl.x) - 1, x1 = (int) Math.floor(pl.x + pl.w) + 1;
        int y0 = (int) Math.floor(pl.y) - 1, y1 = (int) Math.floor(pl.y + pl.h) + 1;
        for (int ty = Math.max(0, y0); ty <= Math.min(EcoWorld.H - 1, y1); ty++)
            for (int tx = Math.max(0, x0); tx <= Math.min(EcoWorld.W - 1, x1); tx++) {
                char c = room.t[ty][tx];
                String gf = c == 'G' ? room.gateAt(tx, ty) : "";
                if (c == 'G' && !gateOpen(gf) && gateMsgT <= 0) {
                    gateMsgT = 3;
                    if (gf.equals("vamp4")) dialog("", null, EcoData.CASTILLO_CERRADO, null);
                    else if (gf.startsWith("e:"))
                        say("🔒 Esta reja se abre con " + gf.substring(2) + " ecos (tienes " + ecos + ")");
                    else say("🔒 La reja está cerrada");
                    return;
                }
                if ((c == 'K' || c == 'X') && !doorOpen(tx, ty)) {
                    boolean crimson = c == 'X';
                    if (crimson ? ckeys > 0 : keys > 0) {
                        if (crimson) ckeys--; else keys--;
                        flags.add("door_" + room.key() + "_" + doorDir(tx, ty));
                        chip.sfx(Chip.SFX_DOOR);
                        say(crimson ? "🗝 La llave carmesí gira... la puerta se abre" : "🗝 Usas una llave de mazmorra");
                        saveGame(false);
                    } else if (gateMsgT <= 0) {
                        gateMsgT = 4;
                        dialog("", crimson ? sCKey : sKey, crimson ? EcoData.PUERTA_CARMESI : EcoData.PUERTA_LLAVE, null);
                    }
                    return;
                }
            }
    }

    void startFight() {
        Enemy e = mainBoss();
        fightActive = true;
        chip.sfx(Chip.SFX_DOOR);
        if (e == null) return;
        if (e.bdef != null && e.bdef.id.equals("V5")) e.role = claws() ? 1 : 0;
        chip.play(bossSong());
        say(bossName(e));
        if (!introShown && e.bdef != null) {
            introShown = true;
            String[] lines = null;
            switch (e.bdef.id) {
                case "V1": lines = EcoData.HAROLD_IN; break;
                case "V2": lines = EcoData.ALOII_IN; break;
                case "V4": lines = EcoData.SANGRE_IN; break;
                case "V5": lines = claws() ? EcoData.CONDE_IN_GARRAS : EcoData.CONDE_IN; break;
            }
            if (lines != null) dialog(e.bdef.name, bossFace(e), lines, null);
        }
    }

    Bitmap bossFace(Enemy e) {
        if (e.bdef == null || e.bdef.tpl < 0) return null;
        return EcoArt.boss(e.bdef, false)[0];
    }

    String bossName(Enemy e) {
        if (e.bdef != null) return "💀 " + e.bdef.name.toUpperCase();
        char t = e.type;
        return t == '1' ? "👑 REY TOPO LOCO" : t == '2' ? "👻 VAGONETA FANTASMA" : "🦇 MURCIÉGALO GEMELO";
    }

    void bossFled(Enemy e) { kill(e, false); }

    // =====================================================================
    // Enemigos
    // =====================================================================
    void updateEnemy(Enemy e, float dt) {
        e.t += dt;
        if (e.phaseLock > 0) e.phaseLock -= dt;
        switch (e.type) {
            case '1': reyTopo(e, dt, (pl.x + pl.w / 2) - (e.b.x + e.b.w / 2)); break;
            case '2': vagoneta(e, dt); break;
            case '3': gemelo(e, dt, (pl.x + pl.w / 2) - (e.b.x + e.b.w / 2), (pl.y + pl.h / 2) - (e.b.y + e.b.h / 2)); break;
            case 'B': EcoBoss.update(this, e, dt); break;
            case 'D': break;            // clon de Bruma: lo mueve la loba de verdad
            default: creature(e, dt);
        }
    }

    void creature(Enemy e, float dt) {
        Body b = e.b;
        EcoData.Kind k = e.kind;
        if (k.id.equals("AS")) { EcoBoss2.ant(this, e, dt); return; }
        float px0 = pl.x + pl.w / 2, py0 = pl.y + pl.h / 2;
        float ex = b.x + b.w / 2, ey = b.y + b.h / 2;
        float dx = px0 - ex, dy = py0 - ey;
        switch (k.arch) {
            case EcoData.A_WALK: walker(e, k.speed, dt); break;
            case EcoData.A_SHOOT: {
                e.cd -= dt;
                if (e.cd <= 0 && Math.abs(dx) < 9 && Math.abs(dy) < 5) {
                    e.cd = 2.5f;
                    e.dir = Math.signum(dx);
                    int sk = k.zone == EcoData.Z_LAGO ? SH_SNOW : k.zone == EcoData.Z_NIDO ? SH_WEB : k.zone == EcoData.Z_CEMENTERIO ? SH_RING : SH_PEBBLE;
                    enemyShot(sk, ex, b.y, GameKit.clamp(dx / 1.0f, -8, 8), -10, 25, 0.38f, e.dmg, k.c2);
                } else if (e.cd > 0.6f) walker(e, k.speed, dt);
                else { b.vx = 0; b.vy += GRAV * dt; moveBody(b, dt, true); }
                break;
            }
            case EcoData.A_CHARGE: {
                if (e.state == 0) {
                    walker(e, k.speed, dt);
                    if (Math.abs(dy) < 1.2f && Math.abs(dx) < 8 && Math.signum(dx) == e.dir) { e.state = 1; e.cd = 1.2f; }
                } else if (e.state == 1) {
                    b.vx = e.dir * 7 * (k.zone >= EcoData.Z_CIUDAD ? 1.15f : 1f);
                    b.vy += GRAV * dt;
                    moveBody(b, dt, true);
                    e.cd -= dt;
                    if (e.cd <= 0 || b.hitWall || edgeAhead(e)) { e.state = 2; e.cd = 0.8f; b.vx = 0; }
                } else {
                    e.cd -= dt;
                    b.vy += GRAV * dt;
                    b.vx = 0;
                    moveBody(b, dt, true);
                    if (e.cd <= 0) e.state = 0;
                }
                break;
            }
            case EcoData.A_FLY: {
                float sp = k.speed;
                if (Math.hypot(dx, dy) < 7) {
                    float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                    b.x += dx / d * sp * dt;
                    b.y += (dy / d * sp + (float) Math.sin(e.t * 5) * 2) * dt;
                } else {
                    b.x = e.homeX + (float) Math.sin(e.t * 1.2f) * 2.5f;
                    b.y = e.homeY + (float) Math.sin(e.t * 2.1f) * 0.8f;
                }
                clampIn(b);
                break;
            }
            case EcoData.A_FLOAT: {
                float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                if (d < 10) {
                    b.x += (dx / d * k.speed + (float) Math.cos(e.t * 3) * 1.2f) * dt;
                    b.y += (dy / d * k.speed + (float) Math.sin(e.t * 3.7f) * 1.2f) * dt;
                } else b.y = e.homeY + (float) Math.sin(e.t * 2) * 0.6f;
                clampIn(b);
                break;
            }
            case EcoData.A_JUMP: {
                b.vy += GRAV * dt;
                if (b.onGround) {
                    b.vx = 0;
                    e.cd -= dt;
                    if (e.cd <= 0 && Math.abs(dx) < 10) {
                        e.cd = 1.3f + rnd.nextFloat() * 0.6f;
                        b.vy = -15;
                        b.vx = GameKit.clamp(dx * 0.9f, -k.speed, k.speed);
                        e.dir = Math.signum(dx);
                    }
                }
                moveBody(b, dt, true);
                break;
            }
            case EcoData.A_TURRET: {
                b.vy += GRAV * dt;
                moveBody(b, dt, true);
                e.dir = Math.signum(dx) == 0 ? e.dir : Math.signum(dx);
                e.cd -= dt;
                e.hidden = false;
                if (e.cd < 0.4f && e.cd > 0) e.flash = ((int) (e.cd * 20)) % 2 == 0 ? 0.03f : 0;
                if (e.cd <= 0 && Math.abs(dx) < 12 && Math.abs(dy) < 6) {
                    e.cd = k.id.equals("J1") ? (++e.cycle % 3 == 0 ? 2.6f : 0.5f) : 2.2f;
                    float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                    float sp = k.id.equals("K2") ? 14 : 8;
                    enemyShot(SH_ORB, ex, ey - 0.1f, dx / d * sp, dy / d * sp, 0, 0.35f, e.dmg, k.c1);
                }
                break;
            }
            case EcoData.A_DIVE: {
                if (e.state == 0) {          // vigila en el aire
                    b.x = e.homeX + (float) Math.sin(e.t * 1.4f) * 2;
                    b.y = e.homeY + (float) Math.sin(e.t * 3f) * 0.4f;
                    e.cd -= dt;
                    if (e.cd <= 0 && Math.abs(dx) < 7 && dy > -1) { e.state = 1; e.t2 = 0; }
                } else if (e.state == 1) {   // zumba (aviso)
                    e.t2 += dt;
                    b.x += (float) Math.sin(e.t * 40) * 0.03f;
                    if (e.t2 > 0.45f) {
                        float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                        e.aux = dx / d; e.aux2 = dy / d;
                        e.state = 2; e.t2 = 0;
                    }
                } else if (e.state == 2) {   // picado
                    e.t2 += dt;
                    b.vx = e.aux * k.speed * 1.6f; b.vy = e.aux2 * k.speed * 1.6f;
                    moveBody(b, dt, false);
                    if (b.onGround || b.hitWall || e.t2 > 1.1f) { e.state = 3; e.t2 = 0; }
                } else if (e.state == 3) {   // aturdido en el suelo
                    e.t2 += dt;
                    if (e.t2 > 0.8f) e.state = 4;
                } else {                     // vuelve a su sitio
                    b.x += (e.homeX - b.x) * Math.min(1, dt * 2.5f);
                    b.y += (e.homeY - b.y) * Math.min(1, dt * 2.5f);
                    if (Math.abs(b.y - e.homeY) < 0.2f) { e.state = 0; e.cd = 1.2f; }
                }
                clampIn(b);
                break;
            }
            case EcoData.A_SPIDER: {
                if (e.state == 0) {          // colgada del techo
                    b.y = e.homeY + (float) Math.sin(e.t * 2) * 0.15f;
                    if (Math.abs(dx) < 1.6f && dy > 0) { e.state = 1; chip.sfx(Chip.SFX_DUCK); }
                } else if (e.state == 1) {   // cae
                    b.vy = Math.min(b.vy + 40 * dt, 16);
                    b.vx = 0;
                    moveBody(b, dt, true);
                    if (b.onGround) e.state = 2;
                } else walker(e, k.speed * 0.5f, dt);
                break;
            }
            case EcoData.A_GHOST: {
                float cycle = e.t % 4f;
                e.hidden = cycle > 2.6f;
                e.vis = e.hidden ? 0.15f : 1;
                float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                if (d < 12) { b.x += dx / d * k.speed * dt; b.y += (dy / d * k.speed + (float) Math.sin(e.t * 2) * 0.6f) * dt; }
                clampIn(b);
                break;
            }
        }
    }

    void clampIn(Body b) {
        b.x = GameKit.clamp(b.x, 1, EcoWorld.W - 1 - b.w);
        b.y = GameKit.clamp(b.y, 1, EcoWorld.H - 1 - b.h);
    }

    boolean edgeAhead(Enemy e) {
        Body b = e.b;
        float fx0 = e.dir > 0 ? b.x + b.w + 0.05f : b.x - 0.05f;
        int tx = (int) Math.floor(fx0), ty = (int) Math.floor(b.y + b.h + 0.1f);
        return !solid(tx, ty) && !oneWay(tx, ty);
    }

    void walker(Enemy e, float speed, float dt) {
        Body b = e.b;
        b.vx = e.dir * speed;
        b.vy += GRAV * dt;
        moveBody(b, dt, true);
        if (b.onGround && (b.hitWall || edgeAhead(e))) e.dir = -e.dir;
        if (b.x < 0.5f) e.dir = 1;
        if (b.x > EcoWorld.W - 1.5f) e.dir = -1;
    }

    Shot enemyShot(int kind, float x, float y, float vx, float vy, float grav, float size) {
        return enemyShot(kind, x, y, vx, vy, grav, size, 12, Color.WHITE);
    }

    Shot enemyShot(int kind, float x, float y, float vx, float vy, float grav, float size, float dmg, int color) {
        Shot s = new Shot();
        s.kind = kind; s.x = x - size / 2; s.y = y; s.vx = vx; s.vy = vy; s.grav = grav;
        s.w = size; s.h = size; s.life = kind == SH_SHOCK ? 2.5f : 4; s.dmg = dmg; s.color = color;
        shots.add(s);
        return s;
    }

    // ---- REY TOPO LOCO ----
    void reyTopo(Enemy e, float dt, float dx) {
        Body b = e.b;
        if (!fightActive) { b.vy += GRAV * dt; moveBody(b, dt, false); return; }
        e.phase2 = e.hp < e.maxHp / 2;
        float k = e.phase2 ? 1.4f : 1f;
        e.cd -= dt;
        switch (e.state) {
            case 0: // caminar
                b.vx = Math.signum(dx) * 2.5f * k;
                b.vy += GRAV * dt;
                moveBody(b, dt, false);
                if (e.cd <= 0) {
                    e.cycle++;
                    if (e.cycle % 2 == 1) { e.state = 1; e.hidden = true; e.cd = 1.6f; chip.sfx(Chip.SFX_DUCK); }
                    else { e.state = 3; e.cd = 0.5f; b.vx = 0; }
                }
                break;
            case 1: // bajo tierra: el montículo te sigue
                b.vx = Math.signum(dx) * 5 * k;
                moveBody(b, dt, false);
                if (e.cd <= 0) {
                    e.state = 2; e.hidden = false; b.vy = -16;
                    chip.sfx(Chip.SFX_BOOM);
                    for (int i = 0; i < 4; i++) float_("·", b.x + rnd.nextFloat() * b.w, b.y + b.h, Color.rgb(160, 110, 60));
                }
                break;
            case 2: // salta desde la tierra
                b.vx = 0;
                b.vy += GRAV * dt;
                moveBody(b, dt, false);
                if (b.onGround) { e.state = 0; e.cd = 2.2f / k; }
                break;
            case 3: // lanza rocas
                b.vy += GRAV * dt;
                moveBody(b, dt, false);
                if (e.cd <= 0) {
                    int n = e.phase2 ? 5 : 3;
                    for (int i = 0; i < n; i++)
                        enemyShot(SH_ROCK, b.x + b.w / 2, b.y, (dx / 1.3f) + (i - (n - 1) / 2f) * 2.2f, -13, 26, 0.5f);
                    chip.sfx(Chip.SFX_SHOOT);
                    e.state = 0; e.cd = 2.2f / k;
                }
                break;
        }
    }

    // ---- VAGONETA FANTASMA ----
    void vagoneta(Enemy e, float dt) {
        Body b = e.b;
        b.vy += GRAV * dt;
        if (!fightActive) { moveBody(b, dt, false); return; }
        e.phase2 = e.hp < e.maxHp / 2;
        if (e.state == 0) {          // pausa: aquí es más fácil golpearla
            b.vx = 0;
            e.cd -= dt;
            if (e.cd <= 0) {
                e.state = 1;
                e.dir = b.x + b.w / 2 < EcoWorld.W / 2f ? 1 : -1;
                e.cd2 = 0.5f;
                chip.sfx(Chip.SFX_DOOR);
            }
        } else {
            b.vx = e.dir * (e.phase2 ? 14 : 11);
            e.cd2 -= dt;
            if (e.cd2 <= 0) {
                e.cd2 = e.phase2 ? 0.35f : 0.5f;
                enemyShot(SH_GHOSTFIRE, b.x + b.w / 2, b.y, (rnd.nextFloat() - 0.5f) * 6, -12, 25, 0.45f);
            }
        }
        moveBody(b, dt, false);
        if (e.state == 1 && b.hitWall) {
            e.cycle++;
            if (e.phase2 && e.cycle % 2 == 1) { e.dir = -e.dir; }
            else { e.state = 0; e.cd = 1.4f; }
            chip.sfx(Chip.SFX_BOOM);
        }
    }

    // ---- MURCIÉGALO GEMELO ----
    void gemelo(Enemy e, float dt, float dx, float dy) {
        Body b = e.b;
        if (!fightActive) { b.y = e.homeY - 4 + (float) Math.sin(e.t * 2) * 0.3f; return; }
        e.enraged = e.partner == null || e.partner.dead;
        float k = e.enraged ? 1.5f : 1f;
        if (!e.enraged && ((int) (e.t / 6)) % 2 == 1) e.state = 1 - e.role; else if (!e.enraged) e.state = e.role;
        if (e.enraged) e.state = (((int) (e.t / 4)) % 2);
        e.cd -= dt;
        if (e.state == 0) {          // embiste
            if (e.cd2 > 0) {
                e.cd2 -= dt;
                b.x += b.vx * dt; b.y += b.vy * dt;
            } else {
                float tx = 6 + (float) Math.sin(e.t * 0.8f) * 4 + (e.role == 0 ? 0 : 16), ty = 4;
                b.x += (tx - b.x) * Math.min(1, dt * 2);
                b.y += (ty - b.y) * Math.min(1, dt * 2);
                if (e.cd <= 0) {
                    e.cd = 2.5f / k;
                    e.cd2 = 0.9f;
                    float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                    b.vx = dx / d * 9 * k; b.vy = dy / d * 9 * k;
                }
            }
        } else {                     // chilla: lanza anillos
            float tx = 15 + (float) Math.sin(e.t * 0.9f) * 9, ty = 2.5f + (float) Math.sin(e.t * 2) * 0.5f;
            b.x += (tx - b.x) * Math.min(1, dt * 2);
            b.y += (ty - b.y) * Math.min(1, dt * 2);
            if (e.cd <= 0) {
                e.cd = 1.6f / k;
                float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                enemyShot(SH_RING, b.x + b.w / 2, b.y + b.h / 2, dx / d * 6 * k, dy / d * 6 * k, 0, 0.55f);
                chip.sfx(Chip.SFX_TALK);
            }
        }
        clampIn(b);
    }

    // =====================================================================
    // Daño, muerte y recompensas
    // =====================================================================
    void damage(Enemy e, float d, boolean byClaws) {
        if (e.boss && !fightActive) return;
        if (e.decoy || e.invuln || e.dead || (e.vis < 0.5f && !(e.bdef != null && e.bdef.id.equals("B20")))) return;
        if (e.kind != null && e.kind.id.equals("AS") && EcoBoss2.antHit(this, e)) return;
        if (M[EcoData.M_CRIT] > 0 && rnd.nextFloat() * 100 < M[EcoData.M_CRIT]) { d *= 2; float_("¡CRÍTICO!", e.b.x + e.b.w / 2, e.b.y - 0.8f, Color.rgb(255, 230, 80)); }
        if (e.boss) d *= 1 + M[EcoData.M_BOSS] / 100f;
        if (e.type == 'B') d = EcoBoss2.handles(e.bdef.id) ? EcoBoss2.onHit(this, e, d) : d * EcoBoss.damageMult(e);
        if (e.type == 'B') d = finalBossDamage(e, d);
        if (d <= 0) return;
        // Aloii: al 33 % se le rompe el traje y huye
        if (e.bdef != null && e.bdef.id.equals("V2") && e.role != 2 && e.hp - d <= e.maxHp * 0.33f) {
            e.hp = e.maxHp * 0.33f;
            e.role = 2; e.t2 = 0; e.sub = 0; e.invuln = true;
            e.say = EcoData.ALOII_FLEE[0]; e.sayT = 3f;
            e.flash = 0.2f;
            chip.sfx(Chip.SFX_HURT);
            return;
        }
        e.hp -= d;
        e.flash = 0.1f;
        lana = Math.min(9, lana + 1 + (int) M[EcoData.M_LANA]);
        if (M[EcoData.M_STEAL] > 0 && hp > 0) hp = Math.min(maxHp(), hp + d * M[EcoData.M_STEAL] / 100f);
        chip.sfx(Chip.SFX_HIT);
        float_(String.valueOf(Math.round(d)), e.b.x + e.b.w / 2, e.b.y - 0.2f, Color.WHITE);
        if (!e.boss) e.b.x += (pl.x < e.b.x ? 0.25f : -0.25f);
        if (e.hp <= 0) kill(e, byClaws);
    }

    /**
     * Jefes finales (Conde y LUMENIA): las fases no se pueden saltar (el daño de más se pierde y hay
     * una pausa al cambiar de fase) y fuera de sus aberturas solo reciben un 30 % del daño.
     */
    static final float OUTSIDE_OPENING = 0.3f, OPEN_TIME = 0.55f;   // abertura: 0,7 s tras cada ataque, o aturdido

    float finalBossDamage(Enemy e, float d) {
        if (e.bdef == null) return d;
        String id = e.bdef.id;
        if (!id.equals("V5") && !id.equals("B20")) return d;
        if (e.phaseLock > 0) { float_("🛡", e.b.x + e.b.w / 2, e.b.y - 0.4f, Color.LTGRAY); return 0; }
        float half = e.maxHp / 2;
        if (id.equals("V5")) {
            boolean open = e.stun > 0 || (e.state == 0 && e.t2 < OPEN_TIME) || (e.move == EcoBoss.CM_MELEE && e.sub == 2);
            if (!open) d *= OUTSIDE_OPENING * 0.7f;          // el Conde, aún más duro fuera de sus aberturas
            if (e.hp > half && e.hp - d <= half) {          // fase 2: se enfurece
                d = e.hp - (half - 1);
                e.phaseLock = 2.2f;
                e.enraged = true;
                e.say = "¡BASTA DE JUEGOS, OVEJA!"; e.sayT = 2.2f;
                shake = 0.8f;
                chip.play(Songs.CONDE_FURIA);
                chip.sfx(Chip.SFX_BOOM);
            }
        } else {
            if (e.role == 0) {                              // fase 1: la vida no baja de la mitad hasta el cambio
                if (e.hp - d <= half) { d = e.hp - half; e.phaseLock = 2.5f; }
            } else {
                boolean open = e.stun > 0 || (e.state == 0 && e.t2 < OPEN_TIME);
                if (!open) d *= OUTSIDE_OPENING;
            }
        }
        return d;
    }

    void kill(Enemy e, boolean byClaws) {
        if (e.dead) return;
        e.dead = true;
        String id = e.type == 'k' ? e.kind.id : e.type == 'B' ? e.bdef.id : String.valueOf(e.type);
        kills.put(id, (kills.containsKey(id) ? kills.get(id) : 0) + 1);
        int n = kills.get(id);
        if (n == 10 && !e.boss) say("📖 ¡Secreto desbloqueado en el Bestiario!");
        if (byClaws && !e.boss) {        // los zarpazos dejan el esqueleto (y sangre si está activada)
            Decal dc = new Decal();
            dc.x = e.b.x; dc.w = Math.max(0.8f, e.b.w); dc.h = 0.5f;
            dc.y = groundBelow(e.b.x + e.b.w / 2, e.b.y + e.b.h) - dc.h;
            dc.blood = blood();
            Bitmap[] fr = e.kind != null ? EcoArt.kind(e.kind) : null;
            dc.sprite = dc.blood && fr != null ? fr[0] : sSkel;      // con sangre: el cadáver; sin sangre: el esqueleto
            if (dc.sprite == sSkel) dc.blood = dc.blood && fr == null;
            decals.add(dc);
            if (decals.size() > 14) decals.remove(0);
        }
        if (!e.boss) {
            dropBellsAt(e.b.x + e.b.w / 2, e.b.y, e.bellsMin + rnd.nextInt(Math.max(1, e.bellsMax - e.bellsMin + 1)));
            return;
        }
        chip.sfx(Chip.SFX_BOOM);
        if (e.type == '3' && e.partner != null && !e.partner.dead) {
            say("¡El otro murciélago se enfurece!");
            return;
        }
        for (Shot s : shots) if (!s.mine) s.dead = true;
        warns.clear();
        resetGimmicks();
        fightActive = false;
        if (bossMode) { finishBossRun(true); return; }
        if (e.bdef != null && e.bdef.id.startsWith("T") && room == arena) { titanDown(e); return; }
        recordDex(e.type == 'B' && e.bdef != null ? e.bdef.id : String.valueOf(e.type));
        playRoomMusic();
        switch (e.type) {
            case '1':
                flags.add("boss1"); countEcos(); bells += 150;
                dialog("", null, EcoWorld.BOSS1_WIN, () -> saveGame(false));
                break;
            case '2':
                flags.add("boss2"); countEcos(); bells += 250;
                dialog("", null, EcoWorld.BOSS2_WIN, () -> saveGame(false));
                break;
            case '3':
                flags.add("boss3"); bells += 200; lambs++; owned.add("garra");
                dialog("", null, EcoWorld.BOSS3_WIN, () -> saveGame(false));
                break;
            default: bossDefeated(e);
        }
        chip.sfx(Chip.SFX_LEVEL);
    }

    float groundBelow(float x, float y) {
        int tx = (int) Math.floor(x);
        for (int ty = (int) Math.floor(y); ty < EcoWorld.H; ty++) if (solid(tx, ty) || oneWay(tx, ty)) return ty;
        return EcoWorld.H - 1;
    }

    void bossDefeated(Enemy e) {
        EcoData.Boss d = e.bdef;
        flags.add("boss_" + d.id);
        countEcos();
        int prize = Math.round((100 + d.hp / 5) * (1 + M[EcoData.M_BELLS] / 100f));
        bells += prize;
        List<String> lines = new ArrayList<>();
        Runnable after = () -> saveGame(false);
        String rw = d.reward;
        if (rw != null && !rw.isEmpty()) owned.add(rw);
        String rwName = rw == null || rw.isEmpty() ? null : EcoData.emblem(rw).name.toUpperCase();
        switch (d.id) {
            case "V1": java.util.Collections.addAll(lines, EcoData.HAROLD_WIN); break;
            case "V2": java.util.Collections.addAll(lines, EcoData.ALOII_FLEE); lines.remove(0); break;
            case "V3": java.util.Collections.addAll(lines, EcoData.PLANTA_WIN); break;
            case "V4": java.util.Collections.addAll(lines, EcoData.SANGRE_WIN); break;
            case "V5": java.util.Collections.addAll(lines, EcoData.CONDE_WIN); break;
            default:
                if (d.eco > 0) {
                    ore++;
                    lines.add("¡Has derrotado a " + d.name.toUpperCase() + "! +" + prize + " 🔔 · +1 💎");
                    lines.add("Has recuperado un ECO. ✦ (" + ecos + " de 20)");
                    if (rwName != null) lines.add("Te ha dejado un emblema: " + rwName + ". Equípalo descansando en un fardo.");
                    if (d.eco < 20) lines.add("Algunas rejas de Lanaria se abren al reunir más ecos. Mira el mapa 🗺.");
                } else {
                    ore++;
                    lines.add("¡Has vencido al guardián de la mazmorra: " + d.name.toUpperCase() + "! +" + prize + " 🔔 · +1 💎");
                    if (rwName != null) lines.add("Ganas el emblema " + rwName + ". Equípalo descansando en un fardo.");
                    lines.add("Ha aparecido un gran cofre...");
                    for (EcoWorld.Spawn s : room.spawns)
                        if (s.ch == 'c' && s.data.equals("big")) pick('c', s.x + 0.1f, s.y - 2, 400, "it_" + room.key() + "_" + s.idx);
                }
        }
        if (d.id.startsWith("V") && !d.id.equals("V3")) lines.add("Equípalo descansando en un fardo.");
        if (d.id.startsWith("V")) after = () -> { checkVamp4(); saveGame(false); };
        if (d.id.equals("B20")) after = () -> { saveGame(false); finalChoice(); };
        dialog("", bossFace(e), lines.toArray(new String[0]), after);
    }

    void hurt(float d, float fromX) {
        if (invul > 0 || mode != M_PLAY || dashT > 0) return;
        if (M[EcoData.M_EVADE] > 0 && rnd.nextFloat() * 100 < M[EcoData.M_EVADE]) {
            invul = 0.4f;
            float_("¡Esquivado!", pl.x + 0.4f, pl.y - 0.3f, Color.rgb(160, 220, 255));
            return;
        }
        if (M[EcoData.M_SHIELD] > 0 && shieldT <= 0) {
            shieldT = 20;
            invul = 0.8f;
            chip.sfx(Chip.SFX_POWER);
            float_("🛡", pl.x + 0.4f, pl.y - 0.3f, Color.rgb(160, 220, 255));
            return;
        }
        d *= 1 - Math.min(60, M[EcoData.M_REDUCE]) / 100f;
        hp -= d;
        invul = 1.2f + M[EcoData.M_INVUL];
        knockT = 0.25f;
        pl.vx = (pl.x + pl.w / 2 < fromX ? -1 : 1) * 7;
        pl.vy = -9;
        chip.sfx(Chip.SFX_HURT);
        float_("-" + Math.round(d), pl.x + 0.4f, pl.y - 0.3f, Color.rgb(255, 90, 90));
        // el Conde bebe tu sangre: cada golpe que recibes le cura (hay que esquivar)
        if (fightActive) {
            Enemy cb = mainBoss();
            if (cb != null && cb.bdef != null && cb.bdef.id.equals("V5") && !cb.dead && cb.phaseLock <= 0) {
                float heal = cb.enraged ? 40 : 25;
                float cap = cb.enraged ? cb.maxHp / 2 - 1 : cb.maxHp;      // en la fase 2 no vuelve a la fase 1
                cb.hp = Math.min(cap, cb.hp + heal);
                float_("+" + Math.round(heal), cb.b.x + cb.b.w / 2, cb.b.y - 0.8f, Color.rgb(220, 30, 60));
            }
        }
        if (hp <= 0) {
            if (M[EcoData.M_PHOENIX] > 0 && !phoenixUsed) {
                phoenixUsed = true;
                hp = maxHp() / 2;
                invul = 2.5f;
                chip.sfx(Chip.SFX_LEVEL);
                say("🔥 ¡La Pluma de Fénix te levanta!");
                return;
            }
            die();
        }
    }

    void die() {
        resetGimmicks();
        mode = M_DEAD;
        deadT = 0;
        showPad(false);
        chip.silence();
        int lose = M[EcoData.M_KEEP] > 0 ? bells / 2 : bells;
        if (room == arena) { lose = 0; coliseo = false; colBetween = false; }      // en el Coliseo no pierdes cascabeles
        if (lose > 0) {        // tus cascabeles se quedan donde caíste (los anteriores se pierden)
            dropRoom = room.key();
            dropX = GameKit.clamp(pl.x, 1, EcoWorld.W - 2);
            dropY = GameKit.clamp(pl.y, 1, EcoWorld.H - 2);
            dropBells = lose;
            bells -= lose;
        }
        saveGame(false);
    }

    void collect(Pick k) {
        k.dead = true;
        if (k.flag != null) flags.add(k.flag);
        switch (k.type) {
            case '$': bells += k.value; chip.sfx(Chip.SFX_COIN); break;
            case 'c': {
                int v = M[EcoData.M_LUCK] > 0 ? k.value * 2 : k.value;
                bells += v; chip.sfx(Chip.SFX_COIN); say("🎁 Cofre: +" + v + " cascabeles");
                break;
            }
            case 'o': ore++; chip.sfx(Chip.SFX_POWER); say("💎 ¡Mineral de Eco! Llévaselo a la Herrera"); break;
            case 'k': lambs++; chip.sfx(Chip.SFX_LEVEL); dialog("", sLamb, EcoWorld.CORDERITO, null); break;
            case 'A': {
                abilities.add(k.data);
                if (k.data.equals(EcoData.AB_TROMP) && !claws()) weapon = 1;
                chip.sfx(Chip.SFX_LEVEL);
                int i = java.util.Arrays.asList(EcoData.ABILITIES).indexOf(k.data);
                dialog("", k.data.equals(EcoData.AB_TROMP) ? sTromp : sBoots, EcoData.ABILITY_TEXT[Math.max(0, i)], () -> { showPad(true); saveGame(false); });
                break;
            }
            case 'E': {
                owned.add(k.data);
                EcoData.Emblem em = EcoData.emblem(k.data);
                chip.sfx(Chip.SFX_LEVEL);
                dialog("", null, new String[]{"¡Has encontrado un emblema: " + em.name.toUpperCase() + "!", em.desc + ".",
                        "Puedes llevar hasta 12. Equípalo descansando en un fardo 🌾."},
                        () -> { saveGame(false); if (room == arena && colBetween) askContinue(); });
                break;
            }
            case 'D':
                bells += k.value;
                dropRoom = null;
                chip.sfx(Chip.SFX_LEVEL);
                say("🧶 ¡Recuperaste tus " + k.value + " cascabeles!");
                break;
        }
    }

    // =====================================================================
    // Dibujo
    // =====================================================================
    @Override
    void render(Canvas c) {
        int neon = Neon.color(getContext());
        if (mode == M_TITLE) { drawTitle(c, neon); return; }
        if (mode == M_ACHIEVE && (room == null || achFrom == M_TITLE)) { drawAchieve(c, neon); return; }
        if (mode == M_BOSSRUSH) { drawBossRush(c, neon); return; }
        if (mode == M_INTRO) { drawIntro(c, neon); return; }
        if (mode == M_ENDING) { drawEnding(c, neon); return; }
        if (mode == M_VAMPEND && endIdx >= EcoData.FINAL_VAMP.length) { drawVampVillage(c, neon); return; }

        c.save();
        if (shake > 0) c.translate((rnd.nextFloat() - 0.5f) * 4, (rnd.nextFloat() - 0.5f) * 4);
        drawWorld(c);
        c.restore();
        if (mode == M_VAMPEND) { drawVampTurn(c, neon); return; }
        drawHud(c, neon);
        if (mode == M_PLAY) {
            pad.draw(c, neon);
            stick.draw(c, neon);
            if (gp.enabled) drawPadLegend(c);
        }
        if (bannerT > 0 && banner != null) {
            int a = (int) (255 * Math.min(1, bannerT));
            RectF r = new RectF(vw / 2 - 230, 52, vw / 2 + 230, 82);
            p.setColor(Color.argb(a * 3 / 4, 0, 0, 0));
            c.drawRoundRect(r, 10, 10, p);
            text(c, banner, vw / 2, 72, 13, Neon.withAlpha(Color.WHITE, a));
        }
        if (roomNameT > 0 && mode == M_PLAY) {
            int a = (int) (255 * Math.min(1, roomNameT));
            text(c, room.name, vw / 2, 108, 16, Neon.withAlpha(Color.rgb(255, 240, 200), a));
        }

        switch (mode) {
            case M_DIALOG: drawDialog(c, neon); break;
            case M_PAUSE: drawPause(c, neon); break;
            case M_MAP: drawMap(c, neon); break;
            case M_BEAST: drawBeast(c, neon); break;
            case M_CONTROLS: drawControls(c, neon); break;
            case M_ACHIEVE: drawAchieve(c, neon); break;
            case M_AMULET: drawEmblems(c, neon); break;
            case M_SHOP: drawShop(c, neon); break;
            case M_POLICE: drawPolice(c, neon); break;
            case M_FORGE: drawForge(c, neon); break;
            case M_REST: drawRest(c, neon); break;
            case M_CONFIRM: drawConfirm(c, neon); break;
            case M_DEAD: {
                p.setColor(Color.argb((int) Math.min(220, deadT * 160), 0, 0, 0));
                c.drawRect(0, 0, vw, vh, p);
                text(c, "Te has desmayado...", vw / 2, vh / 2 - 10, 22, Color.WHITE);
                if (dropRoom != null) text(c, "Tus cascabeles se quedaron donde caíste 🧶", vw / 2, vh / 2 + 18, 13, Color.rgb(255, 220, 150));
                break;
            }
        }
    }

    EcoData.Zone zone() { return EcoData.ZONES[room.zone]; }

    void drawWorld(Canvas c) {
        EcoData.Zone z = zone();
        p.setColor(z.bot);
        c.drawRect(0, 0, vw, vh, p);

        c.save();
        c.translate(ox, oy);
        c.scale(T, T);
        boolean ol = oled();
        if (bgBmp != null) {
            if (ol) {   // aspecto OLED: el fondo se mueve más despacio (parallax), más oscuro y saturado
                float par = (pl.x + pl.w / 2 - EcoWorld.W / 2f) * -0.08f, parY = (pl.y - EcoWorld.H / 2f) * -0.04f;
                GameKit.draw(c, bgBmp, -0.9f + par, -0.5f + parY, EcoWorld.W + 1.8f, EcoWorld.H + 1f, bgOledPaint);
            } else GameKit.draw(c, bgBmp, 0, 0, EcoWorld.W, EcoWorld.H);
        }
        drawParticles(c, z);
        // manchas y esqueletos (zarpazos)
        for (Decal d : decals) {
            if (d.blood) {
                p.setColor(Color.argb(200, 150, 10, 20));
                c.drawOval(d.x - 0.4f, d.y + d.h - 0.15f, d.x + d.w + 0.4f, d.y + d.h + 0.12f, p);
                if (d.sprite != sSkel) {
                    if (corpsePaint == null) {
                        corpsePaint = new Paint();
                        corpsePaint.setColorFilter(new android.graphics.PorterDuffColorFilter(Color.argb(150, 90, 0, 10), android.graphics.PorterDuff.Mode.SRC_ATOP));
                    }
                    GameKit.draw(c, d.sprite, d.x, d.y + d.h * 0.2f, d.w, d.h * 0.8f, corpsePaint);
                    continue;
                }
            }
            GameKit.draw(c, d.sprite, d.x, d.y, d.w, d.h);
        }
        if (ol) {     // sombra suave de las paredes sobre el fondo (relieve)
            sh3d.setAlpha(110);
            GameKit.draw(c, roomBmp, 0.12f, 0.16f, EcoWorld.W, EcoWorld.H, sh3d);
        }
        GameKit.draw(c, roomBmp, 0, 0, EcoWorld.W, EcoWorld.H, ol ? oledPaint : null);
        // rejas, puertas de jefe y puertas con cerradura
        for (int y = 0; y < EcoWorld.H; y++)
            for (int x = 0; x < EcoWorld.W; x++) {
                char ch = room.t[y][x];
                boolean show = (ch == 'G' && !gateOpen(room.gateAt(x, y))) || (ch == 'B' && fightActive) || ((ch == 'K' || ch == 'X') && !doorOpen(x, y));
                if (!show) continue;
                int base = ch == 'B' ? Color.rgb(150, 30, 50) : ch == 'K' ? Color.rgb(120, 90, 40) : ch == 'X' ? Color.rgb(90, 0, 20) : Color.rgb(90, 90, 110);
                int bar = ch == 'B' ? Color.rgb(255, 80, 100) : ch == 'K' ? Color.rgb(255, 210, 90) : ch == 'X' ? Color.rgb(230, 40, 70) : Color.rgb(170, 170, 200);
                p.setColor(base);
                c.drawRect(x, y, x + 1, y + 1, p);
                p.setColor(bar);
                for (float k = 0.15f; k < 1; k += 0.35f) {
                    if (y == 0 || y == EcoWorld.H - 1) c.drawRect(x + k, y, x + k + 0.12f, y + 1, p);
                    else c.drawRect(x, y + k, x + 1, y + k + 0.12f, p);
                }
                if ((ch == 'K' || ch == 'X') && (y == 13 || x == 14)) GameKit.draw(c, ch == 'X' ? sCKey : sKey, x + 0.1f, y + 0.3f, 0.8f, 0.45f);
            }
        // paredes falsas que brillan (Vista de Búho)
        if (M[EcoData.M_OWL] > 0) {
            p.setColor(Color.argb(60 + (int) (40 * Math.sin(playTime * 3)), 255, 255, 200));
            for (int y = 0; y < EcoWorld.H; y++) for (int x = 0; x < EcoWorld.W; x++) if (room.t[y][x] == 'F') c.drawRect(x, y, x + 1, y + 1, p);
        }
        // avisos de ataque
        for (Warn w : warns) {
            p.setColor(Color.argb(60 + (int) (60 * Math.abs(Math.sin(w.t * 14))), 255, 40, 60));
            c.drawRect(w.x, w.y, w.x + w.w, w.y + w.h, p);
        }
        // plataformas móviles
        for (Mov m : movs) {
            p.setColor(Color.rgb(200, 130, 60));
            c.drawRect(m.x, m.y, m.x + m.w, m.y + 0.4f, p);
            p.setColor(Color.rgb(255, 200, 110));
            c.drawRect(m.x, m.y, m.x + m.w, m.y + 0.12f, p);
        }
        drawLambs(c);
        // PNJ
        for (Npc n : npcs) {
            Bitmap b = npcSprite(n.ch);
            float bob = n.ch == 'Q' ? (float) Math.sin(playTime * 2) * 0.15f : 0;
            if (n.ch == 'U') GameKit.draw(c, sBDoor, n.x - 0.3f, n.y - 1.45f, 1.6f, 2.45f);
            else if (b != null) GameKit.draw(c, b, n.x - 0.1f, n.y - 0.2f + bob, 1.2f, 1.2f);
            if (n == nearNpc) {
                p.setColor(Color.WHITE);
                c.drawRect(n.x + 0.4f, n.y - 0.8f, n.x + 0.6f, n.y - 0.4f, p);
                c.drawRect(n.x + 0.4f, n.y - 0.3f, n.x + 0.6f, n.y - 0.15f, p);
            }
        }
        // objetos
        for (Pick k : picks) {
            float bob = k.settled || k.type == '$' ? (float) Math.sin(playTime * 3 + k.x) * 0.08f : 0;
            Bitmap b;
            switch (k.type) {
                case '$': b = sBell; break;
                case 'c': b = sChest; break;
                case 'o': b = sOre; break;
                case 'k': b = sLamb; break;
                case 'A': b = k.data.equals(EcoData.AB_TROMP) ? sTromp : k.data.equals(EcoData.AB_DJ) ? sBoots : null; break;
                case 'E': b = null; break;
                default: b = sDrop;
            }
            float s = k.type == '$' ? 0.5f : (k.type == 'c' && k.value >= 400 ? 1.3f : 0.8f);
            if (k.type == 'D' || k.type == 'A' || k.type == 'E') {
                int gc = k.type == 'E' ? Color.rgb(255, 120, 230) : k.type == 'A' ? Color.rgb(120, 230, 255) : Color.rgb(200, 220, 255);
                p.setColor(Neon.withAlpha(gc, 70 + (int) (60 * Math.sin(playTime * 4))));
                c.drawCircle(k.x + 0.4f, k.y + 0.4f + bob, 0.75f, p);
            }
            if (b != null) GameKit.draw(c, b, k.x, k.y + bob, s, s);
            else if (k.type == 'E') GameKit.draw(c, EcoArt.gem(Color.rgb(255, 120, 230)), k.x, k.y + bob, 0.8f, 0.8f);
            else {
                p.setColor(Color.WHITE);
                c.drawCircle(k.x + 0.4f, k.y + 0.4f + bob, 0.28f, p);
            }
        }
        EcoBoss2.draw(this, c, p);
        if (ol) {     // sombras bajo los personajes
            p.setColor(Color.argb(90, 0, 0, 0));
            for (Enemy e : enemies) if (!e.dead && !e.hidden) shadow(c, e.b.x, e.b.y, e.b.w, e.b.h);
            shadow(c, pl.x, pl.y, pl.w, pl.h);
        }
        // enemigos
        for (Enemy e : enemies) drawEnemy(c, e);
        // disparos
        for (Shot s : shots) drawShot(c, s);
        if (ol) {     // bloom: las ondas y los proyectiles brillan
            for (Shot s : shots) {
                if (s.dead) continue;
                float cx = s.x + s.w / 2, cy = s.y + s.h / 2, r = Math.max(s.w, s.h) * (s.big ? 1.3f : 1.1f) + 0.35f;
                int col = s.mine ? Color.argb(85, 140, 210, 255) : Color.argb(70, 255, 120, 90);
                p.setShader(new RadialGradient(cx, cy, r, col, Color.TRANSPARENT, Shader.TileMode.CLAMP));
                c.drawCircle(cx, cy, r, p);
            }
            p.setShader(null);
        }
        // jugadora
        drawBee(c);
        // zarpazos
        for (Fx f : fx) if ("CLAW".equals(f.s)) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.1f);
            p.setColor(Color.argb((int) (255 * (1 - f.t / f.life)), 255, 230, 230));
            for (int i = 0; i < 3; i++) {
                float ox0 = f.x + 0.3f + i * 0.4f;
                c.drawLine(ox0, f.y + 0.1f, ox0 + f.color * 0.6f, f.y + 1.4f, p);
            }
            p.setStyle(Paint.Style.FILL);
        }
        // oscuridad (Nido y Abismo): el Farolillo ilumina más
        if (z.darkness && mode != M_VAMPEND) {
            float r = M[EcoData.M_LIGHT] > 0 ? 9f : 4.2f;
            p.setShader(new RadialGradient(pl.x + pl.w / 2, pl.y + pl.h / 2, r, new int[]{Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Color.argb(235, 0, 0, 0)},
                    new float[]{0, 0.6f, 1}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, EcoWorld.W, EcoWorld.H, p);
            p.setShader(null);
        }
        if (ol && !z.darkness) {   // viñeta: negros profundos en los bordes
            p.setShader(new RadialGradient(EcoWorld.W / 2f, EcoWorld.H / 2f, EcoWorld.W * 0.62f, new int[]{Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(110, 0, 0, 0)},
                    new float[]{0, 0.6f, 1}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, EcoWorld.W, EcoWorld.H, p);
            p.setShader(null);
        }
        c.restore();

        // franjas laterales oscuras (zona de controles)
        p.setColor(Color.rgb(6, 6, 12));
        c.drawRect(0, 0, ox, vh, p);
        c.drawRect(ox + EcoWorld.W * T, 0, vw, vh, p);
        c.drawRect(ox, 0, ox + EcoWorld.W * T, oy, p);
        c.drawRect(ox, oy + EcoWorld.H * T, ox + EcoWorld.W * T, vh, p);
        p.setColor(Neon.withAlpha(z.map, 110));
        c.drawRect(ox - 1.5f, oy, ox, oy + EcoWorld.H * T, p);
        c.drawRect(ox + EcoWorld.W * T, oy, ox + EcoWorld.W * T + 1.5f, oy + EcoWorld.H * T, p);

        // números flotantes y bocadillos (en coordenadas de pantalla)
        for (Fx f : fx) {
            if ("CLAW".equals(f.s)) continue;
            int a = (int) (255 * Math.max(0, 1 - f.t / f.life));
            text(c, f.s, ox + f.x * T, oy + f.y * T, 13, Neon.withAlpha(f.color, a));
        }
        for (Enemy e : enemies) if (e.sayT > 0 && e.say != null) {
            float sx = ox + (e.b.x + e.b.w / 2) * T, sy = oy + e.b.y * T - 10;
            txt.setTextSize(11);
            float tw = txt.measureText(L.t(e.say)) + 14;
            RectF r = new RectF(sx - tw / 2, sy - 16, sx + tw / 2, sy + 3);
            p.setColor(Color.argb(220, 255, 255, 255));
            c.drawRoundRect(r, 6, 6, p);
            text(c, e.say, sx, sy - 3, 11, Color.BLACK);
        }
        EcoBoss2.drawOverlay(this, c, p);
        // barra de vida del jefe
        if (fightActive) {
            float total = 0, max = 0;
            String name = "";
            for (Enemy e : enemies) if (e.boss && !e.decoy) { total += Math.max(0, e.hp); max += e.maxHp; name = bossName(e); }
            if (max > 0) {
                float bw = Math.min(320, EcoWorld.W * T - 20), bx = vw / 2 - bw / 2, by = Math.min(vh - 8, oy + EcoWorld.H * T + 16);
                p.setColor(Color.argb(180, 0, 0, 0));
                c.drawRoundRect(bx - 4, by - 18, bx + bw + 4, by + 10, 6, 6, p);
                p.setColor(Color.rgb(255, 70, 90));
                c.drawRect(bx, by, bx + bw * total / max, by + 6, p);
                text(c, name, vw / 2, by - 4, 12, Color.WHITE);
            }
        }
    }

    void drawParticles(Canvas c, EcoData.Zone z) {
        int n = 24;
        float t = playTime;
        for (int i = 0; i < n; i++) {
            float sx = (i * 7.31f) % EcoWorld.W, sy = (i * 3.17f) % EcoWorld.H;
            switch (z.particles) {
                case EcoData.PT_SNOW:
                    p.setColor(Color.argb(170, 255, 255, 255));
                    c.drawCircle((sx + (float) Math.sin(t + i) * 0.6f) % EcoWorld.W, (sy + t * 1.2f) % EcoWorld.H, 0.07f, p);
                    break;
                case EcoData.PT_RAIN:
                    p.setColor(Color.argb(110, 170, 180, 255));
                    float ry = (sy + t * 14 + i) % EcoWorld.H;
                    c.drawRect(sx, ry, sx + 0.04f, ry + 0.5f, p);
                    break;
                case EcoData.PT_SPORES: case EcoData.PT_PETALS: case EcoData.PT_LEAVES:
                    p.setColor(z.particles == EcoData.PT_PETALS ? Color.argb(150, 255, 120, 160) : z.particles == EcoData.PT_LEAVES ? Color.argb(120, 150, 220, 110) : Color.argb(140, 200, 240, 120));
                    c.drawCircle((sx + t * 0.4f + (float) Math.sin(t * 1.3f + i)) % EcoWorld.W, (sy + t * 0.5f) % EcoWorld.H, 0.08f, p);
                    break;
                case EcoData.PT_SPARKS: case EcoData.PT_EMBERS:
                    p.setColor(z.particles == EcoData.PT_EMBERS ? Color.argb(170, 255, 80, 40) : Color.argb(140, 255, 220, 150));
                    c.drawCircle(sx + (float) Math.sin(t * 2 + i) * 0.3f, EcoWorld.H - ((sy + t * 0.8f) % EcoWorld.H), 0.06f, p);
                    break;
                case EcoData.PT_WIND:
                    p.setColor(Color.argb(70, 255, 255, 255));
                    float wx = (sx + t * 6) % EcoWorld.W;
                    c.drawRect(wx, sy, wx + 1.2f, sy + 0.05f, p);
                    break;
                case EcoData.PT_BUBBLES:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(0.04f);
                    p.setColor(Color.argb(110, 160, 255, 230));
                    c.drawCircle(sx, EcoWorld.H - ((sy + t * 1.1f) % EcoWorld.H), 0.12f, p);
                    p.setStyle(Paint.Style.FILL);
                    break;
                case EcoData.PT_DUST:
                    p.setColor(Color.argb(80, 220, 220, 220));
                    c.drawCircle((sx + (float) Math.sin(t * 0.3f + i) * 1.5f), (sy + (float) Math.cos(t * 0.4f + i)) , 0.05f, p);
                    break;
            }
        }
    }

    void drawBee(Canvas c) {
        if (invul > 0 && mode == M_PLAY && ((int) (invul * 15)) % 2 == 0) return;
        Bitmap b;
        if (!pl.onGround) b = facingR ? sBeeJump : sBeeJumpL;
        else if (Math.abs(pl.vx) > 0.5f && ((int) walk) % 2 == 0) b = facingR ? sBeeRun : sBeeRunL;
        else b = facingR ? sBee : sBeeL;
        if (dashT > 0) {
            p.setColor(Color.argb(90, 255, 255, 255));
            c.drawRect(pl.x - (facingR ? 1.2f : -pl.w), pl.y + 0.2f, pl.x + (facingR ? 0 : pl.w + 1.2f), pl.y + pl.h - 0.2f, p);
        }
        if (gravSign < 0) { c.save(); c.scale(1, -1, 0, pl.y + pl.h / 2); }
        GameKit.draw(c, b, pl.x - 0.15f, pl.y - 0.2f, pl.w + 0.3f, pl.h + 0.2f);
        if (gravSign < 0) c.restore();
        if (claws()) {         // garras: puntitas rojas en las patas
            p.setColor(Color.rgb(200, 20, 40));
            float hx = facingR ? pl.x + pl.w : pl.x - 0.1f;
            c.drawRect(hx, pl.y + pl.h - 0.25f, hx + 0.1f, pl.y + pl.h - 0.05f, p);
        }
        if (healHold > 0) {
            p.setColor(Color.argb(160, 255, 150, 200));
            c.drawCircle(pl.x + pl.w / 2, pl.y + pl.h / 2, 0.3f + healHold, p);
        }
        if (chargeT > 0.9f) {
            p.setColor(Color.argb(90 + (int) (60 * Math.sin(playTime * 20)), 255, 240, 160));
            c.drawCircle(pl.x + pl.w / 2, pl.y + pl.h / 2, 0.75f, p);
        }
    }

    void drawEnemy(Canvas c, Enemy e) {
        if (e.dead) return;
        Body b = e.b;
        // Sangre Joven: sombra en el suelo donde va a caer
        if (e.type == 'B' && e.bdef != null && e.bdef.id.equals("V4") && (e.state == 2 || e.state == 3)) {
            float mx = b.x + b.w / 2, gy = groundBelow(mx, b.y + b.h);
            float pulse = 0.6f + 0.4f * (float) Math.sin(e.t2 * 14);
            p.setColor(Color.argb((int) (90 + 80 * pulse), 200, 0, 30));
            c.drawOval(mx - b.w * 0.6f, gy - 0.22f, mx + b.w * 0.6f, gy + 0.12f, p);
        }
        if (e.type == '1' && e.hidden) {   // montículo de tierra
            p.setColor(Color.rgb(120, 80, 40));
            float mx = b.x + b.w / 2;
            float floorY = b.y + b.h;
            c.drawOval(mx - 0.9f, floorY - 0.45f, mx + 0.9f, floorY + 0.15f, p);
            p.setColor(Color.rgb(160, 110, 60));
            c.drawCircle(mx + (float) Math.sin(e.t * 20) * 0.3f, floorY - 0.5f, 0.12f, p);
            return;
        }
        Bitmap s = null;
        boolean flipWithDir = false;
        if (e.type == 'k') {
            EcoData.Kind k = e.kind;
            if (k.arch == EcoData.A_SPIDER && e.state == 0) {     // hilo
                p.setColor(Color.argb(140, 230, 230, 240));
                c.drawRect(b.x + b.w / 2 - 0.02f, 1, b.x + b.w / 2 + 0.02f, b.y, p);
            }
            if (k.tpl == EcoData.T_ORB) {
                float cx = b.x + b.w / 2, cy = b.y + b.h / 2;
                p.setColor(Neon.withAlpha(k.c2, 120));
                c.drawCircle(cx, cy, 0.45f + (float) Math.sin(e.t * 12) * 0.06f, p);
                p.setColor(e.flash > 0 ? Color.WHITE : k.c1);
                c.drawCircle(cx, cy, 0.22f, p);
                drawHpBar(c, e);
                return;
            }
            Bitmap[] fr = EcoArt.kind(k);
            int frame = ((int) (e.t * (k.flies() ? 8 : 5))) % 2;
            if (k.arch == EcoData.A_TURRET && e.kind.tpl == EcoData.T_EYE) frame = e.cd > 0.3f && e.cd < 0.8f ? 1 : 0;
            s = fr[frame];
            flipWithDir = !k.flies() || k.arch == EcoData.A_DIVE;
        } else if (e.type == 'B' || e.type == 'D') {
            boolean alt = (e.bdef.id.equals("V2") && e.role == 2) || (e.bdef.id.equals("B20") && e.role == 1);
            Bitmap[] fr = EcoArt.boss(e.bdef, alt);
            s = fr[((int) (e.t * (e.flying ? 7 : 4))) % 2];
            flipWithDir = true;
            if (e.bdef.id.equals("V3")) flipWithDir = false;
        } else {
            switch (e.type) {
                case '1': s = sReyTopo; flipWithDir = true; break;
                case '2': s = sVagoneta; break;
                case '3': s = e.role == 0 ? sGemelo : sGemelo2; break;
            }
        }
        if (s != null) {
            boolean flip = flipWithDir && e.dir < 0;
            if (e.type == 'B' && e.bdef.id.equals("V3")) flip = true;     // la planta mira a la izquierda
            c.save();
            if (flip) c.scale(-1, 1, b.x + b.w / 2, 0);
            Paint w = null;
            if (e.flash > 0) {
                w = new Paint();
                w.setColorFilter(new android.graphics.PorterDuffColorFilter(Color.WHITE, android.graphics.PorterDuff.Mode.SRC_ATOP));
            } else if (e.vis < 1 || e.slow > 0) {
                w = new Paint();
                w.setAlpha((int) (255 * Math.max(0.12f, e.vis)));
                if (e.slow > 0) w.setColorFilter(new android.graphics.PorterDuffColorFilter(Color.argb(90, 150, 220, 255), android.graphics.PorterDuff.Mode.SRC_ATOP));
            }
            if (w != null) GameKit.draw(c, s, b.x - 0.05f, b.y - 0.1f, b.w + 0.1f, b.h + 0.1f, w);
            else GameKit.draw(c, s, b.x - 0.05f, b.y - 0.1f, b.w + 0.1f, b.h + 0.1f);
            c.restore();
        }
        // aturdido: estrellitas
        if ((e.type == 'B' && ((e.bdef.id.equals("V1") && e.state == 3) || (e.bdef.id.equals("V4") && e.state == 4) || e.stun > 0))
                || (e.type == 'k' && e.kind.arch == EcoData.A_CHARGE && e.state == 2)) {
            p.setColor(Color.YELLOW);
            for (int i = 0; i < 3; i++)
                c.drawCircle(b.x + b.w / 2 + (float) Math.sin(e.t * 6 + i * 2.1f) * 0.5f, b.y - 0.2f + (float) Math.cos(e.t * 6 + i * 2.1f) * 0.15f, 0.08f, p);
        }
        // zarpazo del Conde
        if (e.slashT > 0) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.12f);
            p.setColor(Color.rgb(255, 60, 80));
            float hx = b.x + b.w / 2 + e.dir * 0.8f;
            for (int i = 0; i < 3; i++) c.drawLine(hx + i * 0.3f * e.dir, b.y + 0.2f, hx + (i * 0.3f + 1) * e.dir, b.y + b.h, p);
            p.setStyle(Paint.Style.FILL);
        }
        drawHpBar(c, e);
    }

    void drawHpBar(Canvas c, Enemy e) {
        Body b = e.b;
        if (!e.boss && e.hp < e.maxHp) {
            p.setColor(Color.argb(160, 0, 0, 0));
            c.drawRect(b.x, b.y - 0.25f, b.x + b.w, b.y - 0.15f, p);
            p.setColor(Color.rgb(255, 80, 80));
            c.drawRect(b.x, b.y - 0.25f, b.x + b.w * Math.max(0, e.hp) / e.maxHp, b.y - 0.15f, p);
        }
    }

    void drawShot(Canvas c, Shot s) {
        switch (s.kind) {
            case SH_WAVE: {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(s.big ? 0.16f : 0.09f);
                p.setColor(s.frost ? Color.rgb(170, 230, 255) : Color.rgb(255, 235, 140));
                float cx = s.x + s.w / 2;
                RectF r = new RectF(cx - s.w / 2, s.y, cx + s.w / 2, s.y + s.h);
                c.drawArc(r, s.vx > 0 ? -60 : 120, 120, false, p);
                RectF r2 = new RectF(cx - s.w / 2 - 0.15f, s.y - 0.1f, cx + s.w / 2 - 0.15f, s.y + s.h + 0.1f);
                if (s.vx < 0) r2.offset(0.3f, 0);
                p.setColor(Color.argb(140, 255, 235, 140));
                c.drawArc(r2, s.vx > 0 ? -60 : 120, 120, false, p);
                p.setStyle(Paint.Style.FILL);
                break;
            }
            case SH_EWAVE: {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(0.1f);
                p.setColor(Color.rgb(140, 120, 220));
                float cx = s.x + s.w / 2;
                c.drawArc(new RectF(cx - s.w / 2, s.y, cx + s.w / 2, s.y + s.h), s.vx > 0 ? -60 : 120, 120, false, p);
                p.setStyle(Paint.Style.FILL);
                break;
            }
            case SH_FLAME:
                p.setColor(Color.argb(200, 255, 120 + rnd.nextInt(80), 30));
                c.drawCircle(s.x + 0.2f, s.y + 0.2f, 0.18f + (0.3f - s.life) * 0.6f, p);
                break;
            case SH_PEBBLE: case SH_ROCK:
                p.setColor(s.kind == SH_ROCK ? Color.rgb(140, 100, 60) : Color.rgb(120, 120, 130));
                c.drawRect(s.x, s.y, s.x + s.w, s.y + s.h, p);
                break;
            case SH_SNOW:
                p.setColor(Color.WHITE);
                c.drawCircle(s.x + s.w / 2, s.y + s.h / 2, s.w / 2, p);
                break;
            case SH_WEB:
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(0.05f);
                p.setColor(Color.rgb(230, 230, 240));
                c.drawCircle(s.x + s.w / 2, s.y + s.h / 2, s.w / 2, p);
                c.drawLine(s.x, s.y, s.x + s.w, s.y + s.h, p);
                c.drawLine(s.x + s.w, s.y, s.x, s.y + s.h, p);
                p.setStyle(Paint.Style.FILL);
                break;
            case SH_RING:
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(0.08f);
                p.setColor(Color.rgb(220, 120, 255));
                c.drawCircle(s.x + s.w / 2, s.y + s.h / 2, s.w / 2, p);
                p.setStyle(Paint.Style.FILL);
                break;
            case SH_GHOSTFIRE: case SH_ORB: case SH_ROSE:
                p.setColor(s.kind == SH_GHOSTFIRE ? Color.argb(210, 120, 200, 255) : Neon.withAlpha(s.color, 220));
                c.drawCircle(s.x + s.w / 2, s.y + s.h / 2, s.w / 2, p);
                p.setColor(Color.WHITE);
                c.drawCircle(s.x + s.w / 2, s.y + s.h / 2, s.w / 5, p);
                break;
            case SH_SHOCK:
                p.setColor(Neon.withAlpha(s.color, 200));
                c.drawRect(s.x, s.y + s.h * 0.3f, s.x + s.w, s.y + s.h, p);
                p.setColor(Color.WHITE);
                c.drawRect(s.x, s.y + s.h * 0.3f, s.x + s.w, s.y + s.h * 0.45f, p);
                break;
            case SH_BEAM:
                p.setColor(Neon.withAlpha(s.color, 210));
                c.drawRect(s.x, s.y, s.x + s.w, s.y + s.h, p);
                p.setColor(Color.argb(230, 255, 255, 255));
                c.drawRect(s.x, s.y + s.h * 0.35f, s.x + s.w, s.y + s.h * 0.65f, p);
                break;
            case SH_VINE:
                p.setColor(Color.rgb(60, 130, 50));
                c.drawRect(s.x, s.y + 0.15f, s.x + s.w, s.y + s.h - 0.15f, p);
                p.setColor(Color.rgb(220, 230, 200));
                for (float x = s.x; x < s.x + s.w; x += 0.7f) {
                    c.drawRect(x, s.y, x + 0.1f, s.y + 0.2f, p);
                    c.drawRect(x + 0.35f, s.y + s.h - 0.2f, x + 0.45f, s.y + s.h, p);
                }
                break;
            case SH_DUST: case SH_VOID:
                p.setColor(s.kind == SH_DUST ? Color.argb(110, 220, 180, 230) : Color.argb(150, 40, 30, 60));
                c.drawCircle(s.x + s.w / 2, s.y + s.h / 2, s.w / 2 + (float) Math.sin(playTime * 5 + s.x) * 0.08f, p);
                break;
            case SH_COCOON:
                p.setColor(Color.rgb(210, 210, 225));
                c.drawOval(s.x, s.y, s.x + s.w, s.y + s.h * 1.3f, p);
                p.setColor(Color.rgb(150, 150, 170));
                c.drawRect(s.x + s.w * 0.2f, s.y + s.h * 0.5f, s.x + s.w * 0.8f, s.y + s.h * 0.6f, p);
                break;
            case SH_THREAD:
                p.setColor(Color.WHITE);
                c.drawCircle(s.x + s.w / 2, s.y + s.h / 2, s.w / 2, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.05f);
                Enemy mb = mainBoss();
                if (mb != null) c.drawLine(s.x + s.w / 2, s.y + s.h / 2, mb.b.x + mb.b.w / 2, mb.b.y + mb.b.h / 2, p);
                p.setStyle(Paint.Style.FILL);
                break;
            case SH_CAPE:
                p.setColor(Color.rgb(120, 0, 20));
                c.drawRect(s.x, s.y, s.x + s.w, s.y + s.h, p);
                p.setColor(Color.rgb(200, 30, 50));
                c.drawRect(s.x, s.y, s.x + s.w, s.y + 0.2f, p);
                break;
        }
    }

    void drawHud(Canvas c, int neon) {
        float bw = ox - 16;
        // barra de vida (100 puntos, sube con emblemas)
        p.setColor(Color.argb(170, 0, 0, 0));
        c.drawRoundRect(6, 8, 10 + bw, 26, 5, 5, p);
        p.setColor(hp < maxHp() * 0.3f ? Color.rgb(255, 70, 90) : Color.rgb(255, 120, 150));
        c.drawRoundRect(8, 10, 8 + bw * Math.max(0, hp) / maxHp(), 24, 4, 4, p);
        text(c, Math.max(0, Math.round(hp)) + " / " + Math.round(maxHp()), 8 + bw / 2, 21, 11, Color.WHITE);
        // lana para curar
        float ls = Math.min(11, (ox - 14) / 9);
        for (int i = 0; i < 9; i++) {
            p.setColor(i < lana ? Color.rgb(255, 150, 200) : Color.argb(60, 255, 255, 255));
            c.drawRect(8 + i * ls, 32, 8 + i * ls + ls - 3, 38, p);
        }
        textLeft(c, "🔔 " + bells, 8, 58, 13, Color.WHITE);
        textLeft(c, "💎 " + ore + "  ✦ " + ecos + "/20", 8, 76, 12, Color.WHITE);
        textLeft(c, "🗝 " + keys + "  🩸 " + ckeys + (bkeys > 0 ? "  🔷 " + bkeys : ""), 8, 94, 12, Color.WHITE);
        String wl = claws() ? "🐾 Garras" : weapon == 0 ? "Cencerro nv" + cLvl : "🔥 Trompeta";
        textLeft(c, wl, 8, 112, 11, Color.rgb(255, 230, 150));
        if (!claws() && weapon == 0 && branch > 0) textLeft(c, EcoWorld.BRANCH_NAMES[branch], 8, 127, 10, Color.rgb(255, 230, 150));
        if (M[EcoData.M_SHIELD] > 0) textLeft(c, shieldT <= 0 ? "🛡 listo" : "🛡 " + (int) Math.ceil(shieldT) + "s", 8, 142, 10, Color.rgb(160, 220, 255));
    }

    // =====================================================================
    // Bitmap de la sala (arte de píxeles 8×8 por casilla) y fondo temático
    // =====================================================================
    void buildRoomBitmap() {
        int S = 8;
        if (roomBmp == null) roomBmp = Bitmap.createBitmap(EcoWorld.W * S, EcoWorld.H * S, Bitmap.Config.ARGB_8888);
        if (bgBmp == null) bgBmp = Bitmap.createBitmap(EcoWorld.W * S, EcoWorld.H * S, Bitmap.Config.ARGB_8888);
        EcoData.Zone z = zone();
        EcoArt.background(new Canvas(bgBmp), z, EcoWorld.W * S, EcoWorld.H * S, room.gx * 131L + room.gy * 977L, room.dungeon > 0);
        roomBmp.eraseColor(Color.TRANSPARENT);
        Canvas bc = new Canvas(roomBmp);
        Paint q = new Paint();
        boolean speck = room.zone == EcoData.Z_MINAS || room.zone == EcoData.Z_CRISTAL || room.zone == EcoData.Z_COLMENA;
        int rock = room.safe ? EcoArt.dark(z.rock, 1.15f) : z.rock;
        int dark = z.dark;
        int edge = room.safe && room.zone == EcoData.Z_PRADERA ? Color.rgb(200, 160, 90) : z.edge;
        Random r = new Random(room.gx * 31 + room.gy * 17);
        for (int y = 0; y < EcoWorld.H; y++)
            for (int x = 0; x < EcoWorld.W; x++) {
                char ch = room.t[y][x];
                int px0 = x * S, py0 = y * S;
                if (ch == '#' || ch == 'F') {
                    q.setColor(rock);
                    bc.drawRect(px0, py0, px0 + S, py0 + S, q);
                    q.setColor(dark);
                    for (int k = 0; k < 3; k++) {
                        int sx = r.nextInt(7), sy = r.nextInt(7);
                        bc.drawRect(px0 + sx, py0 + sy, px0 + sx + (ch == 'F' ? 1 : 2), py0 + sy + 1, q);
                    }
                    if (speck && r.nextFloat() < 0.15f) {
                        q.setColor(z.edge);
                        bc.drawRect(px0 + 2, py0 + 3, px0 + 4, py0 + 4, q);
                    }
                    boolean airAbove = y > 0 && room.t[y - 1][x] != '#' && room.t[y - 1][x] != 'F';
                    if (airAbove) {
                        q.setColor(edge);
                        bc.drawRect(px0, py0, px0 + S, py0 + 2, q);
                        if (room.zone == EcoData.Z_PRADERA && !room.safe) bc.drawRect(px0 + r.nextInt(6), py0 - 1, px0 + r.nextInt(6) + 1, py0, q);
                        if (room.zone == EcoData.Z_LAGO) { q.setColor(Color.argb(160, 230, 250, 255)); bc.drawRect(px0 + r.nextInt(6), py0 + 2, px0 + r.nextInt(6) + 1, py0 + 4 + r.nextInt(3), q); }
                    }
                } else if (ch == '=') {
                    q.setColor(z.plat);
                    bc.drawRect(px0, py0, px0 + S, py0 + 3, q);
                    q.setColor(EcoArt.dark(z.plat, 1.3f));
                    bc.drawRect(px0, py0, px0 + S, py0 + 1, q);
                    q.setColor(EcoArt.dark(z.plat, 0.6f));
                    if (x % 3 == 0) bc.drawRect(px0 + 3, py0 + 3, px0 + 5, py0 + 6, q);
                } else if (ch == '^') {
                    q.setColor(room.zone == EcoData.Z_JARDIN ? Color.rgb(90, 160, 80) : Color.rgb(200, 200, 215));
                    for (int k = 0; k < 4; k++) {
                        int bx = px0 + k * 2;
                        bc.drawRect(bx, py0 + 4, bx + 2, py0 + 8, q);
                        bc.drawRect(bx + 0.5f, py0 + 2, bx + 1.5f, py0 + 4, q);
                    }
                }
            }
        // aspecto OLED: bordes iluminados y sombreados (toque 3D)
        if (oled()) {
            for (int y = 0; y < EcoWorld.H; y++)
                for (int x = 0; x < EcoWorld.W; x++) {
                    char ch = room.t[y][x];
                    if (ch != '#' && ch != 'F') continue;
                    int px0 = x * S, py0 = y * S;
                    boolean open = room.t[y][x] == '#';
                    if (!open) continue;
                    if (y > 0 && room.t[y - 1][x] != '#') { q.setColor(Color.argb(150, 255, 255, 255)); bc.drawRect(px0, py0, px0 + S, py0 + 1, q); }
                    if (x > 0 && room.t[y][x - 1] != '#') { q.setColor(Color.argb(70, 255, 255, 255)); bc.drawRect(px0, py0, px0 + 1, py0 + S, q); }
                    if (x < EcoWorld.W - 1 && room.t[y][x + 1] != '#') { q.setColor(Color.argb(90, 0, 0, 0)); bc.drawRect(px0 + S - 1, py0, px0 + S, py0 + S, q); }
                    if (y < EcoWorld.H - 1 && room.t[y + 1][x] != '#') { q.setColor(Color.argb(110, 0, 0, 0)); bc.drawRect(px0, py0 + S - 2, px0 + S, py0 + S, q); }
                }
        }
        // farolillos en los refugios
        if (room.safe) {
            for (int x = 3; x < EcoWorld.W - 2; x += 7) {
                q.setColor(Color.argb(60, 255, 200, 100));
                bc.drawCircle(x * S + 4, 2 * S, 10, q);
                q.setColor(Color.rgb(255, 210, 120));
                bc.drawRect(x * S + 2, 2 * S - 2, x * S + 6, 2 * S + 3, q);
            }
        }
        // zarzas alrededor del cadáver vampírico
        if (room.has('Y')) {
            q.setColor(Color.rgb(60, 110, 40));
            for (int i = 0; i < 30; i++) { int x = 18 * S + r.nextInt(5 * S), y = 12 * S + r.nextInt(3 * S); bc.drawRect(x, y, x + 1, y + 3, q); }
        }
    }

    Bitmap npcSprite(char ch) {
        switch (ch) {
            case 'S': return sFardo;
            case 'T': return sTopo;
            case 'O': return sSabio;
            case 'M': return sPolice;
            case 'P': return sSapo;
            case 'H': return sHerrera;
            case 'Q': return sFantasma;
            case 'Y': return sCorpse;
            case 'N': return sPresenter;
            default: return null;
        }
    }

    // ---------------- pantallas ----------------
    void overlay(Canvas c, int alpha) {
        p.setColor(Color.argb(alpha, 0, 0, 0));
        c.drawRect(0, 0, vw, vh, p);
    }

    RectF closeRect() { return new RectF(vw / 2 - 70, vh - 32, vw / 2 + 70, vh - 4); }

    // carátula del juego (arte de BLORP.eoac)
    static Bitmap cover;
    static boolean coverTried;
    final Paint coverP = new Paint(Paint.FILTER_BITMAP_FLAG);

    Bitmap cover() {
        if (!coverTried) {
            coverTried = true;
            try (java.io.InputStream in = getContext().getAssets().open("eco_cover.webp")) {
                cover = android.graphics.BitmapFactory.decodeStream(in);
            } catch (Throwable ignored) {}
        }
        return cover;
    }

    void drawTitle(Canvas c, int neon) {
        Bitmap cv = cover();
        float mx;
        if (cv != null && cv.getWidth() > 0 && cv.getHeight() > 0) {
            // la carátula llena la pantalla (recortando lo que sobre) y el menú va a la derecha, sobre un velo oscuro
            float sc = Math.max(vw / cv.getWidth(), vh / cv.getHeight());
            float w = cv.getWidth() * sc, h = cv.getHeight() * sc;
            GameKit.draw(c, cv, (vw - w) / 2, (vh - h) / 2, w, h, coverP);
            p.setShader(new LinearGradient(vw - 330, 0, vw, 0, Color.argb(0, 0, 0, 0), Color.argb(200, 5, 5, 15), Shader.TileMode.CLAMP));
            c.drawRect(vw - 330, 0, vw, vh, p);
            p.setShader(null);
            mx = vw - 140;
        } else {
            p.setShader(new LinearGradient(0, 0, 0, vh, Color.rgb(20, 30, 60), Color.rgb(5, 5, 15), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, vw, vh, p);
            p.setShader(null);
            p.setColor(Color.argb(160, 255, 255, 255));
            for (int i = 0; i < 50; i++) c.drawRect((i * 131) % vw, (i * 71) % (vh * 0.7f), (i * 131) % vw + 1.5f, (i * 71) % (vh * 0.7f) + 1.5f, p);
            text(c, "EL PASTOR", vw / 2, 70, 38, Color.rgb(255, 240, 200));
            text(c, "DE ECOS", vw / 2, 112, 38, Color.rgb(255, 240, 200));
            GameKit.draw(c, sBee, vw / 2 - 22, 128, 44, 44);
            mx = vw / 2;
        }
        textLeft(c, "por BLORP.eoac", 8, vh - 8, 9, Color.argb(170, 230, 230, 245));
        float y = cv != null ? 84 : 180;
        float bh = 36, gap = 44;
        if (hasSave()) {
            if (menuButton(c, new RectF(mx - 120, y, mx + 120, y + bh), "▶ CONTINUAR", neon)) { continueGame(); return; }
            y += gap;
        }
        if (menuButton(c, new RectF(mx - 120, y, mx + 120, y + bh), hasSave() ? "NUEVA PARTIDA" : "▶ EMPEZAR", neon)) {
            if (hasSave()) { confirmText = "¿Empezar de cero? Se borrará tu partida."; confirmYes = this::newGame; confirmNo = null; mode = M_CONFIRM; }
            else newGame();
            return;
        }
        y += gap;
        int dexN = dex().size();
        if (dexN > 0) {
            if (menuButton(c, new RectF(mx - 120, y, mx + 120, y + bh), "⚔ MODO JEFES (" + dexN + ")", neon)) { openBossRush(); return; }
            y += gap;
        }
        if (menuButton(c, new RectF(mx - 120, y, mx + 120, y + bh), "🏆 LOGROS (" + achievements().size() + "/" + EcoData.ACHIEVEMENTS.length + ")", neon)) {
            achFrom = M_TITLE; mode = M_ACHIEVE; return;
        }
        y += gap;
        if (menuButton(c, new RectF(mx - 120, y, mx + 120, y + bh), "SALIR", neon)) ((android.app.Activity) getContext()).finish();
        String done = flag("ending_vamp") ? " · 🦇 final secreto visto" : flag("ending1") ? " · ★ completado" : "";
        text(c, "20 ecos · " + EcoWorld.ROOMS.size() + " salas · se guarda en los fardos 🌾" + done, cv != null ? mx : vw / 2, vh - 12, cv != null ? 9 : 11, cv != null ? Color.LTGRAY : Color.GRAY);
    }

    void drawIntro(Canvas c, int neon) {
        p.setColor(Color.rgb(8, 8, 16));
        c.drawRect(0, 0, vw, vh, p);
        if (introIdx < EcoWorld.INTRO.length)
            wrap(c, EcoWorld.INTRO[introIdx], vw / 2, vh / 2 - 20, vw * 0.7f, 17, Color.WHITE, true);
        text(c, "toca para continuar ▸", vw / 2, vh - 30, 12, Color.GRAY);
    }

    void drawDialog(Canvas c, int neon) {
        RectF r = new RectF(30, vh - 120, vw - 30, vh - 14);
        box(c, r, neon, 235);
        float tx = r.left + 16;
        if (dlgFace != null) {
            GameKit.draw(c, dlgFace, r.left + 12, r.top + 14, 64, 64);
            tx = r.left + 90;
        }
        if (dlgName != null && !dlgName.isEmpty()) textLeft(c, dlgName, tx, r.top + 22, 14, neon);
        String cur = L.t(dlg[dlgIdx]);
        String shown = cur.substring(0, Math.min(cur.length(), (int) dlgChars));
        txt.setTextAlign(Paint.Align.LEFT);
        wrapRaw(c, shown, tx, r.top + (dlgName != null && !dlgName.isEmpty() ? 44 : 30), r.right - tx - 16, 14, Color.WHITE, false);
        text(c, (dlgIdx + 1) + "/" + dlg.length + " ▸", r.right - 30, r.bottom - 8, 11, Color.GRAY);
    }

    void drawConfirm(Canvas c, int neon) {
        overlay(c, 200);
        RectF r = new RectF(vw / 2 - 230, vh / 2 - 80, vw / 2 + 230, vh / 2 + 80);
        box(c, r, neon, 240);
        wrap(c, confirmText, vw / 2, r.top + 40, r.width() - 40, 16, Color.WHITE, true);
        if (menuButton(c, new RectF(vw / 2 - 200, r.bottom - 60, vw / 2 - 20, r.bottom - 16), "SÍ", neon)) {
            Runnable y = confirmYes;
            if (room != null) backToPlay(); else mode = M_TITLE;
            if (y != null) y.run();
            return;
        }
        if (menuButton(c, new RectF(vw / 2 + 20, r.bottom - 60, vw / 2 + 200, r.bottom - 16), "NO", Color.GRAY)) {
            Runnable n = confirmNo;
            if (room != null) backToPlay(); else mode = M_TITLE;
            if (n != null) n.run();
        }
    }

    int achFrom = M_TITLE;

    void drawAchieve(Canvas c, int neon) {
        p.setShader(new LinearGradient(0, 0, 0, vh, Color.rgb(25, 18, 45), Color.rgb(5, 5, 12), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, vw, vh, p);
        p.setShader(null);
        Set<String> got = achievements();
        text(c, "🏆 LOGROS · " + got.size() + "/" + EcoData.ACHIEVEMENTS.length, vw / 2, 34, 20, neon);
        float y = 52;
        for (String[] a : EcoData.ACHIEVEMENTS) {
            boolean on = got.contains(a[0]);
            RectF r = new RectF(vw / 2 - 260, y, vw / 2 + 260, y + 46);
            box(c, r, on ? Color.rgb(255, 210, 80) : Color.DKGRAY, on ? 230 : 160);
            text(c, on ? "🏆" : "🔒", r.left + 24, r.centerY() + 7, 20, Color.WHITE);
            textLeft(c, on ? a[1] : "???", r.left + 48, r.top + 20, 14, on ? Color.rgb(255, 235, 160) : Color.GRAY);
            textLeft(c, a[2], r.left + 48, r.top + 37, 10, on ? Color.LTGRAY : Color.GRAY);
            y += 52;
        }
        text(c, "Los logros son de todas tus partidas: no se borran al empezar de cero.", vw / 2, vh - 42, 10, Color.GRAY);
        if (menuButton(c, closeRect(), "VOLVER", neon)) mode = achFrom;
    }

    void drawPause(Canvas c, int neon) {
        overlay(c, 200);
        text(c, "PAUSA", vw / 2, 40, 24, neon);
        textLeft(c, "Ecos " + ecos + "/20 · Corderitos " + lambs + "/5 · Emblemas " + owned.size() + "/" + EcoData.EMBLEMS.length + " · " + SysInfo.duration((long) (playTime * 1000)), vw / 2 - 210, 62, 11, Color.LTGRAY);
        String[] labels = {"▶ CONTINUAR", "🗺 MAPA", "📖 BESTIARIO", "📿 EMBLEMAS",
                Chip.musicOn(getContext()) ? "🎵 Música: SÍ" : "🎵 Música: NO",
                Chip.sfxOn(getContext()) ? "🔊 Efectos: SÍ" : "🔊 Efectos: NO",
                blood() ? "🩸 Sangre: SÍ" : "🩸 Sangre: NO", "🎮 CONTROLES",
                oled() ? "✨ Aspecto OLED: SÍ" : "✨ Aspecto OLED: NO", "🏆 LOGROS",
                room == arena && coliseo ? "🏳 RETIRARSE" : "💾 SALIR"};
        for (int i = 0; i < labels.length; i++) {
            int col = i % 2, row = i / 2;
            RectF r = new RectF(vw / 2 - 210 + col * 215, 70 + row * 42, vw / 2 - 5 + col * 215, 104 + row * 42);
            if (menuButton(c, r, labels[i], neon)) {
                switch (i) {
                    case 0: backToPlay(); break;
                    case 1: openMap(); break;
                    case 2: mode = M_BEAST; break;
                    case 3: restMode = false; emblemPage = 0; mode = M_AMULET; break;
                    case 4: chip.toggleMusic(); break;
                    case 5: chip.toggleSfx(); break;
                    case 6: prefs().edit().putBoolean("eco_blood", !blood()).apply(); break;
                    case 7: mode = M_CONTROLS; break;
                    case 8: prefs().edit().putBoolean("eco_oled", !oled()).apply(); buildRoomBitmap(); break;
                    case 9: achFrom = M_PAUSE; mode = M_ACHIEVE; break;
                    case 10:
                        if (room == arena && coliseo) { retireColiseo(); break; }
                        if (bossMode) { finishBossRun(false); bossMsg = "Has abandonado el combate."; break; }
                        saveGame(false); mode = M_TITLE; room = null; chip.play(Songs.PUEBLO); break;
                }
                return;
            }
        }
        text(c, "Tus objetos se guardan al salir; volverás al último fardo en que descansaste.", vw / 2, vh - 12, 10, Color.GRAY);
    }

    /** Con mando externo: leyenda pequeña de botones en la franja izquierda. */
    void drawPadLegend(Canvas c) {
        int col = Color.argb(170, 220, 225, 240);
        float x = 8, y = vh - 92;
        textLeft(c, "🎮 Ⓐ saltar", x, y, 10, col);
        textLeft(c, (claws() ? "Ⓧ zarpazo" : "Ⓧ cencerro"), x, y + 14, 10, col);
        if (has(EcoData.AB_DASH)) textLeft(c, "Ⓑ embestida", x, y + 28, 10, col);
        textLeft(c, "Ⓨ curar", x, y + 42, 10, col);
        if (has(EcoData.AB_TROMP) && !claws()) textLeft(c, "LB/RB cambiar", x, y + 56, 10, col);
        if (nearNpc != null) textLeft(c, "↑ " + bUse.label, x, y + 70, 11, Color.rgb(255, 230, 140));
    }

    // ---------------- Modo Jefes ----------------
    Set<String> dex() {
        Set<String> s = new HashSet<>();
        for (String id : prefs().getString("eco_dex", "").split(",")) if (!id.isEmpty()) s.add(id);
        return s;
    }

    void recordDex(String id) {
        if (id == null || EcoData.boss(id) == null) return;
        Set<String> s = dex();
        if (s.add(id)) prefs().edit().putString("eco_dex", String.join(",", s)).apply();
    }

    /** Todos los jefes del mundo, en el orden del mapa. */
    List<EcoWorld.Room> bossRooms() {
        List<EcoWorld.Room> l = new ArrayList<>();
        for (EcoWorld.Room r : EcoWorld.ROOMS) if (r.bossId() != null && EcoData.boss(r.bossId()) != null) l.add(r);
        return l;
    }

    static final String[] BOSS_EQUIP_DEF = {"dobleeco", "garra", "pesado", "corona", "veloz", "corazon", "escudo", "lince"};

    /** Estado "armado hasta los dientes": todas las habilidades, forja al máximo y todos los emblemas. */
    void bossLoadout() {
        bells = 0; ore = 0; cLvl = EcoData.FORGE_BELLS.length; branch = 0; keys = 0; ckeys = 0; weapon = 0;
        flags = new HashSet<>(); visited = new HashSet<>(); kills = new HashMap<>(); dropRoom = null;
        abilities = new HashSet<>(java.util.Arrays.asList(EcoData.ABILITIES));
        owned = new HashSet<>();
        for (EcoData.Emblem em : EcoData.EMBLEMS) owned.add(em.id);
        equipped = new ArrayList<>();
        String saved = prefs().getString("eco_bm_equip", null);
        String[] ids = saved == null ? BOSS_EQUIP_DEF : saved.split(",");
        for (String id : ids) if (EcoData.emblem(id) != null && equipped.size() < EcoData.MAX_EQUIP && !equipped.contains(id)) equipped.add(id);
        recalc();
        hp = maxHp();
    }

    void saveBossEquip() { prefs().edit().putString("eco_bm_equip", String.join(",", equipped)).apply(); }

    void openBossRush() {
        bossMode = true;
        bossLoadout();
        room = null;
        bossMsg = null;
        mode = M_BOSSRUSH;
        chip.play(Songs.PUEBLO);
    }

    void startBossRun(EcoWorld.Room r) {
        bossLoadout();
        bossRunId = r.bossId();
        bossRoom = r;
        bossT = 0;
        bossMsg = null;
        invul = 1.5f;
        pl.vx = pl.vy = 0;
        mode = M_PLAY;
        enterRoom(r);
        pl.x = 13; pl.y = 14 - pl.h + 1;
        unstick();
        showPad(true);
    }

    void finishBossRun(boolean win) {
        String id = bossRunId;
        EcoData.Boss b = id == null ? null : EcoData.boss(id);
        if (win && b != null) {
            String key = "eco_bt_" + id;
            float best = prefs().getFloat(key, 0);
            boolean rec = best <= 0 || bossT < best;
            if (rec) prefs().edit().putFloat(key, bossT).apply();
            bossMsg = "¡" + b.name + " vencido en " + fmtTime(bossT) + "!" + (rec ? " ★ ¡Nuevo récord!" : " (récord " + fmtTime(best) + ")");
            chip.sfx(Chip.SFX_LEVEL);
        } else if (b != null) bossMsg = b.name + " te ha vencido. ¡Otra vez!";
        bossRoom = null;
        enemies.clear(); shots.clear();
        resetGimmicks();
        fightActive = false;
        showPad(false);
        pad.releaseAll();
        mode = M_BOSSRUSH;
        chip.play(Songs.PUEBLO);
    }

    static String fmtTime(float t) {
        int s = Math.round(t);
        return s / 60 + ":" + (s % 60 < 10 ? "0" : "") + s % 60;
    }

    void drawBossRush(Canvas c, int neon) {
        p.setColor(Color.rgb(10, 8, 20));
        c.drawRect(0, 0, vw, vh, p);
        text(c, "⚔ MODO JEFES", vw / 2, 28, 20, neon);
        text(c, "Todas las habilidades · forja nv " + EcoData.FORGE_BELLS.length + " · tus emblemas favoritos. No afecta a tu partida.", vw / 2, 44, 10, Color.LTGRAY);
        if (bossMsg != null) text(c, bossMsg, vw / 2, 60, 12, Color.rgb(255, 230, 140));
        Set<String> d = dex();
        List<EcoWorld.Room> rooms = bossRooms();
        int cols = 3, rows = 5, per = cols * rows, pages = Math.max(1, (rooms.size() + per - 1) / per);
        bossPage = Math.min(bossPage, pages - 1);
        float cw = Math.min(230, (vw - 40) / cols), x0 = vw / 2 - cw * cols / 2;
        for (int i = 0; i < per; i++) {
            int idx = bossPage * per + i;
            if (idx >= rooms.size()) break;
            EcoWorld.Room r = rooms.get(idx);
            String id = r.bossId();
            EcoData.Boss b = EcoData.boss(id);
            boolean open = d.contains(id);
            RectF rr = new RectF(x0 + (i % cols) * cw + 3, 70 + (i / cols) * 44, x0 + (i % cols + 1) * cw - 3, 70 + (i / cols) * 44 + 40);
            box(c, rr, open ? (id.startsWith("V") ? Color.rgb(230, 40, 70) : neon) : Color.DKGRAY, 200);
            if (open) {
                textLeft(c, b.name, rr.left + 6, rr.top + 16, 10, Color.WHITE);
                float best = prefs().getFloat("eco_bt_" + id, 0);
                textLeft(c, best > 0 ? "🏆 " + fmtTime(best) : "sin récord", rr.left + 6, rr.top + 31, 9, Color.LTGRAY);
                if (tapIn(rr)) { tapped = false; startBossRun(r); return; }
            } else textLeft(c, "🔒 ???", rr.left + 6, rr.top + 24, 11, Color.GRAY);
        }
        float by = vh - 40;
        if (pages > 1) {
            if (bossPage > 0 && menuButton(c, new RectF(16, by, 86, by + 32), "◀", neon)) bossPage--;
            if (bossPage < pages - 1 && menuButton(c, new RectF(vw - 86, by, vw - 16, by + 32), "▶", neon)) bossPage++;
        }
        if (menuButton(c, new RectF(vw / 2 - 200, by, vw / 2 - 4, by + 32), "📿 EMBLEMAS (" + equipped.size() + "/" + EcoData.MAX_EQUIP + ")", neon)) {
            restMode = true; emblemPage = 0; mode = M_AMULET; return;
        }
        if (menuButton(c, new RectF(vw / 2 + 4, by, vw / 2 + 200, by + 32), "VOLVER", neon)) { bossMode = false; mode = M_TITLE; }
    }

    // ---------------- ajustes de controles ----------------
    void drawControls(Canvas c, int neon) {
        overlay(c, 225);
        text(c, "🎮 CONTROLES", vw / 2, 36, 20, neon);
        float l = vw / 2 - 210, w = 420;
        if (menuButton(c, new RectF(l, 52, l + w, 90), joyMode ? "Movimiento: 🕹 JOYSTICK (↑ = saltar)" : "Movimiento: 🔘 BOTONES ◀ ▶", neon)) {
            ctrl.setMode(joyMode ? CTRL_BUTTONS : CTRL_JOY); applyCtrl(); return;
        }
        text(c, "Opacidad de los controles: " + ctrl.opacity() + "%", vw / 2, 114, 13, Color.WHITE);
        if (menuButton(c, new RectF(l, 122, l + 100, 158), "−", neon)) { ctrl.setOpacity(ctrl.opacity() - 10); applyCtrl(); return; }
        if (menuButton(c, new RectF(l + w - 100, 122, l + w, 158), "+", neon)) { ctrl.setOpacity(ctrl.opacity() + 10); applyCtrl(); return; }
        // vista previa del joystick con la opacidad elegida
        float sr = stick.r;
        stick.cx = vw / 2; stick.cy = 140; stick.r = 16;
        boolean vis = stick.visible; stick.visible = true;
        stick.draw(c, neon);
        stick.visible = vis; stick.r = sr; stick.cx = stick.homeX; stick.cy = stick.homeY;
        if (menuButton(c, new RectF(l, 166, l + w / 2 - 4, 200), ctrl.lefty() ? "✋ Zurdo: SÍ" : "✋ Zurdo: NO", neon)) {
            ctrl.setLefty(!ctrl.lefty()); relayout(); return;
        }
        if (menuButton(c, new RectF(l + w / 2 + 4, 166, l + w, 200), "Tamaño: " + ctrl.size() + "%", neon)) {
            ctrl.nextSize(); relayout(); return;
        }
        if (menuButton(c, new RectF(l, 208, l + w, 242), ctrl.gamepad() ? "Mando externo (Xbox / gamepad): SÍ" : "Mando externo (Xbox / gamepad): NO", neon)) {
            ctrl.setGamepad(!ctrl.gamepad()); applyCtrl(); return;
        }
        wrap(c, ctrl.gamepad()
                ? "Mando: palanca o cruceta = moverse · A saltar · X cencerro · B embestida · Y curar · ↑ hablar · LB/RB cambiar arma · START pausa · SELECT mapa. En los menús: A tocar, B atrás."
                : "Conecta un mando por Bluetooth o USB y activa esta opción para jugar con él. Los controles táctiles siguen funcionando.",
                vw / 2, 258, 400, 10, Color.LTGRAY, true);
        if (menuButton(c, new RectF(vw / 2 - 100, vh - 52, vw / 2 + 100, vh - 16), "VOLVER", neon)) mode = M_PAUSE;
    }

    // ---------------- descanso en el fardo ----------------
    void drawRest(Canvas c, int neon) {
        overlay(c, 190);
        GameKit.draw(c, sFardo, vw / 2 - 30, 40, 60, 60);
        text(c, "Descansas en el fardo 🌾", vw / 2, 124, 18, neon);
        text(c, "Partida guardada · vida recuperada", vw / 2, 146, 12, Color.LTGRAY);
        if (menuButton(c, new RectF(vw / 2 - 150, 170, vw / 2 + 150, 214), "📿 CAMBIAR EMBLEMAS (" + equipped.size() + "/" + EcoData.MAX_EQUIP + ")", neon)) {
            restMode = true; emblemPage = 0; mode = M_AMULET; return;
        }
        if (menuButton(c, new RectF(vw / 2 - 150, 224, vw / 2 + 150, 268), "▶ SEGUIR", neon)) { saveGame(true); backToPlay(); }
    }

    // ---------------- emblemas ----------------
    void drawEmblems(Canvas c, int neon) {
        overlay(c, 232);
        text(c, "📿 EMBLEMAS · " + equipped.size() + "/" + EcoData.MAX_EQUIP + " equipados", vw / 2, 26, 17, neon);
        text(c, restMode ? "Toca para poner o quitar" : "Solo se pueden cambiar descansando en un fardo 🌾", vw / 2, 42, 10, restMode ? Color.rgb(160, 255, 160) : Color.rgb(255, 200, 120));
        List<EcoData.Emblem> list = new ArrayList<>();
        for (EcoData.Emblem e : EcoData.EMBLEMS) if (owned.contains(e.id)) list.add(e);
        if (list.isEmpty()) {
            text(c, "Aún no tienes emblemas. El Sapo Mercader vende algunos y otros se esconden por Lanaria.", vw / 2, 130, 12, Color.LTGRAY);
        }
        int per = 10, pages = Math.max(1, (list.size() + per - 1) / per);
        emblemPage = Math.min(emblemPage, pages - 1);
        float colW = Math.min(300, (vw - 40) / 2);
        for (int i = 0; i < per; i++) {
            int idx = emblemPage * per + i;
            if (idx >= list.size()) break;
            EcoData.Emblem em = list.get(idx);
            int col = i % 2, row = i / 2;
            RectF r = new RectF(vw / 2 - colW - 4 + col * (colW + 8), 52 + row * 50, vw / 2 - 4 + col * (colW + 8), 98 + row * 50);
            boolean on = equipped.contains(em.id);
            box(c, r, on ? (em.vamp ? Color.rgb(230, 40, 70) : neon) : Color.DKGRAY, 215);
            textLeft(c, (on ? "◉ " : "○ ") + em.name, r.left + 8, r.top + 18, 12, em.vamp ? Color.rgb(255, 150, 160) : Color.WHITE);
            txt.setTextAlign(Paint.Align.LEFT);
            wrap(c, em.desc, r.left + 8, r.top + 33, r.width() - 14, 9, Color.LTGRAY, false);
            if (restMode && tapIn(r)) {
                if (on) equipped.remove(em.id);
                else if (equipped.size() < EcoData.MAX_EQUIP) equipped.add(em.id);
                else say("Solo puedes llevar " + EcoData.MAX_EQUIP + " emblemas");
                boolean wasSet = vampSetOn();
                recalc();
                hp = Math.min(hp, maxHp());
                chip.sfx(Chip.SFX_COIN);
                if (em.vamp && vampSetOn() && !on) { chip.sfx(Chip.SFX_DOOR); say(L.t(EcoData.VAMP_SET_DONE[1])); }
                if (wasSet && !vampSetOn()) say("El frío se va de tu lana...");
                if (!on && symSetOn() && java.util.Arrays.asList(EcoData.SYM_SET).contains(em.id)) {
                    chip.sfx(Chip.SFX_DOOR);
                    dialog("", null, EcoData.SYM_SET_DONE, () -> { mode = M_AMULET; showPad(false); });
                }
            }
        }
        if (pages > 1) {
            if (emblemPage > 0 && menuButton(c, new RectF(16, vh - 32, 116, vh - 4), "◀", neon)) emblemPage--;
            if (emblemPage < pages - 1 && menuButton(c, new RectF(vw - 116, vh - 32, vw - 16, vh - 4), "▶", neon)) emblemPage++;
            text(c, (emblemPage + 1) + "/" + pages, vw / 2 + 110, vh - 12, 11, Color.GRAY);
        }
        if (menuButton(c, closeRect(), "VOLVER", neon)) {
            if (bossMode) { saveBossEquip(); mode = M_BOSSRUSH; }
            else if (restMode) { mode = M_REST; saveGame(true); }
            else mode = M_PAUSE;
        }
    }

    // ---------------- bestiario ----------------
    static class BeastEntry {
        String id, name, desc, tip;
        int zone;
        boolean boss;
    }

    List<BeastEntry> beastList() {
        List<BeastEntry> l = new ArrayList<>();
        for (EcoData.Kind k : EcoData.KINDS) {
            BeastEntry b = new BeastEntry();
            b.id = k.id; b.name = k.name; b.desc = k.desc; b.tip = k.tip; b.zone = k.zone;
            l.add(b);
        }
        for (EcoData.Boss d : EcoData.BOSSES) {
            BeastEntry b = new BeastEntry();
            b.id = d.id; b.name = d.name; b.desc = d.desc; b.tip = d.tip; b.zone = d.zone; b.boss = true;
            l.add(b);
        }
        return l;
    }

    boolean beastKnown(BeastEntry b) {
        return kills.containsKey(b.id) || (!b.boss && flag("sabio_" + b.zone)) || (b.boss && defeated(b.id));
    }

    void drawBeast(Canvas c, int neon) {
        overlay(c, 232);
        text(c, "📖 BESTIARIO DE SABELOTODO", vw / 2, 24, 17, neon);
        List<BeastEntry> list = beastList();
        int per = 9, pages = (list.size() + per - 1) / per;
        beastPage = Math.max(0, Math.min(beastPage, pages - 1));
        float lx = vw / 2 - 300;
        for (int i = 0; i < per; i++) {
            int idx = beastPage * per + i;
            if (idx >= list.size()) break;
            BeastEntry b = list.get(idx);
            RectF r = new RectF(lx, 36 + i * 30, lx + 210, 62 + i * 30);
            boolean known = beastKnown(b);
            int k = kills.containsKey(b.id) ? kills.get(b.id) : 0;
            box(c, r, idx == beastSel ? neon : Color.DKGRAY, 200);
            textLeft(c, known ? (b.boss ? "💀 " : "") + b.name : "???", r.left + 8, r.centerY() + 5, 11, Color.WHITE);
            textLeft(c, "×" + k, r.right - 36, r.centerY() + 5, 10, Color.GRAY);
            if (tapIn(r)) beastSel = idx;
        }
        if (beastSel >= list.size()) beastSel = 0;
        BeastEntry b = list.get(beastSel);
        RectF d = new RectF(lx + 225, 36, vw / 2 + 300, 36 + per * 30 - 4);
        box(c, d, neon, 200);
        boolean known = beastKnown(b);
        int k = kills.containsKey(b.id) ? kills.get(b.id) : 0;
        textLeft(c, known ? b.name : "???", d.left + 14, d.top + 26, 17, neon);
        textLeft(c, L.t(EcoData.ZONES[b.zone].name) + (b.boss ? " · " + L.t("JEFE") : ""), d.left + 14, d.top + 44, 11, Color.GRAY);
        float y = wrap(c, known ? b.desc : "Aún no sabes nada de este ser. Habla con Sabelotodo al entrar en su zona.",
                d.left + 14, d.top + 68, d.width() - 28, 12, Color.WHITE, false);
        boolean secret = b.boss ? k > 0 || defeated(b.id) : k >= 10;
        wrap(c, secret ? b.tip : (b.boss ? "Derrótalo para descubrir su secreto." : "Derrota " + Math.max(0, 10 - k) + " más para descubrir su secreto."),
                d.left + 14, y + 8, d.width() - 28, 12, secret ? Color.rgb(255, 220, 120) : Color.GRAY, false);
        if (beastPage > 0 && menuButton(c, new RectF(16, vh - 32, 116, vh - 4), "◀", neon)) beastPage--;
        if (beastPage < pages - 1 && menuButton(c, new RectF(vw - 116, vh - 32, vw - 16, vh - 4), "▶", neon)) beastPage++;
        text(c, (beastPage + 1) + "/" + pages, vw / 2 + 110, vh - 12, 11, Color.GRAY);
        if (menuButton(c, closeRect(), "VOLVER", neon)) mode = M_PAUSE;
    }

    // ---------------- tiendas ----------------
    void drawShop(Canvas c, int neon) {
        overlay(c, 218);
        GameKit.draw(c, sSapo, vw / 2 - 270, 14, 44, 44);
        text(c, "🐸 SAPO MERCADER", vw / 2, 34, 17, neon);
        text(c, "Tienes 🔔 " + bells, vw / 2, 52, 12, Color.WHITE);
        String[] items = EcoData.SHOPS[Math.min(shopId, EcoData.SHOPS.length - 1)];
        float y = 62;
        for (String id : items) {
            EcoData.Emblem em = EcoData.emblem(id);
            boolean hasIt = owned.contains(id);
            RectF r = new RectF(vw / 2 - 250, y, vw / 2 + 250, y + 36);
            box(c, r, hasIt ? Color.DKGRAY : neon, 210);
            textLeft(c, em.name, r.left + 12, r.top + 16, 13, Color.WHITE);
            textLeft(c, em.desc, r.left + 12, r.top + 30, 10, Color.LTGRAY);
            textLeft(c, hasIt ? "✓" : "🔔 " + em.price, r.right - 80, r.centerY() + 5, 13,
                    hasIt ? Color.GRAY : (bells >= em.price ? Color.rgb(255, 230, 120) : Color.rgb(255, 100, 100)));
            if (!hasIt && tapIn(r)) {
                if (bells >= em.price) {
                    bells -= em.price;
                    owned.add(id);
                    chip.sfx(Chip.SFX_LEVEL);
                    say("¡Comprado: " + L.t(em.name) + "! Equípalo descansando en un fardo.");
                } else { chip.sfx(Chip.SFX_HURT); say("Croac. No tienes suficientes cascabeles."); }
            }
            y += 40;
        }
        if (menuButton(c, closeRect(), "ADIÓS", neon)) backToPlay();
    }

    void drawPolice(Canvas c, int neon) {
        overlay(c, 218);
        GameKit.draw(c, sPolice, vw / 2 - 270, 14, 44, 44);
        text(c, "🚓 AGENTE GARDUÑA", vw / 2, 30, 17, neon);
        text(c, "Tienes 🔔 " + bells + "  ·  🗝 " + keys + "  ·  🩸 " + ckeys + "  ·  🔷 " + bkeys, vw / 2, 48, 12, Color.WHITE);
        int z = room.zone;
        String[] names = {"🗺 Mapa: " + L.t(EcoData.ZONES[z].name), "🗝 Llave de mazmorra", "🩸 Llave carmesí", "🔷 Llave azul",
                "📜 Mapa de los Secuaces"};
        String[] descs = {"Muestra todas las salas de la zona y sus secretos (?)", "Abre una puerta de mazmorra secreta. Dentro: un guardián y un gran tesoro",
                "Abre una guarida de los secuaces del Conde Vampis", "Abre la puerta azul del COLISEO DEL ECO (Cementerio de Campanas)",
                "Marca en el mapa cada puerta carmesí 🩸 y qué secuaz hay detrás"};
        int[] prices = {EcoData.mapPrice(z), EcoData.KEY_PRICE, EcoData.CRIMSON_PRICE, EcoData.BLUE_PRICE, EcoData.MINION_MAP_PRICE};
        boolean[] done = {owned.contains("mapa" + z), false, false, bkeys > 0 || flag("col_open"), owned.contains("secmap")};
        int[] cols = {neon, neon, Color.rgb(230, 40, 70), Color.rgb(60, 140, 255), Color.rgb(200, 60, 90)};
        for (int i = 0; i < names.length; i++) {
            RectF r = new RectF(vw / 2 - 250, 58 + i * 46, vw / 2 + 250, 98 + i * 46);
            box(c, r, done[i] ? Color.DKGRAY : cols[i], 210);
            textLeft(c, names[i], r.left + 12, r.top + 17, 13, Color.WHITE);
            textLeft(c, descs[i], r.left + 12, r.top + 32, 10, Color.LTGRAY);
            textLeft(c, done[i] ? "✓" : "🔔 " + prices[i], r.right - 80, r.centerY() + 5, 13, done[i] ? Color.GRAY : (bells >= prices[i] ? Color.rgb(255, 230, 120) : Color.rgb(255, 100, 100)));
            if (!done[i] && tapIn(r)) {
                if (bells < prices[i]) { chip.sfx(Chip.SFX_HURT); say("Sin cascabeles no hay trato, ovejita."); break; }
                bells -= prices[i];
                chip.sfx(Chip.SFX_LEVEL);
                switch (i) {
                    case 0: owned.add("mapa" + z); say("Mapa comprado. Ábrelo con 🗺"); break;
                    case 1: keys++; say("🗝 Una llave de mazmorra. No le digas a nadie dónde la conseguiste."); break;
                    case 2: ckeys++; say("🩸 Llave carmesí. Yo no te he visto. " + crimsonHint()); break;
                    case 3: bkeys++; say("🔷 La llave azul. El Coliseo está en el refugio del Cementerio de Campanas. Suerte... la vas a necesitar."); break;
                    default: owned.add("secmap"); say("📜 Mapa de los Secuaces. Míralo en 🗺: cada 🩸 dice quién te espera."); break;
                }
                saveGame(false);
            }
        }
        wrap(c, "\"Las puertas de mazmorra brillan en dorado; las guaridas del Conde, en rojo; el Coliseo, en azul.\"", vw / 2, vh - 46, vw * 0.7f, 10, Color.GRAY, true);
        if (menuButton(c, closeRect(), "ADIÓS", neon)) backToPlay();
    }

    /** Quién espera detrás de la puerta carmesí que sale de esta sala en la dirección d (o null). */
    String minionBehind(EcoWorld.Room r, int d) {
        if (r.exits[d] != 'X') return null;
        EcoWorld.Room n = EcoWorld.at(r.gx + EcoWorld.DIRS[d][0], r.gy + EcoWorld.DIRS[d][1]);
        if (n == null) return null;
        switch (n.lair) {
            case 'h': return "Harold";
            case 'a': return "Aloii";
            case 's': return "Sangre Joven";
            case 'f': return "Planta Carnívora";
            case 'x': return "Conde Vampis";
            default: return null;
        }
    }

    /** Al comprar una llave carmesí, la policía chiva dónde hay una puerta que aún no has abierto. */
    String crimsonHint() {
        for (EcoWorld.Room r : EcoWorld.ROOMS)
            for (int d = 0; d < 4; d++)
                if (r.exits[d] == 'X' && !flag("door_" + r.key() + "_" + d)) {
                    String who = minionBehind(r, d);
                    return "Dicen que hay una puerta carmesí en " + L.t(EcoData.ZONES[r.zone].name) + (who != null ? " (" + who + ")" : "") + ".";
                }
        return "";
    }

    void drawForge(Canvas c, int neon) {
        overlay(c, 218);
        GameKit.draw(c, sHerrera, vw / 2 - 260, 20, 48, 48);
        text(c, "🔨 HERRERA TOPO", vw / 2, 42, 18, neon);
        text(c, "Tienes 🔔 " + bells + "  ·  💎 " + ore + " mineral", vw / 2, 62, 13, Color.WHITE);
        text(c, "Cencerro nivel " + cLvl + "/" + EcoData.MAX_CLVL + " · daño " + Math.round(waveDmg()) + (branch > 0 ? " · " + L.t(EcoWorld.BRANCH_NAMES[branch]) : ""), vw / 2, 90, 15, Color.rgb(255, 230, 150));
        if (cLvl >= EcoData.MAX_CLVL) {
            text(c, "¡Tu cencerro ya suena al máximo!", vw / 2, 140, 15, Color.WHITE);
        } else {
            int needB = EcoData.FORGE_BELLS[cLvl], needO = EcoData.FORGE_ORE[cLvl];
            boolean can = bells >= needB && ore >= needO;
            text(c, "Para nivel " + (cLvl + 1) + ": 🔔 " + needB + (needO > 0 ? " + 💎 " + needO : ""), vw / 2, 118, 14, can ? Color.WHITE : Color.rgb(255, 120, 120));
            if (cLvl == 2) {
                text(c, "Al nivel 3 eliges una especialidad:", vw / 2, 142, 12, Color.LTGRAY);
                for (int i = 1; i <= 3; i++) {
                    RectF r = new RectF(vw / 2 - 300 + (i - 1) * 202, 154, vw / 2 - 104 + (i - 1) * 202, 214);
                    box(c, r, can ? neon : Color.DKGRAY, 210);
                    text(c, EcoWorld.BRANCH_NAMES[i], r.centerX(), r.top + 24, 14, Color.WHITE);
                    wrap(c, EcoWorld.BRANCH_DESC[i], r.centerX(), r.top + 42, r.width() - 12, 10, Color.LTGRAY, true);
                    if (can && tapIn(r)) { branch = i; forgeUp(needB, needO); }
                }
            } else {
                RectF r = new RectF(vw / 2 - 110, 140, vw / 2 + 110, 184);
                if (menuButton(c, r, "🔨 MEJORAR", can ? neon : Color.DKGRAY) && can) forgeUp(needB, needO);
            }
        }
        wrap(c, "Cada jefe deja un mineral de eco 💎, y hay más escondidos en lo alto de las salas.", vw / 2, vh - 60, vw * 0.7f, 11, Color.GRAY, true);
        if (menuButton(c, closeRect(), "ADIÓS", neon)) backToPlay();
    }

    void forgeUp(int needB, int needO) {
        bells -= needB;
        ore -= needO;
        cLvl++;
        chip.sfx(Chip.SFX_LEVEL);
        say("¡Cencerro nivel " + cLvl + "!");
        saveGame(false);
    }

    // =====================================================================
    // MAPA (estilo Hollow Knight): cada sala con su forma, coloreada por zona
    // =====================================================================
    void openMap() {
        mode = M_MAP;
        showPad(false);
        mapZoom = 1;
        mapPanX = mapPanY = 0;
    }

    boolean zoneMap(int z) { return owned.contains("mapa" + z); }

    boolean roomShown(EcoWorld.Room r) {
        if (visited.contains(r.key())) return true;
        if (r.lair == 'x') return flag("vamp4") && zoneMap(r.zone);
        if (r.hidden) return false;
        return zoneMap(r.zone);
    }

    Bitmap miniMap(EcoWorld.Room r) {
        Bitmap b = miniMaps.get(r.key());
        if (b != null) return b;
        b = Bitmap.createBitmap(EcoWorld.W, EcoWorld.H, Bitmap.Config.ARGB_8888);
        int col = EcoData.ZONES[r.zone].map;
        if (r.dungeon > 0) col = Color.rgb(200, 170, 90);
        if (r.lair != 0 && r.lair != 'x') col = Color.rgb(220, 60, 80);
        int fill = Color.argb(150, Color.red(col), Color.green(col), Color.blue(col));
        for (int y = 0; y < EcoWorld.H; y++)
            for (int x = 0; x < EcoWorld.W; x++) {
                char ch = r.t[y][x];
                boolean wall = ch == '#';
                if (wall) {
                    boolean edge = false;
                    for (int dy = -1; dy <= 1 && !edge; dy++)
                        for (int dx = -1; dx <= 1; dx++) {
                            int nx = x + dx, ny = y + dy;
                            if (nx >= 0 && ny >= 0 && nx < EcoWorld.W && ny < EcoWorld.H && r.t[ny][nx] != '#') { edge = true; break; }
                        }
                    b.setPixel(x, y, edge ? col : Color.TRANSPARENT);
                } else b.setPixel(x, y, fill);
            }
        miniMaps.put(r.key(), b);
        return b;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (mode == M_MAP) {
            int a = e.getActionMasked();
            if (e.getPointerCount() >= 2) {
                float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                if (pinchD > 0 && a == MotionEvent.ACTION_MOVE) mapZoom = GameKit.clamp(mapZoom * d / pinchD, 1, 5);
                pinchD = d;
                mapDrag = true;
            } else {
                pinchD = 0;
                float x = e.getX() / scale, y = e.getY() / scale;
                if (a == MotionEvent.ACTION_DOWN) { lastTouchX = x; lastTouchY = y; mapDrag = false; }
                else if (a == MotionEvent.ACTION_MOVE) {
                    if (Math.abs(x - lastTouchX) + Math.abs(y - lastTouchY) > 3) mapDrag = true;
                    mapPanX += x - lastTouchX; mapPanY += y - lastTouchY;
                    lastTouchX = x; lastTouchY = y;
                }
            }
            if (a == MotionEvent.ACTION_UP && mapDrag) { mapDrag = false; return true; }   // arrastrar no cuenta como toque
            if (mapDrag) return true;
        }
        return super.onTouchEvent(e);
    }

    void drawMap(Canvas c, int neon) {
        overlay(c, 240);
        // límites del mundo
        int minX = 99, maxX = -99, minY = 99, maxY = -99;
        for (EcoWorld.Room r : EcoWorld.ROOMS) { minX = Math.min(minX, r.gx); maxX = Math.max(maxX, r.gx); minY = Math.min(minY, r.gy); maxY = Math.max(maxY, r.gy); }
        float cols = maxX - minX + 1, rows = maxY - minY + 1;
        float cw0 = Math.min((vw - 20) / cols, (vh - 60) / rows * 1.875f);
        float cw = cw0 * mapZoom, ch = cw / 1.875f;
        float gx0 = vw / 2 - cols * cw / 2 + mapPanX, gy0 = 26 + (vh - 60) / 2 - rows * ch / 2 + mapPanY;
        if (mapZoom > 1 && room != null && mapPanX == 0 && mapPanY == 0) {   // centra en Bee al ampliar
            gx0 = vw / 2 - (room.gx - minX + 0.5f) * cw;
            gy0 = vh / 2 - (room.gy - minY + 0.5f) * ch;
            mapPanX = gx0 - (vw / 2 - cols * cw / 2);
            mapPanY = gy0 - (26 + (vh - 60) / 2 - rows * ch / 2);
        }
        boolean blink = ((int) (playTime * 3)) % 2 == 0;
        boolean secrets = M[EcoData.M_COMPASS] > 0;
        Paint fp = new Paint();
        fp.setFilterBitmap(false);
        Map<Integer, float[]> zoneCenters = new HashMap<>();
        boolean secMap = owned.contains("secmap");
        for (EcoWorld.Room r : EcoWorld.ROOMS) {
            String minion = null;
            if (secMap) for (int d = 0; d < 4 && minion == null; d++) minion = minionBehind(r, d);
            if (!roomShown(r) && minion == null) continue;
            float x = gx0 + (r.gx - minX) * cw, y = gy0 + (r.gy - minY) * ch;
            if (x > vw || y > vh || x + cw < 0 || y + ch < 0) continue;
            boolean vis = visited.contains(r.key());
            fp.setAlpha(vis ? 255 : 110);
            GameKit.draw(c, miniMap(r), x + cw * 0.04f, y + ch * 0.06f, cw * 0.92f, ch * 0.88f, fp);
            // pasillos
            p.setColor(EcoData.ZONES[r.zone].map);
            if (r.exits[1] != '#') c.drawRect(x + cw * 0.96f, y + ch * 0.8f, x + cw * 1.04f, y + ch * 0.88f, p);
            if (r.exits[3] != '#') c.drawRect(x + cw * 0.45f, y + ch * 0.94f, x + cw * 0.55f, y + ch * 1.06f, p);
            float[] zc = zoneCenters.get(r.zone);
            if (zc == null) { zc = new float[3]; zoneCenters.put(r.zone, zc); }
            if (r.dungeon == 0 && r.lair == 0) { zc[0] += x + cw / 2; zc[1] += y + ch / 2; zc[2]++; }
            // iconos
            String icon = "";
            if (r.has('S')) icon += "🌾";
            String bid = r.bossId();
            if (bid != null && !defeated(bid)) icon += "💀";
            if ((zoneMap(r.zone) || secrets) && hasLoot(r)) icon += "?";
            if (r.has('M') || r.has('P') || r.has('H')) icon += "🏪";
            for (int d = 0; d < 4; d++) if ((r.exits[d] == 'K' || r.exits[d] == 'X')) icon += r.exits[d] == 'K' ? "🗝" : "🩸";
            if (dropRoom != null && dropRoom.equals(r.key())) icon += "🧶";
            if (!icon.isEmpty()) text(c, icon, x + cw / 2, y + ch / 2 + Math.min(10, cw * 0.25f) / 2.5f, Math.min(13, Math.max(6, cw * 0.26f)), Color.WHITE);
            if (r.has('U')) text(c, "🔷", x + cw * 0.8f, y + ch * 0.3f, Math.min(12, Math.max(6, cw * 0.24f)), Color.WHITE);
            if (minion != null && mapZoom >= 1.4f) text(c, minion, x + cw / 2, y + ch + Math.min(11, cw * 0.22f), Math.min(11, Math.max(6, cw * 0.2f)), Color.rgb(255, 110, 130));
            if (room == r && blink) {
                p.setColor(Color.rgb(255, 255, 120));
                c.drawCircle(x + (pl.x / EcoWorld.W) * cw, y + (pl.y / EcoWorld.H) * ch, Math.max(3, cw * 0.08f), p);
            }
        }
        // nombres de las zonas
        for (Map.Entry<Integer, float[]> e : zoneCenters.entrySet()) {
            float[] zc = e.getValue();
            if (zc[2] < 1) continue;
            EcoData.Zone z = EcoData.ZONES[e.getKey()];
            text(c, z.name.toUpperCase(), zc[0] / zc[2], zc[1] / zc[2] - 4, Math.min(14, 7 + mapZoom * 2), Neon.withAlpha(z.map, 230));
        }
        text(c, "MAPA DE LANARIA", vw / 2, 18, 15, neon);
        text(c, "🌾 fardo  💀 jefe  🏪 tienda  ? secreto  🗝 mazmorra  🩸 guarida  🔷 coliseo  🧶 cascabeles · arrastra y pellizca", vw / 2, vh - 40, 9, Color.LTGRAY);
        if (menuButton(c, new RectF(16, vh - 32, 76, vh - 4), "－", neon)) { mapZoom = Math.max(1, mapZoom / 1.5f); mapPanX = mapPanY = 0; }
        if (menuButton(c, new RectF(84, vh - 32, 144, vh - 4), "＋", neon)) { mapZoom = Math.min(5, mapZoom * 1.5f); mapPanX = mapPanY = 0; }
        if (menuButton(c, new RectF(152, vh - 32, 212, vh - 4), "📍", neon)) { mapZoom = Math.max(2.5f, mapZoom); mapPanX = mapPanY = 0; }
        if (menuButton(c, closeRect(), "CERRAR", neon)) backToPlay();
    }

    boolean hasLoot(EcoWorld.Room r) {
        for (EcoWorld.Spawn s : r.spawns) {
            String f = "it_" + r.key() + "_" + s.idx;
            if ((s.ch == 'c' || s.ch == 'o' || s.ch == 'k') && !flag(f) && !s.data.equals("big")) return true;
            if (s.ch == 'w' && !has(EcoData.AB_TROMP)) return true;
            if (s.ch == 'j' && !has(EcoData.AB_DJ)) return true;
            if (s.ch == 'A' && !has(s.data)) return true;
            if (s.ch == 'E' && !owned.contains(s.data)) return true;
        }
        return false;
    }

    // =====================================================================
    // FINALES
    // =====================================================================
    /** Tras vencer a LUMENIA: con el Set de la Sinfonía puesto, el set quiere quedarse los ecos... */
    void finalChoice() {
        if (symSetOn()) {
            chip.play(Songs.ECO_FINAL);
            dialog("", null, EcoData.SYM_CHOICE, () -> confirm("¿Devuelves los ecos al mundo?",
                    () -> startEnding(lambs >= 5 ? 0 : 1), () -> startEnding(2)));
        } else startEnding(lambs >= 5 ? 0 : 1);
    }

    String[] endLines() { return endKind == 0 ? EcoData.FINAL_CANON : endKind == 1 ? EcoData.FINAL_SACRIFICIO : EcoData.FINAL_ADICTO; }

    void startEnding(int kind) {
        endKind = kind;
        mode = M_ENDING;
        showPad(false);
        endIdx = 0; endT = 0;
        flags.add("ending1");
        flags.add("ending_" + (kind == 0 ? "canon" : kind == 1 ? "sacrificio" : "adicto"));
        saveGame(false);
        chip.play(kind == 2 ? Songs.VAMP_FINAL : Songs.ECO_FINAL);
    }

    void startVampEnding() {
        mode = M_VAMPEND;
        showPad(false);
        endIdx = 0; endT = 0;
        fightActive = false;
        chip.play(Songs.VAMP_FINAL);
    }

    void advanceEnding() {
        endIdx++;
        endT = 0;
        if (mode == M_ENDING && endIdx >= endLines().length) {
            unlock(endKind == 0 ? "rebano" : endKind == 1 ? "temerario" : "adicto");
            finishGame();
            return;
        }
        if (mode == M_VAMPEND && endIdx >= EcoData.FINAL_VAMP.length + EcoData.FINAL_VAMP_2.length) {
            flags.add("ending_vamp");
            unlock("sangre");
            finishGame();
        }
    }

    void finishGame() {
        saveGame(false);
        mode = M_TITLE;
        room = null;
        chip.play(Songs.PUEBLO);
    }

    void drawEnding(Canvas c, int neon) {
        String[] lines = endLines();
        float gy = vh * 0.72f;
        if (endKind == 2) drawEndAddict(c, gy);
        else if (endKind == 1 && endIdx >= 2) drawEndStatue(c, gy);
        else {
            p.setShader(new LinearGradient(0, 0, 0, vh, Color.rgb(250, 190, 120), Color.rgb(120, 170, 230), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, vw, vh, p);
            p.setShader(null);
            p.setColor(Color.rgb(90, 170, 80));
            c.drawRect(0, gy, vw, vh, p);
            if (endKind == 0) {
                // el rebaño unido: Bee, los 5 corderitos y todo el pueblo celebran (con confeti)
                Bitmap[] folk = {sTopo, sSapo, sLamb, sLamb, sBee, sLamb, sLamb, sLamb, sHerrera, sSabio, sPolice};
                for (int i = 0; i < folk.length; i++) {
                    float x = vw * 0.06f + i * vw * 0.083f, hop = (float) Math.abs(Math.sin(playTime * 4 + i)) * 10;
                    boolean big = folk[i] == sBee;
                    GameKit.draw(c, folk[i], x, gy - (big ? 36 : 28) - hop, big ? 36 : 28, big ? 36 : (folk[i] == sLamb ? 22 : 28));
                    if (folk[i] == sLamb && ((int) (playTime * 3 + i)) % 2 == 0) text(c, "🔔", x + 14, gy - 40 - hop, 10, Color.WHITE);
                }
                for (int i = 0; i < 40; i++) {
                    p.setColor(Color.HSVToColor(new float[]{(i * 47) % 360, 0.7f, 1f}));
                    float x = (i * 97 + playTime * 30 * (1 + i % 3)) % vw, y = (i * 53 + playTime * 60 * (1 + i % 2)) % gy;
                    c.drawRect(x, y, x + 4, y + 6, p);
                }
            } else {
                // sacrificio: Bee da su último repique sola
                GameKit.draw(c, sBee, vw / 2 - 18, gy - 36, 36, 36);
            }
        }
        // el eco definitivo: Bee hace sonar su cencerro y el sonido vuelve al mundo (o se lo queda)
        if (endIdx == 0 && endT < 4f) {
            for (int i = 0; i < 6; i++) {
                float r = endKind == 2 ? 520 - (endT * 140 + i * 60) % 520 : (endT * 140 + i * 60) % 520;
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(5);
                int a = (int) Math.max(0, 230 - r * 0.44f);
                p.setColor(endKind == 2 ? Color.argb(a, 120, 90 + i * 20, 255) : Color.argb(a, 255, 240 - i * 20, 150 + i * 15));
                c.drawCircle(vw / 2, gy - 20, r, p);
                p.setStyle(Paint.Style.FILL);
            }
            text(c, "🔔", vw / 2, gy - 60, 36, Color.WHITE);
            playTime += 0.016f;
            return;
        }
        p.setColor(Color.argb(170, 0, 0, 0));
        c.drawRoundRect(vw / 2 - 260, 30, vw / 2 + 260, 130, 12, 12, p);
        if (endIdx < lines.length) wrap(c, lines[endIdx], vw / 2, 66, 480, 15, endIdx == lines.length - 1 ? Color.rgb(255, 225, 140) : Color.WHITE, true);
        text(c, "toca para continuar ▸", vw / 2, vh - 12, 11, Color.WHITE);
        playTime += 0.016f;
    }

    /** Final del sacrificio: la estatua de la gran oveja del cencerro, rodeada de animales con rosas. */
    void drawEndStatue(Canvas c, float gy) {
        p.setShader(new LinearGradient(0, 0, 0, vh, Color.rgb(255, 200, 170), Color.rgb(170, 140, 200), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, vw, vh, p);
        p.setShader(null);
        p.setColor(Color.rgb(110, 160, 90));
        c.drawRect(0, gy, vw, vh, p);
        // pedestal
        p.setColor(Color.rgb(150, 150, 160));
        c.drawRect(vw / 2 - 50, gy - 40, vw / 2 + 50, gy, p);
        p.setColor(Color.rgb(120, 120, 130));
        c.drawRect(vw / 2 - 60, gy - 46, vw / 2 + 60, gy - 38, p);
        // la oveja de piedra (gris)
        Paint sp = new Paint();
        android.graphics.ColorMatrix cm = new android.graphics.ColorMatrix();
        cm.setSaturation(0);
        sp.setColorFilter(new android.graphics.ColorMatrixColorFilter(cm));
        GameKit.draw(c, sBee, vw / 2 - 48, gy - 142, 96, 96, sp);
        text(c, "🔔", vw / 2 + 24, gy - 64, 22, Color.rgb(230, 200, 90));
        textLeft(c, "BEE · LA PASTORA DE LOS ECOS", vw / 2 - 46, gy - 26, 7, Color.rgb(60, 60, 70));
        // animales con rosas
        Bitmap[] folk = {sTopo, sSapo, sLamb, sHerrera, sSabio, sPolice, sMapache, sLamb};
        for (int i = 0; i < folk.length; i++) {
            boolean left = i < 4;
            float x = left ? vw / 2 - 100 - i * 46 : vw / 2 + 72 + (i - 4) * 46;
            float hop = (float) Math.abs(Math.sin(playTime * 3 + i)) * 6;
            GameKit.draw(c, folk[i], x, gy - 30 - hop, 30, 30);
            text(c, "🌹", x + 15, gy - 36 - hop, 12, Color.WHITE);
        }
        for (int i = 0; i < 9; i++) text(c, "🌹", vw / 2 - 48 + i * 12, gy + 8 + (i % 2) * 6, 10, Color.WHITE);
    }

    /** Final secreto n.º 2: Bee se queda los ecos y se vuelve el nuevo jefe del silencio. */
    void drawEndAddict(Canvas c, float gy) {
        if (endIdx >= 3) {
            // aldea triste y en silencio... y nace una ovejita con un cencerro
            c.drawColor(Color.rgb(40, 42, 50));
            p.setColor(Color.rgb(60, 62, 70));
            c.drawRect(0, gy, vw, vh, p);
            for (int i = 0; i < 5; i++) {
                float x = 30 + i * vw / 5f, h = 50 + (i % 2) * 20;
                p.setColor(Color.rgb(28, 30, 36));
                c.drawRect(x, gy - h, x + 70, gy, p);
                p.setColor(Color.rgb(50, 50, 60));
                c.drawRect(x + 26, gy - 26, x + 44, gy, p);
            }
            GameKit.draw(c, sLamb, vw / 2 - 14, gy - 22, 28, 22);
            if (((int) (playTime * 2)) % 2 == 0) text(c, "🔔", vw / 2 + 16, gy - 24, 12, Color.rgb(255, 230, 140));
            p.setColor(Color.argb((int) (80 + 60 * Math.sin(playTime * 2)), 255, 240, 180));
            c.drawCircle(vw / 2, gy - 12, 26, p);
            return;
        }
        c.drawColor(Color.rgb(8, 6, 16));
        float grow = Math.min(1, (endIdx + endT / 3f) / 2.5f);
        float sz = 40 + grow * 110;
        Paint dp = new Paint();
        dp.setColorFilter(new android.graphics.PorterDuffColorFilter(Color.argb(200, 20, 10, 40), android.graphics.PorterDuff.Mode.SRC_ATOP));
        GameKit.draw(c, sBee, vw / 2 - sz / 2, gy - sz, sz, sz, dp);
        p.setColor(Color.rgb(255, 60, 90));
        c.drawCircle(vw / 2 - sz * 0.12f, gy - sz * 0.62f, 2 + grow * 3, p);
        for (int i = 0; i < 20; i++) {          // los 20 ecos giran a su alrededor
            double a = playTime * 1.6 + i * Math.PI * 2 / 20;
            float r = sz * 0.75f + (float) Math.sin(playTime * 3 + i) * 8;
            p.setColor(Color.HSVToColor(new float[]{200 + i * 6, 0.6f, 1f}));
            c.drawCircle(vw / 2 + (float) Math.cos(a) * r, gy - sz / 2 + (float) Math.sin(a) * r * 0.6f, 4, p);
        }
    }

    /** Primera parte del final secreto: Bee se detiene, todo se vuelve rojo y le salen alas. */
    void drawVampTurn(Canvas c, int neon) {
        float t = endT + endIdx * 3;
        int red = (int) Math.min(170, 30 + t * 18);
        p.setColor(Color.argb(red, 160, 0, 10));
        c.drawRect(0, 0, vw, vh, p);
        // visiones
        if (((int) (playTime * 7)) % 5 == 0) {
            EcoData.Boss[] vs = {EcoData.boss("V1"), EcoData.boss("V2"), EcoData.boss("V4"), EcoData.boss("V5")};
            EcoData.Boss vb = vs[(int) (playTime * 2) % vs.length];
            Paint gp = new Paint();
            gp.setAlpha(110);
            GameKit.draw(c, EcoArt.boss(vb, false)[0], vw / 2 - 90 + (float) Math.sin(playTime) * 60, vh / 2 - 120, 120, 200, gp);
        }
        // alas
        if (endIdx >= 2) {
            float bx = ox + (pl.x + pl.w / 2) * T, by = oy + pl.y * T;
            float s = Math.min(1, endT / 1.5f + (endIdx > 2 ? 1 : 0));
            GameKit.draw(c, sWings, bx - 40 * s, by - 24 * s, 80 * s, 40 * s);
        }
        p.setColor(Color.argb(190, 0, 0, 0));
        c.drawRoundRect(vw / 2 - 260, vh - 100, vw / 2 + 260, vh - 20, 12, 12, p);
        if (endIdx < EcoData.FINAL_VAMP.length) wrap(c, EcoData.FINAL_VAMP[endIdx], vw / 2, vh - 70, 480, 15, Color.rgb(255, 200, 200), true);
        playTime += 0.016f;
    }

    /** Segunda parte: la aldea atacada mientras todos huyen. */
    void drawVampVillage(Canvas c, int neon) {
        float t = playTime;
        p.setShader(new LinearGradient(0, 0, 0, vh, Color.rgb(40, 0, 8), Color.rgb(120, 20, 10), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, vw, vh, p);
        p.setShader(null);
        // luna roja
        p.setColor(Color.rgb(230, 60, 60));
        c.drawCircle(vw * 0.8f, 60, 30, p);
        // casas en llamas
        for (int i = 0; i < 6; i++) {
            float x = i * vw / 6f + 10, w = vw / 8f, h = 60 + (i % 3) * 18;
            p.setColor(Color.rgb(30, 10, 10));
            c.drawRect(x, vh * 0.72f - h, x + w, vh * 0.72f, p);
            p.setColor(Color.rgb(255, 150 + (int) (60 * Math.sin(t * 9 + i)), 40));
            c.drawRect(x + w * 0.3f, vh * 0.72f - h * 0.6f, x + w * 0.45f, vh * 0.72f - h * 0.4f, p);
            for (int k = 0; k < 4; k++) {
                p.setColor(Color.argb(180, 255, 120 + rnd.nextInt(100), 20));
                c.drawCircle(x + w * (0.2f + 0.2f * k) + (float) Math.sin(t * 8 + k) * 4, vh * 0.72f - h - 6 - rnd.nextInt(14), 5 + rnd.nextInt(5), p);
            }
        }
        p.setColor(Color.rgb(20, 8, 8));
        c.drawRect(0, vh * 0.72f, vw, vh, p);
        // vecinos que huyen
        Bitmap[] folk = {sTopo, sSapo, sHerrera, sSabio, sPolice, sLamb, sMapache};
        for (int i = 0; i < folk.length; i++) {
            float x = vw - ((t * (60 + i * 9) + i * 90) % (vw + 80));
            GameKit.draw(c, folk[i], x, vh * 0.72f - 30 + (float) Math.abs(Math.sin(t * 10 + i)) * -6, 30, 30);
        }
        // Sangre SÍ: siluetas y salpicaduras rojas · Sangre NO: animalitos tiernos gritando
        if (blood()) {
            Random br = new Random(7);
            int n = Math.min(60, (int) (endT * 10) + (endIdx - EcoData.FINAL_VAMP.length) * 15);
            for (int k = 0; k < n; k++) {
                p.setColor(Color.argb(200, 150 + br.nextInt(60), 0, 10));
                float sx = br.nextFloat() * vw, sy = br.nextFloat() * vh * 0.9f, r = 3 + br.nextFloat() * 9;
                c.drawCircle(sx, sy, r, p);
                c.drawCircle(sx + r, sy + r * 0.6f, r * 0.45f, p);
            }
        } else {
            for (int k = 0; k < folk.length; k++)
                if (((int) (t * 4 + k)) % 3 == 0) {
                    float x = vw - ((t * (60 + k * 9) + k * 90) % (vw + 80));
                    text(c, k % 2 == 0 ? "¡¡AAAH!!" : "¡Socorro!", x + 15, vh * 0.72f - 40, 10, Color.WHITE);
                }
        }
        // Bee vampiro sobrevuela
        float bx = vw / 2 + (float) Math.sin(t * 1.3f) * vw * 0.3f, by = 110 + (float) Math.sin(t * 2.6f) * 30;
        GameKit.draw(c, sWings, bx - 46, by - 18, 92, 46);
        Paint rp = new Paint();
        rp.setColorFilter(new android.graphics.PorterDuffColorFilter(Color.argb(120, 200, 0, 30), android.graphics.PorterDuff.Mode.SRC_ATOP));
        GameKit.draw(c, sBee, bx - 18, by - 10, 36, 36, rp);
        int i = endIdx - EcoData.FINAL_VAMP.length;
        p.setColor(Color.argb(190, 0, 0, 0));
        c.drawRoundRect(vw / 2 - 270, vh - 92, vw / 2 + 270, vh - 18, 12, 12, p);
        if (i >= 0 && i < EcoData.FINAL_VAMP_2.length) wrap(c, EcoData.FINAL_VAMP_2[i], vw / 2, vh - 62, 500, 15, i >= 3 ? Color.rgb(255, 210, 120) : Color.WHITE, true);
        playTime += 0.016f;
    }

    // =====================================================================
    // Sprites
    // =====================================================================
    void buildSprites() {
        String bk = "wWkey";
        int[] bc = {0xfffff6ea, 0xffd8ccc0, 0xff1c1c22, 0xffffffff, 0xffffcc30};
        String[] bee = {
                "....wwww....",
                "..wwwwwwww..",
                ".wwWwwwwwww.",
                ".wwwwwwkkkw.",
                "wwwwwwkkkkk.",
                "wwWwwwkekkk.",
                "wwwwwwkkkk..",
                ".wwwwwwyw...",
                ".wwWwwwwww..",
                "..wwwwwwww..",
                "..k.k..k.k..",
                "..k.k..k.k.."};
        String[] beeRun = bee.clone();
        beeRun[10] = ".k..k..k..k.";
        beeRun[11] = "k....kk....k";
        String[] beeJump = bee.clone();
        beeJump[10] = "..kk....kk..";
        beeJump[11] = "............";
        sBee = GameKit.sprite(bee, bk, bc);
        sBeeRun = GameKit.sprite(beeRun, bk, bc);
        sBeeJump = GameKit.sprite(beeJump, bk, bc);
        sBeeL = GameKit.flipH(sBee);
        sBeeRunL = GameKit.flipH(sBeeRun);
        sBeeJumpL = GameKit.flipH(sBeeJump);

        sTopo = GameKit.sprite(new String[]{
                "............",
                "....bbbb....",
                "...bbbbbb...",
                "..bgbbbbgb..",
                "..bggbbggb..",
                "..bbbppbbb..",
                "..bwwwwwwb..",
                "...wwwwww...",
                "..bbwwwwbb..",
                ".bbbbbbbbbb.",
                ".pp.bbbb.pp.",
                "....pp.pp..."}, "bgpw", new int[]{0xff6a4a30, 0xffc0d0e0, 0xffffa0a0, 0xffeeeeee});
        sHerrera = GameKit.sprite(new String[]{
                "..........hh",
                "....bbbb..hh",
                "...bbbbbb.s.",
                "..bkbbbbkbs.",
                "..bbbppbbbs.",
                "..rrrrrrrrs.",
                "..rrrrrrrr..",
                "..rrrrrrrr..",
                ".bbrrrrrrbb.",
                ".bbbbbbbbbb.",
                ".pp.bbbb.pp.",
                "....pp.pp..."}, "bkprhs", new int[]{0xff6a4a30, 0xff111111, 0xffffa0a0, 0xffc03030, 0xff9090a0, 0xff8a5a30});
        sSabio = GameKit.sprite(new String[]{
                "..o......o..",
                "..oo....oo..",
                "..oooooooo..",
                ".oggwooggwo.",
                ".ogkgooggko.",
                ".oggoyyoggo.",
                "..ooooyooo..",
                "..oLLLLLLo..",
                "..oLLLLLLo..",
                "...oLLLLo...",
                "....oooo....",
                "....y..y...."}, "ogwkyL", new int[]{0xff8a6a40, 0xffd0d0d0, 0xffffffff, 0xff111111, 0xffffb030, 0xffd8c0a0});
        sMapache = GameKit.sprite(new String[]{
                "..g......g..",
                "..gg....gg..",
                "..gggggggg..",
                ".gkkwggwkkg.",
                ".gkewggwekg.",
                "..wwwkkwww..",
                "...wwwwww...",
                "..ggggggggp.",
                "..gggggggpp.",
                "..ggggggg.p.",
                "...gg..gg...",
                "...kk..kk..."}, "gkwep", new int[]{0xff8a8a90, 0xff222226, 0xffeeeeee, 0xffffffff, 0xfff0e0b0});
        sSapo = GameKit.sprite(new String[]{
                "....hhhh....",
                "...hhhhhh...",
                ".hhhhhhhhhh.",
                "..gwkggwkg..",
                ".gggggggggg.",
                ".grrrrrrrrg.",
                ".gggggggggg.",
                "..gyyyyyyg..",
                "..gyyyyyyg..",
                ".gggg..gggg.",
                "gg........gg",
                "............"}, "hgwkry", new int[]{0xff6a3a8a, 0xff40a040, 0xffffffff, 0xff111111, 0xffd04040, 0xffd0e080});
        sFantasma = GameKit.sprite(new String[]{
                "....wwww....",
                "..wwwwwwww..",
                ".wwwwwwwwww.",
                ".wwkwwwwkww.",
                ".wwkwwwwkww.",
                ".wwwwwwwwww.",
                ".wwwwkkwwww.",
                ".wwwwwwwwww.",
                ".wwwwwwwwww.",
                ".wwwwwwwwww.",
                ".ww.www.www.",
                ".w...w...w.."}, "wk", new int[]{0xb0e8f0ff, 0xff304060});
        sFardo = GameKit.sprite(new String[]{
                "............",
                "............",
                "..y..y.y..y.",
                ".yyyyyyyyyy.",
                "yyYyyyyyYyyy",
                "yyyyrrrryyyy",
                "yYyyyyyyyyYy",
                "yyyyyyyyyyyy",
                "yyyyrrrryyyy",
                "yyYyyyyyyYyy",
                ".yyyyyyyyyy.",
                "............"}, "yYr", new int[]{0xffe8c860, 0xffb89030, 0xff9a5a30});

        sBabosa = GameKit.sprite(new String[]{
                "........gg..",
                ".......gkgg.",
                "......ggggg.",
                "...gggggggg.",
                ".gggggggggg.",
                "gllllllllll."}, "gkl", new int[]{0xff60c060, 0xff102010, 0xffb0f0b0});
        sBat = GameKit.sprite(new String[]{
                "v..........v",
                "vv...vv...vv",
                "vvv.vvvv.vvv",
                "vvvvvrrvvvvv",
                ".vvvvvvvvvv.",
                "...v....v..."}, "vr", new int[]{0xff6a50a0, 0xffff5050});
        sBat2 = GameKit.sprite(new String[]{
                "............",
                ".....vv.....",
                ".vvvvrrvvvv.",
                "vvvvvvvvvvvv",
                "vv..vvvv..vv",
                "v....vv....v"}, "vr", new int[]{0xff6a50a0, 0xffff5050});
        sBatCu = GameKit.sprite(new String[]{
                "c..........c",
                "cc...cc...cc",
                "ccc.cccc.ccc",
                "cccccyycccc.",
                ".cccccccccc.",
                "...c....c..."}, "cy", new int[]{0xffd07a30, 0xffffff60});
        sBatCu2 = GameKit.sprite(new String[]{
                "............",
                ".....cc.....",
                ".cccccyycccc",
                "cccccccccccc",
                "cc..cccc..cc",
                "c....cc....c"}, "cy", new int[]{0xffd07a30, 0xffffff60});
        sBeetle = GameKit.sprite(new String[]{
                "....bbbb....",
                "..bbBBBBbb..",
                ".bBBbBBbBBbk",
                ".bBBbBBbBBkk",
                "bbbbbbbbbbbk",
                ".k.k.k.k.k.."}, "bBk", new int[]{0xff2a3a70, 0xff4a6ac0, 0xff111111});
        sMinero = GameKit.sprite(new String[]{
                "...yyyy.....",
                "..ooooooL...",
                "..bbbbbb....",
                ".bbkbbbbbb..",
                ".bbbbbbbppb.",
                ".bbbbbbbbb..",
                ".bbbbbbbbb..",
                "..pp...pp..."}, "yoLbkp", new int[]{0xffffd040, 0xffc08030, 0xffffffa0, 0xff7a5030, 0xff111111, 0xffffa0a0});
        sReyTopo = GameKit.sprite(new String[]{
                "....y.y.y.y.....",
                "....yyyyyyy.....",
                "...bbbbbbbbb....",
                "..bbbbbbbbbbb...",
                "..bkbbbbbbbkb...",
                "..bbbbbpppbbbb..",
                ".bbbbbbpppbbbbb.",
                ".bbwwbbbbbbwwbb.",
                "bbbbbbbbbbbbbbbb",
                "bbbbbbbbbbbbbbbb",
                ".bbbbbbbbbbbbbb.",
                ".ppp.bbbbbb.ppp.",
                "pppp........pppp",
                "................"}, "ybkpw", new int[]{0xffffd040, 0xff5a3a20, 0xffff3030, 0xffffa0a0, 0xffffffff});
        sVagoneta = GameKit.sprite(new String[]{
                "......gggg..........",
                ".....gggggg.........",
                ".....gkggkg.........",
                ".....gggggg.........",
                "......gggg..........",
                "cccccccccccccccccccc",
                "cCCCCCCCCCCCCCCCCCCc",
                "cCccCCCCccCCCCCCccCc",
                "cCCCCCCCCCCCCCCCCCCc",
                "cccccccccccccccccccc",
                "..kkk..........kkk..",
                ".kkkkk........kkkkk.",
                "..kkk..........kkk..",
                "...................."}, "gkcC", new int[]{0xb0b0e0ff, 0xff203050, 0xff7a4a2a, 0xffb87040});
        sGemelo = GameKit.sprite(new String[]{
                "v..............v",
                "vv....vvvv....vv",
                "vvv..vvvvvv..vvv",
                "vvvvvvrvvrvvvvvv",
                ".vvvvvvvvvvvvvv.",
                "..vvvvwvvwvvvv..",
                "....v......v....",
                "................"}, "vrw", new int[]{0xff6030a0, 0xffff3060, 0xffffffff});
        sGemelo2 = GameKit.sprite(new String[]{
                "v..............v",
                "vv....vvvv....vv",
                "vvv..vvvvvv..vvv",
                "vvvvvvrvvrvvvvvv",
                ".vvvvvvvvvvvvvv.",
                "..vvvvwvvwvvvv..",
                "....v......v....",
                "................"}, "vrw", new int[]{0xff3060a0, 0xff30ffd0, 0xffffffff});

        sChest = GameKit.sprite(new String[]{
                ".bbbbbbbb.",
                "bBBBBBBBBb",
                "bBBBBBBBBb",
                "yyyyyyyyyy",
                "bBBByyBBBb",
                "bBBBBBBBBb",
                "bbbbbbbbbb"}, "bBy", new int[]{0xff6a3a1a, 0xffa0602a, 0xffffd040});
        sOre = GameKit.sprite(new String[]{
                "...cc...",
                "..cCCc..",
                ".cCwCCc.",
                "cCCCCCCc",
                ".cCCCCc.",
                "..cCCc..",
                "...cc..."}, "cCw", new int[]{0xff2090c0, 0xff60e0ff, 0xffffffff});
        sLamb = GameKit.sprite(new String[]{
                "..wwww....",
                ".wwwwwwkk.",
                "wwwwwwkekk",
                "wwwwwwkkk.",
                ".wwwwwww..",
                "..k.k.k.k."}, "wke", new int[]{0xfffff6ea, 0xff1c1c22, 0xffffffff});
        sTromp = GameKit.sprite(new String[]{
                "........yy",
                ".......yyy",
                "yyyyyyyyyy",
                "yryyyyyyyy",
                ".......yyy",
                "........yy"}, "yr", new int[]{0xffffc030, 0xffff6020});
        sBoots = GameKit.sprite(new String[]{
                ".rr...rr..",
                ".rr...rr..",
                ".rr...rr..",
                ".rrrr.rrrr",
                ".wwww.wwww"}, "rw", new int[]{0xffd03030, 0xffffffff});
        sBell = GameKit.sprite(new String[]{
                "..yy..",
                ".yyyy.",
                ".yyyy.",
                "yyyyyy",
                "..k..."}, "yk", new int[]{0xffffd040, 0xff805020});
        sDrop = GameKit.sprite(new String[]{
                "..gggg..",
                ".gGgggg.",
                "gggGgggg",
                "ggggGggg",
                "gggggGgg",
                ".ggggggg",
                "..gggg.g"}, "gG", new int[]{0xffc0c8e0, 0xff8890b0});
    }
}
