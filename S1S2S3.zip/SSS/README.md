# SSS+  (v1.1)

Hecho por **BLORP.eoac**. © 2026 BLORP.eoac — todos los derechos reservados (ver LICENSE).

Aplaudes 5 veces y el teléfono suena, aunque esté bloqueado o en silencio.

## Qué hace
- Escucha el micrófono con la pantalla bloqueada (queda una notificación fija "SSS+ activo").
- Nº de aplausos ajustable (2–8, por defecto 5) y sensibilidad (1–10).
- Sonido propio (oveja, lo que quieras) o el de alarma por defecto.
- Volumen ajustable; suena por el canal de alarma, así se oye aunque el móvil esté en silencio.
- Suena **una vez** (máximo 10 s). Se puede parar desde la notificación o abriendo la app.

## Próxima versión (en preparación)
- El resto del Pastor a lo grande:
  - Habilidades nuevas y zonas que solo se abren con ellas.
  - Guaridas de los secuaces como zonas grandes.
  - Aldeas con vecinos y la multitud esperando a las puertas del final.
  - El corredor con el Gólem.
  - Ver IDEAS.md.

## Novedades v1.1
- Cerebro de Chloe dentro del teléfono: Qwen2.5 1.5B Instruct (Apache 2.0, litert-community, ≈1,6 GB) con MediaPipe
  LLM Inference (com.google.mediapipe:tasks-genai:0.10.24); compileSdk 35. Automático: portátil (si hay IP) → teléfono. Se quita Gemini por completo.
- Memoria hasta 200 recuerdos, con aviso al llenarse.
- ChloeActivity: panel translúcido abajo (ASSIST/VOICE_COMMAND, palabra clave, botón del menú) con estados escuchando/pensando/hablando; tocar fuera cierra. Reconocimiento con SpeechRecognizer del sistema; el oído cede el micrófono (yieldMic).
- Tiempo por días (mañana, pasado mañana, días de la semana) y corrección rápida.
- Juegos nuevos (originales): OrbeView (lanzador de orbes, 60 niveles + infinito), GuardView (proteger a la Hechicera, 50 fases, tienda), SurviveView (supervivencia 10 min, armas automáticas), AquaView (acuario: alimentar, monedas, huevo, mascotas, 20 niveles). Sprites con Pix.java.
- Asistente: Actions.canon() traduce frases naturales («quiero que pongas…») a órdenes; VidTube y app de música por defecto; «stop Chloe» (Wake.isStop, también mientras habla) y bajar volumen para callarla; arreglos de texto del cerebro (fixUtf8, acotaciones, fixVocative, órdenes no pedidas); nombre del usuario solo desde la casilla «Tu nombre».
- Requiere Java 21 en el flujo de GitHub (java-version: '21') por MediaPipe.

## Novedades v1.0 (primera versión oficial; reúne lo que se fue probando como 1.0.1, 1.0.2 y 1.1)
- Palabra clave: «hey chloe», «hola chloe» o «clo responde» (varias frases separadas por comas; comparación por sonido, para que «Chloe» se reconozca aunque el oído la escriba «cloe»). La pantalla del asistente muestra en vivo lo último que oyó.
- Asistente con nombre y personalidad propios (por defecto «Chloe»), con reglas que van por encima de la personalidad:
  no inventa datos; las preguntas de datos se buscan en internet ANTES de responder y dice de dónde lo saca.
- Búsqueda propia sin pasar por Google/Gemini: DuckDuckGo (búsqueda segura desactivada) y Wikipedia de respaldo; lee las 2 primeras páginas.
- Cerebro en el portátil con Ollama (sin cupos), Gemini opcional, o automático (portátil si responde; si no, Gemini).
- Entiende frases libres: el cerebro decide la orden ([[cmd: …]]) y SSS+ la ejecuta.
- Memoria editable: «recuerda que…», «olvida…», «¿qué recuerdas?», y lista con borrar/añadir en pantalla.
- Funciones nuevas: volumen (subir, bajar, %, silencio), pausa/sigue/siguiente/anterior, Spotify, batería, brillo,
  cámara, paneles de wifi/Bluetooth/modo avión.
- Galería: «Poner de fondo» (fondo de SSS+, inicio, bloqueo o ambos) eligiendo qué parte de la foto se ve.
- Botón «N» junto a ⚙ con las novedades de cada versión (círculo rojo hasta que las lees), en español, inglés e italiano (assets/changelog_*.txt).

- Modelo por defecto: gemini-flash-lite-latest (muchas más preguntas gratis al día que Flash).

- Palabra clave: ya no se activa sola. Antes usaba una gramática de una palabra y Vosk "oía" paradoja en cualquier frase;
  ahora usa el reconocedor completo y exige la palabra entera, en una frase terminada y con ≥75 % de seguridad.
  «Paradoja, buenos días» de un tirón también vale. El asistente muestra la última vez que se activó y qué oyó.
- Si Google responde 429, no se le vuelve a preguntar durante 1 min (15 min si es el cupo diario).
- El pitido de «te escucho» suena siempre (antes dejaba de sonar).

- Asistente: ahora cumple órdenes de verdad (YouTube, llamar, WhatsApp/SMS, alarma, temporizador, mapa, abrir apps, linterna, buscar).
- Rutinas: «buenos días» (saludo con tu nombre, hora, tiempo de Open-Meteo, chiste, «que te vaya bien» y quita el No molestar),
  «buenas noches» (pone No molestar; las alarmas suenan), «qué hora es», «qué tiempo hace», «cuéntame un chiste».
- Gemini: limpia la clave pegada, reintenta sin búsqueda y con modelos de reserva si sale 429, y muestra el mensaje de Google.
- Modelador 3D: los modelos con muchos polígonos ya no se ven "de puntitos" (vista simplificada cerrada) y los huesos
  se colocan tocando donde los quieres con ✋ MOVER.
- Nuevo: AMPLIAR IMÁGENES (Scale2x para pixel art, bicúbica + enfoque para fotos), sin internet.

## Novedades v0.9.2
- 🐑 **Asistente SSS+** (menú principal → ASISTENTE):
  - Responde con **Gemini**, con tu propia clave gratuita de Google AI Studio. Puede buscar en internet y su personalidad es configurable.
  - **Voces:** elige el motor de voz (los que tengas instalados; se pueden añadir más desde Play Store), la voz, el tono y la velocidad.
  - **Palabra clave** («paradoja» por defecto, cambiable): sin internet, con un «oído» de ≈40 MB que se descarga una vez. La descarga la hace Android en segundo plano: sigue aunque salgas de la app, se reanuda sola y sale primero de Hugging Face, que es más rápido. Di la frase, oirás un pitido y luego haces tu pregunta; responde en voz alta y en una notificación.
  - Se puede poner como **asistente digital** del teléfono (mantener pulsado Inicio) en lugar de Google o Gemini.
  - Junto con «Silenciar Ok Google», el teléfono solo atiende a tu palabra clave.

## Novedades v0.9.1
- 🔇 **Silenciar «Ok Google»** (Ajustes):
  - De una hora A a una hora B, SSS+ ocupa el micrófono en modo privado y el Asistente de Google de este teléfono no puede oír «Ok Google». No se graba ni se guarda nada.
  - Funciona en Android 11 o más nuevo; en Android 10 y anteriores se usa otro método.
  - Seguridad: «Pausar 1 hora», «Detener por hoy», «Reanudar» y «Apagar del todo», desde Ajustes o desde la notificación.
  - Si otra app necesita el micrófono (llamadas, notas de voz), el escudo se aparta solo y vuelve después.
  - Si el micrófono falla, el escudo se apaga solo.
  - Con la escucha de aplausos encendida, los aplausos siguen funcionando durante el escudo.
  - Tras reiniciar el teléfono, hay que abrir SSS+ una vez.

## Novedades v0.9
- 🐛 **Arreglado: «Nueva partida» cerraba la app.** La pregunta «¿Empezar de cero?» intentaba dibujar una sala que aún no existía.
- 📂 **3 ranuras de partida**:
  - En el título, «PARTIDAS» muestra las tres ranuras con ecos, corderitos, cascabeles y tiempo. Puedes jugar, empezar o borrar cada una.
  - «CONTINUAR» sigue la última que usaste.
  - Tu partida de antes está en la ranura 1.
- 🖼 **Intro ilustrada**: las 4 frases del comienzo del Pastor de Ecos llevan ahora las ilustraciones de BLORP.eoac, con fundido. Cada ilustración se queda al menos 3 segundos (una barrita abajo indica cuándo se puede seguir). En inglés e italiano la frase se ve traducida encima.
- 🎮 **Menús con mando**:
  - En el Pastor de Ecos, el título, la pausa, las tiendas, los emblemas, la forja, los logros, el Modo Jefes y el Coliseo se manejan con mando. La cruceta o la palanca mueven un marco amarillo, A pulsa y B vuelve atrás.
  - En el mapa: palanca para moverte, LB/RB (o X/Y) para alejar y acercar, A o B para cerrar.
  - También funciona en los menús de la Torre, los ajustes del Gato y el pack retro.
- 📿 **127 emblemas** (antes 49):
  - 78 nuevos en familias I/II/III más 15 únicos.
  - Salen de los cofres (cada cofre da uno nuevo hasta agotarlos) y como premio de las misiones.
  - La pantalla de emblemas tiene un filtro por familias: Ataque, Defensa, Movimiento, Lana, Economía, Sets y Puestos.
- 💊 **Mejoras permanentes**, contadas y sin poder farmearlas:
  - 10 Pociones de Vida (+10 de vida máxima): 6 escondidas y 4 de misiones.
  - 10 Pociones de Fuerza (+1 de ataque): 6 escondidas y 4 de misiones.
  - 6 Ovillos Extra (de 9 a 15 ovillos): 3 escondidos y 3 a la venta en los Sapos del Lago, Cristal y Cementerio.
- 📜 **25 misiones secundarias**:
  - Vecinos que piden cazar bichos o encontrar algo que perdieron.
  - Diario en la pausa y marcas ❗ / ✔ en el mapa.
  - Nuevo logro «Vecina de Lanaria».
- 😢 **11 supervivientes del clan Vampis**, uno por zona: cuentan lo que pasó y dan pistas de los secuaces y del Conde.
- 🦇 **Set vampírico**:
  - Las piezas se ven en la oveja: capa negra, puntos negros en las patas (botas), punto rojo en el cuello (vial) y colmillo.
  - Al ponerte el set completo los colores se vuelven negativos: unos segundos la primera vez y 15 s cada vez que te lo vuelves a poner.
  - Final secreto: Bee camina, se para, todo parpadea en negativo, se vuelve rojo, se vuelve negra, le salen alas y sale volando a por la gente.
- 🐾 **Garras con ataque a distancia**: mantén el botón para cargar y suelta unos arañazos que vuelan unas 6 casillas, atraviesan y hacen más daño que el cencerro.

## Novedades v0.8.1 (arreglo)
- Planta Carnívora:
  - Plataformas nuevas que llegan hasta ella: ahora el cencerro le alcanza.
  - Ataca bastante más seguido: avisa menos y lanza más semillas, más rápidas.
  - Tiene 1400 de vida.
  - Cada 15 segundos (12 en la segunda fase) llama a un Polinizador Furioso, hasta 3 a la vez. Se marchitan cuando muere la planta.
  - Uno de sus tallos siempre va a la altura donde estás.
  - La salida que quedaba tapiada detrás de la maceta tiene ahora un túnel por debajo. Se cierra durante la pelea y se abre al vencerla.
- Arreglado el error de compilación de la v0.8 en los juegos retro.

## Novedades v0.8 (gran actualización)
### El Pastor de Ecos
- **Coliseo del Eco**:
  - La Agente Garduña vende la llave azul (1000 🔔), que abre la puerta azul del refugio del Cementerio de Campanas.
  - El Presentador te inscribe. Son 5 tandas de 5 titanes de 2500 de vida, que salen de uno en uno.
  - Al ganar cada tanda, el Presentador deja en el suelo una pieza del Set de la Sinfonía y te pregunta si quieres seguir.
  - Puedes retirarte desde la pausa. Si caes en el Coliseo, no pierdes los cascabeles.
  - Tiene música de pelea propia y la última tanda va más rápida.
- **Set de la Sinfonía** (5 piezas):
  - Cencerro Resonante: +35 % de daño de las ondas.
  - Diapasón del Abismo: las ondas atraviesan y rebotan.
  - Campana Gemela: una onda más.
  - Oído Infinito: más alcance y ondas que buscan al enemigo.
  - Corazón de Eco: cada golpe se repite medio segundo después.
  - Con el set completo, cada 5.º toque lanza una onda gigante. A cambio, 5 s sin sonar te quitan vida poco a poco.
- **Finales nuevos**:
  - Final verdadero «El Rebaño Unido»: con los 5 corderitos, llegan a la pelea contra LUMENIA y la vencéis juntas.
  - Final del sacrificio «Pastor Temerario»: Bee cae, y se alza una estatua con rosas.
  - Final secreto n.º 2 «Adicto al Eco»: con el Set de la Sinfonía puesto, puedes quedarte los ecos.
  - El final secreto vampírico muestra salpicaduras con 🩸 Sangre SÍ, o animalitos que gritan con Sangre NO.
- **Pantalla de logros** 🏆 (5 logros, desde el título o la pausa). Se guardan aunque empieces de cero.
- **Aspecto OLED** (se activa o desactiva en la pausa):
  - Colores más vivos y negros profundos.
  - Fondo con parallax, relieve y sombras en paredes y personajes.
  - Brillo en las ondas y viñeta.
- **Mapa de los Secuaces** (Agente Garduña): marca cada puerta carmesí con el secuaz que hay detrás. Al comprar una llave carmesí, la policía te dice dónde hay una puerta.
- **Jefes finales de verdad**:
  - LUMENIA tiene 5000 de vida y el Conde 3500.
  - Las fases no se pueden saltar y fuera de sus aberturas solo reciben un 30 % del daño.
  - El Conde se cura con tus golpes recibidos.
  - Los dos tienen música de metal sinfónico.

### Pack retro remasterizado
- **5 juegos nuevos** de las maquinitas «Brick Game», a color, con neón y partículas:
  - 🏎 Carreras: tres carriles, monedas, turbo y curvas.
  - 🪖 Tanques: enemigos normales, rápidos y blindados, potenciadores y un jefe cada 5 niveles.
  - 🚀 Disparos: la pared baja y las armas mejoran de doble a triple y láser.
  - 🐸 Ranita: carretera y río con troncos y tortugas que se hunden, de día y de noche.
  - 🧩 Rellenar huecos: bombas, rayos y combos.
- **Opciones comunes**:
  - Nivel y velocidad iniciales (1–10) y récords.
  - Modo «como antes» con LCD verde y las casillas apagadas a la vista.
  - Cruceta o joystick, modo zurdo y mando externo.
  - Música propia en cada juego, que se acelera con el nivel.
- **Lavado de cara** de Culebrita, Bloques y Rompeladrillos:
  - Música, partículas, temblor y relieve.
  - Modo LCD y velocidad inicial (en ⚙).

## Novedades v0.7.1 (arreglo urgente)
- **Pastor de Ecos: ya no te quedas encerrado.** Las rejas de "X ecos" estaban del lado de la zona difícil: se podía entrar sin ecos y luego no salir. Ahora la reja está en la entrada (impide entrar sin los ecos necesarios) y desde dentro siempre se puede salir. Las partidas que quedaron atrapadas se liberan solas al actualizar.
- **🎨 Carátula de El Pastor de Ecos** en la pantalla de título y en la tarjeta del juego.
- **📜 Créditos y licencias** en Ajustes y archivo LICENSE.

## Novedades v0.7
- **🧊 Editor 3D** (antes visor): abre STL, OBJ, FBX, GLB/glTF y VRM con sus texturas, huesos y pesos.
  - **🦴 Huesos**: 🧍 plantilla humanoide de un toque (25 huesos con nombres de VRM), añadir, mover articulaciones con el dedo, posar para probar cómo se dobla, renombrar, cambiar padre, borrar, lista de huesos, izquierda/derecha y papel humanoide de cada hueso.
  - **⚖ Pesos**: automáticos y pincel para sumar o restar, con mapa de calor (rojo = mucho, azul = nada).
  - **🎨 Pintar**: pinta directamente sobre el modelo, cambia la imagen (textura) de cada parte o tíñela; colores de piel y código HEX.
  - **💾 Guardar** en SSS+/3D: GLB con huesos, pesos y texturas (Blender, Unity…), **VRM de verdad** (avatar humanoide para VRoid, VSeeFace, VRChat…), FBX, OBJ, STL y las texturas en PNG.
- **📁 Carpeta SSS+**: todo lo que creas se guarda ordenado en /SSS+ (Fotos, Videos, Audios, Documentos, 3D, Copias), como los programas de la computadora. Acceso directo 📁 SSS+ en Archivos.
- **💾 Copias de seguridad** (Ajustes): guarda partidas, récords y ajustes en SSS+/Copias y restáuralos en otro teléfono.
- **⚔ Modo Jefes**: en la portada del Pastor, pelea contra cualquier jefe que ya hayas vencido con todas las habilidades, la forja al máximo y tus 12 emblemas favoritos. Guarda tu mejor tiempo y no toca tu partida.
- **Sangre Joven**: sombra roja donde va a caer, aturdido 2,5 s y ×1,5 de daño mientras está aturdido.
- **Oveja más fuerte**: +2 de ataque al cencerro y las garras, +1 a la trompeta.
- **Controles**: sin botones de salto repetidos con el joystick; con mando externo desaparecen los controles táctiles y sale una leyenda; modo zurdo y tamaño de controles (Pastor y Gato).

## Novedades v0.6
- **🔔 Pastor de Ecos**: joystick analógico semitransparente (moverse con más o menos fuerza, empujar hacia arriba = saltar). En Pausa → 🎮 Controles: joystick o botones, opacidad y mando externo opcional.
- **🎮 Mando externo opcional** (Xbox, gamepad Bluetooth/USB o teclado) en Pastor, Gato, Bloques, Culebrita, Rompeladrillos, 2048 y Sudoku. Viene apagado; los controles táctiles siguen funcionando.
- **🐈 Gato Runner**: sin botones ↑↓: mitad derecha = saltar, mitad izquierda = agacharse. Los botones vuelven como opción, con opacidad ajustable.
- **🧱 Bloques**: ⚙ Ajustes con joystick en pantalla opcional (el deslizar sigue por defecto).
- **🗼 Torre Arriba**: cargador de 25 balas (+2 por nivel) y +1 de daño por bala; las balas ya no dan XP.
- **Juegos nuevos**: 🔢 2048 y 🧩 Sudoku (9×9, cuatro dificultades, notas, 3 errores máximo).
- **🧊 Visor 3D**: abre FBX, GLB/glTF y VRM además de STL y OBJ, y convierte entre STL, OBJ, FBX y GLB (base de VRM; un VRM de verdad necesita esqueleto).

## Novedades v0.5
- **🌐 Idiomas**: toda la app en español, inglés e italiano (Ajustes → Idioma). Por defecto, el idioma del teléfono.
- **🔔 El Pastor de Ecos, juego completo**: mundo de 306 salas al estilo Hollow Knight (14 zonas con fondos propios, mapa con la forma de cada sala, zoom y arrastre), 20 jefes de eco con su truco de cencerro (Titán de Hielo, Claudio, Sombraverde, Gargantúa, Madame Picadura, Don Caparazón, Coralia, Gran Búho Espía, Turo, Barón Grajófono, Bruma, Marquesa Polilla, Reina Nodriza, Vortex, Griselda, Don Baronio, Cabra Sombra y LUMENIA en dos fases), 7 mazmorras secretas con guardián (llaves de la Agente Garduña, la policía corrupta), vida en barra de 100, enemigos más fuertes cuanto más lejos, 44 emblemas (12 a la vez, se cambian en los fardos) y 6 habilidades (embestida, salto de pared, eco cargado...).
- **🦇 Set vampírico y final secreto**: Harold, Aloii, la Planta Carnívora, Sangre Joven y el Conde Vampis, cada uno con su música; Garras con zarpazos (efecto sangre opcional en la pausa) y el final secreto Nº 1.
- **🗼 Torre Arriba**: límites de estadísticas mucho más altos (vida hasta 3000), cargador con +2 balas por nivel, 5 puntos por nivel y menos séquito en los jefes.

## Novedades v0.4
- **➕ Adicionales**: Documentos (leer, editar y convertir PDF/EPUB/DOCX/TXT), Biblioteca con lectura en voz alta y marcador, Gestor de archivos (copiar, mover, renombrar, borrar, ZIP y RAR4) y Visor 3D (.stl y .obj).
- **Galería**: pestaña DOCS y, manteniendo pulsado, renombrar, mover, borrar, detalles, convertir y añadir a la biblioteca.
- **Editor de fotos**: tamaño exacto (ancho × alto) y calidad/compresión, y nueva interfaz clásica tipo galería (recortar con cuadrícula, girar, filtros, Guardar copia).
- **Editor de sonido**: efecto 8D y ecualizador de 5 bandas con vista previa.
- **Buscaminas**: Fácil 50, Normal 100, Difícil 150 y Nightmare 250 bombas, con lupa/zoom y modo bandera.
- **Rompeladrillos**: 20 niveles con dibujos y la pelota ya no atraviesa ladrillos.
- **Torre Arriba**: sin saltos imposibles, +5 XP por criatura, ajustes (volumen y apuntado automático o flecha hacia arriba).
- **Pastor de Ecos**: la Onda Ancha ya dispara desde el suelo; botones en las franjas oscuras.
- **Récords y partidas ya no se borran** al actualizar (firma fija de la app).

## Novedades v0.3
- **🔔 El Pastor de Ecos (fase 1)**: aventura metroidvania. 18 salas conectadas (Pradera Hundida, pueblo de Eco Hondo y Minas de Cobre), refugios con fardo para guardar, Sabelotodo y su Bestiario (secretos a las 10 muertes), Cartógrafa (mapas), Sapo Mercader (amuletos, 3 huecos), Herrera (cencerro nivel 1-5 con 3 especialidades), Trompeta de Brasas secreta, botas de doble salto, corderitos, cascabeles que se quedan donde caes, y 3 jefes: Rey Topo Loco, Vagoneta Fantasma y Murciégalo Gemelo (opcional).
- **🗼 Torre Arriba**: roguelike vertical hasta el piso 1000. XP, 5 estadísticas con límite (vida 50→1000, daño, salto, defensa con escuditos que se recargan en 30 s, robo de vida 1→10 %), jefe cada 15 pisos, jefe fuerte cada 30 y Guardián cada 60 (Gólem, Dragón, Caballero Oscuro, Ojo Arcano), alitas/escudo/imán/doble daño, partida guardada al salir y final especial en el piso 1000.
- **🐈 Gato Runner**: salta ovillos, agáchate ante chanclas; NIGHTMARE MODE (colores invertidos y más velocidad) cada 250 puntos durante 100.
- **🎵 Música chiptune original** generada por la app (sin archivos), con volumen y silencio en cada juego.
- **🧱 Bloques**: nuevos controles (arrastrar = mover casilla a casilla, tocar = girar, deslizar abajo = soltar) y botones ◀ ↻ ▶ ⬇ ⤓.
- **Galería**: detecta el acceso limitado a fotos ("Seleccionar fotos") y ofrece "Permitir todas"; nuevo botón "Abrir desde el teléfono".

## Novedades v0.2
- **ℹ Info**: batería (carga, temperatura, salud, ciclos, capacidad actual, corriente, voltaje, tiempo hasta carga), estado térmico y temperatura de CPU (si el fabricante lo permite), CPU, RAM, almacenamiento y dispositivo, en vivo.
- **🧹 Limpieza**: recomendaciones según el estado del móvil y opciones marcadas como Recomendado / Opcional / Con cuidado (caché de SSS+, herramienta de Android, capturas antiguas, videos grandes, fotos y audios grandes, ahorro de batería, desinstalar apps). Siempre eliges qué se borra y Android pide confirmación.
- **🎮 Juegos**: Culebrita, Bloques que caen, Rompeladrillos y Buscaminas, con récords.
- **✂ Editores** con galería automática:
  - Fotos: girar, espejo, voltear, recortes (1:1, 4:3, 3:4, 16:9, 9:16), filtros, brillo, contraste, saturación y zoom con dos dedos.
  - Video: recortar tramo, quitar sonido y extraer el audio (sin perder calidad).
  - Sonido: grabadora, recortar, volumen, fundidos, guardar en Música y **usar como sonido de SSS+**.
- Pantalla principal: línea de sistema (batería, temperatura, espacio libre) y accesos a las 4 secciones.

## Novedades v0.1.1
- Arreglado: el sonido de alarma se repetía sin parar (ahora suena una vez, máximo 10 s, con doble vigilancia).
- Notificación grande **🛑 DETENER** visible con el móvil bloqueado; tocarla o deslizarla también lo para.
- Encender la pantalla (botón de encendido) detiene el sonido.
- Pausa de 4 s tras sonar para que no se vuelva a activar sola.
- Detector de aplausos más listo: solo cuenta golpes muy cortos (aplausos); descarta voces, música, golpes largos y ruidos sostenidos.
- Seguro anti-bucle: si suena 3 veces seguidas sin que nadie lo pare, deja de escuchar 1 minuto.

## Novedades v0.1
- Nuevo nombre: **SSS+**.
- Interfaz HUD neón estilo Pipox: botón de encendido grande, panel de sistema en vivo (estado, medidor del micrófono con línea de umbral, puntos que se encienden con cada aplauso) y controles rápidos (Probar, Sonido, Volumen).
- Pantalla ⚙ Ajustes aparte: Detección, Sonido, Skin y Batería.
- Skin: colores rápidos, color RGB de los marcos, opacidad de paneles, color cambiante (arcoíris) con velocidad, y fondo de pantalla propio.

## Permisos (solo estos)
- Micrófono, notificaciones, servicio en primer plano y mantener activo (aplausos y grabadora).
- Fotos, videos y audio: solo se piden al entrar en Editores o Limpieza.
- **Sin internet** y sin contactos.

## Compilar el APK
### Opción A: GitHub (sin instalar nada, sirve desde el móvil)
1. En tu repositorio, sube **SSS.zip** tal cual (Add file → Upload files). Debe ser el único .zip del repositorio.
2. La compilación arranca sola (pestaña **Actions** → "Compilar APK").
3. Al terminar (~3 min), abre la ejecución y descarga **SSS-APK** (un .zip con el .apk dentro).
4. Instálalo en el teléfono (acepta "instalar apps de origen desconocido").

### Opción B: en el propio teléfono
Abre la carpeta con una app tipo AndroidIDE y compila `assembleRelease`.

### Opción C: Android Studio en PC
Abrir la carpeta → Build → Build APK.

## Uso
1. Abre SSS+ y toca el **botón de encendido** grande (acepta micrófono y notificaciones).
2. Elige tu sonido, ajusta el volumen y pulsa **▶ PROBAR**.
3. En ⚙ Ajustes → Batería, pon SSS+ sin restricciones (si no, algunas marcas lo cierran).

## Notas
- Si reinicias el teléfono, hay que abrir la app y activarla de nuevo (Android no deja encender el micrófono solo al arrancar).
- Usa algo de batería por tener el micrófono siempre escuchando.
- Si suena con ruidos que no son aplausos, baja la sensibilidad; si no detecta desde lejos, súbela.
