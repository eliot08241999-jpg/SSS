package com.aplauso.encuentra;

import android.graphics.Color;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Pantalla principal estilo HUD: botón de encendido, panel de sistema en vivo y controles rápidos. */
public class MainActivity extends NeonActivity {
    View newsDot;
    static final int REQ_PERM = 1;
    static final int[] VOLUMES = {25, 50, 75, 100};

    Neon.PowerButton power;
    Neon.LevelBar level;
    Neon.ClapDots dots;
    TextView status, hint, soundLbl, testBtn, volBtn;
    boolean wasOn;
    TextView sysLine;
    int tickN = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(18), dpi(18), dpi(18), dpi(18));

        // --- Barra superior: título + ajustes ---
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = neonText("SSS+", 30);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        // v1.1: «N» de novedades, con un círculo rojo si hay una versión nueva sin leer
        android.widget.FrameLayout news = new android.widget.FrameLayout(this);
        news.addView(circleButton("N", v -> startActivity(new Intent(this, NewsActivity.class))), new android.widget.FrameLayout.LayoutParams(dpi(46), dpi(46)));
        newsDot = new View(this);
        android.graphics.drawable.GradientDrawable dot = new android.graphics.drawable.GradientDrawable();
        dot.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        dot.setColor(android.graphics.Color.rgb(255, 40, 60));
        dot.setStroke(dpi(2), android.graphics.Color.BLACK);
        newsDot.setBackground(dot);
        android.widget.FrameLayout.LayoutParams dl = new android.widget.FrameLayout.LayoutParams(dpi(14), dpi(14), Gravity.TOP | Gravity.END);
        news.addView(newsDot, dl);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(dpi(48), dpi(48));
        nl.rightMargin = dpi(8);
        top.addView(news, nl);
        TextView gear = circleButton("⚙", v -> startActivity(new Intent(this, SettingsActivity.class)));
        top.addView(gear, new LinearLayout.LayoutParams(dpi(46), dpi(46)));
        col.addView(top, gapBelow(14));

        // --- Panel de sistema en vivo ---
        LinearLayout hud = panel("◢ SISTEMA");
        status = neonText("", 17);
        hud.addView(status);
        hud.addView(text("Micrófono", 12));
        level = new Neon.LevelBar(this);
        hud.addView(level, new LinearLayout.LayoutParams(-1, dpi(22)));
        hud.addView(text("Aplausos", 12));
        dots = new Neon.ClapDots(this);
        hud.addView(dots, new LinearLayout.LayoutParams(-1, dpi(30)));
        soundLbl = text("", 13);
        soundLbl.setPadding(0, dpi(6), 0, 0);
        hud.addView(soundLbl);
        sysLine = text("", 13);
        sysLine.setPadding(0, dpi(2), 0, 0);
        hud.addView(sysLine);
        col.addView(hud, gapBelow(8));

        // --- Botón de encendido ---
        power = new Neon.PowerButton(this);
        power.setOnClickListener(v -> {
            if (ClapService.running) stopService(new Intent(this, ClapService.class));
            else enable();
        });
        col.addView(power, new LinearLayout.LayoutParams(-1, dpi(200)));

        hint = text("", 14);
        hint.setGravity(Gravity.CENTER);
        col.addView(hint, gapBelow(14));

        // --- Controles rápidos ---
        LinearLayout quick = new LinearLayout(this);
        testBtn = button("▶ PROBAR", v -> {
            if (SoundPlayer.isPlaying()) SoundPlayer.stopByUser(this);
            else SoundPlayer.play(this, null);
        });
        TextView soundBtn = button("♪ SONIDO", v -> pickSound());
        volBtn = button("", v -> {
            int cur = p.getInt("volume", 100), next = VOLUMES[0];
            for (int x : VOLUMES) if (x > cur) { next = x; break; }
            p.edit().putInt("volume", next).apply();
            refreshLabels();
        });
        quick.addView(testBtn, weighted(true));
        quick.addView(soundBtn, weighted(true));
        quick.addView(volBtn, weighted(false));
        col.addView(quick, gapBelow(10));

        // --- Secciones (estilo Pipox) ---
        LinearLayout row1 = new LinearLayout(this);
        row1.addView(button("ℹ INFO", v -> startActivity(new Intent(this, InfoActivity.class))), weighted(true));
        row1.addView(button("🧹 LIMPIEZA", v -> startActivity(new Intent(this, CleanActivity.class))), weighted(false));
        col.addView(row1, gapBelow(8));
        LinearLayout row2 = new LinearLayout(this);
        row2.addView(button("🎮 JUEGOS", v -> startActivity(new Intent(this, GamesActivity.class))), weighted(true));
        row2.addView(button("✂ EDITORES", v -> startActivity(new Intent(this, GalleryActivity.class))), weighted(false));
        col.addView(row2, gapBelow(8));
        col.addView(button("➕ ADICIONALES · documentos, biblioteca, archivos, 3D", v -> startActivity(new Intent(this, AdditionalActivity.class))), gapBelow(8));
        col.addView(button("✦ HABLAR CON CHLOE", v -> startActivity(new Intent(this, ChloeActivity.class).putExtra(ChloeActivity.EXTRA_LISTEN, true))));
        col.addView(button("🐑 ASISTENTE CHLOE · cerebro, voces, memoria y ajustes", v -> startActivity(new Intent(this, AssistActivity.class))));
        col.addView(button("🎨 ESTUDIO DE DIBUJO · crea imágenes con IA", v -> startActivity(new Intent(this, DrawStudioActivity.class))));
        col.addView(button("🔍 AMPLIAR IMÁGENES · agrandar sin que se vean raras", v -> startActivity(new Intent(this, UpscaleActivity.class))));
        // autor (pequeño, abajo)
        TextView author = text("SSS+ por BLORP.eoac", 11);
        author.setTextColor(Color.argb(150, 200, 210, 230));
        author.setGravity(Gravity.CENTER);
        author.setPadding(0, dpi(18), 0, dpi(4));
        col.addView(author);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(col);
        setContentView(makeRoot(sv));
    }

    private LinearLayout.LayoutParams weighted(boolean gapRight) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        if (gapRight) lp.rightMargin = dpi(8);
        return lp;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (newsDot != null) newsDot.setVisibility(NewsActivity.unseen(this) ? View.VISIBLE : View.GONE);
        if (SoundPlayer.isPlaying() && ClapService.running) SoundPlayer.stopByUser(this); // ya lo encontraste
        ShieldService.start(this);       // v0.9.1: si el escudo anti-«Ok Google» está activado, se pone en marcha
        new Thread(() -> Wake.poll(this, (pc, m) -> {}), "oido").start();   // si el oído terminó de bajar con la app cerrada, se descomprime
        refreshLabels();
    }

    @Override
    protected void onSoundChanged() { refreshLabels(); }

    private void refreshLabels() {
        soundLbl.setText("♪ " + soundName());
        volBtn.setText(L.t("🔊 " + p.getInt("volume", 100) + "%"));
    }

    @Override
    protected void onTick() {
        if (tickN++ % 40 == 0) { // cada 2 segundos
            SysInfo.Battery bt = SysInfo.battery(this);
            long[] st = SysInfo.storage();
            sysLine.setText(L.t("🔋 " + bt.percent + "%"
                    + (Float.isNaN(bt.tempC) ? "" : String.format(java.util.Locale.US, " · %.0f °C", bt.tempC))
                    + " · 💾 " + SysInfo.bytes(st[1]) + " libres"));
        }
        int c = Neon.color(this);
        boolean on = ClapService.running;
        int needed = p.getInt("claps", 5);
        power.set(c, on);
        float mark = on ? Neon.meter(Neon.threshold(p.getInt("sens", 6))) : -1;
        level.set(on ? Neon.meter(ClapService.level) : 0, mark, c);
        dots.set(needed, on ? ClapService.clapCount : 0, c);

        boolean playing = SoundPlayer.isPlaying();
        status.setText(L.t(playing ? "● SONANDO" : on ? "● ESCUCHANDO" : "○ APAGADO"));
        testBtn.setText(L.t(playing ? "■ PARAR" : "▶ PROBAR"));
        if (on != wasOn || hint.getText().length() == 0) {
            wasOn = on;
            hint.setText(L.t(on ? "Aplaude " + needed + " veces para que suene"
                    : "Toca el botón para empezar a escuchar"));
        }
    }

    private void enable() {
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (need.isEmpty()) startForegroundService(new Intent(this, ClapService.class));
        else requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code != REQ_PERM) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startForegroundService(new Intent(this, ClapService.class));
        } else {
            Toast.makeText(this, L.t("Sin micrófono no puedo oír los aplausos"), Toast.LENGTH_LONG).show();
        }
    }
}
