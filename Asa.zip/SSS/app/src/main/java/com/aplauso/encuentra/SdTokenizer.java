package com.aplauso.encuentra;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v1.3 · Estudio de dibujo: convierte el texto en las "fichas" que entiende Stable Diffusion
 * (el tokenizador BPE de CLIP, con vocab.json y merges.txt del propio modelo). 77 fichas como máximo.
 */
public class SdTokenizer {
    static final int BOS = 49406, EOS = 49407, LEN = 77;
    static final Pattern PAT = Pattern.compile(
            "<\\|startoftext\\|>|<\\|endoftext\\|>|'s|'t|'re|'ve|'m|'ll|'d|[\\p{L}]+|[\\p{N}]|[^\\s\\p{L}\\p{N}]+",
            Pattern.CASE_INSENSITIVE);

    final Map<String, Integer> vocab = new HashMap<>();
    final Map<String, Integer> ranks = new HashMap<>();
    final Map<String, String> cache = new HashMap<>();
    final String[] byteChar = new String[256];
    int bos = BOS, eos = EOS, pad = EOS;

    SdTokenizer(File vocabJson, File mergesTxt) throws Exception {
        this(read(vocabJson), read(mergesTxt));
    }

    SdTokenizer(String vocabJson, String merges) throws Exception {
        JSONObject v = new JSONObject(vocabJson);
        for (Iterator<String> it = v.keys(); it.hasNext(); ) { String k = it.next(); vocab.put(k, v.getInt(k)); }
        int r = 0;
        for (String line : merges.split("\n")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#version")) continue;
            String[] ab = line.split(" ");
            if (ab.length != 2) continue;
            ranks.put(ab[0] + " " + ab[1], r++);
        }
        Integer b = vocab.get("<|startoftext|>"), e = vocab.get("<|endoftext|>");
        if (b != null) bos = b;
        if (e != null) { eos = e; pad = e; }
        // bytes_to_unicode de GPT-2/CLIP
        List<Integer> bs = new ArrayList<>();
        for (int i = '!'; i <= '~'; i++) bs.add(i);
        for (int i = 0xA1; i <= 0xAC; i++) bs.add(i);
        for (int i = 0xAE; i <= 0xFF; i++) bs.add(i);
        int n = 0;
        for (int i = 0; i < 256; i++) {
            if (bs.contains(i)) byteChar[i] = String.valueOf((char) i);
            else byteChar[i] = String.valueOf((char) (256 + n++));
        }
    }

    static String read(File f) throws Exception {
        StringBuilder b = new StringBuilder((int) Math.min(Integer.MAX_VALUE, f.length() + 16));
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            char[] buf = new char[65536];
            int k;
            while ((k = r.read(buf)) > 0) b.append(buf, 0, k);
        }
        return b.toString();
    }

    /** Las 77 fichas (inicio, texto, fin y relleno). Lo que no cabe se corta. */
    int[] encode(String text) {
        List<Integer> ids = new ArrayList<>();
        String t = text == null ? "" : text.replaceAll("\\s+", " ").trim().toLowerCase(java.util.Locale.ROOT);
        Matcher m = PAT.matcher(t);
        while (m.find()) {
            String tok = m.group();
            StringBuilder u = new StringBuilder();
            for (byte by : tok.getBytes(StandardCharsets.UTF_8)) u.append(byteChar[by & 0xff]);
            for (String piece : bpe(u.toString()).split(" ")) {
                Integer id = vocab.get(piece);
                if (id != null) ids.add(id);
            }
        }
        int[] out = new int[LEN];
        java.util.Arrays.fill(out, pad);
        out[0] = bos;
        int n = Math.min(ids.size(), LEN - 2);
        for (int i = 0; i < n; i++) out[i + 1] = ids.get(i);
        out[n + 1] = eos;
        return out;
    }

    /** Cuántas palabras-ficha ocupa el texto (para avisar si es demasiado largo). */
    int count(String text) {
        int[] e = encode(text);
        int n = 0;
        for (int i = 1; i < LEN && e[i] != eos; i++) n++;
        return n;
    }

    String bpe(String token) {
        String c = cache.get(token);
        if (c != null) return c;
        List<String> word = new ArrayList<>();
        int len = token.length();
        for (int i = 0; i < len; i++) word.add(i == len - 1 ? token.charAt(i) + "</w>" : String.valueOf(token.charAt(i)));
        if (word.isEmpty()) return "";
        while (word.size() > 1) {
            int best = Integer.MAX_VALUE, at = -1;
            for (int i = 0; i < word.size() - 1; i++) {
                Integer r = ranks.get(word.get(i) + " " + word.get(i + 1));
                if (r != null && r < best) { best = r; at = i; }
            }
            if (at < 0) break;
            String a = word.get(at), b = word.get(at + 1);
            List<String> nw = new ArrayList<>();
            int i = 0;
            while (i < word.size()) {
                if (i < word.size() - 1 && word.get(i).equals(a) && word.get(i + 1).equals(b)) { nw.add(a + b); i += 2; }
                else { nw.add(word.get(i)); i++; }
            }
            word = nw;
        }
        String r = String.join(" ", word);
        if (cache.size() < 5000) cache.put(token, r);
        return r;
    }
}
