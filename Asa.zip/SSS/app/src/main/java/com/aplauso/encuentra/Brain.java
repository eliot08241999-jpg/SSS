package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * El "cerebro" de Chloe (v1.1): piensa dentro del teléfono (LocalBrain) o, si lo configuras, en tu portátil
 * con Ollama. Sin Gemini y sin cupos. Antes de responder preguntas de datos busca en internet (Web).
 */
public class Brain {
    static final String DEFAULT_NAME = "Chloe";
    static final String DEFAULT_PERSONA = "Eres simpática y con un punto sarcástico. Hablas claro y corto, como una amiga lista, "
            + "y de vez en cuando sueltas una broma.";
    static final String DEFAULT_PC_MODEL = "qwen2.5:7b";

    /** Conversación reciente (para que recuerde de qué se hablaba). */
    static final List<String[]> history = new ArrayList<>();      // {"user"|"model", texto}

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static String persona(Context c) { String s = prefs(c).getString("ai_persona", "").trim(); return s.isEmpty() ? DEFAULT_PERSONA : s; }
    static boolean search(Context c) { return prefs(c).getBoolean("ai_search", true); }
    static String botName(Context c) { String s = prefs(c).getString("ai_bot_name", "").trim(); return s.isEmpty() ? DEFAULT_NAME : s; }
    /** "auto" (portátil si responde; si no, el teléfono), "local" o "pc". */
    static String brain(Context c) { String b = prefs(c).getString("ai_brain", "auto"); return b.equals("gemini") ? "auto" : b; }   // v1.1: sin Gemini
    static String pcModel(Context c) { String m = prefs(c).getString("ai_pc_model", "").trim(); return m.isEmpty() ? DEFAULT_PC_MODEL : m; }
    static String pcUrl(Context c) {
        String u = prefs(c).getString("ai_pc_url", "").trim();
        if (u.isEmpty()) return "";
        if (!u.startsWith("http")) u = "http://" + u;
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        if (!u.substring(u.indexOf("//") + 2).contains(":")) u += ":11434";
        return u;
    }

    /** Último error completo (se muestra escrito en la pantalla del asistente). */
    static volatile String lastError = "";

    static final class Fail extends Exception {
        final int code; final String msg;
        Fail(int code, String msg) { super(msg); this.code = code; this.msg = msg; }
    }

    // ================= v1.1: cerebro propio con los pies en la tierra =================
    static String system(Context c) {
        String lang = "es".equals(L.lang) ? "español" : "it".equals(L.lang) ? "italiano" : "English";
        String user = prefs(c).getString("ai_name", "").trim();
        return "Te llamas " + botName(c) + " y eres el asistente de voz de la app SSS+, creada por BLORP.eoac. " + persona(c) + "\n"
                + (user.isEmpty() ? "" : "El usuario se llama " + user + "; llámalo así, nunca por tu nombre.\n")
                + "Responde siempre en " + lang + ". Tus respuestas se leen en voz alta: frases cortas, sin listas, sin asteriscos ni símbolos, "
                + "y como mucho unas 4 frases salvo que te pidan más.\n"
                + "REGLAS (más importantes que tu personalidad):\n"
                + "1. No inventes nunca datos. Tu personalidad está en CÓMO hablas, no en lo que afirmas.\n"
                + "2. Si te preguntan por hechos, noticias, precios, fechas, resultados, personas, lugares o cualquier cosa que no sepas con "
                + "seguridad o que pueda haber cambiado, y NO tienes RESULTADOS DE INTERNET, no respondas: escribe SOLO [[buscar: consulta corta]].\n"
                + "3. Si tienes RESULTADOS DE INTERNET, básate en ellos, di de dónde sale (por ejemplo «según Wikipedia») y si no aparece la respuesta, dilo claramente.\n"
                + "4. Si te piden hacer algo en el teléfono, contesta con una frase corta y añade al final [[cmd: orden]] usando UNA de estas órdenes exactas: "
                + "pon <canción o artista> en youtube | pon <canción o artista> en spotify | sube el volumen | baja el volumen | volumen al <número> | silencio | "
                + "pausa | sigue | siguiente | anterior | cuanta bateria me queda | brillo al <número> | sube el brillo | baja el brillo | abre la camara | "
                + "enciende la linterna | apaga la linterna | llama a <nombre> | alarma a las <hora> | temporizador de <número> minutos | abre <app> | "
                + "llevame a <lugar> | activa el wifi | bluetooth | modo avion | pon el no molestar | quita el no molestar. "
                + "Ejemplo: «está muy alto» → «Vale, lo bajo. [[cmd: baja el volumen]]».\n"
                + "5. Si el usuario te cuenta algo de sí mismo y te pide que no lo olvides, añade al final [[recordar: el dato en una frase]].\n"
                + "6. Nunca digas que has hecho algo en el teléfono si no has puesto su [[cmd: …]].\n"
                + "7. Lo que te llega viene de un reconocedor de voz y a veces trae palabras mal oídas: piensa en lo que el usuario QUISO decir. "
                + "«Boom Bad Romance de Lady Gaga» → «Pon Bad Romance de Lady Gaga». «Pum una de rock» → «Pon música rock». "
                + "Si está claro, hazlo sin preguntar. Si de verdad no se entiende, pregunta breve y con gracia: «¿Quisiste decir…?»."
                + Memory.forPrompt(c);
    }

    static final Pattern TAG = Pattern.compile("\\[{1,2}\\s*(cmd|buscar|recordar)\\s*:\\s*(.*?)\\]{1,2}", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    /** La orden para el teléfono que pidió el cerebro (o null). */
    static String cmdOf(String a) {
        if (a == null) return null;
        Matcher m = TAG.matcher(a);
        while (m.find()) if (m.group(1).equalsIgnoreCase("cmd")) return m.group(2).trim();
        return null;
    }
    /** Lo que se dice en voz alta (sin las etiquetas). */
    static String speech(String a) { return a == null ? "" : TAG.matcher(a).replaceAll("").replaceAll("\\s+", " ").trim(); }

    /**
     * Seguro: Chloe nunca se habla a sí misma, así que si la respuesta te llama «Chloe» («¿algo más, Chloe?»),
     * se cambia por tu nombre (o se quita si no lo has puesto).
     */
    static String fixVocative(Context c, String a) {
        if (a == null) return null;
        String bot = java.util.regex.Pattern.quote(botName(c));
        String user = prefs(c).getString("ai_name", "").trim();
        String rep = user.isEmpty() ? "" : user;
        // «…, Chloe.» «…, Chloe?» «…, Chloe!» al final de una frase
        a = a.replaceAll("(?i),\\s*" + bot + "\\s*([.!?…])", rep.isEmpty() ? "$1" : ", " + Matcher.quoteReplacement(rep) + "$1");
        // «Chloe, …» al principio de la respuesta o de una frase
        a = a.replaceAll("(?i)(^|[.!?¡¿]\\s*)" + bot + "\\s*,\\s*", rep.isEmpty() ? "$1" : "$1" + Matcher.quoteReplacement(rep) + ", ");
        // «Claro, Chloe» / «Hola Chloe»
        a = a.replaceAll("(?i)\\b(hola|claro|vale|de acuerdo|por supuesto|buenos dias|buenos días|buenas noches|gracias|perfecto)\\s*,?\\s+" + bot + "\\b",
                rep.isEmpty() ? "$1" : "$1, " + Matcher.quoteReplacement(rep));
        return a;
    }

    static boolean cmdAllowed(String question, String cmd) {
        if (looksLikeOrder(question)) return true;
        String q = Actions.canon(question);
        for (String w : Actions.norm(cmd).split(" "))
            if (w.length() >= 4 && !w.matches("pon|ponme|abre|llama|alarma|sube|baja|enciende|apaga|reproduce|volumen") && q.contains(w)) return true;
        return q.matches(".*\\b(?:musica|cancion|volumen|alarma|despierta|linterna|brillo|llama|abre|pon)\\b.*");
    }

    /** ¿Lo que dijo suena a una orden para el teléfono? */
    static boolean looksLikeOrder(String q) {
        return Actions.canon(q).matches("^(?:pon|ponme|reproduce|abre|llama|manda|envia|escribe|crea|programa|activa|desactiva|enciende|apaga|sube|baja|"
                + "despiertame|despierta|quita|busca|buscame|llevame)\\b.*");
    }

    /** Preguntas de datos: se busca en internet ANTES de contestar, para no inventar. */
    static boolean looksFactual(String q) {
        String s = Actions.norm(q);
        return s.matches(".*\\b(?:quien|quienes|cuando|donde|cuanto|cuanta|cuantos|cuantas|cual|cuales|que es|que son|que significa|que paso|"
                + "por que|porque|como se|como funciona|precio|cuesta|vale|noticias|ultim[oa]s?|hoy|ayer|resultado|gano|perdio|murio|nacio|"
                + "estreno|sale|salio|horario|busca|buscame|investiga|informacion|who|when|where|how much|what is|news|latest|chi|quando|dove|quanto|cos e|"
                + "puedo encontrar|se puede|hay|existe|existen|venden|tienen|sabes si|donde comprar|donde puedo|abierto|abre|cierra|cerca|tienda|supermercado)\\b.*")
                && !s.matches("^(?:como estas|que tal|quien eres|como te llamas|que haces|que puedes hacer).*");
    }

    /** Pregunta (bloquea: llamar desde un hilo aparte). Devuelve la respuesta (puede llevar [[cmd: …]]). */
    static String ask(Context c, String question) {
        lastError = "";
        String rt = WorkDay.handle(c, question);          // v1.3: «¿qué asistencias tengo hoy?»
        if (rt == null) rt = Memory.handle(c, question);  // «recuerda que…», «olvida…», «¿qué recuerdas?»
        if (rt == null) rt = Routines.handle(c, question); // buenos días, buenas noches, la hora, el tiempo, un chiste…
        if (rt != null) return rt;
        String ctx = "";
        if (search(c) && looksFactual(question)) ctx = Web.research(question);
        String ans = generate(c, question, ctx);
        if (ans == null) return failMessage(c);
        // v1.3: si el cerebro pequeño se niega o dice que no sabe sin haber buscado, busca en internet y lo vuelve a intentar
        if (search(c) && ctx.isEmpty() && cmdOf(ans) == null && refused(ans) && !looksLikeOrder(question)) {
            String more = Web.research(question);
            if (!more.isEmpty()) { String again = generate(c, question, more); if (again != null && !refused(again)) ans = again; else if (again != null) ans = again; }
        }
        Matcher m = TAG.matcher(ans);
        String wanted = null;
        while (m.find()) if (m.group(1).equalsIgnoreCase("buscar")) wanted = m.group(2).trim();
        if (wanted != null) {
            if (!search(c)) ans = L.t("Para eso tendría que buscar en internet, y la búsqueda está apagada en los ajustes del asistente.");
            else {
                String more = Web.research(wanted.isEmpty() ? question : wanted);
                if (more.isEmpty()) ans = L.t("He buscado en internet y no he encontrado nada fiable sobre eso.");
                else {
                    String again = generate(c, question, ctx + more);
                    ans = again == null ? failMessage(c) : again.replaceAll("\\[\\[\\s*buscar[^\\]]*\\]\\]", "");
                }
            }
        }
        // una orden que el usuario no ha pedido (los modelos pequeños a veces se la inventan) no se ejecuta
        String cmd0 = cmdOf(ans);
        if (cmd0 != null && !cmdAllowed(question, cmd0)) ans = TAG.matcher(ans).replaceAll("").trim();
        if (cmdOf(ans) == null && handHolding(speech(ans)) && looksLikeOrder(question))
            ans = L.t("Eso todavía no lo sé hacer yo sola. Prueba a decírmelo así: «pon Queen en YouTube», «alarma a las 7», «llama a mamá» o «abre WhatsApp».");
        ans = fixVocative(c, ans);
        Matcher rm = TAG.matcher(ans);
        while (rm.find()) if (rm.group(1).equalsIgnoreCase("recordar")) Memory.add(c, rm.group(2));
        if (speech(ans).isEmpty() && cmdOf(ans) == null) ans = L.t("No se me ocurre qué responder.");
        synchronized (history) {
            history.add(new String[]{"user", question});
            history.add(new String[]{"model", ans});
            while (history.size() > 12) history.remove(0);
        }
        return ans;
    }

    static Fail lastFail;

    /** Instrucciones cortas para el cerebro del teléfono (tiene poco espacio). */
    static String systemShort(Context c) {
        String lang = "es".equals(L.lang) ? "español" : "it".equals(L.lang) ? "italiano" : "English";
        String mem = Memory.forPrompt(c);
        if (mem.length() > 700) mem = mem.substring(0, 700);
        String user = prefs(c).getString("ai_name", "").trim();
        return "Eres " + botName(c) + ", el asistente de voz de la app SSS+, creada por BLORP.eoac. " + persona(c)
                + (user.isEmpty() ? "" : " El usuario se llama " + user + ": llámalo " + user + ". Tú eres " + botName(c) + "; nunca le llames " + botName(c) + ".")
                + " No describas tu voz ni pongas acotaciones entre corchetes. Nunca expliques pasos para usar apps: o lo haces con [[cmd: …]] o dices que aún no sabes."
                + " Responde en " + lang + ", en 1 a 3 frases cortas, sin listas ni símbolos. "
                + "No inventes datos: si te doy RESULTADOS DE INTERNET, úsalos y di de dónde salen; si no sabes algo, dilo. "
                + "Si te piden hacer algo en el teléfono, contesta corto y termina con [[cmd: orden]], por ejemplo "
                + "[[cmd: pon queen en youtube]], [[cmd: pon queen en spotify]], [[cmd: baja el volumen]], [[cmd: sube el volumen]], "
                + "[[cmd: volumen al 50]], [[cmd: pausa]], [[cmd: siguiente]], [[cmd: enciende la linterna]], [[cmd: llama a mama]], "
                + "[[cmd: alarma a las 7]], [[cmd: abre whatsapp]], [[cmd: brillo al 30]]."
                + " Ejemplos. Usuario: me apetece escuchar algo de Queen. Tú: ¡Marchando un poco de Queen! [[cmd: pon queen en youtube]]."
                + " Usuario: despiértame mañana a las siete. Tú: Hecho, a las siete en pie. [[cmd: alarma a las 7]]."
                + " Usuario: ¿quién pintó la Mona Lisa? Tú: Leonardo da Vinci, a principios del siglo XVI."
                + " El texto viene de un reconocedor de voz y puede traer palabras mal oídas: entiende la intención. Usuario: boom bad romance de lady gaga."
                + " Tú: ¡Gaga a todo volumen! [[cmd: pon bad romance de lady gaga en youtube]]. Si no se entiende nada, pregunta corto y con gracia." + mem;
    }

    /** Una respuesta del cerebro elegido (portátil y/o teléfono). null si ninguno pudo. */
    static String generate(Context c, String question, String webCtx) {
        String b = brain(c);
        lastFail = null;
        // 1) portátil (si hay dirección)
        if ((b.equals("auto") || b.equals("pc")) && !pcUrl(c).isEmpty()) {
            try { return ollama(c, system(c), withCtx(question, webCtx)); }
            catch (Exception e) {
                lastError = L.t("Portátil: ") + e.getMessage();
                if (b.equals("pc")) { lastFail = new Fail(-2, String.valueOf(e.getMessage())); return null; }
            }
        }
        if (b.equals("pc")) { lastFail = new Fail(-3, "sin dirección"); return null; }
        // 2) cerebro del teléfono (gratis, sin internet, sin cupos)
        if (b.equals("auto") || b.equals("local")) {
            if (LocalBrain.ready(c)) {
                try {
                    String ctx = webCtx.length() > 1500 ? webCtx.substring(0, 1500) : webCtx;
                    List<String[]> h;
                    synchronized (history) { h = new ArrayList<>(history); }
                    String a = LocalBrain.generate(c, systemShort(c), h, withCtx(question, ctx));
                    if (a != null && !a.trim().isEmpty()) return clean(a);
                } catch (Throwable e) {
                    lastError = L.t("Cerebro del teléfono: ") + e.getMessage();
                }
                if (b.equals("local")) { lastFail = new Fail(-1, L.t("El cerebro del teléfono no ha podido responder. Mira el mensaje escrito abajo.")); return null; }
            } else if (b.equals("local")) {
                lastFail = new Fail(-1, L.t("Primero descarga el cerebro de Chloe en la pantalla del asistente (apartado CEREBRO EN EL TELÉFONO)."));
                return null;
            }
        }
        if (!LocalBrain.ready(c)) { lastFail = null; return null; }
        if (lastFail == null) lastFail = new Fail(-1, L.t("El cerebro del teléfono no ha podido responder. Mira el mensaje escrito abajo."));
        return null;
    }

    static String withCtx(String question, String webCtx) {
        return webCtx.isEmpty() ? question
                : question + "\n\nRESULTADOS DE INTERNET (buscados ahora mismo):\n" + webCtx + "\nResponde a mi pregunta usando estos resultados.";
    }

    static String failMessage(Context c) {
        Fail last = lastFail;
        if (last != null && last.code == -2) return L.t("No consigo hablar con tu portátil. ¿Está encendido, con Ollama abierto y en el mismo wifi?");
        if (last != null && last.code == -3) return L.t("Aún no me has dicho la dirección de tu portátil. Ponla en la pantalla del asistente.");
        if (last != null && last.code == -1) return last.msg;
        if (last == null) return L.t("Aún no tengo cerebro: descárgalo en la pantalla del asistente, apartado CEREBRO EN EL TELÉFONO. Es gratis y sin cupos.");
        return L.t("No he podido responder") + " (" + last.code + ").";
    }

    /** Cerebro en el portátil con Ollama (http://IP:11434). */
    static String ollama(Context c, String sys, String user) throws Exception {
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", sys));
        synchronized (history) {
            for (String[] h : history) msgs.put(new JSONObject().put("role", h[0].equals("model") ? "assistant" : "user").put("content", h[1]));
        }
        msgs.put(new JSONObject().put("role", "user").put("content", user));
        JSONObject body = new JSONObject().put("model", pcModel(c)).put("messages", msgs).put("stream", false).put("keep_alive", "30m")
                .put("options", new JSONObject().put("temperature", 0.7));
        HttpURLConnection con = (HttpURLConnection) new URL(pcUrl(c) + "/api/chat").openConnection();
        con.setRequestMethod("POST");
        con.setConnectTimeout(4000);
        con.setReadTimeout(120000);
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        try (OutputStream os = con.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = con.getResponseCode();
        String resp = read(code >= 400 ? con.getErrorStream() : con.getInputStream());
        con.disconnect();
        if (code >= 400) {
            String msg = resp;
            try { msg = new JSONObject(resp).getString("error"); } catch (Exception ignored) {}
            if (msg.contains("not found")) msg = L.t("el modelo ") + pcModel(c) + L.t(" no está instalado en el portátil (ollama pull ") + pcModel(c) + ")";
            throw new Exception(msg);
        }
        String ans = new JSONObject(resp).getJSONObject("message").optString("content", "");
        ans = ans.replaceAll("(?s)<think>.*?</think>", "");
        return clean(ans);
    }

    /** Prueba la conexión con el portátil: devuelve los modelos instalados o lanza el error. */
    static String pcTest(Context c) throws Exception {
        if (pcUrl(c).isEmpty()) throw new Exception(L.t("escribe primero la dirección"));
        HttpURLConnection con = (HttpURLConnection) new URL(pcUrl(c) + "/api/tags").openConnection();
        con.setConnectTimeout(4000);
        con.setReadTimeout(8000);
        String resp = read(con.getInputStream());
        con.disconnect();
        JSONArray m = new JSONObject(resp).getJSONArray("models");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < m.length(); i++) b.append(i == 0 ? "" : ", ").append(m.getJSONObject(i).getString("name"));
        return b.toString();
    }

    /** Quita símbolos de formato para que la voz no los lea. */
    static String clean(String s) {
        s = fixUtf8(s);
        s = s.replaceAll("\\[(?!\\[|\\s*(?:cmd|buscar|recordar)\\s*:)[^\\]]{0,80}\\]\\s*(?!\\()", "");   // «[Tu voz agradable y calmada]» y similares
        s = s.replaceAll("\\((?:con )?(?:voz|tono|sonr|ri[eé]|susurr)[^)]{0,60}\\)\\s*", "");
        return s.replaceAll("[*#_`>]+", "").replaceAll("\\[(.*?)\\]\\(.*?\\)", "$1").replaceAll("\\s+", " ").trim();
    }

    /** Arregla letras rotas como «menÃº» → «menú» (texto UTF-8 leído como si fuera Latin-1). */
    static String fixUtf8(String s) {
        if (s == null || (s.indexOf('Ã') < 0 && s.indexOf('Â') < 0 && s.indexOf('â') < 0)) return s;
        Matcher m = Pattern.compile("[\\u00C2-\\u00F4][\\u0080-\\u00BF\\u0152\\u0153\\u0160\\u0161\\u0178\\u017D\\u017E\\u0192\\u02C6\\u02DC\\u2013\\u2014\\u2018-\\u201E\\u2020-\\u2022\\u2026\\u2030\\u2039\\u203A\\u20AC\\u2122]{1,3}").matcher(s);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            String g = m.group(), fixed = g;
            try {
                byte[] b = g.getBytes("windows-1252");
                String d = new String(b, StandardCharsets.UTF_8);
                if (!d.contains("\uFFFD")) fixed = d;
            } catch (Exception ignored) {}
            m.appendReplacement(out, Matcher.quoteReplacement(fixed));
        }
        m.appendTail(out);
        return out.toString();
    }

    /** ¿Se ha negado o ha dicho que no sabe? */
    static boolean refused(String a) {
        String n = Actions.norm(speech(a));
        return n.matches(".*\\b(?:lo siento no puedo|no puedo ayudarte|no puedo encontrar|no tengo informacion|no tengo acceso|no dispongo|no se puede|desconozco|no lo se|no estoy segura|te sugiero buscar|te recomiendo buscar|no puedo responder)\\b.*");
    }

    /** ¿El cerebro está dando instrucciones para hacerlo a mano en vez de hacerlo? (los modelos pequeños lo hacen) */
    static boolean handHolding(String a) {
        String n = Actions.norm(a);
        int hits = 0;
        for (String p : new String[]{"haz clic", "pulsa el boton", "presiona el boton", "selecciona", "abre tu aplicacion", "abre la aplicacion", "abre el menu",
                "toca el icono", "en la esquina", "primero abre", "luego selecciona", "introduce", "no puedo reproducir", "no puedo poner", "no puedo abrir"})
            if (n.contains(p)) hits++;
        return hits >= 1;
    }

    static String read(InputStream in) throws java.io.IOException {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }
}
