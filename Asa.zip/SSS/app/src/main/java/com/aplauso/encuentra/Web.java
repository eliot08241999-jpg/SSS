package com.aplauso.encuentra;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Búsqueda propia del asistente (v1.1): busca en internet sin pasar por Google (búsqueda segura desactivada),
 * lee las primeras páginas y se lo da al cerebro para que responda con datos reales.
 * Primero DuckDuckGo; si falla o no da nada, Wikipedia. Bloquea: llamar desde un hilo.
 */
public class Web {
    static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

    static final class Hit {
        final String title, url, snippet;
        Hit(String t, String u, String s) { title = t; url = u; snippet = s; }
    }

    /** Texto listo para dárselo al cerebro: resultados + el contenido de las 2 primeras páginas. */
    static String research(String q) {
        List<Hit> hits = new ArrayList<>();
        try { hits = duck(q); } catch (Exception ignored) {}
        if (hits.isEmpty()) try { hits = wiki(q); } catch (Exception ignored) {}
        if (hits.isEmpty()) return "";
        StringBuilder b = new StringBuilder();
        int n = 0;
        for (Hit h : hits) {
            if (n >= 6) break;
            n++;
            b.append("[").append(n).append("] ").append(h.title).append(" (").append(host(h.url)).append(")\n").append(h.snippet).append("\n");
        }
        int read = 0;
        for (Hit h : hits) {
            if (read >= 2) break;
            if (h.url.isEmpty()) continue;
            try {
                String page = pageText(h.url);
                if (page.length() > 200) {
                    read++;
                    b.append("\n--- ").append(host(h.url)).append(" ---\n").append(page, 0, Math.min(page.length(), 2500)).append("\n");
                }
            } catch (Exception ignored) {}
        }
        return b.toString();
    }

    /** v1.1: el identificador del primer vídeo de YouTube para una búsqueda (null si no se encuentra). */
    static String youtubeId(String q) {
        try {
            String html = get("https://www.youtube.com/results?hl=es&search_query=" + URLEncoder.encode(q, "UTF-8"));
            Matcher m = Pattern.compile("\"videoRenderer\":\\{\"videoId\":\"([A-Za-z0-9_-]{11})\"").matcher(html);
            if (m.find()) return m.group(1);
            m = Pattern.compile("watch\\?v=([A-Za-z0-9_-]{11})").matcher(html);
            if (m.find()) return m.group(1);
        } catch (Exception ignored) {}
        try {      // plan B: buscador
            for (Hit h : duck(q + " youtube")) {
                Matcher m = Pattern.compile("youtube\\.com/watch\\?v=([A-Za-z0-9_-]{11})|youtu\\.be/([A-Za-z0-9_-]{11})").matcher(h.url);
                if (m.find()) return m.group(1) != null ? m.group(1) : m.group(2);
            }
        } catch (Exception ignored) {}
        return null;
    }

    static String host(String u) {
        try { return new URL(u).getHost().replaceFirst("^www\\.", ""); } catch (Exception e) { return u; }
    }

    static List<Hit> duck(String q) throws Exception {
        String html = get("https://html.duckduckgo.com/html/?kp=-2&kl=" + region() + "&q=" + URLEncoder.encode(q, "UTF-8"));
        List<Hit> out = new ArrayList<>();
        Matcher a = Pattern.compile("class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>", Pattern.DOTALL).matcher(html);
        Matcher sn = Pattern.compile("class=\"result__snippet\"[^>]*>(.*?)</a>", Pattern.DOTALL).matcher(html);
        while (a.find()) {
            String href = a.group(1).replace("&amp;", "&");
            int i = href.indexOf("uddg=");
            if (i >= 0) {
                String enc = href.substring(i + 5);
                int amp = enc.indexOf('&');
                href = URLDecoder.decode(amp >= 0 ? enc.substring(0, amp) : enc, "UTF-8");
            } else if (href.startsWith("//")) href = "https:" + href;
            if (href.contains("duckduckgo.com/y.js")) continue;      // anuncios
            String snip = sn.find() ? strip(sn.group(1)) : "";
            out.add(new Hit(strip(a.group(2)), href, snip));
        }
        return out;
    }

    static String region() { return "en".equals(L.lang) ? "us-en" : "it".equals(L.lang) ? "it-it" : "es-es"; }

    static List<Hit> wiki(String q) throws Exception {
        String lang = Wake.lang();
        JSONObject o = new JSONObject(get("https://" + lang + ".wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=4&srsearch="
                + URLEncoder.encode(q, "UTF-8")));
        JSONArray r = o.getJSONObject("query").getJSONArray("search");
        List<Hit> out = new ArrayList<>();
        for (int i = 0; i < r.length(); i++) {
            JSONObject h = r.getJSONObject(i);
            String t = h.getString("title");
            out.add(new Hit(t, "https://" + lang + ".wikipedia.org/wiki/" + URLEncoder.encode(t.replace(' ', '_'), "UTF-8"), strip(h.optString("snippet"))));
        }
        return out;
    }

    /** Texto legible de una página (sin scripts, menús ni etiquetas). */
    static String pageText(String url) throws Exception {
        String h = get(url);
        h = h.replaceAll("(?is)<(script|style|noscript|nav|header|footer|aside|form|svg)[^>]*>.*?</\\1>", " ");
        Matcher m = Pattern.compile("(?is)<(?:p|h1|h2|h3|li|td)[^>]*>(.*?)</(?:p|h1|h2|h3|li|td)>").matcher(h);
        StringBuilder b = new StringBuilder();
        while (m.find() && b.length() < 6000) {
            String t = strip(m.group(1));
            if (t.length() > 30) b.append(t).append('\n');
        }
        return b.toString();
    }

    static String strip(String s) {
        return s.replaceAll("(?s)<[^>]+>", "").replace("&amp;", "&").replace("&quot;", "\"").replace("&#x27;", "'").replace("&#39;", "'")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ").replaceAll("\\s+", " ").trim();
    }

    static String get(String u) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(u).openConnection();
        con.setConnectTimeout(8000);
        con.setReadTimeout(10000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", UA);
        con.setRequestProperty("Accept-Language", L.lang + ",en;q=0.5");
        try {
            String ct = con.getContentType();
            if (ct != null && !ct.contains("html") && !ct.contains("json") && !ct.contains("text")) return "";
            return Brain.read(con.getInputStream());
        } finally { con.disconnect(); }
    }
}
