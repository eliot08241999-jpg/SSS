package com.aplauso.encuentra;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * ASISTENTE SSS+ (v0.9.2): habla con Gemini con la voz que tú elijas.
 * - Se abre desde Ajustes, desde su notificación o como "asistente digital" del teléfono (mantener pulsado Inicio).
 * - Con la palabra clave activada ("paradoja"), te escucha aunque la app esté cerrada.
 */
public class AssistActivity extends NeonActivity {
    static final int REQ_SPEAK = 71, REQ_MIC = 72;
    TextView log, modelState, voiceBtn, engineBtn;
    Switch wakeSw;
    final StringBuilder chat = new StringBuilder();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🐑 ASISTENTE SSS+");
        Voice.init(this, null);

        // ---------- hablar ----------
        LinearLayout talk = panel("◢ HABLAR");
        log = text(L.t("Pregúntame lo que quieras. Respondo con Gemini y con la voz que elijas abajo."), 14);
        talk.addView(log);
        EditText in = edit("Escribe tu pregunta…", false);
        talk.addView(spaced(in));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams h1 = new LinearLayout.LayoutParams(0, -2, 1);
        h1.rightMargin = dpi(6);
        row.addView(button("🎤 HABLAR", v -> listen()), h1);
        row.addView(button("➤ ENVIAR", v -> {
            String q = in.getText().toString().trim();
            if (!q.isEmpty()) { in.setText(""); ask(q); }
        }), new LinearLayout.LayoutParams(0, -2, 1));
        talk.addView(spaced(row));
        talk.addView(spaced(button("⏹ CALLAR", v -> Voice.stop())));
        col.addView(talk, gapBelow(14));

        // ---------- cerebro ----------
        LinearLayout br = panel("◢ CEREBRO: GEMINI");
        br.addView(text("Necesitas tu propia clave gratuita de Gemini: entra en aistudio.google.com/apikey con tu cuenta de Google, "
                + "pulsa «Create API key», cópiala y pégala aquí. Se guarda solo en este teléfono.", 13));
        br.addView(spaced(button("🔑 CONSEGUIR MI CLAVE", v -> open("https://aistudio.google.com/apikey"))));
        br.addView(spaced(edit("Clave de Gemini (API key)", true, "ai_key")));
        br.addView(text(L.t("Modelo (déjalo vacío para usar ") + Brain.DEFAULT_MODEL + ")", 12));
        br.addView(edit(Brain.DEFAULT_MODEL, false, "ai_model"));
        br.addView(spaced(text("Personalidad: cómo quieres que sea y cómo te trate.", 12)));
        EditText per = edit(Brain.DEFAULT_PERSONA, false, "ai_persona");
        per.setMinLines(3);
        per.setSingleLine(false);
        br.addView(per);
        Switch web = neonSwitch("Buscar en internet (Google) para responder");
        web.setChecked(Brain.search(this));
        web.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("ai_search", on).apply());
        br.addView(web);
        br.addView(spaced(button("🧹 OLVIDAR LA CONVERSACIÓN", v -> { synchronized (Brain.history) { Brain.history.clear(); } toast(L.t("Conversación borrada")); })));
        col.addView(br, gapBelow(14));

        // ---------- voz ----------
        LinearLayout vo = panel("◢ VOZ");
        vo.addView(text("Usa los motores de voz instalados en el teléfono. Para tener más voces, instala otro motor "
                + "desde Play Store (busca «texto a voz» o «TTS») y elígelo aquí.", 13));
        engineBtn = button("", v -> pickEngine());
        voiceBtn = button("", v -> pickVoice());
        vo.addView(spaced(engineBtn));
        vo.addView(spaced(voiceBtn));
        slider(vo, "Tono", "tts_pitch", 100, 50, 200, " %", v -> Voice.apply(this));
        slider(vo, "Velocidad", "tts_rate", 100, 50, 200, " %", v -> Voice.apply(this));
        vo.addView(spaced(button("▶ PROBAR LA VOZ", v -> Voice.say(this, L.t("Hola, soy el asistente de SSS+. ¿En qué te ayudo?")))));
        vo.addView(spaced(button("➕ CONSEGUIR MÁS VOCES", v -> open("market://search?q=text to speech voices"))));
        vo.addView(spaced(button("⚙ AJUSTES DE VOZ DEL TELÉFONO", v -> {
            try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); } catch (Exception e) { toast(L.t("Este teléfono no tiene ese ajuste")); }
        })));
        col.addView(vo, gapBelow(14));
        refreshVoiceLabels();

        // ---------- palabra clave ----------
        LinearLayout wk = panel("◢ PALABRA CLAVE");
        wk.addView(text("Di la palabra clave y luego tu pregunta, sin tocar el teléfono. Funciona sin internet "
                + "(solo la pregunta, ya escrita, se manda a Gemini). Usa palabras normales del idioma: una palabra larga "
                + "y poco común (como «paradoja») o dos o tres palabras. Las palabras cortas se disparan solas más a menudo.", 13));
        wk.addView(spaced(text(L.t("Frase (vacía = «") + Wake.info()[2] + "»)", 12)));
        wk.addView(edit(Wake.info()[2], false, "ai_phrase"));
        modelState = text("", 12);
        wk.addView(spaced(modelState));
        wk.addView(spaced(button("⬇ DESCARGAR EL OÍDO (≈40 MB, una vez)", v -> download())));
        wakeSw = neonSwitch("Escuchar siempre la palabra clave");
        wakeSw.setChecked(Wake.enabled(this));
        wakeSw.setOnCheckedChangeListener((v, on) -> {
            if (on && !Wake.downloaded(this)) { wakeSw.setChecked(false); toast(L.t("Primero descarga el oído")); return; }
            if (on && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(Build.VERSION.SDK_INT >= 33 ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                        : new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            }
            p.edit().putBoolean("ai_wake", on).apply();
            if (on) ShieldService.start(this);
            else if (!ShieldService.needed(this)) ShieldService.stopAll(this);
            refreshModel();
        });
        wk.addView(wakeSw);
        wk.addView(text("Gasta algo más de batería mientras escucha. Se pausa sola si otra app usa el micrófono.", 11));
        col.addView(wk, gapBelow(14));
        refreshModel();

        // ---------- asistente del teléfono ----------
        LinearLayout ph = panel("◢ COMO ASISTENTE DEL TELÉFONO");
        ph.addView(text("Para que SSS+ se abra al mantener pulsado el botón de inicio en lugar de Google o Gemini: "
                + "Ajustes → Aplicaciones → Aplicaciones predeterminadas → Asistente digital → SSS+.", 13));
        ph.addView(spaced(button("📲 ABRIR APPS PREDETERMINADAS", v -> {
            try { startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        })));
        ph.addView(text("Junto con «Silenciar Ok Google» (en Ajustes), el teléfono solo te hará caso a ti con tu palabra clave.", 11));
        col.addView(ph, gapBelow(14));

        String a = getIntent() == null ? null : getIntent().getAction();
        if (Intent.ACTION_ASSIST.equals(a) || "android.intent.action.VOICE_COMMAND".equals(a)) h.postDelayed(this::listen, 500);
    }

    // ------------------------------------------------------------------ conversación
    void say(String who, String s) {
        if (chat.length() > 0) chat.append("\n\n");
        chat.append(who).append(" ").append(s);
        log.setText(chat.toString());
    }

    void ask(String q) {
        say("🗣", q);
        say("🐑", L.t("Pensando…"));
        int mark = chat.lastIndexOf("🐑");
        new Thread(() -> {
            String ans = Brain.ask(this, q);
            runOnUiThread(() -> {
                chat.setLength(mark);
                chat.append("🐑 ").append(ans);
                log.setText(chat.toString());
                Voice.say(this, ans);
            });
        }, "cerebro").start();
    }

    /** Usa el reconocedor de voz del teléfono; mientras tanto, la escucha de SSS+ suelta el micrófono. */
    void listen() {
        Voice.stop();
        ShieldService.yieldMic = true;
        h.postDelayed(() -> ShieldService.yieldMic = false, 30000);       // seguridad: nunca más de 30 s
        h.postDelayed(() -> {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en".equals(L.lang) ? "en-US" : "it".equals(L.lang) ? "it-IT" : "es-ES");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, L.t("Te escucho…"));
            try { startActivityForResult(i, REQ_SPEAK); }
            catch (Exception e) { ShieldService.yieldMic = false; toast(L.t("Este teléfono no tiene reconocimiento de voz. Escribe tu pregunta.")); }
        }, 1200);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_SPEAK) {
            ShieldService.yieldMic = false;
            if (res == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) ask(r.get(0));
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    protected void onDestroy() {
        ShieldService.yieldMic = false;
        super.onDestroy();
    }

    // ------------------------------------------------------------------ voz
    void refreshVoiceLabels() {
        String e = p.getString("tts_engine", "");
        engineBtn.setText(L.t("Motor: ") + (e.isEmpty() ? L.t("el del teléfono") : e));
        String v = p.getString("tts_voice", "");
        voiceBtn.setText(L.t("Voz: ") + (v.isEmpty() ? L.t("la de por defecto") : v));
    }

    void pickEngine() {
        if (Voice.tts == null) { toast(L.t("Cargando las voces… prueba otra vez")); Voice.init(this, null); return; }
        List<TextToSpeech.EngineInfo> eng = Voice.tts.getEngines();
        String[] names = new String[eng.size() + 1];
        names[0] = L.t("El del teléfono (por defecto)");
        for (int i = 0; i < eng.size(); i++) names[i + 1] = eng.get(i).label + "  (" + eng.get(i).name + ")";
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Motor de voz")).setItems(names, (d, w) -> {
            p.edit().putString("tts_engine", w == 0 ? "" : eng.get(w - 1).name).putString("tts_voice", "").apply();
            Voice.init(this, () -> runOnUiThread(this::refreshVoiceLabels));
            refreshVoiceLabels();
        }).show();
    }

    void pickVoice() {
        if (Voice.tts == null || !Voice.ready) { toast(L.t("Cargando las voces… prueba otra vez")); Voice.init(this, null); return; }
        String want = "en".equals(L.lang) ? "en" : "it".equals(L.lang) ? "it" : "es";
        List<android.speech.tts.Voice> list = new ArrayList<>();
        try {
            for (android.speech.tts.Voice v : Voice.tts.getVoices())
                if (v.getLocale() != null && want.equals(v.getLocale().getLanguage())) list.add(v);
        } catch (Exception ignored) {}
        if (list.isEmpty()) { toast(L.t("Este motor no tiene voces en tu idioma")); return; }
        list.sort((a, b) -> a.getName().compareTo(b.getName()));
        String[] names = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            android.speech.tts.Voice v = list.get(i);
            names[i] = v.getName() + (v.isNetworkConnectionRequired() ? "  🌐" : "") + "  · " + v.getLocale().getDisplayCountry();
        }
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Elige una voz")).setItems(names, (d, w) -> {
            p.edit().putString("tts_voice", list.get(w).getName()).apply();
            Voice.apply(this);
            refreshVoiceLabels();
            Voice.say(this, L.t("Esta es mi nueva voz."));
        }).show();
    }

    // ------------------------------------------------------------------ palabra clave
    void refreshModel() {
        if (modelState == null) return;
        modelState.setText(Wake.downloaded(this)
                ? L.t("✓ Oído descargado. Di «") + Wake.phrase(this) + L.t("» y luego tu pregunta.")
                : L.t("Falta descargar el oído (solo una vez, con wifi mejor)."));
    }

    void download() {
        modelState.setText(L.t("Empezando la descarga…"));
        new Thread(() -> {
            boolean ok = Wake.download(this, (pc, msg) -> runOnUiThread(() -> modelState.setText(msg + (pc >= 0 && pc < 100 ? "  " + pc + " %" : ""))));
            runOnUiThread(() -> { if (ok) refreshModel(); });
        }, "descarga").start();
    }

    // ------------------------------------------------------------------ utilidades
    EditText edit(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(L.t(hint));
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setTextSize(15);
        e.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        e.setBackground(frame(dp(10)));
        e.setPadding(dpi(12), dpi(10), dpi(12), dpi(10));
        e.setSingleLine(true);
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    /** Campo de texto que se guarda solo en los ajustes. */
    EditText edit(String hint, boolean secret, String key) {
        EditText e = edit(hint, secret);
        e.setText(p.getString(key, ""));
        e.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) {
                p.edit().putString(key, s.toString()).apply();
                if (key.equals("ai_phrase")) refreshModel();
            }
        });
        return e;
    }

    android.view.View spaced(android.view.View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dpi(8);
        v.setLayoutParams(lp);
        return v;
    }

    void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { toast(url); }
    }
}
