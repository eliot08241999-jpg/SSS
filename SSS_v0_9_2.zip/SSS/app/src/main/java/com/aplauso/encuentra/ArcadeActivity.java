package com.aplauso.encuentra;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

/** Pantalla completa para los juegos arcade (Torre, Gato, Pastor y el pack retro). */
public class ArcadeActivity extends Activity {
    GameKit.GameView game;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String id = getIntent().getStringExtra("game");
        if ("runner".equals(id)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            game = new RunnerView(this);
        } else if ("eco".equals(id)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            game = new EcoView(this);
        } else if ("race".equals(id) || "tank".equals(id) || "shoot".equals(id) || "frog".equals(id) || "fill".equals(id)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            game = "race".equals(id) ? new Retro.Race(this) : "tank".equals(id) ? new Retro.Tank(this)
                    : "shoot".equals(id) ? new Retro.Shooter(this) : "frog".equals(id) ? new Retro.Frog(this) : new Retro.Fill(this);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            game = new TowerView(this);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        game.setBackgroundColor(Color.BLACK);
        setContentView(game);
        hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    protected void onResume() {
        super.onResume();
        game.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        game.pause();
    }

    // Mando externo / teclado: se reenvía al juego si está activado en sus ajustes
    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getKeyCode() != KeyEvent.KEYCODE_BACK && game != null && game.handleKey(e)) return true;
        return super.dispatchKeyEvent(e);
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent e) {
        if (game != null && game.handleMotion(e)) return true;
        return super.dispatchGenericMotionEvent(e);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (game instanceof Backable && ((Backable) game).onBack()) return;
        super.onBackPressed();
    }

    /** Los juegos pueden usar "atrás" para abrir su menú de pausa. */
    interface Backable { boolean onBack(); }
}
