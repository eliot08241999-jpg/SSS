package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Palabra clave del asistente (v0.9.2), sin internet: usa Vosk con un modelo pequeño de voz (≈40 MB)
 * que se descarga una vez. Escucha SOLO la palabra elegida ("paradoja"); al oírla, escucha la pregunta
 * y la pasa al cerebro (Gemini). Nada del audio sale del teléfono: a Gemini solo se le manda el texto.
 */
public class Wake {
    interface Listener { void onWake(); void onQuestion(String text); }

    static final String[][] MODELS = {
            {"es", "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip", "paradoja"},
            {"en", "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip", "paradox"},
            {"it", "https://alphacephei.com/vosk/models/vosk-model-small-it-0.22.zip", "paradosso"},
    };

    static volatile Listener listener;
    static Model model;
    static String modelLang;
    static Recognizer wakeRec, askRec;
    static String wakeFor;
    static volatile boolean asking;
    static long askStart;
    static float[] resampleCarry;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static boolean enabled(Context c) { return prefs(c).getBoolean("ai_wake", false); }
    static String lang() { return "en".equals(L.lang) || "it".equals(L.lang) ? L.lang : "es"; }
    static String[] info() { for (String[] m : MODELS) if (m[0].equals(lang())) return m; return MODELS[0]; }
    static String phrase(Context c) {
        String s = prefs(c).getString("ai_phrase", "").trim().toLowerCase(java.util.Locale.ROOT);
        return s.isEmpty() ? info()[2] : s;
    }
    static File dir(Context c) { return new File(c.getFilesDir(), "vosk-" + lang()); }
    static boolean downloaded(Context c) { return new File(dir(c), "am").exists() || new File(dir(c), "conf").exists(); }

    /** ¿Está todo listo para escuchar la palabra clave? */
    static boolean ready(Context c) { return enabled(c) && downloaded(c); }

    interface Progress { void at(int percent, String msg); }

    /** Descarga y descomprime el modelo de voz (bloquea: llamar desde un hilo). */
    static boolean download(Context c, Progress pr) {
        File out = dir(c);
        try {
            HttpURLConnection con = (HttpURLConnection) new URL(info()[1]).openConnection();
            con.setConnectTimeout(20000);
            con.setReadTimeout(60000);
            con.setInstanceFollowRedirects(true);
            long total = con.getContentLengthLong();
            File tmp = new File(c.getCacheDir(), "vosk.zip");
            try (InputStream in = con.getInputStream(); FileOutputStream fo = new FileOutputStream(tmp)) {
                byte[] b = new byte[65536];
                long got = 0;
                int n, last = -1;
                while ((n = in.read(b)) > 0) {
                    fo.write(b, 0, n);
                    got += n;
                    int pc = total > 0 ? (int) (got * 90 / total) : 0;
                    if (pc != last) { last = pc; pr.at(pc, L.t("Descargando la voz… ") + (got >> 20) + " MB"); }
                }
            }
            con.disconnect();
            pr.at(92, L.t("Descomprimiendo…"));
            deleteAll(out);
            out.mkdirs();
            try (ZipInputStream z = new ZipInputStream(new java.io.FileInputStream(tmp))) {
                ZipEntry e;
                byte[] b = new byte[65536];
                while ((e = z.getNextEntry()) != null) {
                    String name = e.getName();
                    int slash = name.indexOf('/');
                    if (slash < 0) continue;
                    name = name.substring(slash + 1);          // quita la carpeta "vosk-model-small-xx/"
                    if (name.isEmpty() || name.contains("..")) continue;
                    File f = new File(out, name);
                    if (e.isDirectory()) { f.mkdirs(); continue; }
                    f.getParentFile().mkdirs();
                    try (FileOutputStream fo = new FileOutputStream(f)) {
                        int n;
                        while ((n = z.read(b)) > 0) fo.write(b, 0, n);
                    }
                }
            }
            tmp.delete();
            close();
            pr.at(100, L.t("¡Listo!"));
            return downloaded(c);
        } catch (Exception e) {
            pr.at(-1, L.t("No se pudo descargar: ") + e.getMessage());
            return false;
        }
    }

    static void deleteAll(File f) {
        if (f.isDirectory()) { File[] k = f.listFiles(); if (k != null) for (File x : k) deleteAll(x); }
        f.delete();
    }

    /** Prepara el modelo y el reconocedor de la palabra clave. */
    static synchronized boolean prepare(Context c) {
        if (!ready(c)) return false;
        try {
            if (model == null || !lang().equals(modelLang)) {
                close();
                model = new Model(dir(c).getAbsolutePath());
                modelLang = lang();
            }
            String ph = phrase(c);
            if (wakeRec == null || !ph.equals(wakeFor)) {
                if (wakeRec != null) wakeRec.close();
                wakeRec = new Recognizer(model, 16000f, "[\"" + ph.replace("\"", "") + "\", \"[unk]\"]");
                wakeFor = ph;
            }
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    static synchronized void close() {
        if (wakeRec != null) wakeRec.close();
        if (askRec != null) askRec.close();
        if (model != null) model.close();
        wakeRec = askRec = null;
        model = null;
        asking = false;
    }

    /** Le pasa audio (de cualquier frecuencia) al detector. */
    static synchronized void feed(Context c, short[] buf, int n, int rate) {
        if (wakeRec == null || n <= 0) return;
        if (Voice.speaking) return;                 // que no se escuche a sí mismo
        short[] s = rate == 16000 ? buf : resample(buf, n, rate);
        int len = rate == 16000 ? n : s.length;
        try {
            if (!asking) {
                if (wakeRec.acceptWaveForm(s, len)) check(c, wakeRec.getResult());
                else checkPartial(c, wakeRec.getPartialResult());
            } else {
                boolean end = askRec.acceptWaveForm(s, len);
                long t = System.currentTimeMillis();
                if (end || t - askStart > 9000) {
                    String q = text(end ? askRec.getResult() : askRec.getFinalResult());
                    if (q.isEmpty() && !end) q = text(askRec.getFinalResult());
                    if (!q.isEmpty() || t - askStart > 9000) {
                        asking = false;
                        askRec.close();
                        askRec = null;
                        wakeRec.reset();
                        Listener l = listener;
                        if (l != null && !q.isEmpty()) l.onQuestion(q);
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    static void checkPartial(Context c, String json) {
        String t = text(json, "partial");
        if (t.contains(wakeFor)) { wakeRec.reset(); startAsking(); }
    }

    static void check(Context c, String json) {
        if (text(json).contains(wakeFor)) startAsking();
    }

    static void startAsking() {
        try {
            askRec = new Recognizer(model, 16000f);
            asking = true;
            askStart = System.currentTimeMillis();
            Listener l = listener;
            if (l != null) l.onWake();
        } catch (Throwable ignored) {}
    }

    static String text(String json) { return text(json, "text"); }
    static String text(String json, String key) {
        try { return new JSONObject(json).optString(key, "").trim(); } catch (Exception e) { return ""; }
    }

    /** Cambia la frecuencia a 16 kHz (interpolación lineal sencilla). */
    static short[] resample(short[] in, int n, int rate) {
        int outN = (int) ((long) n * 16000 / rate);
        short[] out = new short[outN];
        double step = (double) rate / 16000;
        for (int i = 0; i < outN; i++) {
            double x = i * step;
            int a = (int) x;
            int b = Math.min(n - 1, a + 1);
            double f = x - a;
            out[i] = (short) (in[a] * (1 - f) + in[b] * f);
        }
        return out;
    }
}
