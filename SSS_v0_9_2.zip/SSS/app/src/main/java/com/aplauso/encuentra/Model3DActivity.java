package com.aplauso.encuentra;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Visor y editor 3D: abre STL, OBJ, FBX, GLB/glTF y VRM.
 * Modos: VER (girar, zoom), HUESOS (plantilla humanoide, añadir, mover, posar, renombrar, padre, borrar),
 * PESOS (automáticos y pincel), TEXTURA (pintar, cambiar imagen, color de cada parte) y GUARDAR
 * (GLB con huesos y texturas, VRM, OBJ, STL, FBX) en la carpeta SSS+/3D.
 */
public class Model3DActivity extends Activity {
    static final int REQ_OPEN = 70, REQ_IMAGE = 72;
    static final int M_VIEW = 0, M_BONES = 1, M_WEIGHTS = 2, M_PAINT = 3;
    static final int T_SELECT = 0, T_MOVE = 1, T_POSE = 2;

    Editor view;
    Model3D model;
    String name = "";
    String status = "Cargando…";
    boolean reduced;                 // modelo enorme: se cargó reducido
    int mode = M_VIEW, tool = T_SELECT, sel = -1;
    boolean brushAdd = true, painting = true;
    int brushSize = 2;               // 1..4
    int paintColor = Color.rgb(255, 80, 120);
    int imagePart = 0;
    boolean dirty;                   // hay cambios sin guardar

    // texturas: versión para ver (reducida) y versión completa (al pintar)
    Bitmap[] texView = new Bitmap[0], texFull = new Bitmap[0];
    BitmapShader[] shaders = new BitmapShader[0];
    boolean[] texDirty = new boolean[0];

    static void explainUnsupported(Context c, String ext) {
        String msg = "blend".equals(ext)
                ? "Los archivos .blend son el formato interno de Blender: es cerrado y muy complejo, así que solo Blender puede abrirlos.\n\n"
                + "Solución: en Blender ve a Archivo → Exportar → FBX, glTF, STL u OBJ, y abre ese archivo aquí."
                : "El formato ." + ext + " todavía no se puede abrir en SSS+.\n\nExpórtalo como FBX, GLB, STL u OBJ desde tu programa 3D y ábrelo aquí.";
        new AlertDialog.Builder(c).setTitle(L.t("🧊 Formato ." + ext)).setMessage(L.t(msg)).setPositiveButton(L.t("Entendido"), null).show();
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        L.init(this);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        view = new Editor(this);
        setContentView(view);
        Uri u = getIntent().getData();
        if (u != null) load(u);
        else pick();
    }

    void toast(String s) { Toast.makeText(this, L.t(s), Toast.LENGTH_LONG).show(); }

    void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_OPEN);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (dirty && model != null) {
            new AlertDialog.Builder(this).setTitle(L.t("¿Salir sin guardar?"))
                    .setMessage(L.t("Tienes cambios en el modelo que aún no has guardado."))
                    .setPositiveButton(L.t("💾 Guardar"), (d, w) -> saveMenu())
                    .setNegativeButton(L.t("Salir"), (d, w) -> finish())
                    .setNeutralButton(L.t("Cancelar"), null).show();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_IMAGE) {
            if (res == RESULT_OK && data != null && data.getData() != null) replaceTexture(data.getData());
            return;
        }
        if (req != REQ_OPEN) return;
        if (res != RESULT_OK || data == null || data.getData() == null) { if (model == null) finish(); return; }
        load(data.getData());
    }

    // =====================================================================
    // Cargar
    // =====================================================================
    void load(Uri u) {
        String nm = Media.nameOf(this, u);
        String ext = Archive.ext(nm);
        if (!Arrays.asList(Mesh3D.READ_EXT).contains(ext)) {
            if (Arrays.asList(FilesActivity.M3D_OTHER).contains(ext)) explainUnsupported(this, ext);
            else toast("Elige un archivo .stl, .obj, .fbx, .glb, .gltf o .vrm");
            if (model == null) status = "Abre un archivo .stl, .obj, .fbx, .glb o .vrm";
            view.invalidate();
            return;
        }
        status = "Cargando " + nm + "…";
        view.invalidate();
        new Thread(() -> {
            try (InputStream in = getContentResolver().openInputStream(u)) {
                byte[] data = DocIO.readAll(in);
                Model3D m;
                boolean red = false;
                try {
                    m = Model3D.load(data, nm);
                } catch (OutOfMemoryError oom) {          // modelos gigantes: versión reducida para ver
                    m = Model3D.fromSoup(Mesh3D.load(data, nm));
                    red = true;
                }
                Model3D fm = m;
                boolean fr = red;
                Bitmap[] views = decodeTextures(fm);
                runOnUiThread(() -> {
                    model = fm;
                    name = nm;
                    reduced = fr;
                    sel = -1;
                    dirty = false;
                    texView = views;
                    texFull = new Bitmap[views.length];
                    texDirty = new boolean[views.length];
                    rebuildShaders();
                    status = "";
                    view.fit();
                });
            } catch (Throwable t) {
                runOnUiThread(() -> { status = "No se pudo abrir: " + (t instanceof OutOfMemoryError ? "el modelo es demasiado grande" : t.getMessage()); view.invalidate(); });
            }
        }).start();
    }

    /** Texturas reducidas (máx. 1024 px) solo para verlas. */
    static Bitmap[] decodeTextures(Model3D m) {
        Bitmap[] out = new Bitmap[m.textures.size()];
        for (int i = 0; i < out.length; i++) {
            byte[] d = m.textures.get(i).data;
            if (d == null || d.length == 0) continue;
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(d, 0, d.length, o);
                int s = 1;
                while (Math.max(o.outWidth, o.outHeight) / s > 1024) s *= 2;
                o = new BitmapFactory.Options();
                o.inSampleSize = s;
                o.inMutable = true;
                out[i] = BitmapFactory.decodeByteArray(d, 0, d.length, o);
            } catch (Throwable ignored) {}
        }
        return out;
    }

    void rebuildShaders() {
        shaders = new BitmapShader[texView.length];
        for (int i = 0; i < texView.length; i++)
            if (texView[i] != null) shaders[i] = new BitmapShader(texView[i], Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
    }

    /** Versión completa y editable de una textura (para pintar sin perder calidad). */
    Bitmap fullTex(int t) {
        if (texFull[t] != null) return texFull[t];
        byte[] d = model.textures.get(t).data;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inMutable = true;
            texFull[t] = d == null || d.length == 0 ? null : BitmapFactory.decodeByteArray(d, 0, d.length, o);
        } catch (OutOfMemoryError e) {
            texFull[t] = null;
        }
        if (texFull[t] == null) texFull[t] = texView[t];       // sin memoria: se pinta sobre la reducida
        return texFull[t];
    }

    // =====================================================================
    // Guardar (en SSS+/3D)
    // =====================================================================
    void saveMenu() {
        if (model == null) { toast("Primero abre un modelo"); return; }
        String[] opts = {"GLB (con huesos y texturas · Blender, Unity…)", "VRM (avatar: VRoid, VSeeFace, VRChat…)",
                "FBX (solo forma)", "OBJ (solo forma)", "STL (impresión 3D)", "PNG (las texturas)"};
        new AlertDialog.Builder(this).setTitle(L.t("💾 Guardar en SSS+/3D")).setItems(L.ta(opts), (d, w) -> {
            if (w == 1) vrmDialog();
            else if (w == 5) saveTextures();
            else export(new String[]{"glb", "", "fbx", "obj", "stl"}[w]);
        }).show();
    }

    void vrmDialog() {
        List<String> miss = model.missingHuman();
        if (!miss.isEmpty()) {
            new AlertDialog.Builder(this).setTitle(L.t("Falta el esqueleto humanoide"))
                    .setMessage(L.t("Para un VRM hace falta un esqueleto humano con estos huesos: ") + miss
                            + L.t("\n\nEn 🦴 HUESOS pulsa 🧍 PLANTILLA para crearlo de un toque y ajusta las articulaciones. "
                            + "Si el modelo ya tiene huesos, asígnalos en ⋯ MÁS → Hueso humanoide."))
                    .setPositiveButton(L.t("Entendido"), null).show();
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40, 10, 40, 0);
        EditText title = new EditText(this);
        title.setHint(L.t("Nombre del avatar"));
        title.setText(model.title);
        EditText author = new EditText(this);
        author.setHint(L.t("Autor"));
        String au = model.author == null || model.author.isEmpty()
                ? getSharedPreferences("cfg", MODE_PRIVATE).getString("vrm_author", "BLORP.eoac") : model.author;
        author.setText(au);
        box.addView(title);
        box.addView(author);
        new AlertDialog.Builder(this).setTitle(L.t("🧍 Guardar como VRM")).setView(box)
                .setMessage(L.t("El personaje debe estar en pose de T (brazos abiertos) para que el avatar se mueva bien."))
                .setPositiveButton(L.t("💾 Guardar"), (d, w) -> {
                    model.title = title.getText().toString().trim().isEmpty() ? model.title : title.getText().toString().trim();
                    model.author = author.getText().toString().trim();
                    getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("vrm_author", model.author).apply();
                    export("vrm");
                }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    void export(String ext) {
        status = "Guardando ." + ext + "…";
        view.invalidate();
        commitTextures();
        String base = baseName();
        new Thread(() -> {
            try {
                byte[] bytes = model.export(ext);
                Uri u = Media.saveBytes(this, bytes, Media.SUB_3D, base + "." + ext, "model/" + (ext.equals("vrm") ? "gltf-binary" : ext));
                runOnUiThread(() -> {
                    status = "";
                    if (u != null) dirty = false;
                    view.invalidate();
                    toast(u != null ? "✅ Guardado en " + Media.where(this, Media.SUB_3D) + ": " + base + "." + ext
                            + (reduced ? " (versión reducida)" : "") : "No se pudo guardar");
                });
            } catch (Throwable t) {
                runOnUiThread(() -> { status = ""; view.invalidate(); toast("No se pudo guardar: " + (t instanceof OutOfMemoryError ? "falta memoria" : t.getMessage())); });
            }
        }).start();
    }

    String baseName() {
        String b = model != null && model.title != null && !model.title.isEmpty() ? model.title : name;
        if (b.contains(".")) b = b.substring(0, b.lastIndexOf('.'));
        return b.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    /** Pasa las texturas pintadas al modelo (PNG). */
    void commitTextures() {
        for (int i = 0; i < texDirty.length; i++) {
            if (!texDirty[i]) continue;
            Bitmap b = texFull[i] != null ? texFull[i] : texView[i];
            if (b == null) continue;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.PNG, 100, bos);
            model.textures.get(i).data = bos.toByteArray();
            model.textures.get(i).mime = "image/png";
            texDirty[i] = false;
        }
    }

    void saveTextures() {
        commitTextures();
        if (model.textures.isEmpty()) { toast("Este modelo no tiene texturas"); return; }
        int ok = 0;
        for (int i = 0; i < model.textures.size(); i++) {
            Model3D.Tex t = model.textures.get(i);
            String ext = t.mime.contains("jpeg") ? "jpg" : "png";
            if (Media.saveBytes(this, t.data, Media.SUB_TEX, baseName() + "_" + i + "." + ext, t.mime) != null) ok++;
        }
        toast("✅ " + ok + " texturas guardadas en " + Media.where(this, Media.SUB_TEX));
    }

    // =====================================================================
    // Texturas
    // =====================================================================
    void replaceTexture(Uri u) {
        try (InputStream in = getContentResolver().openInputStream(u)) {
            byte[] d = DocIO.readAll(in);
            Model3D.Tex t = new Model3D.Tex();
            t.data = d;
            t.mime = d.length > 2 && (d[0] & 0xff) == 0xFF && (d[1] & 0xff) == 0xD8 ? "image/jpeg" : "image/png";
            t.name = Media.nameOf(this, u);
            Model3D.Part p = model.parts.get(imagePart);
            if (p.tex >= 0 && p.tex < model.textures.size()) {      // sustituye la textura de esa parte
                model.textures.set(p.tex, t);
                texView[p.tex] = decodeOne(d);
                texFull[p.tex] = null;
                texDirty[p.tex] = false;
            } else {
                model.textures.add(t);
                p.tex = model.textures.size() - 1;
                texView = Arrays.copyOf(texView, model.textures.size());
                texFull = Arrays.copyOf(texFull, model.textures.size());
                texDirty = Arrays.copyOf(texDirty, model.textures.size());
                texView[p.tex] = decodeOne(d);
            }
            p.color = 0xFFFFFFFF;
            rebuildShaders();
            dirty = true;
            if (model.uv == null) toast("Imagen puesta, pero este modelo no tiene UV: no se verá hasta que tenga coordenadas de textura.");
            view.invalidate();
        } catch (Throwable e) {
            toast("No se pudo abrir la imagen");
        }
    }

    static Bitmap decodeOne(byte[] d) {
        Model3D tmp = new Model3D();
        Model3D.Tex t = new Model3D.Tex();
        t.data = d;
        tmp.textures.add(t);
        return decodeTextures(tmp)[0];
    }

    /** Crea una textura lisa para poder pintar una parte que no tenía. */
    int blankTexture(int part) {
        Model3D.Part p = model.parts.get(part);
        Bitmap b = Bitmap.createBitmap(1024, 1024, Bitmap.Config.ARGB_8888);
        b.eraseColor(p.color | 0xFF000000);
        Model3D.Tex t = new Model3D.Tex();
        t.name = p.name + "_pintura";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, bos);
        t.data = bos.toByteArray();
        model.textures.add(t);
        p.tex = model.textures.size() - 1;
        p.color = 0xFFFFFFFF;
        texView = Arrays.copyOf(texView, model.textures.size());
        texFull = Arrays.copyOf(texFull, model.textures.size());
        texDirty = Arrays.copyOf(texDirty, model.textures.size());
        texView[p.tex] = b;
        texFull[p.tex] = b;
        rebuildShaders();
        return p.tex;
    }

    void colorDialog() {
        final int[] pal = {Color.WHITE, Color.BLACK, Color.rgb(128, 128, 128), Color.rgb(255, 80, 120), Color.rgb(255, 40, 40), Color.rgb(255, 150, 40),
                Color.rgb(255, 230, 60), Color.rgb(80, 220, 90), Color.rgb(40, 200, 255), Color.rgb(60, 90, 255), Color.rgb(170, 80, 255),
                Color.rgb(255, 205, 170), Color.rgb(230, 170, 120), Color.rgb(150, 95, 60), Color.rgb(90, 55, 35), Color.rgb(250, 235, 215)};
        String[] names = {"Blanco", "Negro", "Gris", "Rosa", "Rojo", "Naranja", "Amarillo", "Verde", "Cian", "Azul", "Morado",
                "Piel clara", "Piel media", "Piel morena", "Castaño", "Crema", "#️⃣ Código HEX…"};
        new AlertDialog.Builder(this).setTitle(L.t("🎨 Color del pincel")).setItems(L.ta(names), (d, w) -> {
            if (w < pal.length) { paintColor = pal[w]; view.invalidate(); return; }
            EditText e = new EditText(this);
            e.setInputType(InputType.TYPE_CLASS_TEXT);
            e.setText(String.format("#%06X", paintColor & 0xFFFFFF));
            new AlertDialog.Builder(this).setTitle("HEX").setView(e).setPositiveButton("OK", (d2, w2) -> {
                try { paintColor = Color.parseColor(e.getText().toString().trim()); } catch (Exception ex) { toast("Color no válido"); }
                view.invalidate();
            }).show();
        }).show();
    }

    void partsDialog() {
        String[] ps = new String[model.parts.size()];
        for (int i = 0; i < ps.length; i++) {
            Model3D.Part p = model.parts.get(i);
            ps[i] = (p.tex >= 0 ? "🖼 " : "🎨 ") + p.name;
        }
        new AlertDialog.Builder(this).setTitle(L.t("Elige la parte")).setItems(ps, (d, w) -> {
            imagePart = w;
            String[] acts = {"🖼 Cambiar su imagen (textura)…", "🎨 Teñirla con el color del pincel", "↺ Quitar el tinte"};
            new AlertDialog.Builder(this).setTitle(model.parts.get(w).name).setItems(L.ta(acts), (d2, a) -> {
                if (a == 0) {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.setType("image/*");
                    startActivityForResult(Intent.createChooser(i, L.t("Imagen")), REQ_IMAGE);
                } else {
                    model.parts.get(w).color = a == 1 ? (paintColor | 0xFF000000) : 0xFFFFFFFF;
                    dirty = true;
                    view.invalidate();
                }
            }).show();
        }).show();
    }

    // =====================================================================
    // Huesos: diálogos
    // =====================================================================
    void bonesMore() {
        String[] acts = {"📋 Lista de huesos", "✏ Renombrar", "⤴ Cambiar padre", "🗑 Borrar hueso", "🧍 Hueso humanoide (VRM)…",
                "⇄ Cambiar izquierda / derecha", "⟲ Quitar la pose", "🤖 Pesos automáticos"};
        new AlertDialog.Builder(this).setTitle(L.t("⋯ Huesos")).setItems(L.ta(acts), (d, w) -> {
            switch (w) {
                case 0: boneList("Elige un hueso", i -> { sel = i; view.invalidate(); }); break;
                case 1: renameBone(); break;
                case 2: reparent(); break;
                case 3: deleteBone(); break;
                case 4: humanDialog(); break;
                case 5: model.swapSides(); dirty = true; toast("Izquierda y derecha intercambiadas"); view.invalidate(); break;
                case 6: model.resetPose(); view.poseChanged(); break;
                case 7: autoWeights(); break;
            }
        }).show();
    }

    interface IntCb { void on(int i); }

    void boneList(String title, IntCb cb) {
        if (model.bones.isEmpty()) { toast("Aún no hay huesos. Pulsa 🧍 PLANTILLA o ➕ HUESO."); return; }
        String[] ns = new String[model.bones.size()];
        for (int i = 0; i < ns.length; i++) ns[i] = depth(i) + model.bones.get(i).name + humanTag(i);
        new AlertDialog.Builder(this).setTitle(L.t(title)).setItems(ns, (d, w) -> cb.on(w)).show();
    }

    String depth(int i) {
        StringBuilder s = new StringBuilder();
        int guard = 0;
        for (int p = model.bones.get(i).parent; p >= 0 && guard++ < 30; p = model.bones.get(p).parent) s.append("· ");
        return s.toString();
    }

    String humanTag(int i) {
        for (java.util.Map.Entry<String, Integer> e : model.human.entrySet()) if (e.getValue() == i) return "  🧍" + e.getKey();
        return "";
    }

    boolean needSel() {
        if (sel >= 0 && sel < model.bones.size()) return true;
        toast("Primero toca un hueso para elegirlo");
        return false;
    }

    void renameBone() {
        if (!needSel()) return;
        EditText e = new EditText(this);
        e.setText(model.bones.get(sel).name);
        new AlertDialog.Builder(this).setTitle(L.t("✏ Nombre del hueso")).setView(e).setPositiveButton("OK", (d, w) -> {
            String n = e.getText().toString().trim();
            if (n.isEmpty()) return;
            if (!n.equals(model.bones.get(sel).name)) model.bones.get(sel).name = model.uniqueName(n);
            dirty = true;
            view.invalidate();
        }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    void reparent() {
        if (!needSel()) return;
        List<String> ns = new ArrayList<>();
        ns.add(L.t("(ninguno: hueso raíz)"));
        for (int i = 0; i < model.bones.size(); i++) ns.add(depth(i) + model.bones.get(i).name);
        new AlertDialog.Builder(this).setTitle(L.t("⤴ Padre de ") + model.bones.get(sel).name).setItems(ns.toArray(new String[0]), (d, w) -> {
            int np = w - 1;
            if (np == sel || (np >= 0 && model.wouldLoop(sel, np))) { toast("Ese padre crearía un bucle"); return; }
            model.bones.get(sel).parent = np;
            model.resetPose();
            dirty = true;
            view.poseChanged();
        }).show();
    }

    void deleteBone() {
        if (!needSel()) return;
        String n = model.bones.get(sel).name;
        new AlertDialog.Builder(this).setTitle(L.t("🗑 ¿Borrar ") + n + "?")
                .setMessage(L.t("Sus hijos pasan a su padre y su peso también."))
                .setPositiveButton(L.t("Borrar"), (d, w) -> {
                    model.resetPose();
                    model.deleteBone(sel);
                    sel = -1;
                    dirty = true;
                    view.poseChanged();
                }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    static final String[] HUMAN_ALL = {"hips", "spine", "chest", "upperChest", "neck", "head", "leftEye", "rightEye", "jaw",
            "leftShoulder", "leftUpperArm", "leftLowerArm", "leftHand", "rightShoulder", "rightUpperArm", "rightLowerArm", "rightHand",
            "leftUpperLeg", "leftLowerLeg", "leftFoot", "leftToes", "rightUpperLeg", "rightLowerLeg", "rightFoot", "rightToes"};

    void humanDialog() {
        if (!needSel()) return;
        String[] items = new String[HUMAN_ALL.length + 1];
        for (int i = 0; i < HUMAN_ALL.length; i++) {
            Integer cur = model.human.get(HUMAN_ALL[i]);
            items[i] = HUMAN_ALL[i] + (cur != null && cur >= 0 && cur < model.bones.size() ? "  ← " + model.bones.get(cur).name : "");
        }
        items[HUMAN_ALL.length] = L.t("✖ Quitar su papel humanoide");
        new AlertDialog.Builder(this).setTitle(L.t("🧍 ¿Qué es ") + model.bones.get(sel).name + "?").setItems(items, (d, w) -> {
            model.human.values().removeIf(v -> v == sel);
            if (w < HUMAN_ALL.length) model.human.put(HUMAN_ALL[w], sel);
            dirty = true;
            view.invalidate();
        }).show();
    }

    void templateDialog() {
        Runnable go = () -> {
            model.resetPose();
            model.humanoidTemplate(true);
            sel = model.boneByName("hips");
            dirty = true;
            view.poseChanged();
            new AlertDialog.Builder(this).setTitle(L.t("🧍 Esqueleto creado"))
                    .setMessage(L.t("Se han colocado 25 huesos con nombres de VRM y se han calculado los pesos.\n\n"
                            + "Ahora usa ✋ MOVER para llevar cada articulación (codos, rodillas, cuello...) a su sitio, "
                            + "y ↻ POSAR para probar cómo se dobla. Si izquierda y derecha salen al revés: ⋯ MÁS → Cambiar izquierda / derecha. "
                            + "Cuando muevas articulaciones, vuelve a calcular 🤖 Pesos automáticos."))
                    .setPositiveButton(L.t("Entendido"), null).show();
        };
        if (!model.bones.isEmpty())
            new AlertDialog.Builder(this).setTitle(L.t("🧍 ¿Crear esqueleto humanoide?"))
                    .setMessage(L.t("Se borrarán los huesos y pesos que tiene ahora el modelo."))
                    .setPositiveButton(L.t("Crear"), (d, w) -> go.run()).setNegativeButton(L.t("Cancelar"), null).show();
        else go.run();
    }

    void addBone() {
        float[] b = model.bounds();
        float size = Math.max(b[3] - b[0], Math.max(b[4] - b[1], b[5] - b[2]));
        float x, y, z;
        if (sel >= 0) {
            Model3D.Bone p = model.bones.get(sel);
            x = p.hx(); y = p.hy() + size * 0.08f; z = p.hz();
        } else { x = (b[0] + b[3]) / 2; y = (b[1] + b[4]) / 2; z = (b[2] + b[5]) / 2; }
        model.resetPose();
        sel = model.addBone("hueso", sel, x, y, z);
        tool = T_MOVE;
        dirty = true;
        view.poseChanged();
        toast("Hueso añadido: arrástralo a su sitio (✋ MOVER)");
    }

    void autoWeights() {
        if (model.bones.isEmpty()) { toast("Aún no hay huesos. Pulsa 🧍 PLANTILLA o ➕ HUESO."); return; }
        status = "Calculando pesos…";
        view.invalidate();
        new Thread(() -> {
            model.autoWeights();
            runOnUiThread(() -> { status = ""; dirty = true; view.poseChanged(); toast("🤖 Pesos calculados"); });
        }).start();
    }

    // =====================================================================
    // Vista y edición
    // =====================================================================
    class Editor extends View {
        final int[] COLORS = {Color.rgb(220, 220, 230), Color.rgb(0, 200, 255), Color.rgb(255, 140, 40), Color.rgb(120, 230, 120), Color.rgb(255, 90, 160), Color.rgb(200, 160, 110)};
        final String[] COLOR_NAMES = {"Blanco", "Cian", "Naranja", "Verde", "Rosa", "Arcilla"};
        float yaw = 0f, pitch = -0.15f, zoom = 1f, panX, panY;
        int colorIdx;
        boolean wire, spin, touching, showTex = true;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG), tex = new Paint();
        // proyección del último fotograma
        float[] sx = new float[0], sy = new float[0], sz = new float[0];
        float[] posed;
        float[][] boneWorld = new float[0][];
        float cx0, cy0, cz0, unit, scr, ocx, ocy;      // centro del modelo, escala y centro en pantalla
        float[] R = new float[9];                       // giro mundo → vista (filas: derecha, arriba, hacia ti)
        long[] order = new long[0];
        int drawn;
        int[] drawnTri = new int[0];
        float[] verts = new float[0], texs = new float[0];
        int[] cols = new int[0];
        // botones
        final List<RectF> btnR = new ArrayList<>();
        final List<Runnable> btnA = new ArrayList<>();
        final List<String> btnL = new ArrayList<>();
        final List<Boolean> btnOn = new ArrayList<>();
        // toques
        float lastX, lastY, pinchD, pinchZ, pinchMX, pinchMY, downX, downY;
        long lastTap;
        int gesture;      // 0 nada, 1 girar cámara, 2 mover hueso, 3 posar, 4 pincel de pesos, 5 pintar, 6 dos dedos, 7 por decidir
        int pendingHit = -1;
        float poseAngle;

        Editor(Context c) {
            super(c);
            setBackgroundColor(Color.rgb(8, 10, 18));
            t.setTypeface(Typeface.DEFAULT_BOLD);
            tex.setFilterBitmap(true);
            if (Build.VERSION.SDK_INT < 29) setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        float dp(float v) { return v * getResources().getDisplayMetrics().density; }

        void fit() {
            yaw = 0; pitch = -0.15f; zoom = 1; panX = panY = 0;
            poseChanged();
        }

        void poseChanged() {
            posed = null;
            invalidate();
        }

        // ---------- proyección ----------
        void setupCamera(float W, float H) {
            float[] b = model.bounds();
            cx0 = (b[0] + b[3]) / 2; cy0 = (b[1] + b[4]) / 2; cz0 = (b[2] + b[5]) / 2;
            float size = Math.max(1e-6f, Math.max(b[3] - b[0], Math.max(b[4] - b[1], b[5] - b[2])));
            unit = 2f / size;
            float cyw = (float) Math.cos(yaw), syw = (float) Math.sin(yaw), cp = (float) Math.cos(pitch), sp = (float) Math.sin(pitch);
            // fila 0: derecha · fila 1: arriba · fila 2: hacia el que mira
            R[0] = cyw; R[1] = 0; R[2] = syw;
            R[3] = -sp * -syw; R[4] = cp; R[5] = -sp * cyw;
            R[6] = cp * -syw; R[7] = sp; R[8] = cp * cyw;
            scr = Math.min(W, H - dp(170)) * 0.42f * zoom;
            ocx = W / 2 + panX;
            ocy = dp(70) + (H - dp(190)) / 2 + panY;
        }

        float vx(float x, float y, float z) { return R[0] * (x - cx0) + R[1] * (y - cy0) + R[2] * (z - cz0); }
        float vy(float x, float y, float z) { return R[3] * (x - cx0) + R[4] * (y - cy0) + R[5] * (z - cz0); }
        float vz(float x, float y, float z) { return R[6] * (x - cx0) + R[7] * (y - cy0) + R[8] * (z - cz0); }
        float toSx(float x, float y, float z) { return ocx + vx(x, y, z) * unit * scr; }
        float toSy(float x, float y, float z) { return ocy - vy(x, y, z) * unit * scr; }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), H = getHeight();
            int neon = Neon.color(getContext());
            t.setTextAlign(Paint.Align.LEFT);
            t.setColor(Color.WHITE);
            t.setTextSize(dp(15));
            c.drawText(L.t("🧊 " + (name.isEmpty() ? "Editor 3D" : name)) + (dirty ? " •" : ""), dp(14), dp(30), t);
            if (model != null) {
                t.setTextSize(dp(11));
                t.setColor(Color.LTGRAY);
                float[] b = model.bounds();
                c.drawText(L.t(String.format(Locale.US, "%,d triángulos · %,d vértices · %d huesos · %d texturas · %.2f × %.2f × %.2f%s",
                        model.tris(), model.nv, model.bones.size(), model.textures.size(), b[3] - b[0], b[4] - b[1], b[5] - b[2],
                        reduced ? " · reducido" : "")), dp(14), dp(48), t);
                drawModel(c, W, H, neon);
                if (mode != M_VIEW) drawBones(c, neon);
                drawHint(c, W, neon);
                if (spin && !touching) { yaw += 0.012f; postInvalidateOnAnimation(); }
            }
            if (!status.isEmpty()) {
                t.setTextAlign(Paint.Align.CENTER);
                t.setTextSize(dp(15));
                t.setColor(Color.WHITE);
                c.drawText(L.t(status), W / 2, H / 2, t);
            }
            drawButtons(c, W, H, neon);
        }

        void drawModel(Canvas c, float W, float H, int neon) {
            Model3D m = model;
            setupCamera(W, H);
            if (posed == null) {
                posed = m.skinned();
                boneWorld = m.poseWorld();
            }
            int n = m.nv;
            if (sx.length < n) { sx = new float[n]; sy = new float[n]; sz = new float[n]; }
            for (int i = 0; i < n; i++) {
                float x = posed[i * 3], y = posed[i * 3 + 1], z = posed[i * 3 + 2];
                sx[i] = toSx(x, y, z); sy[i] = toSy(x, y, z); sz[i] = vz(x, y, z);
            }
            int tris = m.tris();
            int step = (touching || spin) ? Math.max(1, (tris + 39_999) / 40_000) : Math.max(1, (tris + 119_999) / 120_000);
            if (gesture == 5 || gesture == 4) step = Math.max(1, (tris + 59_999) / 60_000);
            int cnt = 0;
            if (order.length < tris / step + 1) { order = new long[tris / step + 1]; drawnTri = new int[tris / step + 1]; }
            for (int ti = 0; ti < tris; ti += step) {
                int a = m.idx[ti * 3], bb = m.idx[ti * 3 + 1], cc = m.idx[ti * 3 + 2];
                float zs = sz[a] + sz[bb] + sz[cc];
                int depth = Float.floatToIntBits(zs);
                long key = depth ^ ((depth >> 31) & 0x7fffffff);
                order[cnt] = (((long) key) << 32) | (cnt & 0xffffffffL);
                drawnTri[cnt] = ti;
                cnt++;
            }
            Arrays.sort(order, 0, cnt);
            drawn = cnt;
            if (wire) { drawWire(c, cnt, neon); return; }
            boolean heat = mode == M_WEIGHTS && sel >= 0 && sel < m.bones.size();
            int vc = cnt * 6;
            if (verts.length < vc) { verts = new float[vc]; texs = new float[vc]; cols = new int[cnt * 3]; }
            int base = COLORS[colorIdx];
            float lx = 0.3f, ly = 0.5f, lz = 0.81f;
            int runStart = 0, runKey = Integer.MIN_VALUE;
            for (int j = 0; j < cnt; j++) {
                int ti = drawnTri[(int) order[j]];
                int part = m.triPart.length > ti ? m.triPart[ti] : 0;
                Model3D.Part pt = part < m.parts.size() ? m.parts.get(part) : null;
                boolean textured = !heat && showTex && m.uv != null && pt != null && pt.tex >= 0 && pt.tex < shaders.length && shaders[pt.tex] != null;
                int key = textured ? pt.tex : -1;
                if (key != runKey && j > runStart) { flush(c, runStart, j, runKey); runStart = j; }
                runKey = key;
                int a = m.idx[ti * 3], bI = m.idx[ti * 3 + 1], cI = m.idx[ti * 3 + 2];
                // sombreado plano según la normal en la vista
                float ux = sx[bI] - sx[a], uy = sy[a] - sy[bI], uz = sz[bI] - sz[a];
                float wx = sx[cI] - sx[a], wy = sy[a] - sy[cI], wz = sz[cI] - sz[a];
                float nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
                float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                float sh = len > 0 ? Math.abs(nx * lx + ny * ly + nz * lz) / len : 0.5f;
                sh = 0.35f + 0.65f * sh;
                int tint = pt == null ? 0xFFFFFFFF : pt.color;
                int col;
                if (textured) col = Color.rgb((int) (Color.red(tint) * sh), (int) (Color.green(tint) * sh), (int) (Color.blue(tint) * sh));
                else if (!heat) {
                    int b0 = pt != null && (pt.color & 0xFFFFFF) != 0xFFFFFF ? pt.color : base;
                    col = Color.rgb((int) (Color.red(b0) * sh), (int) (Color.green(b0) * sh), (int) (Color.blue(b0) * sh));
                } else col = 0;
                Bitmap bm = textured ? texView[pt.tex] : null;
                int[] vs = {a, bI, cI};
                for (int k = 0; k < 3; k++) {
                    int v = vs[k];
                    verts[j * 6 + k * 2] = sx[v];
                    verts[j * 6 + k * 2 + 1] = sy[v];
                    if (bm != null) { texs[j * 6 + k * 2] = m.uv[v * 2] * bm.getWidth(); texs[j * 6 + k * 2 + 1] = m.uv[v * 2 + 1] * bm.getHeight(); }
                    if (heat) {
                        float w = m.weight(v, sel);
                        int hc = heatColor(w);
                        cols[j * 3 + k] = Color.rgb((int) (Color.red(hc) * sh), (int) (Color.green(hc) * sh), (int) (Color.blue(hc) * sh));
                    } else cols[j * 3 + k] = col;
                }
            }
            if (cnt > runStart) flush(c, runStart, cnt, runKey);
        }

        void flush(Canvas c, int from, int to, int texKey) {
            int n = (to - from) * 6;
            if (n <= 0) return;
            if (texKey >= 0) {
                tex.setShader(shaders[texKey]);
                c.drawVertices(Canvas.VertexMode.TRIANGLES, n, verts, from * 6, texs, from * 6, cols, from * 3, null, 0, 0, tex);
                tex.setShader(null);
            } else {
                p.setShader(null);
                c.drawVertices(Canvas.VertexMode.TRIANGLES, n, verts, from * 6, null, 0, cols, from * 3, null, 0, 0, p);
            }
        }

        int heatColor(float w) {
            // azul (0) → verde → amarillo → rojo (1), como en Blender
            w = Math.max(0, Math.min(1, w));
            float r, g, b;
            if (w < 0.25f) { r = 0; g = w / 0.25f; b = 1; }
            else if (w < 0.5f) { r = 0; g = 1; b = 1 - (w - 0.25f) / 0.25f; }
            else if (w < 0.75f) { r = (w - 0.5f) / 0.25f; g = 1; b = 0; }
            else { r = 1; g = 1 - (w - 0.75f) / 0.25f; b = 0; }
            return Color.rgb((int) (r * 255), (int) (g * 255), (int) (b * 255));
        }

        void drawWire(Canvas c, int cnt, int neon) {
            int lines = Math.min(cnt, 25_000);
            float[] pts = new float[lines * 12];
            int pi = 0;
            for (int j = cnt - lines; j < cnt; j++) {
                int ti = drawnTri[(int) order[j]];
                for (int k = 0; k < 3; k++) {
                    int a = model.idx[ti * 3 + k], bb = model.idx[ti * 3 + (k + 1) % 3];
                    pts[pi++] = sx[a]; pts[pi++] = sy[a]; pts[pi++] = sx[bb]; pts[pi++] = sy[bb];
                }
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1);
            p.setColor(COLORS[colorIdx]);
            c.drawLines(pts, 0, pi, p);
            p.setStyle(Paint.Style.FILL);
        }

        float bsx(int i) { float[] w = boneWorld[i]; return toSx(w[3], w[7], w[11]); }
        float bsy(int i) { float[] w = boneWorld[i]; return toSy(w[3], w[7], w[11]); }

        void drawBones(Canvas c, int neon) {
            Model3D m = model;
            if (boneWorld.length != m.bones.size()) boneWorld = m.poseWorld();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < m.bones.size(); i++) {
                int par = m.bones.get(i).parent;
                if (par < 0) continue;
                p.setStrokeWidth(dp(i == sel || par == sel ? 3.5f : 2f));
                p.setColor(i == sel ? Color.WHITE : Color.argb(200, Color.red(neon), Color.green(neon), Color.blue(neon)));
                c.drawLine(bsx(par), bsy(par), bsx(i), bsy(i), p);
            }
            p.setStyle(Paint.Style.FILL);
            boolean hum = !m.human.isEmpty();
            for (int i = 0; i < m.bones.size(); i++) {
                boolean isHuman = hum && m.human.containsValue(i);
                p.setColor(i == sel ? Color.rgb(255, 230, 80) : isHuman ? Color.rgb(120, 255, 160) : neon);
                c.drawCircle(bsx(i), bsy(i), dp(i == sel ? 7 : 4.5f), p);
                p.setColor(Color.BLACK);
                c.drawCircle(bsx(i), bsy(i), dp(i == sel ? 3 : 1.8f), p);
            }
            if (sel >= 0 && sel < m.bones.size()) {
                t.setTextAlign(Paint.Align.LEFT);
                t.setTextSize(dp(12));
                t.setColor(Color.rgb(255, 230, 80));
                c.drawText(m.bones.get(sel).name + humanTag(sel), bsx(sel) + dp(10), bsy(sel) - dp(8), t);
            }
        }

        void drawHint(Canvas c, float W, int neon) {
            String h;
            switch (mode) {
                case M_BONES:
                    h = tool == T_MOVE ? "✋ Arrastra una articulación para colocarla" : tool == T_POSE ? "↻ Arrastra alrededor del hueso elegido para doblarlo"
                            : "Toca una articulación para elegirla · arrastra para girar la vista";
                    break;
                case M_WEIGHTS:
                    h = sel < 0 ? "Toca una articulación: verás su peso (rojo = mucho, azul = nada)"
                            : (brushAdd ? "🖌 Pinta para dar más peso a " : "🧽 Pinta para quitar peso a ") + model.bones.get(sel).name;
                    break;
                case M_PAINT:
                    h = painting ? (model.uv == null ? "Este modelo no tiene UV: solo se pueden teñir sus partes (🧩 PARTES)" : "🖌 Pinta sobre el modelo · dos dedos = mover la vista")
                            : "Arrastra para girar la vista";
                    break;
                default:
                    h = "Un dedo gira · dos dedos acercan y mueven · doble toque centra";
            }
            t.setTextAlign(Paint.Align.CENTER);
            t.setTextSize(dp(11));
            t.setColor(Color.argb(190, 255, 255, 255));
            c.drawText(L.t(h), W / 2, dp(66), t);
            if (mode == M_PAINT || mode == M_WEIGHTS) {      // tamaño del pincel
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1.5f));
                p.setColor(mode == M_PAINT ? paintColor : Color.WHITE);
                c.drawCircle(W - dp(30), dp(84), brushRadius(), p);
                p.setStyle(Paint.Style.FILL);
            }
        }

        float brushRadius() { return dp(6 + brushSize * 8); }

        // ---------- botones ----------
        void btn(String label, boolean on, Runnable a) { btnL.add(label); btnOn.add(on); btnA.add(a); }

        void drawButtons(Canvas c, float W, float H, int neon) {
            btnR.clear(); btnA.clear(); btnL.clear(); btnOn.clear();
            // fila de herramientas del modo
            switch (mode) {
                case M_VIEW:
                    btn("🎨 " + COLOR_NAMES[colorIdx].toUpperCase(), false, () -> colorIdx = (colorIdx + 1) % COLORS.length);
                    btn("🕸 MALLA", wire, () -> wire = !wire);
                    btn("🖼 TEXTURA", showTex, () -> showTex = !showTex);
                    btn("🔄 GIRO", spin, () -> spin = !spin);
                    btn("⟲ CENTRAR", false, this::fit);
                    btn("📂 ABRIR", false, Model3DActivity.this::pick);
                    break;
                case M_BONES:
                    btn("🧍 PLANTILLA", false, Model3DActivity.this::templateDialog);
                    btn("➕ HUESO", false, Model3DActivity.this::addBone);
                    btn("✋ MOVER", tool == T_MOVE, () -> { tool = tool == T_MOVE ? T_SELECT : T_MOVE; if (tool == T_MOVE && model.posed()) { model.resetPose(); poseChanged(); } });
                    btn("↻ POSAR", tool == T_POSE, () -> tool = tool == T_POSE ? T_SELECT : T_POSE);
                    btn("✏ NOMBRE", false, Model3DActivity.this::renameBone);
                    btn("⋯ MÁS", false, Model3DActivity.this::bonesMore);
                    break;
                case M_WEIGHTS:
                    btn("🤖 AUTO", false, Model3DActivity.this::autoWeights);
                    btn("🖌 SUMAR", brushAdd, () -> brushAdd = true);
                    btn("🧽 RESTAR", !brushAdd, () -> brushAdd = false);
                    btn("◉ TAMAÑO " + brushSize, false, () -> brushSize = brushSize % 4 + 1);
                    btn("📋 HUESOS", false, () -> boneList("Elige un hueso", i -> { sel = i; invalidate(); }));
                    btn("⟲ POSE", false, () -> { model.resetPose(); poseChanged(); });
                    break;
                case M_PAINT:
                    btn("🖌 PINTAR", painting, () -> painting = !painting);
                    btn("🎨 COLOR", false, Model3DActivity.this::colorDialog);
                    btn("◉ TAMAÑO " + brushSize, false, () -> brushSize = brushSize % 4 + 1);
                    btn("🧩 PARTES", false, Model3DActivity.this::partsDialog);
                    btn("🖼 TEXTURA", showTex, () -> showTex = !showTex);
                    break;
            }
            float gap = dp(4), rowH = dp(46);
            int n = btnL.size();
            float bw = (W - dp(8) * 2 - gap * (n - 1)) / n, y = H - dp(60) - rowH - dp(6);
            for (int i = 0; i < n; i++) btnR.add(new RectF(dp(8) + i * (bw + gap), y, dp(8) + i * (bw + gap) + bw, y + rowH));
            // pestañas de modo
            String[] tabs = {"👁 VER", "🦴 HUESOS", "⚖ PESOS", "🎨 PINTAR", "💾 GUARDAR"};
            int tabStart = btnR.size();
            float tw = (W - dp(8) * 2 - gap * 4) / 5, ty = H - dp(60);
            for (int i = 0; i < 5; i++) {
                btnR.add(new RectF(dp(8) + i * (tw + gap), ty, dp(8) + i * (tw + gap) + tw, ty + dp(52)));
                btnL.add(tabs[i]);
                btnOn.add(i == mode);
                final int md = i;
                btnA.add(() -> {
                    if (md == 4) { saveMenu(); return; }
                    if (model == null) return;
                    mode = md;
                    if (md == M_WEIGHTS && model.bones.isEmpty()) toast("Aún no hay huesos. Pulsa 🧍 PLANTILLA o ➕ HUESO.");
                    if (md == M_WEIGHTS && sel < 0 && !model.bones.isEmpty()) sel = 0;
                });
            }
            for (int i = 0; i < btnR.size(); i++) {
                RectF r = btnR.get(i);
                boolean on = btnOn.get(i), tab = i >= tabStart;
                p.setStyle(Paint.Style.FILL);
                p.setColor(Neon.withAlpha(neon, on ? 120 : tab ? 55 : 35));
                c.drawRoundRect(r, dp(11), dp(11), p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(tab ? 2 : 1.5f));
                p.setColor(on ? Color.WHITE : neon);
                c.drawRoundRect(r, dp(11), dp(11), p);
                p.setStyle(Paint.Style.FILL);
                t.setTextAlign(Paint.Align.CENTER);
                t.setTextSize(dp(10));
                t.setColor(Color.WHITE);
                String lab = L.t(btnL.get(i));
                int sp = lab.indexOf(' ');
                if (sp > 0) {
                    c.drawText(lab.substring(0, sp), r.centerX(), r.centerY() - dp(3), t);
                    c.drawText(lab.substring(sp + 1), r.centerX(), r.centerY() + dp(11), t);
                } else c.drawText(lab, r.centerX(), r.centerY() + dp(4), t);
            }
        }

        // ---------- toques ----------
        int boneAt(float x, float y) {
            if (model == null || boneWorld.length != model.bones.size()) return -1;
            int best = -1;
            float bd = dp(26);
            for (int i = 0; i < model.bones.size(); i++) {
                float d = (float) Math.hypot(bsx(i) - x, bsy(i) - y);
                if (d < bd) { bd = d; best = i; }
            }
            return best;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    for (int i = 0; i < btnR.size(); i++) if (btnR.get(i).contains(x, y)) { btnA.get(i).run(); invalidate(); gesture = -1; return true; }
                    if (model == null) return true;
                    lastX = downX = x; lastY = downY = y;
                    touching = true;
                    gesture = 1;
                    int hit = mode == M_BONES || mode == M_WEIGHTS ? boneAt(x, y) : -1;
                    if (mode == M_BONES) {
                        if (tool == T_MOVE && hit >= 0) { sel = hit; gesture = 2; }
                        else if (tool == T_POSE && sel >= 0) { gesture = 3; poseAngle = angleAt(x, y); }
                        else if (hit >= 0) { sel = hit; gesture = 0; }
                    } else if (mode == M_WEIGHTS) {
                        // tocar sin arrastrar = elegir la articulación; arrastrar = pintar peso
                        pendingHit = hit;
                        gesture = 7;
                    } else if (mode == M_PAINT && painting) {
                        gesture = 5;
                        paintAt(x, y);
                    }
                    long now = System.currentTimeMillis();
                    if (gesture == 1 && now - lastTap < 300) fit();
                    lastTap = now;
                    invalidate();
                    return true;
                }
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (e.getPointerCount() >= 2 && gesture != -1) {
                        if (gesture == 5 || gesture == 4) finishStroke();
                        pendingHit = -1;
                        gesture = 6;
                        pinchD = (float) Math.max(1, Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
                        pinchZ = zoom;
                        pinchMX = (e.getX(0) + e.getX(1)) / 2;
                        pinchMY = (e.getY(0) + e.getY(1)) / 2;
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (gesture == -1 || model == null) return true;
                    if (gesture == 6 && e.getPointerCount() >= 2) {
                        float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                        zoom = Math.max(0.2f, Math.min(12f, pinchZ * d / pinchD));
                        float mx = (e.getX(0) + e.getX(1)) / 2, my = (e.getY(0) + e.getY(1)) / 2;
                        panX += mx - pinchMX; panY += my - pinchMY;
                        pinchMX = mx; pinchMY = my;
                    } else if (gesture == 1) {
                        yaw += (x - lastX) * 0.01f;
                        pitch = Math.max(-1.55f, Math.min(1.55f, pitch + (y - lastY) * 0.01f));
                    } else if (gesture == 2) {
                        moveSelected(x - lastX, y - lastY);
                    } else if (gesture == 3) {
                        float a = angleAt(x, y), da = a - poseAngle;
                        if (da > Math.PI) da -= 2 * Math.PI;
                        if (da < -Math.PI) da += 2 * Math.PI;
                        poseAngle = a;
                        model.rotateBone(sel, R[6], R[7], R[8], da);
                        posed = null;
                    } else if (gesture == 7) {
                        if (Math.hypot(x - downX, y - downY) > dp(10)) {
                            if (sel >= 0 && sel < model.bones.size()) { gesture = 4; brushWeights(downX, downY); brushWeights(x, y); }
                            else gesture = 1;
                        }
                    } else if (gesture == 4) {
                        brushWeights(x, y);
                    } else if (gesture == 5) {
                        paintAt(x, y);
                    }
                    lastX = x; lastY = y;
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (gesture == 7) {
                        if (pendingHit >= 0) sel = pendingHit;
                        else if (sel >= 0 && sel < model.bones.size()) brushWeights(x, y);
                        else toast("Toca una articulación para elegir el hueso");
                    }
                    if (gesture == 4 || gesture == 5) finishStroke();
                    if (gesture == 2) { dirty = true; posed = null; }
                    touching = false;
                    gesture = 0;
                    invalidate();
                    return true;
            }
            return true;
        }

        float angleAt(float x, float y) {
            if (sel < 0 || sel >= model.bones.size()) return 0;
            return (float) Math.atan2(-(y - bsy(sel)), x - bsx(sel));
        }

        /** Mueve la articulación elegida en el plano de la pantalla. */
        void moveSelected(float dx, float dy) {
            if (sel < 0 || sel >= model.bones.size()) return;
            float k = 1f / (unit * scr);
            float wx = (R[0] * dx - R[3] * dy) * k, wy = (R[1] * dx - R[4] * dy) * k, wz = (R[2] * dx - R[5] * dy) * k;
            Model3D.Bone b = model.bones.get(sel);
            model.moveBone(sel, b.hx() + wx, b.hy() + wy, b.hz() + wz);
            boneWorld = model.poseWorld();
        }

        /** Pincel de pesos: vértices visibles dentro del círculo. */
        void brushWeights(float x, float y) {
            if (sel < 0 || sel >= model.bones.size() || posed == null) return;
            float r = brushRadius(), r2 = r * r;
            float front = -Float.MAX_VALUE;
            List<Integer> in = new ArrayList<>();
            for (int v = 0; v < model.nv; v++) {
                float ddx = sx[v] - x, ddy = sy[v] - y;
                if (ddx * ddx + ddy * ddy <= r2) { in.add(v); front = Math.max(front, sz[v]); }
            }
            float tol = 0.06f / Math.max(1e-6f, unit) * 2;        // solo la superficie de delante
            for (int v : in) {
                if (sz[v] < front - tol) continue;
                float ddx = sx[v] - x, ddy = sy[v] - y;
                float fall = 1 - (float) Math.sqrt(ddx * ddx + ddy * ddy) / r;
                model.paintWeight(v, sel, (brushAdd ? 1 : -1) * 0.12f * fall);
            }
            dirty = true;
            if (model.posed()) posed = null;
        }

        float lastU = -1, lastV = -1;
        int lastTex = -1;

        /** Pinta en la textura el punto del modelo que hay bajo el dedo. */
        void paintAt(float x, float y) {
            if (model.uv == null) return;
            // triángulo visible más cercano bajo el dedo
            for (int j = drawn - 1; j >= 0; j--) {
                int ti = drawnTri[(int) order[j]];
                int a = model.idx[ti * 3], b = model.idx[ti * 3 + 1], c = model.idx[ti * 3 + 2];
                float d = (sy[b] - sy[c]) * (sx[a] - sx[c]) + (sx[c] - sx[b]) * (sy[a] - sy[c]);
                if (Math.abs(d) < 1e-6f) continue;
                float l1 = ((sy[b] - sy[c]) * (x - sx[c]) + (sx[c] - sx[b]) * (y - sy[c])) / d;
                float l2 = ((sy[c] - sy[a]) * (x - sx[c]) + (sx[a] - sx[c]) * (y - sy[c])) / d;
                float l3 = 1 - l1 - l2;
                if (l1 < 0 || l2 < 0 || l3 < 0) continue;
                int part = model.triPart[ti];
                Model3D.Part pt = model.parts.get(part);
                int ti2 = pt.tex >= 0 && pt.tex < texView.length && texView[pt.tex] != null ? pt.tex : blankTexture(part);
                float u = l1 * model.uv[a * 2] + l2 * model.uv[b * 2] + l3 * model.uv[c * 2];
                float v = l1 * model.uv[a * 2 + 1] + l2 * model.uv[b * 2 + 1] + l3 * model.uv[c * 2 + 1];
                u -= (float) Math.floor(u);
                v -= (float) Math.floor(v);
                // tamaño del pincel en la textura: según cuánto ocupa el triángulo en pantalla
                float scrArea = Math.abs(d) / 2;
                float uvArea = Math.abs((model.uv[b * 2] - model.uv[a * 2]) * (model.uv[c * 2 + 1] - model.uv[a * 2 + 1])
                        - (model.uv[c * 2] - model.uv[a * 2]) * (model.uv[b * 2 + 1] - model.uv[a * 2 + 1])) / 2;
                float uvPerPx = scrArea > 1e-3f ? (float) Math.sqrt(uvArea / scrArea) : 0.002f;
                float ruv = Math.max(0.0015f, Math.min(0.08f, brushRadius() * 0.5f * uvPerPx));
                stamp(ti2, u, v, ruv);
                if (lastTex == ti2 && lastU >= 0 && Math.hypot(u - lastU, v - lastV) < 0.08) {   // rellena el trazo
                    float dist = (float) Math.hypot(u - lastU, v - lastV);
                    int steps = (int) (dist / (ruv * 0.5f));
                    for (int s = 1; s < steps; s++) stamp(ti2, lastU + (u - lastU) * s / steps, lastV + (v - lastV) * s / steps, ruv);
                }
                lastU = u; lastV = v; lastTex = ti2;
                dirty = true;
                return;
            }
            lastU = -1;
        }

        final Paint stampP = new Paint(Paint.ANTI_ALIAS_FLAG);

        void stamp(int ti, float u, float v, float ruv) {
            stampP.setColor(paintColor);
            Bitmap full = fullTex(ti), small = texView[ti];
            if (full != null && full.isMutable()) {
                new Canvas(full).drawCircle(u * full.getWidth(), v * full.getHeight(), Math.max(1, ruv * full.getWidth()), stampP);
            }
            if (small != null && small != full && small.isMutable())
                new Canvas(small).drawCircle(u * small.getWidth(), v * small.getHeight(), Math.max(1, ruv * small.getWidth()), stampP);
            texDirty[ti] = true;
        }

        void finishStroke() {
            lastU = -1;
            rebuildShaders();
        }
    }
}
