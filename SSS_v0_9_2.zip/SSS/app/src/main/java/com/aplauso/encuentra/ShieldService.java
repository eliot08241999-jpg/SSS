package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioRecordingConfiguration;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.util.Calendar;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * ESCUDO ANTI-«OK GOOGLE» (v0.9.1).
 *
 * Una app normal no puede apagar el Asistente de Google. Lo que sí puede hacer es OCUPAR el micrófono
 * de forma "privada": desde Android 11, mientras una app graba con setPrivacySensitive(true), ni siquiera
 * el Asistente puede escuchar a la vez, así que "Ok Google" no lo oye (en Android 10 se usa una fuente de
 * audio de llamadas, que también es privada; en Android 9 o antes, cualquier grabación ya bloquea el micro).
 * Lo grabado NO se guarda ni se envía: se lee y se descarta al momento.
 *
 * Seguridad:
 * - Pausar 1 hora, detener por hoy o apagarlo del todo, desde la app o desde la notificación.
 * - Si OTRA app necesita el micrófono (una llamada de WhatsApp, una nota de voz...), el escudo se aparta solo
 *   y vuelve cuando esa app termina.
 * - Si el micrófono falla, el escudo se apaga solo y avisa.
 */
public class ShieldService extends Service {
    static final String CHANNEL = "escudo";
    static final int NOTIF_ID = 7;
    static final String ACT_PAUSE = "com.aplauso.SHIELD_PAUSE", ACT_TODAY = "com.aplauso.SHIELD_TODAY", ACT_OFF = "com.aplauso.SHIELD_OFF";

    static volatile boolean running = false;
    static volatile boolean capturing = false;          // el escudo tiene el micro ahora mismo
    static volatile boolean otherAppRecording = false;  // otra app usa el micro: el escudo se aparta
    static final Set<Integer> ourSessions = new CopyOnWriteArraySet<>();
    /** La pantalla del asistente usa el reconocedor de Google: mientras tanto, soltamos el micro. */
    static volatile boolean yieldMic = false;
    static final int ANSWER_ID = 8;

    private volatile boolean alive;
    private Thread thread;
    private AudioManager am;
    private AudioManager.AudioRecordingCallback cb;
    private final Handler main = new Handler(Looper.getMainLooper());
    private String lastNotif = "";

    // ------------------------------------------------------------------ ajustes
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static boolean enabled(Context c) { return prefs(c).getBoolean("shield_on", false); }
    static int from(Context c) { return prefs(c).getInt("shield_from", 9 * 60); }      // minutos desde las 00:00
    static int to(Context c) { return prefs(c).getInt("shield_to", 18 * 60); }

    static int nowMin() { Calendar k = Calendar.getInstance(); return k.get(Calendar.HOUR_OF_DAY) * 60 + k.get(Calendar.MINUTE); }

    /** ¿La hora actual está dentro del horario A→B? (si B < A, cruza la medianoche; si A == B, todo el día) */
    static boolean inWindow(Context c) {
        int a = from(c), b = to(c), n = nowMin();
        if (a == b) return true;
        return a < b ? n >= a && n < b : n >= a || n < b;
    }

    static long pausedUntil(Context c) { return prefs(c).getLong("shield_pause", 0); }

    /** ¿Debe estar bloqueado el micro ahora mismo? */
    static boolean activeNow(Context c) {
        return enabled(c) && inWindow(c) && System.currentTimeMillis() >= pausedUntil(c) && !otherAppRecording && !yieldMic;
    }

    /** v0.9.2: el servicio también hace falta para escuchar la palabra clave del asistente. */
    static boolean needed(Context c) { return enabled(c) || Wake.ready(c); }

    static String hhmm(int m) { return String.format(java.util.Locale.US, "%02d:%02d", (m / 60) % 24, m % 60); }

    static void start(Context c) {
        if (!needed(c) || running) return;
        try { c.startForegroundService(new Intent(c, ShieldService.class)); } catch (Exception ignored) {}
    }

    static void stopAll(Context c) { c.stopService(new Intent(c, ShieldService.class)); }

    /** Pausa el escudo N minutos. */
    static void pause(Context c, int minutes) { prefs(c).edit().putLong("shield_pause", System.currentTimeMillis() + minutes * 60_000L).apply(); }

    /** Detiene el escudo hasta que vuelva a empezar el horario (mañana a la hora A). */
    static void stopToday(Context c) {
        int a = from(c), n = nowMin();
        int mins = a > n ? a - n : 24 * 60 - n + a;
        if (!inWindow(c)) mins = 1;          // fuera del horario no hay nada que detener
        prefs(c).edit().putLong("shield_pause", System.currentTimeMillis() + mins * 60_000L - 30_000L).apply();
    }

    static void resume(Context c) { prefs(c).edit().putLong("shield_pause", 0).apply(); }

    /** Abre el micrófono como captura privada (lo que impide que el Asistente escuche a la vez). */
    static AudioRecord openPrivate(int rate, int buf) {
        if (Build.VERSION.SDK_INT >= 30) {
            return new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_IN_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                    .setBufferSizeInBytes(buf)
                    .setPrivacySensitive(true)
                    .build();
        }
        int src = Build.VERSION.SDK_INT >= 29 ? MediaRecorder.AudioSource.VOICE_COMMUNICATION : MediaRecorder.AudioSource.MIC;
        return new AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf);
    }

    // ------------------------------------------------------------------ servicio
    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        L.init(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Escudo anti-Ok Google", NotificationManager.IMPORTANCE_LOW));
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, buildNotif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(NOTIF_ID, buildNotif());
        } catch (Exception e) {
            stopSelf();      // Android no deja usar el micrófono desde segundo plano: hay que abrir SSS+
            return;
        }
        running = true;
        alive = true;
        am = getSystemService(AudioManager.class);
        cb = new AudioManager.AudioRecordingCallback() {
            @Override public void onRecordingConfigChanged(List<AudioRecordingConfiguration> configs) { checkOthers(configs); }
        };
        try { am.registerAudioRecordingCallback(cb, main); } catch (Exception ignored) {}
        Wake.listener = new Wake.Listener() {
            @Override public void onWake() { main.post(() -> { Voice.stop(); showAnswer(L.t("🐑 Te escucho…"), ""); chimeUp(); }); }
            @Override public void onQuestion(String q) { main.post(() -> answer(q)); }
        };
        thread = new Thread(this::loop, "escudo");
        thread.start();
    }

    // ---------------- v0.9.2: el asistente responde con la voz elegida ----------------
    private void chimeUp() {
        try { new android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 60).startTone(android.media.ToneGenerator.TONE_PROP_ACK, 150); } catch (Exception ignored) {}
    }

    private void answer(String q) {
        showAnswer("🗣 " + q, L.t("Pensando…"));
        new Thread(() -> {
            String a = Brain.ask(this, q);
            main.post(() -> { showAnswer("🗣 " + q, a); Voice.say(this, a); });
        }, "cerebro").start();
    }

    void showAnswer(String title, String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("asistente", "Asistente SSS+", NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent open = PendingIntent.getActivity(this, 3, new Intent(this, AssistActivity.class), PendingIntent.FLAG_IMMUTABLE);
        nm.notify(ANSWER_ID, new Notification.Builder(this, "asistente")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(open)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .build());
    }

    /** Si alguna app que no somos nosotros graba (y no es la escucha del "Ok Google"), el escudo se aparta. */
    private void checkOthers(List<AudioRecordingConfiguration> configs) {
        boolean other = false;
        if (configs != null) for (AudioRecordingConfiguration k : configs) {
            if (ourSessions.contains(k.getClientAudioSessionId())) continue;
            if (Build.VERSION.SDK_INT >= 29 && k.getClientAudioSource() == 1999) continue;   // la escucha del "Ok Google" (HOTWORD)
            other = true;
        }
        otherAppRecording = other;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (ACT_PAUSE.equals(a)) pause(this, 60);
        else if (ACT_TODAY.equals(a)) stopToday(this);
        else if (ACT_OFF.equals(a)) {
            prefs(this).edit().putBoolean("shield_on", false).apply();
            if (!needed(this)) { stopSelf(); return START_NOT_STICKY; }
        }
        refreshNotif();
        return START_STICKY;
    }

    private void loop() {
        final int rate = 16000;
        int min = Math.max(AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 4096);
        short[] buf = new short[1024];
        AudioRecord rec = null;
        int fails = 0;
        long lastCheck = 0;
        while (alive) {
            long now = System.currentTimeMillis();
            if (now - lastCheck > 1000) {
                lastCheck = now;
                if (!needed(this)) { main.post(this::stopSelf); break; }
                boolean wakeOn = Wake.ready(this) && Wake.prepare(this);
                boolean priv = activeNow(this);
                // con la escucha de aplausos encendida, es ella quien usa el micro (y también le pasa el audio al asistente)
                boolean want = (priv || wakeOn) && !ClapService.running && !yieldMic;
                if (rec != null && want && priv != recPriv) { release(rec); rec = null; }
                if (want && rec == null) {
                    try {
                        rec = priv ? openPrivate(rate, min)
                                : new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min);
                        recPriv = priv;
                        rec.startRecording();
                        if (rec.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("micro ocupado");
                        ourSessions.add(rec.getAudioSessionId());
                        fails = 0;
                    } catch (Exception e) {
                        if (rec != null) try { rec.release(); } catch (Exception ignored) {}
                        rec = null;
                        if (++fails >= 5) {          // seguridad: si el micro falla, el escudo (y la escucha) se apagan solos
                            prefs(this).edit().putBoolean("shield_on", false).putBoolean("ai_wake", false).putBoolean("shield_failed", true).apply();
                            main.post(this::stopSelf);
                            break;
                        }
                    }
                } else if (!want && rec != null) {
                    release(rec);
                    rec = null;
                }
                capturing = rec != null;
                main.post(this::refreshNotif);
            }
            if (rec != null) {
                int n = rec.read(buf, 0, buf.length);      // no se guarda nada: solo lo oye el detector de la palabra clave
                if (n < 0) { release(rec); rec = null; }
                else if (n > 0 && Wake.wakeRec != null) Wake.feed(this, buf, n, rate);
            } else {
                try { Thread.sleep(500); } catch (InterruptedException e) { break; }
            }
        }
        if (rec != null) release(rec);
        capturing = false;
    }

    private boolean recPriv;

    private void release(AudioRecord r) {
        ourSessions.remove(r.getAudioSessionId());
        try { r.stop(); } catch (Exception ignored) {}
        try { r.release(); } catch (Exception ignored) {}
    }

    String status() {
        String wk = Wake.ready(this) ? L.t("🐑 Di «") + Wake.phrase(this) + L.t("» para hablarme · ") : "";
        if (!enabled(this)) return wk.isEmpty() ? L.t("Apagado") : wk + L.t("escudo apagado");
        return wk + statusShield();
    }

    String statusShield() {
        long pu = pausedUntil(this);
        if (!inWindow(this)) return L.t("En espera · se activa a las ") + hhmm(from(this));
        if (System.currentTimeMillis() < pu) {
            Calendar k = Calendar.getInstance();
            k.setTimeInMillis(pu);
            return L.t("En pausa hasta las ") + hhmm(k.get(Calendar.HOUR_OF_DAY) * 60 + k.get(Calendar.MINUTE));
        }
        if (otherAppRecording) return L.t("Otra app usa el micrófono: el escudo se aparta un momento");
        return L.t("«Ok Google» bloqueado hasta las ") + hhmm(to(this));
    }

    private void refreshNotif() {
        if (!running) return;
        String s = status();
        if (s.equals(lastNotif)) return;
        lastNotif = s;
        getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotif());
    }

    private PendingIntent act(String a, int code) {
        return PendingIntent.getService(this, code, new Intent(this, ShieldService.class).setAction(a),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildNotif() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, SettingsActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode)
                .setContentTitle(L.t(enabled(this) ? "🔇 Escudo anti-«Ok Google»" : "🐑 Asistente SSS+"))
                .setContentText(status())
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), L.t("Pausar 1 h"), act(ACT_PAUSE, 11)).build())
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), L.t("Detener hoy"), act(ACT_TODAY, 12)).build())
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_lock_power_off), L.t("Apagar"), act(ACT_OFF, 13)).build())
                .build();
    }

    @Override
    public void onDestroy() {
        alive = false;
        running = false;
        if (thread != null) try { thread.join(800); } catch (InterruptedException ignored) {}
        capturing = false;
        if (am != null && cb != null) try { am.unregisterAudioRecordingCallback(cb); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
