package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * El "cerebro" del asistente de SSS+ (v0.9.2): le pregunta a Gemini por la API de Google AI Studio.
 * La clave la pone el usuario en Ajustes (es suya y se queda solo en el teléfono).
 */
public class Brain {
    static final String DEFAULT_MODEL = "gemini-flash-latest";
    static final String DEFAULT_PERSONA = "Eres el asistente de voz de SSS+, una app de BLORP.eoac. Eres simpático, claro y vas al grano.";

    /** Conversación reciente (para que recuerde de qué se hablaba). */
    static final List<String[]> history = new ArrayList<>();      // {"user"|"model", texto}

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static String key(Context c) { return prefs(c).getString("ai_key", "").trim(); }
    static String model(Context c) { String m = prefs(c).getString("ai_model", "").trim(); return m.isEmpty() ? DEFAULT_MODEL : m; }
    static String persona(Context c) { String s = prefs(c).getString("ai_persona", "").trim(); return s.isEmpty() ? DEFAULT_PERSONA : s; }
    static boolean search(Context c) { return prefs(c).getBoolean("ai_search", true); }

    /** Pregunta (bloquea: llamar desde un hilo aparte). Devuelve la respuesta o un mensaje de error para leer en voz alta. */
    static String ask(Context c, String question) {
        String k = key(c);
        if (k.isEmpty()) return L.t("Aún no tengo cerebro: pon tu clave de Gemini en Ajustes, en el apartado Asistente.");
        try {
            JSONObject body = new JSONObject();
            String lang = "es".equals(L.lang) ? "español" : "it".equals(L.lang) ? "italiano" : "English";
            body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text",
                    persona(c) + "\nResponde siempre en " + lang + ". Tus respuestas se leen en voz alta: frases cortas, sin listas, "
                            + "sin asteriscos ni símbolos, y como mucho unas 4 frases salvo que te pidan más."))));
            JSONArray contents = new JSONArray();
            synchronized (history) {
                for (String[] h : history)
                    contents.put(new JSONObject().put("role", h[0]).put("parts", new JSONArray().put(new JSONObject().put("text", h[1]))));
            }
            contents.put(new JSONObject().put("role", "user").put("parts", new JSONArray().put(new JSONObject().put("text", question))));
            body.put("contents", contents);
            if (search(c)) body.put("tools", new JSONArray().put(new JSONObject().put("google_search", new JSONObject())));

            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model(c) + ":generateContent");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setConnectTimeout(15000);
            con.setReadTimeout(60000);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            con.setRequestProperty("x-goog-api-key", k);
            try (OutputStream os = con.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
            int code = con.getResponseCode();
            String resp = read(code >= 400 ? con.getErrorStream() : con.getInputStream());
            con.disconnect();
            if (code >= 400) {
                String msg = "";
                try { msg = new JSONObject(resp).getJSONObject("error").getString("message"); } catch (Exception ignored) {}
                if (code == 400 || code == 403) return L.t("Gemini no acepta la clave o el modelo. Revisa la clave en Ajustes.") + (msg.isEmpty() ? "" : " (" + msg + ")");
                if (code == 429) return L.t("Gemini dice que has hecho demasiadas preguntas seguidas. Espera un poco.");
                return L.t("Gemini no ha podido responder") + " (" + code + ").";
            }
            JSONObject o = new JSONObject(resp);
            JSONArray parts = o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length(); i++) {
                JSONObject pt = parts.getJSONObject(i);
                if (pt.has("text") && !pt.optBoolean("thought", false)) sb.append(pt.getString("text"));
            }
            String ans = clean(sb.toString());
            if (ans.isEmpty()) ans = L.t("No se me ocurre qué responder.");
            synchronized (history) {
                history.add(new String[]{"user", question});
                history.add(new String[]{"model", ans});
                while (history.size() > 12) history.remove(0);
            }
            return ans;
        } catch (java.net.UnknownHostException e) {
            return L.t("No tengo internet ahora mismo.");
        } catch (Exception e) {
            return L.t("Algo ha fallado al hablar con Gemini: ") + e.getMessage();
        }
    }

    /** Quita símbolos de formato para que la voz no los lea. */
    static String clean(String s) {
        return s.replaceAll("[*#_`>]+", "").replaceAll("\\[(.*?)\\]\\(.*?\\)", "$1").replaceAll("\\s+", " ").trim();
    }

    static String read(InputStream in) throws java.io.IOException {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }
}
