package com.aplauso.encuentra;

/**
 * Motor de jefes de EL PASTOR DE ECOS.
 * Los jefes "normales" combinan movimientos de una lista (carga, golpe en el suelo, abanico, lluvia...).
 * Los secuaces del Conde y el propio Conde tienen su propio comportamiento.
 */
public class EcoBoss {
    static final int W = EcoWorld.W, H = EcoWorld.H;
    // movimientos propios del Conde
    static final int CM_MELEE = 100, CM_BATS = 101, CM_ORBS = 102, CM_RUN = 103, CM_DASH = 104, CM_JUMP = 105;

    static EcoView.Enemy spawn(EcoView v, EcoData.Boss d, float x, float y) {
        EcoView.Enemy e = new EcoView.Enemy();
        e.type = 'B';
        e.bdef = d;
        e.boss = true;
        e.b = new EcoView.Body(d.w, d.h);
        e.hp = e.maxHp = d.hp;
        e.dmg = d.dmg;
        e.flying = d.flyer;
        e.b.x = x + 0.5f - d.w / 2;
        e.b.y = y + 1 - d.h;
        if (d.id.equals("V3")) e.b.x = 25;
        e.b.x = GameKit.clamp(e.b.x, 1, W - 1 - d.w);
        e.homeX = e.b.x; e.homeY = e.b.y;
        e.cd = 1.4f;
        e.bellsMin = e.bellsMax = 100 + (int) (d.hp / 6);
        v.enemies.add(e);
        return e;
    }

    static void update(EcoView v, EcoView.Enemy e, float dt) {
        if (EcoBoss2.handles(e.bdef.id)) EcoBoss2.update(v, e, dt);
        else switch (e.bdef.id) {
            case "V1": harold(v, e, dt); break;
            case "V2": aloii(v, e, dt); break;
            case "V3": plant(v, e, dt); break;
            case "V4": sangre(v, e, dt); break;
            case "V5": conde(v, e, dt); break;
            default: generic(v, e, dt);
        }
        if (e.sayT > 0) e.sayT -= dt;
        EcoView.Body b = e.b;
        b.x = GameKit.clamp(b.x, 1, W - 1 - b.w);
        b.y = GameKit.clamp(b.y, 1, H - 1 - b.h);
    }

    /** Daño que recibe según el estado (algunos jefes solo son vulnerables aturdidos). */
    static float damageMult(EcoView.Enemy e) {
        if (e.bdef == null) return 1;
        switch (e.bdef.id) {
            case "V1": return e.state == 3 ? 1f : 0.35f;
            case "V4": return e.state == 4 ? 1.5f : 0.25f;     // aturdido: castigo extra
            default: return e.invuln ? 0 : 1;
        }
    }

    // ---------------------------------------------------------------------
    static float px(EcoView v) { return v.pl.x + v.pl.w / 2; }
    static float py(EcoView v) { return v.pl.y + v.pl.h / 2; }
    static float cx(EcoView.Enemy e) { return e.b.x + e.b.w / 2; }
    static float cy(EcoView.Enemy e) { return e.b.y + e.b.h / 2; }

    static void gravity(EcoView v, EcoView.Enemy e, float dt) {
        e.b.vy += EcoView.GRAV * dt;
        v.moveBody(e.b, dt, false);
    }

    static void hover(EcoView.Enemy e, float tx, float ty, float dt, float speed) {
        e.b.x += (tx - e.b.w / 2 - e.b.x) * Math.min(1, dt * speed);
        e.b.y += (ty - e.b.h / 2 - e.b.y) * Math.min(1, dt * speed);
    }

    static void fan(EcoView v, EcoView.Enemy e, int n, float spread, float speed, int kind) {
        float ex = cx(e), ey = cy(e);
        double a0 = Math.atan2(py(v) - ey, px(v) - ex);
        for (int i = 0; i < n; i++) {
            double a = a0 + (i - (n - 1) / 2f) * spread;
            v.enemyShot(kind, ex, ey, (float) Math.cos(a) * speed, (float) Math.sin(a) * speed, 0, 0.45f, e.dmg, e.bdef.c2);
        }
        v.chip.sfx(Chip.SFX_SHOOT);
    }

    static void ring(EcoView v, EcoView.Enemy e, int n, float speed, float rot) {
        float ex = cx(e), ey = cy(e);
        for (int i = 0; i < n; i++) {
            double a = rot + Math.PI * 2 * i / n;
            v.enemyShot(EcoView.SH_ORB, ex, ey, (float) Math.cos(a) * speed, (float) Math.sin(a) * speed, 0, 0.45f, e.dmg, e.bdef.c2);
        }
        v.chip.sfx(Chip.SFX_TALK);
    }

    static int minions(EcoView v) {
        int n = 0;
        for (EcoView.Enemy o : v.enemies) if (!o.boss && !o.dead) n++;
        return n;
    }

    static void summon(EcoView v, EcoView.Enemy e, int n) {
        String id = e.bdef.summon;
        if (id == null || id.isEmpty()) return;
        for (int i = 0; i < n && minions(v) < 3; i++) {
            float x = GameKit.clamp(cx(e) + (i == 0 ? -2.5f : 2.5f), 2, W - 3);
            EcoView.Enemy m = v.spawnKind(id, x, EcoData.kind(id).flies() ? 5 : 13);
            if (m != null) { m.bellsMin = 0; m.bellsMax = 1; }
        }
        v.chip.sfx(Chip.SFX_POWER);
    }

    static void endMove(EcoView.Enemy e, float k, EcoView v) {
        e.state = 0;
        e.cd = (1.2f + v.rnd.nextFloat() * 0.7f) / k;
        e.sub = 0;
        e.t2 = 0;
        e.invuln = false;
        e.vis = 1;
    }

    // =====================================================================
    // Jefes normales
    // =====================================================================
    static void generic(EcoView v, EcoView.Enemy e, float dt) {
        EcoData.Boss d = e.bdef;
        EcoView.Body b = e.b;
        float px = px(v), py = py(v), ex = cx(e), ey = cy(e), dx = px - ex;
        if (!v.fightActive) {
            if (e.flying) hover(e, e.homeX + b.w / 2, e.homeY + b.h / 2 + (float) Math.sin(e.t * 2) * 0.3f, dt, 3);
            else gravity(v, e, dt);
            return;
        }
        e.phase2 = e.hp < e.maxHp / 2;
        float k = e.phase2 ? 1.3f : 1f;
        if (e.stun > 0) {
            e.stun -= dt;
            if (!e.flying) { b.vx = 0; gravity(v, e, dt); }
            return;
        }
        e.t2 += dt;
        if (e.state == 0) {
            if (e.flying) hover(e, px + (float) Math.sin(e.t * 0.8f) * 6, 7.5f + (float) Math.sin(e.t * 1.7f) * 2.2f, dt, 1.3f);   // baja lo bastante para darle saltando
            else {
                b.vx = Math.signum(dx) * d.speed * 0.35f * k;
                e.dir = Math.signum(dx) == 0 ? e.dir : Math.signum(dx);
                gravity(v, e, dt);
            }
            e.cd -= dt;
            if (e.cd <= 0) {
                e.move = d.moves[e.cycle % d.moves.length];
                e.cycle++;
                e.state = 1; e.t2 = 0; e.sub = 0;
            }
            return;
        }
        doMove(v, e, dt, k, d.moves == null ? 0 : e.move);
    }

    static void doMove(EcoView v, EcoView.Enemy e, float dt, float k, int move) {
        EcoData.Boss d = e.bdef;
        EcoView.Body b = e.b;
        float px = px(v), py = py(v), ex = cx(e), ey = cy(e), dx = px - ex, dy = py - ey;
        switch (move) {
            case EcoData.MV_CHARGE:
                if (e.sub == 0) {
                    b.vx = 0;
                    e.flash = ((int) (e.t2 * 12)) % 2 == 0 ? 0.05f : 0;
                    if (!e.flying) gravity(v, e, dt);
                    if (e.t2 > 0.45f) {
                        e.sub = 1; e.t2 = 0;
                        e.dir = Math.signum(dx) == 0 ? 1 : Math.signum(dx);
                        float dd = (float) Math.max(0.1, Math.hypot(dx, dy));
                        e.aux = dx / dd; e.aux2 = dy / dd;
                        v.chip.sfx(Chip.SFX_DOOR);
                    }
                } else if (!e.flying) {
                    b.vx = e.dir * d.speed * 2.4f * k;
                    gravity(v, e, dt);
                    if (b.hitWall) { e.stun = 0.9f; v.chip.sfx(Chip.SFX_BOOM); v.shake = 0.3f; endMove(e, k, v); }
                    else if (e.t2 > 2.5f) endMove(e, k, v);
                } else {
                    b.x += e.aux * 13 * k * dt;
                    b.y += e.aux2 * 13 * k * dt;
                    if (e.t2 > 1.0f || b.x <= 1 || b.x >= W - 1 - b.w || b.y >= H - 1 - b.h) endMove(e, k, v);
                }
                break;
            case EcoData.MV_SLAM:
                if (e.sub == 0) {
                    if (e.flying) {
                        hover(e, px, 3, dt, 4);
                        if (e.t2 > 0.7f) { e.sub = 1; b.vy = 4; }
                    } else {
                        gravity(v, e, dt);
                        if (b.onGround) { b.vy = -19; b.vx = GameKit.clamp(dx * 1.1f, -9, 9); e.sub = 1; v.chip.sfx(Chip.SFX_JUMP); }
                    }
                } else if (e.sub == 1) {
                    if (e.flying) { b.vy += 60 * dt; b.y += b.vy * dt; }
                    else gravity(v, e, dt);
                    boolean landed = e.flying ? b.y + b.h >= H - 1.05f : b.onGround && e.t2 > 0.15f;
                    if (landed) {
                        b.vx = 0;
                        float fy = b.y + b.h - 0.6f;
                        v.enemyShot(EcoView.SH_SHOCK, ex - 0.4f, fy, -9 * k, 0, 0, 0.7f, e.dmg, d.c2);
                        v.enemyShot(EcoView.SH_SHOCK, ex + 0.4f, fy, 9 * k, 0, 0, 0.7f, e.dmg, d.c2);
                        v.chip.sfx(Chip.SFX_BOOM);
                        v.shake = 0.35f;
                        if (e.flying) { e.sub = 2; e.t2 = 0; } else endMove(e, k, v);
                    }
                } else {
                    hover(e, ex, 4, dt, 2.5f);
                    if (e.t2 > 0.9f) endMove(e, k, v);
                }
                break;
            case EcoData.MV_FAN:
                if (!e.flying) gravity(v, e, dt);
                if (e.t2 > 0.35f) { fan(v, e, e.phase2 ? 7 : 5, 0.2f, 8 * k, EcoView.SH_ORB); endMove(e, k, v); }
                break;
            case EcoData.MV_RAIN:
                if (!e.flying) gravity(v, e, dt);
                if (e.sub == 0) {
                    int n = e.phase2 ? 9 : 6;
                    e.lanes = new float[n];
                    for (int i = 0; i < n; i++) {
                        e.lanes[i] = 2 + v.rnd.nextFloat() * (W - 4);
                        v.warn(e.lanes[i] - 0.3f, 1, 0.6f, H - 2, 0.7f);
                    }
                    e.sub = 1;
                } else if (e.t2 > 0.7f) {
                    for (float x : e.lanes) v.enemyShot(EcoView.SH_ORB, x, 1.2f, 0, 3, 22, 0.45f, e.dmg, d.c1);
                    endMove(e, k, v);
                }
                break;
            case EcoData.MV_RING:
                if (!e.flying) gravity(v, e, dt);
                if (e.t2 > 0.4f) { ring(v, e, e.phase2 ? 16 : 12, 6 * k, e.cycle * 0.3f); endMove(e, k, v); }
                break;
            case EcoData.MV_SUMMON:
                if (!e.flying) { b.vx = 0; gravity(v, e, dt); }
                if (e.sub == 0) { summon(v, e, e.phase2 ? 2 : 1); e.sub = 1; }
                if (e.t2 > 0.8f) endMove(e, k, v);
                break;
            case EcoData.MV_DIVE:
                if (!e.flying) { doMove(v, e, dt, k, EcoData.MV_SLAM); return; }
                if (e.sub == 0) {
                    hover(e, px, 2.5f, dt, 4);
                    e.flash = ((int) (e.t2 * 10)) % 2 == 0 ? 0.05f : 0;
                    if (e.t2 > 0.6f) {
                        e.sub = 1; e.t2 = 0;
                        float dd = (float) Math.max(0.1, Math.hypot(dx, dy));
                        e.aux = dx / dd; e.aux2 = dy / dd;
                        v.chip.sfx(Chip.SFX_DOOR);
                    }
                } else if (e.sub == 1) {
                    b.x += e.aux * 15 * k * dt;
                    b.y += e.aux2 * 15 * k * dt;
                    if (b.y + b.h >= H - 1.05f || e.t2 > 1.4f || b.x <= 1 || b.x >= W - 1 - b.w) {
                        e.sub = 2; e.t2 = 0;
                        v.chip.sfx(Chip.SFX_BOOM);
                    }
                } else if (e.sub == 2) {        // descansa en el suelo: ¡ahora!
                    if (e.t2 > 0.8f) { e.sub = 3; e.t2 = 0; }
                } else {
                    hover(e, ex, 4, dt, 2.5f);
                    if (e.t2 > 0.8f) endMove(e, k, v);
                }
                break;
            case EcoData.MV_TELEPORT:
                if (!e.flying) { b.vx = 0; gravity(v, e, dt); }
                if (e.sub == 0) {
                    e.invuln = true;
                    e.vis = Math.max(0, 1 - e.t2 / 0.4f);
                    if (e.t2 > 0.4f) {
                        float nx = px - Math.signum(dx == 0 ? 1 : dx) * 7;
                        if (nx < 2 || nx > W - 3) nx = px + Math.signum(dx == 0 ? 1 : dx) * 7;
                        b.x = GameKit.clamp(nx - b.w / 2, 1, W - 1 - b.w);
                        if (e.flying) b.y = 3;
                        e.sub = 1; e.t2 = 0;
                    }
                } else {
                    e.vis = Math.min(1, e.t2 / 0.3f);
                    if (e.t2 > 0.4f) { e.invuln = false; fan(v, e, 3, 0.25f, 8 * k, EcoView.SH_ORB); endMove(e, k, v); }
                }
                break;
            case EcoData.MV_LASER:
                if (!e.flying) { b.vx = 0; gravity(v, e, dt); }
                if (e.sub == 0) {
                    e.laserY = GameKit.clamp(e.flying ? py : ey, 1.5f, H - 1.8f);
                    v.warn(1, e.laserY - 0.3f, W - 2, 0.6f, 0.8f);
                    e.sub = 1;
                } else if (e.sub == 1 && e.t2 > 0.8f) {
                    EcoView.Shot s = v.enemyShot(EcoView.SH_BEAM, 1, e.laserY - 0.3f, 0, 0, 0, 0.6f, e.dmg * 1.2f, d.c1);
                    s.x = 1; s.w = W - 2; s.h = 0.6f; s.life = 0.45f;
                    v.chip.sfx(Chip.SFX_BOOM);
                    e.sub = 2;
                } else if (e.sub == 2 && e.t2 > 1.3f) endMove(e, k, v);
                break;
            case EcoData.MV_HOP:
                gravity(v, e, dt);
                if (b.onGround) {
                    b.vx = 0;
                    if (e.sub >= 3) { endMove(e, k, v); break; }
                    if (e.t2 > 0.25f) { b.vy = -11; b.vx = Math.signum(dx) * 5 * k; e.sub++; e.t2 = 0; v.chip.sfx(Chip.SFX_JUMP); }
                }
                break;
            case EcoData.MV_MIRROR:
                if (!e.flying) { b.vx = 0; gravity(v, e, dt); }
                if (e.t2 > 0.35f * (e.sub + 1)) {
                    float dir = Math.signum(dx) == 0 ? 1 : Math.signum(dx);
                    EcoView.Shot s = v.enemyShot(EcoView.SH_EWAVE, ex, ey - 0.3f, dir * 13 * k, 0, 0, 0.6f, e.dmg, d.c2);
                    s.w = 0.5f; s.h = 0.9f;
                    v.chip.sfx(Chip.SFX_SHOOT);
                    e.sub++;
                    if (e.sub >= 3) endMove(e, k, v);
                }
                break;
            case EcoData.MV_VINES: {
                if (!e.flying) { b.vx = 0; if (!d.id.equals("V3")) gravity(v, e, dt); }
                float[] lanes = d.id.equals("V3") ? new float[]{14, 10, 7, 4} : new float[]{14, 10, 7};
                if (e.sub == 0) {
                    int n = d.id.equals("V3") ? (e.phase2 ? 3 : 2) : (e.phase2 ? 2 : 1);
                    java.util.List<Float> pool = new java.util.ArrayList<>();
                    for (float l : lanes) pool.add(l);
                    java.util.Collections.shuffle(pool, v.rnd);
                    e.lanes = new float[n];
                    for (int i = 0; i < n; i++) {
                        e.lanes[i] = pool.get(i);
                        v.warn(1, e.lanes[i] + 0.05f, W - 2, 0.8f, 0.9f);
                    }
                    e.sub = 1;
                } else if (e.sub == 1 && e.t2 > 0.9f) {
                    for (float l : e.lanes) {
                        EcoView.Shot s = v.enemyShot(EcoView.SH_VINE, 1, l + 0.1f, 0, 0, 0, 0.7f, e.dmg, d.c2);
                        s.x = d.id.equals("V3") ? 1 : 1; s.w = d.id.equals("V3") ? 24.5f : W - 2; s.h = 0.7f; s.life = 0.6f;
                    }
                    v.chip.sfx(Chip.SFX_BOOM);
                    e.sub = 2;
                } else if (e.sub == 2 && e.t2 > 1.6f) endMove(e, k, v);
                break;
            }
            default:
                endMove(e, k, v);
        }
    }

    // =====================================================================
    // HAROLD VAMPIS: corre a morderte; si choca contra un muro se queda atontado 2 s
    // =====================================================================
    static void harold(EcoView v, EcoView.Enemy e, float dt) {
        EcoView.Body b = e.b;
        float dx = px(v) - cx(e), dy = py(v) - cy(e);
        if (!v.fightActive) { gravity(v, e, dt); return; }
        e.phase2 = e.hp < e.maxHp / 2;
        e.t2 += dt;
        switch (e.state) {
            case 0:     // camina y busca
                b.vx = Math.signum(dx) * 2;
                e.dir = Math.signum(dx) == 0 ? e.dir : Math.signum(dx);
                gravity(v, e, dt);
                if (e.t2 > 0.8f && Math.abs(dy) < 3f) {
                    e.state = 1; e.t2 = 0;
                    e.say = "¡GRRRAAAH!"; e.sayT = 0.8f;
                }
                break;
            case 1:     // rugido (aviso)
                b.vx = 0;
                gravity(v, e, dt);
                if (e.t2 > 0.4f) { e.state = 2; e.t2 = 0; e.dir = Math.signum(dx) == 0 ? 1 : Math.signum(dx); v.chip.sfx(Chip.SFX_DOOR); }
                break;
            case 2:     // carrera
                b.vx = e.dir * (e.phase2 ? 11 : 9);
                gravity(v, e, dt);
                if (b.hitWall) {
                    e.state = 3; e.t2 = 0;
                    e.say = "¡¡OUCH!!"; e.sayT = 1.2f;
                    v.chip.sfx(Chip.SFX_BOOM); v.shake = 0.4f;
                } else if (Math.signum(dx) != e.dir && Math.abs(dx) > 4 && e.t2 > 1.0f) { e.state = 4; e.t2 = 0; }
                break;
            case 3:     // atontado: ¡ahora!
                b.vx = 0;
                gravity(v, e, dt);
                if (e.t2 > 2f) { e.state = 0; e.t2 = 0; }
                break;
            case 4:     // derrapa para darse la vuelta (torpe)
                b.vx *= 0.9f;
                gravity(v, e, dt);
                if (e.t2 > 0.5f) { e.state = 1; e.t2 = 0; }
                break;
        }
    }

    // =====================================================================
    // ALOII VAMPIS: posa, se enfada, vuela... y acaba huyendo en calzoncillos
    // =====================================================================
    static void aloii(EcoView v, EcoView.Enemy e, float dt) {
        EcoView.Body b = e.b;
        float px = px(v), py = py(v), dx = px - cx(e), dy = py - cy(e);
        if (!v.fightActive) { gravity(v, e, dt); return; }
        e.t2 += dt;
        if (e.role == 0) {                 // fase 1: lento y presumido
            e.cd -= dt; e.cd2 -= dt;
            if (e.sub == 1) {              // posando
                b.vx = 0;
                gravity(v, e, dt);
                if (e.t2 > 1.3f) { e.sub = 0; e.t2 = 0; }
            } else {
                b.vx = Math.signum(dx) * 1.3f;
                e.dir = Math.signum(dx) == 0 ? e.dir : Math.signum(dx);
                gravity(v, e, dt);
                if (e.cd <= 0) {
                    e.cd = 2.6f;
                    e.sub = 1; e.t2 = 0;
                    e.say = EcoData.ALOII_POSES[v.rnd.nextInt(EcoData.ALOII_POSES.length)]; e.sayT = 1.8f;
                }
            }
            if (e.cd2 <= 0) {
                e.cd2 = 3.4f;
                float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                v.enemyShot(EcoView.SH_ROSE, cx(e), cy(e), dx / d * 4, dy / d * 4, 0, 0.5f, e.dmg, 0xffff3060);
            }
            if (e.hp <= e.maxHp * 0.66f) {
                e.role = 1; e.flying = true; e.t2 = 0; e.sub = 0; e.cd = 1;
                e.say = EcoData.ALOII_RAGE[0]; e.sayT = 2f;
                v.chip.sfx(Chip.SFX_HURT);
            }
        } else if (e.role == 1) {          // fase 2: vuela y se lanza con la capa
            float k = e.hp < e.maxHp / 2 ? 1.3f : 1f;
            if (e.sub == 0) {
                hover(e, px + (float) Math.sin(e.t) * 5, 3.5f, dt, 2);
                e.cd -= dt;
                if (e.cd <= 0) { e.sub = 1; e.t2 = 0; }
            } else if (e.sub == 1) {       // aviso
                e.flash = ((int) (e.t2 * 12)) % 2 == 0 ? 0.05f : 0;
                if (e.t2 > 0.4f) {
                    float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                    e.aux = dx / d; e.aux2 = dy / d;
                    e.sub = 2; e.t2 = 0;
                    v.chip.sfx(Chip.SFX_DOOR);
                }
            } else {                       // embestida con la capa (apunta peor cuanto más enfadado)
                b.x += e.aux * 14 * k * dt;
                b.y += e.aux2 * 14 * k * dt;
                if (e.t2 > 0.6f || b.y + b.h >= H - 1.05f) { e.sub = 0; e.cd = 1.6f / k; }
            }
        } else {                           // fase 3: le das la vuelta al traje y huye
            e.invuln = true;
            e.flying = false;
            if (e.sub == 0) {
                gravity(v, e, dt);
                b.vx = 0;
                if (e.t2 > 0.6f) {
                    float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                    EcoView.Shot s = v.enemyShot(EcoView.SH_CAPE, cx(e), cy(e), dx / d * 9, dy / d * 9, 0, 1.2f, e.dmg, 0xff7a0012);
                    s.w = 1.3f; s.h = 0.9f;
                    e.say = "¡¡BUAAAAA!!"; e.sayT = 3f;
                    e.sub = 1; e.t2 = 0;
                }
            } else {
                e.dir = cx(e) < W / 2f ? -1 : 1;
                b.vx = e.dir * 10;
                gravity(v, e, dt);
                if (e.t2 > 0.5f && (b.x <= 1.05f || b.x >= W - 1.05f - b.w)) v.bossFled(e);
            }
        }
    }

    // =====================================================================
    // PLANTA CARNÍVORA: tallos espinosos en línea recta a una de las alturas
    // =====================================================================
    static void plant(EcoView v, EcoView.Enemy e, float dt) {
        e.b.vx = 0; e.b.vy = 0;
        if (!v.fightActive) return;
        e.phase2 = e.hp < e.maxHp / 2;
        float k = e.phase2 ? 1.25f : 1f;
        e.t2 += dt;
        if (e.state == 0) {
            e.cd -= dt;
            if (e.cd <= 0) { e.state = 1; e.t2 = 0; e.sub = 0; e.move = (e.cycle++ % 3 == 2) ? EcoData.MV_FAN : EcoData.MV_VINES; }
            return;
        }
        if (e.move == EcoData.MV_FAN) {
            if (e.t2 > 0.4f) { fan(v, e, e.phase2 ? 5 : 3, 0.25f, 7, EcoView.SH_ORB); endMove(e, k, v); }
        } else doMove(v, e, dt, k, EcoData.MV_VINES);
    }

    // =====================================================================
    // SANGRE JOVEN: salta, se coloca encima de ti 2 s y cae; si falla, aturdido 2 s
    // =====================================================================
    static void sangre(EcoView v, EcoView.Enemy e, float dt) {
        EcoView.Body b = e.b;
        float px = px(v), dx = px - cx(e);
        if (!v.fightActive) { gravity(v, e, dt); return; }
        e.phase2 = e.hp < e.maxHp / 2;
        e.t2 += dt;
        switch (e.state) {
            case 0:
                b.vx = Math.signum(dx) * (e.phase2 ? 7 : 6);
                gravity(v, e, dt);
                e.cd -= dt;
                if (e.cd <= 0 && b.onGround) { e.state = 1; e.t2 = 0; b.vy = -22; v.chip.sfx(Chip.SFX_JUMP); e.say = "¡Allá voy!"; e.sayT = 1; }
                break;
            case 1:     // sube
                b.y += b.vy * dt;
                b.vy += 20 * dt;
                hover(e, px, cy(e), dt, 3);
                if (b.y <= 2.5f || b.vy >= 0) { e.state = 2; e.t2 = 0; b.vy = 0; }
                break;
            case 2:     // se coloca encima (2 s)
                hover(e, px, 3f, dt, e.phase2 ? 4f : 3f);
                if (e.t2 > 2f) { e.state = 3; e.t2 = 0; b.vy = 6; v.chip.sfx(Chip.SFX_DUCK); }
                break;
            case 3:     // cae en picado
                b.vx = 0;
                b.vy += 70 * dt;
                v.moveBody(b, dt, false);
                if (b.onGround) {
                    v.chip.sfx(Chip.SFX_BOOM); v.shake = 0.3f;
                    boolean under = Math.abs(px - cx(e)) < b.w / 2 + v.pl.w / 2 + 0.2f;
                    if (under) { e.state = 0; e.cd = 1.2f; }
                    else { e.state = 4; e.t2 = 0; e.say = "¡Uy!"; e.sayT = 1.5f; }
                }
                break;
            case 4:     // aturdido: ¡ahora!
                b.vx = 0;
                gravity(v, e, dt);
                if (e.t2 > 2.5f) { e.state = 0; e.cd = 1.4f; }
                break;
        }
    }

    // =====================================================================
    // CONDE VAMPIS: usa los trucos de sus secuaces. Con Garras: cuerpo a cuerpo (25 por golpe).
    // =====================================================================
    static void conde(EcoView v, EcoView.Enemy e, float dt) {
        EcoView.Body b = e.b;
        float px = px(v), py = py(v), dx = px - cx(e), dy = py - cy(e);
        if (!v.fightActive) { gravity(v, e, dt); return; }
        e.phase2 = e.hp < e.maxHp / 2;
        float k = e.phase2 ? 1.3f : 1f;
        boolean claws = e.role == 1;
        e.t2 += dt;
        if (e.stun > 0) { e.stun -= dt; b.vx = 0; gravity(v, e, dt); return; }
        if (e.state == 0) {
            e.flying = false;
            b.vx = Math.signum(dx) * 1.6f * k;
            e.dir = Math.signum(dx) == 0 ? e.dir : Math.signum(dx);
            gravity(v, e, dt);
            e.cd -= dt;
            if (e.cd <= 0) {
                int[] seq = claws ? new int[]{CM_MELEE, CM_RUN, CM_MELEE, CM_DASH, CM_MELEE, CM_JUMP}
                        : new int[]{CM_BATS, CM_RUN, CM_ORBS, CM_DASH, CM_ORBS, CM_JUMP};
                e.move = seq[e.cycle++ % seq.length];
                e.state = 1; e.t2 = 0; e.sub = 0;
            }
            return;
        }
        switch (e.move) {
            case CM_MELEE:
                if (e.sub == 0) {          // se acerca
                    b.vx = Math.signum(dx) * 3 * k;
                    e.dir = Math.signum(dx) == 0 ? e.dir : Math.signum(dx);
                    gravity(v, e, dt);
                    if (Math.abs(dx) < 2.2f || e.t2 > 2.5f) { e.sub = 1; e.t2 = 0; e.say = "¡Hmm!"; e.sayT = 0.6f; }
                } else if (e.sub == 1) {   // prepara el zarpazo (lento)
                    b.vx = 0;
                    gravity(v, e, dt);
                    e.flash = ((int) (e.t2 * 14)) % 2 == 0 ? 0.05f : 0;
                    if (e.t2 > 0.6f / k) {
                        e.sub = 2; e.t2 = 0;
                        e.slashT = 0.25f;
                        v.chip.sfx(Chip.SFX_SWORD);
                        float reach = cx(e) + e.dir * 1.6f;
                        if (Math.abs(px - reach) < 1.8f && Math.abs(dy) < 2f) v.hurt(25, cx(e));
                    }
                } else {
                    gravity(v, e, dt);
                    if (e.t2 > 0.5f) endMove(e, k, v);
                }
                break;
            case CM_BATS:
                b.vx = 0; gravity(v, e, dt);
                if (e.sub == 0) {
                    e.say = "¡Hijos de la noche!"; e.sayT = 1.2f;
                    for (int i = 0; i < 3 && minions(v) < 4; i++) {
                        EcoView.Enemy m = v.spawnKind("X1", GameKit.clamp(cx(e) + (i - 1) * 2, 2, W - 3), 4);
                        if (m != null) { m.bellsMin = 0; m.bellsMax = 1; }
                    }
                    e.sub = 1;
                }
                if (e.t2 > 1f) endMove(e, k, v);
                break;
            case CM_ORBS:
                b.vx = 0; gravity(v, e, dt);
                if (e.t2 > 0.4f) { fan(v, e, e.phase2 ? 9 : 7, 0.18f, 7.5f * k, EcoView.SH_ORB); endMove(e, k, v); }
                break;
            case CM_RUN:          // la carrera de Harold
                if (e.sub == 0) {
                    b.vx = 0; gravity(v, e, dt);
                    if (e.t2 > 0.45f) { e.sub = 1; e.t2 = 0; e.dir = Math.signum(dx) == 0 ? 1 : Math.signum(dx); v.chip.sfx(Chip.SFX_DOOR); }
                } else {
                    b.vx = e.dir * 10 * k;
                    gravity(v, e, dt);
                    if (b.hitWall) { e.stun = 1.2f; v.shake = 0.35f; v.chip.sfx(Chip.SFX_BOOM); endMove(e, k, v); }
                    else if (e.t2 > 2.4f) endMove(e, k, v);
                }
                break;
            case CM_DASH:         // la capa de Aloii
                e.flying = true;
                if (e.sub == 0) {
                    hover(e, px, 3, dt, 3);
                    if (e.t2 > 0.8f) {
                        float d = (float) Math.max(0.1, Math.hypot(dx, dy));
                        e.aux = dx / d; e.aux2 = dy / d;
                        e.sub = 1; e.t2 = 0; v.chip.sfx(Chip.SFX_DOOR);
                    }
                } else {
                    b.x += e.aux * 15 * k * dt;
                    b.y += e.aux2 * 15 * k * dt;
                    if (e.t2 > 0.65f || b.y + b.h >= H - 1.05f) { e.flying = false; endMove(e, k, v); }
                }
                break;
            case CM_JUMP:         // la caída de Sangre Joven
                if (e.sub == 0) {
                    e.flying = true;
                    hover(e, px, 2.8f, dt, 2.5f);
                    if (e.t2 > 1.4f / k) { e.sub = 1; e.t2 = 0; b.vy = 6; }
                } else {
                    e.flying = false;
                    b.vx = 0;
                    b.vy += 70 * dt;
                    v.moveBody(b, dt, false);
                    if (b.onGround) {
                        v.shake = 0.35f; v.chip.sfx(Chip.SFX_BOOM);
                        if (Math.abs(px - cx(e)) > b.w / 2 + 0.6f) e.stun = 1.2f;
                        endMove(e, k, v);
                    }
                }
                break;
            default: endMove(e, k, v);
        }
    }
}
