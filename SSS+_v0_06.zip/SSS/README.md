# SSS+  (v0.6)

Hecho por **BLORP.eoac**.

Aplaudes 5 veces y el teléfono suena, aunque esté bloqueado o en silencio.

## Qué hace
- Escucha el micrófono con la pantalla bloqueada (queda una notificación fija "SSS+ activo").
- Nº de aplausos ajustable (2–8, por defecto 5) y sensibilidad (1–10).
- Sonido propio (oveja, lo que quieras) o el de alarma por defecto.
- Volumen ajustable; suena por el canal de alarma, así se oye aunque el móvil esté en silencio.
- Suena **una vez** (máximo 10 s). Se puede parar desde la notificación o abriendo la app.

## Novedades v0.6
- **🔔 Pastor de Ecos**: joystick analógico semitransparente (moverse con más o menos fuerza, empujar hacia arriba = saltar). En Pausa → 🎮 Controles: joystick o botones, opacidad y mando externo opcional.
- **🎮 Mando externo opcional** (Xbox, gamepad Bluetooth/USB o teclado) en Pastor, Gato, Bloques, Culebrita, Rompeladrillos, 2048 y Sudoku. Viene apagado; los controles táctiles siguen funcionando.
- **🐈 Gato Runner**: sin botones ↑↓: mitad derecha = saltar, mitad izquierda = agacharse. Los botones vuelven como opción, con opacidad ajustable.
- **🧱 Bloques**: ⚙ Ajustes con joystick en pantalla opcional (el deslizar sigue por defecto).
- **🗼 Torre Arriba**: cargador de 25 balas (+2 por nivel) y +1 de daño por bala; las balas ya no dan XP.
- **Juegos nuevos**: 🔢 2048 y 🧩 Sudoku (9×9, cuatro dificultades, notas, 3 errores máximo).
- **🧊 Visor 3D**: abre FBX, GLB/glTF y VRM además de STL y OBJ, y convierte entre STL, OBJ, FBX y GLB (base de VRM; un VRM de verdad necesita esqueleto).

## Novedades v0.5
- **🌐 Idiomas**: toda la app en español, inglés e italiano (Ajustes → Idioma). Por defecto, el idioma del teléfono.
- **🔔 El Pastor de Ecos, juego completo**: mundo de 306 salas al estilo Hollow Knight (14 zonas con fondos propios, mapa con la forma de cada sala, zoom y arrastre), 20 jefes de eco con su truco de cencerro (Titán de Hielo, Claudio, Sombraverde, Gargantúa, Madame Picadura, Don Caparazón, Coralia, Gran Búho Espía, Turo, Barón Grajófono, Bruma, Marquesa Polilla, Reina Nodriza, Vortex, Griselda, Don Baronio, Cabra Sombra y LUMENIA en dos fases), 7 mazmorras secretas con guardián (llaves de la Agente Garduña, la policía corrupta), vida en barra de 100, enemigos más fuertes cuanto más lejos, 44 emblemas (12 a la vez, se cambian en los fardos) y 6 habilidades (embestida, salto de pared, eco cargado...).
- **🦇 Set vampírico y final secreto**: Harold, Aloii, la Planta Carnívora, Sangre Joven y el Conde Vampis, cada uno con su música; Garras con zarpazos (efecto sangre opcional en la pausa) y el final secreto Nº 1.
- **🗼 Torre Arriba**: límites de estadísticas mucho más altos (vida hasta 3000), cargador con +2 balas por nivel, 5 puntos por nivel y menos séquito en los jefes.

## Novedades v0.4
- **➕ Adicionales**: Documentos (leer, editar y convertir PDF/EPUB/DOCX/TXT), Biblioteca con lectura en voz alta y marcador, Gestor de archivos (copiar, mover, renombrar, borrar, ZIP y RAR4) y Visor 3D (.stl y .obj).
- **Galería**: pestaña DOCS y, manteniendo pulsado, renombrar, mover, borrar, detalles, convertir y añadir a la biblioteca.
- **Editor de fotos**: tamaño exacto (ancho × alto) y calidad/compresión, y nueva interfaz clásica tipo galería (recortar con cuadrícula, girar, filtros, Guardar copia).
- **Editor de sonido**: efecto 8D y ecualizador de 5 bandas con vista previa.
- **Buscaminas**: Fácil 50, Normal 100, Difícil 150 y Nightmare 250 bombas, con lupa/zoom y modo bandera.
- **Rompeladrillos**: 20 niveles con dibujos y la pelota ya no atraviesa ladrillos.
- **Torre Arriba**: sin saltos imposibles, +5 XP por criatura, ajustes (volumen y apuntado automático o flecha hacia arriba).
- **Pastor de Ecos**: la Onda Ancha ya dispara desde el suelo; botones en las franjas oscuras.
- **Récords y partidas ya no se borran** al actualizar (firma fija de la app).

## Novedades v0.3
- **🔔 El Pastor de Ecos (fase 1)**: aventura metroidvania. 18 salas conectadas (Pradera Hundida, pueblo de Eco Hondo y Minas de Cobre), refugios con fardo para guardar, Sabelotodo y su Bestiario (secretos a las 10 muertes), Cartógrafa (mapas), Sapo Mercader (amuletos, 3 huecos), Herrera (cencerro nivel 1-5 con 3 especialidades), Trompeta de Brasas secreta, botas de doble salto, corderitos, cascabeles que se quedan donde caes, y 3 jefes: Rey Topo Loco, Vagoneta Fantasma y Murciégalo Gemelo (opcional).
- **🗼 Torre Arriba**: roguelike vertical hasta el piso 1000. XP, 5 estadísticas con límite (vida 50→1000, daño, salto, defensa con escuditos que se recargan en 30 s, robo de vida 1→10 %), jefe cada 15 pisos, jefe fuerte cada 30 y Guardián cada 60 (Gólem, Dragón, Caballero Oscuro, Ojo Arcano), alitas/escudo/imán/doble daño, partida guardada al salir y final especial en el piso 1000.
- **🐈 Gato Runner**: salta ovillos, agáchate ante chanclas; NIGHTMARE MODE (colores invertidos y más velocidad) cada 250 puntos durante 100.
- **🎵 Música chiptune original** generada por la app (sin archivos), con volumen y silencio en cada juego.
- **🧱 Bloques**: nuevos controles (arrastrar = mover casilla a casilla, tocar = girar, deslizar abajo = soltar) y botones ◀ ↻ ▶ ⬇ ⤓.
- **Galería**: detecta el acceso limitado a fotos ("Seleccionar fotos") y ofrece "Permitir todas"; nuevo botón "Abrir desde el teléfono".

## Novedades v0.2
- **ℹ Info**: batería (carga, temperatura, salud, ciclos, capacidad actual, corriente, voltaje, tiempo hasta carga), estado térmico y temperatura de CPU (si el fabricante lo permite), CPU, RAM, almacenamiento y dispositivo, en vivo.
- **🧹 Limpieza**: recomendaciones según el estado del móvil y opciones marcadas como Recomendado / Opcional / Con cuidado (caché de SSS+, herramienta de Android, capturas antiguas, videos grandes, fotos y audios grandes, ahorro de batería, desinstalar apps). Siempre eliges qué se borra y Android pide confirmación.
- **🎮 Juegos**: Culebrita, Bloques que caen, Rompeladrillos y Buscaminas, con récords.
- **✂ Editores** con galería automática:
  - Fotos: girar, espejo, voltear, recortes (1:1, 4:3, 3:4, 16:9, 9:16), filtros, brillo, contraste, saturación y zoom con dos dedos.
  - Video: recortar tramo, quitar sonido y extraer el audio (sin perder calidad).
  - Sonido: grabadora, recortar, volumen, fundidos, guardar en Música y **usar como sonido de SSS+**.
- Pantalla principal: línea de sistema (batería, temperatura, espacio libre) y accesos a las 4 secciones.

## Novedades v0.1.1
- Arreglado: el sonido de alarma se repetía sin parar (ahora suena una vez, máximo 10 s, con doble vigilancia).
- Notificación grande **🛑 DETENER** visible con el móvil bloqueado; tocarla o deslizarla también lo para.
- Encender la pantalla (botón de encendido) detiene el sonido.
- Pausa de 4 s tras sonar para que no se vuelva a activar sola.
- Detector de aplausos más listo: solo cuenta golpes muy cortos (aplausos); descarta voces, música, golpes largos y ruidos sostenidos.
- Seguro anti-bucle: si suena 3 veces seguidas sin que nadie lo pare, deja de escuchar 1 minuto.

## Novedades v0.1
- Nuevo nombre: **SSS+**.
- Interfaz HUD neón estilo Pipox: botón de encendido grande, panel de sistema en vivo (estado, medidor del micrófono con línea de umbral, puntos que se encienden con cada aplauso) y controles rápidos (Probar, Sonido, Volumen).
- Pantalla ⚙ Ajustes aparte: Detección, Sonido, Skin y Batería.
- Skin: colores rápidos, color RGB de los marcos, opacidad de paneles, color cambiante (arcoíris) con velocidad, y fondo de pantalla propio.

## Permisos (solo estos)
- Micrófono, notificaciones, servicio en primer plano y mantener activo (aplausos y grabadora).
- Fotos, videos y audio: solo se piden al entrar en Editores o Limpieza.
- **Sin internet** y sin contactos.

## Compilar el APK
### Opción A: GitHub (sin instalar nada, sirve desde el móvil)
1. En tu repositorio, sube **SSS.zip** tal cual (Add file → Upload files). Debe ser el único .zip del repositorio.
2. La compilación arranca sola (pestaña **Actions** → "Compilar APK").
3. Al terminar (~3 min), abre la ejecución y descarga **SSS-APK** (un .zip con el .apk dentro).
4. Instálalo en el teléfono (acepta "instalar apps de origen desconocido").

### Opción B: en el propio teléfono
Abre la carpeta con una app tipo AndroidIDE y compila `assembleRelease`.

### Opción C: Android Studio en PC
Abrir la carpeta → Build → Build APK.

## Uso
1. Abre SSS+ y toca el **botón de encendido** grande (acepta micrófono y notificaciones).
2. Elige tu sonido, ajusta el volumen y pulsa **▶ PROBAR**.
3. En ⚙ Ajustes → Batería, pon SSS+ sin restricciones (si no, algunas marcas lo cierran).

## Notas
- Si reinicias el teléfono, hay que abrir la app y activarla de nuevo (Android no deja encender el micrófono solo al arrancar).
- Usa algo de batería por tener el micrófono siempre escuchando.
- Si suena con ruidos que no son aplausos, baja la sensibilidad; si no detecta desde lejos, súbela.
