package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** PDF: leer el texto (PdfBox), crear PDF nuevos (Android) y dibujar páginas (PdfRenderer). */
public class DocPdf {
    private static boolean inited;

    static DocIO.Doc read(Context ctx, Uri uri, String title) throws Exception {
        if (!inited) { PDFBoxResourceLoader.init(ctx.getApplicationContext()); inited = true; }
        String text;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri); PDDocument pd = PDDocument.load(in)) {
            text = new PDFTextStripper().getText(pd);
        }
        DocIO.Doc d = new DocIO.Doc();
        d.title = title;
        d.type = "pdf";
        // une las líneas cortadas del PDF en párrafos
        StringBuilder cur = new StringBuilder();
        for (String raw : text.replace("\r", "").split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) { flush(d, cur); continue; }
            if (cur.length() > 0) {
                if (cur.charAt(cur.length() - 1) == '-') cur.setLength(cur.length() - 1);
                else cur.append(' ');
            }
            cur.append(line);
            char last = line.charAt(line.length() - 1);
            if ((last == '.' || last == '!' || last == '?' || last == ':') && line.length() < 70) flush(d, cur);
        }
        flush(d, cur);
        return d;
    }

    private static void flush(DocIO.Doc d, StringBuilder cur) {
        String t = cur.toString().trim();
        if (!t.isEmpty()) d.paras.add(t);
        cur.setLength(0);
    }

    /** Crea un PDF A4 con el texto del documento, paginado automáticamente. */
    static void write(DocIO.Doc d, OutputStream os) throws Exception {
        int pageW = 595, pageH = 842, margin = 54, width = pageW - margin * 2, contentH = pageH - margin * 2 - 20;
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (d.title != null && !d.title.isEmpty()) {
            sb.append(d.title);
            sb.setSpan(new StyleSpan(Typeface.BOLD), 0, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new RelativeSizeSpan(1.6f), 0, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append("\n\n");
        }
        for (String p : d.paras) sb.append(p).append("\n\n");
        TextPaint tp = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
        tp.setColor(Color.BLACK);
        tp.setTextSize(12);
        StaticLayout layout = StaticLayout.Builder.obtain(sb, 0, sb.length(), tp, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(2f, 1f)
                .build();
        PdfDocument pdf = new PdfDocument();
        TextPaint foot = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
        foot.setColor(Color.GRAY);
        foot.setTextSize(9);
        int line = 0, total = layout.getLineCount(), pageNo = 1;
        while (line < total) {
            int top = layout.getLineTop(line);
            int end = layout.getLineForVertical(top + contentH);
            if (layout.getLineBottom(end) > top + contentH && end > line) end--;
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create());
            Canvas c = page.getCanvas();
            c.save();
            c.translate(margin, margin - top);
            c.clipRect(0, top, width, layout.getLineBottom(end));
            layout.draw(c);
            c.restore();
            c.drawText(String.valueOf(pageNo), pageW / 2f, pageH - 24, foot);
            pdf.finishPage(page);
            line = end + 1;
            pageNo++;
        }
        if (total == 0) {
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, 1).create());
            pdf.finishPage(page);
        }
        pdf.writeTo(os);
        pdf.close();
    }

    // ---------------- páginas como imágenes ----------------
    static class Pages {
        ParcelFileDescriptor fd;
        PdfRenderer renderer;

        Pages(Context ctx, Uri uri) throws Exception {
            if ("file".equals(uri.getScheme())) {
                fd = ParcelFileDescriptor.open(new File(uri.getPath()), ParcelFileDescriptor.MODE_READ_ONLY);
            } else {
                fd = ctx.getContentResolver().openFileDescriptor(uri, "r");
            }
            renderer = new PdfRenderer(fd);
        }

        int count() { return renderer.getPageCount(); }

        synchronized Bitmap render(int index, int width) {
            try (PdfRenderer.Page page = renderer.openPage(index)) {
                int h = Math.round(width * page.getHeight() / (float) page.getWidth());
                Bitmap b = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888);
                b.eraseColor(Color.WHITE);
                page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                return b;
            } catch (Exception | OutOfMemoryError e) {
                return null;
            }
        }

        void close() {
            try { renderer.close(); } catch (Exception ignored) {}
            try { fd.close(); } catch (Exception ignored) {}
        }
    }

    // ---------------- abrir cualquier documento ----------------
    static DocIO.Doc load(Context ctx, Uri uri) throws Exception {
        String name = Media.nameOf(ctx, uri);
        String type = DocIO.typeOf(name);
        if (type == null) type = "txt";
        String title = DocIO.baseName(name);
        if (type.equals("pdf")) return read(ctx, uri, title);
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            switch (type) {
                case "epub": return DocIO.readEpub(in, title);
                case "docx": return DocIO.readDocx(in, title);
                case "html": return DocIO.readHtml(in, title);
                default: return DocIO.readTxt(in, title);
            }
        }
    }

    /** Guarda el documento en el formato pedido dentro de Documentos/SSS. */
    static Uri saveAs(Context ctx, DocIO.Doc d, String format) throws Exception {
        String name = (d.title == null || d.title.trim().isEmpty() ? "documento" : d.title.trim().replaceAll("[\\\\/:*?\"<>|]", "_"))
                + "_" + Media.stamp() + "." + format;
        File tmp = new File(ctx.getCacheDir(), "doc_" + System.currentTimeMillis() + "." + format);
        try (FileOutputStream fos = new FileOutputStream(tmp)) {
            switch (format) {
                case "pdf": write(d, fos); break;
                case "epub": DocIO.writeEpub(d, fos); break;
                case "docx": DocIO.writeDocx(d, fos); break;
                default: DocIO.writeTxt(d, fos);
            }
        }
        return Media.saveDoc(ctx, tmp, name, DocIO.mime(format));
    }
}
