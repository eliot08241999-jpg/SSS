package com.aplauso.encuentra;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/** Arte de píxeles de EL PASTOR DE ECOS: criaturas, jefes, vampiros, objetos y fondos de cada zona. */
public class EcoArt {

    static final Map<String, Bitmap[]> CACHE = new HashMap<>();

    static int dark(int c, float f) {
        return Color.argb(Color.alpha(c), (int) (Color.red(c) * f), (int) (Color.green(c) * f), (int) (Color.blue(c) * f));
    }

    static Bitmap[] two(Bitmap a, Bitmap b) { return new Bitmap[]{a, b}; }

    // =====================================================================
    // Criaturas (plantillas + paleta de cada una)
    // =====================================================================
    static Bitmap[] kind(EcoData.Kind k) {
        Bitmap[] b = CACHE.get("k" + k.id);
        if (b != null) return b;
        b = template(k.tpl, k.c1, k.c2, k.c3);
        CACHE.put("k" + k.id, b);
        return b;
    }

    static final int BLACK = 0xff111116, WHITE = 0xffffffff;

    static Bitmap[] template(int tpl, int c1, int c2, int c3) {
        switch (tpl) {
            case EcoData.T_SLUG: {
                String[] a = {"........aa..", ".......aeaa.", "......aaaaa.", "...aaaaaaaa.", ".aaaaaaaaaa.", "bbbbbbbbbbb."};
                String[] f = {"........aa..", ".......aeaa.", "......aaaaa.", "..aaaaaaaaa.", "aaaaaaaaaaa.", "bbbbbbbbbbb."};
                return two(GameKit.sprite(a, "aeb", new int[]{c1, c2, c3}), GameKit.sprite(f, "aeb", new int[]{c1, c2, c3}));
            }
            case EcoData.T_BAT: {
                String[] a = {"v..........v", "vv...vv...vv", "vvv.vvvv.vvv", "vvvvvrrvvvvv", ".vvvvvvvvvv.", "...v....v..."};
                String[] f = {"............", ".....vv.....", ".vvvvrrvvvv.", "vvvvvvvvvvvv", "vv..vvvv..vv", "v....vv....v"};
                return two(GameKit.sprite(a, "vr", new int[]{c1, c2}), GameKit.sprite(f, "vr", new int[]{c1, c2}));
            }
            case EcoData.T_BEETLE: {
                String[] a = {"....bbbb....", "..bbBBBBbb..", ".bBBbBBbBBbk", ".bBBbBBbBBkk", "bbbbbbbbbbbk", ".k.k.k.k.k.."};
                String[] f = {"....bbbb....", "..bbBBBBbb..", ".bBBbBBbBBbk", ".bBBbBBbBBkk", "bbbbbbbbbbbk", "k.k.k.k.k.k."};
                return two(GameKit.sprite(a, "bBk", new int[]{c1, c2, c3}), GameKit.sprite(f, "bBk", new int[]{c1, c2, c3}));
            }
            case EcoData.T_MOLE: {
                String[] a = {"...yyyy.....", "..ooooooL...", "..bbbbbb....", ".bbkbbbbbb..", ".bbbbbbbppb.", ".bbbbbbbbb..", ".bbbbbbbbb..", "..pp...pp..."};
                String[] f = a.clone();
                f[7] = ".pp.....pp..";
                int[] pal = {c2, dark(c2, 0.75f), 0xffffffa0, c1, BLACK, c3};
                return two(GameKit.sprite(a, "yoLbkp", pal), GameKit.sprite(f, "yoLbkp", pal));
            }
            case EcoData.T_FROG: {
                String[] a = {"............", "..ww....ww..", ".wkwa..awkw.", ".aaaaaaaaaa.", "aaaabbbbaaaa", "aaabbbbbbaaa", ".aaaaaaaaaa.", "aa.a....a.aa"};
                String[] f = {"..ww....ww..", ".wkwa..awkw.", ".aaaaaaaaaa.", "aaaabbbbaaaa", "aaabbbbbbaaa", ".aaaaaaaaaa.", "a..........a", "a..........a"};
                int[] pal = {c3, BLACK, c1, c2};
                return two(GameKit.sprite(a, "wkab", pal), GameKit.sprite(f, "wkab", pal));
            }
            case EcoData.T_POD: {
                String[] a = {"....bbbb....", "..bbbbbbbb..", ".bbbaaaabbb.", ".bbakkkkabb.", ".bbakkkkabb.", "..bbaaaabb..", "....bbbb....",
                        ".....gg.....", "..gg.gg.gg..", "...ggggg....", ".....gg.....", "....gggg...."};
                String[] f = a.clone();
                f[3] = ".bbaaaaaabb."; f[4] = ".bbaaaaaabb.";
                int[] pal = {c1, c3, BLACK, c2};
                return two(GameKit.sprite(a, "bakg", pal), GameKit.sprite(f, "bakg", pal));
            }
            case EcoData.T_BIRD: {
                String[] a = {"....w...w...", "...ww..ww...", "..aaaaaaa...", ".aaekaaaaa..", "cc.aaaaaabb.", "...abababb..", "....a..a....", "............"};
                String[] f = {"............", "............", "..aaaaaaa...", ".aaekaaaaa..", "cc.aaaaaabb.", "..wabababbw.", ".ww.a..a.ww.", "............"};
                int[] pal = {c3, c1, WHITE, BLACK, c2, c2};
                return two(GameKit.sprite(a, "waekcb", pal), GameKit.sprite(f, "waekcb", pal));
            }
            case EcoData.T_SPIDER: {
                String[] a = {"k..k....k..k", ".k.k....k.k.", "..kaaaaaak..", ".kaaeaaeaak.", "k.aaaaaaaa.k", "..kaaaaaak..", ".k..k..k..k.", "k..........k"};
                String[] f = {".k.k....k.k.", "k..k....k..k", "..kaaaaaak..", ".kaaeaaeaak.", "k.aaaaaaaa.k", "..kaaaaaak..", "k..k....k..k", ".k........k."};
                int[] pal = {dark(c1, 0.6f), c1, c2};
                return two(GameKit.sprite(a, "kae", pal), GameKit.sprite(f, "kae", pal));
            }
            case EcoData.T_GHOST: {
                String[] a = {"....wwww....", "..wwwwwwww..", ".wwwwwwwwww.", ".wwkwwwwkww.", ".wwkwwwwkww.", ".wwwwwwwwww.", ".wwwwkkwwww.",
                        ".wwwwwwwwww.", ".wwwwwwwwww.", ".wwwwwwwwww.", ".ww.www.www.", ".w...w...w.."};
                String[] f = a.clone();
                f[10] = ".www.www.ww."; f[11] = "..w...w...w.";
                int[] pal = {Color.argb(200, Color.red(c1), Color.green(c1), Color.blue(c1)), c3};
                return two(GameKit.sprite(a, "wk", pal), GameKit.sprite(f, "wk", pal));
            }
            case EcoData.T_KNIGHT: {
                String[] a = {"...hhhh...", "..hhhhhh..", "..hkhhkh..", "..hhhhhh..", "...aaaa...", ".aaaaaaaa.", "aaabbbbaaa",
                        "a.aaaaaa.a", "..aaaaaa..", "..aa..aa..", "..aa..aa..", ".bbb..bbb."};
                String[] f = a.clone();
                f[9] = "..aa...aa."; f[10] = ".aa....aa."; f[11] = ".bb....bbb";
                int[] pal = {c2, BLACK, c1, c3};
                return two(GameKit.sprite(a, "hkab", pal), GameKit.sprite(f, "hkab", pal));
            }
            case EcoData.T_QUAD: {
                String[] a = {"..........ee..", "..........aaa.", ".aaaaaaaaaakaa", "aaaaaaaaaaaaab", "aaaaaaaaaaaa..", "taaaaaaaaaaa..", "t.a.a....a.a..", "..a.a....a.a.."};
                String[] f = a.clone();
                f[6] = "t..a.a..a.a..."; f[7] = "...a.a..a.a...";
                int[] pal = {c2, c1, c3, c2, c2};
                return two(GameKit.sprite(a, "eakbt", pal), GameKit.sprite(f, "eakbt", pal));
            }
            case EcoData.T_FISH: {
                String[] a = {"....aaaaaa....", "..aaaaaaaaaa..", ".aakaaaaaaaaaa", "aaaaaaaaaaaaa.", ".bbbbbbbbbaa.a", "..bbbbbbbb..aa", "...........a.."};
                String[] f = {"....aaaaaa....", "..aaaaaaaaaa..", ".aakaaaaaaaaa.", "aaaaaaaaaaaaaa", ".bbbbbbbbbaa..", "..bbbbbbbb.aa.", "............a."};
                int[] pal = {c1, BLACK, c2};
                return two(GameKit.sprite(a, "akb", pal), GameKit.sprite(f, "akb", pal));
            }
            case EcoData.T_SHROOM: {
                String[] a = {"...aaaa...", ".aaawaaaa.", "aawaaaaawa", "aaaaawaaaa", ".bbbbbbbb.", "...bbbb...", "...kbbk...", "...bbbb...", "..bbbbbb..", "..b....b.."};
                String[] f = {"..........", "...aaaa...", ".aaawaaaa.", "aawaaaaawa", "aaaaawaaaa", ".bbbbbbbb.", "...kbbk...", "..bbbbbb..", ".bbbbbbbb.", ".b......b."};
                int[] pal = {c1, c2, c2, c3};
                return two(GameKit.sprite(a, "awbk", pal), GameKit.sprite(f, "awbk", pal));
            }
            case EcoData.T_EYE: {
                String[] a = {"...wwwwww...", ".wwwwwwwwww.", "wwwwiiiiwwww", "wwwiikkiiwww", "wwwiikkiiwww", "wwwwiiiiwwww", ".wwwwwwwwww.", "...wwwwww..."};
                String[] f = {"............", "............", ".ssssssssss.", "ssssssssssss", "ssssssssssss", ".ssssssssss.", "............", "............"};
                int[] pal = {c2, c1, c3 == 0 ? BLACK : c3, dark(c1, 0.6f)};
                return two(GameKit.sprite(a, "wiks", pal), GameKit.sprite(f, "wiks", pal));
            }
            default: return null;    // T_ORB: se dibuja con círculos
        }
    }

    // =====================================================================
    // Jefes
    // =====================================================================
    static Bitmap[] boss(EcoData.Boss b, boolean alt) {
        String key = "b" + b.id + (alt ? "x" : "");
        Bitmap[] r = CACHE.get(key);
        if (r != null) return r;
        r = bossTemplate(b, alt);
        CACHE.put(key, r);
        return r;
    }

    static Bitmap[] bossTemplate(EcoData.Boss b, boolean alt) {
        int c1 = b.c1, c2 = b.c2, c3 = b.c3;
        switch (b.tpl) {
            case EcoData.BT_QUEEN: {
                String[] a = {"......cccc......", ".....c.cc.c.....", "......hhhh......", "ww...hkhhkh...ww", "www..hhhhhh..www", "wwww..hhhh..wwww",
                        "wwwwwaaaaaawwwww", ".wwwaaaaaaaawww.", "..wwaabbbbaaww..", "....aaaaaaaa....", "....aabbbbaa....", "...aaaaaaaaaa...",
                        "..aaaaaaaaaaaa..", "..aaaabbbbaaaa..", ".aaaaaaaaaaaaaa.", "................"};
                String[] f = a.clone();
                f[3] = ".....hkhhkh....."; f[4] = "w....hhhhhh....w"; f[5] = "ww....hhhh....ww"; f[6] = "wwwwwaaaaaawwwww"; f[7] = "wwwwaaaaaaaawwww";
                int[] pal = {0xffffd040, c3, BLACK, Color.argb(190, Color.red(c2), Color.green(c2), Color.blue(c2)), c1, c2};
                return two(GameKit.sprite(a, "chkwab", pal), GameKit.sprite(f, "chkwab", pal));
            }
            case EcoData.BT_WALRUS: {
                String[] a = {"......aaaaaaa.......", "....aaaaaaaaaaa.....", "...aakaaaaaakaaa....", "..aaaaaaaaaaaaaaa...", "..aaaabbbbbbaaaaaa..",
                        ".aaaabbbbbbbbaaaaaa.", ".aaaaw.bbbb.waaaaaa.", ".aaaaw......waaaaaaa", "aaaaaw......waaaaaaa", "aaaaaa......aaaaaaaa",
                        "aaaaaaaaaaaaaaaaaaaa", ".aaaaaaaaaaaaaaaaaa.", "aaa..aaa....aaa..aaa", "...................."};
                String[] f = a.clone();
                f[12] = ".aaa..aaa..aaa..aaa.";
                int[] pal = {c1, BLACK, c3, c2};
                return two(GameKit.sprite(a, "akbw", pal), GameKit.sprite(f, "akbw", pal));
            }
            case EcoData.BT_SHROOM: {
                String[] a = {".....aaaaaa.....", "...aaawwaaaaa...", "..aawwaaaaawwa..", ".aaaaaaawwaaaaa.", "aawwaaaaaaaaawwa", "aaaaaaaaaaaaaaaa",
                        ".bbbbbbbbbbbbbb.", "....bbbbbbbb....", "....bkkbbkkb....", "....bbbbbbbb....", "....bbmmmmbb....", "...bbbbbbbbbb...",
                        "..bbbbbbbbbbbb..", "..bbbbbbbbbbbb..", "..bbb......bbb..", ".bbbb......bbbb."};
                String[] f = a.clone();
                f[10] = "....bbbmmbbb....";
                int[] pal = {c1, c2, c2, BLACK, c3};
                return two(GameKit.sprite(a, "awbkm", pal), GameKit.sprite(f, "awbkm", pal));
            }
            case EcoData.BT_PLANT: {
                String[] a = {"....pppppppp....", "..pppppppppppp..", ".ppppwppppwpppp.", "pppppkkkkkkppppp", "ppppkwkwkwkkpppp", "pppkkkkkkkkkkppp",
                        "pppkwkwkwkwkkppp", ".ppppkkkkkkpppp.", "..pppppppppppp..", "......gggg......", "..ll..gggg..ll..", ".llll.gggg.llll.",
                        "lllllggggggllll.", ".lll..gggg..lll.", "......gggg......", ".....gggggg.....", "....gggggggg....", "...gggggggggg..."};
                String[] f = a.clone();
                f[4] = "ppppkkkkkkkkpppp"; f[5] = "pppkkkkkkkkkkppp"; f[6] = "pppkkkkkkkkkkppp";
                int[] pal = {c1, WHITE, 0xff200008, c2, dark(c2, 0.8f)};
                return two(GameKit.sprite(a, "pwkgl", pal), GameKit.sprite(f, "pwkgl", pal));
            }
            case EcoData.BT_GOLEM: {
                String[] a = {"....aaaaaaaa....", "...aaaaaaaaaa...", "...aawwaawwaa...", "...aaaaaaaaaa...", ".bbbaaaaaaaabbb.", "bbbbbbaaaabbbbbb",
                        "bbb.bbbbbbbb.bbb", "bbb.bbbaabbb.bbb", "aaa.bbbbbbbb.aaa", "aaa.bbbbbbbb.aaa", "....bbbbbbbb....", "....bbb..bbb....",
                        "....bbb..bbb....", "...aaaa..aaaa..."};
                String[] f = a.clone();
                f[2] = "...aaaaaaaaaa...";
                int[] pal = {c2, c1, c3};
                return two(GameKit.sprite(a, "abw", pal), GameKit.sprite(f, "abw", pal));
            }
            case EcoData.BT_DRAGON: {
                String[] a = {"ww..............", "www......aaaa...", "wwww....aaakaa..", "wwwww..aaaaaaaa.", ".wwwwwaaaaaaayyy", "..wwwaaaaaaaa...",
                        "...aaaaaaaaa....", "..aaaaaaaaa.....", ".aaaaaaaaaa.....", "aaa.aa..aa......", "aa..aa..aa......"};
                String[] f = {"................", ".........aaaa...", "........aaakaa..", ".......aaaaaaaa.", "..wwwwaaaaaaayyy", ".wwwwaaaaaaaa...",
                        "wwwwaaaaaaaa....", "wwwaaaaaaaa.....", "ww.aaaaaaaa.....", "aaa.aa..aa......", "aa..aa..aa......"};
                int[] pal = {c2, c1, BLACK, c3};
                return two(GameKit.sprite(a, "waky", pal), GameKit.sprite(f, "waky", pal));
            }
            case EcoData.BT_BELL: {
                String[] a = {".......cc.......", "......cccc......", ".....aaaaaa.....", "....aaaaaaaa....", "...aakaaaakaa...", "...aaaaaaaaaa...",
                        "..aaaaaaaaaaaa..", "..aaaa.bb.aaaa..", ".aaaaa.bb.aaaaa.", ".aaaaaaaaaaaaaa.", "aaaaaaaaaaaaaaaa", "bbbbbbbbbbbbbbbb", ".......cc.......", "......cccc......"};
                String[] f = a.clone();
                f[12] = "......cc........"; f[13] = ".....cccc.......";
                int[] pal = {c3, c1, BLACK, c2};
                return two(GameKit.sprite(a, "cakb", pal), GameKit.sprite(f, "cakb", pal));
            }
            case EcoData.BT_MOTH: {
                String[] a = {"ww....kk....ww..", "www...kk...www..", "wwww.aaaa.wwww..", "wwwwwaawaawwwww.", "wwwbwaaaaawbwww.", "wwwwwaaaaawwwww.",
                        ".wwwwaaaaawwww..", "..www.aaa.www...", "..wwbw.a.wbww...", ".wwwww...wwwww..", "wwww.......wwww.", "ww...........ww."};
                String[] f = {"......kk........", "......kk........", "w....aaaa....w..", "ww..aawaaw..ww..", "wwwwwaaaaawwwww.", "wwwbwaaaaawbwww.",
                        "wwwwwaaaaawwwww.", "wwwwwwaaawwwwww.", "..wwbwwawwbww...", "...www...www....", "................", "................"};
                int[] pal = {c1, BLACK, c2, c3};
                return two(GameKit.sprite(a, "wkab", pal), GameKit.sprite(f, "wkab", pal));
            }
            case EcoData.BT_CENTI: {
                String[] a = {"....................aa..", "..aaaaaaaaaaaaaaaaaaaka.", ".abababababababababaaaa.", "aaaaaaaaaaaaaaaaaaaaaaa.", ".l.l.l.l.l.l.l.l.l.l.l..", "l.l.l.l.l.l.l.l.l.l.l..."};
                String[] f = a.clone();
                f[4] = "l.l.l.l.l.l.l.l.l.l.l..."; f[5] = ".l.l.l.l.l.l.l.l.l.l.l..";
                int[] pal = {c1, c2, BLACK, c3};
                return two(GameKit.sprite(a, "abkl", pal), GameKit.sprite(f, "abkl", pal));
            }
            case EcoData.BT_SNAIL: {
                String[] a = {".....ssssss.........", "...ssssssssss.......", "..sssbbbbbssss......", ".sssbbsssbbsss......", ".ssbbssbsssbsss..e.e", ".ssbsssbbssbsss..a.a",
                        ".sssbbsssbbsss..aaa.", "..sssbbbbbsss..aaaa.", "aaaaaaaaaaaaaaaaaaa.", "aaaaaaaaaaaaaaaaaaa."};
                String[] f = a.clone();
                f[4] = ".ssbbssbsssbsss.e.e."; f[5] = ".ssbsssbbssbsss.a.a.";
                int[] pal = {c1, c3, c2, BLACK};
                return two(GameKit.sprite(a, "sbae", pal), GameKit.sprite(f, "sbae", pal));
            }
            case EcoData.BT_SHEEP: {          // la Sombra del Pastor: Bee hecha de sombra
                String[] a = {"....wwww....", "..wwwwwwww..", ".wwWwwwwwww.", ".wwwwwwkkkw.", "wwwwwwkkkkk.", "wwWwwwkekkk.", "wwwwwwkkkk..",
                        ".wwwwwwyw...", ".wwWwwwwww..", "..wwwwwwww..", "..k.k..k.k..", "..k.k..k.k.."};
                String[] f = a.clone();
                f[10] = ".k..k..k..k."; f[11] = "k....kk....k";
                int[] pal = {c1, dark(c1, 1.6f), 0xff505070, c2, 0xff606080};
                return two(GameKit.sprite(a, "wWkey", pal), GameKit.sprite(f, "wWkey", pal));
            }
            case EcoData.BT_VAMP:
                return vampire(b, alt);
            case EcoData.BT_YETI: {
                String[] f0 = {"....wwwwww....", "...wwwwwwww...", "..wwkwwwwkww..", "..wwwwbbwwww..", "...wwbwwbww...", ".iiwwwwwwwwii.", "iiiwwwwwwwwiii",
                        "iiwwwwwwwwwwii", "iiwwwiiiiwwwii", "..wwwiiiiwww..", "..wwwwwwwwww..", "..www....www..", ".iiii....iiii."};
                String[] f1 = f0.clone();
                f1[11] = "..www.....www."; f1[12] = ".iiii.....iiii";
                int[] pal = {c1, BLACK, c3, c2};
                return two(GameKit.sprite(f0, "wkbi", pal), GameKit.sprite(f1, "wkbi", pal));
            }
            case EcoData.BT_DEER: {
                String[] f0 = {"b.b.....b.b...", ".bbb...bbb....", "..bb...bb.....", "...bbbbb......", "....aaaa......", "...akaak......", "...aaaaa......",
                        "....aagaaaaaa.", "...aaaaaaaaaaa", "...gaaagaaaga.", "...a.a....a.a.", "...a.a....a.a.", "..bb.bb..bb.bb"};
                String[] f1 = f0.clone();
                f1[10] = "..a...a..a...a"; f1[11] = ".a.....aa.....";
                int[] pal = {c2, c1, c3, BLACK};
                return two(GameKit.sprite(f0, "bagk", pal), GameKit.sprite(f1, "bagk", pal));
            }
            case EcoData.BT_TORTOISE: {
                String[] f0 = {"......cccc..........", "......c..c..........", ".....cccccc.........", ".....c.yy.c.........", "....ssssssss........",
                        "..ssssddssssss......", ".ssddssssddssss.hhh.", "ssssssssssssssshhkh.", ".sssddssssddsss.hhh.", "..hhh.......hhh.....", "..hhh.......hhh....."};
                String[] f1 = f0.clone();
                f1[6] = ".ssddssssddssss....."; f1[7] = "sssssssssssssss....."; f1[8] = ".sssddssssddsss....."; f1[9] = "...................."; f1[10] = "....................";
                int[] pal = {c3, 0xffffd040, c1, dark(c1, 0.7f), c2, BLACK};
                return two(GameKit.sprite(f0, "cysdhk", pal), GameKit.sprite(f1, "cysdhk", pal));
            }
            case EcoData.BT_JELLY: {
                String[] f0 = {"....aaaaaa....", "..aaaaaaaaaa..", ".aaawaaaaawaa.", "aaaaaaaaaaaaaa", "aabbbbbbbbbbaa", ".t..t..t..t..t", ".t..t..t..t..t", "t..t..t..t..t.",
                        "t..t..t..t..t.", ".t..t..t..t..t", ".t..t..t..t..t"};
                String[] f1 = {"..............", "....aaaaaa....", ".aaaaaaaaaaaa.", "aaawaaaaawaaaa", "aabbbbbbbbbbaa", "t..t..t..t..t.", "t..t..t..t..t.", ".t..t..t..t..t",
                        ".t..t..t..t..t", "t..t..t..t..t.", "t..t..t..t..t."};
                int[] pal = {Color.argb(210, Color.red(c1), Color.green(c1), Color.blue(c1)), c3, c2, Color.argb(200, Color.red(c2), Color.green(c2), Color.blue(c2))};
                return two(GameKit.sprite(f0, "awbt", pal), GameKit.sprite(f1, "awbt", pal));
            }
            case EcoData.BT_OWL: {
                String[] f0 = {"aa........aa", "aaa......aaa", ".aaaaaaaaaa.", "aggaaaaaagga", "agkgaaaagkga", "aggaayyaagga", ".aaaayyaaaa.", "aabbbbbbbbaa",
                        "aabgbbbbgbaa", "aabbbbbbbbaa", ".aabbbbbbaa.", "..yy....yy.."};
                String[] f1 = f0.clone();
                f1[3] = "aggaaaaaagga"; f1[4] = "aggaaaaaagga";
                int[] pal = {c1, c2, BLACK, 0xffffb030, c3};
                return two(GameKit.sprite(f0, "agkyb", pal), GameKit.sprite(f1, "agkyb", pal));
            }
            case EcoData.BT_ARMADILLO: {
                String[] f0 = {".....pppppp.......", "...pppPPpppPP.....", "..pPPppPPppPPpp...", ".pppPPppPPppPPpphh", "ppppppppppppppphkh", "pppppppppppppp.hh.",
                        ".ll.ll....ll.ll...", ".ll.ll....ll.ll..."};
                String[] f1 = f0.clone();
                f1[6] = "ll..ll...ll..ll..."; f1[7] = "l....l...l....l...";
                int[] pal = {c1, c2, dark(c1, 0.6f), dark(c2, 0.8f), BLACK};
                return two(GameKit.sprite(f0, "pPlhk", pal), GameKit.sprite(f1, "pPlhk", pal));
            }
            case EcoData.BT_ANTQ: {
                String[] f0 = {"..c.....c.....", "...c...c......", "....aaaa......", "...akaaka.....", "...aaaaaa.....", "..wwaaaaww....", ".wwwbbbbwww...",
                        "..wbbbbbbbbbb.", "...bbbbbbbbbbb", "..bbbbbbbbbbbb", "...bbbbbbbbbb.", "..l.l.l..l.l.."};
                String[] f1 = f0.clone();
                f1[5] = "...waaaaw.....";
                int[] pal = {c2, c1, BLACK, Color.argb(160, 255, 255, 255), dark(c1, 0.8f), c3};
                return two(GameKit.sprite(f0, "cakwbl", pal), GameKit.sprite(f1, "cakwbl", pal));
            }
            case EcoData.BT_LUMENIA: {
                if (alt) {        // fase 2: alas rasgadas y brillo interior
                    String[] f0 = {"w.w...kk...w.w..", "ww.w..kk..w.ww..", "w.ww.gggg.ww.w..", "wwwwwggggggwww..", "w.wbwgGGgwbw.w..", "wwww.ggggg.www..",
                            ".w.ww.ggg.ww.w..", "..ww..ggg..ww...", "..w.bw.g.wb.w...", ".w.w.......w.w..", "w..w.......w..w.", "w.............w."};
                    String[] f1 = f0.clone();
                    f1[4] = "w.wbwGGGGwbw.w.."; f1[5] = "wwww.GGGGG.www..";
                    int[] pal = {Color.argb(200, 60, 50, 80), BLACK, 0xffffffe0, 0xffffffff, c2};
                    return two(GameKit.sprite(f0, "wkgGb", pal), GameKit.sprite(f1, "wkgGb", pal));
                }
                String[] f0 = {"ww....kk....ww..", "www...kk...www..", "wwww.aaaa.wwww..", "wwwwwaacaawwwww.", "wwwswaaaaawswww.", "wwwwwacaacwwwww.",
                        ".wwwwaaaaawwww..", "..www.aca.www...", "..wwsw.a.wsww...", ".wwwww...wwwww..", "wwww.......wwww.", "ww...........ww."};
                String[] f1 = {"......kk........", "......kk........", "w....aaaa....w..", "ww..aacaac..ww..", "wwwwwaaaaawwwww.", "wwwswacaacwswww.",
                        "wwwwwaaaaawwwww.", "wwwwwwacawwwwww.", "..wwsww.wwsww...", "...www...www....", "................", "................"};
                int[] pal = {0xff16121e, BLACK, c1, 0xffc8c8dc, 0xff8a8aa8};
                return two(GameKit.sprite(f0, "wkacs", pal), GameKit.sprite(f1, "wkacs", pal));
            }
            case EcoData.BT_FROGB: return template(EcoData.T_FROG, c1, c2, c3);
            case EcoData.BT_BULL: case EcoData.BT_WOLF: case EcoData.BT_BEAVER: case EcoData.BT_RAM: return template(EcoData.T_QUAD, c1, c2, c3);
            case EcoData.BT_WOODPECKER: return template(EcoData.T_BIRD, c1, c2, c3);
            case EcoData.BT_MOLE: return template(EcoData.T_MOLE, c1, c2, c3);
            // jefes que usan las plantillas pequeñas en grande
            case EcoData.BT_KNIGHT: return template(EcoData.T_KNIGHT, c1, c2, c3);
            case EcoData.BT_BIRD: return template(EcoData.T_BIRD, c1, c2, c3);
            case EcoData.BT_SPIDER: return template(EcoData.T_SPIDER, c1, c2, c3);
            case EcoData.BT_RAT: return template(EcoData.T_QUAD, c1, c2, c3);
            case EcoData.BT_GHOST: return template(EcoData.T_GHOST, c1, c2, c3);
            default: return template(EcoData.T_SLUG, c1, c2, c3);
        }
    }

    /** Vampiros: traje, capa y colmillos. alt = Aloii en calzoncillos. */
    static Bitmap[] vampire(EcoData.Boss b, boolean alt) {
        String[] a = {"....hhhh....", "...hhhhhh...", "...ssssss...", "...srssrs...", "...ssssss...", "....swsw....", "..CCaaaaCC..",
                ".CCaawwaaCC.", ".CCaawwaaCC.", "CCCaarraaCCC", "CCCaaaaaaCCC", "CC.aaaaaa.CC", "C..aaaaaa..C", "...aaaaaa...",
                "...aa..aa...", "...aa..aa...", "...aa..aa...", "...kk..kk..."};
        String[] f = a.clone();
        f[14] = "...aa...aa.."; f[15] = "..aa....aa.."; f[16] = "..aa.....aa."; f[17] = "..kk.....kk.";
        int suit = b.c1, skin = b.c2;
        if (alt) {           // traje roto: calzoncillos y capa
            for (int i = 6; i < 14; i++) { a[i] = a[i].replace('a', 's').replace('w', 's').replace('r', 's'); f[i] = f[i].replace('a', 's').replace('w', 's').replace('r', 's'); }
            a[12] = "C..wwwwww..C"; a[13] = "...wwwwww..."; f[12] = a[12]; f[13] = a[13];
            for (int i = 14; i < 17; i++) { a[i] = a[i].replace('a', 's'); f[i] = f[i].replace('a', 's'); }
        }
        int[] pal = {0xff141018, skin, b.c3, WHITE, 0xff7a0012, suit, b.c3, BLACK};
        String keys = "hsrwCark";
        return two(GameKit.sprite(a, keys, pal), GameKit.sprite(f, keys, pal));
    }

    // =====================================================================
    // Personajes y objetos nuevos
    // =====================================================================
    static Bitmap police() {
        return GameKit.sprite(new String[]{"...bbbbbb...", "..bbbbbbbb..", ".bbbyybbbbb.", "....gggg....", "...gkggkg...", "...gggggg...", "....gwwg....",
                "...bbbbbb...", "..bbbybbbb..", "..bbbbbbbb..", "...bb..bb...", "...kk..kk..."}, "bygkw", new int[]{0xff28408a, 0xffffd040, 0xff9a6a3a, BLACK, 0xfff0e8e0});
    }

    static Bitmap corpse() {
        return GameKit.sprite(new String[]{"g.g.g...g.g.", ".ggg.....gg.", "..g..bbb..g.", ".....bkb....", "....wbbbw...", "...wwwwwww..",
                "..r.wwwww.r.", ".rr.w.w.w.rr", "rrr.wwwww.rr", "g...w...w..g", ".g.gww.ww.g.", "gggggggggggg"}, "gbkwr", new int[]{0xff3a6a2a, 0xffd0d0c0, BLACK, 0xffb0b0a0, 0xffc02030});
    }

    static Bitmap skeleton() {
        return GameKit.sprite(new String[]{"..www.......", ".wkwkw......", "..www..w.w..", "...w.wwwwww.", "..wwwwwww.w.", ".w.w.w.w.w.."}, "wk", new int[]{0xffe8e4d8, BLACK});
    }

    static Bitmap key(boolean crimson) {
        int c = crimson ? 0xffd02040 : 0xffffd040;
        return GameKit.sprite(new String[]{".ccc......", "c...c.....", "c...cccccc", "c...c..c.c", ".ccc...c.c"}, "c", new int[]{c});
    }

    static Bitmap gem(int c) {
        return GameKit.sprite(new String[]{"...cc...", "..cCCc..", ".cCwCCc.", "cCCCCCCc", ".cCCCCc.", "..cCCc..", "...cc..."}, "cCw", new int[]{dark(c, 0.6f), c, WHITE});
    }

    static Bitmap wings() {
        return GameKit.sprite(new String[]{"k..............k", "kk............kk", "kkk..........kkk", "kkkk........kkkk", "kkkkk......kkkkk",
                ".kkrkk....kkrkk.", "..kkkk....kkkk..", "...k.k....k.k..."}, "kr", new int[]{0xff100008, 0xff901020});
    }

    // =====================================================================
    // Fondos temáticos (se pintan una vez por sala, 8 píxeles por casilla)
    // =====================================================================
    static void background(Canvas bc, EcoData.Zone z, int w, int h, long seed, boolean dungeon) {
        Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
        q.setShader(new LinearGradient(0, 0, 0, h, z.top, z.bot, Shader.TileMode.CLAMP));
        bc.drawRect(0, 0, w, h, q);
        q.setShader(null);
        Random r = new Random(seed);
        int far = Color.argb(70, Color.red(z.edge), Color.green(z.edge), Color.blue(z.edge));
        int mid = Color.argb(45, 0, 0, 0);
        switch (z.bg) {
            case EcoData.BG_HILLS:
                q.setColor(Color.argb(50, 140, 220, 140));
                for (int i = 0; i < 5; i++) bc.drawCircle(r.nextInt(w), h * 0.95f, 30 + r.nextInt(40), q);
                q.setColor(Color.argb(60, 255, 255, 220));
                for (int i = 0; i < 14; i++) { int x = r.nextInt(w), y = r.nextInt(h / 2); bc.drawRect(x, y, x + 1, y + 1, q); }
                for (int i = 0; i < 8; i++) { int x = r.nextInt(w); bc.drawRect(x, h - 40 - r.nextInt(20), x + 2, h, q); }
                break;
            case EcoData.BG_MINE:
                q.setColor(Color.argb(80, 110, 70, 40));
                for (int x = 20 + r.nextInt(20); x < w; x += 60 + r.nextInt(20)) {
                    bc.drawRect(x, 0, x + 5, h, q);
                    bc.drawRect(x - 20, 18, x + 25, 23, q);
                }
                q.setColor(Color.argb(90, 255, 200, 100));
                for (int i = 0; i < 4; i++) bc.drawCircle(r.nextInt(w), 26, 3, q);
                break;
            case EcoData.BG_ICE: {
                q.setColor(Color.argb(70, 220, 240, 255));
                Path p = new Path();
                for (int x = 0; x < w; x += 10 + r.nextInt(14)) {
                    int len = 10 + r.nextInt(30);
                    p.moveTo(x, 0); p.lineTo(x + 6, 0); p.lineTo(x + 3, len); p.close();
                }
                bc.drawPath(p, q);
                q.setColor(Color.argb(40, 200, 230, 255));
                for (int i = 0; i < 4; i++) { int x = r.nextInt(w); bc.drawRect(x, h / 3f, x + 10 + r.nextInt(10), h, q); }
                break;
            }
            case EcoData.BG_FUNGI:
                for (int i = 0; i < 6; i++) {
                    int x = r.nextInt(w), top = h / 4 + r.nextInt(h / 2);
                    q.setColor(Color.argb(60, 220, 190, 150));
                    bc.drawRect(x - 3, top, x + 3, h, q);
                    q.setColor(Color.argb(80, 255, 140 + r.nextInt(80), 60));
                    bc.drawOval(x - 18, top - 10, x + 18, top + 6, q);
                }
                break;
            case EcoData.BG_THORNS: {
                q.setStyle(Paint.Style.STROKE);
                q.setStrokeWidth(3);
                q.setColor(Color.argb(70, 60, 140, 60));
                for (int i = 0; i < 6; i++) {
                    Path p = new Path();
                    float x = r.nextInt(w);
                    p.moveTo(x, h);
                    p.quadTo(x + r.nextInt(80) - 40, h / 2f, x + r.nextInt(60) - 30, 0);
                    bc.drawPath(p, q);
                }
                q.setStyle(Paint.Style.FILL);
                q.setColor(Color.argb(90, 220, 40, 70));
                for (int i = 0; i < 10; i++) bc.drawCircle(r.nextInt(w), r.nextInt(h), 3, q);
                break;
            }
            case EcoData.BG_CITY:
                for (int x = -10; x < w; x += 22 + r.nextInt(18)) {
                    int bw = 18 + r.nextInt(14), bh = 40 + r.nextInt(70);
                    q.setColor(Color.argb(90, 20, 22, 50));
                    bc.drawRect(x, h - bh, x + bw, h, q);
                    q.setColor(Color.argb(110, 255, 220, 120));
                    for (int wy = h - bh + 6; wy < h - 8; wy += 9)
                        for (int wx = x + 3; wx < x + bw - 3; wx += 6) if (r.nextFloat() < 0.3f) bc.drawRect(wx, wy, wx + 2, wy + 3, q);
                }
                break;
            case EcoData.BG_CRYSTAL: {
                Path p = new Path();
                for (int i = 0; i < 9; i++) {
                    float x = r.nextInt(w), base = h - r.nextInt(20), hh = 30 + r.nextInt(60), ww = 6 + r.nextInt(8);
                    p.moveTo(x - ww, base); p.lineTo(x, base - hh); p.lineTo(x + ww, base); p.close();
                }
                q.setColor(Color.argb(70, 255, 150, 230));
                bc.drawPath(p, q);
                break;
            }
            case EcoData.BG_CLIFFS: {
                q.setColor(Color.argb(70, 160, 170, 190));
                Path p = new Path();
                p.moveTo(0, h);
                for (int x = 0; x <= w; x += 20) p.lineTo(x, h * 0.45f + r.nextInt(40));
                p.lineTo(w, h); p.close();
                bc.drawPath(p, q);
                q.setColor(Color.argb(60, 255, 255, 255));
                for (int i = 0; i < 5; i++) { float x = r.nextInt(w), y = r.nextInt(h / 3); bc.drawOval(x, y, x + 30 + r.nextInt(20), y + 6, q); }
                break;
            }
            case EcoData.BG_GRAVES:
                for (int i = 0; i < 8; i++) {
                    int x = r.nextInt(w), y = h - 8 - r.nextInt(30);
                    q.setColor(Color.argb(80, 140, 120, 110));
                    if (r.nextBoolean()) { bc.drawRect(x, y - 12, x + 3, y, q); bc.drawRect(x - 4, y - 9, x + 7, y - 7, q); }
                    else { bc.drawRect(x, y - 10, x + 9, y, q); bc.drawCircle(x + 4.5f, y - 10, 4.5f, q); }
                }
                q.setColor(Color.argb(90, 230, 170, 80));
                for (int i = 0; i < 3; i++) { int x = r.nextInt(w); bc.drawRect(x, 0, x + 1, 20, q); bc.drawCircle(x, 24, 5, q); }
                break;
            case EcoData.BG_HIVE:
                q.setStyle(Paint.Style.STROKE);
                q.setStrokeWidth(1.5f);
                q.setColor(Color.argb(70, 255, 220, 100));
                for (int y = 0; y < h + 16; y += 14)
                    for (int x = (y / 14) % 2 * 8; x < w + 16; x += 16) {
                        Path p = new Path();
                        for (int k = 0; k < 6; k++) {
                            double a = Math.PI / 3 * k;
                            float px = (float) (x + 8 * Math.cos(a)), py = (float) (y + 8 * Math.sin(a));
                            if (k == 0) p.moveTo(px, py); else p.lineTo(px, py);
                        }
                        p.close();
                        bc.drawPath(p, q);
                    }
                q.setStyle(Paint.Style.FILL);
                break;
            case EcoData.BG_SEWER:
                q.setColor(Color.argb(80, 60, 110, 100));
                for (int i = 0; i < 3; i++) { int y = 10 + r.nextInt(h - 40); bc.drawRect(0, y, w, y + 7, q); }
                q.setColor(Color.argb(60, 100, 230, 200));
                bc.drawRect(0, h - 14, w, h, q);
                q.setStyle(Paint.Style.STROKE);
                q.setStrokeWidth(4);
                q.setColor(Color.argb(60, 80, 140, 130));
                for (int x = 30; x < w; x += 80) bc.drawArc(new android.graphics.RectF(x - 30, h * 0.35f, x + 30, h * 1.2f), 180, 180, false, q);
                q.setStyle(Paint.Style.FILL);
                break;
            case EcoData.BG_WEB:
                q.setStyle(Paint.Style.STROKE);
                q.setStrokeWidth(1);
                q.setColor(Color.argb(60, 220, 220, 230));
                for (int i = 0; i < 3; i++) {
                    float cx = r.nextInt(w), cy = r.nextInt(h / 2);
                    for (int k = 0; k < 8; k++) {
                        double a = Math.PI / 4 * k;
                        bc.drawLine(cx, cy, (float) (cx + 50 * Math.cos(a)), (float) (cy + 50 * Math.sin(a)), q);
                    }
                    for (int rr = 12; rr < 50; rr += 12) bc.drawCircle(cx, cy, rr, q);
                }
                q.setStyle(Paint.Style.FILL);
                break;
            case EcoData.BG_VOID:
                q.setColor(Color.argb(40, 200, 200, 230));
                for (int i = 0; i < 4; i++) { int x = r.nextInt(w); bc.drawRect(x, 0, x + 6 + r.nextInt(6), h, q); }
                q.setColor(Color.argb(120, 255, 255, 255));
                for (int i = 0; i < 25; i++) { int x = r.nextInt(w), y = r.nextInt(h); bc.drawRect(x, y, x + 1, y + 1, q); }
                break;
            case EcoData.BG_CASTLE:
                // ventanales góticos con vidrieras rojas, columnas y estandartes
                for (int x = 20; x < w; x += 70) {
                    q.setColor(Color.argb(110, 30, 0, 6));
                    bc.drawRect(x - 4, 0, x + 4, h, q);
                    int wx = x + 30;
                    Path p = new Path();
                    p.moveTo(wx - 12, h * 0.75f); p.lineTo(wx - 12, h * 0.3f); p.lineTo(wx, h * 0.15f); p.lineTo(wx + 12, h * 0.3f); p.lineTo(wx + 12, h * 0.75f); p.close();
                    q.setColor(Color.argb(120, 200, 20, 40));
                    bc.drawPath(p, q);
                    q.setColor(Color.argb(140, 255, 210, 120));
                    bc.drawRect(wx - 1, h * 0.2f, wx + 1, h * 0.75f, q);
                    bc.drawRect(wx - 12, h * 0.45f, wx + 12, h * 0.47f, q);
                    q.setColor(Color.argb(120, 120, 10, 30));
                    bc.drawRect(x + 52, 8, x + 62, 40, q);
                }
                break;
        }
        if (dungeon) {     // las mazmorras son más oscuras
            q.setColor(Color.argb(90, 0, 0, 0));
            bc.drawRect(0, 0, w, h, q);
        }
        q.setColor(mid);
        bc.drawRect(0, h - 3, w, h, q);
        q.setColor(far);
    }
}
