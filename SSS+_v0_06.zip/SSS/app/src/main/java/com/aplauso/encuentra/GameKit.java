package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.BitmapFactory;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Piezas comunes de los juegos arcade: bucle, botones multitáctiles, sprites de píxeles y texto. */
public class GameKit {

    // ======================================================================
    // Sprites de píxeles: cada carácter es un color de la paleta, '.' = transparente
    // ======================================================================
    static Bitmap sprite(String[] rows, String keys, int[] colors) {
        int h = rows.length, w = 0;
        for (String r : rows) w = Math.max(w, r.length());
        Bitmap b = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        for (int y = 0; y < h; y++) {
            String r = rows[y];
            for (int x = 0; x < w; x++) {
                char ch = x < r.length() ? r.charAt(x) : '.';
                int idx = keys.indexOf(ch);
                b.setPixel(x, y, idx < 0 ? Color.TRANSPARENT : colors[idx]);
            }
        }
        return b;
    }

    static Bitmap flipH(Bitmap b) {
        Matrix m = new Matrix();
        m.preScale(-1, 1);
        return Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, false);
    }

    static final Paint PIX = new Paint();
    static { PIX.setFilterBitmap(false); PIX.setAntiAlias(false); }
    private static final RectF TMP = new RectF();

    /** Dibuja un sprite de píxeles nítido en el rectángulo (x, y, w, h). */
    static void draw(Canvas c, Bitmap b, float x, float y, float w, float h) {
        TMP.set(x, y, x + w, y + h);
        c.drawBitmap(b, null, TMP, PIX);
    }

    static void draw(Canvas c, Bitmap b, float x, float y, float w, float h, Paint p) {
        TMP.set(x, y, x + w, y + h);
        c.drawBitmap(b, null, TMP, p);
    }

    // ======================================================================
    // Botones en pantalla (varios dedos a la vez)
    // ======================================================================
    static class Btn {
        final RectF r = new RectF();
        String label;
        float textSize;
        boolean visible = true, round;
        boolean ghost;        // activo pero sin dibujar (zonas táctiles invisibles)
        boolean down;
        int presses;          // pulsaciones desde el último fotograma
        boolean touchDown;    // pulsado con el dedo
        int ext;              // pulsado por otra fuente (joystick, mando): bits

        boolean pressed() { return presses > 0; }

        void refresh() {
            boolean d = touchDown || ext != 0;
            if (d && !down) presses++;
            down = d;
        }

        /** Pulsa o suelta el botón desde una fuente externa (bit = fuente). */
        void setExt(int bit, boolean on) {
            ext = on ? (ext | bit) : (ext & ~bit);
            refresh();
        }
    }

    static final int SRC_STICK = 1, SRC_PAD = 2;

    static class Pad {
        final List<Btn> btns = new ArrayList<>();
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);

        Pad() {
            t.setTextAlign(Paint.Align.CENTER);
            t.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        }

        Btn add(String label, float l, float top, float r, float b, float textSize) {
            Btn x = new Btn();
            x.label = label;
            x.r.set(l, top, r, b);
            x.textSize = textSize;
            btns.add(x);
            return x;
        }

        /** Recalcula qué botones están pulsados según todos los dedos. Coordenadas ya divididas por la escala. */
        void touch(MotionEvent e, float scale) { touch(e, scale, -1); }

        /** Igual, pero sin contar el dedo que maneja el joystick (ignoreId). */
        void touch(MotionEvent e, float scale, int ignoreId) {
            int action = e.getActionMasked();
            int upIndex = (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP
                    || action == MotionEvent.ACTION_CANCEL) ? e.getActionIndex() : -1;
            boolean cancel = action == MotionEvent.ACTION_CANCEL;
            for (Btn b : btns) {
                boolean now = false;
                if (b.visible && !cancel) {
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        if (i == upIndex) continue;
                        if (ignoreId >= 0 && e.getPointerId(i) == ignoreId) continue;
                        float x = e.getX(i) / scale, y = e.getY(i) / scale;
                        if (b.r.contains(x, y)) { now = true; break; }
                    }
                }
                b.touchDown = now;
                b.refresh();
            }
        }

        boolean anyAt(float x, float y) {
            for (Btn b : btns) if (b.visible && b.r.contains(x, y)) return true;
            return false;
        }

        void endFrame() { for (Btn b : btns) b.presses = 0; }

        void releaseAll() { for (Btn b : btns) { b.down = false; b.touchDown = false; b.ext = 0; b.presses = 0; } }

        float alpha = 1f;     // opacidad de los botones (ajustes)

        void draw(Canvas c, int color) {
            int save = alpha < 0.99f ? c.saveLayerAlpha(0, 0, 4000, 4000, Math.round(255 * alpha)) : -1;
            drawBtns(c, color);
            if (save >= 0) c.restoreToCount(save);
        }

        private void drawBtns(Canvas c, int color) {
            for (Btn b : btns) {
                if (!b.visible || b.ghost) continue;
                float rad = b.round ? Math.min(b.r.width(), b.r.height()) / 2 : 10;
                p.setStyle(Paint.Style.FILL);
                p.setColor(b.down ? Neon.withAlpha(color, 110) : Color.argb(70, 0, 0, 0));
                c.drawRoundRect(b.r, rad, rad, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2);
                p.setColor(Neon.withAlpha(color, b.down ? 255 : 150));
                c.drawRoundRect(b.r, rad, rad, p);
                p.setStyle(Paint.Style.FILL);
                t.setTextSize(b.textSize);
                t.setColor(Color.argb(b.down ? 255 : 210, 255, 255, 255));
                Paint.FontMetrics fm = t.getFontMetrics();
                c.drawText(L.t(b.label), b.r.centerX(), b.r.centerY() - (fm.ascent + fm.descent) / 2, t);
            }
        }
    }

    // ======================================================================
    // Joystick virtual (analógico): placa con flechas y bola, semitransparente
    // ======================================================================
    private static Bitmap joyBase, joyKnob;

    static void loadJoy(Context c) {
        if (joyBase != null) return;
        try {
            joyBase = BitmapFactory.decodeStream(c.getAssets().open("joy_base.png"));
            joyKnob = BitmapFactory.decodeStream(c.getAssets().open("joy_knob.png"));
        } catch (Exception ignored) {}
    }

    static class Stick {
        float homeX, homeY, r = 40;     // posición de reposo y recorrido de la bola
        float cx, cy;                   // centro actual (se mueve al dedo: joystick flotante)
        final RectF zone = new RectF(); // dónde se puede agarrar
        float ax, ay;                   // -1..1 (ay < 0 = arriba)
        int pid = -1;
        boolean visible = true, floating = true;
        float alpha = 0.55f;
        final Paint p = new Paint();

        Stick() { p.setFilterBitmap(false); }

        void place(float x, float y, float radius) { homeX = cx = x; homeY = cy = y; r = radius; }

        boolean active() { return pid >= 0; }

        void reset() { pid = -1; ax = ay = 0; cx = homeX; cy = homeY; }

        /** Procesa el toque (coordenadas divididas por scale). Devuelve true si este dedo es del joystick. */
        void touch(MotionEvent e, float scale, Pad pad) {
            if (!visible) { if (pid >= 0) reset(); return; }
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_CANCEL) { reset(); return; }
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
                int i = e.getActionIndex();
                float x = e.getX(i) / scale, y = e.getY(i) / scale;
                if (pid < 0 && zone.contains(x, y) && (pad == null || !pad.anyAt(x, y))) {
                    pid = e.getPointerId(i);
                    if (floating) {
                        cx = clamp(x, zone.left + r * 0.6f, zone.right - r * 0.6f);
                        cy = clamp(y, zone.top + r * 0.6f, zone.bottom - r * 0.6f);
                    }
                    follow(x, y);
                }
                return;
            }
            if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP) && pid >= 0
                    && e.getPointerId(e.getActionIndex()) == pid) { reset(); return; }
            if (a == MotionEvent.ACTION_MOVE && pid >= 0) {
                int i = e.findPointerIndex(pid);
                if (i < 0) { reset(); return; }
                follow(e.getX(i) / scale, e.getY(i) / scale);
            }
        }

        void follow(float x, float y) {
            float dx = (x - cx) / r, dy = (y - cy) / r;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len > 1) { dx /= len; dy /= len; }
            ax = dx; ay = dy;
        }

        /** Eje X con zona muerta, reescalado a 0..1. */
        float x(float dead) {
            float v = Math.abs(ax);
            if (v < dead) return 0;
            return Math.signum(ax) * Math.min(1, (v - dead) / (1 - dead) * 1.25f);
        }

        void draw(Canvas c, int neon) {
            if (!visible) return;
            float al = active() ? Math.min(1, alpha + 0.2f) : alpha;
            p.setAlpha(Math.round(255 * al));
            float pw = r * 2.6f;
            if (joyBase != null) {
                float ph = pw * joyBase.getHeight() / joyBase.getWidth();
                GameKit.draw(c, joyBase, cx - pw / 2, cy - ph / 2, pw, ph, p);
            } else {
                p.setColor(Color.argb(Math.round(140 * al), 20, 20, 24));
                c.drawCircle(cx, cy, r * 1.25f, p);
            }
            float kd = pw * 0.535f, kx = cx + ax * r, ky = cy + ay * r;
            if (joyKnob != null) GameKit.draw(c, joyKnob, kx - kd / 2, ky - kd / 2, kd, kd, p);
            else {
                p.setColor(Color.argb(Math.round(220 * al), 60, 60, 66));
                c.drawCircle(kx, ky, kd / 2, p);
            }
            p.setAlpha(255);
        }
    }

    // ======================================================================
    // Mando externo (Xbox, gamepad Bluetooth/USB, teclado): opcional en ajustes
    // ======================================================================
    static final int G_LEFT = 0, G_RIGHT = 1, G_UP = 2, G_DOWN = 3, G_A = 4, G_B = 5, G_X = 6, G_Y = 7,
            G_START = 8, G_SELECT = 9, G_L1 = 10, G_R1 = 11, G_N = 12;

    static class Gamepad {
        boolean enabled;
        final boolean[] key = new boolean[G_N];   // botones físicos
        final boolean[] on = new boolean[G_N];    // estado combinado (botón o palanca)
        final int[] presses = new int[G_N];
        final Btn[] bind = new Btn[G_N];
        float lx, ly, hx, hy;                     // palanca izquierda y cruceta analógica

        static int map(int code) {
            switch (code) {
                case KeyEvent.KEYCODE_DPAD_LEFT: case KeyEvent.KEYCODE_A: return G_LEFT;
                case KeyEvent.KEYCODE_DPAD_RIGHT: case KeyEvent.KEYCODE_D: return G_RIGHT;
                case KeyEvent.KEYCODE_DPAD_UP: case KeyEvent.KEYCODE_W: return G_UP;
                case KeyEvent.KEYCODE_DPAD_DOWN: case KeyEvent.KEYCODE_S: return G_DOWN;
                case KeyEvent.KEYCODE_BUTTON_A: case KeyEvent.KEYCODE_DPAD_CENTER: case KeyEvent.KEYCODE_SPACE:
                case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_BUTTON_1: return G_A;
                case KeyEvent.KEYCODE_BUTTON_B: case KeyEvent.KEYCODE_J: case KeyEvent.KEYCODE_BUTTON_2: return G_B;
                case KeyEvent.KEYCODE_BUTTON_X: case KeyEvent.KEYCODE_K: case KeyEvent.KEYCODE_BUTTON_3: return G_X;
                case KeyEvent.KEYCODE_BUTTON_Y: case KeyEvent.KEYCODE_L: case KeyEvent.KEYCODE_BUTTON_4: return G_Y;
                case KeyEvent.KEYCODE_BUTTON_START: case KeyEvent.KEYCODE_MENU: case KeyEvent.KEYCODE_ESCAPE:
                case KeyEvent.KEYCODE_P: return G_START;
                case KeyEvent.KEYCODE_BUTTON_SELECT: case KeyEvent.KEYCODE_M: case KeyEvent.KEYCODE_TAB: return G_SELECT;
                case KeyEvent.KEYCODE_BUTTON_L1: case KeyEvent.KEYCODE_BUTTON_L2: case KeyEvent.KEYCODE_Q: return G_L1;
                case KeyEvent.KEYCODE_BUTTON_R1: case KeyEvent.KEYCODE_BUTTON_R2: case KeyEvent.KEYCODE_E: return G_R1;
            }
            return -1;
        }

        static boolean fromPad(int source) {
            return (source & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                    || (source & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                    || (source & InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD
                    || (source & InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD;
        }

        /** Tecla o botón. Devuelve true si se usó. */
        boolean onKey(KeyEvent e) {
            if (!enabled) return false;
            int g = map(e.getKeyCode());
            if (g < 0) return false;
            if (e.getAction() == KeyEvent.ACTION_DOWN) { if (e.getRepeatCount() == 0) key[g] = true; }
            else if (e.getAction() == KeyEvent.ACTION_UP) key[g] = false;
            sync();
            return true;
        }

        /** Palancas y cruceta analógica. */
        boolean onMotion(MotionEvent e) {
            if (!enabled) return false;
            if ((e.getSource() & InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK
                    && (e.getSource() & InputDevice.SOURCE_GAMEPAD) != InputDevice.SOURCE_GAMEPAD) return false;
            if (e.getActionMasked() != MotionEvent.ACTION_MOVE) return false;
            lx = dz(e.getAxisValue(MotionEvent.AXIS_X));
            ly = dz(e.getAxisValue(MotionEvent.AXIS_Y));
            hx = e.getAxisValue(MotionEvent.AXIS_HAT_X);
            hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y);
            sync();
            return true;
        }

        static float dz(float v) { return Math.abs(v) < 0.18f ? 0 : v; }

        /** Combina botones y palancas, cuenta pulsaciones y aprieta los botones en pantalla enlazados. */
        void sync() {
            for (int g = 0; g < G_N; g++) {
                boolean v = key[g];
                if (g == G_LEFT) v |= lx < -0.5f || hx < -0.5f;
                if (g == G_RIGHT) v |= lx > 0.5f || hx > 0.5f;
                if (g == G_UP) v |= ly < -0.5f || hy < -0.5f;
                if (g == G_DOWN) v |= ly > 0.5f || hy > 0.5f;
                if (v && !on[g]) presses[g]++;
                on[g] = v;
            }
            for (int g = 0; g < G_N; g++) if (bind[g] != null) bind[g].setExt(SRC_PAD << g, on[g]);
        }

        /** Eje horizontal: palanca analógica, o -1/0/1 con la cruceta. */
        float axisX() {
            if (lx != 0) return lx;
            if (hx != 0) return hx;
            return (on[G_RIGHT] ? 1 : 0) - (on[G_LEFT] ? 1 : 0);
        }

        float axisY() {
            if (ly != 0) return ly;
            if (hy != 0) return hy;
            return (on[G_DOWN] ? 1 : 0) - (on[G_UP] ? 1 : 0);
        }

        boolean pressed(int g) { return presses[g] > 0; }
        boolean down(int g) { return on[g]; }
        void endFrame() { java.util.Arrays.fill(presses, 0); }

        void releaseAll() {
            java.util.Arrays.fill(key, false);
            lx = ly = hx = hy = 0;
            sync();
            java.util.Arrays.fill(presses, 0);
        }
    }

    /** Ajustes de controles de un juego (se guardan con el prefijo del juego). */
    static class Ctrl {
        final SharedPreferences p;
        final String id;
        Ctrl(SharedPreferences p, String id) { this.p = p; this.id = id; }
        int mode(int def) { return p.getInt(id + "_ctrl", def); }
        void setMode(int m) { p.edit().putInt(id + "_ctrl", m).apply(); }
        int opacity() { return p.getInt(id + "_opacity", 55); }
        void setOpacity(int v) { p.edit().putInt(id + "_opacity", Math.max(15, Math.min(100, v))).apply(); }
        boolean gamepad() { return p.getBoolean(id + "_gamepad", false); }
        void setGamepad(boolean b) { p.edit().putBoolean(id + "_gamepad", b).apply(); }
    }

    // ======================================================================
    // Vista base con bucle de juego (≈60 fps) y coordenadas virtuales
    // ======================================================================
    abstract static class GameView extends View {
        final Pad pad = new Pad();
        final Gamepad gp = new Gamepad();
        Stick stick;                     // solo si el juego usa joystick
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        float scale = 1, vw = 360, vh = 640;   // unidades virtuales
        boolean running;
        private long last;
        boolean tapped;
        float tapX, tapY;
        final Chip chip;

        GameView(Context c) {
            super(c);
            txt.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            txt.setTextAlign(Paint.Align.CENTER);
            chip = new Chip(c);
            L.init(c);
            loadJoy(c);
            setKeepScreenOn(true);
            setFocusable(true);
            setFocusableInTouchMode(true);
        }

        /** Teclas del mando (las reenvía la actividad). */
        boolean handleKey(KeyEvent e) { return gp.onKey(e); }
        boolean handleMotion(MotionEvent e) { return gp.onMotion(e); }

        SharedPreferences prefs() { return getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE); }

        /** Define el tamaño virtual: ancho fijo (vertical) o alto fijo (horizontal). */
        abstract void computeScale(int w, int h);
        abstract void layout();
        abstract void update(float dt);
        abstract void render(Canvas c);
        void onPauseGame() {}
        void onResumeGame() {}

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            if (w <= 0 || h <= 0) return;
            computeScale(w, h);
            pad.btns.clear();
            layout();
        }

        void resume() {
            running = true;
            last = System.nanoTime();
            chip.start();
            onResumeGame();
            postInvalidateOnAnimation();
        }

        void pause() {
            running = false;
            pad.releaseAll();
            gp.releaseAll();
            if (stick != null) stick.reset();
            onPauseGame();
            chip.stop();
        }

        @Override
        protected void onDraw(Canvas c) {
            long now = System.nanoTime();
            float dt = Math.min(0.05f, (now - last) / 1e9f);
            last = now;
            if (running && getWidth() > 0) update(dt);
            c.save();
            c.scale(scale, scale);
            render(c);          // los menús comprueban los toques aquí
            c.restore();
            tapped = false;
            pad.endFrame();
            gp.endFrame();
            if (running) postInvalidateOnAnimation();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (stick != null) stick.touch(e, scale, pad);
            pad.touch(e, scale, stick != null ? stick.pid : -1);
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
                int i = e.getActionIndex();
                tapX = e.getX(i) / scale;
                tapY = e.getY(i) / scale;
                tapped = true;
            }
            return true;
        }

        /** ¿Se tocó dentro de este rectángulo en este fotograma? */
        boolean tapIn(RectF r) { return tapped && r.contains(tapX, tapY); }

        // ---------- dibujo de texto y paneles ----------
        void text(Canvas c, String s, float x, float y, float size, int color) {
            txt.setTextSize(size);
            txt.setColor(color);
            c.drawText(L.t(s), x, y, txt);
        }

        void textLeft(Canvas c, String s, float x, float y, float size, int color) {
            txt.setTextAlign(Paint.Align.LEFT);
            text(c, s, x, y, size, color);
            txt.setTextAlign(Paint.Align.CENTER);
        }

        /** Texto con salto de línea automático (traducido); devuelve la y final. */
        float wrap(Canvas c, String s, float x, float y, float maxW, float size, int color, boolean center) {
            return wrapRaw(c, L.t(s), x, y, maxW, size, color, center);
        }

        /** Igual que wrap, pero sin traducir (el texto ya viene traducido). */
        float wrapRaw(Canvas c, String s, float x, float y, float maxW, float size, int color, boolean center) {
            txt.setTextSize(size);
            txt.setColor(color);
            if (!center) txt.setTextAlign(Paint.Align.LEFT);
            for (String para : s.split("\n")) {
                String[] words = para.split(" ");
                StringBuilder line = new StringBuilder();
                for (String w : words) {
                    String test = line.length() == 0 ? w : line + " " + w;
                    if (txt.measureText(test) > maxW && line.length() > 0) {
                        c.drawText(line.toString(), x, y, txt);
                        y += size * 1.3f;
                        line = new StringBuilder(w);
                    } else line = new StringBuilder(test);
                }
                c.drawText(line.toString(), x, y, txt);
                y += size * 1.3f;
            }
            txt.setTextAlign(Paint.Align.CENTER);
            return y;
        }

        void box(Canvas c, RectF r, int color, int fillAlpha) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(fillAlpha, 8, 10, 22));
            c.drawRoundRect(r, 12, 12, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.5f);
            p.setColor(color);
            c.drawRoundRect(r, 12, 12, p);
            p.setStyle(Paint.Style.FILL);
        }

        /** Botón de menú dibujado; devuelve true si se tocó en este fotograma. */
        boolean menuButton(Canvas c, RectF r, String label, int color) {
            box(c, r, color, 200);
            text(c, label, r.centerX(), r.centerY() + 6, 17, Color.WHITE);
            return tapIn(r);
        }
    }

    static float clamp(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }

    static boolean overlap(float ax, float ay, float aw, float ah, float bx, float by, float bw, float bh) {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
    }
}
