package com.aplauso.encuentra;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Editor de fotos con interfaz "clásica" (como la de casi todas las galerías):
 * foto grande sobre negro, recorte libre con esquinas, girar, filtros con miniaturas,
 * tamaño/calidad y "Guardar copia".
 */
public class PhotoClassicActivity extends Activity {
    Uri uri;
    Bitmap work;            // foto con el giro aplicado
    ClassicView view;
    int outW, outH, quality = 92;
    boolean png;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        uri = getIntent().getData();
        work = uri == null ? null : PhotoTools.load(this, uri, 2560);
        if (work == null) {
            Toast.makeText(this, L.t("No se pudo abrir la imagen"), Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        view = new ClassicView(this);
        setContentView(view);
    }

    void toNeon() {
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("photo_ui", "neon").apply();
        startActivity(new Intent(this, PhotoEditorActivity.class).setData(uri).putExtra("neon", true));
        finish();
    }

    void rotate() {
        work = PhotoTools.rotate(work, 90);
        view.resetCrop();
        outW = outH = 0;
    }

    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    // ---------------- diálogo de tamaño y calidad ----------------
    void sizeDialog() {
        RectF cr = view.crop;
        final int baseW = Math.max(1, Math.round(cr.width())), baseH = Math.max(1, Math.round(cr.height()));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(10), dp(20), dp(4));
        TextView info = new TextView(this);
        info.setText(L.t("Tamaño del recorte: " + baseW + " × " + baseH + " px"));
        col.addView(info);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final EditText w = new EditText(this), h = new EditText(this);
        w.setInputType(InputType.TYPE_CLASS_NUMBER);
        h.setInputType(InputType.TYPE_CLASS_NUMBER);
        w.setText(String.valueOf(outW > 0 ? outW : baseW));
        h.setText(String.valueOf(outH > 0 ? outH : baseH));
        row.addView(w, new LinearLayout.LayoutParams(0, -2, 1));
        TextView x = new TextView(this);
        x.setText("  ×  ");
        row.addView(x);
        row.addView(h, new LinearLayout.LayoutParams(0, -2, 1));
        col.addView(row);
        final CheckBox lock = new CheckBox(this);
        lock.setText(L.t("Mantener proporción"));
        lock.setChecked(true);
        col.addView(lock);
        final boolean[] busy = {false};
        w.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b0, int c) {}
            public void onTextChanged(CharSequence s, int a, int b0, int c) {}
            public void afterTextChanged(Editable s) {
                if (busy[0] || !lock.isChecked()) return;
                busy[0] = true;
                h.setText(String.valueOf(Math.max(1, Math.round(num(w, baseW) * baseH / (float) baseW))));
                busy[0] = false;
            }
        });
        h.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b0, int c) {}
            public void onTextChanged(CharSequence s, int a, int b0, int c) {}
            public void afterTextChanged(Editable s) {
                if (busy[0] || !lock.isChecked()) return;
                busy[0] = true;
                w.setText(String.valueOf(Math.max(1, Math.round(num(h, baseH) * baseW / (float) baseH))));
                busy[0] = false;
            }
        });
        final TextView qLabel = new TextView(this);
        qLabel.setText(L.t("Calidad: " + quality + " %"));
        qLabel.setPadding(0, dp(10), 0, 0);
        col.addView(qLabel);
        SeekBar q = new SeekBar(this);
        q.setMax(90);
        q.setProgress(quality - 10);
        q.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int pr, boolean u) { quality = pr + 10; qLabel.setText(L.t("Calidad: " + quality + " %")); }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        col.addView(q);
        final CheckBox pngBox = new CheckBox(this);
        pngBox.setText(L.t("Guardar como PNG (sin pérdida)"));
        pngBox.setChecked(png);
        col.addView(pngBox);
        final TextView weight = new TextView(this);
        weight.setPadding(0, dp(8), 0, 0);
        col.addView(weight);
        new AlertDialog.Builder(this)
                .setTitle(L.t("Tamaño y calidad"))
                .setView(col)
                .setPositiveButton(L.t("Aplicar"), (d, which) -> {
                    outW = num(w, baseW);
                    outH = num(h, baseH);
                    if (outW == baseW && outH == baseH) outW = outH = 0;
                    png = pngBox.isChecked();
                    estimateToast();
                })
                .setNeutralButton(L.t("Original"), (d, which) -> { outW = outH = 0; })
                .setNegativeButton(L.t("Cancelar"), null)
                .show();
    }

    static int num(EditText e, int def) {
        try { return Math.max(1, Math.min(12000, Integer.parseInt(e.getText().toString().trim()))); } catch (Exception x) { return def; }
    }

    Bitmap finalBitmap() {
        RectF cr = view.crop;
        int x = Math.max(0, Math.round(cr.left)), y = Math.max(0, Math.round(cr.top));
        int w = Math.min(work.getWidth() - x, Math.max(1, Math.round(cr.width())));
        int h = Math.min(work.getHeight() - y, Math.max(1, Math.round(cr.height())));
        Bitmap c = Bitmap.createBitmap(work, x, y, w, h, null, false);
        return PhotoTools.render(c, PhotoTools.filter(view.filter), outW, outH);
    }

    void estimateToast() {
        new Thread(() -> {
            try {
                Bitmap b = finalBitmap();
                long bytes = PhotoTools.estimate(b, quality, png);
                String m = b.getWidth() + " × " + b.getHeight() + " px · ≈ " + SysInfo.bytes(bytes);
                runOnUiThread(() -> Toast.makeText(this, L.t(m), Toast.LENGTH_LONG).show());
            } catch (Throwable ignored) {}
        }).start();
    }

    void saveCopy() {
        Toast.makeText(this, L.t("Guardando…"), Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            Uri saved = null;
            try { saved = PhotoTools.save(this, finalBitmap(), quality, png); } catch (Throwable ignored) {}
            final boolean ok = saved != null;
            runOnUiThread(() -> {
                Toast.makeText(this, L.t(ok ? "Copia guardada en Imágenes/SSS ✓" : "No se pudo guardar"), Toast.LENGTH_LONG).show();
                if (ok) finish();
            });
        }).start();
    }

    // =====================================================================
    // Vista de la interfaz clásica
    // =====================================================================
    class ClassicView extends View {
        final int TAB_FILTERS = 0, TAB_CROP = 1;
        final String[] ASPECTS = {"Libre", "Original", "1:1", "4:3", "3:4", "16:9", "9:16"};
        final float[] RATIOS = {0, -1, 1f, 4f / 3, 3f / 4, 16f / 9, 9f / 16};
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), img = new Paint(Paint.FILTER_BITMAP_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);
        RectF crop = new RectF();          // en píxeles de "work"
        int filter, tab, aspect;
        Bitmap thumb;
        float stripScroll;
        // gestos
        int drag = -1;                     // 0..3 esquinas, 4 mover, 5 desplazar filtros
        float lastX, lastY, downX, downY;
        boolean moved;
        final RectF imgRect = new RectF();
        final RectF bRotate = new RectF(), bCrop = new RectF(), bSize = new RectF(), bCancel = new RectF(), bSave = new RectF(), bNeon = new RectF();

        ClassicView(Context c) {
            super(c);
            setBackgroundColor(Color.BLACK);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            resetCrop();
        }

        void resetCrop() {
            crop.set(0, 0, work.getWidth(), work.getHeight());
            float s = 120f / Math.max(work.getWidth(), work.getHeight());
            thumb = Bitmap.createScaledBitmap(work, Math.max(1, Math.round(work.getWidth() * s)), Math.max(1, Math.round(work.getHeight() * s)), true);
            invalidate();
        }

        float sc() {   // píxeles de pantalla por píxel de la foto
            return imgRect.width() / work.getWidth();
        }

        void layoutRects() {
            float W = getWidth(), H = getHeight();
            float bottom = dp(250);
            float areaTop = dp(56), areaBot = H - bottom;
            float s = Math.min((W - dp(24)) / work.getWidth(), (areaBot - areaTop) / work.getHeight());
            float iw = work.getWidth() * s, ih = work.getHeight() * s;
            imgRect.set((W - iw) / 2, areaTop + (areaBot - areaTop - ih) / 2, (W + iw) / 2, areaTop + (areaBot - areaTop + ih) / 2);
            float by = H - bottom + dp(14);
            float gap = dp(10), bw = (W - dp(24) - gap * 2) / 3;
            bRotate.set(dp(12), by, dp(12) + bw, by + dp(52));
            bCrop.set(bRotate.right + gap, by, bRotate.right + gap + bw, by + dp(52));
            bSize.set(bCrop.right + gap, by, W - dp(12), by + dp(52));
            bCancel.set(dp(12), H - dp(64), W / 2 - dp(8), H - dp(12));
            bSave.set(W / 2 + dp(8), H - dp(64), W - dp(12), H - dp(12));
            bNeon.set(W - dp(130), dp(10), W - dp(12), dp(46));
        }

        RectF screenCrop() {
            float s = sc();
            return new RectF(imgRect.left + crop.left * s, imgRect.top + crop.top * s,
                    imgRect.left + crop.right * s, imgRect.top + crop.bottom * s);
        }

        float stripY() { return getHeight() - dp(250) + dp(80); }

        @Override
        protected void onDraw(Canvas c) {
            layoutRects();
            float W = getWidth();
            // barra superior
            t.setTextSize(dp(17));
            t.setColor(Color.WHITE);
            t.setTextAlign(Paint.Align.LEFT);
            c.drawText(L.t("Editar"), dp(16), dp(36), t);
            pill(c, bNeon, "Interfaz neón", false, dp(13));
            // foto
            img.setColorFilter(new ColorMatrixColorFilter(PhotoTools.filter(filter)));
            c.drawBitmap(work, null, imgRect, img);
            if (tab == TAB_CROP) {
                RectF sr = screenCrop();
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.argb(150, 0, 0, 0));
                c.drawRect(imgRect.left, imgRect.top, imgRect.right, sr.top, p);
                c.drawRect(imgRect.left, sr.bottom, imgRect.right, imgRect.bottom, p);
                c.drawRect(imgRect.left, sr.top, sr.left, sr.bottom, p);
                c.drawRect(sr.right, sr.top, imgRect.right, sr.bottom, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1));
                p.setColor(Color.argb(200, 255, 255, 255));
                for (int i = 1; i < 3; i++) {
                    float x = sr.left + sr.width() * i / 3, y = sr.top + sr.height() * i / 3;
                    c.drawLine(x, sr.top, x, sr.bottom, p);
                    c.drawLine(sr.left, y, sr.right, y, p);
                }
                p.setStrokeWidth(dp(2));
                p.setColor(Color.WHITE);
                c.drawRect(sr, p);
                p.setStyle(Paint.Style.FILL);
                float[][] corners = {{sr.left, sr.top}, {sr.right, sr.top}, {sr.left, sr.bottom}, {sr.right, sr.bottom}};
                for (float[] k : corners) c.drawCircle(k[0], k[1], dp(9), p);
            }
            // botones grandes
            pill(c, bRotate, "⟳  Girar", false, dp(16));
            pill(c, bCrop, "⛶  Recortar", tab == TAB_CROP, dp(16));
            pill(c, bSize, "⇲  Tamaño", outW > 0, dp(16));
            // tira inferior: filtros o proporciones
            float sy = stripY();
            if (tab == TAB_CROP) {
                float x = dp(12) - stripScroll;
                for (int i = 0; i < ASPECTS.length; i++) {
                    float w = dp(84);
                    RectF r = new RectF(x, sy + dp(14), x + w, sy + dp(58));
                    pill(c, r, ASPECTS[i], i == aspect, dp(14));
                    x += w + dp(8);
                }
            } else {
                float x = dp(12) - stripScroll, size = dp(78);
                t.setTextAlign(Paint.Align.CENTER);
                for (int i = 0; i < PhotoTools.FILTERS.length; i++) {
                    RectF r = new RectF(x, sy, x + size, sy + size);
                    if (r.right > 0 && r.left < W) {
                        Paint fp = new Paint(Paint.FILTER_BITMAP_FLAG);
                        fp.setColorFilter(new ColorMatrixColorFilter(PhotoTools.filter(i)));
                        float s = Math.max(size / thumb.getWidth(), size / thumb.getHeight());
                        float tw = thumb.getWidth() * s, th = thumb.getHeight() * s;
                        c.save();
                        c.clipRect(r);
                        c.drawBitmap(thumb, null, new RectF(r.centerX() - tw / 2, r.centerY() - th / 2, r.centerX() + tw / 2, r.centerY() + th / 2), fp);
                        c.restore();
                        if (i == filter) {
                            p.setStyle(Paint.Style.STROKE);
                            p.setStrokeWidth(dp(3));
                            p.setColor(Color.WHITE);
                            c.drawRoundRect(r, dp(8), dp(8), p);
                            p.setStyle(Paint.Style.FILL);
                        }
                        t.setTextSize(dp(13));
                        t.setColor(i == filter ? Color.WHITE : Color.LTGRAY);
                        c.drawText(L.t(PhotoTools.FILTERS[i]), r.centerX(), r.bottom + dp(18), t);
                    }
                    x += size + dp(10);
                }
                t.setTextAlign(Paint.Align.LEFT);
            }
            // cancelar / guardar
            t.setTextAlign(Paint.Align.CENTER);
            t.setTextSize(dp(17));
            t.setColor(Color.WHITE);
            c.drawText(L.t("Cancelar"), bCancel.centerX(), bCancel.centerY() + dp(6), t);
            pill(c, bSave, "Guardar copia", true, dp(17));
            t.setTextAlign(Paint.Align.LEFT);
        }

        void pill(Canvas c, RectF r, String label, boolean on, float size) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(on ? Color.rgb(60, 60, 66) : Color.rgb(32, 32, 36));
            c.drawRoundRect(r, r.height() / 2.6f, r.height() / 2.6f, p);
            if (on) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1.5f));
                p.setColor(Color.argb(160, 255, 255, 255));
                c.drawRoundRect(r, r.height() / 2.6f, r.height() / 2.6f, p);
                p.setStyle(Paint.Style.FILL);
            }
            t.setTextAlign(Paint.Align.CENTER);
            t.setTextSize(size);
            t.setColor(Color.WHITE);
            c.drawText(L.t(label), r.centerX(), r.centerY() + size * 0.36f, t);
            t.setTextAlign(Paint.Align.LEFT);
        }

        float stripMax() {
            float item = tab == TAB_CROP ? dp(92) : dp(88);
            int n = tab == TAB_CROP ? ASPECTS.length : PhotoTools.FILTERS.length;
            return Math.max(0, dp(12) + n * item - getWidth());
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX(), y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    downX = lastX = x; downY = lastY = y;
                    moved = false;
                    drag = -1;
                    if (tab == TAB_CROP) {
                        RectF sr = screenCrop();
                        float[][] corners = {{sr.left, sr.top}, {sr.right, sr.top}, {sr.left, sr.bottom}, {sr.right, sr.bottom}};
                        for (int i = 0; i < 4; i++)
                            if (Math.hypot(x - corners[i][0], y - corners[i][1]) < dp(34)) { drag = i; break; }
                        if (drag < 0 && sr.contains(x, y)) drag = 4;
                    }
                    if (drag < 0 && y > stripY() - dp(10) && y < stripY() + dp(100)) drag = 5;
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    if (Math.hypot(x - downX, y - downY) > dp(8)) moved = true;
                    float dx = x - lastX, dy = y - lastY;
                    lastX = x; lastY = y;
                    if (drag == 5) {
                        stripScroll = GameKit.clamp(stripScroll - dx, 0, stripMax());
                    } else if (drag >= 0) {
                        moveCrop(drag, dx / sc(), dy / sc());
                    }
                    invalidate();
                    return true;
                }
                case MotionEvent.ACTION_UP: {
                    if (!moved) tap(x, y);
                    drag = -1;
                    invalidate();
                    return true;
                }
            }
            return true;
        }

        void moveCrop(int which, float dx, float dy) {
            float W = work.getWidth(), H = work.getHeight(), min = Math.max(16, Math.min(W, H) * 0.05f);
            RectF r = new RectF(crop);
            if (which == 4) {
                r.offset(dx, dy);
                if (r.left < 0) r.offset(-r.left, 0);
                if (r.top < 0) r.offset(0, -r.top);
                if (r.right > W) r.offset(W - r.right, 0);
                if (r.bottom > H) r.offset(0, H - r.bottom);
                crop.set(r);
                return;
            }
            if (which == 0 || which == 2) r.left = GameKit.clamp(r.left + dx, 0, r.right - min);
            else r.right = GameKit.clamp(r.right + dx, r.left + min, W);
            if (which == 0 || which == 1) r.top = GameKit.clamp(r.top + dy, 0, r.bottom - min);
            else r.bottom = GameKit.clamp(r.bottom + dy, r.top + min, H);
            float ratio = ratio();
            if (ratio > 0) {   // proporción fija: el alto sigue al ancho
                float h = r.width() / ratio;
                if (which == 0 || which == 1) r.top = r.bottom - h; else r.bottom = r.top + h;
                if (r.top < 0 || r.bottom > H) return;
            }
            crop.set(r);
        }

        float ratio() {
            if (aspect == 0) return 0;
            if (aspect == 1) return work.getWidth() / (float) work.getHeight();
            return RATIOS[aspect];
        }

        void applyAspect() {
            float r = ratio();
            float W = work.getWidth(), H = work.getHeight();
            if (r <= 0) { crop.set(0, 0, W, H); return; }
            float w = W, h = W / r;
            if (h > H) { h = H; w = H * r; }
            crop.set((W - w) / 2, (H - h) / 2, (W + w) / 2, (H + h) / 2);
        }

        void tap(float x, float y) {
            if (bNeon.contains(x, y)) { toNeon(); return; }
            if (bRotate.contains(x, y)) { rotate(); return; }
            if (bCrop.contains(x, y)) { tab = tab == TAB_CROP ? TAB_FILTERS : TAB_CROP; stripScroll = 0; return; }
            if (bSize.contains(x, y)) { sizeDialog(); return; }
            if (bCancel.contains(x, y)) { finish(); return; }
            if (bSave.contains(x, y)) { saveCopy(); return; }
            float sy = stripY();
            if (y > sy - dp(10) && y < sy + dp(100)) {
                if (tab == TAB_CROP) {
                    int i = (int) ((x - dp(12) + stripScroll) / dp(92));
                    if (i >= 0 && i < ASPECTS.length) { aspect = i; applyAspect(); }
                } else {
                    int i = (int) ((x - dp(12) + stripScroll) / dp(88));
                    if (i >= 0 && i < PhotoTools.FILTERS.length) filter = i;
                }
            }
        }
    }
}
