package com.aplauso.encuentra;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/** Acceso a fotos, videos y audios del teléfono (galería automática) y guardado de resultados. */
public class Media {
    static final int TYPE_IMAGE = 0, TYPE_VIDEO = 1, TYPE_AUDIO = 2, TYPE_DOC = 3;

    static class Item {
        Uri uri;
        String name;
        long size, dateSec, durationMs;
        int type;
    }

    // ---------- Permisos ----------
    static final int ACCESS_NONE = 0, ACCESS_PARTIAL = 1, ACCESS_FULL = 2;
    static final String USER_SELECTED = "android.permission.READ_MEDIA_VISUAL_USER_SELECTED";
    static volatile String lastError = null;

    static String[] permissions() {
        if (Build.VERSION.SDK_INT >= 34) return new String[]{
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                USER_SELECTED};
        if (Build.VERSION.SDK_INT >= 33) return new String[]{
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO};
        return new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    }

    static boolean granted(Context c, String p) {
        return c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    /** Acceso a un tipo: completo, limitado ("Seleccionar fotos") o ninguno. */
    static int access(Context c, int type) {
        if (Build.VERSION.SDK_INT < 33)
            return granted(c, Manifest.permission.READ_EXTERNAL_STORAGE) ? ACCESS_FULL : ACCESS_NONE;
        if (type == TYPE_AUDIO)
            return granted(c, Manifest.permission.READ_MEDIA_AUDIO) ? ACCESS_FULL : ACCESS_NONE;
        String full = type == TYPE_VIDEO ? Manifest.permission.READ_MEDIA_VIDEO : Manifest.permission.READ_MEDIA_IMAGES;
        if (granted(c, full)) return ACCESS_FULL;
        if (Build.VERSION.SDK_INT >= 34 && granted(c, USER_SELECTED)) return ACCESS_PARTIAL;
        return ACCESS_NONE;
    }

    /** true si hay algún acceso (completo o limitado) a los tres tipos. */
    static boolean hasPermission(Context c) {
        return access(c, TYPE_IMAGE) != ACCESS_NONE && access(c, TYPE_VIDEO) != ACCESS_NONE
                && access(c, TYPE_AUDIO) != ACCESS_NONE;
    }

    static void request(Activity a, int code) {
        List<String> need = new ArrayList<>();
        for (String p : permissions()) need.add(p);
        if (Build.VERSION.SDK_INT <= 28) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        a.requestPermissions(need.toArray(new String[0]), code);
    }

    // ---------- Consultas ----------
    static Uri collection(int type) {
        if (type == TYPE_VIDEO) return MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        if (type == TYPE_AUDIO) return MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        return MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
    }

    static List<Item> query(Context c, int type, String selection, String[] args, int limit) {
        List<Item> out = new ArrayList<>();
        Uri col = collection(type);
        List<String> cols = new ArrayList<>();
        cols.add(MediaStore.MediaColumns._ID);
        cols.add(MediaStore.MediaColumns.DISPLAY_NAME);
        cols.add(MediaStore.MediaColumns.SIZE);
        cols.add(MediaStore.MediaColumns.DATE_MODIFIED);
        if (type == TYPE_VIDEO) cols.add(MediaStore.Video.Media.DURATION);
        if (type == TYPE_AUDIO) cols.add(MediaStore.Audio.Media.DURATION);
        try (Cursor cur = c.getContentResolver().query(col, cols.toArray(new String[0]), selection, args,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC")) {
            if (cur == null) return out;
            while (cur.moveToNext() && (limit <= 0 || out.size() < limit)) {
                Item it = new Item();
                long id = cur.getLong(0);
                it.uri = ContentUris.withAppendedId(col, id);
                it.name = cur.getString(1);
                it.size = cur.getLong(2);
                it.dateSec = cur.getLong(3);
                if (cols.size() > 4) it.durationMs = cur.getLong(4);
                it.type = type;
                out.add(it);
            }
            lastError = null;
        } catch (Exception e) {
            lastError = e.getClass().getSimpleName() + ": " + e.getMessage();
        }
        return out;
    }

    static long totalSize(List<Item> items) {
        long s = 0;
        for (Item i : items) s += i.size;
        return s;
    }

    // ---------- Guardar resultados de los editores ----------
    /**
     * Copia un archivo temporal a la carpeta pública (Pictures/SSS, Movies/SSS o Music/SSS).
     * Devuelve la Uri del archivo guardado o null si falla.
     */
    static Uri save(Context c, File tmp, int type, String name, String mime) {
        String dir = type == TYPE_VIDEO ? Environment.DIRECTORY_MOVIES
                : type == TYPE_AUDIO ? Environment.DIRECTORY_MUSIC : Environment.DIRECTORY_PICTURES;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir + "/SSS");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri uri = c.getContentResolver().insert(collection(type), v);
                if (uri == null) return null;
                try (OutputStream os = c.getContentResolver().openOutputStream(uri);
                     InputStream is = new FileInputStream(tmp)) {
                    copy(is, os);
                }
                v.clear();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                c.getContentResolver().update(uri, v, null, null);
                return uri;
            } else {
                File folder = new File(Environment.getExternalStoragePublicDirectory(dir), "SSS");
                if (!folder.exists() && !folder.mkdirs()) return null;
                File dest = new File(folder, name);
                try (InputStream is = new FileInputStream(tmp); OutputStream os = new FileOutputStream(dest)) {
                    copy(is, os);
                }
                MediaScannerConnection.scanFile(c, new String[]{dest.getAbsolutePath()}, new String[]{mime}, null);
                return Uri.fromFile(dest);
            }
        } catch (Exception e) {
            return null;
        } finally {
            tmp.delete();
        }
    }

    static void copy(InputStream is, OutputStream os) throws java.io.IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
    }

    static String stamp() {
        return new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(new java.util.Date());
    }

    // ---------- Documentos y acceso a todos los archivos ----------
    /** ¿Tiene SSS+ "Acceso a todos los archivos"? (necesario para documentos de otras apps y el gestor). */
    static boolean allFiles(Context c) {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    static void requestAllFiles(Activity a) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                a.startActivity(new android.content.Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + a.getPackageName())));
            } else {
                a.requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 77);
            }
        } catch (Exception e) {
            a.startActivity(new android.content.Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
        }
    }

    /** Busca documentos (PDF, EPUB, DOCX, TXT) en las carpetas habituales del teléfono. */
    static List<Item> scanDocs(int limit) {
        List<Item> out = new ArrayList<>();
        File root = Environment.getExternalStorageDirectory();
        String[] dirs = {"Download", "Documents", "Books", "DCIM", "Telegram", "WhatsApp/Media/WhatsApp Documents",
                "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Documents", "Pictures", "Music", ""};
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (String d : dirs) {
            File f = d.isEmpty() ? root : new File(root, d);
            scan(f, d.isEmpty() ? 1 : 5, out, seen, limit);
            if (out.size() >= limit) break;
        }
        java.util.Collections.sort(out, (x, y) -> Long.compare(y.dateSec, x.dateSec));
        return out;
    }

    private static void scan(File dir, int depth, List<Item> out, java.util.Set<String> seen, int limit) {
        if (dir == null || depth < 0 || out.size() >= limit) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            if (out.size() >= limit) return;
            if (k.getName().startsWith(".")) continue;
            if (k.isDirectory()) {
                if (!k.getName().equals("Android") || depth > 3) scan(k, depth - 1, out, seen, limit);
            } else if (DocIO.typeOf(k.getName()) != null && !"html".equals(DocIO.typeOf(k.getName())) && seen.add(k.getAbsolutePath())) {
                Item it = new Item();
                it.uri = Uri.fromFile(k);
                it.name = k.getName();
                it.size = k.length();
                it.dateSec = k.lastModified() / 1000;
                it.type = TYPE_DOC;
                out.add(it);
            }
        }
    }

    /** Guarda un documento en Documentos/SSS. */
    static Uri saveDoc(Context c, File tmp, String name, String mime) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/SSS");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri uri = c.getContentResolver().insert(MediaStore.Files.getContentUri("external"), v);
                if (uri == null) return null;
                try (OutputStream os = c.getContentResolver().openOutputStream(uri); InputStream is = new FileInputStream(tmp)) {
                    copy(is, os);
                }
                v.clear();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                c.getContentResolver().update(uri, v, null, null);
                return uri;
            } else {
                File folder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "SSS");
                if (!folder.exists() && !folder.mkdirs()) return null;
                File dest = new File(folder, name);
                try (InputStream is = new FileInputStream(tmp); OutputStream os = new FileOutputStream(dest)) {
                    copy(is, os);
                }
                return Uri.fromFile(dest);
            }
        } catch (Exception e) {
            return null;
        } finally {
            tmp.delete();
        }
    }

    /** Nombre visible de una Uri (content:// o file://). */
    static String nameOf(Context c, Uri uri) {
        if (uri == null) return "documento";
        if ("file".equals(uri.getScheme())) return new File(uri.getPath()).getName();
        try (Cursor cur = c.getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) return cur.getString(0);
        } catch (Exception ignored) {}
        String seg = uri.getLastPathSegment();
        return seg == null ? "documento" : seg;
    }
}
