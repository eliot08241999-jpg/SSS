package com.aplauso.encuentra;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Iterator;

/**
 * Los trucos de los jefes de Lanaria (ideas del creador de SSS+): cada uno reacciona de una forma distinta al cencerro.
 * EcoBoss se encarga de moverlos y de sus ataques básicos; aquí va lo especial de cada uno.
 */
public class EcoBoss2 {
    static final int W = EcoWorld.W, H = EcoWorld.H;

    static boolean handles(String id) {
        switch (id) {
            case "B3": case "B4": case "B5": case "B6": case "B7": case "B8": case "B9": case "B10": case "B11": case "B12":
            case "B13": case "B14": case "B15": case "B16": case "B17": case "B18": case "B19": case "B20":
            case "D1": case "D2": case "D3":
                return true;
        }
        return false;
    }

    static float cx(EcoView.Enemy e) { return e.b.x + e.b.w / 2; }
    static float cy(EcoView.Enemy e) { return e.b.y + e.b.h / 2; }
    static float px(EcoView v) { return v.pl.x + v.pl.w / 2; }
    static float py(EcoView v) { return v.pl.y + v.pl.h / 2; }

    static boolean playerOnTop(EcoView v, EcoView.Enemy e) {
        float bottom = v.pl.y + v.pl.h;
        return v.pl.x + v.pl.w > e.b.x + 0.1f && v.pl.x < e.b.x + e.b.w - 0.1f && Math.abs(bottom - e.b.y) < 0.35f;
    }

    // =====================================================================
    // Actualización
    // =====================================================================
    static void update(EcoView v, EcoView.Enemy e, float dt) {
        String id = e.bdef.id;
        boolean fight = v.fightActive;
        switch (id) {
            case "B3": {            // TITÁN DE HIELO: coraza que se regenera si dejas de sonar
                if (e.shield < 0) e.shield = 100;
                if (fight) { e.hitT += dt; if (e.hitT > 2.2f) e.shield = Math.min(100, e.shield + 22 * dt); }
                EcoBoss.generic(v, e, dt);
                break;
            }
            case "B4": {            // CLAUDIO: escudo de agua que se rompe repicando justo tras su croar
                if (fight) {
                    e.aux3 += dt;
                    if (e.aux3 > 1.9f) {
                        e.aux3 = 0; e.winT = 0.55f;
                        e.say = "¡CROOOAC!"; e.sayT = 0.6f;
                        v.chip.sfx(Chip.SFX_DUCK);
                    }
                    if (e.winT > 0) e.winT -= dt;
                    if (e.aux4 > 0) e.aux4 -= dt;
                }
                EcoBoss.generic(v, e, dt);
                break;
            }
            case "B5": {            // SOMBRAVERDE: zonas de silencio y piedras del eco
                if (fight) {
                    if (v.gongs.isEmpty()) { v.gongs.add(new float[]{4.5f, 13.4f, 0, 0}); v.gongs.add(new float[]{24.5f, 13.4f, 0, 0}); }
                    e.aux3 += dt;
                    if (e.aux3 > 4f) { e.aux3 = 0; v.silence.add(new float[]{cx(e), cy(e), 3f, 6f}); v.chip.sfx(Chip.SFX_DUCK); }
                }
                EcoBoss.generic(v, e, dt);
                break;
            }
            case "B6": gargantua(v, e, dt); break;
            case "B7": {            // MADAME PICADURA: látigo de enjambre
                EcoBoss.generic(v, e, dt);
                if (!fight) break;
                if (e.aux4 > 0) { e.aux4 -= dt; break; }
                double target = Math.atan2(py(v) - cy(e), px(v) - cx(e));
                e.aux3 = (float) (target + Math.sin(e.t * 2.2f) * 1.1f);
                for (int i = 2; i <= 11; i++) {
                    float sx = cx(e) + (float) Math.cos(e.aux3) * i * 0.6f, sy = cy(e) + (float) Math.sin(e.aux3) * i * 0.6f;
                    if (Math.abs(sx - px(v)) < 0.55f && Math.abs(sy - py(v)) < 0.6f) v.hurt(e.dmg * 0.8f, sx);
                }
                break;
            }
            case "B8": {            // DON CAPARAZÓN: se encierra; súbete y repica en su campana
                if (fight && e.stun <= 0) {
                    e.aux3 += dt;
                    if (e.aux4 == 0 && e.aux3 > 6f) { e.aux4 = 1; e.aux3 = 0; e.say = "*se esconde*"; e.sayT = 1; }
                    else if (e.aux4 == 1 && e.aux3 > 5f) { e.aux4 = 0; e.aux3 = 0; }
                }
                if (e.aux4 == 1) { e.b.vx = 0; EcoBoss.gravity(v, e, dt); }
                else EcoBoss.generic(v, e, dt);
                // su caparazón es una plataforma
                if (v.pl.vy >= 0 && v.pl.x + v.pl.w > e.b.x + 0.1f && v.pl.x < e.b.x + e.b.w - 0.1f) {
                    float bottom = v.pl.y + v.pl.h;
                    if (bottom > e.b.y - 0.05f && bottom < e.b.y + 0.55f) { v.pl.y = e.b.y - v.pl.h; v.pl.vy = 0; v.pl.onGround = true; }
                }
                break;
            }
            case "B9": {            // CORALIA: bajo el agua, tentáculos verticales
                v.water = fight;
                if (fight) {
                    e.aux3 += dt;
                    if (e.aux3 > 2.6f) {
                        e.aux3 = 0;
                        e.lanes = new float[e.hp < e.maxHp / 2 ? 3 : 2];
                        for (int i = 0; i < e.lanes.length; i++) {
                            e.lanes[i] = 2 + v.rnd.nextFloat() * (W - 5);
                            v.warn(e.lanes[i], 1, 0.9f, H - 2, 0.9f);
                        }
                        e.aux4 = 0.9f;
                    }
                    if (e.aux4 > 0) {
                        e.aux4 -= dt;
                        if (e.aux4 <= 0 && e.lanes != null) for (float x : e.lanes) {
                            EcoView.Shot s = v.enemyShot(EcoView.SH_BEAM, x, 1, 0, 0, 0, 0.9f, e.dmg, e.bdef.c1);
                            s.x = x; s.w = 0.9f; s.h = H - 2; s.life = 0.5f;
                        }
                    }
                }
                EcoBoss.generic(v, e, dt);
                break;
            }
            case "B10": buho(v, e, dt); break;
            case "B11": {           // TURO: si lo desvías, se estrella contra la trampa
                EcoBoss.generic(v, e, dt);
                if (e.aux4 == 1 && e.stun > 0.5f) {
                    e.aux4 = 0;
                    e.stun = 2.5f;
                    v.damageBoss(e, e.maxHp * 0.09f);
                    v.shake = 0.5f;
                    e.say = "¡¡CLANG!!"; e.sayT = 1.2f;
                }
                break;
            }
            case "B12": {           // BARÓN GRAJÓFONO: devuelve tus repiques del revés
                EcoBoss.generic(v, e, dt);
                if (!fight) break;
                for (Iterator<float[]> it = v.shotLog.iterator(); it.hasNext(); ) if (v.playTime - it.next()[3] > 4) it.remove();
                e.aux3 += dt;
                if (e.aux3 > 3.5f) {
                    e.aux3 = 0;
                    if (!v.shotLog.isEmpty()) {
                        int n = 0;
                        for (float[] r : v.shotLog) {
                            if (n++ >= 6) break;
                            EcoView.Shot s = v.enemyShot(EcoView.SH_EWAVE, W - r[0], r[1], -r[2] * 0.8f, 0, 0, 0.6f, e.dmg, e.bdef.c2);
                            s.w = 0.5f; s.h = 0.9f; s.bounces = 2; s.life = 3;
                        }
                        v.shotLog.clear();
                        e.say = "♫ ¡Repetición!"; e.sayT = 1.2f;
                        v.chip.sfx(Chip.SFX_TALK);
                    }
                }
                break;
            }
            case "B13": bruma(v, e, dt); break;
            case "B14": {           // MARQUESA POLILLA: polvo hipnótico
                EcoBoss.generic(v, e, dt);
                if (!fight) break;
                e.aux3 += dt;
                if (e.aux3 > 0.45f) {
                    e.aux3 = 0;
                    double a = v.rnd.nextDouble() * Math.PI * 2;
                    EcoView.Shot s = v.enemyShot(EcoView.SH_DUST, cx(e), cy(e), (float) Math.cos(a) * 1.6f, (float) Math.sin(a) * 1.2f + 0.4f, 0, 1.1f, e.dmg * 0.4f, e.bdef.c1);
                    s.life = 7;
                }
                break;
            }
            case "B15": {           // REINA NODRIZA: oleadas de hormigas soldado
                e.b.vx = 0;
                EcoBoss.generic(v, e, dt);
                if (!fight) break;
                e.aux3 += dt;
                if (e.aux3 > 5f) {
                    e.aux3 = 0;
                    int alive = 0;
                    for (EcoView.Enemy o : v.enemies) if (!o.dead && o.kind != null && o.kind.id.equals("AS")) alive++;
                    for (int i = 0; i < 3 && alive < 6; i++, alive++) {
                        EcoView.Enemy a = v.spawnKind("AS", Math.max(2, e.b.x - 1.5f - i * 1.3f), 14);
                        if (a != null) { a.dir = -1; a.partner = e; a.bellsMin = 0; a.bellsMax = 1; }
                    }
                    v.chip.sfx(Chip.SFX_POWER);
                }
                break;
            }
            case "B16": {           // VORTEX: barricadas de madera
                EcoBoss.generic(v, e, dt);
                if (!fight) break;
                for (Iterator<float[]> it = v.barricades.iterator(); it.hasNext(); ) { float[] bq = it.next(); bq[5] -= dt; if (bq[5] <= 0) it.remove(); }
                e.aux3 += dt;
                if (e.aux3 > 4f && v.barricades.size() < 3) {
                    e.aux3 = 0;
                    float dir = Math.signum(px(v) - cx(e));
                    float bx = GameKit.clamp(cx(e) + dir * 3f, 2, W - 4);
                    if (Math.abs(bx + 0.6f - px(v)) > 1.6f) {
                        v.barricades.add(new float[]{bx, 12, 1.2f, 3, 0, 12});
                        v.chip.sfx(Chip.SFX_DOOR);
                        e.say = "¡Tac, tac, tac!"; e.sayT = 0.8f;
                    }
                }
                break;
            }
            case "B17": {           // GRISELDA: hilos de lana que atrapan tu cencerro
                EcoBoss.generic(v, e, dt);
                if (!fight) break;
                e.aux3 += dt;
                if (e.aux3 > 3f) {
                    e.aux3 = 0;
                    float dx = px(v) - cx(e), dy = py(v) - cy(e), d = (float) Math.max(0.1, Math.hypot(dx, dy));
                    v.enemyShot(EcoView.SH_THREAD, cx(e), cy(e), dx / d * 11, dy / d * 11, 0, 0.45f, e.dmg * 0.5f, Color.WHITE);
                }
                if (v.pullT > 0) v.pullVX = Math.signum(cx(e) - px(v)) * 6;
                break;
            }
            case "B18": {           // DON BARONIO: campo eléctrico
                EcoBoss.generic(v, e, dt);
                if (!fight) break;
                e.aux3 += dt;
                if (e.aux4 > 0) e.aux4 -= dt;
                if (e.aux3 > 5f) { e.aux3 = 0; e.aux4 = 2.5f; e.say = "*bzzzt*"; e.sayT = 0.8f; v.chip.sfx(Chip.SFX_POWER); }
                break;
            }
            case "B19": cabra(v, e, dt); break;
            case "B20": lumenia(v, e, dt); break;
            case "D1": goliath(v, e, dt); break;
            case "D2": {            // IGNIS: el cencerro se calienta
                EcoBoss.generic(v, e, dt);
                if (!fight) break;
                v.heat = Math.max(0, v.heat - 15 * dt);
                break;
            }
            case "D3": {            // SEÑOR TOPO: se esconde y agrieta el suelo
                if (fight) {
                    e.aux3 += dt;
                    if (!e.hidden && e.aux3 > 6f) { e.hidden = true; e.aux3 = 0; v.chip.sfx(Chip.SFX_DUCK); }
                    if (e.hidden) {
                        e.b.vx = Math.signum(px(v) - cx(e)) * 5;
                        v.moveBody(e.b, dt, false);
                        if (e.aux3 > 1.5f) {
                            e.hidden = false; e.aux3 = 0; e.b.vy = -14;
                            float fy = e.b.y + e.b.h - 0.6f;
                            v.enemyShot(EcoView.SH_SHOCK, cx(e) - 0.4f, fy, -9, 0, 0, 0.7f, e.dmg, e.bdef.c2);
                            v.enemyShot(EcoView.SH_SHOCK, cx(e) + 0.4f, fy, 9, 0, 0, 0.7f, e.dmg, e.bdef.c2);
                            for (int i = -1; i <= 1; i += 2) v.statics.add(new float[]{GameKit.clamp(cx(e) + i * 3, 1, W - 3), 14.6f, 2, 5, 1});
                            v.shake = 0.4f;
                            v.chip.sfx(Chip.SFX_BOOM);
                        }
                        break;
                    }
                }
                EcoBoss.generic(v, e, dt);
                break;
            }
        }
    }

    // ---------------- GARGANTÚA: la oruga sube desde abajo; el cencerro hace caer estalactitas ----------------
    static void gargantua(EcoView v, EcoView.Enemy e, float dt) {
        if (e.aux3 == 0) e.aux3 = 15.5f;
        if (!v.fightActive) { e.b.y = e.aux3 - e.b.h + 0.3f; return; }
        e.t2 += dt;
        float cyc = e.t2 % 11f;
        float target = cyc < 6 ? 15.5f - (cyc / 6f) * 3.9f : cyc < 8 ? 11.6f : 11.6f + (cyc - 8) / 3f * 3.9f;
        e.aux3 += (target - e.aux3) * Math.min(1, dt * 3);
        e.b.x += (px(v) - cx(e)) * Math.min(1, dt * 0.8f);
        e.b.y = e.aux3 - e.b.h + 0.3f;
        if (v.pl.y + v.pl.h > e.aux3 + 0.15f) v.hurt(e.dmg, px(v) + 1);
        // estalactitas
        for (Iterator<float[]> it = v.stalactites.iterator(); it.hasNext(); ) {
            float[] s = it.next();
            s[2] += 30 * dt;
            s[1] += s[2] * dt;
            if (s[1] + 0.8f > e.aux3 && s[0] > e.b.x - 1.2f && s[0] < e.b.x + e.b.w + 1.2f) {
                it.remove();
                v.chip.sfx(Chip.SFX_BOOM);
                v.damageBoss(e, e.maxHp * 0.06f);
                if (e.dead) return;
            } else if (s[1] > H) it.remove();
        }
        // sus ataques normales
        e.cd -= dt;
        if (e.state == 0 && e.cd <= 0) { e.state = 1; e.t2 = e.t2; e.sub = 0; e.move = e.bdef.moves[e.cycle++ % e.bdef.moves.length]; e.aux = 0; }
        if (e.state == 1) {
            e.aux += dt;
            if (e.move == EcoData.MV_FAN && e.aux > 0.4f) { EcoBoss.fan(v, e, 5, 0.22f, 7, EcoView.SH_ORB); e.state = 0; e.cd = 2.2f; }
            else if (e.move == EcoData.MV_RAIN) {
                if (e.sub == 0) {
                    e.lanes = new float[6];
                    for (int i = 0; i < 6; i++) { e.lanes[i] = 2 + v.rnd.nextFloat() * (W - 4); v.warn(e.lanes[i] - 0.3f, 1, 0.6f, H - 2, 0.7f); }
                    e.sub = 1;
                } else if (e.aux > 0.7f) {
                    for (float x : e.lanes) v.enemyShot(EcoView.SH_ORB, x, 1.2f, 0, 3, 22, 0.45f, e.dmg, e.bdef.c1);
                    e.state = 0; e.cd = 2.4f;
                }
            }
        }
    }

    // ---------------- GRAN BÚHO ESPÍA: ciego, ataca donde oyó el último sonido ----------------
    static void buho(EcoView v, EcoView.Enemy e, float dt) {
        EcoView.Body b = e.b;
        if (!v.fightActive) { EcoBoss.hover(e, e.homeX + b.w / 2, 3, dt, 2); return; }
        if (v.gongs.isEmpty()) { v.gongs.add(new float[]{4.5f, 13.2f, 0, 0}); v.gongs.add(new float[]{24.5f, 13.2f, 0, 0}); }
        if (e.stun > 0) { e.stun -= dt; b.vy += 30 * dt; v.moveBody(b, dt, false); return; }
        e.t2 += dt;
        boolean heard = v.playTime - v.lastSoundT < 3;
        switch (e.sub) {
            case 0:
                EcoBoss.hover(e, 15 + (float) Math.sin(e.t * 0.5f) * 9, 2.6f, dt, 1.5f);
                if (e.t2 > 2.2f) {
                    e.t2 = 0;
                    if (heard) { e.sub = 1; e.aux = v.lastSoundX; e.aux2 = v.lastSoundY; e.say = "¡Te oigo!"; e.sayT = 0.7f; }
                    else if (v.rnd.nextBoolean()) { e.say = "...¿dónde?"; e.sayT = 1; }
                }
                break;
            case 1:     // aviso
                e.flash = ((int) (e.t2 * 12)) % 2 == 0 ? 0.05f : 0;
                if (e.t2 > 0.5f) { e.sub = 2; e.t2 = 0; v.chip.sfx(Chip.SFX_DOOR); }
                break;
            case 2: {   // picado hacia el último sonido
                float dx = e.aux - cx(e), dy = e.aux2 - cy(e), d = (float) Math.max(0.1, Math.hypot(dx, dy));
                b.x += dx / d * 14 * dt; b.y += dy / d * 14 * dt;
                if (d < 0.6f || b.y + b.h >= H - 1.05f || e.t2 > 1.4f) { e.sub = 3; e.t2 = 0; v.chip.sfx(Chip.SFX_BOOM); EcoBoss.fan(v, e, 6, 0.4f, 6, EcoView.SH_ORB); }
                break;
            }
            case 3:
                if (e.t2 > 0.7f) { e.sub = 0; e.t2 = 0; }
                break;
        }
        // engranajes que caen
        for (Iterator<float[]> it = v.stalactites.iterator(); it.hasNext(); ) {
            float[] s = it.next();
            s[2] += 40 * dt;
            s[1] += s[2] * dt;
            if (Math.abs(s[0] - cx(e)) < b.w / 2 + 0.6f && s[1] + 0.8f > b.y && s[1] < b.y + b.h) {
                it.remove();
                e.stun = 2f; e.say = "¡CRONK!"; e.sayT = 1;
                v.shake = 0.4f;
                v.damageBoss(e, e.maxHp * 0.1f);
                if (e.dead) return;
            } else if (s[1] > H) it.remove();
        }
        for (float[] g : v.gongs) if (g[2] > 0) g[2] -= dt;
    }

    // ---------------- BRUMA: tres lobas en la niebla, solo una es real ----------------
    static void bruma(EcoView v, EcoView.Enemy e, float dt) {
        v.fog = v.fightActive;
        if (v.fightActive && v.decoys.isEmpty()) {
            for (int i = 0; i < 2; i++) {
                EcoView.Enemy c = new EcoView.Enemy();
                c.type = 'D'; c.decoy = true; c.bdef = e.bdef; c.b = new EcoView.Body(e.b.w, e.b.h);
                c.hp = c.maxHp = 1; c.partner = e;
                v.enemies.add(c); v.decoys.add(c);
            }
        }
        EcoBoss.generic(v, e, dt);
        if (!v.fightActive) return;
        e.aux3 += dt;
        if (e.aux3 > 5f && !v.decoys.isEmpty()) {     // se cambia de sitio con un clon
            e.aux3 = 0;
            EcoView.Enemy c = v.decoys.get(v.rnd.nextInt(v.decoys.size()));
            float tx = c.b.x; c.b.x = e.b.x; e.b.x = tx;
            v.chip.sfx(Chip.SFX_DUCK);
        }
        for (int i = 0; i < v.decoys.size(); i++) {
            EcoView.Enemy c = v.decoys.get(i);
            float target = i == 0 ? W - e.b.x - e.b.w : ((e.b.x + 9 + i * 4) % (W - 4)) + 1;
            c.b.x += (target - c.b.x) * Math.min(1, dt * 3);
            c.b.y = e.b.y; c.dir = i == 0 ? -e.dir : e.dir; c.t = e.t + i; c.vis = 0.95f;
        }
        if (v.sonarT > 0) v.sonarT -= dt;
    }

    // ---------------- CABRA SOMBRA: te imita un segundo después ----------------
    static void cabra(EcoView v, EcoView.Enemy e, float dt) {
        EcoView.Body b = e.b;
        if (!v.fightActive || v.trailN < 60) { EcoBoss.gravity(v, e, dt); return; }
        int i = (v.trailI - 60 + v.trailX.length) % v.trailX.length;
        b.x += (v.trailX[i] - b.x) * Math.min(1, dt * 20);
        b.y += (v.trailY[i] - b.y) * Math.min(1, dt * 20);
        e.dir = v.trailFace[i] ? 1 : -1;
        if (v.trailShot[i]) {
            v.trailShot[i] = false;
            EcoView.Shot s = v.enemyShot(EcoView.SH_EWAVE, cx(e) + e.dir * 0.6f, cy(e) - 0.3f, e.dir * 14, 0, 0, 0.6f, e.dmg, e.bdef.c2);
            s.w = 0.5f; s.h = 0.7f; s.bounces = 1; s.selfHit = true; s.life = 2.2f;
        }
        // sus propias ondas rebotadas le hacen daño
        for (EcoView.Shot s : v.shots)
            if (s.selfHit && !s.dead && s.bounces == 0 && GameKit.overlap(s.x, s.y, s.w, s.h, b.x, b.y, b.w, b.h)) {
                s.dead = true;
                e.say = "¡!"; e.sayT = 0.5f;
                v.damageBoss(e, 120);
                if (e.dead) return;
            }
    }

    // ---------------- GOLIATH: pica el tronco y da la vuelta a la gravedad ----------------
    static void goliath(EcoView v, EcoView.Enemy e, float dt) {
        EcoView.Body b = e.b;
        if (!v.fightActive) { b.x = W - 2 - b.w; b.y = 6; return; }
        b.x = W - 2.2f - b.w;
        if (e.stun > 0) { e.stun -= dt; return; }
        b.y = 9.2f + (float) Math.sin(e.t * 0.7f) * 3.2f;
        if (e.aux4 > 0) { e.aux4 -= dt; if (e.aux4 <= 0) { v.gravSign = 1; v.say("La gravedad vuelve a la normalidad"); } }
        e.aux3 += dt;
        if (e.aux3 > 5f && e.winT <= 0 && e.aux4 <= 0) { e.winT = 0.8f; e.say = "*toc toc...*"; e.sayT = 0.8f; }
        if (e.winT > 0) {
            e.winT -= dt;
            e.flash = ((int) (e.winT * 14)) % 2 == 0 ? 0.04f : 0;
            if (e.winT <= 0) {
                e.aux3 = 0;
                v.gravSign = -v.gravSign;
                e.aux4 = 4f;
                v.shake = 0.5f;
                v.chip.sfx(Chip.SFX_BOOM);
                v.say("🙃 ¡La gravedad se ha dado la vuelta!");
            }
        }
        e.cd -= dt;
        if (e.cd <= 0) { e.cd = 2f; EcoBoss.fan(v, e, 5, 0.25f, 7, EcoView.SH_ORB); }
    }

    // ---------------- LUMENIA ----------------
    static final int LM_DUST = 0, LM_MIRROR = 1, LM_AMBUSH = 2, LM_LANES = 3, LM_COCOONS = 4, LM_CANTO = 5;

    static void lumenia(EcoView v, EcoView.Enemy e, float dt) {
        EcoView.Body b = e.b;
        if (!v.fightActive) { EcoBoss.hover(e, e.homeX + b.w / 2, 4, dt, 2); return; }
        // ---- paso a la fase 2 ----
        if (e.role == 0 && e.hp <= e.maxHp / 2) {
            e.role = 1; e.state = 0; e.cd = 1.5f; e.stun = 0; e.flying = true; e.vis = 1;
            e.say = "¡¡KRRRZZZZT!!"; e.sayT = 2;
            v.shake = 1f;
            v.chip.tempoMul = 1.25f;
            v.chip.sfx(Chip.SFX_BOOM);
            for (int i = 0; i < 18; i++) v.float_("✧", cx(e) + (v.rnd.nextFloat() - 0.5f) * 4, cy(e) + (v.rnd.nextFloat() - 0.5f) * 3, Color.rgb(255, 255, 220));
            v.say("Los capullos estallan: ¡todos los sonidos robados salen a la vez!");
        }
        if (e.aux3 > 0) e.aux3 -= dt;
        if (e.stun > 0) {           // en el suelo, aturdida: ¡ahora!
            e.stun -= dt;
            e.flying = false;
            b.vy += EcoView.GRAV * dt;
            v.moveBody(b, dt, false);
            if (e.stun <= 0) { e.flying = true; e.state = 0; e.cd = 1; }
            return;
        }
        e.t2 += dt;
        if (e.state == 0) {
            e.vis = e.role == 0 ? 0.55f : 1;
            EcoBoss.hover(e, 15 + (float) Math.sin(e.t * 0.6f) * 8, e.role == 0 ? 3.5f : 5f, dt, 1.5f);
            e.cd -= dt;
            if (e.cd <= 0) {
                int[] seq = e.role == 0 ? new int[]{LM_DUST, LM_AMBUSH, LM_MIRROR, LM_AMBUSH} : new int[]{LM_LANES, LM_COCOONS, LM_CANTO, LM_LANES, LM_COCOONS};
                e.move = seq[e.cycle++ % seq.length];
                e.state = 1; e.sub = 0; e.t2 = 0;
            }
            return;
        }
        float k = e.role == 0 ? 1 : 1.25f;
        switch (e.move) {
            case LM_DUST:           // Polvo de Vacío: si te roza, el cencerro enmudece
                EcoBoss.hover(e, 15, 2.5f, dt, 2);
                if (e.t2 > 0.6f && e.sub == 0) {
                    for (int i = 0; i < 14; i++) {
                        EcoView.Shot s = v.enemyShot(EcoView.SH_VOID, 1.5f + i * 1.9f, 1.5f + v.rnd.nextFloat() * 2, (v.rnd.nextFloat() - 0.5f) * 2, 1.2f + v.rnd.nextFloat(), 0, 0.9f, e.dmg * 0.3f, Color.rgb(60, 50, 80));
                        s.life = 7;
                    }
                    v.chip.sfx(Chip.SFX_DUCK);
                    e.sub = 1;
                }
                if (e.t2 > 1.4f) end(e, v, k);
                break;
            case LM_MIRROR:         // Aleteo Espejo: imita a los jefes que ya venciste
                e.vis = 0.3f;
                EcoBoss.hover(e, 15 + (float) Math.sin(e.t) * 6, 1.6f, dt, 3);
                if (e.t2 > 0.7f * (e.sub + 1)) {
                    switch (e.sub) {
                        case 0: EcoBoss.fan(v, e, 7, 0.18f, 7.5f, EcoView.SH_ORB); break;
                        case 1: EcoBoss.ring(v, e, 14, 6, e.t); break;
                        default:
                            for (int i = 0; i < 8; i++) { float x = 2 + v.rnd.nextFloat() * (W - 4); v.enemyShot(EcoView.SH_ORB, x, 1.2f, 0, 3, 22, 0.45f, e.dmg, e.bdef.c2); }
                    }
                    e.sub++;
                    if (e.sub >= 3) end(e, v, k);
                }
                break;
            case LM_AMBUSH: {       // Emboscada Silenciosa: el capullo se abre justo antes del golpe
                if (e.sub == 0) {
                    float side = px(v) < W / 2f ? W - 2 - b.w : 1;
                    float ty = GameKit.clamp(py(v) - b.h / 2, 1.2f, H - 1.2f - b.h);
                    b.x += (side - b.x) * Math.min(1, dt * 4);
                    b.y += (ty - b.y) * Math.min(1, dt * 4);
                    e.vis = 0.25f;
                    if (e.t2 > 0.9f) { e.sub = 1; e.t2 = 0; e.dir = b.x < W / 2f ? 1 : -1; e.aux4 = 0; v.chip.sfx(Chip.SFX_DOOR); }
                } else {
                    b.x += e.dir * 16 * k * dt;
                    e.vis = 0.45f;
                    if (e.aux4 == 0 && Math.abs(px(v) - cx(e)) < 4.5f && Math.signum(px(v) - cx(e)) == e.dir) {
                        e.aux4 = 1; e.aux3 = 0.42f;      // ventana para repicar
                    }
                    if (b.x <= 1.01f || b.x >= W - 1.01f - b.w || e.t2 > 2.2f) end(e, v, k);
                }
                break;
            }
            case LM_LANES: {        // Ecualizador Mortal: carriles de frecuencia
                if (e.sub == 0 || e.sub == 2) {
                    float[] rows = {2.2f, 4.8f, 7.4f, 10f, 13f};
                    int safe = v.rnd.nextInt(rows.length);
                    e.lanes = new float[rows.length - 1];
                    int j = 0;
                    for (int i = 0; i < rows.length; i++) if (i != safe) { e.lanes[j++] = rows[i]; v.warn(1, rows[i] - 0.5f, W - 2, 1.1f, 0.85f); }
                    e.sub++; e.t2 = 0;
                } else if (e.t2 > 0.85f) {
                    for (float l : e.lanes) {
                        EcoView.Shot s = v.enemyShot(EcoView.SH_BEAM, 1, l - 0.4f, 0, 0, 0, 0.8f, e.dmg, Color.rgb(255, 255, 230));
                        s.x = 1; s.w = W - 2; s.h = 0.9f; s.life = 0.45f;
                    }
                    v.chip.sfx(Chip.SFX_BOOM);
                    e.sub++; e.t2 = 0;
                    if (e.sub >= 4) end(e, v, k);
                }
                break;
            }
            case LM_COCOONS:        // Tormenta de Capullos: rebotan y dejan estática en el suelo
                if (e.sub == 0 && e.t2 > 0.4f) {
                    for (int i = 0; i < 5; i++) {
                        EcoView.Shot s = v.enemyShot(EcoView.SH_COCOON, cx(e), cy(e), (i - 2) * 3.2f, -6 - v.rnd.nextFloat() * 4, 16, 0.6f, e.dmg, Color.rgb(200, 200, 220));
                        s.bounces = 3; s.life = 6;
                    }
                    v.chip.sfx(Chip.SFX_SHOOT);
                    e.sub = 1;
                }
                if (e.t2 > 1.6f) end(e, v, k);
                break;
            case LM_CANTO: {        // El Canto de la Polilla: atracción y latidos
                EcoBoss.hover(e, 15, 5f, dt, 2);
                if (e.sub == 0) {
                    e.sub = 1; v.canto = true; v.beatT = 0; v.beatMeter = 0;
                    e.say = "♪ Ven... ♪"; e.sayT = 2;
                }
                v.pullVX = Math.signum(cx(e) - px(v)) * 4.5f;
                v.beatT += dt;
                if (GameKit.overlap(v.pl.x, v.pl.y, v.pl.w, v.pl.h, b.x + b.w * 0.25f, b.y + b.h * 0.3f, b.w * 0.5f, b.h * 0.5f)) {
                    v.canto = false;
                    v.hurt(35, cx(e));
                    end(e, v, k);
                    break;
                }
                if (v.beatMeter >= 6) {
                    v.canto = false;
                    v.damageBoss(e, e.maxHp * 0.12f);
                    e.stun = 3f;
                    e.say = "¡¡NOOO!!"; e.sayT = 1.5f;
                    v.shake = 0.6f;
                    v.say("¡Tu onda pura rompe su canto!");
                    end(e, v, k);
                    break;
                }
                if (e.t2 > 8f) { v.canto = false; end(e, v, k); }
                break;
            }
            default: end(e, v, k);
        }
    }

    static void end(EcoView.Enemy e, EcoView v, float k) {
        e.state = 0; e.sub = 0; e.t2 = 0;
        e.cd = (1.1f + v.rnd.nextFloat() * 0.6f) / k;
    }

    // =====================================================================
    // Cuando le das a un jefe: cada uno se defiende a su manera. Devuelve el daño que recibe de verdad.
    // =====================================================================
    static float onHit(EcoView v, EcoView.Enemy e, float d) {
        if (e.bdef == null) return d;
        switch (e.bdef.id) {
            case "B3":
                e.hitT = 0;
                if (e.shield > 0) {
                    e.shield -= 17;
                    v.float_("❄", cx(e), e.b.y - 0.4f, Color.rgb(200, 240, 255));
                    if (e.shield <= 0) { e.shield = 0; e.say = "¡CRAAACK!"; e.sayT = 1; v.chip.sfx(Chip.SFX_BOOM); }
                    return 0;
                }
                return d;
            case "B4":
                if (e.aux4 > 0) return d;
                if (e.winT > 0) {
                    e.aux4 = 4f; e.winT = 0;
                    e.say = "¡Glub! ¡Mi escudo!"; e.sayT = 1.2f;
                    v.chip.sfx(Chip.SFX_BOOM);
                    return d * 0.5f;
                }
                v.float_("💧", cx(e), e.b.y - 0.4f, Color.rgb(140, 200, 255));
                return 0;
            case "B5":
                for (float[] z : v.silence) if (Math.hypot(cx(e) - z[0], cy(e) - z[1]) < z[2]) { v.float_("🔇", cx(e), e.b.y - 0.4f, Color.LTGRAY); return 0; }
                for (float[] g : v.gongs) if (Math.abs(cx(e) - g[0]) < 3.5f) return d * 1.6f;
                return d * 0.7f;
            case "B6": return d * 0.3f;
            case "B7": return e.aux4 > 0 ? d * 1.2f : d * 0.35f;
            case "B8":
                if (e.aux4 == 1) { v.float_("🛡", cx(e), e.b.y - 0.4f, Color.LTGRAY); return 0; }
                return e.stun > 0 ? d * 1.5f : d * 0.5f;
            case "B9":
                e.b.x = GameKit.clamp(e.b.x + Math.signum(cx(e) - px(v)) * 1.2f, 1, W - 1 - e.b.w);
                return d;
            case "B10": return e.stun > 0 ? d : e.sub == 3 ? d * 0.8f : d * 0.25f;
            case "B11":
                if (e.move == EcoData.MV_CHARGE && e.sub == 1 && e.state == 1 && e.aux4 == 0) {
                    e.dir = -e.dir; e.aux4 = 1;
                    e.say = "¡¿?!"; e.sayT = 0.8f;
                    v.chip.sfx(Chip.SFX_DOOR);
                    return d * 0.3f;
                }
                return e.stun > 0 ? d * 1.4f : d * 0.5f;
            case "B15": {
                for (EcoView.Enemy o : v.enemies)
                    if (!o.dead && o.kind != null && o.kind.id.equals("AS") && o.state != 9) { v.float_("🛡", cx(e), e.b.y - 0.4f, Color.LTGRAY); return 0; }
                return d * 0.6f;
            }
            case "B16": return e.stun > 0 ? d * 1.4f : d * 0.6f;
            case "B18":
                if (e.aux4 > 0) {
                    v.float_("⚡", px(v), v.pl.y - 0.4f, Color.rgb(140, 220, 255));
                    v.hurt(e.dmg * 0.7f, cx(e));
                    return 0;
                }
                return d;
            case "B19": return d * 0.5f;
            case "B20":
                if (e.role == 0) {
                    if (e.stun > 0) return d;
                    if (e.aux3 > 0) {        // capullo abierto: ¡rompe el camuflaje!
                        e.aux3 = 0;
                        e.stun = 3f;
                        e.say = "¡¿MI MANTO?!"; e.sayT = 1.2f;
                        v.chip.sfx(Chip.SFX_BOOM);
                        v.shake = 0.4f;
                        end(e, v, 1);
                        e.state = 0;
                        return d * 0.5f;
                    }
                    v.float_("🌑", cx(e), e.b.y - 0.4f, Color.GRAY);
                    return 0;
                }
                return d;
            case "D1":
                if (e.winT > 0) {
                    e.winT = 0; e.aux3 = 0; e.stun = 2.5f;
                    e.say = "¡Mi pico!"; e.sayT = 1;
                    v.chip.sfx(Chip.SFX_BOOM);
                    return d * 1.5f;
                }
                return d * 0.8f;
            default: return d;
        }
    }

    /** Cada vez que suena el cencerro (onda, zarpazo u onda cargada). */
    static void onBell(EcoView v) {
        EcoView.Enemy e = v.mainBoss();
        v.lastSoundX = px(v); v.lastSoundY = py(v); v.lastSoundT = v.playTime;
        if (e == null || e.bdef == null || !v.fightActive) return;
        switch (e.bdef.id) {
            case "B6":
                v.stalactites.add(new float[]{GameKit.clamp(cx(e) + (v.rnd.nextFloat() - 0.5f) * 4, 2, W - 3), 1.1f, 0});
                break;
            case "B8":
                if (e.aux4 == 1 && playerOnTop(v, e)) {
                    e.aux4 = 0; e.aux3 = 0; e.stun = 3f;
                    e.say = "¡¡DOOONG!!"; e.sayT = 1.2f;
                    v.shake = 0.5f;
                    v.chip.sfx(Chip.SFX_BOOM);
                }
                break;
            case "B12":
                v.shotLog.add(new float[]{px(v), py(v) - 0.3f, v.facingR ? 16 : -16, v.playTime});
                break;
            case "B13":
                v.sonarT = 0.8f;
                break;
            case "B14": {
                int n = 0;
                for (EcoView.Shot s : v.shots)
                    if (!s.mine && s.kind == EcoView.SH_DUST && Math.hypot(s.x - px(v), s.y - py(v)) < 3.5f) { s.dead = true; n++; }
                v.ringT = 0.35f;
                break;
            }
            case "B20":
                if (v.canto) {
                    float ph = v.beatT % 0.65f;
                    if (ph < 0.2f || ph > 0.45f) {
                        v.beatMeter++;
                        v.pl.vx = Math.signum(px(v) - cx(e)) * 10; v.knockT = 0.15f;
                        v.float_("♥", px(v), v.pl.y - 0.5f, Color.rgb(255, 120, 150));
                    } else v.float_("✗", px(v), v.pl.y - 0.5f, Color.GRAY);
                }
                break;
            case "D2":
                v.heat += 20;
                if (v.heat > 100) {
                    v.heat = 50;
                    v.muteT = 1.5f;
                    v.hurt(12, px(v) - 1);
                    v.say("🔥 ¡El cencerro quema! Espera a que se enfríe");
                }
                break;
            case "D3":
                if (!v.pl.onGround && !v.floatUsed) { v.floatUsed = true; v.pl.vy = Math.min(v.pl.vy, -8); }
                break;
        }
    }

    /** Las ondas del jugador pueden chocar con cosas de la sala (enjambre, barricadas, gongs...). true = la onda se gasta. */
    static boolean shotHook(EcoView v, EcoView.Shot s) {
        if (!v.fightActive) return false;
        for (float[] z : v.silence) if (Math.hypot(s.x - z[0], s.y - z[1]) < z[2]) return true;
        EcoView.Enemy e = v.mainBoss();
        if (e == null || e.bdef == null) return false;
        switch (e.bdef.id) {
            case "B7":
                if (e.aux4 <= 0) for (int i = 2; i <= 11; i++) {
                    float sx = cx(e) + (float) Math.cos(e.aux3) * i * 0.6f, sy = cy(e) + (float) Math.sin(e.aux3) * i * 0.6f;
                    if (GameKit.overlap(s.x, s.y, s.w, s.h, sx - 0.3f, sy - 0.3f, 0.6f, 0.6f)) {
                        e.aux4 = 2.5f;
                        e.say = "¡Mi enjambre!"; e.sayT = 1;
                        v.chip.sfx(Chip.SFX_HIT);
                        return true;
                    }
                }
                return false;
            case "B5": case "B10":
                for (float[] g : v.gongs)
                    if (GameKit.overlap(s.x, s.y, s.w, s.h, g[0] - 0.5f, g[1] - 0.6f, 1, 1.6f)) {
                        if (e.bdef.id.equals("B10") && g[2] <= 0) {
                            g[2] = 6;
                            v.stalactites.add(new float[]{cx(e), 1.1f, 0});
                            v.chip.sfx(Chip.SFX_DOOR);
                            v.say("⚙ ¡GONG! Los engranajes del techo se sueltan...");
                        }
                        g[3] = 0.3f;
                        return e.bdef.id.equals("B10");
                    }
                return false;
            case "B16":
                for (Iterator<float[]> it = v.barricades.iterator(); it.hasNext(); ) {
                    float[] bq = it.next();
                    if (GameKit.overlap(s.x, s.y, s.w, s.h, bq[0], bq[1], bq[2], bq[3])) {
                        bq[4]++;
                        v.chip.sfx(Chip.SFX_HIT);
                        if (bq[4] >= 3) {
                            it.remove();
                            v.shake = 0.3f;
                            if (Math.abs(cx(e) - (bq[0] + bq[2] / 2)) < 3.2f) {
                                v.damageBoss(e, e.maxHp * 0.1f);
                                e.stun = 2f;
                                e.say = "¡Mi obra maestra!"; e.sayT = 1.2f;
                            }
                        }
                        return true;
                    }
                }
                return false;
            case "D2":
                for (EcoView.Shot o : v.shots)
                    if (!o.mine && !o.dead && o.kind == EcoView.SH_ORB && GameKit.overlap(s.x, s.y, s.w, s.h, o.x, o.y, o.w, o.h)) {
                        o.dead = true;
                        v.heat = Math.max(0, v.heat - 8);
                        v.float_("💨", o.x, o.y, Color.LTGRAY);
                    }
                return false;
        }
        return false;
    }

    // ---------------- hormigas soldado de la Reina Nodriza ----------------
    static void ant(EcoView v, EcoView.Enemy e, float dt) {
        if (e.state == 9) {            // confundida: va a por la reina
            EcoView.Enemy q = e.partner;
            if (q == null || q.dead) { v.walker(e, 2.2f, dt); return; }
            e.dir = Math.signum(cx(q) - cx(e));
            e.b.vx = e.dir * 3.2f;
            e.b.vy += EcoView.GRAV * dt;
            v.moveBody(e.b, dt, true);
            if (GameKit.overlap(e.b.x, e.b.y, e.b.w, e.b.h, q.b.x, q.b.y, q.b.w, q.b.h)) {
                v.damageBoss(q, q.maxHp * 0.06f);
                q.say = "¡Traidora!"; q.sayT = 0.8f;
                e.dead = true;
            }
            return;
        }
        e.dir = Math.signum(px(v) - cx(e)) == 0 ? e.dir : Math.signum(px(v) - cx(e));
        e.b.vx = e.dir * e.kind.speed;
        e.b.vy += EcoView.GRAV * dt;
        v.moveBody(e.b, dt, true);
    }

    /** true si la hormiga se confunde en vez de recibir daño (le diste por delante, en su escudo). */
    static boolean antHit(EcoView v, EcoView.Enemy e) {
        if (e.state == 9) return false;
        if (Math.signum(px(v) - cx(e)) == e.dir) {
            e.state = 9;
            e.flash = 0.2f;
            v.float_("?", cx(e), e.b.y - 0.3f, Color.YELLOW);
            return true;
        }
        return false;
    }

    // =====================================================================
    // Dibujo de los elementos especiales (en coordenadas de la sala)
    // =====================================================================
    static void draw(EcoView v, Canvas c, Paint p) {
        for (float[] z : v.silence) {
            p.setColor(Color.argb(70, 20, 40, 10));
            c.drawCircle(z[0], z[1], z[2], p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.06f);
            p.setColor(Color.argb(140, 120, 200, 80));
            c.drawCircle(z[0], z[1], z[2], p);
            p.setStyle(Paint.Style.FILL);
        }
        for (float[] s : v.statics) {
            p.setColor(s[4] == 1 ? Color.argb(200, 40, 25, 15) : Color.argb(150, 220, 220, 255));
            c.drawRect(s[0], s[1], s[0] + s[2], s[1] + 0.4f, p);
            if (s[4] == 0 && v.rnd.nextFloat() < 0.5f) { p.setColor(Color.WHITE); float sx = s[0] + v.rnd.nextFloat() * s[2]; c.drawRect(sx, s[1] - 0.2f, sx + 0.08f, s[1] - 0.12f, p); }
        }
        for (float[] bq : v.barricades) {
            p.setColor(Color.rgb(140, 90, 40));
            float sh = bq[4] > 0 ? (v.rnd.nextFloat() - 0.5f) * 0.08f * bq[4] : 0;
            c.drawRect(bq[0] + sh, bq[1], bq[0] + bq[2] + sh, bq[1] + bq[3], p);
            p.setColor(Color.rgb(90, 55, 25));
            for (float y = bq[1] + 0.4f; y < bq[1] + bq[3]; y += 0.8f) c.drawRect(bq[0] + sh, y, bq[0] + bq[2] + sh, y + 0.12f, p);
        }
        EcoView.Enemy e = v.mainBoss();
        String id = e != null && e.bdef != null ? e.bdef.id : "";
        for (float[] g : v.gongs) {
            boolean stone = id.equals("B5");
            p.setColor(stone ? Color.rgb(120, 140, 110) : Color.rgb(200, 150, 60));
            if (stone) c.drawOval(g[0] - 0.6f, g[1] - 0.6f, g[0] + 0.6f, g[1] + 0.6f, p);
            else { c.drawCircle(g[0], g[1] - 0.2f, 0.55f, p); p.setColor(Color.rgb(90, 70, 40)); c.drawRect(g[0] - 0.08f, g[1] + 0.3f, g[0] + 0.08f, g[1] + 0.9f, p); }
            if (g[3] > 0 || (stone && ((int) (v.playTime * 2)) % 2 == 0)) {
                p.setColor(Color.argb(90, 255, 255, 200));
                c.drawCircle(g[0], g[1] - 0.2f, 1.1f, p);
            }
            if (g[3] > 0) g[3] -= 0.016f;
        }
        for (float[] s : v.stalactites) {
            p.setColor(id.equals("B10") ? Color.rgb(180, 160, 120) : Color.rgb(170, 160, 150));
            if (id.equals("B10")) c.drawCircle(s[0], s[1], 0.55f, p);
            else c.drawRect(s[0] - 0.2f, s[1], s[0] + 0.2f, s[1] + 0.8f, p);
        }
        if (e == null || e.bdef == null) return;
        switch (id) {
            case "B3":
                if (e.shield > 0) {
                    p.setColor(Color.argb((int) (60 + e.shield), 200, 240, 255));
                    c.drawRoundRect(e.b.x - 0.2f, e.b.y - 0.2f, e.b.x + e.b.w + 0.2f, e.b.y + e.b.h + 0.1f, 0.4f, 0.4f, p);
                }
                break;
            case "B4":
                if (e.aux4 <= 0) {
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.08f);
                    p.setColor(e.winT > 0 ? Color.argb(230, 255, 255, 120) : Color.argb(150, 120, 190, 255));
                    c.drawOval(e.b.x - 0.4f, e.b.y - 0.4f, e.b.x + e.b.w + 0.4f, e.b.y + e.b.h + 0.2f, p);
                    p.setStyle(Paint.Style.FILL);
                }
                break;
            case "B6": {
                p.setColor(Color.rgb(120, 160, 50));
                c.drawRect(1, e.aux3, W - 1, H - 1, p);
                p.setColor(Color.rgb(80, 110, 30));
                for (float x = 1.5f; x < W - 1; x += 1.4f) c.drawCircle(x, e.aux3 + 0.3f, 0.55f, p);
                break;
            }
            case "B7":
                if (e.aux4 <= 0) for (int i = 2; i <= 11; i++) {
                    float sx = cx(e) + (float) Math.cos(e.aux3) * i * 0.6f, sy = cy(e) + (float) Math.sin(e.aux3) * i * 0.6f;
                    p.setColor(i % 2 == 0 ? Color.rgb(250, 200, 40) : Color.rgb(40, 30, 10));
                    c.drawCircle(sx + (float) Math.sin(v.playTime * 30 + i) * 0.1f, sy, 0.22f, p);
                }
                break;
            case "B13":
                if (v.sonarT > 0) {
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.1f);
                    p.setColor(Color.argb((int) (255 * v.sonarT / 0.8f), 255, 255, 255));
                    c.drawCircle(cx(e), cy(e), 1.5f + (0.8f - v.sonarT) * 3, p);
                    p.setStyle(Paint.Style.FILL);
                }
                break;
            case "B18":
                if (e.aux4 > 0) {
                    p.setColor(Color.argb(120, 120, 200, 255));
                    c.drawOval(e.b.x - 0.5f, e.b.y - 0.5f, e.b.x + e.b.w + 0.5f, e.b.y + e.b.h + 0.3f, p);
                    p.setColor(Color.WHITE);
                    for (int i = 0; i < 4; i++) { float sx = e.b.x + v.rnd.nextFloat() * e.b.w, sy = e.b.y - 0.3f + v.rnd.nextFloat() * e.b.h; c.drawRect(sx, sy, sx + 0.12f, sy + 0.12f, p); }
                }
                break;
            case "D1":
                p.setColor(Color.rgb(90, 60, 30));
                c.drawRect(W - 2.2f, 1, W - 1, H - 1, p);
                break;
            case "B20":
                if (e.aux3 > 0) {            // el capullo se abre
                    p.setColor(Color.argb(200, 255, 255, 230));
                    c.drawCircle(cx(e), cy(e), 0.7f + e.aux3, p);
                }
                if (e.role == 1) {
                    p.setColor(Color.argb(60 + (int) (40 * Math.sin(v.playTime * 9)), 255, 255, 220));
                    c.drawCircle(cx(e), cy(e), 2.4f, p);
                }
                break;
        }
    }

    /** Capas sobre la pantalla (niebla, polvo, ruido blanco, latidos, calor). */
    static void drawOverlay(EcoView v, Canvas c, Paint p) {
        EcoView.Enemy e = v.mainBoss();
        float rx = v.ox, ry = v.oy, rw = EcoWorld.W * v.T, rh = EcoWorld.H * v.T;
        if (v.fog) {
            p.setColor(Color.argb(150, 190, 200, 215));
            c.drawRect(rx, ry, rx + rw, ry + rh, p);
            if (e != null && v.sonarT > 0) {
                p.setColor(Color.argb((int) (220 * v.sonarT), 255, 255, 255));
                c.drawCircle(rx + cx(e) * v.T, ry + cy(e) * v.T, 26, p);
            }
        }
        if (e != null && e.bdef != null && e.bdef.id.equals("B14")) {
            int n = 0;
            for (EcoView.Shot s : v.shots) if (s.kind == EcoView.SH_DUST && !s.dead) n++;
            p.setColor(Color.argb(Math.min(150, n * 8), 80, 50, 90));
            c.drawRect(rx, ry, rx + rw, ry + rh, p);
        }
        if (v.ringT > 0) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
            p.setColor(Color.argb((int) (255 * v.ringT / 0.35f), 255, 240, 180));
            c.drawCircle(rx + px(v) * v.T, ry + py(v) * v.T, (3.5f - v.ringT * 6) * v.T, p);
            p.setStyle(Paint.Style.FILL);
        }
        if (v.canto) {
            for (int i = 0; i < 160; i++) {
                p.setColor(Color.argb(60, 255, 255, 255));
                float x = rx + v.rnd.nextFloat() * rw, y = ry + v.rnd.nextFloat() * rh;
                c.drawRect(x, y, x + 2, y + 2, p);
            }
            float ph = v.beatT % 0.65f;
            float s = ph < 0.12f ? 1.4f : 1f;
            v.text(c, "♥", v.vw / 2, ry + rh - 20, 30 * s, Color.rgb(255, 90, 120));
            v.text(c, "Repica 🔔 al ritmo del corazón · " + (int) v.beatMeter + "/6", v.vw / 2, ry + 18, 12, Color.WHITE);
        }
        if (e != null && e.bdef != null && e.bdef.id.equals("D2")) {
            float w = 120;
            p.setColor(Color.argb(170, 0, 0, 0));
            c.drawRect(v.vw / 2 - w / 2 - 2, ry + 4, v.vw / 2 + w / 2 + 2, ry + 14, p);
            p.setColor(v.heat > 80 ? Color.rgb(255, 60, 40) : Color.rgb(255, 160, 60));
            c.drawRect(v.vw / 2 - w / 2, ry + 6, v.vw / 2 - w / 2 + w * Math.min(1, v.heat / 100f), ry + 12, p);
            v.text(c, "🔥 calor del cencerro", v.vw / 2, ry + 26, 10, Color.WHITE);
        }
        if (v.muteT > 0) v.text(c, "🔇 ¡Cencerro silenciado!", v.vw / 2, ry + rh - 8, 13, Color.rgb(200, 200, 255));
        if (v.invertT > 0) v.text(c, "🌀 Hipnotizada", v.vw / 2, ry + rh - 24, 12, Color.rgb(230, 180, 255));
    }
}
