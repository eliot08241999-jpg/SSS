package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Sección Adicionales: documentos, biblioteca, gestor de archivos y visor 3D. */
public class AdditionalActivity extends NeonActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("ADICIONALES");
        card(col, "📄 DOCUMENTOS", "Lee, edita y convierte PDF, EPUB, DOCX y TXT. Crea documentos nuevos.", DocsActivity.class);
        card(col, "📚 BIBLIOTECA", "Tus libros elegidos, con la página donde te quedaste y lectura en voz alta.", LibraryActivity.class);
        card(col, "🗂 GESTOR DE ARCHIVOS", "Explora tu teléfono: copia, mueve, renombra, borra, comprime y descomprime ZIP/RAR.", FilesActivity.class);
        card(col, "🧊 VISOR 3D", "Abre modelos STL, OBJ, FBX, GLB y VRM, gíralos con el dedo, haz zoom y conviértelos entre formatos.", Model3DActivity.class);
    }

    void card(LinearLayout col, String title, String desc, Class<?> target) {
        LinearLayout c = panel(null);
        c.addView(neonText(title, 19));
        TextView d = text(desc, 13);
        d.setTextColor(Color.rgb(170, 180, 200));
        d.setPadding(0, dpi(4), 0, 0);
        c.addView(d);
        c.setClickable(true);
        c.setOnClickListener(v -> startActivity(new Intent(this, target)));
        col.addView(c, gapBelow(14));
    }
}
