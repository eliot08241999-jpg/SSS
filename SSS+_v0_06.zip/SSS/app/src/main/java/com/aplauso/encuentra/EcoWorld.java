package com.aplauso.encuentra;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * El mundo de EL PASTOR DE ECOS: las 18 salas originales (hechas a mano) y el resto de Lanaria,
 * generado SIEMPRE IGUAL a partir de un plano y una semilla fija (como un mapa dibujado a mano).
 *
 * Cada sala mide 30 x 16 casillas. Leyenda de casillas:
 *  # muro  . aire  = plataforma (se atraviesa desde abajo)  ^ pinchos  F pared falsa (secreto)
 *  G reja (se abre con ecos o una bandera)  B puerta de jefe  K puerta de mazmorra (llave)  X puerta carmesí (llave carmesí)
 * Apariciones: @ inicio  S fardo  T Topo Abuelo  O Sabelotodo  M Agente Garduña (policía)  P Sapo Mercader  H Herrera
 *  Q Fantasma  s b e m z v criaturas  % criatura (data = id)  ! jefe (data = id)  c cofre  o mineral  k corderito
 *  w Trompeta  j botas  A habilidad (data)  E emblema (data)  Y cadáver vampírico con las Garras  ~ plataforma móvil
 *  1 Rey Topo Loco  2 Vagoneta Fantasma  3 Murciégalo Gemelo
 * Salidas (izquierda, derecha, arriba, abajo).
 */
public class EcoWorld {
    static final int W = 30, H = 16;
    static final int Z_PRADERA = 0, Z_MINAS = 1;

    static class Spawn {
        char ch;
        int x, y, idx;
        String data = "";
    }

    static class Room {
        int gx, gy, zone;
        String name, gateFlag = "";
        char[] exits;          // L R U D
        boolean safe, boss, hidden, generated;
        int dungeon;           // 1..7: mazmorra secreta
        char lair;             // h a s f: guaridas vampíricas · x: castillo
        float dist;            // distancia al inicio (dificultad)
        Chip.Song music;
        char[][] t = new char[H][W];
        final List<Spawn> spawns = new ArrayList<>();

        String key() { return gx + "_" + gy; }
        boolean has(char c) { for (Spawn s : spawns) if (s.ch == c) return true; return false; }
        Spawn find(char c) { for (Spawn s : spawns) if (s.ch == c) return s; return null; }
        String bossId() {
            for (Spawn s : spawns) {
                if (s.ch == '!') return s.data;
                if (s.ch == '1' || s.ch == '2' || s.ch == '3') return String.valueOf(s.ch);
            }
            return null;
        }
    }

    static final List<Room> ROOMS = new ArrayList<>();
    static final Map<String, Room> BY_KEY = new HashMap<>();

    static Room at(int gx, int gy) { return BY_KEY.get(gx + "_" + gy); }

    static void add(Room r) {
        r.dist = (float) Math.hypot(r.gx, r.gy);
        ROOMS.add(r);
        BY_KEY.put(r.key(), r);
    }

    static Room room(int gx, int gy, int zone, String name, String exits, Chip.Song music, String... rows) {
        Room r = new Room();
        r.gx = gx; r.gy = gy; r.zone = zone; r.name = name; r.music = music;
        r.exits = exits.toCharArray();
        int idx = 0;
        for (int y = 0; y < H; y++) {
            String row = y < rows.length ? rows[y] : "";
            for (int x = 0; x < W; x++) {
                char ch = x < row.length() ? row.charAt(x) : '.';
                if (y == 0 || y == H - 1 || x == 0 || x == W - 1) ch = '#';
                if ("#.=^F".indexOf(ch) < 0) {
                    Spawn s = new Spawn();
                    s.ch = ch; s.x = x; s.y = y; s.idx = idx++;
                    r.spawns.add(s);
                    ch = '.';
                }
                r.t[y][x] = ch;
            }
        }
        carveExits(r);
        add(r);
        return r;
    }

    static void carveExits(Room r) {
        carve(r, r.exits[0], 0, 12, 0, 14);
        carve(r, r.exits[1], W - 1, 12, W - 1, 14);
        carve(r, r.exits[2], 13, 0, 16, 0);
        carve(r, r.exits[3], 13, H - 1, 16, H - 1);
    }

    private static void carve(Room r, char spec, int x0, int y0, int x1, int y1) {
        if (spec == '#') return;
        for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) r.t[y][x] = spec;
        if (spec == 'B') r.boss = true;
    }

    static final String FULL = "##############################";
    static final String OPEN = "#............................#";

    static {
        // ======================= PRADERA HUNDIDA =======================
        room(0, 0, Z_PRADERA, "Pradera Hundida · Inicio", "..##", Songs.PRADERA,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#....................c.......#",
                "#..................=====.....#",
                OPEN, OPEN,
                "#.............=====..........#",
                OPEN,
                "#.@..S.....T............O....#",
                FULL);

        room(1, 0, Z_PRADERA, "Prados del Eco", "..#.", Songs.PRADERA,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#......b.....................#",
                OPEN,
                "#..........======............#",
                OPEN,
                "#....===..............===....#",
                OPEN,
                "#.........===....===.........#",
                "#...s................s.......#",
                FULL);

        room(2, 0, Z_PRADERA, "Colinas Calladas", "..##", Songs.PRADERA,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#..........b.................#",
                OPEN,
                "#.................=====......#",
                OPEN,
                "#..........=====.............#",
                "#.......................e....#",
                "#......................####..#",
                "#.....###..............####..#",
                "#.....###.....s........####..#",
                FULL);

        Room ref1 = room(3, 0, Z_PRADERA, "Refugio de la Pradera", "..#.", Songs.PUEBLO,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#.........===....===.........#",
                "#....S....................M..#",
                FULL);
        ref1.safe = true;

        room(0, 1, Z_PRADERA, "Cueva Secreta", "#.##", Songs.PRADERA,
                FULL, FULL, FULL, FULL, FULL, FULL, FULL,
                "#####......................###",
                "####........................##",
                "###..........................#",
                "##...........====............#",
                OPEN,
                "#.....k......................#",
                "#....###.....................#",
                "#....###..........c..........#",
                FULL);

        Room pueblo = room(1, 1, Z_PRADERA, "Eco Hondo (pueblo)", "F..G", Songs.PUEBLO,
                FULL, OPEN, OPEN,
                "#...........======...........#",
                OPEN, OPEN,
                "#.....=====..................#",
                OPEN, OPEN,
                "#.........====.......====....#",
                OPEN, OPEN,
                "#...=====..........=====.....#",
                "#.........===....===.........#",
                "#.S...P...H.............M....#",
                FULL);
        pueblo.safe = true;
        pueblo.gateFlag = "boss1";

        room(2, 1, Z_PRADERA, "Pozo de Raíces", "..##", Songs.PRADERA,
                FULL, OPEN,
                "#...........o................#",
                "#..........====..............#",
                OPEN, OPEN,
                "#.....====..........====.....#",
                OPEN,
                "#...b.......................b#",
                "#..........=====.............#",
                OPEN,
                "#...................e........#",
                "#....====...........=====....#",
                OPEN,
                "#..s......^^^^...........s...#",
                FULL);

        room(3, 1, Z_PRADERA, "Antesala del Topo", "...#", Songs.PRADERA,
                FULL, OPEN, OPEN,
                "#...........======...........#",
                OPEN, OPEN,
                "#....=====...................#",
                "#....................b.......#",
                OPEN,
                "#........=====.......=====...#",
                OPEN, OPEN,
                "#...=====..........=====.....#",
                OPEN,
                "#.......s.............e......#",
                FULL);

        room(4, 1, Z_PRADERA, "Guarida del Rey Topo", "B###", Songs.BOSS,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#.....====..........====.....#",
                OPEN,
                "#...................1........#",
                FULL);

        // ======================= MINAS DE COBRE =======================
        room(1, 2, Z_MINAS, "Entrada de las Minas", "...#", Songs.MINAS,
                FULL, OPEN, OPEN,
                "#...........======...........#",
                OPEN, OPEN,
                "#.......=====................#",
                OPEN, OPEN,
                "#.............=====..........#",
                OPEN, OPEN,
                "#........=====...............#",
                OPEN,
                "#...O.........................",
                FULL);

        room(2, 2, Z_MINAS, "Galería de Cobre", "..#.", Songs.MINAS,
                FULL, OPEN, OPEN, OPEN, OPEN,
                "#.....v...............v......#",
                OPEN,
                "#...........~................#",
                OPEN,
                "#....=====...........=====...#",
                OPEN,
                "#...z..................z.....#",
                OPEN,
                "#.........===....===.........#",
                "#...m.................m......#",
                FULL);

        Room ref2 = room(3, 2, Z_MINAS, "Refugio Minero", "..##", Songs.PUEBLO,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#...=====............=====...#",
                OPEN,
                "#.....S.............M........#",
                FULL);
        ref2.safe = true;

        room(4, 2, Z_MINAS, "Pozo Minero", "..##", Songs.MINAS,
                FULL, OPEN,
                "#.............o..............#",
                "#............====............#",
                OPEN, OPEN,
                "#.......====.........====....#",
                OPEN, OPEN,
                "#...........=====............#",
                OPEN,
                "#....v..................v....#",
                "#...=====...........=====....#",
                OPEN,
                "#..m..........z..........m...#",
                FULL);

        room(5, 2, Z_MINAS, "Nido Gemelo", "B###", Songs.BOSS,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#..............3.............#",
                OPEN, OPEN,
                "#..........========..........#",
                OPEN, OPEN,
                "#....=====..........=====....#",
                OPEN, OPEN,
                FULL);

        room(2, 3, Z_MINAS, "Minas Profundas", "F...", Songs.MINAS,
                FULL, OPEN, OPEN, OPEN,
                "#...........======...........#",
                OPEN, OPEN, OPEN,
                "#.....=====..........=====....#",
                OPEN,
                "#.......................z....#",
                OPEN,
                "#.........=====..............#",
                OPEN,
                "#..j......m..................#",
                FULL);

        room(1, 3, Z_MINAS, "Cámara de Brasas", "#.##", Songs.MINAS,
                FULL, FULL, FULL, FULL, FULL, FULL,
                "####......................####",
                "###........................###",
                "##..........................##",
                OPEN, OPEN,
                "#.........====...............#",
                OPEN, OPEN,
                "#.....w..........o...........#",
                FULL);

        room(3, 3, Z_MINAS, "Raíles Olvidados", "..##", Songs.MINAS,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#..............o.............#",
                "#............=====...........#",
                OPEN, OPEN,
                "#.....=====.........=====....#",
                "#....................z.......#",
                OPEN, OPEN,
                "#....Q........m..............#",
                FULL);

        Room vag = room(4, 3, Z_MINAS, "Túnel de la Vagoneta", "BG##", Songs.BOSS,
                FULL, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN, OPEN,
                "#......====........====......#",
                OPEN, OPEN,
                "#..............2.............#",
                FULL);
        vag.gateFlag = "boss2";

        // las salas de la izquierda/derecha de "Minas Profundas" y del pueblo usan paredes falsas
        // (F en la salida); su vecina tiene la salida abierta para poder volver.
    }

    // =====================================================================
    // PLANO DE LANARIA (cada letra es una sala; '.' = roca)
    //  o salas originales  L Lago  H Hongos  J Jardín  C Ciudad  K Cristal  V Viento  R Cementerio
    //  A Colmena  W Cloacas  N Nido  Z Abismo  X Castillo Carmesí
    //  1-7 mazmorras secretas (llave)  h a s f guaridas vampíricas (llave carmesí)
    // =====================================================================
    static final String[] LAYOUT = {
            "........VVVV.........KKKK......XXX..",  // gy -5
            ".......VV..VV.......KK..KK....XX....",
            "...JJ.VV....V......KK....KKKKXX.....",
            "..JJ..V.....VV....KK..77.K..........",
            "..J...VVV..VVV...KK...77KK..........",
            "ffJ..JJ.V..VooooKKKKKKKK..RRRRR.....",  // gy 0
            "f.JJJJ..V...ooooo....K...RR...RR....",
            "ffJ.11..HHHHHooooo.LLLLL.R..55RR....",
            "..JJ11.HHH.H.ooooLLL...LLRR..5RRsss.",
            "...JJHHH.HH...C.......LL..RRRRR..s..",
            "....HHH...HCCCCCCC..LLLL....A.......",  // gy 5
            ".NNNH.22..HC...C.CC....L...AAA.44...",
            ".N..NN2NNNCC.aaC..CCCC...WWAAAAA4...",
            ".N33.NNN..C...aC....C.WWWW.AA..A....",
            ".N3...N...CCCCCC....WWWW.WWWW..A....",
            ".NNNNNNN......W..WWWW..WW...WWW.....",  // gy 10
            "....hhhN......WWWW..W...ZZ..........",
            ".......N...........ZZZZZZ...........",
            "......NNN66........Z....ZZ..........",
            ".........6.........ZZZZZZZ..........",
    };
    static final int LX = 12, LY = 5;
    static final long SEED = 0x5A5A2026L;
    static final int[][] DIRS = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
    static final int[] OPP = {1, 0, 3, 2};

    static int zoneOfChar(char c) {
        switch (c) {
            case 'L': return EcoData.Z_LAGO;
            case 'H': case '2': return EcoData.Z_HONGOS;
            case 'J': case '1': case 'f': return EcoData.Z_JARDIN;
            case 'C': return EcoData.Z_CIUDAD;
            case 'K': case '7': return EcoData.Z_CRISTAL;
            case 'V': return EcoData.Z_VIENTO;
            case 'R': case '5': return EcoData.Z_CEMENTERIO;
            case 'A': case '4': return EcoData.Z_COLMENA;
            case 'W': return EcoData.Z_CLOACAS;
            case 'N': case '3': case '6': return EcoData.Z_NIDO;
            case 'Z': return EcoData.Z_ABISMO;
            default: return EcoData.Z_CASTILLO;   // X h a s
        }
    }

    static boolean isNormalZone(char c) { return "LHJCKVRAWNZ".indexOf(c) >= 0; }
    static boolean isDungeon(char c) { return c >= '1' && c <= '7'; }
    static boolean isLair(char c) { return "hasf".indexOf(c) >= 0; }

    // ---- jefes de cada zona (en orden de distancia a la entrada) ----
    static String[] bossesOf(char c) {
        switch (c) {
            case 'L': return new String[]{"B3", "B4"};
            case 'H': return new String[]{"B5", "B6"};
            case 'J': return new String[]{"B7"};
            case 'C': return new String[]{"B8", "B9"};
            case 'K': return new String[]{"B10", "B11"};
            case 'V': return new String[]{"B12"};
            case 'R': return new String[]{"B13", "B14"};
            case 'A': return new String[]{"B15"};
            case 'W': return new String[]{"B16"};
            case 'N': return new String[]{"B17", "B18"};
            case 'Z': return new String[]{"B19", "B20"};
            case 'X': return new String[]{"V5"};
            case 'h': return new String[]{"V1"};
            case 'a': return new String[]{"V2"};
            case 's': return new String[]{"V4"};
            case 'f': return new String[]{"V3"};
            default: return new String[]{"D" + c};
        }
    }

    static final String[][] SUBNAMES = {
            {}, {},
            {"Orilla Helada", "Témpanos", "Gruta Azul", "Puente de Hielo", "Lago Dormido", "Cascada Congelada", "Cueva de Escarcha", "Hielo Fino"},
            {"Sombrerillos", "Claro de Esporas", "Tallo Gigante", "Cueva Húmeda", "Anillo de Setas", "Raíces Viejas", "Bosque Bajo"},
            {"Zarzal", "Rosaleda", "Muros Verdes", "Laberinto de Espinas", "Invernadero Roto", "Senda de Pétalos"},
            {"Calle del Farol", "Plaza Mojada", "Canal Viejo", "Torre del Reloj", "Barrio Hundido", "Mercado Vacío", "Puerta de la Lluvia"},
            {"Veta Rosa", "Pico Brillante", "Mina de Cuarzo", "Salón de Espejos", "Grieta Violeta", "Cima Helada", "Cristalera"},
            {"Cornisa", "Paso del Viento", "Nido de Cuervos", "Peñasco", "Mirador", "Cumbre Ventosa"},
            {"Hilera de Tumbas", "Campanario", "Cripta", "Jardín de Lápidas", "Capilla Rota", "Osario"},
            {"Panal", "Celdas Doradas", "Galería de Miel", "Sala de la Cera", "Zumbadero"},
            {"Alcantarilla", "Colector", "Tubería Mayor", "Canal de Lodo", "Compuertas", "Desagüe"},
            {"Telaraña", "Galería Oscura", "Madriguera", "Hilos Colgantes", "Cámara de Huevos", "Túnel Estrecho"},
            {"Borde del Silencio", "Vacío", "Escalera Rota", "Fondo del Mundo", "Mar de Sombras"},
            {"Gran Salón", "Pasillo de Retratos", "Biblioteca Roja", "Torreón", "Bodega", "Capilla Carmesí"},
    };

    static final String[] LAIR_NAMES = {"Guarida de Harold", "Salón de los Espejos de Aloii", "Cuarto de Juegos de Sangre Joven", "Ruinas Antiguas"};

    // =====================================================================
    // GENERADOR
    // =====================================================================
    static class Generator {
        static final int R_NORMAL = 0, R_REFUGE = 1, R_BOSS = 2, R_CORPSE = 3;

        static final Map<String, Character> cell = new LinkedHashMap<>();
        static final Map<String, char[]> ex = new HashMap<>();
        static final Map<String, String> gates = new HashMap<>();
        static final Map<String, Integer> role = new HashMap<>();
        static final Map<String, String> bossOf = new HashMap<>();
        static final Map<String, List<Spawn>> extra = new HashMap<>();
        static final Set<String> linkCells = new HashSet<>();
        static final List<String> entryOrder = new ArrayList<>();

        static String k(int x, int y) { return x + "_" + y; }
        static int kx(String k) { return Integer.parseInt(k.substring(0, k.indexOf('_'))); }
        static int ky(String k) { return Integer.parseInt(k.substring(k.indexOf('_') + 1)); }

        static char[] exitsOf(String key) {
            char[] e = ex.get(key);
            if (e == null) { e = new char[]{'#', '#', '#', '#'}; ex.put(key, e); }
            return e;
        }

        static int tierOf(char c) {
            if (c == 'X') return 99;
            if (isNormalZone(c)) return EcoData.ZONES[zoneOfChar(c)].tier;
            return 0;
        }

        /** Une dos celdas vecinas (a -> dirección d -> b). */
        static void link(String a, String b, int d, char onA, char onB) {
            if (cell.containsKey(a)) exitsOf(a)[d] = onA;
            if (cell.containsKey(b)) exitsOf(b)[OPP[d]] = onB;
        }

        static void addGate(String key, int d, char zc) {
            int t = tierOf(zc);
            exitsOf(key)[d] = 'G';
            gates.put(key, zc == 'X' ? "vamp4" : "e:" + t);
        }

        static void build() {
            Random rnd = new Random(SEED);
            for (int row = 0; row < LAYOUT.length; row++)
                for (int col = 0; col < LAYOUT[row].length(); col++) {
                    char c = LAYOUT[row].charAt(col);
                    if (c == '.' || c == 'o') continue;
                    cell.put(k(col - LX, row - LY), c);
                }

            // ---- 1) enlaces con las salas originales ----
            int[][] forced = {{0, 0, 0}, {3, 0, 1}, {1, 2, 0}, {2, 3, 3}, {4, 3, 1}};   // sala antigua + dirección
            for (int[] f : forced) {
                int nx = f[0] + DIRS[f[2]][0], ny = f[1] + DIRS[f[2]][1];
                String nk = k(nx, ny);
                char zc = cell.get(nk);
                linkCells.add(nk);
                entryOrder.add(nk);
                if (tierOf(zc) > (f[1] >= 2 ? 1 : 0)) addGate(nk, OPP[f[2]], zc);
                else exitsOf(nk)[OPP[f[2]]] = '.';
            }

            // ---- 2) un paso entre cada par de zonas vecinas ----
            Map<String, List<String[]>> pairs = new LinkedHashMap<>();
            for (Map.Entry<String, Character> e : cell.entrySet()) {
                char a = e.getValue();
                if (!isNormalZone(a) && a != 'X') continue;
                int x = kx(e.getKey()), y = ky(e.getKey());
                for (int d : new int[]{1, 3}) {     // derecha y abajo (cada par una vez)
                    String nk = k(x + DIRS[d][0], y + DIRS[d][1]);
                    Character b = cell.get(nk);
                    if (b == null || b == a || (!isNormalZone(b) && b != 'X')) continue;
                    if ((a == 'X') != (b == 'X') && !(a == 'K' || b == 'K')) continue;   // el castillo solo se une a Cristal
                    String pk = a < b ? a + "" + b : b + "" + a;
                    List<String[]> l = pairs.get(pk);
                    if (l == null) { l = new ArrayList<>(); pairs.put(pk, l); }
                    l.add(new String[]{e.getKey(), nk, String.valueOf(d)});
                }
            }
            for (List<String[]> l : pairs.values()) {
                int n = l.size() > 8 ? 2 : 1;
                Collections.shuffle(l, rnd);
                for (int i = 0; i < n && i < l.size(); i++) {
                    String a = l.get(i)[0], b = l.get(i)[1];
                    int d = Integer.parseInt(l.get(i)[2]);
                    char ca = cell.get(a), cb = cell.get(b);
                    linkCells.add(a); linkCells.add(b);
                    entryOrder.add(a); entryOrder.add(b);
                    link(a, b, d, '.', '.');
                    if (tierOf(cb) > tierOf(ca)) addGate(b, OPP[d], cb);
                    else if (tierOf(ca) > tierOf(cb)) addGate(a, d, ca);
                }
            }

            // ---- 3) grupos (zonas, mazmorras y guaridas) ----
            Map<Character, List<String>> groups = new LinkedHashMap<>();
            for (Map.Entry<String, Character> e : cell.entrySet()) {
                List<String> l = groups.get(e.getValue());
                if (l == null) { l = new ArrayList<>(); groups.put(e.getValue(), l); }
                l.add(e.getKey());
            }

            // ---- 4) puertas de mazmorras y guaridas ----
            Map<Character, String> entryOf = new HashMap<>();
            for (Map.Entry<Character, List<String>> g : groups.entrySet()) {
                char c = g.getKey();
                if (!isDungeon(c) && !isLair(c)) continue;
                List<String[]> opts = new ArrayList<>();
                for (String ck : g.getValue()) {
                    int x = kx(ck), y = ky(ck);
                    for (int d = 0; d < 4; d++) {
                        String nk = k(x + DIRS[d][0], y + DIRS[d][1]);
                        Character b = cell.get(nk);
                        if (b != null && isNormalZone(b)) opts.add(new String[]{ck, nk, String.valueOf(d)});
                    }
                }
                Collections.shuffle(opts, rnd);
                // preferimos puertas laterales (más fáciles de ver)
                String[] best = opts.get(0);
                for (String[] o : opts) if (Integer.parseInt(o[2]) < 2) { best = o; break; }
                int d = Integer.parseInt(best[2]);
                char door = isLair(c) ? 'X' : 'K';
                link(best[0], best[1], d, '.', door);
                linkCells.add(best[0]); linkCells.add(best[1]);
                entryOf.put(c, best[0]);
            }

            // ---- 5) árbol de cada grupo + jefes ----
            for (Map.Entry<Character, List<String>> g : groups.entrySet()) {
                char c = g.getKey();
                List<String> cells = g.getValue();
                Set<String> in = new HashSet<>(cells);
                // entradas
                List<String> entries = new ArrayList<>();
                for (String ck : entryOrder) if (in.contains(ck) && !entries.contains(ck)) entries.add(ck);
                if (entryOf.containsKey(c)) { entries.clear(); entries.add(entryOf.get(c)); }
                if (entries.isEmpty()) entries.add(cells.get(0));
                Map<String, Integer> dist = bfs(entries, in);

                String[] bosses = bossesOf(c);
                List<String> bossCells = new ArrayList<>();
                String corpse = null;
                if (c == 'f') {          // ruinas: sala del cadáver al fondo, la planta justo antes
                    corpse = farthest(cells, dist, new HashSet<String>(), in, entries);
                    in.remove(corpse);
                    String arena = null;
                    int bd = 1 << 20;
                    for (int d = 0; d < 4; d++) {
                        String nk = k(kx(corpse) + DIRS[d][0], ky(corpse) + DIRS[d][1]);
                        if (in.contains(nk) && dist.get(nk) < bd) { bd = dist.get(nk); arena = nk; }
                    }
                    bossCells.add(arena);
                } else {
                    Set<String> taken = new HashSet<>();
                    for (String b : bosses) {
                        String bc = farthest(cells, dist, taken, in, entries);
                        if (bc == null) break;
                        taken.add(bc);
                        bossCells.add(bc);
                        in.remove(bc);
                    }
                }
                for (int i = 0; i < bossCells.size(); i++) bossOf.put(bossCells.get(i), bosses[Math.min(i, bosses.length - 1)]);
                if (c != 'f') for (String bc : bossCells) in.add(bc);   // se vuelven a añadir como hojas

                // árbol aleatorio sin las salas de jefe
                Set<String> tree = new HashSet<>(in);
                for (String bc : bossCells) if (c != 'f') tree.remove(bc);
                if (c == 'f') tree.remove(bossCells.get(0));
                String start = entries.get(0);
                Set<String> seen = new HashSet<>();
                Deque<String> st = new ArrayDeque<>();
                seen.add(start); st.push(start);
                Set<String> edges = new HashSet<>();
                while (!st.isEmpty()) {
                    String cur = st.peek();
                    List<Integer> ds = new ArrayList<>();
                    for (int d = 0; d < 4; d++) ds.add(d);
                    Collections.shuffle(ds, rnd);
                    boolean moved = false;
                    for (int d : ds) {
                        String nk = k(kx(cur) + DIRS[d][0], ky(cur) + DIRS[d][1]);
                        if (tree.contains(nk) && !seen.contains(nk)) {
                            seen.add(nk); st.push(nk);
                            link(cur, nk, d, '.', '.');
                            edges.add(edgeKey(cur, nk));
                            moved = true;
                            break;
                        }
                    }
                    if (!moved) st.pop();
                }
                // pasillos extra (bucles)
                for (String a : tree)
                    for (int d = 1; d <= 3; d += 2) {
                        String b = k(kx(a) + DIRS[d][0], ky(a) + DIRS[d][1]);
                        if (tree.contains(b) && !edges.contains(edgeKey(a, b)) && rnd.nextFloat() < 0.28f) {
                            link(a, b, d, '.', '.');
                            edges.add(edgeKey(a, b));
                        }
                    }
                // salas de jefe: una sola puerta (preferimos de lado o desde arriba)
                for (String bc : bossCells) {
                    int[] order = {0, 1, 2, 3};
                    String parent = null;
                    int pd = -1;
                    for (int d : order) {
                        String nk = k(kx(bc) + DIRS[d][0], ky(bc) + DIRS[d][1]);
                        if (tree.contains(nk)) { parent = nk; pd = d; break; }
                    }
                    if (parent == null) continue;
                    link(bc, parent, pd, 'B', '.');
                    role.put(bc, R_BOSS);
                }
                if (corpse != null) {
                    String arena = bossCells.get(0);
                    for (int d = 0; d < 4; d++) {
                        String nk = k(kx(arena) + DIRS[d][0], ky(arena) + DIRS[d][1]);
                        if (tree.contains(nk)) { link(arena, nk, d, 'B', '.'); break; }
                    }
                    for (int d = 0; d < 4; d++) {
                        String nk = k(kx(corpse) + DIRS[d][0], ky(corpse) + DIRS[d][1]);
                        if (nk.equals(arena)) { link(corpse, arena, d, '.', 'B'); break; }
                    }
                    role.put(arena, R_BOSS);
                    role.put(corpse, R_CORPSE);
                }

                // ---- 6) refugios, Sabelotodo, habilidades y tesoros ----
                if (isNormalZone(c) || c == 'X') placeSpecials(c, cells, entries, dist, bossCells, rnd);
            }

            // ---- 7) construir las salas ----
            for (Map.Entry<String, Character> e : cell.entrySet()) makeRoom(e.getKey(), e.getValue());
        }

        static String edgeKey(String a, String b) { return a.compareTo(b) < 0 ? a + "|" + b : b + "|" + a; }

        static Map<String, Integer> bfs(List<String> from, Set<String> in) {
            Map<String, Integer> d = new HashMap<>();
            Deque<String> q = new ArrayDeque<>();
            for (String f : from) { d.put(f, 0); q.add(f); }
            while (!q.isEmpty()) {
                String cur = q.poll();
                for (int[] dd : DIRS) {
                    String nk = k(kx(cur) + dd[0], ky(cur) + dd[1]);
                    if (in.contains(nk) && !d.containsKey(nk)) { d.put(nk, d.get(cur) + 1); q.add(nk); }
                }
            }
            return d;
        }

        /** La celda más lejana que se puede quitar sin partir el grupo y que no es una entrada. */
        static String farthest(List<String> cells, Map<String, Integer> dist, Set<String> taken, Set<String> in, List<String> entries) {
            List<String> cand = new ArrayList<>(cells);
            Collections.sort(cand, (a, b) -> {
                int da = dist.containsKey(a) ? dist.get(a) : -1, db = dist.containsKey(b) ? dist.get(b) : -1;
                return da != db ? db - da : a.compareTo(b);
            });
            for (String c : cand) {
                if (taken.contains(c) || linkCells.contains(c) || !in.contains(c)) continue;
                boolean nextToBoss = false;      // dos jefes juntos dejarían a uno sin salida
                for (int[] dd : DIRS) if (taken.contains(k(kx(c) + dd[0], ky(c) + dd[1]))) nextToBoss = true;
                if (nextToBoss) continue;
                // que no quede nadie aislado
                Set<String> rest = new HashSet<>(in);
                rest.remove(c);
                if (bfs(entries.subList(0, 1), rest).size() != rest.size()) continue;   // todo unido desde la entrada
                // necesita un vecino del grupo
                boolean nb = false;
                for (int[] dd : DIRS) if (rest.contains(k(kx(c) + dd[0], ky(c) + dd[1]))) nb = true;
                if (nb) return c;
            }
            return null;
        }

        static void spawn(String key, char ch, String data) {
            List<Spawn> l = extra.get(key);
            if (l == null) { l = new ArrayList<>(); extra.put(key, l); }
            Spawn s = new Spawn();
            s.ch = ch; s.data = data;
            l.add(s);
        }

        static void placeSpecials(char c, List<String> cells, List<String> entries, Map<String, Integer> dist,
                                  List<String> bossCells, Random rnd) {
            Set<String> used = new HashSet<>(bossCells);
            // Sabelotodo en la primera entrada
            String sab = entries.get(0);
            if (c != 'X') { spawn(sab, 'O', ""); used.add(sab); }
            int maxD = 0;
            for (String ck : cells) if (dist.containsKey(ck)) maxD = Math.max(maxD, dist.get(ck));
            // refugio a media distancia
            String ref = null;
            int bestScore = 1 << 20;
            for (String ck : cells) {
                if (used.contains(ck) || !dist.containsKey(ck)) continue;
                int sc = Math.abs(dist.get(ck) - maxD / 2) * 10 + (linkCells.contains(ck) ? 5 : 0);
                if (sc < bestScore) { bestScore = sc; ref = ck; }
            }
            if (ref != null) {
                role.put(ref, R_REFUGE);
                used.add(ref);
                spawn(ref, 'M', "");
                String zs = String.valueOf(c);
                for (int i = 0; i < EcoData.SHOP_ZONE.length; i++) if (EcoData.SHOP_ZONE[i].equals(zs)) spawn(ref, 'P', String.valueOf(i));
            }
            // segundo refugio, junto al primer jefe, en zonas grandes
            if (cells.size() >= 16 && !bossCells.isEmpty()) {
                String bc = bossCells.get(0);
                char[] e = ex.get(bc);
                for (int d = 0; d < 4 && e != null; d++) {
                    if (e[d] == '#') continue;
                    String nk = k(kx(bc) + DIRS[d][0], ky(bc) + DIRS[d][1]);
                    if (cells.contains(nk) && !used.contains(nk) && !linkCells.contains(nk)) {
                        role.put(nk, R_REFUGE);
                        used.add(nk);
                        break;
                    }
                }
            }
            List<String> free = new ArrayList<>();
            for (String ck : cells) if (!used.contains(ck) && dist.containsKey(ck) && dist.get(ck) >= 1) free.add(ck);
            Collections.shuffle(free, rnd);
            String zs = String.valueOf(c);
            int fi = 0;
            for (String[] ab : EcoData.ABILITY_SPOTS) if (ab[1].equals(zs) && fi < free.size()) spawn(free.get(fi++), 'A', ab[0]);
            for (String[] em : EcoData.EMBLEM_SPOTS) if (em[1].equals(zs) && fi < free.size()) spawn(free.get(fi++), 'E', em[0]);
            if (fi < free.size()) spawn(free.get(fi++), 'o', "");
            if (fi < free.size() && cells.size() > 14) spawn(free.get(fi++), 'o', "");
        }

        // ------------------------------------------------------------------
        // Una sala
        // ------------------------------------------------------------------
        static void makeRoom(String key, char c) {
            Room r = new Room();
            r.gx = kx(key); r.gy = ky(key);
            r.generated = true;
            r.zone = zoneOfChar(c);
            r.exits = exitsOf(key).clone();
            r.gateFlag = gates.containsKey(key) ? gates.get(key) : "";
            if (isDungeon(c)) { r.dungeon = c - '0'; r.hidden = true; }
            if (isLair(c)) { r.lair = c; r.hidden = true; }
            if (c == 'X') r.lair = 'x';
            Random rnd = new Random(SEED ^ (r.gx * 73856093L) ^ (r.gy * 19349663L));
            int rl = role.containsKey(key) ? role.get(key) : R_NORMAL;
            r.safe = rl == R_REFUGE;
            r.music = EcoData.ZONES[r.zone].music;
            if (c == 'f') r.music = Songs.JARDIN;
            // nombre
            if (isLair(c)) r.name = LAIR_NAMES["hasf".indexOf(c)];
            else if (isDungeon(c)) r.name = "Mazmorra Secreta · " + EcoData.ZONES[r.zone].name;
            else if (rl == R_REFUGE) r.name = "Refugio · " + EcoData.ZONES[r.zone].name;
            else {
                String[] sn = SUBNAMES[r.zone];
                r.name = EcoData.ZONES[r.zone].name + " · " + sn[rnd.nextInt(sn.length)];
            }
            // terreno
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                    r.t[y][x] = (y == 0 || y == H - 1 || x == 0 || x == W - 1) ? '#' : '.';
            boolean up = r.exits[2] != '#', down = r.exits[3] != '#';
            List<int[]> plats = new ArrayList<>();
            String bossId = bossOf.get(key);
            if (rl == R_BOSS && bossId != null) arena(r, bossId, up, plats);
            else terrain(r, rnd, up, down, rl, plats);
            carveExits(r);
            if (rl == R_BOSS && bossId != null)
                r.name = (isLair(c) ? r.name : r.dungeon > 0 ? "Mazmorra Secreta" : EcoData.ZONES[r.zone].name) + " · " + EcoData.boss(bossId).name;

            // apariciones
            List<Spawn> sp = new ArrayList<>();
            if (rl == R_BOSS && bossId != null) {
                EcoData.Boss b = EcoData.boss(bossId);
                if (b.id.equals("V3")) sp.add(mk('!', bossId, 25, 8));
                else sp.add(mk('!', bossId, 15, b.flyer ? 6 : 14));
                if (isDungeon(c)) sp.add(mk('c', "big", 15, 14));
            } else if (rl == R_CORPSE) {
                sp.add(mk('Y', "", 20, 14));
            } else if (rl == R_REFUGE) {
                sp.add(mk('S', "", 5, 14));
            } else {
                enemies(r, rnd, c, sp, plats);
                if (rnd.nextFloat() < (isDungeon(c) ? 0.6f : 0.2f) && !plats.isEmpty()) {
                    int[] pl = top(plats);
                    sp.add(mk('c', isDungeon(c) ? "rich" : "", (pl[1] + pl[2]) / 2, pl[0] - 1));
                }
            }
            // extras (Sabelotodo, tiendas, tesoros...)
            List<Spawn> ext = extra.get(key);
            if (ext != null) {
                int[] npcXs = rl == R_REFUGE ? new int[]{9, 20, 24} : new int[]{22, 9, 25};   // nunca sobre el agujero del suelo
                int ni = 0;
                for (Spawn s : ext) {
                    switch (s.ch) {
                        case 'O': case 'M': case 'P':
                            s.x = npcXs[ni % npcXs.length]; ni++;
                            s.y = groundY(r, s.x);
                            break;
                        default: {    // en lo alto (premio por explorar)
                            if (!plats.isEmpty()) { int[] pl = top(plats); s.x = (pl[1] + pl[2]) / 2 + (s.ch == 'o' ? 1 : 0); s.y = pl[0] - 1; }
                            else { s.x = 22; s.y = groundY(r, 22); }
                        }
                    }
                    sp.add(s);
                }
            }
            int idx = 0;
            for (Spawn s : sp) { s.idx = idx++; r.spawns.add(s); }
            add(r);
            if (r.lair == 'x') r.hidden = true;
        }

        static Spawn mk(char ch, String data, int x, int y) {
            Spawn s = new Spawn();
            s.ch = ch; s.data = data; s.x = x; s.y = y;
            return s;
        }

        static int[] top(List<int[]> plats) {
            int[] best = plats.get(0);
            for (int[] p : plats) if (p[0] < best[0]) best = p;
            return best;
        }

        /** La casilla libre más baja de la columna (de pie sobre el suelo). */
        static int groundY(Room r, int x) {
            for (int y = H - 2; y >= 1; y--) if (r.t[y][x] == '.' && (r.t[y + 1][x] == '#' || r.t[y + 1][x] == '=')) return y;
            return H - 2;
        }

        static void plat(Room r, List<int[]> plats, int row, int x0, int x1) {
            x0 = Math.max(1, x0); x1 = Math.min(W - 2, x1);
            for (int x = x0; x <= x1; x++) if (r.t[row][x] == '.') r.t[row][x] = '=';
            plats.add(new int[]{row, x0, x1});
        }

        static void terrain(Room r, Random rnd, boolean up, boolean down, int rl, List<int[]> plats) {
            int tier = EcoData.ZONES[r.zone].tier;
            // bultos en el suelo
            int bumps = rl == R_REFUGE ? 0 : rnd.nextInt(3);
            for (int b = 0; b < bumps; b++) {
                int w = 3 + rnd.nextInt(4);
                int x0 = 5 + rnd.nextInt(Math.max(1, 20 - w));
                if (down && x0 <= 19 && x0 + w - 1 >= 10) continue;
                int hgt = rnd.nextInt(3) == 0 ? 2 : 1;
                for (int x = x0; x < x0 + w; x++) for (int h = 0; h < hgt; h++) r.t[14 - h][x] = '#';
            }
            // pinchos en el suelo (zonas difíciles)
            if (rl != R_REFUGE && (tier >= 4 || r.dungeon > 0) && rnd.nextFloat() < 0.45f) {
                int x0 = 7 + rnd.nextInt(15), w = 2 + rnd.nextInt(2);
                if (!(down && x0 <= 18 && x0 + w >= 11))
                    for (int x = x0; x < x0 + w; x++) if (r.t[14][x] == '.' && r.t[15][x] == '#') r.t[14][x] = '^';
            }
            // plataformas
            if (up) {
                plat(r, plats, 3, 11, 18);
                int prev = 14;
                for (int row = 6; row <= 12; row += 3) {
                    int c = prev + (rnd.nextBoolean() ? 1 : -1) * (3 + rnd.nextInt(3));
                    c = Math.max(5, Math.min(24, c));
                    int w = 4 + rnd.nextInt(3);
                    plat(r, plats, row, c - w / 2, c - w / 2 + w - 1);
                    prev = c;
                }
            } else {
                int levels = rl == R_REFUGE ? 1 : 1 + rnd.nextInt(3);
                int prev = 6 + rnd.nextInt(18);
                for (int i = 0; i < levels; i++) {
                    int row = 12 - 3 * i;
                    int c = i == 0 ? prev : Math.max(5, Math.min(24, prev + (rnd.nextBoolean() ? 1 : -1) * (3 + rnd.nextInt(3))));
                    int w = 4 + rnd.nextInt(3);
                    plat(r, plats, row, c - w / 2, c - w / 2 + w - 1);
                    prev = c;
                }
                // estalactitas
                if (rl != R_REFUGE) for (int i = 0; i < 3; i++) {
                    int x = 3 + rnd.nextInt(24), len = 1 + rnd.nextInt(2);
                    for (int y = 1; y <= len; y++) r.t[y][x] = '#';
                }
            }
            // otra plataforma suelta a la altura más baja
            if (rnd.nextBoolean()) {
                int c = 5 + rnd.nextInt(20);
                boolean clash = false;
                for (int[] p : plats) if (p[0] == 12 && c + 3 >= p[1] - 2 && c - 2 <= p[2] + 2) clash = true;
                if (!clash) plat(r, plats, 12, c - 2, c + 2);
            }
        }

        /** Salas de jefe: suelo plano, plataformas a los lados y en el centro. */
        static void arena(Room r, String bossId, boolean up, List<int[]> plats) {
            if (bossId.equals("V3")) {           // Planta Carnívora: tres plataformas para subir y bajar
                plat(r, plats, 11, 3, 9);
                plat(r, plats, 8, 8, 14);
                plat(r, plats, 5, 3, 9);
                for (int y = 9; y < 15; y++) for (int x = 25; x < 29; x++) r.t[y][x] = '#';   // maceta de piedra
                if (up) plat(r, plats, 3, 11, 18);
                return;
            }
            if (bossId.equals("V1")) {           // Harold: columnas bajas contra las que se estrella
                for (int x = 9; x <= 10; x++) for (int y = 13; y <= 14; y++) r.t[y][x] = '#';
                for (int x = 19; x <= 20; x++) for (int y = 13; y <= 14; y++) r.t[y][x] = '#';
                plat(r, plats, 10, 12, 17);
                if (up) { plat(r, plats, 7, 6, 10); plat(r, plats, 4, 11, 18); plat(r, plats, 3, 11, 18); }
                return;
            }
            plat(r, plats, 11, 3, 8);
            plat(r, plats, 11, 21, 26);
            plat(r, plats, 8, 12, 17);
            if (up) { plat(r, plats, 5, 6, 10); plat(r, plats, 3, 11, 18); }
        }

        static void enemies(Room r, Random rnd, char c, List<Spawn> sp, List<int[]> plats) {
            EcoData.Zone z = EcoData.ZONES[r.zone];
            int n = 2 + (z.tier >= 4 ? 1 : 0) + rnd.nextInt(2) + (r.dungeon > 0 ? 2 : 0) + (r.lair != 0 ? 1 : 0);
            for (int i = 0; i < n; i++) {
                String id = z.kinds[rnd.nextInt(z.kinds.length)];
                EcoData.Kind kd = EcoData.kind(id);
                int x, y;
                if (kd.arch == EcoData.A_SPIDER) {
                    x = 6 + rnd.nextInt(18); y = 1;
                    if (r.t[1][x] != '.') continue;
                } else if (kd.flies()) {
                    x = 6 + rnd.nextInt(18); y = 3 + rnd.nextInt(7);
                    if (r.t[y][x] != '.') continue;
                } else if ((kd.arch == EcoData.A_TURRET || kd.arch == EcoData.A_SHOOT) && !plats.isEmpty() && rnd.nextBoolean()) {
                    int[] p = plats.get(rnd.nextInt(plats.size()));
                    x = p[1] + rnd.nextInt(Math.max(1, p[2] - p[1] + 1)); y = p[0] - 1;
                } else {
                    x = 6 + rnd.nextInt(18); y = groundY(r, x);
                    if (r.t[y][x] != '.' || r.t[y + 1][x] == '^') continue;
                }
                sp.add(mk('%', id, x, y));
            }
        }
    }

    // =====================================================================
    // Diálogos
    // =====================================================================
    static final String[] INTRO = {
            "En el valle de LANARIA todo hacía ruido: las campanas, los grillos, los balidos de las ovejas.",
            "Una noche bajó de la montaña LUMENIA, LA POLILLA DEL SILENCIO ABSOLUTO... y se comió todos los sonidos del mundo.",
            "Ahora el valle está en silencio. Solo un cencerro sigue sonando: el tuyo.",
            "Eres BEE, una ovejita pequeña. Baja a las cuevas, recupera los 20 ECOS robados y devuelve la voz a Lanaria."
    };

    static final String[] TOPO_1 = {
            "¡Bee! Menos mal que tu cencerro aún suena... Soy el Topo Abuelo.",
            "Lumenia escondió los 20 ECOS por todo el mundo de abajo. El primero lo guarda el REY TOPO LOCO, al este, más allá del Pozo de Raíces.",
            "Toca 🔔 para lanzar ondas con tu cencerro. Si te hieren, mantén 🧶 para curarte con la lana que ganas al golpear.",
            "Los fardos de heno 🌾 son refugios: descansa en ellos para guardar, recuperar la vida y cambiar tus EMBLEMAS.",
            "Las rejas de cada zona se abren cuando llevas suficientes ecos. Y si caes... tus cascabeles se quedarán donde caíste. ¡Suerte, pequeña!"
    };
    static final String[] TOPO_2 = {
            "¡Recuperaste un Eco! ¿Oyes eso? Los grillos han vuelto a cantar un poquito.",
            "Cada eco que traes abre nuevas rejas en Lanaria. Mira el mapa 🗺: el mundo de abajo es ENORME.",
            "Al este de las minas está el Lago Helado; al oeste, el Bosque de Hongos. Y más abajo, la ciudad que se hundió..."
    };

    static final String[] SABIO_AGAIN = {"Ujú. Mira tu BESTIARIO en el menú ⏸: ahí está todo lo que sé."};

    static final String[] HERRERA = {"Soy la Herrera. Dame cascabeles y MINERAL DE ECO y haré que tu cencerro suene más fuerte. Hasta el nivel 10."};
    static final String[] FARDO = {"Descansas en el fardo de heno... Partida guardada. Vida recuperada."};
    static final String[] FANTASMA = {
            "...Hola. Nadie me oye desde que llegó la Polilla.",
            "Perdí mi nana favorita en el Lago Helado. Si algún día cruzas el hielo... ¿la buscarías por mí?",
    };
    static final String[] CORDERITO = {"¡Un CORDERITO perdido! Lo llevas de vuelta al rebaño."};

    static final String[] BOSS1_WIN = {
            "¡El REY TOPO LOCO se rinde y suelta algo brillante!",
            "Has recuperado el ECO DE LAS CAMPANAS. 🔔 (1 de 20)",
            "A lo lejos, la reja de Eco Hondo se abre: el camino a las MINAS DE COBRE está libre."
    };
    static final String[] BOSS2_WIN = {
            "La VAGONETA FANTASMA se detiene para siempre...",
            "Has recuperado el ECO DEL COBRE. ⚙ (2 de 20)",
            "Con 2 ecos se abren las rejas del LAGO HELADO (al este de los raíles) y del BOSQUE DE HONGOS (al oeste de la entrada de las minas)."
    };
    static final String[] BOSS3_WIN = {
            "¡Los MURCIÉLAGOS GEMELOS caen a la vez!",
            "Entre sus plumas había un CORDERITO asustado y un emblema: GARRA GEMELA (+20 % de daño)."
    };

    // Herrera: especialidades del cencerro (nivel 3)
    static final String[] BRANCH_NAMES = {"", "Onda Ancha", "Eco Rebotante", "Nota Aguda"};
    static final String[] BRANCH_DESC = {"", "Ondas más altas: golpean a varios", "Rebotan en las paredes 2 veces", "Atraviesan a los enemigos"};

    /** Texto de Sabelotodo para una zona, hecho con su bestiario. */
    static String[] sabio(int zone) {
        EcoData.Zone z = EcoData.ZONES[zone];
        List<String> l = new ArrayList<>();
        l.add(zone == 0 ? "¡Ujú! Soy Sabelotodo, y lo sé TODO de los bichos de cada zona." : "¡Ujú! " + z.name.toUpperCase() + ". Aquí los bichos muerden más.");
        for (String id : z.kinds) {
            EcoData.Kind k = EcoData.kind(id);
            l.add(k.name.toUpperCase() + ": " + k.desc);
        }
        for (EcoData.Boss b : EcoData.BOSSES)
            if (b.zone == zone && b.eco > 0) l.add("Y en lo más hondo vive " + b.name.toUpperCase() + ". " + b.desc);
        l.add("Lo apunto todo en tu BESTIARIO (menú ⏸). Si derrotas 10 de un mismo bicho, te cuento su secreto.");
        return l.toArray(new String[0]);
    }

    // se ejecuta al final, cuando el plano y los nombres ya están listos
    static { Generator.build(); }
}
