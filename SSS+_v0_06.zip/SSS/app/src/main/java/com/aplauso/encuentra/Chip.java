package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

import java.util.ArrayList;
import java.util.List;

/**
 * Sintetizador chiptune (8 bits) en tiempo real: melodía de pulso suavizada, armonía, bajo triangular,
 * batería de ruido y efectos de sonido. Sin archivos de audio: todo se genera con código.
 */
public class Chip {
    static final int RATE = 22050;

    // Efectos de sonido
    static final int SFX_JUMP = 0, SFX_SHOOT = 1, SFX_HIT = 2, SFX_HURT = 3, SFX_COIN = 4,
            SFX_LEVEL = 5, SFX_BOOM = 6, SFX_POWER = 7, SFX_SWORD = 8, SFX_TALK = 9, SFX_SPRING = 10,
            SFX_DOOR = 11, SFX_DUCK = 12;

    // ======================================================================
    // Canción: cada canal es una lista de notas ("C5", "F#4", "Bb3"), "-" = mantener, "." = silencio
    // ======================================================================
    public static class Song {
        final float bpm;
        final int stepsPerBeat = 2;            // cada paso = corchea
        final int[] lead, harm, bass;
        final char[] drums;
        boolean musicBox;
        float leadVol = 0.15f, harmVol = 0.06f, bassVol = 0.19f, drumVol = 0.11f;
        float duty = 0.25f;

        Song(float bpm, String lead, String harm, String bass, String drums) {
            this.bpm = bpm;
            this.lead = notes(lead);
            this.harm = notes(harm);
            this.bass = notes(bass);
            this.drums = drumChars(drums);
        }

        Song box() { musicBox = true; return this; }
        Song vols(float l, float h, float b, float d) { leadVol = l; harmVol = h; bassVol = b; drumVol = d; return this; }
    }

    static int[] notes(String s) {
        if (s == null || s.trim().isEmpty()) return new int[]{0};
        String[] t = s.trim().split("\\s+");
        int[] out = new int[t.length];
        for (int i = 0; i < t.length; i++) {
            String k = t[i];
            if (k.equals("-")) out[i] = -1;
            else if (k.equals(".")) out[i] = 0;
            else out[i] = midi(k);
        }
        return out;
    }

    static char[] drumChars(String s) {
        if (s == null || s.trim().isEmpty()) return new char[]{'.'};
        String[] t = s.trim().split("\\s+");
        char[] out = new char[t.length];
        for (int i = 0; i < t.length; i++) out[i] = t[i].charAt(0);
        return out;
    }

    static int midi(String k) {
        int base;
        switch (k.charAt(0)) {
            case 'C': base = 0; break;
            case 'D': base = 2; break;
            case 'E': base = 4; break;
            case 'F': base = 5; break;
            case 'G': base = 7; break;
            case 'A': base = 9; break;
            default: base = 11; break; // B
        }
        int i = 1;
        if (k.length() > 2 && k.charAt(1) == '#') { base++; i = 2; }
        else if (k.length() > 2 && k.charAt(1) == 'b') { base--; i = 2; }
        int oct;
        try { oct = Integer.parseInt(k.substring(i)); } catch (Exception e) { oct = 4; }
        return (oct + 1) * 12 + base;
    }

    // ======================================================================
    // Estado
    // ======================================================================
    private final Context ctx;
    private AudioTrack track;
    private Thread thread;
    private volatile boolean run;
    private volatile Song song;
    private volatile boolean reset;
    volatile int intensity = 1;        // 0 suave · 1 normal · 2 intenso
    volatile float tempoMul = 1f;
    volatile int transpose = 0;
    volatile boolean harsh = false;    // sonido distorsionado (Nightmare)
    volatile float musicVol = 0.6f, sfxVol = 0.8f;

    private final List<float[]> pendingSfx = new ArrayList<>();

    Chip(Context c) {
        ctx = c.getApplicationContext();
        loadVolumes();
    }

    void loadVolumes() {
        SharedPreferences p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        musicVol = p.getBoolean("music_on", true) ? p.getInt("music_vol", 60) / 100f : 0f;
        sfxVol = p.getBoolean("sfx_on", true) ? p.getInt("sfx_vol", 80) / 100f : 0f;
    }

    static boolean musicOn(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("music_on", true); }
    static boolean sfxOn(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("sfx_on", true); }

    void toggleMusic() {
        SharedPreferences p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        p.edit().putBoolean("music_on", !p.getBoolean("music_on", true)).apply();
        loadVolumes();
    }

    void toggleSfx() {
        SharedPreferences p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        p.edit().putBoolean("sfx_on", !p.getBoolean("sfx_on", true)).apply();
        loadVolumes();
    }

    /** Cambia de canción (si es la misma no la reinicia). */
    void play(Song s) {
        if (s == song) return;
        song = s;
        reset = true;
    }

    void silence() { song = null; }

    void sfx(int id) {
        if (sfxVol <= 0) return;
        // {tipo, f0, f1, duración, volumen}  tipo: 0 pulso, 1 ruido, 2 arpegio
        float[] d;
        switch (id) {
            case SFX_JUMP: d = new float[]{0, 300, 700, 0.12f, 0.35f}; break;
            case SFX_SHOOT: d = new float[]{0, 900, 400, 0.08f, 0.25f}; break;
            case SFX_HIT: d = new float[]{1, 0, 0, 0.08f, 0.4f}; break;
            case SFX_HURT: d = new float[]{0, 500, 120, 0.25f, 0.4f}; break;
            case SFX_COIN: d = new float[]{2, 988, 1318, 0.12f, 0.25f}; break;
            case SFX_LEVEL: d = new float[]{2, 523, 1046, 0.45f, 0.35f}; break;
            case SFX_BOOM: d = new float[]{1, 0, 0, 0.5f, 0.55f}; break;
            case SFX_POWER: d = new float[]{2, 392, 784, 0.35f, 0.35f}; break;
            case SFX_SWORD: d = new float[]{1, 0, 0, 0.05f, 0.25f}; break;
            case SFX_TALK: d = new float[]{0, 600, 620, 0.03f, 0.12f}; break;
            case SFX_SPRING: d = new float[]{0, 200, 1100, 0.2f, 0.35f}; break;
            case SFX_DOOR: d = new float[]{0, 150, 80, 0.4f, 0.4f}; break;
            default: d = new float[]{0, 250, 180, 0.08f, 0.2f}; break;
        }
        synchronized (pendingSfx) {
            if (pendingSfx.size() < 12) pendingSfx.add(d);
        }
    }

    // ======================================================================
    // Arranque / parada
    // ======================================================================
    void start() {
        if (thread != null) return;
        loadVolumes();
        try {
            int min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(min, 4096))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            track.play();
        } catch (Exception e) {
            track = null;
            return;
        }
        run = true;
        reset = true;
        thread = new Thread(this::loop, "chip");
        thread.start();
    }

    void stop() {
        run = false;
        if (thread != null) {
            try { thread.join(400); } catch (InterruptedException ignored) {}
            thread = null;
        }
        if (track != null) {
            try { track.stop(); } catch (Exception ignored) {}
            track.release();
            track = null;
        }
    }

    // ======================================================================
    // Síntesis
    // ======================================================================
    private static class Voice {
        double phase, freq;
        float env, lp;
        boolean on;
    }

    private int seed = 0x1234567;

    private float noise() {
        seed ^= seed << 13;
        seed ^= seed >>> 17;
        seed ^= seed << 5;
        return (seed & 0xffff) / 32768f - 1f;
    }

    private static double hz(int midi) { return 440.0 * Math.pow(2, (midi - 69) / 12.0); }

    private void loop() {
        short[] buf = new short[512];
        Voice lead = new Voice(), harm = new Voice(), bass = new Voice();
        List<float[]> active = new ArrayList<>();   // {tipo,f0,f1,dur,vol,t,fase}
        double stepLeft = 0;
        int step = 0;
        int kickT = 99999, snareT = 99999, hatT = 99999;
        double kickPh = 0;
        float prevNoise = 0;

        while (run) {
            Song s = song;
            if (reset) {
                reset = false;
                step = 0;
                stepLeft = 0;
                lead.on = harm.on = bass.on = false;
                lead.env = harm.env = bass.env = 0;
            }
            synchronized (pendingSfx) {
                for (float[] d : pendingSfx) active.add(new float[]{d[0], d[1], d[2], d[3], d[4], 0, 0});
                pendingSfx.clear();
            }
            float mv = musicVol, sv = sfxVol;
            boolean crush = harsh;
            for (int i = 0; i < buf.length; i++) {
                float out = 0;
                if (s != null && mv > 0) {
                    if (stepLeft <= 0) {
                        int tr = transpose;
                        trigger(lead, s.lead, step, tr);
                        trigger(harm, s.harm, step, tr);
                        trigger(bass, s.bass, step, tr);
                        char d = s.drums[step % s.drums.length];
                        int lvl = intensity;
                        if (d == 'k' || d == 'x') kickT = 0;
                        if (d == 's') snareT = 0;
                        if ((d == 'h' || d == 'x') && lvl >= 1) hatT = 0;
                        if (d == '.' && lvl >= 2 && step % 2 == 1) hatT = 0;
                        if (d == '.' && lvl >= 2 && step % 4 == 2) kickT = 0;
                        step++;
                        stepLeft += RATE * 60.0 / (s.bpm * tempoMul * s.stepsPerBeat);
                    }
                    stepLeft--;

                    float duty = crush ? 0.125f : s.duty;
                    if (s.musicBox) {
                        out += tri(lead, 0.9998f) * s.leadVol * 1.3f;
                        out += tri(bass, 0.9999f) * s.bassVol * 0.7f;
                    } else {
                        out += pulse(lead, duty, 0.3f, 0.6f) * s.leadVol;
                        out += pulse(harm, 0.5f, 0.2f, 0.5f) * s.harmVol;
                        out += triSustain(bass) * s.bassVol;
                    }
                    // batería
                    if (kickT < RATE * 0.15) {
                        float t = kickT / (float) RATE;
                        double f = 150 * Math.exp(-t * 25) + 45;
                        kickPh += f / RATE;
                        out += (float) Math.sin(kickPh * Math.PI * 2) * (float) Math.exp(-t * 18) * s.drumVol * 1.6f;
                        kickT++;
                    }
                    if (snareT < RATE * 0.15) {
                        float t = snareT / (float) RATE;
                        out += noise() * (float) Math.exp(-t * 30) * s.drumVol * 0.7f;
                        snareT++;
                    }
                    if (hatT < RATE * 0.05) {
                        float t = hatT / (float) RATE;
                        float n = noise();
                        out += (n - prevNoise) * 0.5f * (float) Math.exp(-t * 90) * s.drumVol * 0.5f;
                        prevNoise = n;
                        hatT++;
                    }
                    out *= mv;
                }
                // efectos
                for (int k = active.size() - 1; k >= 0; k--) {
                    float[] a = active.get(k);
                    float u = a[5] / a[3];
                    if (u >= 1) { active.remove(k); continue; }
                    float env = 1 - u;
                    float v;
                    if (a[0] == 1) {
                        v = noise() * env * env;
                    } else {
                        float f;
                        if (a[0] == 2) {
                            int part = (int) (u * 3);
                            f = part == 0 ? a[1] : part == 1 ? a[1] * 1.26f : a[2];
                        } else f = a[1] + (a[2] - a[1]) * u;
                        a[6] += f / RATE;
                        if (a[6] >= 1) a[6] -= 1;
                        v = (a[6] < 0.5f ? 1 : -1) * env;
                    }
                    out += v * a[4] * sv * 0.5f;
                    a[5] += 1f / RATE;
                }
                if (crush) out = Math.round(out * 10) / 10f;
                if (out > 1) out = 1;
                if (out < -1) out = -1;
                buf[i] = (short) (out * 30000);
            }
            AudioTrack t = track;
            if (t == null) break;
            try { t.write(buf, 0, buf.length); } catch (Exception e) { break; }
        }
    }

    private void trigger(Voice v, int[] arr, int step, int tr) {
        int n = arr[step % arr.length];
        if (n > 0) {
            v.freq = hz(n + tr);
            v.on = true;
            v.env = 1f;
        } else if (n == 0) {
            v.on = false;
        }
    }

    private float pulse(Voice v, float duty, float lpAmt, float sustain) {
        if (v.env < 0.0005f && !v.on) return 0;
        v.phase += v.freq / RATE;
        if (v.phase >= 1) v.phase -= 1;
        float raw = v.phase < duty ? 1f : -1f;
        v.lp += (raw - v.lp) * lpAmt;
        if (v.on) v.env += (sustain - v.env) * 0.0004f;
        else v.env *= 0.996f;
        return v.lp * v.env;
    }

    private float triSustain(Voice v) {
        if (v.env < 0.0005f && !v.on) return 0;
        v.phase += v.freq / RATE;
        if (v.phase >= 1) v.phase -= 1;
        float raw = (float) (4 * Math.abs(v.phase - 0.5) - 1);
        if (v.on) v.env += (0.85f - v.env) * 0.0004f;
        else v.env *= 0.996f;
        return raw * v.env;
    }

    /** Caja de música: cada nota se apaga sola poco a poco. */
    private float tri(Voice v, float decay) {
        if (v.env < 0.0005f) return 0;
        v.phase += v.freq / RATE;
        if (v.phase >= 1) v.phase -= 1;
        float raw = (float) (4 * Math.abs(v.phase - 0.5) - 1);
        v.env *= decay;
        return raw * v.env;
    }
}
