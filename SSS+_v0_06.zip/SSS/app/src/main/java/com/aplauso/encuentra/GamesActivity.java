package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.Switch;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Menú de minijuegos y pantalla de juego. */
public class GamesActivity extends NeonActivity {
    static final String[][] GAMES = {
            {"eco", "🔔 EL PASTOR DE ECOS", "Metroidvania: 300 salas, 20 jefes y un final secreto. Recupera los 20 Ecos robados por Lumenia."},
            {"tower", "🗼 TORRE ARRIBA", "Roguelike: sube pisos, sube de nivel y llega al piso 1000. Si caes, desde cero."},
            {"runner", "🐈 GATO RUNNER", "Toca para saltar ovillos, mantén para agacharte ante chanclas. Cada 250 puntos: NIGHTMARE MODE."},
            {"snake", "🐍 CULEBRITA", "Desliza (o toca a un lado) para girar. Come y crece."},
            {"blocks", "🧱 BLOQUES", "Arrastra para mover, toca para girar, desliza abajo para soltar. También hay botones y joystick opcional (⚙)."},
            {"breakout", "🏓 ROMPELADRILLOS", "Arrastra el dedo para mover la barra. Rompe todos los ladrillos."},
            {"mines", "💣 BUSCAMINAS", "Toca para descubrir, mantén pulsado para poner bandera."},
            {"2048", "🔢 2048", "Desliza para juntar fichas iguales hasta llegar a 2048."},
            {"sudoku", "🧩 SUDOKU", "9×9 con cajas de 3×3. Cuatro dificultades, notas y 3 errores máximo."},
    };
    TextView[] bests = new TextView[GAMES.length];

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("JUEGOS");
        for (int i = 0; i < GAMES.length; i++) {
            String[] g = GAMES[i];
            LinearLayout card = panel(null);
            TextView name = neonText(g[1], 20);
            card.addView(name);
            TextView desc = text(g[2], 13);
            desc.setTextColor(Color.rgb(170, 180, 200));
            desc.setPadding(0, dpi(4), 0, dpi(4));
            card.addView(desc);
            bests[i] = text("", 13);
            card.addView(bests[i]);
            card.setClickable(true);
            boolean arcade = g[0].equals("eco") || g[0].equals("tower") || g[0].equals("runner");
            card.setOnClickListener(v -> startActivity(new Intent(this, arcade ? ArcadeActivity.class : Play.class)
                    .putExtra("game", g[0]).putExtra("title", g[1])));
            col.addView(card, gapBelow(14));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (int i = 0; i < GAMES.length; i++) {
            String id = GAMES[i][0];
            if (id.equals("tower"))
                bests[i].setText(L.t("🏆 Récord: piso " + p.getInt("best_tower", 0) + (p.getBoolean("tower_won", false) ? "   🗡 ¡Torre completada!" : "")));
            else if (id.equals("eco")) bests[i].setText(ecoProgress());
            else bests[i].setText(L.t("🏆 Récord: " + p.getInt("best_" + id, 0)));
        }
    }

    String ecoProgress() {
        String s = p.getString("eco_save", null);
        if (s == null) return "✦ Nueva aventura";
        try {
            org.json.JSONObject o = new org.json.JSONObject(s);
            return "✦ Ecos " + o.getInt("ecos") + "/3 · 🐑 Corderitos " + o.getInt("lambs") + "/5 · 🔔 " + o.getInt("bells");
        } catch (Exception e) {
            return "✦ Partida guardada";
        }
    }

    /** Pantalla de una partida. */
    public static class Play extends NeonActivity {
        Games.Base game;
        TextView score;

        @Override
        protected void onCreate(Bundle b) {
            super.onCreate(b);
            String id = getIntent().getStringExtra("game");
            if ("blocks".equals(id)) game = new Games.Blocks(this);
            else if ("breakout".equals(id)) game = new Games.Breakout(this);
            else if ("mines".equals(id)) game = new Games.Mines(this);
            else if ("2048".equals(id)) game = new Games.Game2048(this);
            else if ("sudoku".equals(id)) game = new Games.Sudoku(this);
            else game = new Games.Snake(this);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dpi(12), dpi(18), dpi(12), dpi(12));
            String title = getIntent().getStringExtra("title");
            LinearLayout bar = topBar(title == null ? "JUEGO" : title);
            if (!"mines".equals(id))      // ajustes de controles (joystick / mando externo)
                bar.addView(circleButton("⚙", v -> controls()), new LinearLayout.LayoutParams(dpi(46), dpi(46)));
            col.addView(bar, gapBelow(6));
            score = neonText("", 15);
            score.setGravity(Gravity.CENTER);
            col.addView(score, gapBelow(6));
            col.addView(game, new LinearLayout.LayoutParams(-1, 0, 1));
            setContentView(makeRoot(col));
        }

        /** Ajustes de controles del juego: joystick en pantalla (Bloques) y mando externo opcional. */
        void controls() {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dpi(20), dpi(8), dpi(20), dpi(8));
            if (game.hasStick()) {
                Switch joy = neonSwitch("🕹 Joystick en pantalla (si no: deslizar el dedo)");
                joy.setChecked(game.ctrl.mode(0) == 1);
                joy.setOnCheckedChangeListener((v, on) -> { game.ctrl.setMode(on ? 1 : 0); game.applyCtrl(); });
                box.addView(joy);
                plainSlider(box, "Opacidad del joystick", 15, 100, game.ctrl.opacity(), "%", v -> { game.ctrl.setOpacity(v); game.applyCtrl(); });
            }
            Switch pad = neonSwitch("🎮 Mando externo (Xbox / gamepad / teclado)");
            pad.setChecked(game.ctrl.gamepad());
            pad.setOnCheckedChangeListener((v, on) -> { game.ctrl.setGamepad(on); game.applyCtrl(); });
            box.addView(pad);
            TextView help = text("Conecta el mando por Bluetooth o USB. Cruceta o palanca = mover · A = acción · B = otra acción. "
                    + "Los controles táctiles siguen funcionando.", 12);
            help.setTextColor(Color.rgb(170, 180, 200));
            box.addView(help);
            new AlertDialog.Builder(this).setTitle(L.t("🎮 Controles")).setView(box)
                    .setPositiveButton(L.t("Listo"), null).show();
        }

        @Override
        public boolean dispatchKeyEvent(KeyEvent e) {
            if (e.getKeyCode() != KeyEvent.KEYCODE_BACK && game != null && game.handleKey(e)) return true;
            return super.dispatchKeyEvent(e);
        }

        @Override
        public boolean dispatchGenericMotionEvent(MotionEvent e) {
            if (game != null && game.handleMotion(e)) return true;
            return super.dispatchGenericMotionEvent(e);
        }

        @Override
        protected void onResume() {
            super.onResume();
            game.startLoop();
        }

        @Override
        protected void onPause() {
            super.onPause();
            game.stopLoop();
        }

        @Override
        protected void onTick() {
            game.color = Neon.color(this);
            score.setText(L.t("PUNTOS " + game.score + "   ·   RÉCORD " + game.best()));
        }
    }
}
