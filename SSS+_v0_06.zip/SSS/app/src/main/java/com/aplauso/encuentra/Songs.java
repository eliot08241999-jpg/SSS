package com.aplauso.encuentra;

/** Canciones originales de SSS+ (todas compuestas para la app). Cada compás = 8 corcheas. */
public class Songs {

    // ---------------- TORRE ARRIBA: valiente, alegre, con energía (Do mayor, 125) ----------------
    static final String TOWER_LEAD =
            "C5 - E5 G5 C6 - B5 G5 " +
            "A5 - G5 E5 F5 - E5 D5 " +
            "E5 - G5 C6 D6 - C6 B5 " +
            "C6 - - - G5 - - - " +
            "A5 - C6 A5 G5 - E5 C5 " +
            "F5 - A5 F5 E5 - C5 E5 " +
            "D5 - F5 A5 G5 - B5 D6 " +
            "C6 - - - . . G5 - ";
    static final String TOWER_HARM =
            "E4 - - - G4 - - - " +
            "F4 - - - G4 - - - " +
            "E4 - - - D4 - - - " +
            "E4 - - - D4 - - - " +
            "E4 - - - E4 - - - " +
            "F4 - - - E4 - - - " +
            "F4 - - - D4 - - - " +
            "E4 - - - . . . . ";
    static final String TOWER_BASS =
            "C3 . C4 . C3 . C4 . " +
            "F2 . F3 . G2 . G3 . " +
            "C3 . C4 . G2 . G3 . " +
            "C3 . C4 . G2 . B2 . " +
            "A2 . A3 . C3 . C4 . " +
            "F2 . F3 . C3 . C4 . " +
            "D3 . D4 . G2 . G3 . " +
            "C3 . C4 . G2 . G3 . ";
    static final String TOWER_DRUMS = "k . h . s . h . k . h k s . h .";

    static final Chip.Song TOWER = new Chip.Song(125, TOWER_LEAD, TOWER_HARM, TOWER_BASS, TOWER_DRUMS);

    // ---------------- Jefe: tenso y rápido (La menor, 150) ----------------
    static final Chip.Song BOSS = new Chip.Song(150,
            "A4 A4 C5 A4 E5 A4 D5 C5 " +
            "A4 A4 C5 A4 G5 F5 E5 D5 " +
            "F4 F4 A4 F4 C5 F4 B4 A4 " +
            "E4 E4 G#4 E4 B4 E4 D5 B4 ",
            "C4 - - - E4 - - - C4 - - - E4 - - - A3 - - - C4 - - - G#3 - - - B3 - - - ",
            "A2 A3 A2 A3 A2 A3 A2 A3 A2 A3 A2 A3 A2 A3 A2 A3 " +
            "F2 F3 F2 F3 F2 F3 F2 F3 E2 E3 E2 E3 E2 E3 E2 E3 ",
            "k h s h k k s h");

    // ---------------- Guardián: épico (Re menor, 110) ----------------
    static final Chip.Song GUARDIAN = new Chip.Song(110,
            "D5 - - A4 D5 - F5 - " +
            "E5 - - C5 A4 - - - " +
            "Bb4 - - F4 Bb4 - D5 - " +
            "C5 - - G4 C5 - E5 - " +
            "D5 - F5 - A5 - - - " +
            "G5 - F5 - E5 - D5 - " +
            "C#5 - E5 - A5 - G5 - " +
            "A5 - - - - - - - ",
            "F4 - - - F4 - - - E4 - - - C#4 - - - D4 - - - F4 - - - E4 - - - G4 - - - " +
            "F4 - - - F4 - - - Bb4 - - - A4 - - - E4 - - - C#4 - - - E4 - - - C#4 - - - ",
            "D2 - D3 - D2 - D3 - A2 - A3 - A2 - A3 - Bb2 - Bb3 - Bb2 - Bb3 - C3 - C4 - C3 - C4 - " +
            "D2 - D3 - D2 - D3 - G2 - G3 - G2 - G3 - A2 - A3 - A2 - A3 - A2 - A3 - A2 - A3 - ",
            "k . s . k k s .");

    // ---------------- Final del piso 1000: el tema principal como caja de música ----------------
    static final Chip.Song ENDING = new Chip.Song(70, TOWER_LEAD, "", TOWER_BASS, "").box().vols(0.2f, 0, 0.12f, 0);

    // ---------------- GATO RUNNER: juguetón (Fa mayor, 140) ----------------
    static final Chip.Song RUNNER = new Chip.Song(140,
            "F5 . A5 . C6 . A5 . " +
            "Bb5 . G5 . E5 . C5 . " +
            "F5 . A5 . C6 . F6 . " +
            "E6 . C6 . G5 - - . " +
            "D6 . Bb5 . F5 . D5 . " +
            "C6 . A5 . F5 . C5 . " +
            "G5 . A5 . Bb5 . C6 . " +
            "F6 - - . . . . . ",
            "",
            "F3 . C3 . F3 . C3 . " +
            "C3 . G2 . C3 . G2 . " +
            "F3 . C3 . F3 . C3 . " +
            "C3 . G2 . C3 . E3 . " +
            "Bb2 . F3 . Bb2 . F3 . " +
            "F3 . C3 . F3 . C3 . " +
            "C3 . G2 . C3 . E3 . " +
            "F3 . C3 . F2 . . . ",
            "k h s h k h s h");

    // ---------------- EL PASTOR DE ECOS ----------------
    // Pradera Hundida: pastoral (Sol mayor, 100)
    static final Chip.Song PRADERA = new Chip.Song(100,
            "G5 - - B5 D6 - B5 - " +
            "C6 - - A5 F#5 - D5 - " +
            "G5 - - B5 D6 - G6 - " +
            "F#6 - E6 - D6 - - - " +
            "E6 - - D6 C6 - B5 - " +
            "A5 - - G5 F#5 - D5 - " +
            "E5 - F#5 - G5 - A5 - " +
            "G5 - - - - - - - ",
            "B4 - - - B4 - - - A4 - - - F#4 - - - B4 - - - B4 - - - A4 - - - F#4 - - - " +
            "G4 - - - E4 - - - F#4 - - - D4 - - - G4 - - - F#4 - - - B4 - - - - - - - ",
            "G2 - D3 - G2 - D3 - D3 - A2 - D3 - A2 - G2 - D3 - G2 - D3 - D3 - A2 - D3 - A2 - " +
            "C3 - G2 - C3 - G2 - D3 - A2 - D3 - A2 - C3 - G2 - D3 - A2 - G2 - D3 - G2 - - - ",
            "k . h . . . h .").vols(0.13f, 0.05f, 0.17f, 0.08f);

    // Eco Hondo (el pueblo): acogedor, como una nana
    static final Chip.Song PUEBLO = new Chip.Song(84,
            "E5 - - G5 - - C6 - " +
            "B5 - - G5 - - D5 - " +
            "C5 - - E5 - - A5 - " +
            "G5 - - - - - - - " +
            "F5 - - A5 - - C6 - " +
            "E5 - - G5 - - C6 - " +
            "D5 - - F5 - - B5 - " +
            "C6 - - - - - - - ",
            "",
            "C3 - - - G3 - - - G2 - - - D3 - - - A2 - - - E3 - - - G2 - - - D3 - - - " +
            "F2 - - - C3 - - - C3 - - - G3 - - - G2 - - - D3 - - - C3 - - - G2 - - - ",
            "").box();

    // Minas de Cobre: misteriosa (Mi menor, 96)
    static final Chip.Song MINAS = new Chip.Song(96,
            "E4 - . G4 . B4 - . " +
            "C5 - - - B4 - . . " +
            "A4 - . C5 . E5 - . " +
            "D#5 - - - B4 - . . " +
            "E5 . . D5 . . B4 . " +
            "C5 - - A4 - - F#4 - " +
            "G4 - A4 - B4 - D#5 - " +
            "E5 - - - - - . . ",
            "",
            "E2 - - - - - - - C2 - - - - - - - A2 - - - - - - - B2 - - - - - - - " +
            "E2 - - - - - - - A2 - - - - - - - B2 - - - - - - - E2 - - - - - - - ",
            "k . . . . . h .").vols(0.14f, 0, 0.22f, 0.09f);


    // =====================================================================
    // EL PASTOR DE ECOS · zonas nuevas (v0.5)
    // =====================================================================
    // Lago Helado: cristalino y lento (Re menor, 84)
    static final Chip.Song LAGO = new Chip.Song(84,
            "A5 - - - E5 - A5 - G5 - F5 - E5 - - - " +
            "F5 - - - C5 - F5 - E5 - D5 - C#5 - - - " +
            "D5 - F5 - A5 - D6 - C6 - Bb5 - A5 - - - " +
            "G5 - E5 - C#5 - E5 - D5 - - - - - - - ",
            "",
            "D3 - - - A3 - - - Bb2 - - - F3 - - - F2 - - - C3 - - - A2 - - - E3 - - - " +
            "D3 - - - A3 - - - G2 - - - D3 - - - A2 - - - E3 - - - D3 - - - A2 - - - ",
            "").box();

    // Bosque de Hongos: saltarín y curioso (Fa mayor, 108)
    static final Chip.Song HONGOS = new Chip.Song(108,
            "F5 . A5 . C6 . A5 . G5 . Bb5 . D6 - . . " +
            "C6 . A5 . F5 . A5 . G5 - - - . . . . " +
            "D5 . F5 . A5 . F5 . E5 . G5 . C6 - . . " +
            "Bb5 . A5 . G5 . E5 . F5 - - - . . . . ",
            "",
            "F2 . C3 . F2 . C3 . G2 . D3 . G2 . D3 . A2 . E3 . A2 . E3 . C3 . G2 . C3 . G2 . " +
            "D3 . A2 . D3 . A2 . C3 . G2 . C3 . G2 . Bb2 . F3 . C3 . G2 . F2 . C3 . F2 . . . ",
            "k . h . s . h h").vols(0.13f, 0, 0.18f, 0.08f);

    // Jardín de Espinas: misterioso y verde (Mi frigio, 92)
    static final Chip.Song JARDIN = new Chip.Song(92,
            "E5 - F5 - E5 - B4 - C5 - - - B4 - - - " +
            "A4 - B4 - C5 - E5 - D5 - C5 - B4 - - - " +
            "E5 - G5 - F5 - E5 - D5 - - - C5 - - - " +
            "B4 - C5 - B4 - A4 - G#4 - - - E4 - - - ",
            "B4 - - - - - - - A4 - - - - - - - F4 - - - - - - - E4 - - - - - - - ",
            "E2 - - - E3 - - - F2 - - - F3 - - - A2 - - - A3 - - - E2 - - - B2 - - - ",
            "k . . h . . s .").vols(0.13f, 0.05f, 0.19f, 0.07f);

    // Ciudad Sumergida: lluvia y melancolía (Do menor, 76)
    static final Chip.Song CIUDAD = new Chip.Song(76,
            "G5 - - Eb5 - - C5 - D5 - Eb5 - F5 - - - " +
            "Eb5 - - C5 - - Ab4 - Bb4 - C5 - D5 - - - " +
            "G5 - - Ab5 - - G5 - F5 - Eb5 - D5 - - - " +
            "C5 - D5 - Eb5 - B4 - C5 - - - - - - - ",
            "Eb4 - - - - - - - F4 - - - - - - - Eb4 - - - - - - - D4 - - - - - - - ",
            "C3 - - - G2 - - - Ab2 - - - Eb3 - - - F2 - - - C3 - - - G2 - - - D3 - - - ",
            "k . h . s . h .").vols(0.12f, 0.05f, 0.18f, 0.06f);

    // Cumbres de Cristal: brillante (Mi mayor, 112)
    static final Chip.Song CRISTAL = new Chip.Song(112,
            "E6 . B5 . G#5 . B5 . E6 . F#6 . G#6 - - - " +
            "F#6 . C#6 . A5 . C#6 . F#6 - E6 - D#6 - - - " +
            "E6 . G#6 . B6 . G#6 . A6 . F#6 . D#6 - - - " +
            "E6 . B5 . G#5 . E5 . E6 - - - . . . . ",
            "",
            "E3 . B3 . E3 . B3 . A2 . E3 . A2 . E3 . F#2 . C#3 . F#2 . C#3 . B2 . F#3 . B2 . F#3 . ",
            "k . h h s . h h").box().vols(0.17f, 0, 0.16f, 0.07f);

    // Acantilados del Viento: épico y abierto (Sol mixolidio, 104)
    static final Chip.Song VIENTO = new Chip.Song(104,
            "D5 - G5 - A5 - B5 - C6 - B5 - A5 - - - " +
            "G5 - F5 - G5 - A5 - D5 - - - - - - - " +
            "D5 - G5 - A5 - B5 - D6 - C6 - B5 - A5 - " +
            "G5 - F5 - D5 - F5 - G5 - - - - - - - ",
            "B4 - - - - - - - A4 - - - - - - - B4 - - - - - - - G4 - - - - - - - ",
            "G2 - - - D3 - - - F2 - - - C3 - - - G2 - - - D3 - - - F2 - - - G2 - - - ",
            "k . . h s . . h");

    // Cementerio de Campanas: lúgubre con campanadas (La menor, 70)
    static final Chip.Song CEMENTERIO = new Chip.Song(70,
            "A4 - - - C5 - - - B4 - - - E4 - - - " +
            "F4 - - - A4 - - - G#4 - - - - - - - " +
            "A4 - - - E5 - - - D5 - - - C5 - - - " +
            "B4 - - - G#4 - - - A4 - - - - - - - ",
            "",
            "A2 - - - - - - - F2 - - - - - - - D2 - - - - - - - E2 - - - - - - - ",
            "k . . . . . . .").box().vols(0.18f, 0, 0.2f, 0.06f);

    // Colmena Dorada: zumbona y rápida (Re mayor, 132)
    static final Chip.Song COLMENA = new Chip.Song(132,
            "D6 C#6 D6 . A5 . F#5 . G5 F#5 G5 . E5 . C#5 . " +
            "D5 E5 F#5 G5 A5 . D6 . C#6 - B5 - A5 . . . " +
            "B5 A5 B5 . G5 . E5 . A5 G5 A5 . F#5 . D5 . " +
            "E5 F#5 G5 A5 B5 . C#6 . D6 - - - . . . . ",
            "",
            "D3 . A2 . D3 . A2 . G2 . D3 . A2 . E3 . D3 . A2 . D3 . A2 . G2 . D3 . A2 . D3 . ",
            "k h s h k h s h").vols(0.12f, 0, 0.17f, 0.09f);

    // Cloacas Reales: goteo y eco (Si menor, 90)
    static final Chip.Song CLOACAS = new Chip.Song(90,
            "B4 . . D5 . . F#5 . E5 . . D5 . . C#5 . " +
            "B4 . . . A4 . B4 . D5 - - - . . . . " +
            "G5 . . F#5 . . E5 . D5 . . C#5 . . A4 . " +
            "B4 - - - . . . . F#4 . A4 . B4 - - - ",
            "",
            "B1 - - - B2 - - - G1 - - - G2 - - - E2 - - - E2 - - - F#2 - - - F#2 - - - ",
            "k . h . . h s .").vols(0.13f, 0, 0.21f, 0.08f);

    // Nido Profundo: tenso y oscuro (Do# menor, 96)
    static final Chip.Song NIDO = new Chip.Song(96,
            "C#5 . D5 . C#5 . G#4 . A4 - - - G#4 - - - " +
            "C#5 . E5 . D#5 . C#5 . B#4 - - - G#4 - - - ",
            "",
            "C#2 C#2 . C#2 . . C#3 . A1 A1 . A1 . . A2 . G#1 G#1 . G#1 . . G#2 . G#1 . . . G#2 . . . ",
            "k . . k s . . .").vols(0.12f, 0, 0.22f, 0.09f);

    // Abismo del Silencio: casi nada, un eco lejano (Mi menor, 60)
    static final Chip.Song ABISMO = new Chip.Song(60,
            "E5 - - - - - - - . . . . . . . . B4 - - - - - - - . . . . . . . . " +
            "G5 - - - F#5 - - - E5 - - - - - - - . . . . . . . . . . . . . . . . ",
            "",
            "E1 - - - - - - - - - - - - - - - C2 - - - - - - - - - - - - - - - ",
            "").box().vols(0.2f, 0, 0.16f, 0);

    // Castillo Carmesí: órgano gótico (Re menor, 80)
    static final Chip.Song CASTILLO = new Chip.Song(80,
            "D5 - A4 - F4 - A4 - D5 - E5 - F5 - - - " +
            "E5 - C5 - A4 - C5 - E5 - F5 - G5 - - - " +
            "F5 - D5 - Bb4 - D5 - G5 - F5 - E5 - D5 - " +
            "C#5 - E5 - A5 - G5 - F5 - E5 - D5 - - - ",
            "F4 - - - - - - - G4 - - - - - - - Bb4 - - - - - - - A4 - - - - - - - ",
            "D2 - - - D3 - - - A1 - - - A2 - - - Bb1 - - - Bb2 - - - A1 - - - A2 - - - ",
            "k . . . s . . .").vols(0.13f, 0.07f, 0.2f, 0.06f);

    // ---------------- Temas de los vampiros ----------------
    // Harold Vampis: bruto y galopante
    static final Chip.Song HAROLD = new Chip.Song(160,
            "D5 D5 . D5 F5 . D5 . C5 C5 . C5 Eb5 . C5 . " +
            "Bb4 Bb4 . Bb4 D5 . Bb4 . A4 - C#5 - E5 - A5 - ",
            "",
            "D2 D3 D2 D3 D2 D3 D2 D3 C2 C3 C2 C3 C2 C3 C2 C3 Bb1 Bb2 Bb1 Bb2 Bb1 Bb2 Bb1 Bb2 A1 A2 A1 A2 A1 A2 A1 A2 ",
            "k k s . k k s h");
    // Aloii Vampis: vals presumido y dramático
    static final Chip.Song ALOII = new Chip.Song(132,
            "A5 - - C6 - - E6 - - D6 - - C6 - - B5 - - " +
            "A5 - - G#5 - - A5 - - E5 - - - - - - - - " +
            "F5 - - A5 - - D6 - - C6 - - B5 - - A5 - - " +
            "G#5 - - B5 - - E6 - - A5 - - - - - - - - ",
            "",
            "A2 . . E3 . . E3 . . A2 . . E3 . . E3 . . F2 . . C3 . . C3 . . E2 . . B2 . . B2 . . ",
            "k . . h . . h . .").vols(0.14f, 0, 0.18f, 0.07f);
    // Sangre Joven: nervioso y saltón
    static final Chip.Song SANGRE = new Chip.Song(150,
            "E5 . G5 . B5 . G5 . A5 . F#5 . D#5 . B4 . " +
            "E5 . E6 . D6 . C6 . B5 . A5 . G5 . F#5 . ",
            "",
            "E2 . E3 . E2 . E3 . B1 . B2 . B1 . B2 . C2 . C3 . C2 . C3 . B1 . B2 . D#2 . F#2 . ",
            "k h s h k h s s");
    // Planta Carnívora: lento y venenoso
    static final Chip.Song PLANTA = new Chip.Song(100,
            "E4 - F4 - E4 - - - Bb4 - A4 - G4 - F4 - " +
            "E4 - F4 - G4 - Bb4 - A4 - - - - - - - ",
            "",
            "E2 - E2 - E2 - E2 - Bb1 - Bb1 - Bb1 - Bb1 - E2 - E2 - E2 - E2 - A1 - A1 - Bb1 - Bb1 - ",
            "k . s . k k s .").vols(0.15f, 0, 0.21f, 0.08f);
    // Conde Vampis: épico, órgano y batería
    static final Chip.Song CONDE = new Chip.Song(144,
            "D5 - D5 F5 A5 - D6 - C#6 - A5 - E5 - C#5 - " +
            "D5 - F5 A5 Bb5 - A5 G5 F5 - E5 D5 E5 - - - " +
            "F5 - F5 A5 C6 - F6 - E6 - C6 - G5 - E5 - " +
            "D6 - C6 Bb5 A5 - G5 F5 E5 - C#5 - D5 - - - ",
            "A4 - - - F4 - - - A4 - - - E4 - - - F4 - - - D4 - - - E4 - - - C#4 - - - " +
            "C5 - - - A4 - - - C5 - - - G4 - - - Bb4 - - - F4 - - - G4 - - - A4 - - - ",
            "D2 D3 D2 D3 D2 D3 D2 D3 A1 A2 A1 A2 A1 A2 A1 A2 Bb1 Bb2 Bb1 Bb2 G1 G2 G1 G2 A1 A2 A1 A2 A1 A2 A1 A2 " +
            "F2 F3 F2 F3 F2 F3 F2 F3 C2 C3 C2 C3 C2 C3 C2 C3 Bb1 Bb2 Bb1 Bb2 G1 G2 G1 G2 A1 A2 A1 A2 D2 D3 D2 D3 ",
            "k h s h k k s h").vols(0.14f, 0.07f, 0.19f, 0.11f);
    // La Polilla Gris: jefe final
    static final Chip.Song POLILLA = new Chip.Song(138,
            "E5 - G5 - B5 - E6 - D6 - B5 - G5 - A5 - " +
            "F#5 - A5 - C6 - F#6 - E6 - C6 - A5 - B5 - " +
            "G5 - B5 - D6 - G6 - F#6 - D6 - B5 - C6 - " +
            "B5 - A5 - G5 - F#5 - E5 - - - - - - - ",
            "B4 - - - G4 - - - A4 - - - F#4 - - - B4 - - - G4 - - - F#4 - - - D#4 - - - ",
            "E2 E3 E2 E3 E2 E3 E2 E3 D2 D3 D2 D3 D2 D3 D2 D3 C2 C3 C2 C3 C2 C3 C2 C3 B1 B2 B1 B2 B1 B2 B1 B2 ",
            "k h s h k h s s").vols(0.14f, 0.06f, 0.19f, 0.1f);
    // Final del Pastor
    static final Chip.Song ECO_FINAL = new Chip.Song(72, PRADERA_LEAD(), "", "", "").box().vols(0.22f, 0, 0, 0);
    // Final secreto vampírico
    static final Chip.Song VAMP_FINAL = new Chip.Song(60,
            "D5 - - - A4 - - - F4 - - - E4 - - - D4 - - - - - - - . . . . . . . . ",
            "",
            "D2 - - - - - - - Bb1 - - - - - - - A1 - - - - - - - D2 - - - - - - - ",
            "k . . . . . . .").vols(0.16f, 0, 0.22f, 0.08f);

    static String PRADERA_LEAD() {
        return "G5 - - B5 D6 - B5 - C6 - - A5 F#5 - D5 - G5 - - B5 D6 - G6 - F#6 - E6 - D6 - - - " +
               "E6 - - D6 C6 - B5 - A5 - - G5 F#5 - D5 - E5 - F#5 - G5 - A5 - G5 - - - - - - - ";
    }
}