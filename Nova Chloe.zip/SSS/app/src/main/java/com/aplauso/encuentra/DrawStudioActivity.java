package com.aplauso.encuentra;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * v1.3 · ESTUDIO DE DIBUJO: crea imágenes con IA dentro del teléfono (Stable Diffusion 1.5, sin internet ni cupos).
 * Texto → imagen, «lo que NO quieres», a partir de una imagen tuya (img2img) y ampliar el resultado.
 */
public class DrawStudioActivity extends NeonActivity {
    static final int REQ_INIT = 93, REQ_CHAR = 94;
    LinearLayout charsBox;
    static final String[][] SIZES = {{"Cuadrada 512×512", "512", "512"}, {"Vertical 512×768", "512", "768"},
            {"Horizontal 768×512", "768", "512"}, {"Rápida 384×384", "384", "384"}};
    static final String[][] CHIPS = {
            {"✨ Calidad", "masterpiece, best quality, highly detailed"},
            {"👧 Chica anime", "1girl, anime style, beautiful detailed eyes"},
            {"🧑 Chico anime", "1boy, anime style, detailed face"},
            {"🌄 Paisaje", "scenery, landscape, sky, clouds, sunset"},
            {"🌃 Ciudad neón", "cyberpunk city at night, neon lights, rain"},
            {"🐉 Fantasía", "fantasy, magic, epic, dramatic lighting"},
            {"🎨 Acuarela", "watercolor painting, soft colors"},
            {"📷 Foto", "photo, realistic, 35mm, natural light"},
            {"🐱 Animal mono", "cute animal, chibi, kawaii"},
    };

    String modelId;
    int sizeIdx, steps, cfg10, strength;
    EditText prompt, negative, seedIn;
    TextView info, sizeBtn, drawBtn, initInfo;
    ImageView view, initView;
    LinearLayout modelsBox;
    Bitmap result, init;
    SdEngine.Job job;
    boolean running, translating;
    TextView transBtn;
    android.widget.ProgressBar transSpin, drawSpin;

    /** v1.3.3: rueda que gira mientras trabaja (para que se vea que no está colgada). */
    android.widget.ProgressBar spinner() {
        android.widget.ProgressBar pb = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setIndeterminate(true);
        pb.setVisibility(android.view.View.GONE);
        try { pb.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(Neon.DEFAULT_COLOR)); } catch (Exception ignored) {}
        return pb;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        modelId = p.getString("sd_model", "anything5");
        sizeIdx = p.getInt("sd_size", 0);
        LinearLayout col = screen("🎨 ESTUDIO DE DIBUJO");

        // ---- modelos ----
        LinearLayout pm = panel("◢ ESTILO (MODELO)");
        pm.addView(small("Cada estilo es un modelo de IA que se descarga una vez (≈1,3 GB) y luego dibuja sin internet."));
        modelsBox = new LinearLayout(this);
        modelsBox.setOrientation(LinearLayout.VERTICAL);
        pm.addView(modelsBox);
        col.addView(pm, gapBelow(14));

        // ---- qué dibujar ----
        LinearLayout pp = panel("◢ QUÉ DIBUJAR");
        prompt = area(pp, "Describe la imagen (mejor en inglés: «a girl with silver hair in a forest»)", p.getString("sd_prompt", ""));
        // v1.7: contador de fichas (lo que ocupa la descripción) y prompts largos
        TextView tokTv = small("");
        pp.addView(tokTv);
        Runnable tokUpd = () -> {
            String t = prompt.getText().toString();
            int n = SdEngine.tok != null ? SdEngine.tok.countAll(t) : (int) Math.round(t.trim().isEmpty() ? 0 : t.trim().split("[\\s,]+").length * 1.3);
            int chunks = Math.max(1, (n + 74) / 75);
            tokTv.setText((SdEngine.tok != null ? "" : "≈") + n + " " + L.t("fichas") + (chunks > 1 ? " · " + chunks + " " + L.t("trozos (se lee todo)") : " / 75"));
            tokTv.setTextColor(chunks > 4 ? Color.rgb(255, 170, 110) : Color.rgb(150, 160, 185));
        };
        prompt.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence a, int b, int c, int d) {}
            public void onTextChanged(CharSequence a, int b, int c, int d) {}
            public void afterTextChanged(android.text.Editable e) { tokUpd.run(); }
        });
        tokUpd.run();
        pp.addView(small("Truco: pon entre paréntesis lo que más te importa, con un número: (single tulip:1.4). Más de 1,5 suele deformar. "
                + "Lo más importante, al principio. Escribe BREAK para separar ideas (personaje BREAK ropa BREAK fondo): se mezclan menos."), gapBelow(6));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        LinearLayout chips = new LinearLayout(this);
        for (String[] ch : CHIPS) {
            TextView t = button(ch[0], v -> addToPrompt(ch[1]));
            t.setTextSize(12);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dpi(6);
            chips.addView(t, lp);
        }
        hs.addView(chips);
        pp.addView(hs, gapBelow(8));
        transBtn = button("🌐 PASAR AL INGLÉS (con el cerebro de Chloe)", v -> translate());
        pp.addView(transBtn, gapBelow(4));
        transSpin = spinner();
        pp.addView(transSpin, gapBelow(4));
        negative = area(pp, "Lo que NO quieres en la imagen", p.getString("sd_neg", SdEngine.DEFAULT_NEG));
        col.addView(pp, gapBelow(14));

        // ---- v1.4: personajes ----
        LinearLayout pc = panel("◢ PERSONAJES");
        pc.addView(small("Importa un personaje entrenado para Stable Diffusion 1.5 (archivo .safetensors o .pt, lo que llaman «embedding» o «textual inversion»). Luego escribe su nombre en la descripción. Los LoRA no sirven en el móvil."));
        charsBox = new LinearLayout(this);
        charsBox.setOrientation(LinearLayout.VERTICAL);
        pc.addView(charsBox, gapBelow(6));
        pc.addView(button("➕ IMPORTAR PERSONAJE", v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, L.t("Elige el archivo del personaje")), REQ_CHAR);
        }));
        TextView use = small("Para ti o para fan art sin ánimo de lucro. Si publicas algo, márcalo como hecho con IA.");
        use.setTextSize(10);
        pc.addView(use);
        col.addView(pc, gapBelow(14));
        refreshChars();

        // ---- ajustes ----
        LinearLayout pa = panel("◢ AJUSTES");
        sizeBtn = button("", v -> { sizeIdx = (sizeIdx + 1) % SIZES.length; p.edit().putInt("sd_size", sizeIdx).apply(); labels(); });
        pa.addView(sizeBtn, gapBelow(6));
        steps = p.getInt("sd_steps", 20);
        slider(pa, "Pasos (más = más detalle y más lento)", "sd_steps", 20, 4, 40, "", v -> steps = v);
        cfg10 = p.getInt("sd_cfg", 7);
        slider(pa, "Cuánto obedece al texto", "sd_cfg", 7, 1, 14, "", v -> cfg10 = v);
        seedIn = new EditText(this);
        seedIn.setHint(L.t("Semilla (vacía = al azar; repite una para rehacer igual)"));
        seedIn.setInputType(InputType.TYPE_CLASS_NUMBER);
        seedIn.setTextColor(Color.WHITE);
        seedIn.setHintTextColor(Color.GRAY);
        seedIn.setTextSize(13);
        seedIn.setBackground(frame(10));
        seedIn.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        pa.addView(seedIn, gapBelow(6));
        // v1.7
        android.widget.Switch prec = neonSwitch("📖 Lector de texto preciso (lee todo el prompt)");
        prec.setChecked(SdEngine.preciseText(this));
        prec.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("sd_te_float", on).apply());
        pa.addView(prec);
        pa.addView(small("El lector de texto de estos modelos venía comprimido y se quedaba con las primeras palabras. Con esto lee sin comprimir "
                + "(apenas más lento, ocupa ≈0,4 GB más de memoria mientras dibuja). Apágalo y repite con la misma semilla para comparar."), gapBelow(6));
        android.widget.Switch coolSw = neonSwitch("🌡 Modo fresco (más lento, el móvil no se calienta)");
        coolSw.setChecked(Thermal.on(this));
        coolSw.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("sd_cool", on).apply());
        pa.addView(coolSw);
        pa.addView(small("Usa menos núcleos y descansa entre pasos; si la batería pasa de 40 °C se para hasta que baje a 36 °C y sigue sola. "
                + "Vale también para ampliar vídeos."), gapBelow(6));
        col.addView(pa, gapBelow(14));

        // ---- a partir de una imagen ----
        LinearLayout pi = panel("◢ A PARTIR DE UNA IMAGEN (opcional)");
        initInfo = small("Usa una foto o dibujo tuyo como base: la IA lo redibuja con tu descripción.");
        pi.addView(initInfo);
        LinearLayout row = new LinearLayout(this);
        row.addView(button("🖼 ELEGIR", v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, L.t("Elige una imagen")), REQ_INIT);
        }), new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(button("✖ QUITAR", v -> { init = null; initView.setImageBitmap(null); initView.setVisibility(android.view.View.GONE); }), new LinearLayout.LayoutParams(0, -2, 1));
        pi.addView(row, gapBelow(6));
        pi.addView(button("🌑 BASE OSCURA CON UN RAYO DE LUZ", v -> darkBase()), gapBelow(6));
        initView = new ImageView(this);
        initView.setAdjustViewBounds(true);
        initView.setVisibility(android.view.View.GONE);
        pi.addView(initView, new LinearLayout.LayoutParams(-1, dpi(140)));
        strength = p.getInt("sd_strength", 60);
        slider(pi, "Cuánto cambia (poco = se parece más a la tuya)", "sd_strength", 60, 20, 95, " %", v -> strength = v);
        col.addView(pi, gapBelow(14));

        // ---- dibujar ----
        LinearLayout pd = panel("◢ RESULTADO");
        drawBtn = button("✨ DIBUJAR", v -> { if (running) stop(); else draw(); });
        pd.addView(drawBtn, gapBelow(4));
        drawSpin = spinner();
        pd.addView(drawSpin, gapBelow(4));
        info = small("Elige un estilo, describe la imagen y pulsa DIBUJAR. En tu POCO tarda alrededor de un minuto.");
        pd.addView(info, gapBelow(6));
        view = new ImageView(this);
        view.setAdjustViewBounds(true);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pd.addView(view, new LinearLayout.LayoutParams(-1, dpi(360)));
        LinearLayout r2 = new LinearLayout(this);
        r2.addView(button("💾 GUARDAR", v -> save(result, "SSS_dibujo_")), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(button("🔍 AMPLIAR ×2", v -> upscale()), new LinearLayout.LayoutParams(0, -2, 1));
        pd.addView(r2, gapBelow(6));
        pd.addView(button("🔁 USAR COMO BASE", v -> {
            if (result == null) { toast(L.t("Primero dibuja algo.")); return; }
            init = result; initView.setImageBitmap(init); initView.setVisibility(android.view.View.VISIBLE);
            toast(L.t("Listo: ahora cambia la descripción y vuelve a DIBUJAR."));
        }), gapBelow(6));
        TextView lic = small("Modelos con licencia CreativeML OpenRAIL-M: no se pueden usar para hacer daño, engañar ni para imágenes de personas reales sin permiso.");
        lic.setTextSize(10);
        pd.addView(lic);
        col.addView(pd, gapBelow(14));

        labels();
        refreshModels();
        h.postDelayed(tick, 1500);
    }

    final Runnable tick = new Runnable() {
        public void run() {
            if (isFinishing()) return;
            boolean any = false;
            for (String[] m : SdEngine.MODELS) if (SdEngine.prefs(DrawStudioActivity.this).contains("sd_dl_" + m[0]) || FastDownload.running(m[0])) any = true;
            if (!any && wasRunning) refreshModels();             // acaba de terminar
            wasRunning = FastDownload.runningId != null;
            if (any) refreshModels();
            h.postDelayed(this, 2000);
        }
    };

    boolean wasRunning;

    TextView small(String s) {
        TextView t = text(s, 12);
        t.setTextColor(Color.rgb(170, 180, 200));
        return t;
    }

    EditText area(LinearLayout pn, String hint, String val) {
        EditText e = new EditText(this);
        e.setHint(L.t(hint));
        e.setText(val);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setTextSize(14);
        e.setMinLines(2);
        e.setMaxLines(6);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setBackground(frame(10));
        e.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        pn.addView(e, gapBelow(8));
        return e;
    }

    /**
     * v1.3.6: el modelo del móvil (SD 1.5) casi no sabe hacer imágenes muy oscuras: tiende a un brillo «medio».
     * Partiendo de una base negra con un rayo de luz que cae en el centro, sí respeta la oscuridad.
     */
    void darkBase() {
        int w = Integer.parseInt(SIZES[sizeIdx][1]), hh = Integer.parseInt(SIZES[sizeIdx][2]);
        Bitmap b = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(b);
        c.drawColor(Color.rgb(4, 4, 8));
        android.graphics.Paint p2 = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        // rayo: de arriba a la izquierda hacia el centro-abajo
        android.graphics.Path ray = new android.graphics.Path();
        ray.moveTo(w * 0.30f, 0); ray.lineTo(w * 0.42f, 0); ray.lineTo(w * 0.58f, hh * 0.72f); ray.lineTo(w * 0.44f, hh * 0.72f); ray.close();
        p2.setShader(new android.graphics.LinearGradient(0, 0, 0, hh * 0.72f, Color.argb(30, 255, 240, 200), Color.argb(150, 255, 235, 180), android.graphics.Shader.TileMode.CLAMP));
        p2.setMaskFilter(new android.graphics.BlurMaskFilter(w * 0.04f, android.graphics.BlurMaskFilter.Blur.NORMAL));
        c.drawPath(ray, p2);
        // charco de luz donde cae
        p2.setShader(new android.graphics.RadialGradient(w * 0.51f, hh * 0.74f, w * 0.16f, Color.argb(190, 255, 240, 190), Color.argb(0, 255, 240, 190), android.graphics.Shader.TileMode.CLAMP));
        p2.setMaskFilter(null);
        c.drawCircle(w * 0.51f, hh * 0.74f, w * 0.16f, p2);
        init = b;
        initView.setImageBitmap(b);
        initView.setVisibility(android.view.View.VISIBLE);
        info.setText(L.t("Base oscura lista. Pon «Cuánto cambia» en 75-85 % y pulsa DIBUJAR: lo importante se dibuja donde cae la luz."));
    }

    void addToPrompt(String s) {
        String t = prompt.getText().toString().trim();
        prompt.setText(t.isEmpty() ? s : t + ", " + s);
        prompt.setSelection(prompt.getText().length());
    }

    void labels() {
        sizeBtn.setText(L.t("Tamaño: ") + L.t(SIZES[sizeIdx][0]));
    }

    void refreshModels() {
        modelsBox.removeAllViews();
        for (String[] m : SdEngine.MODELS) {
            boolean sel = m[0].equals(modelId), ok = SdEngine.ready(this, m[0]);
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dpi(10), dpi(8), dpi(10), dpi(8));
            if (sel) box.setBackground(frame(10));
            TextView t = text((sel ? "● " : "○ ") + m[1], 15);
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            box.addView(t);
            box.addView(small(m[2]));
            box.addView(small(SdEngine.progress(this, m[0])));
            LinearLayout row = new LinearLayout(this);
            if (!sel) row.addView(button("USAR", v -> { modelId = m[0]; p.edit().putString("sd_model", modelId).apply(); refreshModels(); }), new LinearLayout.LayoutParams(0, -2, 1));
            long[] stt = SdEngine.status(this, m[0]);
            if (!ok && (stt == null || stt[0] == android.app.DownloadManager.STATUS_FAILED))
                row.addView(button("⬇ DESCARGAR", v -> {
                    if (FastDownload.runningId != null) { toast(L.t("Espera a que termine la otra descarga.")); return; }
                    SdEngine.startDownload(this, m[0]); h.postDelayed(this::refreshModels, 800); }), new LinearLayout.LayoutParams(0, -2, 1));
            else if (!ok) row.addView(button("✖ CANCELAR", v -> { SdEngine.cancel(this, m[0]); refreshModels(); }), new LinearLayout.LayoutParams(0, -2, 1));
            else row.addView(button("🗑 BORRAR", v -> { SdEngine.delete(this, m[0]); refreshModels(); }), new LinearLayout.LayoutParams(0, -2, 1));
            box.addView(row);
            box.setClickable(true);
            box.setOnClickListener(v -> { modelId = m[0]; p.edit().putString("sd_model", modelId).apply(); refreshModels(); });
            modelsBox.addView(box, gapBelow(6));
        }
    }

    void translate() {
        if (translating) { toast(L.t("Ya estoy traduciendo, espera un momento…")); return; }
        String t = prompt.getText().toString().trim();
        if (t.isEmpty()) { toast(L.t("Primero escribe qué quieres dibujar.")); return; }
        if (!LocalBrain.ready(this)) { toast(L.t("Para traducir, descarga el cerebro de Chloe (pantalla del asistente).")); return; }
        translating = true;
        transBtn.setText(L.t("⏳ TRADUCIENDO… (espera)"));
        transBtn.setAlpha(0.5f);
        transSpin.setVisibility(android.view.View.VISIBLE);
        info.setText(L.t("Traduciendo… la primera vez Chloe tarda unos segundos en despertar."));
        new Thread(() -> {
            String r;
            try {
                r = LocalBrain.generate(this, "You translate image descriptions into short English prompts for Stable Diffusion. "
                        + "Reply ONLY with the English prompt: comma-separated keywords, no explanations, no quotes.", new java.util.ArrayList<>(), t);
                r = r == null ? "" : r.replaceAll("(?s)^.*?:\\s*(?=[a-zA-Z])", "").replace("\"", "").trim();
            } catch (Exception e) { r = ""; }
            LocalBrain.close();                    // libera la memoria para dibujar
            String out = r;
            runOnUiThread(() -> {
                translating = false;
                transBtn.setText(L.t("🌐 PASAR AL INGLÉS (con el cerebro de Chloe)"));
                transBtn.setAlpha(1f);
                transSpin.setVisibility(android.view.View.GONE);
                if (out.isEmpty()) { info.setText(L.t("No he podido traducirlo.")); return; }
                prompt.setText(out);
                info.setText(L.t("Traducido. Ya puedes pulsar DIBUJAR."));
            });
        }, "traducir").start();
    }

    void draw() {
        if (translating) { toast(L.t("Espera a que termine de traducir.")); return; }
        String t = prompt.getText().toString().trim();
        if (t.isEmpty()) { toast(L.t("Describe qué quieres dibujar.")); return; }
        if (!SdEngine.ready(this, modelId)) { toast(L.t("Primero descarga ese estilo (botón DESCARGAR).")); return; }
        p.edit().putString("sd_prompt", t).putString("sd_neg", negative.getText().toString()).apply();
        SdEngine.Job j = new SdEngine.Job();
        j.model = modelId;
        j.prompt = t;
        j.negative = negative.getText().toString();
        j.width = Integer.parseInt(SIZES[sizeIdx][1]);
        j.height = Integer.parseInt(SIZES[sizeIdx][2]);
        boolean lcm = SdEngine.isLcm(modelId);
        j.steps = lcm ? Math.max(4, Math.min(8, steps)) : Math.max(8, steps);
        j.cfg = lcm ? Math.min(8f, Math.max(1f, cfg10)) : cfg10;
        j.strength = strength / 100f;
        j.init = init;
        try { j.seed = seedIn.getText().toString().trim().isEmpty() ? -1 : Long.parseLong(seedIn.getText().toString().trim()); } catch (Exception e) { j.seed = -1; }
        job = j;
        running = true;
        drawBtn.setText(L.t("⏹ PARAR"));
        drawSpin.setVisibility(android.view.View.VISIBLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        new Thread(() -> {
            String err = null;
            Bitmap out = null;
            try {
                out = SdEngine.generate(this, j, (step, msg, prev) -> runOnUiThread(() -> {
                    if (job != j) return;
                    info.setText(msg);
                    if (prev != null) view.setImageBitmap(Bitmap.createScaledBitmap(prev, j.width, j.height, true));
                }));
            } catch (OutOfMemoryError e) {
                err = L.t("No hay memoria suficiente: cierra otras apps o usa el tamaño «Rápida».");
                SdEngine.unload();
            } catch (Throwable e) {
                err = L.t("No he podido dibujar: ") + e.getMessage();
                SdEngine.unload();
            }
            Bitmap done = out;
            String fe = err;
            runOnUiThread(() -> {
                running = false;
                drawSpin.setVisibility(android.view.View.GONE);
                drawBtn.setText(L.t("✨ DIBUJAR"));
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (fe != null) { info.setText(fe); return; }
                if (done == null) { info.setText(L.t("Parado.")); return; }
                result = done;
                view.setImageBitmap(done);
                info.setText(L.t("¡Hecho! Semilla") + " " + j.seed + " · " + L.t("pulsa GUARDAR para tenerla en la galería."));
            });
        }, "dibujar").start();
    }

    void stop() {
        if (job != null) job.cancel = true;
        info.setText(L.t("Parando…"));
    }

    void upscale() {
        if (result == null) { toast(L.t("Primero dibuja algo.")); return; }
        info.setText(L.t("Ampliando…"));
        Bitmap src = result;
        new Thread(() -> {
            try {
                Bitmap big = UpscaleActivity.sharpen(UpscaleActivity.bicubic2x(src), 0.55f);
                runOnUiThread(() -> { result = big; view.setImageBitmap(big); info.setText(big.getWidth() + "×" + big.getHeight() + " · " + L.t("pulsa GUARDAR.")); });
            } catch (OutOfMemoryError e) { runOnUiThread(() -> info.setText(L.t("No hay memoria suficiente para ampliar."))); }
        }, "ampliar").start();
    }

    void save(Bitmap b, String prefix) {
        if (b == null) { toast(L.t("Primero dibuja algo.")); return; }
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, prefix + System.currentTimeMillis() + ".png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (android.os.Build.VERSION.SDK_INT >= 29) v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SSS+");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            try (OutputStream os = getContentResolver().openOutputStream(u)) { b.compress(Bitmap.CompressFormat.PNG, 100, os); }
            toast(L.t("Guardada en Imágenes/SSS+"));
        } catch (Exception e) {
            toast(L.t("No se pudo guardar: ") + e.getMessage());
        }
    }

    void refreshChars() {
        charsBox.removeAllViews();
        java.util.List<SdChars.Char> l = SdChars.all(this);
        if (l.isEmpty()) { charsBox.addView(small(L.t("(ninguno todavía)"))); return; }
        for (SdChars.Char ch : l) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView t = text("🧑‍🎨 " + ch.name, 14);
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(button("✍", v -> addToPrompt(ch.name)), new LinearLayout.LayoutParams(dpi(56), -2));
            row.addView(button("🗑", v -> {
                if (running) { toast(L.t("Espera a que termine de dibujar.")); return; }
                SdChars.remove(this, ch.name); refreshChars();
            }), new LinearLayout.LayoutParams(dpi(56), -2));
            charsBox.addView(row, gapBelow(4));
        }
    }

    /** v1.7: si el archivo es un LoRA, el mensaje que explica para qué modelo es; si no, null. */
    String loraInfo(Uri u) {
        try (InputStream in = getContentResolver().openInputStream(u)) {
            byte[] h8 = new byte[8];
            if (in.read(h8) != 8) return null;
            long n = java.nio.ByteBuffer.wrap(h8).order(java.nio.ByteOrder.LITTLE_ENDIAN).getLong();
            if (n <= 0 || n > 20_000_000L) return null;
            byte[] hb = new byte[(int) n];
            int got = 0, k;
            while (got < n && (k = in.read(hb, got, (int) n - got)) > 0) got += k;
            String h = new String(hb, 0, got, java.nio.charset.StandardCharsets.UTF_8);
            if (!h.contains("lora_") && !h.contains("lora_down") && !h.contains("lora_A") && !h.contains("\"lokr") && !h.contains("hada_")) return null;
            String base;
            String low = h.toLowerCase(java.util.Locale.ROOT);
            boolean xl = low.contains("lora_te2_") || low.contains("\"sdxl") || low.contains("ss_base_model_version\":\"sdxl") || low.contains("pony") || low.contains("illustrious")
                    || low.contains("\"ss_sd_model_name\":\"sd_xl") || h.contains("[2048,") || h.contains(", 2048]") || h.contains(",2048]");
            boolean flux = low.contains("flux") || low.contains("lora_unet_double_blocks") || low.contains("transformer.single_transformer_blocks");
            if (flux) base = L.t("Es para Flux: ese modelo es demasiado grande para el teléfono.");
            else if (xl) base = L.t("Es para SDXL (o Pony / Illustrious, que son de esa familia): esos modelos son demasiado grandes para dibujar en el teléfono.");
            else base = L.t("Es para SD 1.5: ¡ese sí encaja con los modelos del Estudio! El importador de LoRA llegará en una próxima versión.");
            return base + "\n\n" + L.t("Aquí, en «Personajes», solo van los «embeddings» (archivos pequeños, de unos KB).");
        } catch (Exception e) { return null; }
    }

    void importChar(Uri u) {
        String fname = "personaje";
        try (android.database.Cursor k = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (k != null && k.moveToFirst()) fname = k.getString(0);
        } catch (Exception ignored) {}
        // v1.7: ¿es un LoRA? Se mira solo la cabecera del .safetensors (dice para qué modelo es)
        String lora = loraInfo(u);
        if (lora != null) {
            new android.app.AlertDialog.Builder(this).setTitle(L.t("Esto es un LoRA, no un personaje")).setMessage(lora)
                    .setPositiveButton(L.t("Entendido"), null).show();
            return;
        }
        byte[] b;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[65536]; int n; long tot = 0;
            while ((n = in.read(buf)) > 0) { o.write(buf, 0, n); tot += n; if (tot > 50_000_000L) { toast(L.t("Ese archivo es demasiado grande: parece un modelo o un LoRA, no un personaje.")); return; } }
            b = o.toByteArray();
        } catch (Exception e) { toast(L.t("No puedo abrir ese archivo.")); return; }
        EditText name = new EditText(this);
        name.setText(fname.replaceAll("\\.(safetensors|pt|bin)$", "").replace('_', ' ').replace('-', ' '));
        name.setSelectAllOnFocus(true);
        final byte[] data = b;
        final String fn = fname;
        new android.app.AlertDialog.Builder(this)
                .setTitle(L.t("Nombre del personaje"))
                .setMessage(L.t("Es la palabra que escribirás en la descripción para dibujarlo."))
                .setView(name)
                .setPositiveButton(L.t("Guardar"), (d, w) -> {
                    String err = SdChars.add(this, name.getText().toString(), data, fn);
                    if (err != null) toast(err); else { toast(L.t("Personaje guardado. Escribe su nombre en la descripción.")); refreshChars(); }
                })
                .setNegativeButton(L.t("Cancelar"), null)
                .show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CHAR) { if (res == RESULT_OK && data != null && data.getData() != null) importChar(data.getData()); return; }
        if (req != REQ_INIT || res != RESULT_OK || data == null || data.getData() == null) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap b = BitmapFactory.decodeStream(in, null, o);
            if (b == null) { toast(L.t("No puedo abrir esa imagen.")); return; }
            float sc = Math.min(1f, 1024f / Math.max(b.getWidth(), b.getHeight()));
            if (sc < 1f) b = Bitmap.createScaledBitmap(b, Math.round(b.getWidth() * sc), Math.round(b.getHeight() * sc), true);
            init = b;
            initView.setImageBitmap(b);
            initView.setVisibility(android.view.View.VISIBLE);
        } catch (Exception e) {
            toast(L.t("No puedo abrir esa imagen."));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacks(tick);
        if (job != null) job.cancel = true;
    }
}
