package com.aplauso.encuentra;

import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import com.google.mediapipe.tasks.genai.llminference.LlmInference;

import java.io.File;

/**
 * Cerebro de Chloe DENTRO del teléfono (v1.1): sin internet, sin cupos y gratis para siempre.
 * Modelo Qwen2.5 1.5B Instruct (Apache 2.0, de litert-community), ≈1,6 GB, que se descarga una vez.
 * Funciona con MediaPipe LLM Inference de Google. Bloquea: llamar desde un hilo.
 */
public class LocalBrain {
    static final String FILE = "chloe-qwen2.5-1.5b.task";
    static final String URL = "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/"
            + "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task";
    static final long SIZE_MIN = 1_000_000_000L;      // si el archivo pesa menos, está incompleto
    /** El modelo admite 1280 fichas en total (pregunta + respuesta): hay que ser breve. */
    static final int MAX_TOKENS = 1280;

    static LlmInference llm;
    static volatile String loadError = "";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    // ---------------- v1.7: cerebro GRANDE (opcional) ----------------
    static final String BIG_FILE = "chloe-big.task";
    /** Repositorios donde buscar el cerebro grande (misma familia Qwen: mismo formato de chat). */
    static final String[] BIG_REPOS = {"litert-community/Qwen2.5-3B-Instruct", "litert-community/Qwen3-4B"};
    static boolean big(Context c) { return "big".equals(prefs(c).getString("llm_size", "small")); }
    static File smallFile(Context c) { return new File(c.getExternalFilesDir(null), FILE); }
    static File bigFile(Context c) { return new File(c.getExternalFilesDir(null), BIG_FILE); }
    static File file(Context c) { return big(c) ? bigFile(c) : smallFile(c); }
    static long sizeMin(Context c) { return big(c) ? 2_000_000_000L : SIZE_MIN; }
    /** Fichas que admite el modelo elegido (el grande suele admitir más: lo dice su nombre, «ekv4096»). */
    static int maxTokens(Context c) { return big(c) ? prefs(c).getInt("llm_big_ctx", 1280) : MAX_TOKENS; }
    static boolean ready(Context c) {
        File f = file(c);
        return f.exists() && f.length() > sizeMin(c) && status(c) == null;
    }
    static boolean hasSmall(Context c) { return smallFile(c).length() > SIZE_MIN; }
    static boolean hasBig(Context c) { return bigFile(c).length() > 2_000_000_000L; }

    /** Cambia de cerebro (descarga hecha o no). */
    static void choose(Context c, boolean wantBig) {
        if (wantBig == big(c)) return;
        close();
        prefs(c).edit().putString("llm_size", wantBig ? "big" : "small").apply();
    }

    /**
     * Busca en Hugging Face el archivo .task del cerebro grande: {url, ctx, nombre}. Bloquea (red).
     * v1.7.1: si la lista del servidor falla (repositorio movido o cambiado), prueba nombres conocidos uno a uno.
     */
    static String[] resolveBig() throws Exception {
        StringBuilder why = new StringBuilder();
        for (String repo : BIG_REPOS) {
            try {
                org.json.JSONObject o = new org.json.JSONObject(Web.get("https://huggingface.co/api/models/" + repo));
                org.json.JSONArray sib = o.getJSONArray("siblings");
                String best = null; int bestScore = -1, bestCtx = 1280;
                for (int i = 0; i < sib.length(); i++) {
                    String f = sib.getJSONObject(i).optString("rfilename");
                    if (!f.endsWith(".task") || f.contains("/")) continue;
                    String fl = f.toLowerCase(java.util.Locale.ROOT);
                    if (fl.contains("web") || fl.contains("gpu_only")) continue;
                    int ctx = ctxOf(f);
                    int sc = (fl.contains("q8") ? 10000 : fl.contains("q4") ? 5000 : 0) + Math.min(ctx, 4096);
                    if (sc > bestScore) { bestScore = sc; best = f; bestCtx = ctx; }
                }
                if (best != null) return new String[]{"https://huggingface.co/" + repo + "/resolve/main/" + best, String.valueOf(Math.min(bestCtx, 4096)), best};
                why.append(repo).append(": ").append(L.t("sin archivo .task")).append(". ");
            } catch (Exception e) { why.append(repo).append(": ").append(e instanceof java.io.FileNotFoundException ? L.t("no está") : e.getMessage()).append(". "); }
            // nombres conocidos (por si la lista falla)
            String base = repo.substring(repo.indexOf('/') + 1);
            for (String suf : new String[]{"_multi-prefill-seq_q8_ekv4096.task", "_multi-prefill-seq_q8_ekv2048.task", "_multi-prefill-seq_q8_ekv1280.task"}) {
                String url = "https://huggingface.co/" + repo + "/resolve/main/" + base + suf;
                if (exists(url)) return new String[]{url, String.valueOf(ctxOf(suf)), base + suf};
            }
        }
        throw new Exception(L.t("no encuentro el cerebro grande en el servidor (puede que lo hayan movido). Puedes importar un archivo .task con el botón 📥.") + " [" + why.toString().trim() + "]");
    }

    static int ctxOf(String f) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("ekv(\\d+)").matcher(f);
        return m.find() ? Integer.parseInt(m.group(1)) : 1280;
    }

    /** ¿Existe ese archivo en el servidor? (petición HEAD, sigue las redirecciones) */
    static boolean exists(String u) {
        try {
            for (int hop = 0; hop < 5; hop++) {
                java.net.HttpURLConnection con = (java.net.HttpURLConnection) new java.net.URL(u).openConnection();
                con.setRequestMethod("HEAD");
                con.setInstanceFollowRedirects(false);
                con.setConnectTimeout(8000);
                con.setReadTimeout(8000);
                int code = con.getResponseCode();
                String loc = con.getHeaderField("Location");
                con.disconnect();
                if (code >= 300 && code < 400 && loc != null) { u = new java.net.URL(new java.net.URL(u), loc).toString(); continue; }
                return code == 200;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /** Qwen3 piensa en voz alta (<think>) si no se le dice que no. */
    static boolean qwen3(Context c) { return big(c) && prefs(c).getString("llm_big_name", "").toLowerCase(java.util.Locale.ROOT).contains("qwen3"); }

    /** v1.7.1: cerebro grande desde un archivo .task del teléfono (copiado a su sitio). Bloquea. */
    static void importBig(Context c, Uri u, String name, java.util.function.LongConsumer progress) throws Exception {
        close();
        File f = bigFile(c), tmp = new File(f.getPath() + ".part");
        try (java.io.InputStream in = c.getContentResolver().openInputStream(u); java.io.OutputStream os = new java.io.FileOutputStream(tmp)) {
            byte[] buf = new byte[1 << 20]; int n; long tot = 0, lastRep = 0;
            while ((n = in.read(buf)) > 0) { os.write(buf, 0, n); tot += n; if (tot - lastRep > 50L << 20) { lastRep = tot; progress.accept(tot >> 20); } }
        }
        if (tmp.length() < 500_000_000L) { tmp.delete(); throw new Exception(L.t("ese archivo es demasiado pequeño para ser un cerebro")); }
        f.delete();
        if (!tmp.renameTo(f)) throw new Exception(L.t("no se pudo guardar"));
        prefs(c).edit().putString("llm_size", "big").putString("llm_big_name", name).putInt("llm_big_ctx", Math.min(4096, ctxOf(name))).remove("llm_dl").apply();
    }

    // ---------------- descarga (sigue aunque cierres la app) ----------------
    static void startDownload(Context c) {
        DownloadManager dm = c.getSystemService(DownloadManager.class);
        long old = prefs(c).getLong("llm_dl", -1);
        if (old >= 0) {
            long[] st = status(c);
            if (st != null && (st[0] == DownloadManager.STATUS_RUNNING || st[0] == DownloadManager.STATUS_PENDING
                    || st[0] == DownloadManager.STATUS_PAUSED)) return;
            dm.remove(old);
        }
        File f = file(c);
        if (f.exists()) f.delete();
        String url = URL;
        if (big(c)) {                                        // v1.7: el grande se busca en el servidor (bloquea: se llama desde un hilo)
            try {
                String[] r = resolveBig();
                url = r[0];
                prefs(c).edit().putInt("llm_big_ctx", Integer.parseInt(r[1])).putString("llm_big_name", r[2]).apply();
            } catch (Exception e) { throw new RuntimeException(e.getMessage()); }
        }
        DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url))
                .setTitle(L.t("Cerebro de Chloe (SSS+)"))
                .setDescription(big(c) ? L.t("Cerebro grande para usar sin internet · unos 3 GB") : L.t("Modelo de IA para usar sin internet · 1,6 GB"))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationUri(Uri.fromFile(f))
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false);
        prefs(c).edit().putLong("llm_dl", dm.enqueue(r)).apply();
    }

    /** {estado, MB bajados, MB totales} mientras hay una descarga sin terminar; null si no hay. */
    static long[] status(Context c) {
        long id = prefs(c).getLong("llm_dl", -1);
        if (id < 0) return null;
        DownloadManager dm = c.getSystemService(DownloadManager.class);
        try (android.database.Cursor k = dm.query(new DownloadManager.Query().setFilterById(id))) {
            if (k == null || !k.moveToFirst()) { prefs(c).edit().remove("llm_dl").apply(); return null; }
            int st = k.getInt(k.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            if (st == DownloadManager.STATUS_SUCCESSFUL) { prefs(c).edit().remove("llm_dl").apply(); return null; }
            long got = k.getLong(k.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            long tot = k.getLong(k.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            return new long[]{st, got >> 20, tot >> 20};
        } catch (Exception e) {
            return null;
        }
    }

    static String progress(Context c) {
        long[] st = status(c);
        String which = big(c) ? L.t("Cerebro GRANDE") : L.t("Cerebro NORMAL");
        if (st == null) return which + ": " + (ready(c) ? L.t("✓ descargado. Chloe ya piensa sin internet y sin cupos.") : L.t("aún no está descargado."));
        if (st[0] == DownloadManager.STATUS_FAILED) return L.t("La descarga falló. Vuelve a pulsar DESCARGAR.");
        String mb = st[1] + " / " + (st[2] > 0 ? st[2] + " MB" : "? MB");
        int pc = st[2] > 0 ? (int) (st[1] * 100 / st[2]) : 0;
        if (st[0] == DownloadManager.STATUS_PAUSED) return L.t("Descarga en pausa (esperando wifi o conexión)… ") + mb;
        return L.t("Descargando el cerebro… ") + mb + "  " + pc + " % · " + L.t("puedes salir de la app, sigue sola");
    }

    static void delete(Context c) {
        close();
        long id = prefs(c).getLong("llm_dl", -1);
        if (id >= 0) c.getSystemService(DownloadManager.class).remove(id);
        prefs(c).edit().remove("llm_dl").apply();
        file(c).delete();
    }

    // ---------------- pensar ----------------
    static synchronized boolean load(Context c) {
        if (llm != null) return true;
        if (!ready(c)) return false;
        try {
            LlmInference.LlmInferenceOptions.Builder b = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(file(c).getAbsolutePath())
                    .setMaxTokens(maxTokens(c));
            gpu(b);
            llm = LlmInference.createFromOptions(c.getApplicationContext(), b.build());
            loadError = "";
            return true;
        } catch (Throwable e) {
            loadError = String.valueOf(e.getMessage());
            llm = null;
            return false;
        }
    }

    /** Usa la gráfica del teléfono si esta versión de MediaPipe lo permite (mucho más rápido). */
    static void gpu(LlmInference.LlmInferenceOptions.Builder b) {
        try {
            Class<?> be = Class.forName("com.google.mediapipe.tasks.genai.llminference.LlmInference$Backend");
            Object g = null;
            for (Object o : be.getEnumConstants()) if (o.toString().equals("GPU")) g = o;
            if (g != null) b.getClass().getMethod("setPreferredBackend", be).invoke(b, g);
        } catch (Throwable ignored) {}
    }

    /**
     * v1.6: genera avisando de cada trozo (generateResponseAsync de MediaPipe). Va por reflexión: si esta versión
     * no lo tiene, devuelve null y se hace como siempre.
     */
    static String stream(String prompt, Brain.Partial pl) {
        try {
            Class<?> lc = Class.forName("com.google.mediapipe.tasks.genai.llminference.ProgressListener");
            java.lang.reflect.Method m = llm.getClass().getMethod("generateResponseAsync", String.class, lc);
            final StringBuilder acc = new StringBuilder();
            Object listener = java.lang.reflect.Proxy.newProxyInstance(lc.getClassLoader(), new Class[]{lc}, (proxy, method, args) -> {
                if (method.getName().equals("run") && args != null && args.length >= 1 && args[0] != null) {
                    synchronized (acc) { acc.append(args[0].toString()); }
                    String so;
                    synchronized (acc) { so = acc.toString(); }
                    int e = so.indexOf("<|im_end|>");
                    if (e >= 0) so = so.substring(0, e);
                    try { pl.text(so); } catch (Throwable ignored) {}
                    return null;
                }
                if (method.getName().equals("equals")) return proxy == args[0];
                if (method.getName().equals("hashCode")) return System.identityHashCode(proxy);
                if (method.getName().equals("toString")) return "partial";
                return null;
            });
            Object fut = m.invoke(llm, prompt, listener);
            Object res = fut.getClass().getMethod("get").invoke(fut);
            String full = res == null ? null : res.toString();
            synchronized (acc) { if ((full == null || full.isEmpty()) && acc.length() > 0) full = acc.toString(); }
            return full;
        } catch (Throwable e) {
            return null;
        }
    }

    static synchronized void close() {
        try { if (llm != null) llm.close(); } catch (Throwable ignored) {}
        llm = null;
    }

    /** Responde con el formato de chat de Qwen. null si no se pudo. */
    static synchronized String generate(Context c, String system, java.util.List<String[]> hist, String user) throws Exception {
        return generate(c, system, hist, user, null);
    }

    /** v1.6: con «p» va avisando de lo que lleva escrito (así se ve y se oye antes). */
    static synchronized String generate(Context c, String system, java.util.List<String[]> hist, String user, Brain.Partial pl) throws Exception {
        if (!load(c)) throw new Exception(loadError.isEmpty() ? L.t("el cerebro no está descargado") : loadError);
        StringBuilder p = new StringBuilder();
        p.append("<|im_start|>system\n").append(system).append("<|im_end|>\n");
        // solo lo último de la conversación: el modelo tiene poco espacio
        // v1.6: las 2 últimas idas y vueltas (menos texto = empieza antes); v1.7: con el cerebro grande y más espacio, más
        boolean roomy = maxTokens(c) >= 2048;
        int from = Math.max(0, hist.size() - (roomy ? 10 : 4));
        int cap = roomy ? 400 : 240;
        for (int i = from; i < hist.size(); i++) {
            String[] h = hist.get(i);
            String t = Brain.speech(h[1]);
            if (t.length() > cap) t = t.substring(0, cap);
            p.append("<|im_start|>").append(h[0].equals("model") ? "assistant" : "user").append('\n').append(t).append("<|im_end|>\n");
        }
        p.append("<|im_start|>user\n").append(user).append(qwen3(c) ? " /no_think" : "").append("<|im_end|>\n<|im_start|>assistant\n");
        if (qwen3(c)) p.append("<think>\n\n</think>\n\n");          // v1.7.1: Qwen3 sin «pensar en voz alta»
        String out = pl == null ? null : stream(p.toString(), pl);
        if (out == null) out = llm.generateResponse(p.toString());
        if (out == null) return null;
        int end = out.indexOf("<|im_end|>");
        if (end >= 0) out = out.substring(0, end);
        out = out.replaceAll("(?s)<think>.*?</think>", "").replace("<think>", "").replace("</think>", "");
        return out.replace("<|im_start|>", "").replace("assistant\n", "").trim();
    }
}
