package com.aplauso.encuentra;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Gestor de archivos propio: navegar, abrir, renombrar, copiar/mover, borrar, comprimir y descomprimir ZIP/RAR. */
public class FilesActivity extends NeonActivity {
    static final String[] IMG = {"jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif"};
    static final String[] VID = {"mp4", "mkv", "webm", "3gp", "mov", "avi"};
    static final String[] AUD = {"mp3", "wav", "ogg", "m4a", "aac", "flac", "opus", "amr", "mid"};
    static final String[] M3D = {"stl", "obj"};
    static final String[] M3D_OTHER = {"blend", "fbx", "3ds", "gltf", "glb", "dae", "max", "c4d"};

    File root, dir;
    final List<File> files = new ArrayList<>();
    ListView list;
    TextView path, status, pasteBtn;
    LinearLayout permBox, browser;
    File clip;
    boolean clipCut, showHidden;
    int sort;          // 0 nombre, 1 fecha, 2 tamaño
    final Adapter adapter = new Adapter();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        // permitir abrir archivos con otras apps (file://) sin bibliotecas extra
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        root = Environment.getExternalStorageDirectory();
        dir = root;
        sort = p.getInt("files_sort", 0);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(12), dpi(16), dpi(12), dpi(8));
        col.addView(topBar("ARCHIVOS"), gapBelow(10));

        permBox = panel("◢ PERMISO NECESARIO");
        permBox.addView(text("Para ver y gestionar todos tus archivos, Android exige activar "
                + "\"Acceso a todos los archivos\" para SSS+. Solo se usa dentro del gestor.", 13));
        TextView grant = button("🔓 PERMITIR ACCESO", v -> Media.requestAllFiles(this));
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-1, -2);
        glp.topMargin = dpi(8);
        permBox.addView(grant, glp);
        col.addView(permBox, gapBelow(10));

        browser = new LinearLayout(this);
        browser.setOrientation(LinearLayout.VERTICAL);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = new LinearLayout(this);
        tool(tools, "⬆ SUBIR", v -> up());
        tool(tools, "🏠 INICIO", v -> go(root));
        tool(tools, "📥 DESCARGAS", v -> go(new File(root, "Download")));
        tool(tools, "➕ CARPETA", v -> newFolder());
        pasteBtn = tool(tools, "📋 PEGAR", v -> paste());
        pasteBtn.setVisibility(View.GONE);
        tool(tools, "⇅ ORDENAR", v -> {
            sort = (sort + 1) % 3;
            p.edit().putInt("files_sort", sort).apply();
            toast(new String[]{"Por nombre", "Por fecha", "Por tamaño"}[sort]);
            refresh();
        });
        tool(tools, "👁 OCULTOS", v -> { showHidden = !showHidden; refresh(); });
        hs.addView(tools);
        browser.addView(hs, gapBelow(8));
        path = text("", 12);
        path.setTextColor(Color.rgb(160, 200, 230));
        browser.addView(path, gapBelow(6));
        list = new ListView(this);
        list.setAdapter(adapter);
        list.setDividerHeight(dpi(4));
        list.setOnItemClickListener((pa, v, pos, id) -> open(files.get(pos)));
        list.setOnItemLongClickListener((pa, v, pos, id) -> { options(files.get(pos)); return true; });
        browser.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        status = text("", 12);
        status.setGravity(Gravity.CENTER);
        browser.addView(status);
        col.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(makeRoot(col));
    }

    TextView tool(LinearLayout parent, String label, View.OnClickListener l) {
        TextView t = button(label, l);
        t.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        t.setTextSize(12);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dpi(6);
        parent.addView(t, lp);
        return t;
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean ok = Media.allFiles(this);
        permBox.setVisibility(ok ? View.GONE : View.VISIBLE);
        browser.setVisibility(ok ? View.VISIBLE : View.GONE);
        if (ok) refresh();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (browser.getVisibility() == View.VISIBLE && !dir.equals(root) && dir.getParentFile() != null) up();
        else super.onBackPressed();
    }

    void go(File d) {
        if (d == null || !d.isDirectory()) { toast("Esa carpeta no existe"); return; }
        dir = d;
        refresh();
        list.setSelection(0);
    }

    void up() {
        if (dir.equals(root)) return;
        File par = dir.getParentFile();
        if (par != null) go(par);
    }

    void refresh() {
        files.clear();
        File[] kids = dir.listFiles();
        if (kids != null) for (File k : kids) if (showHidden || !k.getName().startsWith(".")) files.add(k);
        Collections.sort(files, (a, c) -> {
            if (a.isDirectory() != c.isDirectory()) return a.isDirectory() ? -1 : 1;
            if (sort == 1) return Long.compare(c.lastModified(), a.lastModified());
            if (sort == 2 && !a.isDirectory()) return Long.compare(c.length(), a.length());
            return a.getName().compareToIgnoreCase(c.getName());
        });
        adapter.notifyDataSetChanged();
        String shown = dir.getAbsolutePath().replace(root.getAbsolutePath(), "📱 Teléfono");
        path.setText(shown);
        status.setText(L.t(files.size() + " elementos · mantén pulsado para opciones"));
        pasteBtn.setVisibility(clip != null ? View.VISIBLE : View.GONE);
        if (clip != null) pasteBtn.setText(L.t((clipCut ? "📋 MOVER AQUÍ: " : "📋 PEGAR: ") + clip.getName()));
    }

    static boolean is(String e, String[] list) { return Arrays.asList(list).contains(e); }

    static String icon(File f) {
        if (f.isDirectory()) return "📁";
        String e = Archive.ext(f.getName());
        if (is(e, IMG)) return "🖼";
        if (is(e, VID)) return "🎬";
        if (is(e, AUD)) return "🎵";
        if (DocIO.typeOf(f.getName()) != null) return DocsActivity.icon(f.getName());
        if (is(e, M3D) || is(e, M3D_OTHER)) return "🧊";
        if (e.equals("zip") || e.equals("rar") || e.equals("7z")) return "🗜";
        if (e.equals("apk")) return "📦";
        return "📄";
    }

    void open(File f) {
        if (f.isDirectory()) { go(f); return; }
        String e = Archive.ext(f.getName());
        Uri u = Uri.fromFile(f);
        if (is(e, IMG)) startActivity(new Intent(this, PhotoEditorActivity.class).setData(u));
        else if (is(e, VID)) startActivity(new Intent(this, VideoEditorActivity.class).setData(u).putExtra("name", f.getName()));
        else if (is(e, AUD)) startActivity(new Intent(this, AudioEditorActivity.class).setData(u).putExtra("name", f.getName()));
        else if (DocIO.typeOf(f.getName()) != null) startActivity(new Intent(this, DocReaderActivity.class).setData(u));
        else if (is(e, M3D)) startActivity(new Intent(this, Model3DActivity.class).setData(u));
        else if (is(e, M3D_OTHER)) Model3DActivity.explainUnsupported(this, e);
        else if (e.equals("zip") || e.equals("rar")) extract(f);
        else openWith(f);
    }

    void openWith(File f) {
        try {
            String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(Archive.ext(f.getName()));
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.fromFile(f), mime == null ? "*/*" : mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(i, "Abrir con"));
        } catch (Exception ex) {
            toast("Ninguna app puede abrir este archivo");
        }
    }

    void options(File f) {
        List<String> ops = new ArrayList<>();
        ops.add(f.isDirectory() ? "📂 Abrir" : "📂 Abrir");
        ops.add("✏ Renombrar");
        ops.add("📄 Copiar");
        ops.add("✂ Cortar (mover)");
        ops.add("🗑 Eliminar");
        ops.add("🗜 Comprimir en ZIP");
        String e = Archive.ext(f.getName());
        if (e.equals("zip") || e.equals("rar")) ops.add("📦 Descomprimir aquí");
        ops.add("ℹ Detalles");
        if (!f.isDirectory()) ops.add("↗ Abrir con otra app");
        if (DocIO.typeOf(f.getName()) != null) ops.add("📚 Añadir a la biblioteca");
        new AlertDialog.Builder(this).setTitle(L.t(icon(f) + " " + f.getName()))
                .setItems(L.ta(ops.toArray(new String[0])), (d, w) -> {
                    String op = ops.get(w);
                    if (op.startsWith("📂")) open(f);
                    else if (op.startsWith("✏")) rename(f);
                    else if (op.startsWith("📄 Copiar")) { clip = f; clipCut = false; refresh(); toast("Ve a otra carpeta y pulsa PEGAR"); }
                    else if (op.startsWith("✂")) { clip = f; clipCut = true; refresh(); toast("Ve a otra carpeta y pulsa MOVER AQUÍ"); }
                    else if (op.startsWith("🗑")) confirmDelete(f);
                    else if (op.startsWith("🗜")) work("Comprimiendo…", () -> "Creado " + Archive.zip(f, this::progress).getName());
                    else if (op.startsWith("📦")) extract(f);
                    else if (op.startsWith("ℹ")) details(f);
                    else if (op.startsWith("↗")) openWith(f);
                    else if (op.startsWith("📚")) { LibraryActivity.add(this, Uri.fromFile(f), f.getName()); toast("Añadido a tu biblioteca ✓"); }
                }).show();
    }

    // ---------------- acciones ----------------
    interface Job { String run() throws Exception; }

    void progress(String what) { runOnUiThread(() -> status.setText("⏳ " + what)); }

    void work(String msg, Job job) {
        status.setText("⏳ " + msg);
        new Thread(() -> {
            String res;
            try { res = job.run(); } catch (Throwable t) {
                String n = t.getClass().getSimpleName();
                res = n.contains("V5") || String.valueOf(t.getMessage()).contains("RAR5")
                        ? "Este RAR es RAR5 y no se puede abrir aquí. Prueba a convertirlo a ZIP."
                        : "Error: " + (t.getMessage() != null ? t.getMessage() : n);
            }
            String fr = res;
            runOnUiThread(() -> { refresh(); toast(fr); status.setText(fr); });
        }).start();
    }

    void extract(File f) {
        boolean rar = Archive.ext(f.getName()).equals("rar");
        new AlertDialog.Builder(this).setTitle(L.t("Descomprimir"))
                .setMessage(L.t("¿Descomprimir \"" + f.getName() + "\" en una carpeta nueva aquí?"))
                .setPositiveButton(L.t("Descomprimir"), (d, w) -> work("Descomprimiendo…", () -> {
                    File out = rar ? Archive.unrar(f, this::progress) : Archive.unzip(f, this::progress);
                    return "Descomprimido en " + out.getName() + " ✓";
                }))
                .setNegativeButton(L.t("Cancelar"), null).show();
    }

    void paste() {
        if (clip == null) return;
        File src = clip;
        boolean cut = clipCut;
        File dst = Archive.unique(dir, src.getName());
        clip = null;
        work(cut ? "Moviendo…" : "Copiando…", () -> {
            if (cut) Archive.move(src, dst, this::progress);
            else Archive.copy(src, dst, this::progress);
            return (cut ? "Movido" : "Copiado") + " ✓";
        });
    }

    void rename(File f) {
        EditText et = new EditText(this);
        et.setText(f.getName());
        new AlertDialog.Builder(this).setTitle(L.t("Renombrar")).setView(et)
                .setPositiveButton(L.t("OK"), (d, w) -> {
                    String n = et.getText().toString().trim().replaceAll("[\\\\/:*?\"<>|]", "_");
                    if (n.isEmpty()) return;
                    toast(f.renameTo(new File(f.getParentFile(), n)) ? "Renombrado ✓" : "No se pudo renombrar");
                    refresh();
                }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    void newFolder() {
        EditText et = new EditText(this);
        et.setHint(L.t("Nueva carpeta"));
        new AlertDialog.Builder(this).setTitle(L.t("Crear carpeta")).setView(et)
                .setPositiveButton(L.t("Crear"), (d, w) -> {
                    String n = et.getText().toString().trim().replaceAll("[\\\\/:*?\"<>|]", "_");
                    if (n.isEmpty()) n = "Nueva carpeta";
                    toast(Archive.unique(dir, n).mkdirs() ? "Carpeta creada ✓" : "No se pudo crear");
                    refresh();
                }).setNegativeButton(L.t("Cancelar"), null).show();
    }

    void confirmDelete(File f) {
        new AlertDialog.Builder(this).setTitle(L.t("¿Eliminar?"))
                .setMessage(L.t(f.getName() + (f.isDirectory() ? "\n\n⚠ Se borrará la carpeta con todo su contenido." : "")))
                .setPositiveButton(L.t("Eliminar"), (d, w) -> work("Eliminando…", () -> Archive.delete(f) ? "Eliminado ✓" : "No se pudo eliminar todo"))
                .setNegativeButton(L.t("Cancelar"), null).show();
    }

    void details(File f) {
        status.setText(L.t("Calculando…"));
        new Thread(() -> {
            long size = Archive.size(f);
            String msg = "Nombre: " + f.getName() + "\nCarpeta: " + f.getParent()
                    + "\nTamaño: " + SysInfo.bytes(size)
                    + "\nModificado: " + new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date(f.lastModified()));
            runOnUiThread(() -> {
                status.setText("");
                new AlertDialog.Builder(this).setTitle(L.t("Detalles")).setMessage(L.t(msg)).setPositiveButton(L.t("OK"), null).show();
            });
        }).start();
    }

    class Adapter extends BaseAdapter {
        final SimpleDateFormat df = new SimpleDateFormat("dd/MM/yy", Locale.getDefault());
        @Override public int getCount() { return files.size(); }
        @Override public Object getItem(int i) { return files.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            File f = files.get(pos);
            TextView t = convert instanceof TextView ? (TextView) convert : button("", null);
            t.setClickable(false);
            t.setLongClickable(false);
            t.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            t.setTextSize(13);
            String sub;
            if (f.isDirectory()) {
                String[] k = f.list();
                sub = (k == null ? 0 : k.length) + " elementos";
            } else sub = SysInfo.bytes(f.length()) + " · " + df.format(new Date(f.lastModified()));
            t.setText(icon(f) + "  " + f.getName() + "\n      " + sub);
            t.setAlpha(clip != null && clip.equals(f) ? 0.5f : 1f);
            return t;
        }
    }
}
