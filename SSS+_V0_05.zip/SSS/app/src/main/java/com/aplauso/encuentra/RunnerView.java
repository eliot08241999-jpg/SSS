package com.aplauso.encuentra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * GATO RUNNER — un gato corre solo. Salta los ovillos de lana y agáchate ante las chanclas.
 * NIGHTMARE MODE: cada 250 puntos todo se invierte de color y va mucho más rápido durante 100 puntos.
 */
public class RunnerView extends GameKit.GameView implements ArcadeActivity.Backable {
    static final float GROUND = 160, GRAVITY = 1500, JUMP_V = 440;
    static final float BASE_SPEED = 170, MAX_SPEED = 420;
    static final int NIGHTMARE_EVERY = 250, NIGHTMARE_LEN = 100;

    static final int ST_MENU = 0, ST_PLAY = 1, ST_PAUSE = 2, ST_OVER = 3;
    int state = ST_MENU;

    static class Obs {
        int type;          // 0 ovillo, 1 chancla
        float x, y, r, rot, vxExtra;
        int color;
        boolean dead;
    }

    final List<Obs> obs = new ArrayList<>();
    final Random rnd = new Random();
    float catY, catVy, dist, nextSpawn, anim, t;
    boolean ducking, onGround = true;
    int score, nightmares;
    boolean nightmare;
    int nightmareEnd;
    float flash, shake;
    float cloudX, hillX, fenceX;
    boolean newRecord;

    GameKit.Btn bJump, bDuck, bPause;
    Bitmap cat1, cat2, catJump, catDuck1, catDuck2, chancla;
    final Paint invert = new Paint();

    RunnerView(Context c) {
        super(c);
        invert.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(new float[]{
                -1, 0, 0, 0, 255,
                0, -1, 0, 0, 255,
                0, 0, -1, 0, 255,
                0, 0, 0, 1, 0})));
        buildSprites();
    }

    @Override
    void computeScale(int w, int h) {
        scale = h / 200f;
        vh = 200;
        vw = w / scale;
    }

    @Override
    void layout() {
        bDuck = pad.add("⬇ AGACHAR", 8, vh - 58, 8 + vw * 0.32f, vh - 6, 15);
        bJump = pad.add("⬆ SALTAR", vw - 8 - vw * 0.32f, vh - 58, vw - 8, vh - 6, 15);
        bPause = pad.add("⏸", vw - 40, 6, vw - 8, 32, 14);
        showButtons(state == ST_PLAY);
    }

    void showButtons(boolean v) { for (GameKit.Btn b : pad.btns) b.visible = v; }

    void start() {
        obs.clear();
        catY = GROUND; catVy = 0; dist = 0; score = 0; nightmares = 0;
        nightmare = false; ducking = false; onGround = true; newRecord = false;
        nextSpawn = 220;
        setNightmare(false);
        state = ST_PLAY;
        showButtons(true);
        chip.play(Songs.RUNNER);
    }

    void setNightmare(boolean on) {
        nightmare = on;
        chip.harsh = on;
        chip.tempoMul = on ? 1.35f : 1f;
        chip.transpose = on ? -1 : 0;
        chip.intensity = on ? 2 : 1;
    }

    @Override
    void onPauseGame() { if (state == ST_PLAY) state = ST_PAUSE; }

    @Override
    void onResumeGame() { chip.play(Songs.RUNNER); }

    @Override
    public boolean onBack() {
        if (state == ST_PLAY) { state = ST_PAUSE; return true; }
        if (state == ST_PAUSE) { state = ST_PLAY; return true; }
        return false;
    }

    float speed() {
        float s = Math.min(MAX_SPEED, BASE_SPEED + score * 0.06f);
        if (nightmare) s *= 1.45f + 0.05f * (nightmares - 1);
        return s;
    }

    @Override
    void update(float dt) {
        t += dt;
        if (flash > 0) flash -= dt;
        if (shake > 0) shake -= dt;
        if (state != ST_PLAY) return;
        if (bPause.pressed()) { state = ST_PAUSE; return; }

        float sp = speed();
        dist += sp * dt;
        score = (int) (dist / 12);
        anim += dt * sp / 18;
        cloudX = (cloudX + sp * 0.1f * dt) % 400;
        hillX = (hillX + sp * 0.3f * dt) % 300;
        fenceX = (fenceX + sp * dt) % 40;

        // Nightmare Mode
        if (!nightmare && score >= (nightmares + 1) * NIGHTMARE_EVERY) {
            nightmares++;
            nightmareEnd = score + NIGHTMARE_LEN;
            setNightmare(true);
            flash = 0.6f; shake = 0.5f;
            chip.sfx(Chip.SFX_BOOM);
        } else if (nightmare && score >= nightmareEnd) {
            setNightmare(false);
            flash = 0.4f;
            chip.sfx(Chip.SFX_LEVEL);
        }

        // salto y agacharse
        ducking = bDuck.down && onGround;
        if (bJump.pressed() && onGround) {
            catVy = -JUMP_V;
            onGround = false;
            chip.sfx(Chip.SFX_JUMP);
        }
        if (!onGround) {
            float g = GRAVITY * (bDuck.down ? 2.2f : 1f);   // agacharse en el aire = caer rápido
            catVy += g * dt;
            catY += catVy * dt;
            if (catY >= GROUND) { catY = GROUND; catVy = 0; onGround = true; }
        }

        // obstáculos
        nextSpawn -= sp * dt;
        if (nextSpawn <= 0) {
            spawn();
            nextSpawn = 170 + rnd.nextFloat() * 170 + sp * 0.35f;
        }
        float catX = 60, cw = ducking ? 30 : 24, chh = ducking ? 12 : 22;
        for (Iterator<Obs> it = obs.iterator(); it.hasNext(); ) {
            Obs o = it.next();
            o.x -= (sp + o.vxExtra) * dt;
            if (o.type == 0) o.rot += (sp + o.vxExtra) * dt / o.r;
            else o.rot += dt * 9;
            if (o.x < -40) { it.remove(); continue; }
            boolean hit;
            if (o.type == 0) {
                // círculo contra rectángulo (con algo de margen a favor del jugador)
                float nx = GameKit.clamp(o.x, catX + 3, catX + cw - 3);
                float ny = GameKit.clamp(o.y, catY - chh + 3, catY - 1);
                hit = Math.hypot(o.x - nx, o.y - ny) < o.r - 2;
            } else {
                hit = GameKit.overlap(catX + 3, catY - chh + 2, cw - 6, chh - 2, o.x - 12, o.y - 4, 24, 8);
            }
            if (hit) { gameOver(); return; }
        }
    }

    void spawn() {
        boolean chanclaOk = score > 60;
        if (chanclaOk && rnd.nextFloat() < 0.3f + Math.min(0.15f, score / 3000f)) {
            Obs o = new Obs();
            o.type = 1; o.x = vw + 30; o.y = GROUND - 18; o.vxExtra = 90;   // a la altura de la cabeza: agáchate
            obs.add(o);
            return;
        }
        int[] cols = {Color.rgb(255, 110, 170), Color.rgb(90, 170, 255), Color.rgb(255, 210, 70), Color.rgb(140, 230, 120), Color.rgb(190, 120, 255)};
        int n = (score > 150 && rnd.nextFloat() < 0.25f) ? 2 : 1;
        for (int i = 0; i < n; i++) {
            Obs o = new Obs();
            o.type = 0;
            o.r = (n == 2 || rnd.nextFloat() < 0.55f) ? 9 : 14;
            o.x = vw + 30 + i * 26;
            o.y = GROUND - o.r;
            o.vxExtra = 30 + rnd.nextFloat() * 30;
            o.color = cols[rnd.nextInt(cols.length)];
            obs.add(o);
        }
    }

    void gameOver() {
        state = ST_OVER;
        showButtons(false);
        shake = 0.4f;
        chip.sfx(Chip.SFX_HURT);
        setNightmare(false);
        chip.silence();
        int best = prefs().getInt("best_runner", 0);
        if (score > best) { prefs().edit().putInt("best_runner", score).apply(); newRecord = true; }
    }

    // =====================================================================
    // Dibujo
    // =====================================================================
    @Override
    void render(Canvas c) {
        int neon = Neon.color(getContext());
        float sx = shake > 0 ? (rnd.nextFloat() - 0.5f) * 6 : 0;
        if (nightmare) c.saveLayer(0, 0, vw, vh, invert);
        else c.save();
        c.translate(sx, 0);
        drawScene(c);
        c.restore();

        if (flash > 0) {
            p.setColor(Color.argb((int) (Math.min(1, flash) * 200), 255, 255, 255));
            c.drawRect(0, 0, vw, vh, p);
        }
        // marcador
        textLeft(c, "PUNTOS " + score, 10, 20, 13, nightmare ? Color.rgb(255, 40, 60) : Color.rgb(40, 40, 60));
        textLeft(c, "RÉCORD " + prefs().getInt("best_runner", 0), 10, 36, 10, nightmare ? Color.rgb(255, 120, 120) : Color.rgb(70, 70, 90));
        if (nightmare) {
            if (((int) (t * 4)) % 2 == 0) text(c, "☠ NIGHTMARE MODE ☠", vw / 2, 24, 16, Color.rgb(255, 30, 50));
            text(c, "aguanta " + Math.max(0, nightmareEnd - score) + " puntos", vw / 2, 38, 10, Color.rgb(255, 120, 120));
        } else if (state == ST_PLAY) {
            int next = (nightmares + 1) * NIGHTMARE_EVERY - score;
            if (next < 40) text(c, "⚠ Nightmare en " + next, vw / 2, 24, 12, Color.rgb(200, 40, 60));
        }
        pad.draw(c, nightmare ? Color.rgb(255, 40, 60) : neon);

        if (state == ST_MENU) {
            overlay(c);
            text(c, "GATO RUNNER", vw / 2, 60, 30, Color.WHITE);
            text(c, "Salta los ovillos 🧶 · agáchate ante las chanclas", vw / 2, 82, 11, Color.WHITE);
            text(c, "Cada " + NIGHTMARE_EVERY + " puntos: NIGHTMARE MODE", vw / 2, 98, 11, Color.rgb(255, 90, 110));
            text(c, "Récord: " + prefs().getInt("best_runner", 0), vw / 2, 116, 13, neon);
            if (menuButton(c, new RectF(vw / 2 - 90, 128, vw / 2 + 90, 160), "▶ JUGAR", neon)) start();
            if (menuButton(c, new RectF(vw / 2 - 90, 166, vw / 2 + 90, 192), "SALIR", neon)) ((android.app.Activity) getContext()).finish();
        } else if (state == ST_PAUSE) {
            overlay(c);
            text(c, "PAUSA", vw / 2, 56, 26, Color.WHITE);
            if (menuButton(c, new RectF(vw / 2 - 95, 72, vw / 2 + 95, 102), "▶ SEGUIR", neon)) { state = ST_PLAY; pad.releaseAll(); }
            if (menuButton(c, new RectF(vw / 2 - 95, 108, vw / 2 - 3, 136), Chip.musicOn(getContext()) ? "🎵 SÍ" : "🎵 NO", neon)) chip.toggleMusic();
            if (menuButton(c, new RectF(vw / 2 + 3, 108, vw / 2 + 95, 136), Chip.sfxOn(getContext()) ? "🔊 SÍ" : "🔊 NO", neon)) chip.toggleSfx();
            if (menuButton(c, new RectF(vw / 2 - 95, 142, vw / 2 + 95, 172), "SALIR", neon)) ((android.app.Activity) getContext()).finish();
        } else if (state == ST_OVER) {
            overlay(c);
            text(c, "¡MIAU! TE DIERON", vw / 2, 58, 24, Color.WHITE);
            text(c, "Puntos: " + score + (newRecord ? "  ★ ¡NUEVO RÉCORD!" : ""), vw / 2, 80, 14, newRecord ? Color.rgb(255, 220, 80) : Color.WHITE);
            text(c, "Nightmares superados: " + Math.max(0, nightmares - (nightmare ? 1 : 0)), vw / 2, 96, 11, Color.rgb(255, 140, 150));
            if (menuButton(c, new RectF(vw / 2 - 90, 110, vw / 2 + 90, 142), "↻ OTRA VEZ", neon)) start();
            if (menuButton(c, new RectF(vw / 2 - 90, 150, vw / 2 + 90, 178), "SALIR", neon)) ((android.app.Activity) getContext()).finish();
        }
    }

    void overlay(Canvas c) {
        p.setColor(Color.argb(170, 0, 0, 0));
        c.drawRect(0, 0, vw, vh, p);
    }

    void drawScene(Canvas c) {
        // cielo
        p.setShader(new LinearGradient(0, 0, 0, GROUND, Color.rgb(120, 200, 255), Color.rgb(255, 210, 170), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, vw, GROUND, p);
        p.setShader(null);
        // sol
        p.setColor(Color.rgb(255, 230, 90));
        c.drawCircle(vw - 70, 44, 18, p);
        p.setColor(Color.argb(80, 255, 230, 90));
        c.drawCircle(vw - 70, 44, 26, p);
        // nubes
        p.setColor(Color.WHITE);
        for (int i = 0; i < 4; i++) {
            float x = ((i * 140 - cloudX) % (vw + 100) + vw + 100) % (vw + 100) - 50;
            float y = 30 + (i % 2) * 18;
            c.drawRoundRect(x, y, x + 46, y + 12, 6, 6, p);
            c.drawRoundRect(x + 10, y - 7, x + 34, y + 6, 6, 6, p);
        }
        // colinas
        p.setColor(Color.rgb(110, 200, 120));
        for (int i = -1; i < vw / 150 + 2; i++) {
            float x = i * 150 - hillX * 0.5f % 150;
            c.drawCircle(x + 75, GROUND + 20, 70, p);
        }
        p.setColor(Color.rgb(80, 175, 95));
        for (int i = -1; i < vw / 110 + 2; i++) {
            float x = i * 110 - hillX % 110;
            c.drawCircle(x + 40, GROUND + 26, 46, p);
        }
        // valla
        p.setColor(Color.rgb(230, 200, 150));
        c.drawRect(0, GROUND - 22, vw, GROUND - 19, p);
        for (float x = -fenceX; x < vw; x += 40) c.drawRect(x, GROUND - 28, x + 5, GROUND, p);
        // suelo
        p.setColor(Color.rgb(110, 200, 80));
        c.drawRect(0, GROUND, vw, GROUND + 6, p);
        p.setColor(Color.rgb(170, 120, 70));
        c.drawRect(0, GROUND + 6, vw, vh, p);
        p.setColor(Color.rgb(150, 100, 60));
        for (float x = -fenceX * 1.0f; x < vw; x += 20) c.drawRect(x, GROUND + 14, x + 8, GROUND + 17, p);

        // obstáculos
        for (Obs o : obs) {
            if (o.type == 0) drawYarn(c, o);
            else {
                c.save();
                c.rotate((float) Math.toDegrees(o.rot) % 360, o.x, o.y);
                GameKit.draw(c, chancla, o.x - 13, o.y - 6, 26, 12);
                c.restore();
            }
        }
        // gato
        Bitmap b;
        if (!onGround) b = catJump;
        else if (ducking) b = ((int) anim) % 2 == 0 ? catDuck1 : catDuck2;
        else b = ((int) anim) % 2 == 0 ? cat1 : cat2;
        if (ducking) GameKit.draw(c, b, 54, catY - 12, 46, 12);
        else GameKit.draw(c, b, 54, catY - 24, 34, 24);
    }

    void drawYarn(Canvas c, Obs o) {
        p.setColor(Color.argb(60, 0, 0, 0));
        c.drawOval(o.x - o.r, GROUND - 2, o.x + o.r, GROUND + 3, p);
        p.setColor(o.color);
        c.drawCircle(o.x, o.y, o.r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f);
        int dark = Color.rgb((int) (Color.red(o.color) * 0.7f), (int) (Color.green(o.color) * 0.7f), (int) (Color.blue(o.color) * 0.7f));
        p.setColor(dark);
        for (int i = 0; i < 3; i++) {
            double a = o.rot + i * Math.PI / 3;
            float dx = (float) Math.cos(a) * o.r * 0.95f, dy = (float) Math.sin(a) * o.r * 0.95f;
            c.drawLine(o.x - dx, o.y - dy, o.x + dx, o.y + dy, p);
        }
        c.drawCircle(o.x, o.y, o.r * 0.55f, p);
        p.setStyle(Paint.Style.FILL);
        // hilo suelto
        p.setColor(o.color);
        c.drawRect(o.x + o.r - 1, GROUND - 1.5f, o.x + o.r + 8, GROUND, p);
    }

    void buildSprites() {
        String k = "oOwkpg";
        int[] col = {0xffff9a3a, 0xffd06a18, 0xffffffff, 0xff202020, 0xffff8ab0, 0xff60d060};
        cat1 = GameKit.sprite(new String[]{
                "..............o.o",
                "..............ooo",
                ".o...........okok",
                "o............oooo",
                "o..oOoOoOoOooopo.",
                ".ooOoOoOoOoOooo..",
                "..ooooooooooooo..",
                "..owooooooowoo...",
                "..oo.oo...oo.oo..",
                "..o...o...o...o..",
                ".kk..kk..kk..kk..",
                "................."}, k, col);
        cat2 = GameKit.sprite(new String[]{
                "..............o.o",
                "..............ooo",
                "o............okok",
                ".o...........oooo",
                ".o.oOoOoOoOooopo.",
                "..ooOoOoOoOoOoo..",
                "..ooooooooooooo..",
                "..owooooooowoo...",
                "...oo.oo.oo.oo...",
                "....o..o.o..o....",
                "...kk.kk.kk.kk...",
                "................."}, k, col);
        catJump = GameKit.sprite(new String[]{
                "..............o.o",
                "o.............ooo",
                ".o...........okok",
                "..o..........oooo",
                "..ooOoOoOoOooopo.",
                "..ooOoOoOoOoOoo..",
                "...oooooooooooo..",
                "..owwoooooowwo...",
                ".oo..........oo..",
                "kk............kk.",
                "................",
                "................."}, k, col);
        catDuck1 = GameKit.sprite(new String[]{
                "....................o.o",
                "o...................ooo",
                ".ooOoOoOoOoOoOoOoooookok",
                "..ooooooooooooooooooopoo",
                "..owoooooooooooowooooo..",
                "..kk.kk.........kk.kk..."}, k, col);
        catDuck2 = GameKit.sprite(new String[]{
                "....................o.o",
                ".o..................ooo",
                "o.ooOoOoOoOoOoOoOoooookok",
                "..ooooooooooooooooooopoo",
                "..owoooooooooooowooooo..",
                "...kk.kk.......kk.kk...."}, k, col);
        chancla = GameKit.sprite(new String[]{
                "......gg........",
                ".....g..g.......",
                "bbbbgbbbbgbbbbb.",
                "bwwwwwwwwwwwwwbb",
                "bbbbbbbbbbbbbbb.",
                ".bbbbbbbbbbbbb.."}, "gbw", new int[]{0xff20c060, 0xff2070e0, 0xff90d0ff});
    }
}
