package com.aplauso.encuentra;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Modelo 3D en triángulos sueltos (x,y,z por vértice). Lee STL (texto o binario) y OBJ. */
public class Mesh3D {
    float[] v = new float[0];      // 9 floats por triángulo
    int tris;
    int originalTris;
    float sizeX, sizeY, sizeZ;     // tamaño real antes de normalizar

    static final int MAX_TRIS = 150_000;

    static Mesh3D load(byte[] data, String name) throws IOException {
        String n = name.toLowerCase(Locale.ROOT);
        Mesh3D m;
        if (n.endsWith(".obj")) m = parseObj(new String(data, StandardCharsets.UTF_8));
        else m = isBinaryStl(data) ? parseStlBinary(data) : parseStlAscii(new String(data, StandardCharsets.US_ASCII));
        if (m.tris == 0) throw new IOException("El modelo no tiene triángulos");
        m.normalize();
        return m;
    }

    static boolean isBinaryStl(byte[] d) {
        if (d.length < 84) return false;
        long count = ByteBuffer.wrap(d, 80, 4).order(ByteOrder.LITTLE_ENDIAN).getInt() & 0xffffffffL;
        if (84 + count * 50 == d.length) return true;
        String head = new String(d, 0, Math.min(d.length, 512), StandardCharsets.US_ASCII).trim().toLowerCase(Locale.ROOT);
        return !(head.startsWith("solid") && head.contains("facet"));
    }

    static Mesh3D parseStlBinary(byte[] d) {
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        int count = (int) Math.min((d.length - 84) / 50, b.getInt(80) & 0xffffffffL);
        Mesh3D m = new Mesh3D();
        m.originalTris = count;
        int step = Math.max(1, (count + MAX_TRIS - 1) / MAX_TRIS);
        m.v = new float[(count / step + 1) * 9];
        for (int i = 0; i < count; i += step) {
            int off = 84 + i * 50 + 12;
            for (int k = 0; k < 9; k++) m.v[m.tris * 9 + k] = b.getFloat(off + k * 4);
            m.tris++;
        }
        return m;
    }

    static Mesh3D parseStlAscii(String s) {
        Mesh3D m = new Mesh3D();
        FloatList f = new FloatList();
        int idx = 0;
        while ((idx = s.indexOf("vertex", idx)) >= 0) {
            idx += 6;
            int end = s.indexOf('\n', idx);
            if (end < 0) end = s.length();
            String[] t = s.substring(idx, end).trim().split("\\s+");
            if (t.length >= 3) {
                try { f.add(Float.parseFloat(t[0])); f.add(Float.parseFloat(t[1])); f.add(Float.parseFloat(t[2])); }
                catch (NumberFormatException ignored) {}
            }
        }
        m.tris = f.size / 9;
        m.originalTris = m.tris;
        m.v = f.trim(m.tris * 9);
        m.decimate();
        return m;
    }

    static Mesh3D parseObj(String s) {
        FloatList verts = new FloatList(), out = new FloatList();
        for (String raw : s.split("\n")) {
            String line = raw.trim();
            if (line.startsWith("v ")) {
                String[] t = line.split("\\s+");
                if (t.length >= 4) {
                    try { verts.add(Float.parseFloat(t[1])); verts.add(Float.parseFloat(t[2])); verts.add(Float.parseFloat(t[3])); }
                    catch (NumberFormatException e) { verts.add(0); verts.add(0); verts.add(0); }
                }
            } else if (line.startsWith("f ")) {
                String[] t = line.split("\\s+");
                int nv = verts.size / 3;
                int[] ids = new int[t.length - 1];
                int c = 0;
                for (int i = 1; i < t.length; i++) {
                    String tok = t[i];
                    int slash = tok.indexOf('/');
                    if (slash >= 0) tok = tok.substring(0, slash);
                    try {
                        int k = Integer.parseInt(tok);
                        k = k < 0 ? nv + k : k - 1;
                        if (k >= 0 && k < nv) ids[c++] = k;
                    } catch (NumberFormatException ignored) {}
                }
                for (int i = 1; i + 1 < c; i++) {     // abanico de triángulos
                    int[] tri = {ids[0], ids[i], ids[i + 1]};
                    for (int k : tri) { out.add(verts.a[k * 3]); out.add(verts.a[k * 3 + 1]); out.add(verts.a[k * 3 + 2]); }
                }
            }
        }
        Mesh3D m = new Mesh3D();
        m.tris = out.size / 9;
        m.originalTris = m.tris;
        m.v = out.trim(m.tris * 9);
        m.decimate();
        return m;
    }

    /** Si el modelo es enorme, muestra un triángulo de cada N para que gire con fluidez. */
    void decimate() {
        if (tris <= MAX_TRIS) return;
        int step = (tris + MAX_TRIS - 1) / MAX_TRIS;
        int nt = tris / step;
        float[] nv = new float[nt * 9];
        for (int i = 0; i < nt; i++) System.arraycopy(v, i * step * 9, nv, i * 9, 9);
        v = nv;
        tris = nt;
    }

    /** Centra el modelo y lo escala para que su lado más largo mida 2. */
    void normalize() {
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, minZ = Float.MAX_VALUE;
        float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE, maxZ = -Float.MAX_VALUE;
        for (int i = 0; i < tris * 9; i += 3) {
            minX = Math.min(minX, v[i]); maxX = Math.max(maxX, v[i]);
            minY = Math.min(minY, v[i + 1]); maxY = Math.max(maxY, v[i + 1]);
            minZ = Math.min(minZ, v[i + 2]); maxZ = Math.max(maxZ, v[i + 2]);
        }
        sizeX = maxX - minX; sizeY = maxY - minY; sizeZ = maxZ - minZ;
        float cx = (minX + maxX) / 2, cy = (minY + maxY) / 2, cz = (minZ + maxZ) / 2;
        float s = 2f / Math.max(1e-6f, Math.max(sizeX, Math.max(sizeY, sizeZ)));
        for (int i = 0; i < tris * 9; i += 3) {
            v[i] = (v[i] - cx) * s;
            v[i + 1] = (v[i + 1] - cy) * s;
            v[i + 2] = (v[i + 2] - cz) * s;
        }
    }

    static class FloatList {
        float[] a = new float[1024];
        int size;
        void add(float f) {
            if (size == a.length) a = java.util.Arrays.copyOf(a, a.length * 2);
            a[size++] = f;
        }
        float[] trim(int n) { return java.util.Arrays.copyOf(a, n); }
    }
}
