package com.aplauso.encuentra;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.io.InputStream;
import java.util.Arrays;
import java.util.Locale;

/** Visor 3D de archivos STL y OBJ: gira con un dedo, zoom con dos, sombreado y modo malla. */
public class Model3DActivity extends Activity {
    static final int REQ_OPEN = 70;
    Viewer view;
    Mesh3D mesh;
    String name = "";
    String status = "Cargando…";

    static void explainUnsupported(Context c, String ext) {
        String msg = "blend".equals(ext)
                ? "Los archivos .blend son el formato interno de Blender: es cerrado y muy complejo, así que solo Blender puede abrirlos.\n\n"
                + "Solución: en Blender ve a Archivo → Exportar → STL u OBJ, y abre ese archivo aquí."
                : "El formato ." + ext + " todavía no se puede abrir en SSS+.\n\nExpórtalo como STL u OBJ desde tu programa 3D y ábrelo aquí.";
        new AlertDialog.Builder(c).setTitle(L.t("🧊 Formato ." + ext)).setMessage(L.t(msg)).setPositiveButton(L.t("Entendido"), null).show();
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        view = new Viewer(this);
        setContentView(view);
        Uri u = getIntent().getData();
        if (u != null) load(u);
        else pick();
    }

    void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_OPEN);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_OPEN) return;
        if (res != RESULT_OK || data == null || data.getData() == null) { if (mesh == null) finish(); return; }
        load(data.getData());
    }

    void load(Uri u) {
        name = Media.nameOf(this, u);
        String ext = Archive.ext(name);
        if (!ext.equals("stl") && !ext.equals("obj")) {
            if (Arrays.asList(FilesActivity.M3D_OTHER).contains(ext)) explainUnsupported(this, ext);
            else Toast.makeText(this, L.t("Elige un archivo .stl u .obj"), Toast.LENGTH_LONG).show();
            if (mesh == null) status = "Abre un archivo .stl u .obj";
            view.invalidate();
            return;
        }
        status = "Cargando " + name + "…";
        view.invalidate();
        new Thread(() -> {
            try (InputStream in = getContentResolver().openInputStream(u)) {
                Mesh3D m = Mesh3D.load(DocIO.readAll(in), name);
                runOnUiThread(() -> { mesh = m; status = ""; view.reset(); });
            } catch (Throwable t) {
                runOnUiThread(() -> { status = "No se pudo abrir: " + (t instanceof OutOfMemoryError ? "el modelo es demasiado grande" : t.getMessage()); view.invalidate(); });
            }
        }).start();
    }

    // =====================================================================
    class Viewer extends View {
        final int[] COLORS = {Color.rgb(0, 200, 255), Color.rgb(220, 220, 230), Color.rgb(255, 140, 40), Color.rgb(120, 230, 120), Color.rgb(255, 90, 160), Color.rgb(200, 160, 110)};
        final String[] COLOR_NAMES = {"Cian", "Blanco", "Naranja", "Verde", "Rosa", "Arcilla"};
        float yaw = 0.6f, pitch = -0.4f, zoom = 1f;
        int colorIdx;
        boolean wire, spin, touching;
        float lastX, lastY, pinchD, pinchZ;
        long lastTap;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF[] btn = {new RectF(), new RectF(), new RectF(), new RectF(), new RectF()};
        final String[] LABELS = {"🎨 COLOR", "🕸 MALLA", "🔄 GIRO", "⟲ CENTRAR", "📂 ABRIR"};
        float[] tx = new float[0], ty = new float[0], tz = new float[0], verts = new float[0];
        int[] cols = new int[0];
        long[] order = new long[0];

        Viewer(Context c) {
            super(c);
            setBackgroundColor(Color.rgb(8, 10, 18));
            t.setTypeface(Typeface.DEFAULT_BOLD);
            if (Build.VERSION.SDK_INT < 29) setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        float dp(float v) { return v * getResources().getDisplayMetrics().density; }

        void reset() { yaw = 0.6f; pitch = -0.4f; zoom = 1f; invalidate(); }

        @Override
        protected void onDraw(Canvas c) {
            float W = getWidth(), H = getHeight();
            int neon = Neon.color(getContext());
            t.setColor(Color.WHITE);
            t.setTextSize(dp(16));
            t.setTextAlign(Paint.Align.LEFT);
            c.drawText(L.t("🧊 " + (name.isEmpty() ? "Visor 3D" : name)), dp(14), dp(34), t);
            if (mesh != null) {
                t.setTextSize(dp(11));
                t.setColor(Color.LTGRAY);
                c.drawText(L.t(String.format(Locale.US, "%,d triángulos%s · %.1f × %.1f × %.1f", mesh.originalTris,
                        mesh.tris < mesh.originalTris ? " (se muestran " + String.format(Locale.US, "%,d", mesh.tris) + ")" : "",
                        mesh.sizeX, mesh.sizeY, mesh.sizeZ)), dp(14), dp(54), t);
                drawMesh(c, W, H - dp(80));
                if (spin && !touching) { yaw += 0.012f; postInvalidateOnAnimation(); }
            }
            if (!status.isEmpty()) {
                t.setTextAlign(Paint.Align.CENTER);
                t.setTextSize(dp(15));
                t.setColor(Color.WHITE);
                c.drawText(L.t(status), W / 2, H / 2, t);
            }
            // botones
            float bw = (W - dp(12) * 2 - dp(6) * 4) / 5, by = H - dp(66);
            for (int i = 0; i < 5; i++) {
                btn[i].set(dp(12) + i * (bw + dp(6)), by, dp(12) + i * (bw + dp(6)) + bw, by + dp(52));
                boolean on = (i == 1 && wire) || (i == 2 && spin);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Neon.withAlpha(neon, on ? 120 : 40));
                c.drawRoundRect(btn[i], dp(12), dp(12), p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(2));
                p.setColor(neon);
                c.drawRoundRect(btn[i], dp(12), dp(12), p);
                p.setStyle(Paint.Style.FILL);
                t.setTextAlign(Paint.Align.CENTER);
                t.setTextSize(dp(11));
                t.setColor(Color.WHITE);
                c.drawText(L.t(i == 0 ? "🎨 " + COLOR_NAMES[colorIdx].toUpperCase() : LABELS[i]), btn[i].centerX(), btn[i].centerY() + dp(4), t);
            }
            t.setTextAlign(Paint.Align.LEFT);
        }

        void drawMesh(Canvas c, float W, float H) {
            Mesh3D m = mesh;
            int step = (touching || spin) ? Math.max(1, (m.tris + 29_999) / 30_000) : Math.max(1, (m.tris + 89_999) / 90_000);
            int n = (m.tris + step - 1) / step;
            if (tz.length < n * 3) { tx = new float[n * 3]; ty = new float[n * 3]; tz = new float[n * 3]; }
            if (order.length < n) order = new long[n];
            float cyw = (float) Math.cos(yaw), syw = (float) Math.sin(yaw), cp = (float) Math.cos(pitch), sp = (float) Math.sin(pitch);
            float scale = Math.min(W, H) * 0.36f * zoom, cx = W / 2, cy = dp(60) + (H - dp(60)) / 2;
            float lx = 0.3f, ly = 0.5f, lz = 0.81f;
            int base = COLORS[colorIdx];
            int cnt = 0;
            for (int ti = 0; ti < m.tris; ti += step) {
                float zs = 0;
                for (int k = 0; k < 3; k++) {
                    int o = ti * 9 + k * 3;
                    float x = m.v[o], y = m.v[o + 1], z = m.v[o + 2];
                    float x1 = x * cyw + z * syw, z1 = -x * syw + z * cyw;
                    float y2 = y * cp - z1 * sp, z2 = y * sp + z1 * cp;
                    tx[cnt * 3 + k] = x1; ty[cnt * 3 + k] = y2; tz[cnt * 3 + k] = z2;
                    zs += z2;
                }
                // orden de dibujo: lo más lejano primero
                int depth = Float.floatToIntBits(zs);    // menor z = más lejos
                long key = depth ^ ((depth >> 31) & 0x7fffffff);
                order[cnt] = (((long) key) << 32) | (cnt & 0xffffffffL);
                cnt++;
            }
            Arrays.sort(order, 0, cnt);
            if (wire) {
                int lines = Math.min(cnt, 25_000);
                float[] pts = new float[lines * 12];
                int pi = 0;
                for (int j = cnt - lines; j < cnt; j++) {
                    int i = (int) order[j];
                    for (int k = 0; k < 3; k++) {
                        int a = i * 3 + k, bb = i * 3 + (k + 1) % 3;
                        pts[pi++] = cx + tx[a] * scale; pts[pi++] = cy - ty[a] * scale;
                        pts[pi++] = cx + tx[bb] * scale; pts[pi++] = cy - ty[bb] * scale;
                    }
                }
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(1);
                p.setColor(base);
                c.drawLines(pts, 0, pi, p);
                p.setStyle(Paint.Style.FILL);
                return;
            }
            int vc = cnt * 6;
            if (verts.length < vc) { verts = new float[vc]; cols = new int[vc]; }
            int r0 = Color.red(base), g0 = Color.green(base), b0 = Color.blue(base);
            for (int j = 0; j < cnt; j++) {
                int i = (int) order[j];
                int a = i * 3, bI = a + 1, cI = a + 2;
                float ux = tx[bI] - tx[a], uy = ty[bI] - ty[a], uz = tz[bI] - tz[a];
                float vx = tx[cI] - tx[a], vy = ty[cI] - ty[a], vz = tz[cI] - tz[a];
                float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
                float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                float sh = len > 0 ? Math.abs(nx * lx + ny * ly + nz * lz) / len : 0.5f;
                sh = 0.22f + 0.78f * sh;
                int col = Color.rgb((int) (r0 * sh), (int) (g0 * sh), (int) (b0 * sh));
                for (int k = 0; k < 3; k++) {
                    int src = a + k;
                    verts[j * 6 + k * 2] = cx + tx[src] * scale;
                    verts[j * 6 + k * 2 + 1] = cy - ty[src] * scale;
                    cols[j * 3 + k] = col;
                }
            }
            c.drawVertices(Canvas.VertexMode.TRIANGLES, vc, verts, 0, null, 0, cols, 0, null, 0, 0, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = e.getX(); lastY = e.getY();
                    for (int i = 0; i < 5; i++) if (btn[i].contains(lastX, lastY)) { press(i); return true; }
                    touching = true;
                    long now = System.currentTimeMillis();
                    if (now - lastTap < 300) reset();
                    lastTap = now;
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (e.getPointerCount() >= 2) {
                        pinchD = (float) Math.max(1, Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
                        pinchZ = zoom;
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (e.getPointerCount() >= 2) {
                        float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                        zoom = Math.max(0.2f, Math.min(8f, pinchZ * d / pinchD));
                    } else if (touching) {
                        yaw += (e.getX() - lastX) * 0.01f;
                        pitch = Math.max(-1.55f, Math.min(1.55f, pitch + (e.getY() - lastY) * 0.01f));
                        lastX = e.getX(); lastY = e.getY();
                    }
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    touching = false;
                    invalidate();
                    return true;
            }
            return true;
        }

        void press(int i) {
            switch (i) {
                case 0: colorIdx = (colorIdx + 1) % COLORS.length; break;
                case 1: wire = !wire; break;
                case 2: spin = !spin; break;
                case 3: reset(); break;
                case 4: pick(); break;
            }
            invalidate();
        }
    }
}
