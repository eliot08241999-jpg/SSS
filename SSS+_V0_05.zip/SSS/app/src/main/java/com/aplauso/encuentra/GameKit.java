package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Piezas comunes de los juegos arcade: bucle, botones multitáctiles, sprites de píxeles y texto. */
public class GameKit {

    // ======================================================================
    // Sprites de píxeles: cada carácter es un color de la paleta, '.' = transparente
    // ======================================================================
    static Bitmap sprite(String[] rows, String keys, int[] colors) {
        int h = rows.length, w = 0;
        for (String r : rows) w = Math.max(w, r.length());
        Bitmap b = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        for (int y = 0; y < h; y++) {
            String r = rows[y];
            for (int x = 0; x < w; x++) {
                char ch = x < r.length() ? r.charAt(x) : '.';
                int idx = keys.indexOf(ch);
                b.setPixel(x, y, idx < 0 ? Color.TRANSPARENT : colors[idx]);
            }
        }
        return b;
    }

    static Bitmap flipH(Bitmap b) {
        Matrix m = new Matrix();
        m.preScale(-1, 1);
        return Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, false);
    }

    static final Paint PIX = new Paint();
    static { PIX.setFilterBitmap(false); PIX.setAntiAlias(false); }
    private static final RectF TMP = new RectF();

    /** Dibuja un sprite de píxeles nítido en el rectángulo (x, y, w, h). */
    static void draw(Canvas c, Bitmap b, float x, float y, float w, float h) {
        TMP.set(x, y, x + w, y + h);
        c.drawBitmap(b, null, TMP, PIX);
    }

    static void draw(Canvas c, Bitmap b, float x, float y, float w, float h, Paint p) {
        TMP.set(x, y, x + w, y + h);
        c.drawBitmap(b, null, TMP, p);
    }

    // ======================================================================
    // Botones en pantalla (varios dedos a la vez)
    // ======================================================================
    static class Btn {
        final RectF r = new RectF();
        String label;
        float textSize;
        boolean visible = true, round;
        boolean down;
        int presses;          // pulsaciones desde el último fotograma

        boolean pressed() { return presses > 0; }
    }

    static class Pad {
        final List<Btn> btns = new ArrayList<>();
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);

        Pad() {
            t.setTextAlign(Paint.Align.CENTER);
            t.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        }

        Btn add(String label, float l, float top, float r, float b, float textSize) {
            Btn x = new Btn();
            x.label = label;
            x.r.set(l, top, r, b);
            x.textSize = textSize;
            btns.add(x);
            return x;
        }

        /** Recalcula qué botones están pulsados según todos los dedos. Coordenadas ya divididas por la escala. */
        void touch(MotionEvent e, float scale) {
            int action = e.getActionMasked();
            int upIndex = (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP
                    || action == MotionEvent.ACTION_CANCEL) ? e.getActionIndex() : -1;
            boolean cancel = action == MotionEvent.ACTION_CANCEL;
            for (Btn b : btns) {
                boolean now = false;
                if (b.visible && !cancel) {
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        if (i == upIndex) continue;
                        float x = e.getX(i) / scale, y = e.getY(i) / scale;
                        if (b.r.contains(x, y)) { now = true; break; }
                    }
                }
                if (now && !b.down) b.presses++;
                b.down = now;
            }
        }

        boolean anyAt(float x, float y) {
            for (Btn b : btns) if (b.visible && b.r.contains(x, y)) return true;
            return false;
        }

        void endFrame() { for (Btn b : btns) b.presses = 0; }

        void releaseAll() { for (Btn b : btns) { b.down = false; b.presses = 0; } }

        void draw(Canvas c, int color) {
            for (Btn b : btns) {
                if (!b.visible) continue;
                float rad = b.round ? Math.min(b.r.width(), b.r.height()) / 2 : 10;
                p.setStyle(Paint.Style.FILL);
                p.setColor(b.down ? Neon.withAlpha(color, 110) : Color.argb(70, 0, 0, 0));
                c.drawRoundRect(b.r, rad, rad, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2);
                p.setColor(Neon.withAlpha(color, b.down ? 255 : 150));
                c.drawRoundRect(b.r, rad, rad, p);
                p.setStyle(Paint.Style.FILL);
                t.setTextSize(b.textSize);
                t.setColor(Color.argb(b.down ? 255 : 210, 255, 255, 255));
                Paint.FontMetrics fm = t.getFontMetrics();
                c.drawText(L.t(b.label), b.r.centerX(), b.r.centerY() - (fm.ascent + fm.descent) / 2, t);
            }
        }
    }

    // ======================================================================
    // Vista base con bucle de juego (≈60 fps) y coordenadas virtuales
    // ======================================================================
    abstract static class GameView extends View {
        final Pad pad = new Pad();
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        float scale = 1, vw = 360, vh = 640;   // unidades virtuales
        boolean running;
        private long last;
        boolean tapped;
        float tapX, tapY;
        final Chip chip;

        GameView(Context c) {
            super(c);
            txt.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            txt.setTextAlign(Paint.Align.CENTER);
            chip = new Chip(c);
            L.init(c);
            setKeepScreenOn(true);
        }

        SharedPreferences prefs() { return getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE); }

        /** Define el tamaño virtual: ancho fijo (vertical) o alto fijo (horizontal). */
        abstract void computeScale(int w, int h);
        abstract void layout();
        abstract void update(float dt);
        abstract void render(Canvas c);
        void onPauseGame() {}
        void onResumeGame() {}

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            if (w <= 0 || h <= 0) return;
            computeScale(w, h);
            pad.btns.clear();
            layout();
        }

        void resume() {
            running = true;
            last = System.nanoTime();
            chip.start();
            onResumeGame();
            postInvalidateOnAnimation();
        }

        void pause() {
            running = false;
            pad.releaseAll();
            onPauseGame();
            chip.stop();
        }

        @Override
        protected void onDraw(Canvas c) {
            long now = System.nanoTime();
            float dt = Math.min(0.05f, (now - last) / 1e9f);
            last = now;
            if (running && getWidth() > 0) update(dt);
            c.save();
            c.scale(scale, scale);
            render(c);          // los menús comprueban los toques aquí
            c.restore();
            tapped = false;
            pad.endFrame();
            if (running) postInvalidateOnAnimation();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            pad.touch(e, scale);
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
                int i = e.getActionIndex();
                tapX = e.getX(i) / scale;
                tapY = e.getY(i) / scale;
                tapped = true;
            }
            return true;
        }

        /** ¿Se tocó dentro de este rectángulo en este fotograma? */
        boolean tapIn(RectF r) { return tapped && r.contains(tapX, tapY); }

        // ---------- dibujo de texto y paneles ----------
        void text(Canvas c, String s, float x, float y, float size, int color) {
            txt.setTextSize(size);
            txt.setColor(color);
            c.drawText(L.t(s), x, y, txt);
        }

        void textLeft(Canvas c, String s, float x, float y, float size, int color) {
            txt.setTextAlign(Paint.Align.LEFT);
            text(c, s, x, y, size, color);
            txt.setTextAlign(Paint.Align.CENTER);
        }

        /** Texto con salto de línea automático (traducido); devuelve la y final. */
        float wrap(Canvas c, String s, float x, float y, float maxW, float size, int color, boolean center) {
            return wrapRaw(c, L.t(s), x, y, maxW, size, color, center);
        }

        /** Igual que wrap, pero sin traducir (el texto ya viene traducido). */
        float wrapRaw(Canvas c, String s, float x, float y, float maxW, float size, int color, boolean center) {
            txt.setTextSize(size);
            txt.setColor(color);
            if (!center) txt.setTextAlign(Paint.Align.LEFT);
            for (String para : s.split("\n")) {
                String[] words = para.split(" ");
                StringBuilder line = new StringBuilder();
                for (String w : words) {
                    String test = line.length() == 0 ? w : line + " " + w;
                    if (txt.measureText(test) > maxW && line.length() > 0) {
                        c.drawText(line.toString(), x, y, txt);
                        y += size * 1.3f;
                        line = new StringBuilder(w);
                    } else line = new StringBuilder(test);
                }
                c.drawText(line.toString(), x, y, txt);
                y += size * 1.3f;
            }
            txt.setTextAlign(Paint.Align.CENTER);
            return y;
        }

        void box(Canvas c, RectF r, int color, int fillAlpha) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(fillAlpha, 8, 10, 22));
            c.drawRoundRect(r, 12, 12, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.5f);
            p.setColor(color);
            c.drawRoundRect(r, 12, 12, p);
            p.setStyle(Paint.Style.FILL);
        }

        /** Botón de menú dibujado; devuelve true si se tocó en este fotograma. */
        boolean menuButton(Canvas c, RectF r, String label, int color) {
            box(c, r, color, 200);
            text(c, label, r.centerX(), r.centerY() + 6, 17, Color.WHITE);
            return tapIn(r);
        }
    }

    static float clamp(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }

    static boolean overlap(float ax, float ay, float aw, float ah, float bx, float by, float bw, float bh) {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
    }
}
