package com.aplauso.encuentra;

import java.util.Random;

/**
 * v1.5 · Retoques de la voz de Chloe, sobre el sonido ya hecho (24 kHz):
 * AIRE (los agudos de la voz se vuelven soplo, como en una voz aireada, sin meter ruido en los silencios),
 * S SUAVE (baja las eses que silban), T/D SUAVES (redondea los golpecitos de t, d, p, k), BRILLO y VOLUMEN.
 * Es Java puro para poder probarlo fuera del teléfono.
 */
public class VoiceFx {
    public static final int SR = 24000;
    /** 0..1 */
    public float air, softS, softT;
    /** -1 (cálida) .. 1 (brillante) */
    public float bright;
    /** 1 = normal */
    public float volume = 1;
    final Random rnd = new Random(7);

    static float coef(float ms) { return (float) Math.exp(-1.0 / (SR * ms / 1000.0)); }

    /** Quita el silencio de los extremos (deja un pelín) y devuelve el trozo útil. */
    public static float[] trim(float[] x) {
        int a = 0, b = x.length;
        float th = 0.004f;
        while (a < b && Math.abs(x[a]) < th) a++;
        while (b > a && Math.abs(x[b - 1]) < th) b--;
        a = Math.max(0, a - SR / 50);
        b = Math.min(x.length, b + SR / 25);
        float[] y = new float[b - a];
        System.arraycopy(x, a, y, 0, y.length);
        return y;
    }

    public float[] process(float[] x) {
        int n = x.length;
        float[] y = new float[n];
        // --- cruce a 3 kHz: grave = paso bajo de 2 polos (dos veces, ida y vuelta no: en línea), agudo = resto
        float k = 1 - (float) Math.exp(-2 * Math.PI * 3000 / SR);
        float l1 = 0, l2 = 0;
        // envolventes
        float aF = coef(3), aS = coef(25);
        float eF = 0, eS = 0;                       // rápida y lenta (para t/d)
        float aE = coef(3), rE = coef(35);
        float eH = 0, eL = 0;                       // agudos y graves (para la s)
        float gS = 1, gT = 1, sm = coef(2);
        // ruido lento para volver soplo los agudos, y ruido agudo para la aspiración
        float kn = 1 - (float) Math.exp(-2 * Math.PI * 1400 / SR), nl = 0, nh1 = 0;
        float shelf = (float) Math.pow(10, bright * 6 / 20.0);
        float floorT = 1 - 0.72f * softT;
        for (int i = 0; i < n; i++) {
            float v = x[i];
            // t, d, p, k: cuando el sonido sube de golpe, se frena la subida
            float av = Math.abs(v);
            eF = aF * eF + (1 - aF) * av;                               // media rápida (3 ms) y lenta (25 ms)
            eS = aS * eS + (1 - aS) * av;
            float tg = 1;
            if (softT > 0 && eF > 0.01f && eF > eS) {
                float r = (eS + 0.003f) / (eF + 0.003f);                  // <1 solo mientras el sonido está subiendo
                tg = Math.max(floorT, (float) Math.pow(r, softT * 0.9f));
            }
            gT = sm * gT + (1 - sm) * tg;
            v *= gT;

            l1 += k * (v - l1);
            l2 += k * (l1 - l2);
            float lo = l2, hi = v - l2;

            // s: si mandan los agudos, se bajan
            float ah = Math.abs(hi), al = Math.abs(lo);
            eH = ah > eH ? aE * eH + (1 - aE) * ah : rE * eH + (1 - rE) * ah;
            eL = al > eL ? aE * eL + (1 - aE) * al : rE * eL + (1 - rE) * al;
            float ratio = eH / (eL + 0.003f);
            float u = Math.max(0, Math.min(1, (ratio - 0.4f) / 0.8f));
            u = u * u * (3 - 2 * u);
            float sg = 1 - softS * 0.85f * u;
            gS = sm * gS + (1 - sm) * sg;
            hi *= gS;

            // aire
            if (air > 0) {
                float w = rnd.nextFloat() * 2 - 1;
                nl += kn * (w - nl);                                       // ruido lento (≈ ±0.35 eficaz)
                float soplo = hi * nl * 4.2f;                              // los mismos agudos, pero sin armónicos
                nh1 += k * (w - nh1);
                float asp = (w - nh1) * eL * 0.22f;                        // un poco de aliento que sigue a la voz
                hi = hi * (1 - 0.65f * air) + air * (soplo * 1.1f + asp);
                lo *= 1 - 0.12f * air;
            }
            y[i] = lo + hi * shelf;
        }
        // volumen con tope suave y fundidos en los bordes (sin chasquidos)
        float g = 1.9f * volume;
        int fade = Math.min(n / 2, SR / 200);
        for (int i = 0; i < n; i++) {
            float v = y[i] * g;
            float a = Math.abs(v);
            if (a > 0.7f) v = Math.signum(v) * (0.7f + 0.3f * (float) Math.tanh((a - 0.7f) / 0.3f));
            if (i < fade) v *= i / (float) fade;
            if (n - 1 - i < fade) v *= (n - 1 - i) / (float) fade;
            y[i] = v;
        }
        return y;
    }
}
