package com.aplauso.encuentra;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * ASISTENTE SSS+: Chloe, con su cerebro dentro del teléfono y la voz que tú elijas.
 * - Se abre desde Ajustes, desde su notificación o como "asistente digital" del teléfono (mantener pulsado Inicio).
 * - Con la palabra clave activada ("paradoja"), te escucha aunque la app esté cerrada.
 */
public class AssistActivity extends NeonActivity {
    static final int REQ_SPEAK = 71, REQ_MIC = 72;
    TextView log, modelState, voiceBtn, engineBtn, brainBtn;
    LinearLayout memList;
    TextView heardTv, llmState;

    void openAi(String pkg, String web) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        try {
            if (i != null) startActivity(i);
            else startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(web)));
        } catch (Exception e) { toast(L.t("No se pudo abrir.")); }
    }

    void refreshLlm() { if (llmState != null) llmState.setText(LocalBrain.progress(this)); }
    /** Muestra en vivo lo último que oyó el oído, para ver cómo escribe «Chloe» y ajustar las frases. */
    final Runnable heardTick = new Runnable() {
        @Override public void run() {
            if (heardTv != null) heardTv.setText(Wake.heard.isEmpty() ? "" : L.t("👂 Lo último que oí: ") + Wake.heard);
            refreshLlm();
            h.postDelayed(this, 1000);
        }
    };

    void refreshBrain() {
        String b = Brain.brain(this);
        brainBtn.setText(L.t("Cerebro: ") + (b.equals("pc") ? L.t("solo el portátil")
                : b.equals("local") ? L.t("solo el teléfono (gratis, sin internet)")
                : L.t("automático (portátil si lo tienes; si no, el teléfono)")));
    }

    void refreshMemory() {
        memList.removeAllViews();
        java.util.List<String> l = Memory.all(this);
        if (l.isEmpty()) { memList.addView(text(L.t("(vacía)"), 12)); return; }
        for (int i = 0; i < l.size(); i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(text("• " + l.get(i), 13), new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(button("🗑", v -> { Memory.remove(this, idx); refreshMemory(); }), new LinearLayout.LayoutParams(dpi(52), -2));
            memList.addView(row, gapBelow(4));
        }
    }
    Switch wakeSw;
    ChloeAvatarView av;
    final StringBuilder chat = new StringBuilder();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🐑 ASISTENTE SSS+");
        Voice.init(this, null);

        // ---------- hablar ----------
        LinearLayout talk = panel("◢ HABLAR");
        // v1.4: Chloe en persona (tócala)
        av = new ChloeAvatarView(this);
        av.setOnPoke(line -> { say("🐑", line); Voice.say(this, line); });
        talk.addView(av, new LinearLayout.LayoutParams(-1, dpi(260)));
        // v1.4.1: su aspecto: la conejita (con traje según la estación) o la neón
        LinearLayout look = new LinearLayout(this);
        look.setOrientation(LinearLayout.HORIZONTAL);
        TextView skinB = button("", null), outB = button("", null);
        Runnable lbl = () -> {
            boolean bun = !"neon".equals(p.getString("avatar_skin", "bunny"));
            skinB.setText(bun ? L.t("🐰 Conejita") : L.t("💠 Neón"));
            String o = p.getString("avatar_outfit", "auto");
            int i = java.util.Arrays.asList(Outfit.ALL).indexOf(Outfit.now(this));
            outB.setText(("auto".equals(o) ? L.t("Auto: ") : "") + L.t(Outfit.LABEL[Math.max(0, i)]));
            outB.setAlpha(bun ? 1f : 0.4f);
        };
        skinB.setOnClickListener(v -> { p.edit().putString("avatar_skin", "neon".equals(p.getString("avatar_skin", "bunny")) ? "bunny" : "neon").apply(); av.refreshOutfit(); lbl.run(); });
        outB.setOnClickListener(v -> {
            String[] cyc = {"auto", "autumn", "winter", "spring", "summer"};
            int i = java.util.Arrays.asList(cyc).indexOf(p.getString("avatar_outfit", "auto"));
            p.edit().putString("avatar_outfit", cyc[(i + 1) % cyc.length]).apply();
            av.refreshOutfit(); lbl.run();
        });
        lbl.run();
        LinearLayout.LayoutParams lk = new LinearLayout.LayoutParams(0, -2, 1); lk.rightMargin = dpi(6);
        look.addView(skinB, lk);
        look.addView(outB, new LinearLayout.LayoutParams(0, -2, 1));
        talk.addView(look, gapBelow(8));
        talk.addView(button("⛶ AGRANDAR · CHATEAR CON CHLOE", v -> startActivity(new Intent(this, ChloeChatActivity.class))), gapBelow(8));
        talk.addView(button("🎙 LIVE · HABLAR CON CHLOE SIN MANOS", v -> startActivity(new Intent(this, LiveActivity.class))), gapBelow(8));
        log = text(L.t("Pregúntame lo que quieras. Pienso dentro de tu teléfono y respondo con la voz que elijas abajo."), 14);
        talk.addView(log);
        EditText in = edit("Escribe tu pregunta…", false);
        // v1.4.6: «Enviar» del teclado = enviar la pregunta (antes saltaba a la siguiente casilla)
        in.setSingleLine(true);
        in.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEND);
        in.setOnEditorActionListener((tv, act, ev) -> {
            String q = in.getText().toString().trim();
            if (!q.isEmpty()) { in.setText(""); ask(q); }
            return true;
        });
        talk.addView(spaced(in));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams h1 = new LinearLayout.LayoutParams(0, -2, 1);
        h1.rightMargin = dpi(6);
        row.addView(button("🎤 HABLAR", v -> listen()), h1);
        row.addView(button("➤ ENVIAR", v -> {
            String q = in.getText().toString().trim();
            if (!q.isEmpty()) { in.setText(""); ask(q); }
        }), new LinearLayout.LayoutParams(0, -2, 1));
        talk.addView(spaced(row));
        talk.addView(spaced(button("⏹ CALLAR", v -> Voice.stop())));
        col.addView(talk, gapBelow(14));

        // ---------- v1.1: ir a otras IAs con un toque ----------
        LinearLayout ais = panel("◢ OTRAS IAs");
        ais.addView(text("Abre otra IA con un toque. Si no tienes la app, se abre su web.", 12));
        String[][] list = {
                {"✨ Gemini", "com.google.android.apps.bard", "https://gemini.google.com"},
                {"🧡 Claude", "com.anthropic.claude", "https://claude.ai"},
                {"💬 ChatGPT", "com.openai.chatgpt", "https://chatgpt.com"},
                {"🪁 Copilot", "com.microsoft.copilot", "https://copilot.microsoft.com"},
                {"✖ Grok", "ai.x.grok", "https://grok.com"},
                {"🔎 Perplexity", "ai.perplexity.app.android", "https://www.perplexity.ai"},
                {"🐋 DeepSeek", "com.deepseek.chat", "https://chat.deepseek.com"},
        };
        LinearLayout aiRow = null;
        for (int i = 0; i < list.length; i++) {
            if (i % 2 == 0) {
                aiRow = new LinearLayout(this);
                aiRow.setOrientation(LinearLayout.HORIZONTAL);
                ais.addView(aiRow, gapBelow(8));
            }
            String[] a = list[i];
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i % 2 == 0) lp.rightMargin = dpi(8);
            aiRow.addView(button(a[0], v -> openAi(a[1], a[2])), lp);
        }
        if (list.length % 2 == 1) aiRow.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        col.addView(ais, gapBelow(14));

        // ---------- v1.1: identidad ----------
        LinearLayout id = panel("◢ TU ASISTENTE");
        id.addView(text("Nombre del asistente", 12));
        id.addView(edit(Brain.DEFAULT_NAME, false, "ai_bot_name"));
        id.addView(spaced(text("Personalidad: cómo habla y cómo te trata. (Las reglas de no inventar datos van aparte y siempre se cumplen.)", 12)));
        EditText per = edit(Brain.DEFAULT_PERSONA, false, "ai_persona");
        per.setMinLines(3);
        per.setSingleLine(false);
        id.addView(per);
        Switch web = neonSwitch("Buscar en internet para responder (sin pasar por Google)");
        web.setChecked(Brain.search(this));
        web.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("ai_search", on).apply());
        id.addView(web);
        id.addView(text("Con esto, las preguntas de datos (quién, cuándo, cuánto, noticias…) se buscan antes de responder, "
                + "para que no se invente nada y te diga de dónde lo saca.", 11));
        col.addView(id, gapBelow(14));

        // ---------- v1.1: memoria ----------
        LinearLayout mem = panel("◢ MEMORIA");
        mem.addView(text("Lo que le enseñas. También por voz: «recuerda que…», «olvida…», «¿qué recuerdas?».", 12));
        memList = new LinearLayout(this);
        memList.setOrientation(LinearLayout.VERTICAL);
        mem.addView(memList);
        EditText memIn = edit("Algo que deba recordar…", false);
        mem.addView(spaced(memIn));
        mem.addView(spaced(button("➕ AÑADIR A LA MEMORIA", v -> {
            String t = memIn.getText().toString().trim();
            if (t.isEmpty()) return;
            Memory.add(this, t);
            memIn.setText("");
            refreshMemory();
        })));
        col.addView(mem, gapBelow(14));
        refreshMemory();

        // ---------- v1.1: cerebro en el teléfono ----------
        LinearLayout lb = panel("◢ CEREBRO EN EL TELÉFONO (gratis, sin cupos)");
        lb.addView(text("Chloe piensa dentro de tu teléfono, sin internet y sin límites de preguntas. Se descarga una vez "
                + "(≈1,6 GB; mejor con wifi). La búsqueda en internet sigue funcionando para las preguntas de datos.", 12));
        llmState = text("", 12);
        lb.addView(spaced(llmState));
        lb.addView(spaced(button("⬇ DESCARGAR EL CEREBRO (1,6 GB, una vez)", v -> {
            try { LocalBrain.startDownload(this); } catch (Exception e) { toast(L.t("No se pudo empezar la descarga: ") + e.getMessage()); }
            refreshLlm();
        })));
        lb.addView(spaced(button("🗑 BORRAR EL CEREBRO (libera 1,6 GB)", v -> { LocalBrain.delete(this); refreshLlm(); })));
        col.addView(lb, gapBelow(14));
        refreshLlm();

        // ---------- v1.1: cerebro en tu portátil ----------
        brainBtn = button("", v -> {
            String[] keys = {"auto", "local", "pc"};
            String cur = Brain.brain(this);
            int i = 0;
            for (int k = 0; k < keys.length; k++) if (keys[k].equals(cur)) i = k;
            p.edit().putString("ai_brain", keys[(i + 1) % keys.length]).apply();
            refreshBrain();
        });
        LinearLayout sel = panel("◢ QUÉ CEREBRO USA");
        sel.addView(brainBtn);
        sel.addView(text("Si no sabes cuál, déjalo en automático. Las casillas con texto gris son ejemplos: si las dejas vacías, se usa lo que pone.", 11));
        col.addView(sel, gapBelow(14));
        refreshBrain();
        LinearLayout pc = panel("◢ CEREBRO: TU PORTÁTIL (opcional)");
        pc.addView(spaced(text("Cómo prepararlo (una vez): 1) En el portátil instala Ollama desde ollama.com. 2) Abre «Terminal» y escribe: "
                + "ollama pull qwen2.5:7b  3) Para que el móvil pueda entrar, en Windows → «Editar las variables de entorno» añade "
                + "OLLAMA_HOST con el valor 0.0.0.0 y reinicia Ollama. 4) Aquí pon la IP del portátil (en el portátil: Configuración → Red → "
                + "propiedades del wifi → Dirección IPv4), por ejemplo 192.168.1.50. Móvil y portátil en el mismo wifi.", 11)));
        pc.addView(spaced(edit("IP del portátil (p. ej. 192.168.1.50)", false, "ai_pc_url")));
        pc.addView(text(L.t("Modelo (vacío = ") + Brain.DEFAULT_PC_MODEL + ")", 12));
        pc.addView(edit(Brain.DEFAULT_PC_MODEL, false, "ai_pc_model"));
        TextView pcState = text("", 12);
        pc.addView(spaced(button("🔌 PROBAR CONEXIÓN", v -> {
            pcState.setText(L.t("Probando…"));
            new Thread(() -> {
                String r;
                try { r = L.t("✓ Conectado. Modelos instalados: ") + Brain.pcTest(this); }
                catch (Exception e) { r = L.t("✗ No responde: ") + e.getMessage(); }
                String rr = r;
                runOnUiThread(() -> pcState.setText(rr));
            }).start();
        })));
        pc.addView(pcState);
        col.addView(pc, gapBelow(14));

        LinearLayout br = panel("◢ CONVERSACIÓN");
        br.addView(spaced(button("🧹 OLVIDAR LA CONVERSACIÓN", v -> { synchronized (Brain.history) { Brain.history.clear(); } toast(L.t("Conversación borrada")); })));
        col.addView(br, gapBelow(14));

        // ---------- voz ----------
        LinearLayout vo = panel("◢ VOZ");
        // v1.5: la voz propia de Chloe (original, dentro del teléfono), con mezclador
        vo.addView(spaced(button("🎙 VOZ PROPIA DE CHLOE (NUEVA)", v -> startActivity(new Intent(this, VoiceLabActivity.class)))));
        vo.addView(spaced(text("Si activas la voz propia, Chloe la usa al hablar en español. Lo de abajo es la voz del teléfono (para italiano e inglés, o si no la activas).", 12)));
        vo.addView(text("Usa los motores de voz instalados en el teléfono. Para tener más voces, instala otro motor "
                + "desde Play Store (busca «texto a voz» o «TTS») y elígelo aquí.", 13));
        engineBtn = button("", v -> pickEngine());
        voiceBtn = button("", v -> pickVoice());
        vo.addView(spaced(engineBtn));
        vo.addView(spaced(voiceBtn));
        slider(vo, "Tono", "tts_pitch", 100, 50, 200, " %", v -> Voice.apply(this));
        slider(vo, "Velocidad", "tts_rate", 100, 50, 200, " %", v -> Voice.apply(this));
        // v1.4.8: estilos de voz de un toque (tono y velocidad sobre la voz elegida)
        LinearLayout pre = new LinearLayout(this);
        pre.setOrientation(LinearLayout.HORIZONTAL);
        String[][] st = {{"🌸 Dulce", "132", "104"}, {"🎀 Muy aguda", "150", "108"}, {"🙂 Normal", "100", "100"}};
        for (int i = 0; i < st.length; i++) {
            String[] x = st[i];
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i < st.length - 1) lp.rightMargin = dpi(6);
            pre.addView(button(x[0], v -> {
                p.edit().putInt("tts_pitch", Integer.parseInt(x[1])).putInt("tts_rate", Integer.parseInt(x[2])).apply();
                Voice.apply(this);
                Voice.say(this, L.t("¡Hola! ¿Te gusta cómo sueno así?"));
                toast(L.t("Listo. Si no te convence, prueba otra voz o mueve Tono y Velocidad. (Cambia al volver a abrir esta pantalla.)"));
            }), lp);
        }
        vo.addView(spaced(text("Estilos rápidos (mejor con una voz femenina):", 12)));
        vo.addView(spaced(pre));
        vo.addView(spaced(button("▶ PROBAR LA VOZ", v -> Voice.say(this, L.t("Hola, soy el asistente de SSS+. ¿En qué te ayudo?")))));
        vo.addView(spaced(button("➕ CONSEGUIR MÁS VOCES", v -> open("market://search?q=text to speech voices"))));
        vo.addView(spaced(button("⚙ AJUSTES DE VOZ DEL TELÉFONO", v -> {
            try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); } catch (Exception e) { toast(L.t("Este teléfono no tiene ese ajuste")); }
        })));
        col.addView(vo, gapBelow(14));
        refreshVoiceLabels();

        // ---------- palabra clave ----------
        LinearLayout wk = panel("◢ PALABRA CLAVE");
        wk.addView(text("Di una de las frases clave y luego tu pregunta, sin tocar el teléfono: «Hola Chloe, ¿qué tiempo hace?». "
                + "Funciona sin internet. Puedes poner varias frases separadas por comas. Mejor dos o tres palabras: "
                + "las palabras sueltas y cortas se disparan solas más a menudo.", 13));
        wk.addView(spaced(text(L.t("Frases (vacío = «") + Wake.info()[2] + "»)", 12)));
        wk.addView(edit(Wake.info()[2], false, "ai_phrase"));
        modelState = text("", 12);
        wk.addView(spaced(modelState));
        heardTv = text("", 12);
        wk.addView(heardTv);
        wk.addView(spaced(button("⬇ DESCARGAR EL OÍDO (≈40 MB, una vez)", v -> download())));
        wakeSw = neonSwitch("Escuchar siempre la palabra clave");
        wakeSw.setChecked(Wake.enabled(this));
        wakeSw.setOnCheckedChangeListener((v, on) -> {
            if (on && !Wake.downloaded(this)) { wakeSw.setChecked(false); toast(L.t("Primero descarga el oído")); return; }
            if (on && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(Build.VERSION.SDK_INT >= 33 ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}
                        : new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            }
            p.edit().putBoolean("ai_wake", on).apply();
            if (on) ShieldService.start(this);
            else if (!ShieldService.needed(this)) ShieldService.stopAll(this);
            refreshModel();
        });
        wk.addView(wakeSw);
        wk.addView(text("Gasta algo más de batería mientras escucha. Se pausa sola si otra app usa el micrófono.", 11));
        Switch scr = neonSwitch("Solo con la pantalla encendida (ahorra batería)");
        scr.setChecked(p.getBoolean("wake_screen_only", false));
        scr.setOnCheckedChangeListener((v, on) -> { p.edit().putBoolean("wake_screen_only", on).apply(); ShieldService.screenOnly = on; });
        wk.addView(scr);
        Switch fol = neonSwitch("Seguir escuchando después de responder");
        fol.setChecked(p.getBoolean("chloe_followup", true));
        fol.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("chloe_followup", on).apply());
        wk.addView(fol);
        wk.addView(text("Al decir la frase se abre el panel de Chloe abajo, encima de cualquier app: ahí ves si te escucha, piensa o habla. "
                + "Toca fuera del panel para cerrarlo. Para que pueda abrirse con la pantalla en otra app necesita el permiso "
                + "«Mostrar sobre otras apps» (botón 🪟 más abajo). Si no prefieres que escuche siempre, apaga el interruptor y "
                + "llámala con el botón de asistente del teléfono o con «✦ HABLAR CON CHLOE».", 11));
        col.addView(wk, gapBelow(14));
        refreshModel();

        // ---------- asistente del teléfono ----------
        // v1.3: trabajo: «¿qué asistencias tengo hoy?»
        LinearLayout wk2 = panel("◢ TRABAJO");
        wk2.addView(text("Pregúntale «¿qué asistencias tengo hoy?» y Chloe abre tu app de trabajo, lee la lista y te dice a qué hora, con quién, "
                + "cuánto dura y dónde. Lo lee en el momento: no guarda ni envía nada.", 12));
        wk2.addView(text("Nombre de la app (vacío = HomeCareOSA)", 12));
        wk2.addView(edit("HomeCareOSA", false, "work_app"));
        TextView srState = text("", 12);
        wk2.addView(spaced(srState));
        srState.setText(ScreenReader.on() ? L.t("✓ Permiso para leer la pantalla activado.") : L.t("✗ Falta el permiso «Chloe · leer pantalla»."));
        wk2.addView(spaced(button("👁 PERMITIR LEER LA PANTALLA", v -> {
            toast(L.t("Busca «Chloe · leer pantalla» (en Apps instaladas o Servicios descargados) y actívalo."));
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } catch (Exception ignored) {}
        })));
        col.addView(wk2, gapBelow(14));

        // v1.1: app de música preferida para «pon X» sin decir dónde
        LinearLayout mu = panel("◢ MÚSICA");
        mu.addView(text("Cuando digas «pon X» sin decir dónde, se pone en:", 12));
        TextView musicBtn = button("", null);
        Runnable musicLbl = () -> {
            String a = p.getString("music_app", "auto");
            musicBtn.setText(L.t("App de música: ") + (a.equals("spotify") ? "Spotify" : a.equals("vidtube") ? "VidTube" : "YouTube"));
        };
        musicBtn.setOnClickListener(v -> {
            String a = p.getString("music_app", "auto");
            p.edit().putString("music_app", a.equals("auto") || a.equals("youtube") ? "spotify" : a.equals("spotify") ? "vidtube" : "youtube").apply();
            musicLbl.run();
        });
        musicLbl.run();
        mu.addView(spaced(musicBtn));
        mu.addView(text("También puedes decirlo directamente: «pon Queen en Spotify», «pon Queen en VidTube».", 11));
        col.addView(mu, gapBelow(14));

        LinearLayout ph = panel("◢ COMO ASISTENTE DEL TELÉFONO");
        ph.addView(text("Para que SSS+ se abra al mantener pulsado el botón de inicio en lugar de Google: "
                + "Ajustes → Aplicaciones → Aplicaciones predeterminadas → Asistente digital → SSS+.", 13));
        ph.addView(spaced(button("📲 ABRIR APPS PREDETERMINADAS", v -> {
            try { startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        })));
        ph.addView(text("Órdenes que entiende: «pon Bad Bunny en YouTube», «llama a mamá», «manda un WhatsApp a Juan diciendo ya voy», "
                + "«pon una alarma a las 7», «temporizador de 10 minutos», «llévame a la estación», «abre Spotify», «enciende la linterna», «busca recetas de pasta». "
                + "«buenos días» (saludo, hora, tiempo, chiste), «buenas noches» (No molestar), «qué hora es», «qué tiempo hace», «cuéntame un chiste». "
                + "Lo demás lo responde Chloe con su cerebro.", 12));
        ph.addView(text("☀ RUTINAS · tu nombre y tu ciudad (para el saludo y el tiempo)", 12));
        ph.addView(edit("Tu nombre (así te llamará Chloe)", false, "ai_name"));
        Switch cr = neonSwitch("👑 Yo soy quien creó a Chloe (BLORP.eoac)");
        cr.setChecked(p.getBoolean("ai_creator", false));
        cr.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("ai_creator", on).apply());
        ph.addView(cr);
        ph.addView(edit("Tu ciudad (p. ej. Roma)", false, "ai_city"));
        ph.addView(spaced(button("📍 O USAR MI UBICACIÓN", v -> requestPermissions(
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_MIC + 2))));
        ph.addView(spaced(button("🌙 PERMITIR NO MOLESTAR (para «buenas noches»)", v -> {
            try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); }
            catch (Exception e) { toast(L.t("Búscalo en Ajustes → Notificaciones → No molestar → Acceso")); }
        })));
        ph.addView(spaced(button("👥 PERMITIR CONTACTOS Y LLAMADAS", v -> requestPermissions(
                new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE}, REQ_MIC + 1))));
        ph.addView(spaced(button("🪟 PERMITIR ABRIR APPS CON LA PALABRA CLAVE", v -> {
            try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); }
            catch (Exception e) { toast(L.t("Búscalo en Ajustes → Apps → SSS+ → Mostrar sobre otras apps")); }
        })));
        ph.addView(text("Android no deja que una app abra otras estando en segundo plano salvo con el permiso «Mostrar sobre otras apps». "
                + "Sin él, cuando uses la palabra clave te dejaré una notificación para tocarla.", 11));
        ph.addView(text("Junto con «Silenciar Ok Google» (en Ajustes), el teléfono solo te hará caso a ti con tu palabra clave.", 11));
        col.addView(ph, gapBelow(14));

        String a = getIntent() == null ? null : getIntent().getAction();
        if (Intent.ACTION_ASSIST.equals(a) || "android.intent.action.VOICE_COMMAND".equals(a)) h.postDelayed(this::listen, 500);
    }

    // ------------------------------------------------------------------ conversación
    void say(String who, String s) {
        if (chat.length() > 0) chat.append("\n\n");
        chat.append(who).append(" ").append(s);
        log.setText(chat.toString());
    }

    void ask(String q) {
        // v0.9.2: primero, ¿es una orden para el teléfono? (YouTube, llamar, WhatsApp, alarma, abrir app...)
        Actions.Result r = Actions.parse(this, q);
        if (r != null) {
            say("🗣", q);
            boolean ok = Actions.run(this, r);
            String msg = ok ? r.say : L.t("No he podido abrirlo en este teléfono.");
            say("🐑", msg);
            Voice.say(this, msg);
            av.react(ok ? AvatarArt.HAPPY : AvatarArt.SAD, 1800);
            return;
        }
        if (Mood.nonsense(q)) {                                   // v1.4: no lo ha entendido → cara de «¿?»
            say("🗣", q); String m = Mood.confused(); say("🐑", m); Voice.say(this, m); av.react(AvatarArt.CONFUSED, 4000); return;
        }
        av.setState(AvatarArt.THINK);
        say("🗣", q);
        say("🐑", L.t("Pensando…"));
        int mark = chat.lastIndexOf("🐑");
        new Thread(() -> {
            String raw = Brain.ask(this, q);
            String cmd = Brain.cmdOf(raw);
            String ans = Brain.speech(raw);
            runOnUiThread(() -> {
                chat.setLength(mark);
                chat.append("🐑 ").append(ans);
                if (cmd != null) {                     // v1.1: el cerebro decidió hacer algo en el teléfono
                    Actions.Result rc = Actions.parse(this, cmd);
                    if (rc != null && rc.intent != null && !Actions.run(this, rc)) chat.append("\n   ⚠ ").append(L.t("No he podido abrirlo en este teléfono."));
                    if (rc == null) chat.append("\n   ⚠ ").append(L.t("No sé hacer: ")).append(cmd);
                }
                String err = Brain.lastError;
                if (!err.isEmpty()) chat.append("\n   ⚠ ").append(err);
                log.setText(chat.toString());
                Voice.say(this, ans);
                av.setState(AvatarArt.IDLE);
                if (!err.isEmpty()) av.react(AvatarArt.SAD, 3000);
                else if (ans.matches("(?s).*\\?\\s*$") && ans.length() < 140) av.react(AvatarArt.CONFUSED, 1500);
            });
        }, "cerebro").start();
    }

    /** Usa el reconocedor de voz del teléfono; mientras tanto, la escucha de SSS+ suelta el micrófono. */
    void listen() {
        Voice.stop();
        if (av != null) av.setState(AvatarArt.LISTEN);
        ShieldService.yieldMic = true;
        h.postDelayed(() -> ShieldService.yieldMic = false, 30000);       // seguridad: nunca más de 30 s
        h.postDelayed(() -> {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Brain.listenTag(this));
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, L.t("Te escucho…"));
            try { startActivityForResult(i, REQ_SPEAK); }
            catch (Exception e) { ShieldService.yieldMic = false; toast(L.t("Este teléfono no tiene reconocimiento de voz. Escribe tu pregunta.")); }
        }, 1200);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_SPEAK) {
            ShieldService.yieldMic = false;
            av.setState(AvatarArt.IDLE);
            if (res == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) ask(r.get(0));
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    protected void onDestroy() {
        ShieldService.yieldMic = false;
        super.onDestroy();
    }

    // ------------------------------------------------------------------ voz
    void refreshVoiceLabels() {
        String e = p.getString("tts_engine", "");
        engineBtn.setText(L.t("Motor: ") + (e.isEmpty() ? L.t("el del teléfono") : e));
        String v = p.getString("tts_voice", "");
        voiceBtn.setText(L.t("Voz: ") + (v.isEmpty() ? L.t("la de por defecto") : v));
    }

    void pickEngine() {
        if (Voice.tts == null) { toast(L.t("Cargando las voces… prueba otra vez")); Voice.init(this, null); return; }
        List<TextToSpeech.EngineInfo> eng = Voice.tts.getEngines();
        String[] names = new String[eng.size() + 1];
        names[0] = L.t("El del teléfono (por defecto)");
        for (int i = 0; i < eng.size(); i++) names[i + 1] = eng.get(i).label + "  (" + eng.get(i).name + ")";
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Motor de voz")).setItems(names, (d, w) -> {
            p.edit().putString("tts_engine", w == 0 ? "" : eng.get(w - 1).name).putString("tts_voice", "").apply();
            Voice.init(this, () -> runOnUiThread(this::refreshVoiceLabels));
            refreshVoiceLabels();
        }).show();
    }

    void pickVoice() {
        if (Voice.tts == null || !Voice.ready) { toast(L.t("Cargando las voces… prueba otra vez")); Voice.init(this, null); return; }
        String want = "en".equals(L.lang) ? "en" : "it".equals(L.lang) ? "it" : "es";
        List<android.speech.tts.Voice> list = new ArrayList<>();
        try {
            for (android.speech.tts.Voice v : Voice.tts.getVoices())
                if (v.getLocale() != null && want.equals(v.getLocale().getLanguage())) list.add(v);
        } catch (Exception ignored) {}
        if (list.isEmpty()) { toast(L.t("Este motor no tiene voces en tu idioma")); return; }
        list.sort((a, b) -> a.getName().compareTo(b.getName()));
        String[] names = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            android.speech.tts.Voice v = list.get(i);
            names[i] = v.getName() + (v.isNetworkConnectionRequired() ? "  🌐" : "") + "  · " + v.getLocale().getDisplayCountry();
        }
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Elige una voz")).setItems(names, (d, w) -> {
            p.edit().putString("tts_voice", list.get(w).getName()).apply();
            Voice.apply(this);
            refreshVoiceLabels();
            Voice.say(this, L.t("Esta es mi nueva voz."));
        }).show();
    }

    // ------------------------------------------------------------------ palabra clave
    void refreshModel() {
        if (modelState == null) return;
        String last = getSharedPreferences("cfg", MODE_PRIVATE).getString("wake_last", "");
        modelState.setText(Wake.downloaded(this)
                ? L.t("✓ Oído descargado. Di «") + Wake.phrase(this) + L.t("» y luego tu pregunta.")
                  + (last.isEmpty() ? "" : "\n" + L.t("Última vez que me activé: ") + last)
                : L.t("Falta descargar el oído (solo una vez, con wifi mejor)."));
    }

    void download() {
        if (Wake.downloaded(this)) { toast(L.t("El oído ya está descargado")); return; }
        Wake.startDownload(this, 0);
        modelState.setText(L.t("Empezando la descarga… puedes salir de la app, sigue sola."));
        pollDownload();
    }

    boolean polling;

    /** Cada segundo mira cómo va la descarga (que hace Android aunque salgas de la app). */
    void pollDownload() {
        if (polling) return;
        polling = true;
        new Thread(() -> {
            while (polling && !isFinishing()) {
                String msg = Wake.poll(this, (pc, m) -> runOnUiThread(() -> modelState.setText(m)));
                if (msg == null) break;
                runOnUiThread(() -> modelState.setText(msg));
                if (Wake.downloaded(this)) break;
                try { Thread.sleep(1000); } catch (InterruptedException e) { break; }
            }
            polling = false;
            runOnUiThread(() -> { if (Wake.downloaded(this)) refreshModel(); });
        }, "descarga").start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.post(heardTick);
        if (modelState != null && !Wake.downloaded(this) && Wake.status(this) != null) pollDownload();
    }

    @Override
    protected void onPause() {
        polling = false;
        h.removeCallbacks(heardTick);
        super.onPause();
    }

    // ------------------------------------------------------------------ utilidades
    EditText edit(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(L.t(hint));
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setTextSize(15);
        e.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        e.setBackground(frame(dp(10)));
        e.setPadding(dpi(12), dpi(10), dpi(12), dpi(10));
        e.setSingleLine(true);
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    /** Campo de texto que se guarda solo en los ajustes. */
    EditText edit(String hint, boolean secret, String key) {
        EditText e = edit(hint, secret);
        e.setText(p.getString(key, ""));
        e.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) {
                p.edit().putString(key, s.toString()).apply();
                if (key.equals("ai_phrase")) refreshModel();
            }
        });
        return e;
    }

    android.view.View spaced(android.view.View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dpi(8);
        v.setLayoutParams(lp);
        return v;
    }

    void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { toast(url); }
    }
}
