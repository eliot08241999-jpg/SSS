package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * v1.4.5 · Chloe a pantalla completa, como un chatbot: ella grande arriba (se puede tocar) y la conversación
 * en burbujas debajo. Comparte la conversación con la pantalla del asistente.
 */
public class ChloeChatActivity extends NeonActivity {
    static final int REQ_SPEAK = 81;
    ChloeAvatarView av;
    LinearLayout bubbles;
    ScrollView scroll;
    EditText in;
    boolean busy;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Voice.init(this, null);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dpi(12), dpi(10), dpi(12), dpi(10));

        // barra de arriba: volver, nombre y aspecto
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(circleButton("←", v -> finish()), new LinearLayout.LayoutParams(dpi(42), dpi(42)));
        TextView name = neonText("  " + Brain.botName(this), 20);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        TextView skin = button("🎨", v -> {
            String[] cyc = {"auto", "autumn", "winter", "spring", "summer"};
            int i = java.util.Arrays.asList(cyc).indexOf(p.getString("avatar_outfit", "auto"));
            String nx = cyc[(i + 1) % cyc.length];
            p.edit().putString("avatar_outfit", nx).putString("avatar_skin", "bunny").apply();
            av.refreshOutfit();
            int k = java.util.Arrays.asList(Outfit.ALL).indexOf(Outfit.now(this));
            toast(("auto".equals(nx) ? L.t("Auto: ") : "") + L.t(Outfit.LABEL[Math.max(0, k)]));
        });
TextView lg = button("", null);
        Runnable lgl = () -> { String x = p.getString("listen_lang", "auto"); lg.setText("🌐 " + ("auto".equals(x) ? "AUTO" : x.toUpperCase(java.util.Locale.ROOT))); };
        lg.setOnClickListener(v -> {
            String[] cyc = {"auto", "es", "it", "en"};
            int i = java.util.Arrays.asList(cyc).indexOf(p.getString("listen_lang", "auto"));
            p.edit().putString("listen_lang", cyc[(i + 1) % cyc.length]).apply();
            lgl.run();
            toast(L.t("Idioma en el que te escucho. AUTO = el de la conversación."));
        });
        lgl.run();
        lg.setPadding(dpi(10), dpi(8), dpi(10), dpi(8));
        LinearLayout.LayoutParams lgp = new LinearLayout.LayoutParams(-2, -2); lgp.rightMargin = dpi(6);
        top.addView(lg, lgp);
        TextView live = button("🎙", v -> startActivity(new Intent(this, LiveActivity.class)));
        live.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        LinearLayout.LayoutParams lvp = new LinearLayout.LayoutParams(-2, -2); lvp.rightMargin = dpi(6);
        top.addView(live, lvp);
        skin.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        top.addView(skin, new LinearLayout.LayoutParams(-2, -2));
        root.addView(top);

        // Chloe grande
        av = new ChloeAvatarView(this);
        av.setOnPoke(line -> { bubble(false, line); Voice.say(this, line); });
        root.addView(av, new LinearLayout.LayoutParams(-1, 0, 1.15f));

        // conversación
        scroll = new ScrollView(this);
        bubbles = new LinearLayout(this);
        bubbles.setOrientation(LinearLayout.VERTICAL);
        bubbles.setPadding(0, dpi(6), 0, dpi(6));
        scroll.addView(bubbles);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        // escribir / hablar
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        in = new EditText(this);
        in.setHint(L.t("Escribe tu pregunta…"));
        in.setTextColor(Color.WHITE);
        in.setHintTextColor(Color.GRAY);
        in.setTextSize(15);
        in.setSingleLine(true);
        in.setImeOptions(EditorInfo.IME_ACTION_SEND);
        in.setBackground(frame(22));
        in.setPadding(dpi(16), dpi(10), dpi(16), dpi(10));
        in.setOnEditorActionListener((v, id, e) -> { send(); return true; });
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, -2, 1);
        ip.rightMargin = dpi(6);
        row.addView(in, ip);
        TextView mic = circleButton("🎤", v -> listen());
        row.addView(mic, new LinearLayout.LayoutParams(dpi(48), dpi(48)));
        TextView go = circleButton("➤", v -> send());
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dpi(48), dpi(48));
        gp.leftMargin = dpi(6);
        row.addView(go, gp);
        root.addView(row);

        setContentView(makeRoot(root));

        // lo que ya hablasteis
        List<String[]> h;
        synchronized (Brain.history) { h = new ArrayList<>(Brain.history); }
        for (String[] m : h) bubble(m[0].equals("user"), m[0].equals("user") ? m[1] : Brain.speech(m[1]));
        if (h.isEmpty()) bubble(false, L.t("¡Aquí estoy! Escríbeme o pulsa 🎤 para hablarme. Y si me tocas, reacciono. 😊"));
        av.react(AvatarArt.HAPPY, 1500);
    }

    @Override protected void onPause() { super.onPause(); Voice.stop(); }

    // ------------------------------------------------------------------ burbujas
    TextView last;

    TextView bubble(boolean user, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(15);
        t.setTextColor(user ? Color.WHITE : Color.rgb(235, 240, 255));
        t.setPadding(dpi(14), dpi(9), dpi(14), dpi(9));
        GradientDrawable g = new GradientDrawable();
        int neon = Neon.color(this);
        float r = dpi(18), s = dpi(4);
        g.setCornerRadii(user ? new float[]{r, r, s, s, r, r, r, r} : new float[]{s, s, r, r, r, r, r, r});
        if (user) { g.setColor(Color.argb(70, Color.red(neon), Color.green(neon), Color.blue(neon))); g.setStroke(dpi(1), neon); }
        else { g.setColor(Color.rgb(26, 30, 56)); g.setStroke(dpi(1), Color.argb(90, 255, 255, 255)); }
        t.setBackground(g);
        t.setTextIsSelectable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.gravity = user ? Gravity.END : Gravity.START;
        lp.topMargin = dpi(6);
        if (user) lp.leftMargin = dpi(48); else lp.rightMargin = dpi(48);
        bubbles.addView(t, lp);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        last = t;
        return t;
    }

    // ------------------------------------------------------------------ preguntar
    void send() {
        String q = in.getText().toString().trim();
        if (q.isEmpty()) return;
        in.setText("");
        ask(q);
    }

    void ask(String q) {
        if (busy) { toast(L.t("Espera, que aún estoy pensando…")); return; }
        bubble(true, q);
        Actions.Result r = Actions.parse(this, q);
        if (r != null) {
            boolean ok = Actions.run(this, r);
            String msg = ok ? r.say : L.t("No he podido abrirlo en este teléfono.");
            bubble(false, msg);
            Voice.say(this, msg);
            av.react(ok ? AvatarArt.HAPPY : AvatarArt.SAD, 1800);
            return;
        }
        if (Mood.nonsense(q)) { String m = Mood.confused(); bubble(false, m); Voice.say(this, m); av.react(AvatarArt.CONFUSED, 4000); return; }
        busy = true;
        av.setState(AvatarArt.THINK);
        TextView think = bubble(false, "…");
        h.post(new Runnable() {                                 // puntitos mientras piensa
            int n;
            public void run() { if (!busy) return; think.setText(new String[]{"·", "· ·", "· · ·"}[n++ % 3]); h.postDelayed(this, 400); }
        });
        new Thread(() -> {
            String raw = Brain.ask(this, q);
            String cmd = Brain.cmdOf(raw);
            String ans = Brain.speech(raw);
            runOnUiThread(() -> {
                busy = false;
                StringBuilder shown = new StringBuilder(ans);
                if (cmd != null) {
                    Actions.Result rc = Actions.parse(this, cmd);
                    if (rc != null && rc.intent != null && !Actions.run(this, rc)) shown.append("\n⚠ ").append(L.t("No he podido abrirlo en este teléfono."));
                    if (rc == null) shown.append("\n⚠ ").append(L.t("No sé hacer: ")).append(cmd);
                }
                String err = Brain.lastError;
                if (!err.isEmpty()) shown.append("\n⚠ ").append(err);
                think.setText(shown.toString());
                scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
                Voice.say(this, ans);
                av.setState(AvatarArt.IDLE);
                if (!err.isEmpty()) av.react(AvatarArt.SAD, 3000);
                else if (ans.matches("(?s).*\\?\\s*$") && ans.length() < 140) av.react(AvatarArt.CONFUSED, 1500);
            });
        }, "cerebro").start();
    }

    void listen() {
        Voice.stop();
        av.setState(AvatarArt.LISTEN);
        ShieldService.yieldMic = true;
        h.postDelayed(() -> ShieldService.yieldMic = false, 30000);
        h.postDelayed(() -> {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Brain.listenTag(this));
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, L.t("Te escucho…"));
            try { startActivityForResult(i, REQ_SPEAK); }
            catch (Exception e) { av.setState(AvatarArt.IDLE); toast(L.t("Este teléfono no tiene reconocimiento de voz. Escribe tu pregunta.")); }
        }, 300);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_SPEAK) {
            ShieldService.yieldMic = false;
            av.setState(AvatarArt.IDLE);
            if (res == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) ask(r.get(0));
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }
}
