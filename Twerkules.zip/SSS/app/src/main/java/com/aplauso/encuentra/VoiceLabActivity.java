package com.aplauso.encuentra;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * v1.5 · LA VOZ DE CHLOE: descargar su voz propia, mezclarla (cuánto de cada voz) y afinarla:
 * tono, velocidad, aire, eses, t/d, brillo, expresión, volumen, rapidez de respuesta y pausas.
 */
public class VoiceLabActivity extends NeonActivity {
    TextView status, dlBtn, result;
    Switch use;
    LinearLayout mix;
    EditText sample;
    boolean showAll, testing;

    static final String[][] PRESETS = {
            // nombre, mezcla, tono, velocidad, aire, s, t/d, brillo, expresión
            {"🌬 Susurro+", "ef_dora=40,af_nicole=60", "108", "88", "35", "40", "30", "10", "40"},
            {"🍃 Brisa", "ef_dora=60,af_nicole=25,af_heart=15", "103", "90", "25", "35", "25", "5", "35"},
            {"🌸 Dulce", "ef_dora=50,af_bella=30,af_sky=20", "107", "94", "15", "30", "20", "10", "50"},
            {"🎀 Tierna", "ef_dora=55,jf_alpha=25,af_heart=20", "106", "92", "15", "30", "25", "5", "50"},
            {"👒 Señorita", "ef_dora=45,af_heart=25,af_nicole=15,jf_tebukuro=15", "105", "90", "20", "35", "30", "0", "40"},
            {"🙂 Natural", "ef_dora=100", "100", "100", "0", "0", "0", "0", "0"},
    };

    LinearLayout.LayoutParams sp() { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dpi(8); return lp; }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen(L.t("Voz de Chloe"));

        // ---------- la voz propia ----------
        LinearLayout a = panel("◢ VOZ PROPIA");
        a.addView(text("Una voz original para Chloe, hecha mezclando voces sintéticas libres: no copia la voz de nadie. "
                + "Funciona dentro del teléfono, gratis y sin internet. De momento habla español; en italiano e inglés sigue la voz del teléfono.", 13));
        status = text("", 13);
        status.setTextColor(Color.rgb(170, 180, 200));
        a.addView(status, sp());
        dlBtn = button("", v -> download());
        a.addView(dlBtn, sp());
        use = neonSwitch("Usar esta voz");
        use.setChecked(KokoroVoice.on(this));
        use.setOnCheckedChangeListener((v, on) -> {
            if (on && !KokoroVoice.filesReady(this)) { use.setChecked(false); toast(L.t("Primero descarga la voz.")); return; }
            p.edit().putBoolean("kv_on", on).apply();
            KokoroVoice.failures = 0;
            if (on) KokoroVoice.warm(this); else KokoroVoice.unload();
        });
        a.addView(use, sp());
        col.addView(a, gapBelow(14));

        // ---------- probar ----------
        LinearLayout t = panel("◢ PROBAR");
        sample = new EditText(this);
        sample.setText(p.getString("kv_sample", L.t("¡Hola! Soy Chloe. ¿De verdad quieres que hablemos un ratito? Me encanta estar contigo…")));
        sample.setTextColor(Color.WHITE);
        sample.setTextSize(14);
        sample.setBackground(frame(12));
        sample.setPadding(dpi(12), dpi(10), dpi(12), dpi(10));
        sample.setMinLines(2);
        t.addView(sample, sp());
        LinearLayout row = new LinearLayout(this);
        LinearLayout.LayoutParams w1 = new LinearLayout.LayoutParams(0, -2, 2); w1.rightMargin = dpi(6);
        row.addView(button("▶ PROBAR", v -> test()), w1);
        row.addView(button("⏹", v -> Voice.stop()), new LinearLayout.LayoutParams(0, -2, 1));
        t.addView(row, sp());
        result = text("", 12);
        result.setTextColor(Color.rgb(170, 180, 200));
        t.addView(result, sp());
        t.addView(text("Los cambios se oyen en la siguiente frase. Las frases de prueba tienen que estar en español.", 11), sp());
        col.addView(t, gapBelow(14));

        // ---------- estilos ----------
        LinearLayout e = panel("◢ ESTILOS DE UN TOQUE");
        for (int i = 0; i < PRESETS.length; i += 3) {
            LinearLayout r = new LinearLayout(this);
            for (int j = i; j < Math.min(i + 3, PRESETS.length); j++) {
                String[] x = PRESETS[j];
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
                if (j < i + 2) lp.rightMargin = dpi(6);
                TextView bt = button(x[0], v -> preset(x));
                bt.setTextSize(12);
                bt.setLetterSpacing(0.02f);
                r.addView(bt, lp);
            }
            e.addView(r, sp());
        }
        e.addView(text("«Susurro+» es la que elegiste, con más aire y más aguda. Tócala y luego afina abajo.", 11), sp());
        col.addView(e, gapBelow(14));

        // ---------- afinar ----------
        LinearLayout s = panel("◢ AFINAR");
        slider(s, "Tono (más aguda →)", "kv_pitch", 108, 85, 130, " %", null);
        slider(s, "Velocidad", "kv_speed", 88, 60, 140, " %", null);
        slider(s, "Aire (voz soplada)", "kv_air", 35, 0, 100, " %", null);
        slider(s, "Suavizar la S", "kv_s", 40, 0, 100, " %", null);
        slider(s, "Suavizar T, D, P, K", "kv_t", 30, 0, 100, " %", null);
        slider(s, "Brillo (← cálida · brillante →)", "kv_bright", 10, -100, 100, "", null);
        slider(s, "Expresión (entonación viva)", "kv_expr", 40, 0, 100, " %", null);
        slider(s, "Volumen", "kv_vol", 100, 40, 200, " %", null);
        slider(s, "Pausas entre frases", "kv_pause", 100, 0, 250, " %", null);
        slider(s, "Respuesta (← empieza antes · más natural →)", "kv_lat", 35, 0, 100, "", null);
        s.addView(text("Tono sube toda la voz (también la hace más «pequeña»). Expresión cambia la entonación sin tocar el timbre: "
                + "si con mucha suena rara, bájala.", 11), sp());
        col.addView(s, gapBelow(14));

        // ---------- mezcla ----------
        mix = panel("◢ MEZCLA DE VOCES");
        col.addView(mix, gapBelow(14));
        buildMix();

        LinearLayout d = panel(null);
        d.addView(button("🗑 BORRAR LA VOZ DESCARGADA", v -> {
            Voice.stop();
            KokoroVoice.delete(this);
            p.edit().putBoolean("kv_on", false).apply();
            use.setChecked(false);
            buildMix();
            toast(L.t("Borrada. Chloe vuelve a la voz del teléfono."));
        }));
        col.addView(d, gapBelow(8));
        h.post(tick);
    }

    // ------------------------------------------------------------------ mezcla
    static String label(String v) {
        String lang;
        switch (v.charAt(0)) {
            case 'e': lang = "español"; break;
            case 'a': lang = "inglés EE. UU."; break;
            case 'b': lang = "inglés R. U."; break;
            case 'i': lang = "italiano"; break;
            case 'j': lang = "japonés"; break;
            case 'f': lang = "francés"; break;
            case 'p': lang = "portugués"; break;
            case 'h': lang = "hindi"; break;
            case 'z': lang = "chino"; break;
            default: lang = "";
        }
        String n = v.length() > 3 ? v.substring(3) : v;
        n = n.substring(0, 1).toUpperCase(Locale.ROOT) + n.substring(1);
        return n + " · " + L.t(lang) + (v.length() > 1 && v.charAt(1) == 'm' ? " ♂" : " ♀");
    }

    void buildMix() {
        while (mix.getChildCount() > 1) mix.removeViewAt(1);
        if (!KokoroVoice.filesReady(this)) { mix.addView(text("Descarga la voz para ver el mezclador.", 13)); return; }
        mix.addView(text("Cuánto pones de cada voz. La española (Dora) es la que pronuncia bien el español: déjala siempre alta. "
                + "Nicole da el susurro; Heart, Bella y Sky dan dulzura; las japonesas, un toque de anime.", 12));
        List<String> names = KokoroVoice.voiceNames(this);
        Map<String, Integer> w = KokoroVoice.weights(this);
        List<String> order = new ArrayList<>();
        for (String m : KokoroVoice.MAIN) if (names.contains(m)) order.add(m);
        for (String n : w.keySet()) if (!order.contains(n) && names.contains(n)) order.add(n);
        if (showAll) for (String n : names) if (!order.contains(n)) order.add(n);
        // los pesos por defecto se escriben, para que los deslizadores y la voz digan lo mismo
        SharedPreferences.Editor ed = p.edit();
        for (Map.Entry<String, Integer> x : w.entrySet()) ed.putInt("kv_w_" + x.getKey(), x.getValue());
        ed.apply();
        for (String n : order) slider(mix, label(n), "kv_w_" + n, 0, 0, 100, "", null);
        mix.addView(button(showAll ? L.t("VER SOLO LAS PRINCIPALES") : L.t("VER TODAS LAS VOCES") + " (" + names.size() + ")", v -> { showAll = !showAll; buildMix(); }), sp());
        mix.addView(button("↺ MEZCLA A CERO", v -> { clearWeights(); p.edit().putInt("kv_w_ef_dora", 100).apply(); buildMix(); }), sp());
    }

    void clearWeights() {
        SharedPreferences.Editor ed = p.edit();
        for (String k : p.getAll().keySet()) if (k.startsWith("kv_w_")) ed.remove(k);
        ed.apply();
    }

    void preset(String[] x) {
        clearWeights();
        SharedPreferences.Editor ed = p.edit();
        for (String kv : x[1].split(",")) { String[] q = kv.split("="); ed.putInt("kv_w_" + q[0], Integer.parseInt(q[1])); }
        ed.putInt("kv_pitch", Integer.parseInt(x[2])).putInt("kv_speed", Integer.parseInt(x[3])).putInt("kv_air", Integer.parseInt(x[4]))
                .putInt("kv_s", Integer.parseInt(x[5])).putInt("kv_t", Integer.parseInt(x[6])).putInt("kv_bright", Integer.parseInt(x[7]))
                .putInt("kv_expr", Integer.parseInt(x[8])).apply();
        p.edit().putBoolean("kv_autotest", true).apply();
        recreate();                                        // los deslizadores se vuelven a pintar con los valores nuevos
    }

    // ------------------------------------------------------------------ probar y descargar
    void test() {
        if (!KokoroVoice.filesReady(this)) { toast(L.t("Primero descarga la voz.")); return; }
        String txt = sample.getText().toString().trim();
        if (txt.isEmpty()) return;
        p.edit().putString("kv_sample", txt).apply();
        Voice.stop();
        KokoroVoice.failures = 0;
        KokoroVoice.error = "";
        KokoroVoice.firstSoundSec = 0;
        testing = true;
        result.setText(L.t(KokoroVoice.loaded() ? "Preparando la frase…" : "Cargando la voz (la primera vez tarda un poco)…"));
        final android.content.Context app = getApplicationContext();
        KokoroVoice.speak(this, txt, ok -> { if (!ok) Voice.sayPhone(app, L.t("No he podido usar la voz nueva.")); });
    }

    void download() {
        if (FastDownload.running("kokoro")) { FastDownload.stop(); return; }
        if (KokoroVoice.filesReady(this)) return;
        if (FastDownload.runningId != null) { toast(L.t("Hay otra descarga en marcha. Espera a que termine.")); return; }
        FastDownload.start(this, "kokoro");
    }

    final Runnable tick = new Runnable() {
        boolean was;
        public void run() {
            if (isFinishing()) return;
            boolean run = FastDownload.running("kokoro"), ready = KokoroVoice.filesReady(VoiceLabActivity.this);
            if (run) {
                long got = FastDownload.got.get(), tot = FastDownload.total;
                status.setText(L.t("Descargando…") + " " + (got >> 20) + " / " + (tot >> 20) + " MB"
                        + (FastDownload.speed() > 0 ? String.format(Locale.ROOT, " · %.1f MB/s", FastDownload.speed()) : ""));
                dlBtn.setText(L.t("✕ CANCELAR LA DESCARGA"));
                dlBtn.setVisibility(View.VISIBLE);
            } else if (ready) {
                String err = KokoroVoice.error;
                status.setText(L.t(KokoroVoice.loading ? "Cargando la voz…" : "✔ Voz descargada y lista.") + (err.isEmpty() ? "" : "\n⚠ " + err));
                dlBtn.setVisibility(View.GONE);
                if (was) { buildMix(); if (!use.isChecked()) use.setChecked(true); }
            } else {
                String err = "kokoro".equals(FastDownload.lastId) ? FastDownload.error : "";
                status.setText(L.t("Sin descargar. Ocupa unos 145 MB.") + (err.isEmpty() ? "" : "\n⚠ " + err));
                dlBtn.setText(L.t("⬇ DESCARGAR LA VOZ (145 MB)"));
                dlBtn.setVisibility(View.VISIBLE);
            }
            was = run;
            if (testing) {
                if (!KokoroVoice.error.isEmpty() && !Voice.speaking) { result.setText("⚠ " + KokoroVoice.error); testing = false; }
                else if (KokoroVoice.firstSoundSec > 0) {
                    float rt = KokoroVoice.lastAudioSec > 0 ? KokoroVoice.lastMakeSec / KokoroVoice.lastAudioSec : 0;
                    result.setText(String.format(Locale.ROOT, L.t("Empezó a sonar a los %.1f s · cada segundo de voz le cuesta %.1f s a tu teléfono"), KokoroVoice.firstSoundSec, rt)
                            + (rt > 1.05f ? "\n" + L.t("Va justo: habrá paradas entre frases. Sube «Respuesta» hacia «más natural» para que sean menos.") : ""));
                    if (!Voice.speaking) testing = false;
                }
            }
            h.postDelayed(this, 400);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        if (p.getBoolean("kv_autotest", false)) { p.edit().remove("kv_autotest").apply(); h.postDelayed(this::test, 300); }
    }

    @Override protected void onPause() { super.onPause(); if (isFinishing()) Voice.stop(); }
    @Override protected void onDestroy() { h.removeCallbacks(tick); super.onDestroy(); }
}
