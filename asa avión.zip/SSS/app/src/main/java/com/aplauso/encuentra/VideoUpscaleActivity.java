package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/**
 * v1.5.2 · AMPLIAR VÍDEOS: de 360p/480p/720p a 720p, 1080p, 1440p o 4K con una red neuronal, dentro del teléfono.
 * Antes de empezar se puede PROBAR CON UN FOTOGRAMA (se ve el antes y el después, y cuánto va a tardar).
 */
public class VideoUpscaleActivity extends NeonActivity {
    static final int REQ_PICK = 95;
    static final int[] SIDES = {720, 1080, 1440, 2160};
    static final String[] SIDE_NAMES = {"720p", "1080p", "1440p", "4K"};

    Uri uri;
    String name = "";
    int vw, vh, side = 2160, model = 0;
    float fps = 30;
    long durMs;
    TextView info, est, status, startBtn;
    TextView[] sideBtns = new TextView[4], modelBtns = new TextView[2];
    LinearLayout opts, cmp;
    ImageView before, after;
    boolean testing;
    NeonProgress prog, testProg;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen(L.t("🎬 AMPLIAR VÍDEOS"));

        LinearLayout a = panel("◢ VÍDEO");
        info = text("Elige un vídeo y lo paso a más resolución: hasta 4K.", 13);
        a.addView(info);
        a.addView(button("🎞 ELEGIR VÍDEO", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE);
            PickActivity.start(this, i, REQ_PICK, "video_upscale");
        }), sp(8));
        col.addView(a, gapBelow(12));

        opts = panel("◢ RESULTADO");
        opts.addView(text("Tamaño final:", 13));
        LinearLayout r = new LinearLayout(this);
        for (int i = 0; i < 4; i++) {
            final int k = i;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i < 3) lp.rightMargin = dpi(5);
            sideBtns[i] = button(SIDE_NAMES[i], v -> { side = SIDES[k]; marks(); });
            sideBtns[i].setTextSize(12);
            r.addView(sideBtns[i], lp);
        }
        opts.addView(r, sp(6));
        opts.addView(text("Manera:", 13), sp(10));
        LinearLayout r2 = new LinearLayout(this);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1); l1.rightMargin = dpi(6);
        modelBtns[0] = button("⚡ RÁPIDA", v -> { model = 0; marks(); });
        modelBtns[1] = button("🔬 DETALLADA", v -> { model = 1; marks(); });
        modelBtns[0].setTextSize(12); modelBtns[1].setTextSize(12);
        r2.addView(modelBtns[0], l1);
        r2.addView(modelBtns[1], new LinearLayout.LayoutParams(0, -2, 1));
        opts.addView(r2, sp(6));
        opts.addView(text("Rápida: pensada para vídeo (dibujos, anime y también grabaciones normales). Detallada: más textura en vídeos reales, pero tarda el doble.", 11), sp(6));
        est = text("", 13);
        est.setTextColor(Color.rgb(255, 210, 120));
        opts.addView(est, sp(10));
        testProg = new NeonProgress(this);
        opts.addView(testProg, sp(6));
        opts.addView(button("👁 PRUEBA EXPRÉS (unos segundos)", v -> test()), sp(8));
        cmp = new LinearLayout(this);
        cmp.setOrientation(LinearLayout.VERTICAL);
        TextView tb = text("ANTES (estirado)", 11);
        cmp.addView(tb);
        before = new ImageView(this);
        before.setAdjustViewBounds(true);
        cmp.addView(before, new LinearLayout.LayoutParams(-1, -2));
        cmp.addView(text("DESPUÉS (con IA)", 11), sp(6));
        after = new ImageView(this);
        after.setAdjustViewBounds(true);
        cmp.addView(after, new LinearLayout.LayoutParams(-1, -2));
        cmp.setVisibility(View.GONE);
        opts.addView(cmp, sp(8));
        startBtn = button("▶ AMPLIAR EL VÍDEO", v -> go());
        opts.addView(startBtn, sp(10));
        opts.addView(text("Va en segundo plano, también con la pantalla apagada (mejor con el móvil cargando). El vídeo original no se toca: "
                + "el nuevo se guarda aparte, con el sonido.", 11), sp(6));
        opts.setVisibility(View.GONE);
        col.addView(opts, gapBelow(12));

        LinearLayout st = panel("◢ PROGRESO");
        status = text("", 13);
        st.addView(status);
        prog = new NeonProgress(this);
        st.addView(prog, sp(6));
        st.addView(button("✕ CANCELAR", v -> { VideoSR.cancel = true; toast(L.t("Cancelando…")); }), sp(8));
        st.addView(button("▶ VER EL VÍDEO NUEVO", v -> {
            if (VideoSR.result == null) { toast(L.t("Todavía no hay vídeo nuevo.")); return; }
            try { startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(VideoSR.result, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)); }
            catch (Exception e) { toast(L.t("Está en tus vídeos (SSS+).")); }
        }), sp(8));
        col.addView(st, gapBelow(12));

        TextView note = text("Cómo funciona: una red neuronal (Real-ESRGAN, libre) reconstruye bordes y texturas en cada fotograma. "
                + "No puede inventar lo que el vídeo nunca grabó: un 360p no se vuelve un 4K de cámara, pero se ve mucho más nítido que estirado.", 11);
        note.setTextColor(Color.rgb(140, 150, 170));
        col.addView(note, gapBelow(12));

        if (getIntent().getData() != null) open(getIntent().getData());
        h.post(tick);
    }

    LinearLayout.LayoutParams sp(int dp) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dpi(dp); return lp; }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) {
            try { getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            open(data.getData());
        }
    }

    void open(Uri u) {
        uri = u;
        name = Media.nameOf(this, u);
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(this, u, null);
            vw = 0;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m == null || !m.startsWith("video/")) continue;
                vw = f.getInteger(MediaFormat.KEY_WIDTH);
                vh = f.getInteger(MediaFormat.KEY_HEIGHT);
                try { fps = f.containsKey(MediaFormat.KEY_FRAME_RATE) ? f.getInteger(MediaFormat.KEY_FRAME_RATE) : 30; }
                catch (ClassCastException e) { fps = f.getFloat(MediaFormat.KEY_FRAME_RATE); }
                if (fps < 1 || fps > 240) fps = 30;
                durMs = f.containsKey(MediaFormat.KEY_DURATION) ? f.getLong(MediaFormat.KEY_DURATION) / 1000 : MediaTools.durationMs(this, u);
                break;
            }
        } catch (Exception e) { vw = 0; } finally { ex.release(); }
        if (vw <= 0) { info.setText(L.t("No puedo leer ese vídeo.")); opts.setVisibility(View.GONE); return; }
        int ss = Math.min(vw, vh);
        info.setText(name + "\n" + vw + " × " + vh + " (" + ss + "p) · " + fmtDur(durMs / 1000) + " · " + Math.round(fps) + " fps");
        // el primer tamaño que de verdad es más grande
        side = 2160;
        for (int s : SIDES) if (s > ss * 1.2f) { side = Math.max(s, Math.min(2160, ss * 3)); break; }
        side = closest(side);
        cmp.setVisibility(View.GONE);
        lastFrameSec = 0;
        opts.setVisibility(View.VISIBLE);
        marks();
    }

    static int closest(int v) { int best = SIDES[0]; for (int s : SIDES) if (Math.abs(s - v) < Math.abs(best - v)) best = s; return best; }

    float lastFrameSec;        // lo que tardó el fotograma de prueba
    int lastFrameSide = -1, lastFrameModel = -1;

    void marks() {
        int ss = Math.min(vw, vh);
        for (int i = 0; i < 4; i++) {
            boolean ok = SIDES[i] > ss * 1.2f;
            sideBtns[i].setAlpha(!ok ? 0.25f : SIDES[i] == side ? 1f : 0.5f);
            sideBtns[i].setEnabled(ok);
        }
        for (int i = 0; i < 2; i++) modelBtns[i].setAlpha(model == i ? 1f : 0.5f);
        long frames = (long) (durMs / 1000f * fps);
        int[] tg = SrCore.target(vw, vh, side);
        String t = L.t("Saldrá de") + " " + tg[0] + " × " + tg[1] + " · " + frames + " " + L.t("fotogramas");
        if (lastFrameSec > 0 && lastFrameSide == side && lastFrameModel == model) {
            long sec = (long) (frames * lastFrameSec * 1.08f);
            t += "\n" + L.t("Tardará más o menos") + " " + fmtDur(sec) + ".";
        } else t += "\n" + L.t("Pulsa PROBAR para saber cuánto tardará en tu teléfono.");
        if (side >= 2160 && ss <= 480) t += "\n" + L.t("De tan poco a 4K: se ve más nítido, pero un 1440p ya da casi lo mismo y tarda menos.");
        est.setText(t);
    }

    static String fmtDur(long s) {
        if (s >= 3600) return s / 3600 + " h " + (s % 3600) / 60 + " min";
        if (s >= 60) return s / 60 + " min " + (s % 60 > 0 ? s % 60 + " s" : "");
        return s + " s";
    }

    void test() {
        if (uri == null || testing) return;
        if (VideoSR.running) { toast(L.t("Espera a que termine el vídeo que se está ampliando.")); return; }
        testing = true;
        startBtn.setEnabled(false); startBtn.setAlpha(0.4f);
        est.setText(L.t("Prueba exprés: midiendo un trocito del fotograma…"));
        testProg.phase(L.t("Probando…"));
        final int sd = side, md = model;
        new Thread(() -> {
            String err = null;
            Bitmap fb = null, fa = null;
            float sec = 0;
            MediaMetadataRetriever mr = new MediaMetadataRetriever();
            try {
                mr.setDataSource(this, uri);
                Bitmap f = mr.getFrameAtTime(durMs * 500, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if (f == null) throw new Exception(L.t("No pude sacar un fotograma."));
                // del tamaño real del vídeo (girado si hace falta)
                boolean rot = (f.getWidth() > f.getHeight()) != (vw > vh);
                int fw = rot ? vh : vw, fh = rot ? vw : vh;
                if (f.getWidth() != fw || f.getHeight() != fh) f = Bitmap.createScaledBitmap(f, fw, fh, true);
                if (f.getConfig() != Bitmap.Config.ARGB_8888) f = f.copy(Bitmap.Config.ARGB_8888, false);
                int[] tg = SrCore.target(fw, fh, sd);
                VideoSR.session(this, md);                                    // cargar la red no cuenta en el tiempo
                // v1.8 · PRUEBA EXPRÉS: solo un trocito del centro (un «tile» de la red), y con eso se calcula el fotograma entero
                int sw = Math.min(fw, 240), sh = Math.min(fh, 240);
                int sx = (fw - sw) / 2, sy = Math.max(0, (fh - sh) / 3);
                Bitmap crop = Bitmap.createBitmap(f, sx, sy, sw, sh);
                double k = tg[0] / (double) fw;
                int ctw = Math.max(2, (int) Math.round(sw * k)), cth = Math.max(2, (int) Math.round(sh * k));
                long t0 = SystemClock.elapsedRealtime();
                Bitmap big = VideoSR.upscaleBitmap(this, crop, ctw, cth, md);
                float cropSec = (SystemClock.elapsedRealtime() - t0) / 1000f;
                // los trozos de 256 px con borde de 12 que hará con el fotograma entero
                int tiles = (int) (Math.ceil(fw / 256.0) * Math.ceil(fh / 256.0));
                sec = cropSec * tiles * 1.3f + 0.04f * tg[0] * tg[1] / 8.3e6f;   // + bordes + pasar a vídeo
                fb = Bitmap.createScaledBitmap(crop, ctw, cth, true);
                fa = big;
            } catch (Throwable e) {
                err = e.getMessage() == null ? e.toString() : e.getMessage();
            } finally {
                try { mr.release(); } catch (Exception ignored) {}
                if (!VideoSR.running) VideoSR.release();        // v1.8: nunca apagar la red si un vídeo la está usando
            }
            String fe = err;
            Bitmap b1 = fb, b2 = fa;
            float fs = sec;
            runOnUiThread(() -> {
                testing = false;
                testProg.hide();
                startBtn.setEnabled(true); startBtn.setAlpha(1f);
                if (fe != null) { est.setText(L.t("No se pudo probar: ") + fe); return; }
                lastFrameSec = fs; lastFrameSide = sd; lastFrameModel = md;
                before.setImageBitmap(b1);
                after.setImageBitmap(b2);
                cmp.setVisibility(View.VISIBLE);
                marks();
                est.append("\n" + String.format(Locale.ROOT, L.t("Un fotograma: %.1f s."), fs));
                if (afterTest != null) { Runnable r = afterTest; afterTest = null; r.run(); }
            });
        }, "probar-fotograma").start();
    }

    Runnable afterTest;

    void go() {
        if (uri == null) return;
        if (testing) { toast(L.t("Espera a que termine la prueba (unos segundos).")); return; }
        if (VideoSR.running) { toast(L.t("Ya hay un vídeo ampliándose.")); return; }
        if (Math.min(vw, vh) * 1.2f >= side) { toast(L.t("El vídeo ya tiene ese tamaño o más.")); return; }
        // v1.8: antes de empezar, saber cuánto va a tardar
        if (!(lastFrameSec > 0 && lastFrameSide == side && lastFrameModel == model)) { afterTest = this::confirmGo; test(); return; }
        confirmGo();
    }

    void confirmGo() {
        long frames = (long) (durMs / 1000f * fps);
        long sec = (long) (frames * lastFrameSec * 1.08f);
        String msg = L.t("Tardará más o menos") + " " + fmtDur(sec) + " (" + frames + " " + L.t("fotogramas") + ").";
        if (sec > 3 * 3600) {
            int lower = side > 1080 ? (side == 2160 ? 1440 : 1080) : 0;
            msg += "\n\n⚠ " + L.t("Es mucho tiempo para el teléfono.")
                    + (lower > 0 ? " " + L.t("Prueba con un tamaño menor") + " (" + lower + "p) " + L.t("o con un trozo más corto del vídeo.") : "");
        }
        new android.app.AlertDialog.Builder(this).setTitle(L.t("🎬 ¿Empezar?")).setMessage(msg)
                .setPositiveButton(L.t("▶ EMPEZAR"), (d, w) -> start0())
                .setNegativeButton(L.t("Cancelar"), null).show();
    }

    void start0() {
        if (VideoSR.running || testing) return;
        VideoSR.start(this, uri, side, model, name);
        toast(L.t("¡Empezado! Puedes salir: te aviso con una notificación."));
    }

    final Runnable tick = new Runnable() {
        public void run() {
            if (isFinishing()) return;
            if (VideoSR.running) {
                status.setText(VideoSR.srcName + (VideoSR.status.startsWith("🌡") ? "\n" + VideoSR.status : ""));
                prog.begin(VideoSR.startMs);
                if (VideoSR.total > 0) prog.set(L.t("Fotograma"), VideoSR.done, VideoSR.total);
                else prog.phase(VideoSR.status);
                startBtn.setEnabled(false);
                startBtn.setAlpha(0.4f);
            } else {
                prog.hide();
                status.setText(VideoSR.status.isEmpty() ? L.t("Nada en marcha.") : VideoSR.srcName + "\n" + VideoSR.status);
                startBtn.setEnabled(!testing);
                startBtn.setAlpha(testing ? 0.4f : 1f);
            }
            h.postDelayed(this, 1000);
        }
    };

    @Override protected void onDestroy() { h.removeCallbacks(tick); super.onDestroy(); }
}
