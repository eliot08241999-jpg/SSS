package com.aplauso.encuentra;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * v1.3 · ESTUDIO DE DIBUJO: crea imágenes con IA dentro del teléfono (Stable Diffusion 1.5, sin internet ni cupos).
 * Texto → imagen, «lo que NO quieres», a partir de una imagen tuya (img2img) y ampliar el resultado.
 */
public class DrawStudioActivity extends NeonActivity {
    static final int REQ_INIT = 93, REQ_CHAR = 94, REQ_HIST = 92;
    LinearLayout charsBox;
    static final String[][] SIZES = {{"Cuadrada 512×512", "512", "512"}, {"Vertical 512×768", "512", "768"},
            {"Horizontal 768×512", "768", "512"}, {"Rápida 384×384", "384", "384"}};
    static final String[][] CHIPS = {
            {"✨ Calidad", "masterpiece, best quality, highly detailed"},
            {"👧 Chica anime", "1girl, anime style, beautiful detailed eyes"},
            {"🧑 Chico anime", "1boy, anime style, detailed face"},
            {"🌄 Paisaje", "scenery, landscape, sky, clouds, sunset"},
            {"🌃 Ciudad neón", "cyberpunk city at night, neon lights, rain"},
            {"🐉 Fantasía", "fantasy, magic, epic, dramatic lighting"},
            {"🎨 Acuarela", "watercolor painting, soft colors"},
            {"📷 Foto", "photo, realistic, 35mm, natural light"},
            {"🐱 Animal mono", "cute animal, chibi, kawaii"},
    };

    String modelId;
    int sizeIdx, steps, cfg10, strength;
    EditText prompt, negative, seedIn;
    TextView info, sizeBtn, drawBtn, initInfo;
    NeonProgress drawProg;
    ImageView view, initView;
    LinearLayout modelsBox;
    Bitmap result, init;
    SdEngine.Job job;
    boolean running, translating;
    TextView transBtn;
    android.widget.ProgressBar transSpin, drawSpin;

    /** v1.3.3: rueda que gira mientras trabaja (para que se vea que no está colgada). */
    android.widget.ProgressBar spinner() {
        android.widget.ProgressBar pb = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setIndeterminate(true);
        pb.setVisibility(android.view.View.GONE);
        try { pb.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(Neon.DEFAULT_COLOR)); } catch (Exception ignored) {}
        return pb;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        modelId = p.getString("sd_model", "anything5");
        sizeIdx = p.getInt("sd_size", 0);
        LinearLayout col = screen("🎨 ESTUDIO DE DIBUJO");

        // ---- modelos ----
        LinearLayout pm = panel("◢ ESTILO (MODELO)");
        pm.addView(small("Cada estilo es un modelo de IA que se descarga una vez (≈1,3 GB) y luego dibuja sin internet."));
        modelsBox = new LinearLayout(this);
        modelsBox.setOrientation(LinearLayout.VERTICAL);
        pm.addView(modelsBox);
        col.addView(pm, gapBelow(14));

        // ---- qué dibujar ----
        LinearLayout pp = panel("◢ QUÉ DIBUJAR");
        prompt = area(pp, "Describe la imagen (mejor en inglés: «a girl with silver hair in a forest»)", p.getString("sd_prompt", ""));
        // v1.7: contador de fichas (lo que ocupa la descripción) y prompts largos
        TextView tokTv = small("");
        pp.addView(tokTv);
        Runnable tokUpd = () -> {
            String t = prompt.getText().toString();
            int n = SdEngine.tok != null ? SdEngine.tok.countAll(t) : (int) Math.round(t.trim().isEmpty() ? 0 : t.trim().split("[\\s,]+").length * 1.3);
            int chunks = Math.max(1, (n + 74) / 75);
            tokTv.setText((SdEngine.tok != null ? "" : "≈") + n + " " + L.t("fichas") + (chunks > 1 ? " · " + chunks + " " + L.t("trozos (se lee todo)") : " / 75"));
            tokTv.setTextColor(chunks > 4 ? Color.rgb(255, 170, 110) : Color.rgb(150, 160, 185));
        };
        prompt.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence a, int b, int c, int d) {}
            public void onTextChanged(CharSequence a, int b, int c, int d) {}
            public void afterTextChanged(android.text.Editable e) { tokUpd.run(); }
        });
        tokUpd.run();
        pp.addView(small("Truco: pon entre paréntesis lo que más te importa, con un número: (single tulip:1.4). Más de 1,5 suele deformar. "
                + "Lo más importante, al principio. Escribe BREAK para separar ideas (personaje BREAK ropa BREAK fondo): se mezclan menos."), gapBelow(6));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        LinearLayout chips = new LinearLayout(this);
        for (String[] ch : CHIPS) {
            TextView t = button(ch[0], v -> addToPrompt(ch[1]));
            t.setTextSize(12);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dpi(6);
            chips.addView(t, lp);
        }
        hs.addView(chips);
        pp.addView(hs, gapBelow(8));
        transBtn = button("🌐 PASAR AL INGLÉS (con el cerebro de Chloe)", v -> translate());
        pp.addView(transBtn, gapBelow(4));
        transSpin = spinner();
        pp.addView(transSpin, gapBelow(4));
        negative = area(pp, "Lo que NO quieres en la imagen", p.getString("sd_neg", SdEngine.DEFAULT_NEG));
        negChips(pp);                                       // v1.8: etiquetas rápidas para el negativo
        col.addView(pp, gapBelow(14));

        // ---- v1.4: personajes ----
        LinearLayout pc = panel("◢ PERSONAJES");
        pc.addView(small("Importa un personaje entrenado para Stable Diffusion 1.5 (archivo .safetensors o .pt, lo que llaman «embedding» o «textual inversion»). Luego escribe su nombre en la descripción. Los LoRA no sirven en el móvil."));
        charsBox = new LinearLayout(this);
        charsBox.setOrientation(LinearLayout.VERTICAL);
        pc.addView(charsBox, gapBelow(6));
        pc.addView(button("➕ IMPORTAR PERSONAJE", v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, L.t("Elige el archivo del personaje")), REQ_CHAR);
        }));
        TextView use = small("Para ti o para fan art sin ánimo de lucro. Si publicas algo, márcalo como hecho con IA.");
        use.setTextSize(10);
        pc.addView(use);
        col.addView(pc, gapBelow(14));
        refreshChars();

        // ---- ajustes ----
        LinearLayout pa = panel("◢ AJUSTES");
        sizeBtn = button("", v -> { sizeIdx = (sizeIdx + 1) % SIZES.length; p.edit().putInt("sd_size", sizeIdx).apply(); labels(); });
        pa.addView(sizeBtn, gapBelow(6));
        steps = p.getInt("sd_steps", 20);
        slider(pa, "Pasos (más = más detalle y más lento)", "sd_steps", 20, 4, 40, "", v -> steps = v);
        cfg10 = p.getInt("sd_cfg", 7);
        slider(pa, "Cuánto obedece al texto", "sd_cfg", 7, 1, 14, "", v -> cfg10 = v);
        seedIn = new EditText(this);
        seedIn.setHint(L.t("Semilla (vacía = al azar; repite una para rehacer igual)"));
        seedIn.setInputType(InputType.TYPE_CLASS_NUMBER);
        seedIn.setTextColor(Color.WHITE);
        seedIn.setHintTextColor(Color.GRAY);
        seedIn.setTextSize(13);
        seedIn.setBackground(frame(10));
        seedIn.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        pa.addView(seedIn, gapBelow(6));
        // v1.7
        android.widget.Switch prec = neonSwitch("📖 Lector de texto preciso (lee todo el prompt)");
        prec.setChecked(SdEngine.preciseText(this));
        prec.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("sd_te_float", on).apply());
        pa.addView(prec);
        pa.addView(small("El lector de texto de estos modelos venía comprimido y se quedaba con las primeras palabras. Con esto lee sin comprimir "
                + "(apenas más lento, ocupa ≈0,4 GB más de memoria mientras dibuja). Apágalo y repite con la misma semilla para comparar."), gapBelow(6));
        android.widget.Switch coolSw = neonSwitch("🌡 Modo fresco (más lento, el móvil no se calienta)");
        coolSw.setChecked(Thermal.on(this));
        coolSw.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("sd_cool", on).apply());
        pa.addView(coolSw);
        pa.addView(small("Usa menos núcleos y descansa entre pasos; si la batería pasa de 40 °C se para hasta que baje a 36 °C y sigue sola. "
                + "Vale también para ampliar vídeos."), gapBelow(6));
        col.addView(pa, gapBelow(14));

        // ---- a partir de una imagen ----
        LinearLayout pi = panel("◢ A PARTIR DE UNA IMAGEN (opcional)");
        initInfo = small("Usa una foto o dibujo tuyo como base: la IA lo redibuja con tu descripción.");
        pi.addView(initInfo);
        LinearLayout row = new LinearLayout(this);
        row.addView(button("🖼 ELEGIR", v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
            PickActivity.start(this, i, REQ_INIT, "studio_init");
        }), new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(button("✖ QUITAR", v -> { init = null; initView.setImageBitmap(null); initView.setVisibility(android.view.View.GONE); }), new LinearLayout.LayoutParams(0, -2, 1));
        pi.addView(row, gapBelow(6));
        pi.addView(button("🌑 BASE OSCURA CON UN RAYO DE LUZ", v -> darkBase()), gapBelow(6));
        initView = new ImageView(this);
        initView.setAdjustViewBounds(true);
        initView.setVisibility(android.view.View.GONE);
        pi.addView(initView, new LinearLayout.LayoutParams(-1, dpi(140)));
        strength = p.getInt("sd_strength", 60);
        slider(pi, "Cuánto cambia (poco = se parece más a la tuya)", "sd_strength", 60, 20, 95, " %", v -> strength = v);
        col.addView(pi, gapBelow(14));

        // ---- dibujar ----
        LinearLayout pd = panel("◢ RESULTADO");
        drawBtn = button("✨ DIBUJAR", v -> draw());       // v1.7.6: si ya está dibujando, se suma a la cola
        pd.addView(drawBtn, gapBelow(4));
        stopBtn = button("⏹ PARAR", v -> stop());
        stopBtn.setVisibility(android.view.View.GONE);
        pd.addView(stopBtn, gapBelow(4));
        contBtn = button("↻ REINTENTAR", v -> {           // v1.7.6: lo que quedó a medias o falló (sigue desde el paso guardado)
            int n = DrawHistory.retryAll(this);
            DrawService.kick(this);
            toast(n + " " + L.t("vuelven a la cola"));
            refreshDraw();
        });
        contBtn.setVisibility(android.view.View.GONE);
        pd.addView(contBtn, gapBelow(4));
        // v1.7.3: cuántas de una vez
        drawCount = p.getInt("sd_count", 1);
        int[] counts = {1, 2, 3, 4, 6, 8};
        TextView cntBtn = button("", null);
        Runnable cntLbl = () -> cntBtn.setText(L.t("Cuántas: ") + drawCount + (drawCount > 1 ? " · " + L.t("una detrás de otra") : ""));
        cntBtn.setOnClickListener(v -> {
            int k = 0;
            for (int i = 0; i < counts.length; i++) if (counts[i] == drawCount) k = i;
            drawCount = counts[(k + 1) % counts.length];
            p.edit().putInt("sd_count", drawCount).apply();
            cntLbl.run();
        });
        cntLbl.run();
        cntBtn.setTextSize(13);
        pd.addView(cntBtn, gapBelow(4));
        drawSpin = spinner();
        pd.addView(drawSpin, gapBelow(4));
        info = small("Elige un estilo, describe la imagen y pulsa DIBUJAR. Dibuja en segundo plano: puedes salir de la app y te aviso al terminar. Quedan 24 h en el historial: guarda o fija las que quieras.");
        pd.addView(info, gapBelow(6));
        drawProg = new NeonProgress(this);                 // v1.8: barra de verdad
        pd.addView(drawProg, gapBelow(6));
        view = new ImageView(this);
        view.setAdjustViewBounds(true);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pd.addView(view, new LinearLayout.LayoutParams(-1, dpi(360)));
        stripBox = new android.widget.HorizontalScrollView(this);
        strip = new LinearLayout(this);
        stripBox.addView(strip);
        stripBox.setVisibility(android.view.View.GONE);
        LinearLayout.LayoutParams sbl = new LinearLayout.LayoutParams(-1, -2); sbl.topMargin = dpi(6);
        pd.addView(stripBox, sbl);
        pd.addView(button("🕘 HISTORIAL (24 h)", v -> startActivityForResult(new Intent(this, DrawHistoryActivity.class), REQ_HIST)), gapBelow(6));
        new Thread(() -> DrawHistory.cleanup(this)).start();
        LinearLayout r2 = new LinearLayout(this);
        r2.addView(button("💾 GUARDAR", v -> save(result, "SSS_dibujo_")), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(button("🔍 AMPLIAR ×2", v -> upscale()), new LinearLayout.LayoutParams(0, -2, 1));
        pd.addView(r2, gapBelow(6));
        pd.addView(button("🔁 USAR COMO BASE", v -> {
            if (result == null) { toast(L.t("Primero dibuja algo.")); return; }
            init = result; initView.setImageBitmap(init); initView.setVisibility(android.view.View.VISIBLE);
            toast(L.t("Listo: ahora cambia la descripción y vuelve a DIBUJAR."));
        }), gapBelow(6));
        TextView lic = small("Modelos con licencia CreativeML OpenRAIL-M: no se pueden usar para hacer daño, engañar ni para imágenes de personas reales sin permiso.");
        lic.setTextSize(10);
        pd.addView(lic);
        col.addView(pd, gapBelow(14));

        labels();
        refreshModels();
        h.postDelayed(tick, 1500);
        // v1.8: «Chloe, dibuja un perro con sombrero de paja» → llega aquí, se traduce y se dibuja solo
        String cp = getIntent().getStringExtra(EXTRA_CHLOE_PROMPT);
        if (cp != null && !cp.trim().isEmpty()) {
            prompt.setText(cp.trim());
            autoDraw = true;
            if (LocalBrain.ready(this)) h.postDelayed(this::translate, 400);
            else h.postDelayed(this::draw, 400);
        }
    }

    static final String EXTRA_CHLOE_PROMPT = "chloe_prompt";
    boolean autoDraw;

    final Runnable tick = new Runnable() {
        public void run() {
            if (isFinishing()) return;
            boolean any = false;
            for (String[] m : SdEngine.MODELS) if (SdEngine.prefs(DrawStudioActivity.this).contains("sd_dl_" + m[0]) || FastDownload.running(m[0])) any = true;
            if (!any && wasRunning) refreshModels();             // acaba de terminar
            wasRunning = FastDownload.runningId != null;
            if (any) refreshModels();
            h.postDelayed(this, 2000);
        }
    };

    boolean wasRunning;

    TextView small(String s) {
        TextView t = text(s, 12);
        t.setTextColor(Color.rgb(170, 180, 200));
        return t;
    }

    // ------------------------------------------------------------------ v1.8: negativo con etiquetas rápidas
    static final String[][] NEG_GROUPS = {
            {"🖐 Manos", "bad hands, extra fingers, fewer fingers, missing fingers, fused fingers, too many fingers, mutated hands"},
            {"🦵 Cuerpo", "bad anatomy, extra limbs, extra arms, extra legs, missing arms, missing legs, long neck, bad proportions, malformed limbs"},
            {"😶 Cara", "bad face, asymmetric eyes, cross-eyed, deformed face, ugly face, bad eyes"},
            {"🖼 Calidad", "lowres, worst quality, low quality, blurry, jpeg artifacts, noise, pixelated, out of focus"},
            {"🔤 Texto", "text, watermark, signature, logo, username, artist name"},
            {"🔞 NSFW", "nsfw, nude, naked, explicit"},
            {"✂ Encuadre", "cropped, out of frame, cut off"},
    };

    void negChips(LinearLayout pp) {
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        for (String[] g : NEG_GROUPS) {
            TextView t = button(g[0], null);
            t.setTextSize(12);
            t.setOnClickListener(v -> { toggleNeg(g[1]); markNeg(row); });
            t.setTag(g[1]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dpi(6);
            row.addView(t, lp);
        }
        TextView mine = button("⭐ Mis negativos", v -> myNegatives(row));
        mine.setTextSize(12);
        row.addView(mine);
        hs.addView(row);
        pp.addView(hs, gapBelow(4));
        TextView tip = small("Toca una etiqueta para añadirla o quitarla. Pesos como en la descripción: (extra fingers:1.4) insiste más. "
                + "El negativo reduce mucho lo que no quieres, pero no lo garantiza al 100 %.");
        pp.addView(tip, gapBelow(8));
        markNeg(row);
        negative.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(android.text.Editable e) { markNeg(row); }
        });
    }

    static java.util.List<String> negTerms(String s) {
        java.util.List<String> l = new java.util.ArrayList<>();
        for (String t : s.split(",")) { t = t.trim(); if (!t.isEmpty()) l.add(t); }
        return l;
    }

    static String bare(String t) { return t.replaceAll("^[(\\[]+|[)\\]]+$", "").replaceAll(":[0-9.]+$", "").trim().toLowerCase(java.util.Locale.ROOT); }

    boolean hasAll(String group) {
        java.util.Set<String> have = new java.util.HashSet<>();
        for (String t : negTerms(negative.getText().toString())) have.add(bare(t));
        for (String t : negTerms(group)) if (!have.contains(bare(t))) return false;
        return true;
    }

    void toggleNeg(String group) {
        java.util.List<String> cur = negTerms(negative.getText().toString());
        java.util.Set<String> g = new java.util.HashSet<>();
        for (String t : negTerms(group)) g.add(bare(t));
        if (hasAll(group)) {
            java.util.Iterator<String> it = cur.iterator();
            while (it.hasNext()) if (g.contains(bare(it.next()))) it.remove();
        } else {
            java.util.Set<String> have = new java.util.HashSet<>();
            for (String t : cur) have.add(bare(t));
            for (String t : negTerms(group)) if (!have.contains(bare(t))) cur.add(t);
        }
        negative.setText(android.text.TextUtils.join(", ", cur));
        negative.setSelection(negative.getText().length());
    }

    void markNeg(LinearLayout row) {
        for (int i = 0; i < row.getChildCount(); i++) {
            Object tag = row.getChildAt(i).getTag();
            if (tag instanceof String) row.getChildAt(i).setAlpha(hasAll((String) tag) ? 1f : 0.45f);
        }
    }

    /** Grupos propios guardados: «Mi negativo anime», «Mi negativo realista»… */
    void myNegatives(LinearLayout row) {
        String raw = p.getString("sd_neg_sets", "");
        java.util.List<String[]> sets = new java.util.ArrayList<>();
        for (String line : raw.split("\n")) { int k = line.indexOf('\t'); if (k > 0) sets.add(new String[]{line.substring(0, k), line.substring(k + 1)}); }
        java.util.List<String> names = new java.util.ArrayList<>();
        for (String[] st : sets) names.add("⭐ " + st[0]);
        names.add(L.t("💾 Guardar el negativo actual…"));
        names.add(L.t("↺ Volver al negativo por defecto"));
        if (!sets.isEmpty()) names.add(L.t("🗑 Borrar uno…"));
        new android.app.AlertDialog.Builder(this).setTitle(L.t("⭐ Mis negativos"))
                .setItems(names.toArray(new String[0]), (d, w) -> {
                    if (w < sets.size()) { negative.setText(sets.get(w)[1]); return; }
                    int k = w - sets.size();
                    if (k == 0) {
                        EditText e = new EditText(this);
                        e.setHint(L.t("Nombre (p. ej. Mi negativo anime)"));
                        new android.app.AlertDialog.Builder(this).setTitle(L.t("💾 Guardar negativo")).setView(e)
                                .setPositiveButton("OK", (d2, w2) -> {
                                    String n = e.getText().toString().replace("\t", " ").replace("\n", " ").trim();
                                    if (n.isEmpty()) return;
                                    String v = negative.getText().toString().replace("\n", " ");
                                    p.edit().putString("sd_neg_sets", (raw.isEmpty() ? "" : raw + "\n") + n + "\t" + v).apply();
                                    toast(L.t("Guardado."));
                                }).setNegativeButton(L.t("Cancelar"), null).show();
                    } else if (k == 1) negative.setText(SdEngine.DEFAULT_NEG);
                    else {
                        String[] nn = new String[sets.size()];
                        for (int i = 0; i < nn.length; i++) nn[i] = sets.get(i)[0];
                        new android.app.AlertDialog.Builder(this).setTitle(L.t("🗑 Borrar")).setItems(nn, (d3, w3) -> {
                            StringBuilder sb = new StringBuilder();
                            for (int i = 0; i < sets.size(); i++) if (i != w3) sb.append(sb.length() > 0 ? "\n" : "").append(sets.get(i)[0]).append('\t').append(sets.get(i)[1]);
                            p.edit().putString("sd_neg_sets", sb.toString()).apply();
                        }).show();
                    }
                }).show();
    }

    EditText area(LinearLayout pn, String hint, String val) {
        EditText e = new EditText(this);
        e.setHint(L.t(hint));
        e.setText(val);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setTextSize(14);
        e.setMinLines(2);
        e.setMaxLines(6);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setBackground(frame(10));
        e.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        pn.addView(e, gapBelow(8));
        return e;
    }

    /**
     * v1.3.6: el modelo del móvil (SD 1.5) casi no sabe hacer imágenes muy oscuras: tiende a un brillo «medio».
     * Partiendo de una base negra con un rayo de luz que cae en el centro, sí respeta la oscuridad.
     */
    void darkBase() {
        int w = Integer.parseInt(SIZES[sizeIdx][1]), hh = Integer.parseInt(SIZES[sizeIdx][2]);
        Bitmap b = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(b);
        c.drawColor(Color.rgb(4, 4, 8));
        android.graphics.Paint p2 = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        // rayo: de arriba a la izquierda hacia el centro-abajo
        android.graphics.Path ray = new android.graphics.Path();
        ray.moveTo(w * 0.30f, 0); ray.lineTo(w * 0.42f, 0); ray.lineTo(w * 0.58f, hh * 0.72f); ray.lineTo(w * 0.44f, hh * 0.72f); ray.close();
        p2.setShader(new android.graphics.LinearGradient(0, 0, 0, hh * 0.72f, Color.argb(30, 255, 240, 200), Color.argb(150, 255, 235, 180), android.graphics.Shader.TileMode.CLAMP));
        p2.setMaskFilter(new android.graphics.BlurMaskFilter(w * 0.04f, android.graphics.BlurMaskFilter.Blur.NORMAL));
        c.drawPath(ray, p2);
        // charco de luz donde cae
        p2.setShader(new android.graphics.RadialGradient(w * 0.51f, hh * 0.74f, w * 0.16f, Color.argb(190, 255, 240, 190), Color.argb(0, 255, 240, 190), android.graphics.Shader.TileMode.CLAMP));
        p2.setMaskFilter(null);
        c.drawCircle(w * 0.51f, hh * 0.74f, w * 0.16f, p2);
        init = b;
        initView.setImageBitmap(b);
        initView.setVisibility(android.view.View.VISIBLE);
        info.setText(L.t("Base oscura lista. Pon «Cuánto cambia» en 75-85 % y pulsa DIBUJAR: lo importante se dibuja donde cae la luz."));
    }

    void addToPrompt(String s) {
        String t = prompt.getText().toString().trim();
        prompt.setText(t.isEmpty() ? s : t + ", " + s);
        prompt.setSelection(prompt.getText().length());
    }

    void labels() {
        sizeBtn.setText(L.t("Tamaño: ") + L.t(SIZES[sizeIdx][0]));
    }

    void refreshModels() {
        modelsBox.removeAllViews();
        for (String[] m : SdEngine.MODELS) {
            boolean sel = m[0].equals(modelId), ok = SdEngine.ready(this, m[0]);
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dpi(10), dpi(8), dpi(10), dpi(8));
            if (sel) box.setBackground(frame(10));
            TextView t = text((sel ? "● " : "○ ") + m[1], 15);
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            box.addView(t);
            box.addView(small(m[2]));
            box.addView(small(SdEngine.progress(this, m[0])));
            LinearLayout row = new LinearLayout(this);
            if (!sel) row.addView(button("USAR", v -> { modelId = m[0]; p.edit().putString("sd_model", modelId).apply(); refreshModels(); }), new LinearLayout.LayoutParams(0, -2, 1));
            long[] stt = SdEngine.status(this, m[0]);
            if (!ok && (stt == null || stt[0] == android.app.DownloadManager.STATUS_FAILED))
                row.addView(button("⬇ DESCARGAR", v -> {
                    if (FastDownload.runningId != null) { toast(L.t("Espera a que termine la otra descarga.")); return; }
                    SdEngine.startDownload(this, m[0]); h.postDelayed(this::refreshModels, 800); }), new LinearLayout.LayoutParams(0, -2, 1));
            else if (!ok) row.addView(button("✖ CANCELAR", v -> { SdEngine.cancel(this, m[0]); refreshModels(); }), new LinearLayout.LayoutParams(0, -2, 1));
            else row.addView(button("🗑 BORRAR", v -> { SdEngine.delete(this, m[0]); refreshModels(); }), new LinearLayout.LayoutParams(0, -2, 1));
            box.addView(row);
            box.setClickable(true);
            box.setOnClickListener(v -> { modelId = m[0]; p.edit().putString("sd_model", modelId).apply(); refreshModels(); });
            modelsBox.addView(box, gapBelow(6));
        }
    }

    void translate() {
        if (translating) { toast(L.t("Ya estoy traduciendo, espera un momento…")); return; }
        String t = prompt.getText().toString().trim();
        if (t.isEmpty()) { toast(L.t("Primero escribe qué quieres dibujar.")); return; }
        if (!LocalBrain.ready(this)) { toast(L.t("Para traducir, descarga el cerebro de Chloe (pantalla del asistente).")); return; }
        translating = true;
        transBtn.setText(L.t("⏳ TRADUCIENDO… (espera)"));
        transBtn.setAlpha(0.5f);
        transSpin.setVisibility(android.view.View.VISIBLE);
        info.setText(L.t("Traduciendo… la primera vez Chloe tarda unos segundos en despertar."));
        new Thread(() -> {
            String r;
            try {
                r = LocalBrain.generate(this, "You translate image descriptions into short English prompts for Stable Diffusion. "
                        + "Reply ONLY with the English prompt: comma-separated keywords, no explanations, no quotes.", new java.util.ArrayList<>(), t);
                r = r == null ? "" : r.replaceAll("(?s)^.*?:\\s*(?=[a-zA-Z])", "").replace("\"", "").trim();
            } catch (Exception e) { r = ""; }
            LocalBrain.close();                    // libera la memoria para dibujar
            String out = r;
            runOnUiThread(() -> {
                translating = false;
                transBtn.setText(L.t("🌐 PASAR AL INGLÉS (con el cerebro de Chloe)"));
                transBtn.setAlpha(1f);
                transSpin.setVisibility(android.view.View.GONE);
                if (out.isEmpty()) { info.setText(L.t("No he podido traducirlo.")); if (autoDraw) { autoDraw = false; draw(); } return; }
                prompt.setText(out);
                info.setText(L.t("Traducido. Ya puedes pulsar DIBUJAR."));
                if (autoDraw) { autoDraw = false; draw(); }
            });
        }, "traducir").start();
    }

    void draw() {
        if (translating) { toast(L.t("Espera a que termine de traducir.")); return; }
        String t = prompt.getText().toString().trim();
        if (t.isEmpty()) { toast(L.t("Describe qué quieres dibujar.")); return; }
        if (!SdEngine.ready(this, modelId)) { toast(L.t("Primero descarga ese estilo (botón DESCARGAR).")); return; }
        p.edit().putString("sd_prompt", t).putString("sd_neg", negative.getText().toString()).apply();
        SdEngine.Job j = new SdEngine.Job();
        j.model = modelId;
        j.prompt = t;
        j.negative = negative.getText().toString();
        j.width = Integer.parseInt(SIZES[sizeIdx][1]);
        j.height = Integer.parseInt(SIZES[sizeIdx][2]);
        boolean lcm = SdEngine.isLcm(modelId);
        j.steps = lcm ? Math.max(4, Math.min(8, steps)) : Math.max(8, steps);
        j.cfg = lcm ? Math.min(8f, Math.max(1f, cfg10)) : cfg10;
        j.strength = strength / 100f;
        j.init = init;
        try { j.seed = seedIn.getText().toString().trim().isEmpty() ? -1 : Long.parseLong(seedIn.getText().toString().trim()); } catch (Exception e) { j.seed = -1; }
        // v1.7.3: dibuja en segundo plano (aunque salgas) y puede hacer varias de una vez
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 91);
        job = j;
        // v1.7.6: cada dibujo entra YA en el historial («en cola»): no se pierde aunque se corte
        long batch = DrawHistory.enqueue(this, j, drawCount);
        p.edit().putLong("draw_batch", batch).apply();
        DrawService.kick(this);
        askBattery();
        toast(drawCount > 1 ? drawCount + " " + L.t("dibujos en la cola") : L.t("En la cola: ya está en el historial"));
        refreshDraw();
    }

    /** Pinta el estado (lo llama el servicio en cada paso). */
    void refreshDraw() {
        running = DrawService.running;
        drawBtn.setText(running ? L.t("＋ AÑADIR A LA COLA") : L.t("✨ DIBUJAR"));
        stopBtn.setVisibility(running ? android.view.View.VISIBLE : android.view.View.GONE);
        drawSpin.setVisibility(running ? android.view.View.VISIBLE : android.view.View.GONE);
        int queued = DrawHistory.count(this, DrawHistory.QUEUED);
        int broken = DrawHistory.count(this, DrawHistory.FAILED) + DrawHistory.count(this, DrawHistory.STOPPED);
        contBtn.setText("↻ " + L.t("REINTENTAR LO QUE QUEDÓ A MEDIAS") + " (" + broken + ")");
        contBtn.setVisibility(broken > 0 && !running ? android.view.View.VISIBLE : android.view.View.GONE);
        if (running && DrawService.current != null) {
            drawProg.begin(DrawService.itemStartMs);
            if (DrawService.step >= 0) drawProg.set(L.t("Paso"), DrawService.step, DrawService.steps);
            else drawProg.phase(DrawService.status);
        } else drawProg.hide();
        if (running) info.setText(DrawService.status + (queued > 0 ? " · " + L.t("en cola") + ": " + queued : "") + "\n" + L.t("Puedes salir de la app: sigue dibujando y te aviso."));
        else if (!DrawService.status.isEmpty()) info.setText(DrawService.status + (broken > 0 ? "\n⚠ " + broken + " " + L.t("a medias: tócalos abajo o pulsa ↻ (siguen desde el paso guardado).") : ""));
        else if (broken > 0) info.setText("⚠ " + broken + " " + L.t("a medias: tócalos abajo o pulsa ↻ (siguen desde el paso guardado)."));
        Bitmap pv = DrawService.preview;
        SdEngine.Job j = DrawService.job;
        if (running && pv != null && j != null && pv != lastPreview) { lastPreview = pv; view.setImageBitmap(Bitmap.createScaledBitmap(pv, j.width, j.height, true)); }
        // la tanda de ahora, como miniaturas (hechas, dibujándose, en cola o a medias)
        long batch = p.getLong("draw_batch", 0);
        java.util.List<DrawHistory.Item> its = batch == 0 ? new java.util.ArrayList<>() : DrawHistory.batch(this, batch);
        String sig = "";
        for (DrawHistory.Item it : its) sig += it.id + it.status + (DrawService.current == it ? DrawService.percent / 10 : "") + ";";
        if (!sig.equals(stripSig)) {
            stripSig = sig;
            strip.removeAllViews();
            for (DrawHistory.Item it : its) addTile(it);
        }
        stripBox.setVisibility(its.size() > 1 || (its.size() == 1 && !its.get(0).done()) ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    String stripSig = "";
    final java.util.Map<String, Bitmap> thumbs = new java.util.HashMap<>();

    void addTile(DrawHistory.Item it) {
        android.widget.FrameLayout cell = new android.widget.FrameLayout(this);
        ImageView t = new ImageView(this);
        t.setScaleType(ImageView.ScaleType.CENTER_CROP);
        t.setBackground(frame(8));
        t.setPadding(dpi(2), dpi(2), dpi(2), dpi(2));
        cell.addView(t, new android.widget.FrameLayout.LayoutParams(-1, -1));
        if (it.done()) {
            Bitmap bm = thumbs.get(it.id);
            if (bm == null) { bm = DrawHistory.load(this, it, 768); if (bm != null) thumbs.put(it.id, bm); }
            final Bitmap fb = bm;
            t.setImageBitmap(bm);
            cell.setOnClickListener(v -> { if (fb != null) { result = fb; view.setImageBitmap(fb); } });
            if (bm != null && !shownDone.contains(it.id)) { shownDone.add(it.id); result = bm; view.setImageBitmap(bm); }
        } else {
            TextView lab = new TextView(this);
            lab.setText(DrawHistory.leftText(this, it));
            lab.setTextSize(11);
            lab.setTextColor(Color.WHITE);
            lab.setGravity(Gravity.CENTER);
            lab.setPadding(dpi(4), dpi(4), dpi(4), dpi(4));
            cell.addView(lab, new android.widget.FrameLayout.LayoutParams(-1, -1));
            if (DrawHistory.FAILED.equals(it.status) || DrawHistory.STOPPED.equals(it.status))
                cell.setOnClickListener(v -> { DrawHistory.retry(this, it); DrawService.kick(this); toast(L.t("Otra vez a la cola (sigue desde el paso guardado).")); refreshDraw(); });
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpi(84), dpi(84));
        lp.rightMargin = dpi(6);
        strip.addView(cell, lp);
    }

    final java.util.Set<String> shownDone = new java.util.HashSet<>();
    TextView stopBtn;

    Bitmap lastPreview;
    TextView contBtn;

    /** v1.7.5: la primera vez, pide que Android no cierre la app para ahorrar batería mientras dibuja. */
    void askBattery() {
        if (p.getBoolean("draw_batt_asked", false)) return;
        android.os.PowerManager pm = getSystemService(android.os.PowerManager.class);
        if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) return;
        p.edit().putBoolean("draw_batt_asked", true).apply();
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Para que no se corte"))
                .setMessage(L.t("Xiaomi/POCO cierra las apps en segundo plano para ahorrar batería y el dibujo se pierde a medias. Permite que Chloe Nova funcione «Sin restricciones»; "
                        + "si después sigue pasando, activa también «Inicio automático» en los ajustes de la app."))
                .setPositiveButton(L.t("PERMITIR"), (d, w) -> {
                    try {
                        startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) {
                        try { startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) {}
                    }
                })
                .setNeutralButton(L.t("AJUSTES DE LA APP"), (d, w) -> {
                    try { startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) {}
                })
                .setNegativeButton(L.t("Ahora no"), null).show();
    }
    int shownResults, drawCount = 1;
    LinearLayout strip;
    android.widget.HorizontalScrollView stripBox;

    @Override protected void onResume() {
        super.onResume();
        DrawService.listener = () -> runOnUiThread(this::refreshDraw);
        if (drawBtn != null) {
            DrawHistory.reconcile(this);                 // lo que Android cortó: queda «a medias» con ↻
            stripSig = "";
            refreshDraw();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        DrawService.listener = null;
    }

    void stop() {
        DrawService.stop(this);
        info.setText(L.t("Parando…"));
    }

    void upscale() {
        if (result == null) { toast(L.t("Primero dibuja algo.")); return; }
        info.setText(L.t("Ampliando…"));
        Bitmap src = result;
        new Thread(() -> {
            try {
                Bitmap big = UpscaleActivity.sharpen(UpscaleActivity.bicubic2x(src), 0.55f);
                runOnUiThread(() -> { result = big; view.setImageBitmap(big); info.setText(big.getWidth() + "×" + big.getHeight() + " · " + L.t("pulsa GUARDAR.")); });
            } catch (OutOfMemoryError e) { runOnUiThread(() -> info.setText(L.t("No hay memoria suficiente para ampliar."))); }
        }, "ampliar").start();
    }

    void save(Bitmap b, String prefix) {
        if (b == null) { toast(L.t("Primero dibuja algo.")); return; }
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, prefix + System.currentTimeMillis() + ".png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (android.os.Build.VERSION.SDK_INT >= 29) v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SSS+");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            try (OutputStream os = getContentResolver().openOutputStream(u)) { b.compress(Bitmap.CompressFormat.PNG, 100, os); }
            toast(L.t("Guardada en Imágenes/SSS+"));
        } catch (Exception e) {
            toast(L.t("No se pudo guardar: ") + e.getMessage());
        }
    }

    void refreshChars() {
        charsBox.removeAllViews();
        java.util.List<SdChars.Char> l = SdChars.all(this);
        if (l.isEmpty()) { charsBox.addView(small(L.t("(ninguno todavía)"))); return; }
        for (SdChars.Char ch : l) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView t = text("🧑‍🎨 " + ch.name, 14);
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(button("✍", v -> addToPrompt(ch.name)), new LinearLayout.LayoutParams(dpi(56), -2));
            row.addView(button("🗑", v -> {
                if (running) { toast(L.t("Espera a que termine de dibujar.")); return; }
                SdChars.remove(this, ch.name); refreshChars();
            }), new LinearLayout.LayoutParams(dpi(56), -2));
            charsBox.addView(row, gapBelow(4));
        }
    }

    /** v1.7: si el archivo es un LoRA, el mensaje que explica para qué modelo es; si no, null. */
    String loraInfo(Uri u) {
        long size = -1;
        try (android.database.Cursor k = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.SIZE}, null, null, null)) {
            if (k != null && k.moveToFirst() && !k.isNull(0)) size = k.getLong(0);
        } catch (Exception ignored) {}
        String h;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            byte[] h8 = new byte[8];
            int g8 = 0, r;
            while (g8 < 8 && (r = in.read(h8, g8, 8 - g8)) > 0) g8 += r;
            if (g8 != 8) return null;
            long n = java.nio.ByteBuffer.wrap(h8).order(java.nio.ByteOrder.LITTLE_ENDIAN).getLong();
            if (n <= 1 || n > 100_000_000L) {                 // no es un .safetensors (o uno raro)
                return size > 50_000_000L ? L.t("Ese archivo es demasiado grande para ser un personaje (embedding): parece un modelo o un LoRA.") : null;
            }
            byte[] hb = new byte[(int) n];
            int got = 0, k;
            while (got < n && (k = in.read(hb, got, (int) n - got)) > 0) got += k;
            h = new String(hb, 0, got, java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) { return null; }
        String low = h.toLowerCase(java.util.Locale.ROOT);
        String mb = size > 0 ? " (" + (size >> 20) + " MB)" : "";
        // v1.7.2: qué es (por los nombres de dentro), no solo los LoRA de un formato
        boolean emb = low.contains("\"emb_params\"") || low.contains("\"clip_l\"") || low.contains("\"clip_g\"") || low.contains("string_to_param");
        boolean lora = low.contains("lora") || low.contains("lokr") || low.contains("hada_") || low.contains("lycoris") || low.contains("ss_network_module")
                || low.contains(".oft_") || low.contains("glora");
        boolean ckpt = low.contains("model.diffusion_model.") || low.contains("conditioner.embedders") || low.contains("first_stage_model.");
        if (emb && !lora && !ckpt) return null;                  // un personaje de verdad: adelante
        boolean xl = low.contains("lora_te2_") || low.contains("conditioner.embedders.1") || low.contains("\"sdxl") || low.contains("ss_base_model_version\":\"sdxl")
                || low.contains("pony") || low.contains("illustrious") || low.contains("noobai") || low.contains("\"ss_sd_model_name\":\"sd_xl")
                || h.contains("[2048,") || h.contains(", 2048]") || h.contains(",2048]") || low.contains("add_embedding") || low.contains("label_emb");
        boolean flux = low.contains("flux") || low.contains("double_blocks") || low.contains("single_transformer_blocks") || low.contains("single_blocks");
        String what = lora ? L.t("Esto es un LoRA") : ckpt ? L.t("Esto es un modelo completo") : L.t("Esto no es un personaje");
        String base;
        if (flux) base = L.t("Es para Flux: ese modelo es demasiado grande para el teléfono.");
        else if (xl) base = L.t("Es para SDXL (o Pony / Illustrious, que son de esa familia): esos modelos son demasiado grandes para dibujar en el teléfono.");
        else if (lora) base = L.t("Es para SD 1.5: ¡ese sí encaja con los modelos del Estudio! El importador de LoRA llegará en una próxima versión.");
        else if (ckpt) base = L.t("Es un modelo de SD 1.5 entero: para usarlo en el móvil hay que convertirlo antes al formato del teléfono.");
        else {
            // desconocido: enseña cómo se llaman sus primeras partes (para saber qué es)
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"([^\"]{3,90})\"\\s*:\\s*\\{\\s*\"dtype").matcher(h);
            StringBuilder ks = new StringBuilder();
            int c = 0;
            while (m.find() && c < 3) { ks.append("\n· ").append(m.group(1)); c++; }
            base = L.t("No reconozco qué tipo de archivo es. Sus primeras partes se llaman:") + ks;
        }
        return what + mb + ".\n\n" + base + "\n\n" + L.t("Aquí, en «Personajes», solo van los «embeddings» (archivos pequeños, de unos KB).");
    }

    void importChar(Uri u) {
        String fname = "personaje";
        try (android.database.Cursor k = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (k != null && k.moveToFirst()) fname = k.getString(0);
        } catch (Exception ignored) {}
        // v1.7: ¿es un LoRA? Se mira solo la cabecera del .safetensors (dice para qué modelo es)
        String lora = loraInfo(u);
        if (lora != null) {
            new android.app.AlertDialog.Builder(this).setTitle(L.t("No es un personaje")).setMessage(lora)
                    .setPositiveButton(L.t("Entendido"), null).show();
            return;
        }
        byte[] b;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[65536]; int n; long tot = 0;
            while ((n = in.read(buf)) > 0) { o.write(buf, 0, n); tot += n; if (tot > 50_000_000L) { toast(L.t("Ese archivo es demasiado grande: parece un modelo o un LoRA, no un personaje.")); return; } }
            b = o.toByteArray();
        } catch (Exception e) { toast(L.t("No puedo abrir ese archivo.")); return; }
        EditText name = new EditText(this);
        name.setText(fname.replaceAll("\\.(safetensors|pt|bin)$", "").replace('_', ' ').replace('-', ' '));
        name.setSelectAllOnFocus(true);
        final byte[] data = b;
        final String fn = fname;
        new android.app.AlertDialog.Builder(this)
                .setTitle(L.t("Nombre del personaje"))
                .setMessage(L.t("Es la palabra que escribirás en la descripción para dibujarlo."))
                .setView(name)
                .setPositiveButton(L.t("Guardar"), (d, w) -> {
                    String err = SdChars.add(this, name.getText().toString(), data, fn);
                    if (err != null) toast(err); else { toast(L.t("Personaje guardado. Escribe su nombre en la descripción.")); refreshChars(); }
                })
                .setNegativeButton(L.t("Cancelar"), null)
                .show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CHAR) { if (res == RESULT_OK && data != null && data.getData() != null) importChar(data.getData()); return; }
        if (req == REQ_HIST) {                       // v1.7.4: «repetir» desde el historial
            if (res == RESULT_OK && data != null && data.getStringExtra(DrawHistoryActivity.EXTRA_REUSE) != null) {
                prompt.setText(data.getStringExtra(DrawHistoryActivity.EXTRA_REUSE));
                long sd = data.getLongExtra(DrawHistoryActivity.EXTRA_REUSE_SEED, -1);
                seedIn.setText(sd >= 0 ? String.valueOf(sd) : "");
                toast(L.t("Descripción y semilla puestas: pulsa DIBUJAR (o borra la semilla para variar)."));
            }
            return;
        }
        if (req != REQ_INIT || res != RESULT_OK || data == null || data.getData() == null) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap b = BitmapFactory.decodeStream(in, null, o);
            if (b == null) { toast(L.t("No puedo abrir esa imagen.")); return; }
            float sc = Math.min(1f, 1024f / Math.max(b.getWidth(), b.getHeight()));
            if (sc < 1f) b = Bitmap.createScaledBitmap(b, Math.round(b.getWidth() * sc), Math.round(b.getHeight() * sc), true);
            init = b;
            initView.setImageBitmap(b);
            initView.setVisibility(android.view.View.VISIBLE);
        } catch (Exception e) {
            toast(L.t("No puedo abrir esa imagen."));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacks(tick);            // v1.7.3: el dibujo sigue en segundo plano
    }
}
