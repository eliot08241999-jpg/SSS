package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * v1.8 · Lectura de libros en segundo plano (con la pantalla apagada o en otra app), con notificación multimedia:
 * ⏮ ⏯ ⏭ y ⏹. Al parar con ⏹ pone una marca automática para seguir desde ahí la próxima vez.
 */
public class ReadAloudService extends Service {
    static final String CH = "read_aloud";
    static final int NID = 71;

    // estado compartido con el lector
    static volatile List<String> paras = new ArrayList<>();
    static volatile String title = "", key = "";
    static volatile Uri uri;
    static volatile int idx = -1;
    static volatile boolean running, playing;
    static volatile float rate = 1f;

    TextToSpeech tts;
    boolean ready;
    MediaSession session;

    /** Empieza (o cambia de libro). Los párrafos se pasan por memoria: un libro no cabe en un Intent. */
    static void start(Context c, Uri u, String k, String t, List<String> p, int from, float r) {
        paras = new ArrayList<>(p);
        uri = u; key = k; title = t; idx = Math.max(0, from); rate = r;
        Intent i = new Intent(c, ReadAloudService.class).setAction("play");
        if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void send(Context c, String action) { c.startService(new Intent(c, ReadAloudService.class).setAction(action)); }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH, L.t("Lectura en voz alta"), NotificationManager.IMPORTANCE_LOW));
        session = new MediaSession(this, "chloe-lector");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { jump(1); }
            @Override public void onSkipToPrevious() { jump(-1); }
            @Override public void onStop() { stopAndMark(); }
        });
        session.setActive(true);
        tts = new TextToSpeech(this, st -> {
            ready = st == TextToSpeech.SUCCESS;
            if (!ready) return;
            int r = tts.setLanguage(Locale.getDefault());
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(new Locale("es", "ES"));
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                public void onStart(String id) {}
                public void onDone(String id) { if (playing && ("p" + idx).equals(id)) { idx++; speak(); } }
                @Override public void onError(String id) { if (playing) { idx++; speak(); } }
            });
            if (playing) speak();
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? "play" : String.valueOf(intent.getAction());
        running = true;
        startForegroundNow();
        switch (a) {
            case "play": playing = true; if (ready) speak(); break;
            case "toggle": if (playing) pause(); else resume(); break;
            case "next": jump(1); break;
            case "prev": jump(-1); break;
            case "stop": stopAndMark(); break;
            case "quiet": playing = false; if (tts != null) tts.stop(); finishService(); break;   // parar sin marca (desde el lector)
        }
        return START_NOT_STICKY;
    }

    void startForegroundNow() {
        Notification n = build();
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(NID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NID, n);
    }

    void speak() {
        if (!ready || tts == null) return;
        if (idx >= paras.size()) { playing = false; mark(L.t("Fin del libro"), true); finishService(); return; }
        tts.setSpeechRate(rate);
        tts.speak(paras.get(idx), TextToSpeech.QUEUE_FLUSH, null, "p" + idx);
        savePos();
        update();
    }

    void pause() { playing = false; if (tts != null) tts.stop(); savePos(); update(); }

    void resume() { playing = true; speak(); }

    void jump(int d) {
        idx = Math.max(0, Math.min(paras.size() - 1, idx + d));
        if (playing) speak(); else { savePos(); update(); }
    }

    /** ⏹: para y pone una marca borrable para seguir desde aquí. */
    void stopAndMark() {
        playing = false;
        if (tts != null) tts.stop();
        mark("⏹ " + L.t("Donde paraste"), true);
        finishService();
    }

    void finishService() {
        savePos();
        running = false;
        stopForeground(true);
        stopSelf();
    }

    void savePos() {
        if (key.isEmpty() || idx < 0) return;
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        int total = Math.max(1, paras.size());
        p.edit().putInt("rpos_" + key, Math.min(idx, total - 1)).putInt("rpct_" + key, Math.round(100f * (Math.min(idx, total - 1) + 1) / total)).apply();
    }

    /** Marcadores: «bm_<libro>» = [{n: nombre, i: párrafo, a: automático}]. La marca automática se sustituye. */
    void mark(String name, boolean auto) { addBookmark(this, key, name, Math.max(0, Math.min(idx, paras.size() - 1)), auto); }

    static void addBookmark(Context c, String key, String name, int para, boolean auto) {
        try {
            SharedPreferences p = c.getSharedPreferences("cfg", MODE_PRIVATE);
            JSONArray a = new JSONArray(p.getString("bm_" + key, "[]")), out = new JSONArray();
            for (int i = 0; i < a.length(); i++) if (!(auto && a.getJSONObject(i).optBoolean("a"))) out.put(a.getJSONObject(i));
            JSONObject o = new JSONObject();
            o.put("n", name); o.put("i", para); o.put("a", auto); o.put("t", System.currentTimeMillis());
            out.put(o);
            p.edit().putString("bm_" + key, out.toString()).apply();
        } catch (Exception ignored) {}
    }

    void update() {
        getSystemService(NotificationManager.class).notify(NID, build());
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP | PlaybackState.ACTION_PLAY_PAUSE)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, Math.max(0, idx), 1f).build());
        session.setMetadata(new android.media.MediaMetadata.Builder()
                .putString(android.media.MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, progress()).build());
    }

    String progress() {
        int n = Math.max(1, paras.size());
        return L.t("Párrafo") + " " + (Math.min(idx, n - 1) + 1) + " / " + n + " · " + Math.round(100f * (Math.min(idx, n - 1) + 1) / n) + " %";
    }

    PendingIntent act(String a, int rc) {
        return PendingIntent.getService(this, rc, new Intent(this, ReadAloudService.class).setAction(a), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    Notification build() {
        Intent open = new Intent(this, DocReaderActivity.class).setData(uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title.isEmpty() ? L.t("Leyendo") : title)
                .setContentText(progress())
                .setContentIntent(content)
                .setOngoing(playing)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous, L.t("Anterior"), act("prev", 2)).build())
                .addAction(new Notification.Action.Builder(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, playing ? L.t("Pausa") : L.t("Seguir"), act("toggle", 3)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next, L.t("Siguiente"), act("next", 4)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, L.t("Parar y marcar"), act("stop", 5)).build())
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
        return b.build();
    }

    @Override
    public void onDestroy() {
        running = false;
        playing = false;
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (session != null) session.release();
        super.onDestroy();
    }
}
