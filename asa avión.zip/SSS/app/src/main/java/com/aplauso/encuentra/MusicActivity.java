package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** v1.8 · 🎵 MÚSICA: metrónomo, afinador, acordes, cancionero, armónica y tus instrumentos. */
public class MusicActivity extends NeonActivity {
    TextView instrBtn, harpBtn, notBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("🎵 MÚSICA");
        card(col, "📒 CANCIONERO", "Tus canciones con letra y acordes encima. Toca un acorde para ver cómo se pone, transporta, simplifica y pasa solo la pantalla.", SongbookActivity.class);
        card(col, "🎸 BIBLIOTECA DE ACORDES", "Todos los acordes en tu instrumento, con dedos, sonido y varias posiciones. También al revés: pon los dedos y te dice qué acorde es.", ChordsActivity.class);
        card(col, "🎯 AFINADOR", "Preciso (±0,1 cent): guitarra, bajo, ukelele, violín… o cromático. Aguja, modo estroboscópico y tono de referencia.", TunerActivity.class);
        card(col, "🥁 METRÓNOMO", "De 20 a 300 BPM, compases, acentos, subdivisiones, tap tempo, entrenador de velocidad y silencios de prueba.", MetronomeActivity.class);
        card(col, "🎼 ARMÓNICA: DE NOTAS A TABS", "Escribe la melodía (Do Re Mi o C D E) y te dice qué agujero soplar o aspirar, buscando el tono con menos bends.", HarmonicaActivity.class);

        LinearLayout mine = panel("◢ MIS INSTRUMENTOS Y NOTACIÓN");
        notBtn = button("", v -> pickNotation());
        mine.addView(notBtn, gapBelow(6));
        instrBtn = button("", v -> pickInstrument());
        mine.addView(instrBtn, gapBelow(6));
        harpBtn = button("", v -> pickHarp());
        mine.addView(harpBtn, gapBelow(6));
        TextView t = text("La biblioteca de acordes y el cancionero usan tu instrumento de acordes; las tabs de armónica, tu armónica. "
                + "Puedes cambiarlos cuando quieras desde cada pantalla.", 11);
        t.setTextColor(Color.rgb(160, 170, 190));
        mine.addView(t);
        col.addView(mine, gapBelow(14));
        refresh();
    }

    void refresh() {
        String n = MusicTheory.notation(this);
        notBtn.setText(L.t("Notación") + ": " + (MusicTheory.SOL.equals(n) ? "Do-Re-Mi" : MusicTheory.DE.equals(n) ? "C-D-E-F-G-A-H (alemana)" : "C-D-E-F-G-A-B")
                + (MusicTheory.flats(this) ? " · ♭" : " · ♯"));
        instrBtn.setText("🎸 " + L.t(MusicTheory.byId(this, p.getString("mus_chord_instr", "gtr6")).name));
        harpBtn.setText("🎼 " + L.t(MusicTheory.harp(this, p.getString("mus_harp", "harp_c")).name));
    }

    void pickNotation() {
        String[] o = {"C-D-E-F-G-A-B · ♯", "C-D-E-F-G-A-B · ♭", "Do-Re-Mi · ♯", "Do-Re-Mi · ♭", "Alemana (H) · ♯", "Alemana (H) · ♭"};
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Notación")).setItems(o, (d, w) -> {
            p.edit().putString("mus_notation", w < 2 ? MusicTheory.EN : w < 4 ? MusicTheory.SOL : MusicTheory.DE).putBoolean("mus_flats", w % 2 == 1).apply();
            refresh();
        }).show();
    }

    void pickInstrument() {
        List<MusicTheory.Instrument> l = MusicTheory.all(this);
        java.util.List<String> names = new java.util.ArrayList<>();
        java.util.List<String> ids = new java.util.ArrayList<>();
        for (MusicTheory.Instrument i : l) if (i.fretted) { names.add(L.t(i.name)); ids.add(i.id); }
        names.add(L.t("🎹 Piano"));
        ids.add("piano");
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Instrumento de acordes")).setItems(names.toArray(new String[0]), (d, w) -> {
            p.edit().putString("mus_chord_instr", ids.get(w)).apply();
            refresh();
        }).show();
    }

    void pickHarp() {
        List<String[]> h = MusicTheory.harps(this);
        String[] names = new String[h.size()];
        for (int i = 0; i < names.length; i++) names[i] = L.t(h.get(i)[1]);
        new android.app.AlertDialog.Builder(this).setTitle(L.t("Tu armónica")).setItems(names, (d, w) -> {
            p.edit().putString("mus_harp", h.get(w)[0]).apply();
            refresh();
        }).show();
    }

    void card(LinearLayout col, String title, String desc, Class<?> target) {
        LinearLayout c = panel(null);
        c.addView(neonText(title, 18));
        TextView d = text(desc, 13);
        d.setTextColor(Color.rgb(170, 180, 200));
        d.setPadding(0, dpi(4), 0, 0);
        c.addView(d);
        c.setClickable(true);
        c.setOnClickListener(v -> startActivity(new Intent(this, target)));
        col.addView(c, gapBelow(12));
    }

    @Override protected void onResume() { super.onResume(); if (notBtn != null) refresh(); }
}
