package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Lector de documentos: texto con tamaño ajustable, páginas originales del PDF y lectura en voz alta. */
public class DocReaderActivity extends NeonActivity {
    Uri uri;
    String key;
    DocIO.Doc doc;
    DocPdf.Pages pages;
    boolean pageMode;
    ListView list;
    TextView status, titleView, speakBtn, rateBtn, modeBtn;
    final Adapter adapter = new Adapter();
    TextToSpeech tts;
    boolean ttsReady, speaking;
    int speakIdx = -1, fontSize;
    float rate = 1f;
    final ExecutorService ex = Executors.newSingleThreadExecutor();
    final LruCache<Integer, Bitmap> cache = new LruCache<Integer, Bitmap>(40 * 1024 * 1024) {
        @Override protected int sizeOf(Integer k, Bitmap b) { return b.getByteCount(); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        uri = getIntent().getData();
        key = uri == null ? "x" : Integer.toHexString(uri.toString().hashCode());
        fontSize = p.getInt("reader_size", 18);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(10), dpi(14), dpi(10), dpi(6));
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(circleButton("←", v -> finish()), new LinearLayout.LayoutParams(dpi(42), dpi(42)));
        titleView = neonText("  Cargando…", 15);
        titleView.setSingleLine(true);
        top.addView(titleView, new LinearLayout.LayoutParams(0, -2, 1));
        col.addView(top, gapBelow(8));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = new LinearLayout(this);
        speakBtn = tool(tools, "🔊 LEER EN VOZ", v -> toggleSpeak());
        rateBtn = tool(tools, "VEL 1x", v -> cycleRate());
        tool(tools, "🔖 MARCADORES", v -> bookmarks());
        tool(tools, "A−", v -> setFont(fontSize - 2));
        tool(tools, "A+", v -> setFont(fontSize + 2));
        modeBtn = tool(tools, "📄 PÁGINAS", v -> toggleMode());
        modeBtn.setVisibility(View.GONE);
        tool(tools, "✏ EDITAR", v -> startActivity(new Intent(this, DocEditActivity.class).setData(uri)));
        tool(tools, "📚 A BIBLIOTECA", v -> {
            LibraryActivity.add(this, uri, Media.nameOf(this, uri));
            toast("Añadido a tu biblioteca ✓");
        });
        hs.addView(tools);
        col.addView(hs, gapBelow(8));

        list = new ListView(this);
        list.setDividerHeight(0);
        list.setAdapter(adapter);
        list.setBackground(frame(12));
        list.setPadding(dpi(6), dpi(6), dpi(6), dpi(6));
        list.setOnItemClickListener((parent, view, pos, id) -> { if (speaking && !pageMode) speak(pos); });
        col.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        status = text("", 12);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dpi(6), 0, 0);
        col.addView(status);
        setContentView(makeRoot(col));

        ttsReady = true;                 // v1.8: lee el servicio en segundo plano (ReadAloudService)
        rate = p.getFloat("reader_rate", 1f);

        if (uri == null) { titleView.setText(L.t("  Sin documento")); return; }
        ex.execute(() -> {
            try {
                DocIO.Doc d = DocPdf.load(this, uri);
                DocPdf.Pages pg = null;
                if ("pdf".equals(d.type)) { try { pg = new DocPdf.Pages(this, uri); } catch (Exception ignored) {} }
                DocPdf.Pages fpg = pg;
                runOnUiThread(() -> loaded(d, fpg));
            } catch (Throwable t) {
                runOnUiThread(() -> {
                    titleView.setText(L.t("  No se pudo abrir"));
                    status.setText(L.t("Error: " + t.getMessage()));
                });
            }
        });
    }

    TextView tool(LinearLayout parent, String label, View.OnClickListener l) {
        TextView t = button(label, l);
        t.setPadding(dpi(12), dpi(8), dpi(12), dpi(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dpi(6);
        parent.addView(t, lp);
        return t;
    }

    void loaded(DocIO.Doc d, DocPdf.Pages pg) {
        doc = d;
        pages = pg;
        titleView.setText("  " + (d.title.isEmpty() ? Media.nameOf(this, uri) : d.title));
        if (pages != null) {
            modeBtn.setVisibility(View.VISIBLE);
            pageMode = p.getBoolean("rmode_" + key, true);
            modeBtn.setText(L.t(pageMode ? "📝 TEXTO" : "📄 PÁGINAS"));
        }
        adapter.notifyDataSetChanged();
        int pos = pageMode ? p.getInt("rpage_" + key, 0) : p.getInt("rpos_" + key, 0);
        if (pos > 0 && pos < adapter.getCount()) list.setSelection(pos);
        if (doc.paras.isEmpty() && pages == null) status.setText(L.t("El documento no tiene texto que mostrar."));
        for (Object[] bm : bms()) if ((boolean) bm[2]) { toast(L.t("Sigues donde paraste") + " 🔖"); break; }
        rateBtn.setText(L.t("VEL " + (rate == (int) rate ? String.valueOf((int) rate) : String.valueOf(rate)) + "x"));
        if (mine()) { speakIdx = ReadAloudService.idx; speaking = ReadAloudService.playing; speakBtn.setText(L.t(speaking ? "⏸ PAUSA" : "▶ SEGUIR")); if (!pageMode && speakIdx >= 0) list.setSelection(speakIdx); }
    }

    void setFont(int s) {
        fontSize = Math.max(12, Math.min(40, s));
        p.edit().putInt("reader_size", fontSize).apply();
        adapter.notifyDataSetChanged();
    }

    void toggleMode() {
        if (pages == null) return;
        int first = list.getFirstVisiblePosition();
        float frac = adapter.getCount() == 0 ? 0 : first / (float) adapter.getCount();
        pageMode = !pageMode;
        p.edit().putBoolean("rmode_" + key, pageMode).apply();
        modeBtn.setText(L.t(pageMode ? "📝 TEXTO" : "📄 PÁGINAS"));
        adapter.notifyDataSetChanged();
        list.setSelection(Math.round(frac * adapter.getCount()));
    }

    void cycleRate() {
        float[] rates = {0.75f, 1f, 1.25f, 1.5f, 2f};
        int i = 0;
        while (i < rates.length && rates[i] <= rate + 0.01f) i++;
        rate = rates[i % rates.length];
        p.edit().putFloat("reader_rate", rate).apply();
        rateBtn.setText(L.t("VEL " + (rate == (int) rate ? String.valueOf((int) rate) : String.valueOf(rate)) + "x"));
        ReadAloudService.rate = rate;
        if (mine() && ReadAloudService.playing) ReadAloudService.send(this, "play");
    }

    /** ¿El servicio está leyendo ESTE libro? */
    boolean mine() { return ReadAloudService.running && key.equals(ReadAloudService.key); }

    void toggleSpeak() {
        if (doc == null) return;
        if (mine()) { ReadAloudService.send(this, "toggle"); return; }
        int start = list.getFirstVisiblePosition();
        if (pageMode && pages != null && pages.count() > 0)
            start = Math.round(start / (float) pages.count() * doc.paras.size());
        speak(start);
    }

    void speak(int i) {
        if (doc == null || i < 0) return;
        if (i >= doc.paras.size()) {
            speaking = false;
            speakIdx = -1;
            speakBtn.setText(L.t("🔊 LEER EN VOZ"));
            adapter.notifyDataSetChanged();
            return;
        }
        speakIdx = i;
        speaking = true;
        // v1.8: sigue leyendo en segundo plano, con controles en la notificación
        ReadAloudService.start(this, uri, key, titleView.getText().toString().trim(), doc.paras, i, rate);
        if (!pageMode) {
            adapter.notifyDataSetChanged();
            if (i < list.getFirstVisiblePosition() || i > list.getLastVisiblePosition()) list.setSelection(i);
        }
    }

    @Override
    protected void onTick() {
        if (doc == null || adapter.getCount() == 0) return;
        boolean was = speaking;
        speaking = mine() && ReadAloudService.playing;
        if (mine() && ReadAloudService.idx != speakIdx) {
            speakIdx = ReadAloudService.idx;
            if (!pageMode) { adapter.notifyDataSetChanged(); if (speakIdx < list.getFirstVisiblePosition() || speakIdx > list.getLastVisiblePosition()) list.setSelection(speakIdx); }
        }
        if (was != speaking) speakBtn.setText(L.t(speaking ? "⏸ PAUSA" : mine() ? "▶ SEGUIR" : "🔊 LEER EN VOZ"));
        int first = list.getFirstVisiblePosition();
        int pct = Math.round(100f * (first + 1) / adapter.getCount());
        status.setText(L.t((pageMode ? "Página " + (first + 1) + " de " + adapter.getCount() : "Párrafo " + (first + 1) + " de " + adapter.getCount())
                + " · " + pct + " %" + (speaking ? " · 🔊 leyendo" : "")));
    }

    // ------------------------------------------------------------------ v1.8: marcadores
    /** {nombre, párrafo, automático} */
    List<Object[]> bms() {
        List<Object[]> l = new java.util.ArrayList<>();
        try {
            org.json.JSONArray a = new org.json.JSONArray(p.getString("bm_" + key, "[]"));
            for (int i = 0; i < a.length(); i++) { org.json.JSONObject o = a.getJSONObject(i); l.add(new Object[]{o.optString("n"), o.optInt("i"), o.optBoolean("a")}); }
        } catch (Exception ignored) {}
        return l;
    }

    int currentPara() {
        if (mine()) return Math.max(0, ReadAloudService.idx);
        int first = list.getFirstVisiblePosition();
        if (pageMode && pages != null && pages.count() > 0) return Math.round(first / (float) pages.count() * doc.paras.size());
        return first;
    }

    void bookmarks() {
        if (doc == null) return;
        List<Object[]> l = bms();
        String[] items = new String[l.size() + 1];
        items[0] = L.t("＋ Marcar aquí…");
        for (int i = 0; i < l.size(); i++) {
            int para = (int) l.get(i)[1];
            items[i + 1] = l.get(i)[0] + "  ·  " + Math.round(100f * (para + 1) / Math.max(1, doc.paras.size())) + " %"
                    + (para < doc.paras.size() ? "\n«" + cut(doc.paras.get(para), 50) + "»" : "");
        }
        new android.app.AlertDialog.Builder(this).setTitle(L.t("🔖 Marcadores")).setItems(items, (d, w) -> {
            if (w == 0) {
                android.widget.EditText e = new android.widget.EditText(this);
                e.setHint(L.t("Nombre (p. ej. Capítulo 3)"));
                int at = currentPara();
                e.setText(cut(doc.paras.get(Math.min(at, doc.paras.size() - 1)), 30));
                new android.app.AlertDialog.Builder(this).setTitle(L.t("🔖 Marcar aquí")).setView(e).setPositiveButton("OK", (d2, w2) -> {
                    ReadAloudService.addBookmark(this, key, e.getText().toString().trim().isEmpty() ? L.t("Marcador") : e.getText().toString().trim(), at, false);
                    toast(L.t("Marcado ✓"));
                }).setNegativeButton(L.t("Cancelar"), null).show();
                return;
            }
            Object[] bm = l.get(w - 1);
            new android.app.AlertDialog.Builder(this).setTitle((String) bm[0]).setItems(new String[]{L.t("➜ Ir aquí"), L.t("🔊 Leer desde aquí"), L.t("🗑 Borrar")}, (d2, w2) -> {
                int para = (int) bm[1];
                if (w2 == 0) goPara(para);
                else if (w2 == 1) { goPara(para); speak(para); }
                else deleteBookmark(w - 1);
            }).show();
        }).show();
    }

    static String cut(String s, int n) { s = s.replaceAll("\\s+", " ").trim(); return s.length() <= n ? s : s.substring(0, n) + "…"; }

    void goPara(int para) {
        if (pageMode && pages != null && doc.paras.size() > 0) list.setSelection(Math.round(para / (float) doc.paras.size() * pages.count()));
        else list.setSelection(para);
        if (mine()) { ReadAloudService.idx = para; if (ReadAloudService.playing) ReadAloudService.send(this, "play"); }
    }

    void deleteBookmark(int i) {
        try {
            org.json.JSONArray a = new org.json.JSONArray(p.getString("bm_" + key, "[]")), out = new org.json.JSONArray();
            for (int k = 0; k < a.length(); k++) if (k != i) out.put(a.get(k));
            p.edit().putString("bm_" + key, out.toString()).apply();
            toast(L.t("Borrado."));
        } catch (Exception ignored) {}
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (doc == null || mine()) return;           // si está leyendo, la posición la guarda el servicio
        int first = list.getFirstVisiblePosition();
        int total = adapter.getCount();
        p.edit().putInt(pageMode ? "rpage_" + key : "rpos_" + key, first)
                .putInt("rpct_" + key, total == 0 ? 0 : Math.round(100f * (first + 1) / total)).apply();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ex.shutdownNow();                                // la lectura sigue en segundo plano (notificación)
        if (pages != null) pages.close();
    }

    class Adapter extends BaseAdapter {
        @Override public int getCount() {
            if (doc == null) return 0;
            return pageMode && pages != null ? pages.count() : doc.paras.size();
        }
        @Override public Object getItem(int i) { return i; }
        @Override public long getItemId(int i) { return i; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int i) { return pageMode && pages != null ? 1 : 0; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            if (pageMode && pages != null) {
                ImageView iv = convert instanceof ImageView ? (ImageView) convert : new ImageView(DocReaderActivity.this);
                iv.setAdjustViewBounds(true);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iv.setPadding(0, 0, 0, dpi(6));
                iv.setTag(pos);
                int w = Math.max(400, list.getWidth() - dpi(12));
                Bitmap bm = cache.get(pos);
                if (bm != null) iv.setImageBitmap(bm);
                else {
                    iv.setImageBitmap(null);
                    iv.setMinimumHeight(Math.round(w * 1.41f));
                    ex.execute(() -> {
                        Bitmap r = pages.render(pos, w);
                        if (r == null) return;
                        cache.put(pos, r);
                        runOnUiThread(() -> { if (Integer.valueOf(pos).equals(iv.getTag())) { iv.setMinimumHeight(0); iv.setImageBitmap(r); } });
                    });
                }
                return iv;
            }
            TextView t = convert instanceof TextView ? (TextView) convert : new TextView(DocReaderActivity.this);
            t.setText(doc.paras.get(pos));
            t.setTextSize(fontSize);
            t.setTextColor(Color.rgb(230, 232, 240));
            t.setLineSpacing(0, 1.25f);
            t.setPadding(dpi(10), dpi(6), dpi(10), dpi(10));
            t.setBackgroundColor(pos == speakIdx ? Color.argb(70, 0, 229, 255) : Color.TRANSPARENT);
            return t;
        }
    }
}
