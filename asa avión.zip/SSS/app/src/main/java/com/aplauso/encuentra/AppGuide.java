package com.aplauso.encuentra;

import android.content.Context;
import android.content.Intent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v1.8 · Chloe conoce SU app: qué funciones tiene, dónde está cada una y cómo se usa.
 * Responde sin el cerebro (no se inventa «Contactos» ni «iCloud») y puede abrir la pantalla o ponerse a dibujar.
 */
public final class AppGuide {
    private AppGuide() {}

    /** {nombre, palabras clave (regex sobre texto normalizado), dónde está, cómo se usa, clase} */
    static final Object[][] F = {
            {"Chat con Chloe", "chat|hablar contigo|conversacion(?:es)?", "Es esta pantalla; con ☰ ves y buscas las conversaciones guardadas.",
                    "Escríbeme o pulsa 🎤. En ☰ tienes tus conversaciones: fíjalas, renómbralas o empieza una nueva.", ChloeChatActivity.class},
            {"Modo conversación (Live)", "modo live|live|modo conversacion|llamada|manos libres", "Di «hablemos» o pulsa ✦ HABLAR CON CHLOE en el menú.",
                    "Hablamos sin tocar nada, como una llamada. Si hablas mientras yo hablo, me callo y te escucho.", LiveActivity.class},
            {"Estudio de dibujo", "estudio|dibuj\\w*|imagen(?:es)?|crear imagen|generar imagen|ia de imagenes|stable diffusion|pintar con ia", "Menú → 🎨 ESTUDIO DE DIBUJO.",
                    "Describe la imagen, elige estilo y tamaño, y pulsa DIBUJAR. Dibuja en segundo plano, con cola e historial de 24 h. O dime «dibuja un gato astronauta» y lo hago yo.", DrawStudioActivity.class},
            {"Historial de dibujos", "historial de dibujos|historial de imagenes|mis dibujos", "Estudio → 🕘 HISTORIAL.",
                    "Lo que dibujas se guarda 24 h: guárdalo en la galería, fíjalo o repítelo.", DrawHistoryActivity.class},
            {"Ampliar imágenes", "ampliar (?:imagen|imagenes|foto|fotos)|agrandar|mejorar (?:calidad|resolucion)|upscale", "Menú → 🔍 AMPLIAR IMÁGENES.",
                    "Elige una imagen, el tamaño y la manera, y pulsa AMPLIAR. Luego GUARDAR.", UpscaleActivity.class},
            {"Ampliar vídeos", "ampliar (?:video|videos)|video (?:a|en) 4k|mejorar (?:un )?video", "Menú → 🎬 AMPLIAR VÍDEOS.",
                    "Elige el vídeo y el tamaño; la prueba exprés te dice cuánto tardará. Va en segundo plano y te aviso al terminar.", VideoUpscaleActivity.class},
            {"Editores (fotos, vídeos y sonido)", "editor(?:es)?|editar (?:foto|fotos|video|videos|audio|sonido)|galeria|recortar", "Menú → ✂ EDITORES.",
                    "Tu galería con pestañas Fotos, Vídeos y Audios: toca algo para editarlo (recortar, filtros, volumen, quitar sonido…).", GalleryActivity.class},
            {"Fotogramas y GIF", "fotogramas?|gif|separar (?:un )?video|sacar fotos de un video|boomerang", "Adicionales → 🎞 FOTOGRAMAS Y GIF.",
                    "Elige un vídeo y el trozo; saca fotos (todas, X por segundo o un total) o crea un GIF con velocidad, bucle y texto.", FramesGifActivity.class},
            {"Música", "seccion (?:de )?musica|musica de (?:la app|chloe)|metronomo|afinador|afinar|acordes?|cancionero|canciones|armonica|tabs?|partitura", "Adicionales → 🎵 MÚSICA.",
                    "Metrónomo, afinador preciso, biblioteca de acordes, cancionero con transporte y armónica de notas a tabs.", MusicActivity.class},
            {"Metrónomo", "metronomo|tempo|bpm", "Adicionales → 🎵 MÚSICA → 🥁 METRÓNOMO.", "Pon los BPM o pulsa TAP al ritmo, elige compás y pulsa EMPEZAR.", MetronomeActivity.class},
            {"Afinador", "afinador|afinar", "Adicionales → 🎵 MÚSICA → 🎯 AFINADOR.", "Elige instrumento y toca una cuerda: verde es afinada.", TunerActivity.class},
            {"Documentos", "documentos?|pdf|epub|docx|leer (?:un )?libro|convertir documento", "Adicionales → 📄 DOCUMENTOS.",
                    "Lee, edita, convierte y traduce PDF, EPUB, DOCX y TXT, y te los leo en voz alta.", DocsActivity.class},
            {"Biblioteca", "biblioteca|mis libros", "Adicionales → 📚 BIBLIOTECA.", "Tus libros con la página donde te quedaste y lectura en voz alta.", LibraryActivity.class},
            {"Traducir documentos", "traducir (?:un )?documento|traductor", "Adicionales → 📄 DOCUMENTOS → traducir.",
                    "Traduce un documento entre español, italiano e inglés sin cambiar su estructura.", TranslateActivity.class},
            {"Gestor de archivos", "archivos|gestor de archivos|zip|rar|descomprimir|comprimir", "Adicionales → 🗂 GESTOR DE ARCHIVOS.",
                    "Explora el teléfono: copia, mueve, renombra, borra y comprime o descomprime ZIP y RAR.", FilesActivity.class},
            {"Grabar pantalla", "grabar (?:la )?pantalla|grabador", "Adicionales → ⏺ GRABAR PANTALLA, o dime «graba la pantalla».",
                    "Graba con el sonido interno, el micrófono o los dos.", ScreenRecActivity.class},
            {"Buscar el móvil aplaudiendo", "aplaud\\w*|buscar (?:el )?(?:movil|telefono)|encontrar (?:el )?(?:movil|telefono)", "Adicionales → 👏 BUSCAR EL MÓVIL AL APLAUDIR.",
                    "Aplaude de 2 a 8 veces y el móvil suena aunque esté en silencio.", null},
            {"Editor 3D", "3d|vrm|stl|modelo 3d|editor 3d", "Adicionales → 🧊 EDITOR 3D.",
                    "Abre STL, OBJ, FBX, GLB y VRM; huesos, pesos, texturas y exportar.", Model3DActivity.class},
            {"Juegos", "juegos?|jugar", "Menú → 🎮 JUEGOS.", "Minijuegos, entre ellos El Pastor de Ecos.", GamesActivity.class},
            {"Información del teléfono", "info|bateria|temperatura|ram|almacenamiento", "Menú → ℹ INFO.", "Batería, temperatura, CPU, RAM y almacenamiento en vivo.", InfoActivity.class},
            {"Limpieza", "limpieza|limpiar|liberar espacio", "Menú → 🧹 LIMPIEZA.", "Limpia lo de la app y te ayuda a borrar archivos grandes.", CleanActivity.class},
            {"Mi voz", "tu voz|cambiar (?:la|tu) voz|voz de chloe", "Asistente → voz.", "Descarga mi voz propia y ajústala: tono, velocidad, expresión…", VoiceLabActivity.class},
            {"Ajustes del asistente", "asistente|cerebro|personalidad|memoria|ajustes de chloe|roleplay", "Menú → 🐑 ASISTENTE CHLOE.",
                    "Mi cerebro (normal o grande), mi personalidad, tu nombre, cómo te trato, el tiempo y la memoria.", AssistActivity.class},
            {"Mis chistes", "chistes", "Asistente → 😂 MIS CHISTES.", "Añade tus chistes y los cuento mezclados con los míos.", JokesActivity.class},
            {"Novedades", "novedades|version|que hay de nuevo|changelog", "Menú → N.", "Qué trae cada versión.", NewsActivity.class},
            {"Ajustes", "ajustes|configuracion|idioma|tema|color", "Menú → ⚙.", "Idioma, colores, fondo y más.", SettingsActivity.class},
    };

    /** Resumen corto para el cerebro (que no se invente funciones). */
    static String forPrompt() {
        return " La app Chloe Nova tiene: chat y modo conversación contigo, Estudio de dibujo con IA (y su historial), ampliar imágenes y vídeos, "
                + "editores de fotos, vídeo y sonido, Música (metrónomo, afinador, acordes, cancionero, armónica), documentos y biblioteca con lectura en voz alta, "
                + "traducir documentos, gestor de archivos, grabar pantalla, buscar el móvil aplaudiendo, editor 3D, juegos, info del teléfono y limpieza. "
                + "NO tiene contactos, SMS, correo ni iCloud: no inventes funciones.";
    }

    static boolean asksFeatures(String n) {
        return n.matches(".*\\b(?:que (?:funciones|cosas|opciones) (?:tiene|tienes|hay)|que (?:puedes|sabes) hacer|que se puede hacer|para que sirve (?:esta|la) app|"
                + "funciones de (?:la|esta) app|que tiene (?:la|esta) app|que hace (?:la|esta) app|ayuda con la app|como funciona (?:la|esta) app|"
                + "what can you do|cosa sai fare|che funzioni)\\b.*");
    }

    static final Pattern HOW = Pattern.compile("^(?:como (?:se )?(?:uso|usar|usa|hago|hacer|hace|creo|crear|crea|pongo|poner|abro|abrir|funciona|va|activo|activar|cambio|cambiar)|"
            + "donde (?:esta|estan|encuentro|veo|se ve)|para que sirve|que es|explicame|ensename|guiame (?:en|con|por)|ayudame con)\\s+(?:el |la |los |las |lo de |un |una )?(.+)$");

    /** Respuesta sobre la app (o null si no va de la app). */
    static String answer(Context c, String q) {
        String n = Actions.norm(Brain.stripVocative(c, q));
        if (asksFeatures(n)) {
            return L.t("Tengo un montón: chat y modo conversación, el Estudio para crear imágenes con IA, ampliar fotos y vídeos, editores de fotos, vídeo y sonido, "
                    + "la sección Música (metrónomo, afinador, acordes, cancionero y armónica), documentos con lectura en voz alta, traductor, gestor de archivos, "
                    + "grabar la pantalla, buscar el móvil aplaudiendo, editor 3D y juegos. Pregúntame «¿cómo uso…?» cualquiera y te guío.");
        }
        Matcher m = HOW.matcher(n);
        if (!m.find()) return null;
        String what = m.group(1);
        Object[] f = find(what);
        if (f == null) return null;
        return f[0] + ": " + L.t((String) f[3]) + " " + L.t("Está en") + " " + L.t((String) f[2]).replaceAll("\\.$", "") + ". " + L.t("¿Te la abro?");
    }

    static Object[] find(String text) {
        for (Object[] f : F) if (Pattern.compile("\\b(?:" + f[1] + ")\\b").matcher(text).find()) return f;
        return null;
    }

    // ------------------------------------------------------------------ órdenes: abrir y dibujar
    static volatile long pendingDrawUntil;
    static volatile Object[] lastOffered;
    static volatile long lastOfferedAt;

    static final Pattern DRAW = Pattern.compile("^(?:(?:puedes |me )?(?:dibuja|dibujame|dibujar|pinta|pintame|crea|creame|crear|genera|generame|generar|haz|hazme|hacer)"
            + "|quiero (?:crear|hacer|generar|dibujar)|quisiera (?:crear|hacer|dibujar))\\s+(?:una |un )?(?:imagen|dibujo|ilustracion|foto|retrato|fondo de pantalla|wallpaper)?"
            + "\\s*(?:de |con |que sea |sobre |:)?\\s*(.*)$");

    /** Órdenes de la app («abre el afinador», «dibuja un perro con sombrero»). null si no es una. */
    static Actions.Result order(Context c, String said) {
        String n = Actions.norm(Brain.stripVocative(c, said));
        long now = System.currentTimeMillis();
        // «sí» / «ábrela» después de «¿Te la abro?»
        if (lastOffered != null && now - lastOfferedAt < 90_000 && n.matches("^(?:si|sí|vale|ok|venga|claro|abrela|abrelo|abre|por favor|dale|si porfa|si por favor)\\b.*")) {
            Object[] f = lastOffered;
            lastOffered = null;
            return open(c, f);
        }
        // «un perro con un sombrero de paja» justo después de «quiero crear una imagen»
        if (now < pendingDrawUntil && !n.isEmpty() && !n.matches("^(?:no|nada|olvidalo|da igual|cancela)\\b.*") && !Brain.looksLikeOrder(said)) {
            pendingDrawUntil = 0;
            return draw(c, said.replaceAll("(?i)^\\s*(?:pues |vale,? |que sea |una? )", "").trim());
        }
        Matcher d = DRAW.matcher(n);
        if (d.matches() && n.matches(".*\\b(?:imagen|dibujo|dibuja|dibujame|dibujar|pinta|pintame|ilustracion|retrato|wallpaper|fondo de pantalla)\\b.*")) {
            String subj = d.group(1).trim();
            if (subj.length() < 3) {
                pendingDrawUntil = now + 120_000;
                return new Actions.Result(L.t("¡Me encanta! ¿Qué dibujo? Dímelo en una frase, por ejemplo «un perro con un sombrero de paja»."), null);
            }
            // el resto del texto original (con mayúsculas y tildes)
            String orig = Brain.stripVocative(c, said);
            int k = orig.toLowerCase(java.util.Locale.ROOT).indexOf(subj.split(" ")[0]);
            return draw(c, k >= 0 ? orig.substring(k) : subj);
        }
        // «abre el afinador», «llévame al estudio»
        Matcher o = Pattern.compile("^(?:abre|abreme|abrir|llevame (?:a|al)|ve (?:a|al)|vamos (?:a|al)|muestrame|ensename|entra en)\\s+(?:el |la |los |las |mi |mis )?(.+)$").matcher(n);
        if (o.matches()) {
            Object[] f = find(o.group(1));
            // palabras que también son del teléfono («abre ajustes», «abre la galería»): solo si dices que es de la app
            boolean generic = f != null && java.util.Arrays.asList("Ajustes", "Información del teléfono", "Juegos", "Editores (fotos, vídeos y sonido)",
                    "Gestor de archivos", "Chat con Chloe", "Limpieza").contains((String) f[0]);
            if (f != null && f[4] != null && (!generic || n.matches(".*\\b(?:app|chloe nova|de chloe|tuy[oa]s?)\\b.*"))) return open(c, f);
        }
        return null;
    }

    static Actions.Result open(Context c, Object[] f) {
        if (f[4] == null) return new Actions.Result(L.t((String) f[3]) + " " + L.t((String) f[2]), new Intent(c, MainActivity.class).putExtra(MainActivity.EXTRA_CLAP, true));
        return new Actions.Result(L.t("¡Voy!") + " " + L.t((String) f[0]) + ".", new Intent(c, (Class<?>) f[4]));
    }

    static Actions.Result draw(Context c, String subject) {
        String s = subject.replaceAll("[.!?¡¿]+$", "").trim();
        return new Actions.Result(L.t("¡A dibujar!") + " «" + s + "». " + L.t("Lo paso al inglés y empiezo; te aviso cuando esté."),
                new Intent(c, DrawStudioActivity.class).putExtra(DrawStudioActivity.EXTRA_CHLOE_PROMPT, s));
    }

    /** Recuerda qué función ofreció abrir (para el «sí» siguiente). */
    static void offered(String q) {
        Object[] f = null;
        Matcher m = HOW.matcher(Actions.norm(q));
        if (m.find()) f = find(m.group(1));
        lastOffered = f;
        lastOfferedAt = System.currentTimeMillis();
    }
}
