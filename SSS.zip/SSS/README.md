# SSS+  (v0.2)

Aplaudes 5 veces y el teléfono suena, aunque esté bloqueado o en silencio.

## Qué hace
- Escucha el micrófono con la pantalla bloqueada (queda una notificación fija "SSS+ activo").
- Nº de aplausos ajustable (2–8, por defecto 5) y sensibilidad (1–10).
- Sonido propio (oveja, lo que quieras) o el de alarma por defecto.
- Volumen ajustable; suena por el canal de alarma, así se oye aunque el móvil esté en silencio.
- Suena **una vez** (máximo 10 s). Se puede parar desde la notificación o abriendo la app.

## Novedades v0.2
- **ℹ Info**: batería (carga, temperatura, salud, ciclos, capacidad actual, corriente, voltaje, tiempo hasta carga), estado térmico y temperatura de CPU (si el fabricante lo permite), CPU, RAM, almacenamiento y dispositivo, en vivo.
- **🧹 Limpieza**: recomendaciones según el estado del móvil y opciones marcadas como Recomendado / Opcional / Con cuidado (caché de SSS+, herramienta de Android, capturas antiguas, videos grandes, fotos y audios grandes, ahorro de batería, desinstalar apps). Siempre eliges qué se borra y Android pide confirmación.
- **🎮 Juegos**: Culebrita, Bloques que caen, Rompeladrillos y Buscaminas, con récords.
- **✂ Editores** con galería automática:
  - Fotos: girar, espejo, voltear, recortes (1:1, 4:3, 3:4, 16:9, 9:16), filtros, brillo, contraste, saturación y zoom con dos dedos.
  - Video: recortar tramo, quitar sonido y extraer el audio (sin perder calidad).
  - Sonido: grabadora, recortar, volumen, fundidos, guardar en Música y **usar como sonido de SSS+**.
- Pantalla principal: línea de sistema (batería, temperatura, espacio libre) y accesos a las 4 secciones.

## Novedades v0.1.1
- Arreglado: el sonido de alarma se repetía sin parar (ahora suena una vez, máximo 10 s, con doble vigilancia).
- Notificación grande **🛑 DETENER** visible con el móvil bloqueado; tocarla o deslizarla también lo para.
- Encender la pantalla (botón de encendido) detiene el sonido.
- Pausa de 4 s tras sonar para que no se vuelva a activar sola.
- Detector de aplausos más listo: solo cuenta golpes muy cortos (aplausos); descarta voces, música, golpes largos y ruidos sostenidos.
- Seguro anti-bucle: si suena 3 veces seguidas sin que nadie lo pare, deja de escuchar 1 minuto.

## Novedades v0.1
- Nuevo nombre: **SSS+**.
- Interfaz HUD neón estilo Pipox: botón de encendido grande, panel de sistema en vivo (estado, medidor del micrófono con línea de umbral, puntos que se encienden con cada aplauso) y controles rápidos (Probar, Sonido, Volumen).
- Pantalla ⚙ Ajustes aparte: Detección, Sonido, Skin y Batería.
- Skin: colores rápidos, color RGB de los marcos, opacidad de paneles, color cambiante (arcoíris) con velocidad, y fondo de pantalla propio.

## Permisos (solo estos)
- Micrófono, notificaciones, servicio en primer plano y mantener activo (aplausos y grabadora).
- Fotos, videos y audio: solo se piden al entrar en Editores o Limpieza.
- **Sin internet** y sin contactos.

## Compilar el APK
### Opción A: GitHub (sin instalar nada, sirve desde el móvil)
1. Crea un repositorio en github.com y sube todo el contenido de esta carpeta (incluida `.github`).
2. Ve a la pestaña **Actions** → "Compilar APK" se ejecuta solo (o pulsa *Run workflow*).
3. Al terminar (~3 min), abre la ejecución y descarga **SSS-APK** (un .zip con el .apk dentro).
4. Instálalo en el teléfono (acepta "instalar apps de origen desconocido").

### Opción B: en el propio teléfono
Abre la carpeta con una app tipo AndroidIDE y compila `assembleRelease`.

### Opción C: Android Studio en PC
Abrir la carpeta → Build → Build APK.

## Uso
1. Abre SSS+ y toca el **botón de encendido** grande (acepta micrófono y notificaciones).
2. Elige tu sonido, ajusta el volumen y pulsa **▶ PROBAR**.
3. En ⚙ Ajustes → Batería, pon SSS+ sin restricciones (si no, algunas marcas lo cierran).

## Notas
- Si reinicias el teléfono, hay que abrir la app y activarla de nuevo (Android no deja encender el micrófono solo al arrancar).
- Usa algo de batería por tener el micrófono siempre escuchando.
- Si suena con ruidos que no son aplausos, baja la sensibilidad; si no detecta desde lejos, súbela.
