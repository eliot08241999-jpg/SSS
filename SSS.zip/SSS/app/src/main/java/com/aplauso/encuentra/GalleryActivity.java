package com.aplauso.encuentra;

import android.content.ContentUris;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Galería automática con pestañas Fotos / Videos / Audios; tocar abre el editor. */
public class GalleryActivity extends NeonActivity {
    static final int REQ_MEDIA = 30;

    int type = Media.TYPE_IMAGE;
    List<Media.Item> items = new ArrayList<>();
    GridView grid;
    ListView list;
    TextView info, tabImg, tabVid, tabAud;
    View recordBtn;
    final ExecutorService pool = Executors.newFixedThreadPool(3);
    final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    final Adapter adapter = new Adapter();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(14), dpi(18), dpi(14), dpi(8));
        col.addView(topBar("EDITORES"), gapBelow(12));

        LinearLayout tabs = new LinearLayout(this);
        tabImg = button("🖼 FOTOS", v -> load(Media.TYPE_IMAGE));
        tabVid = button("🎬 VIDEOS", v -> load(Media.TYPE_VIDEO));
        tabAud = button("🎵 AUDIOS", v -> load(Media.TYPE_AUDIO));
        tabs.addView(tabImg, weight(true));
        tabs.addView(tabVid, weight(true));
        tabs.addView(tabAud, weight(false));
        col.addView(tabs, gapBelow(8));

        recordBtn = button("🎙 GRABAR SONIDO NUEVO", v ->
                startActivity(new Intent(this, AudioEditorActivity.class).putExtra("record", true)));
        col.addView(recordBtn, gapBelow(8));

        info = text("", 13);
        info.setGravity(Gravity.CENTER);
        col.addView(info, gapBelow(6));

        FrameLayout area = new FrameLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dpi(4));
        grid.setVerticalSpacing(dpi(4));
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(this::open);
        list = new ListView(this);
        list.setAdapter(adapter);
        list.setOnItemClickListener(this::open);
        list.setDividerHeight(dpi(6));
        area.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        area.addView(list, new FrameLayout.LayoutParams(-1, -1));
        col.addView(area, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(makeRoot(col));

        if (Media.hasPermission(this)) load(type);
        else Media.request(this, REQ_MEDIA);
    }

    private LinearLayout.LayoutParams weight(boolean gap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        if (gap) lp.rightMargin = dpi(6);
        return lp;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code != REQ_MEDIA) return;
        if (Media.hasPermission(this)) load(type);
        else info.setText("Sin permiso de fotos/videos/audio no puedo mostrar tu galería.\nActívalo en Ajustes del teléfono → Apps → SSS+ → Permisos.");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Media.hasPermission(this)) load(type); // por si guardaste algo nuevo
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
    }

    void load(int t) {
        type = t;
        tabImg.setAlpha(t == Media.TYPE_IMAGE ? 1f : 0.45f);
        tabVid.setAlpha(t == Media.TYPE_VIDEO ? 1f : 0.45f);
        tabAud.setAlpha(t == Media.TYPE_AUDIO ? 1f : 0.45f);
        recordBtn.setVisibility(t == Media.TYPE_AUDIO ? View.VISIBLE : View.GONE);
        if (!Media.hasPermission(this)) { Media.request(this, REQ_MEDIA); return; }
        info.setText("Cargando…");
        pool.execute(() -> {
            List<Media.Item> got = Media.query(this, t, null, null, 800);
            runOnUiThread(() -> {
                if (t != type) return;
                items = got;
                grid.setVisibility(t == Media.TYPE_AUDIO ? View.GONE : View.VISIBLE);
                list.setVisibility(t == Media.TYPE_AUDIO ? View.VISIBLE : View.GONE);
                adapter.notifyDataSetChanged();
                info.setText(items.isEmpty() ? "No hay archivos" : items.size() + " archivos · toca uno para editarlo");
            });
        });
    }

    void open(AdapterView<?> parent, View v, int pos, long id) {
        Media.Item it = items.get(pos);
        Class<?> target = it.type == Media.TYPE_VIDEO ? VideoEditorActivity.class
                : it.type == Media.TYPE_AUDIO ? AudioEditorActivity.class : PhotoEditorActivity.class;
        startActivity(new Intent(this, target).setData(it.uri).putExtra("name", it.name));
    }

    static String time(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    Bitmap thumb(Media.Item it) {
        try {
            if (Build.VERSION.SDK_INT >= 29)
                return getContentResolver().loadThumbnail(it.uri, new Size(300, 300), null);
            long id = ContentUris.parseId(it.uri);
            if (it.type == Media.TYPE_VIDEO)
                return MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), id, MediaStore.Video.Thumbnails.MINI_KIND, null);
            return MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), id, MediaStore.Images.Thumbnails.MINI_KIND, null);
        } catch (Exception e) {
            return null;
        }
    }

    class Adapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            Media.Item it = items.get(pos);
            if (it.type == Media.TYPE_AUDIO) {
                TextView t = convert instanceof TextView ? (TextView) convert : button("", null);
                t.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                t.setClickable(false);
                t.setText("🎵  " + it.name + "\n      " + time(it.durationMs) + " · " + SysInfo.bytes(it.size));
                return t;
            }
            FrameLayout cell;
            ImageView img;
            TextView dur;
            if (convert instanceof FrameLayout) {
                cell = (FrameLayout) convert;
                img = (ImageView) cell.getChildAt(0);
                dur = (TextView) cell.getChildAt(1);
            } else {
                cell = new FrameLayout(GalleryActivity.this);
                int size = (grid.getWidth() > 0 ? grid.getWidth() : getResources().getDisplayMetrics().widthPixels) / 3 - dpi(4);
                cell.setLayoutParams(new GridView.LayoutParams(-1, size));
                img = new ImageView(GalleryActivity.this);
                img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                img.setBackgroundColor(Color.argb(60, 255, 255, 255));
                cell.addView(img, new FrameLayout.LayoutParams(-1, -1));
                dur = text("", 11);
                dur.setBackgroundColor(Color.argb(150, 0, 0, 0));
                dur.setPadding(dpi(4), dpi(1), dpi(4), dpi(1));
                cell.addView(dur, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END));
            }
            dur.setVisibility(it.type == Media.TYPE_VIDEO ? View.VISIBLE : View.GONE);
            dur.setText("▶ " + time(it.durationMs));
            String key = it.uri.toString();
            img.setTag(key);
            Bitmap cached = cache.get(key);
            img.setImageBitmap(cached);
            if (cached == null) {
                final ImageView target = img;
                pool.execute(() -> {
                    Bitmap bm = thumb(it);
                    if (bm == null) return;
                    cache.put(key, bm);
                    runOnUiThread(() -> { if (key.equals(target.getTag())) target.setImageBitmap(bm); });
                });
            }
            return cell;
        }
    }
}
