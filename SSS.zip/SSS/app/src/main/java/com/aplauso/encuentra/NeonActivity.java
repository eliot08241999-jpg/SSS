package com.aplauso.encuentra;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Base común de las pantallas: fondo, marcos neón, animación del color y piezas de interfaz. */
public abstract class NeonActivity extends Activity {
    static final int REQ_SOUND = 2, REQ_BG = 3;

    protected SharedPreferences p;
    protected final Handler h = new Handler(Looper.getMainLooper());
    private final List<GradientDrawable> frames = new ArrayList<>();
    private final List<TextView> neonTexts = new ArrayList<>();
    private final List<SeekBar> bars = new ArrayList<>();
    private final List<Switch> switches = new ArrayList<>();
    private ImageView bg;
    private View shade;
    private int lastColor = 0, lastFill = 1;

    private final Runnable tick = new Runnable() {
        public void run() {
            applyColors();
            onTick();
            h.postDelayed(this, 50);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Neon.prefs(this);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
    }

    @Override
    protected void onResume() {
        super.onResume();
        lastColor = 0;
        lastFill = 1;
        loadBackground();
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }

    /** Se llama 20 veces por segundo para refrescar datos en vivo. */
    protected void onTick() {}

    private void applyColors() {
        int c = Neon.color(this);
        int f = Neon.fill(this);
        if (c != lastColor) {
            lastColor = c;
            ColorStateList csl = ColorStateList.valueOf(c);
            for (GradientDrawable d : frames) d.setStroke(dpi(2), c);
            for (TextView t : neonTexts) { t.setTextColor(c); t.setShadowLayer(dp(8), 0, 0, c); }
            for (SeekBar s : bars) { s.setProgressTintList(csl); s.setThumbTintList(csl); }
            for (Switch s : switches) { s.setThumbTintList(csl); s.setTrackTintList(ColorStateList.valueOf(Neon.withAlpha(c, 110))); }
        }
        if (f != lastFill) {
            lastFill = f;
            for (GradientDrawable d : frames) d.setColor(f);
        }
    }

    // ---------- Raíz con fondo ----------
    protected FrameLayout makeRoot(View content) {
        FrameLayout root = new FrameLayout(this);
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(10, 14, 32), Color.rgb(2, 2, 6)});
        root.setBackground(base);
        bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        shade = new View(this);
        shade.setBackgroundColor(Color.argb(110, 0, 0, 0));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        return root;
    }

    protected void loadBackground() {
        if (bg == null) return;
        String u = p.getString("bg_uri", null);
        Bitmap bm = null;
        if (u != null) {
            try {
                Uri uri = Uri.parse(u);
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
                int sample = 1;
                while (Math.max(o.outWidth, o.outHeight) / sample > 1600) sample *= 2;
                o = new BitmapFactory.Options();
                o.inSampleSize = sample;
                try (InputStream in = getContentResolver().openInputStream(uri)) { bm = BitmapFactory.decodeStream(in, null, o); }
            } catch (Exception ignored) {}
        }
        bg.setImageBitmap(bm);
        shade.setVisibility(bm != null ? View.VISIBLE : View.GONE);
    }

    // ---------- Piezas de interfaz ----------
    protected int dpi(float v) { return Math.round(dp(v)); }
    protected float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    protected TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(Color.rgb(225, 232, 245));
        return t;
    }

    protected TextView neonText(String s, float size) {
        TextView t = text(s, size);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        t.setLetterSpacing(0.15f);
        neonTexts.add(t);
        return t;
    }

    protected GradientDrawable frame(float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(dp(radius));
        d.setStroke(dpi(2), Neon.DEFAULT_COLOR);
        d.setColor(Neon.fill(this));
        frames.add(d);
        return d;
    }

    /** Panel con marco neón y título, como los de Pipox. */
    protected LinearLayout panel(String title) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(frame(14));
        l.setPadding(dpi(16), dpi(12), dpi(16), dpi(14));
        if (title != null) {
            TextView t = neonText(title, 13);
            t.setPadding(0, 0, 0, dpi(6));
            l.addView(t);
        }
        return l;
    }

    protected LinearLayout.LayoutParams gapBelow(int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dpi(dp);
        return lp;
    }

    protected TextView button(String label, View.OnClickListener l) {
        TextView b = neonText(label, 14);
        b.setGravity(Gravity.CENTER);
        b.setBackground(frame(12));
        b.setPadding(dpi(10), dpi(13), dpi(10), dpi(13));
        b.setClickable(true);
        b.setOnClickListener(l);
        return b;
    }

    protected TextView circleButton(String label, View.OnClickListener l) {
        TextView b = neonText(label, 20);
        b.setGravity(Gravity.CENTER);
        GradientDrawable d = frame(0);
        d.setShape(GradientDrawable.OVAL);
        b.setBackground(d);
        b.setClickable(true);
        b.setOnClickListener(l);
        return b;
    }

    protected Switch neonSwitch(String label) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextSize(15);
        s.setTextColor(Color.rgb(225, 232, 245));
        s.setPadding(0, dpi(8), 0, dpi(8));
        switches.add(s);
        return s;
    }

    public interface OnValue { void set(int v); }

    protected SeekBar slider(LinearLayout parent, String label, String key, int def, int min, int max,
                             String unit, OnValue onChange) {
        TextView t = text("", 14);
        t.setPadding(0, dpi(8), 0, 0);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        int val = p.getInt(key, def);
        s.setProgress(val - min);
        t.setText(label + ": " + val + unit);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int prog, boolean user) {
                int v = prog + min;
                t.setText(label + ": " + v + unit);
                if (user) {
                    p.edit().putInt(key, v).apply();
                    if (onChange != null) onChange.set(v);
                }
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        bars.add(s);
        parent.addView(t);
        parent.addView(s);
        return s;
    }

    /** Deslizador que no se guarda en ajustes (para los editores). */
    protected SeekBar plainSlider(LinearLayout parent, String label, int min, int max, int val,
                                  String unit, OnValue onChange) {
        TextView t = text(label + ": " + val + unit, 14);
        t.setPadding(0, dpi(8), 0, 0);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(val - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int prog, boolean user) {
                int v = prog + min;
                t.setText(label + ": " + v + unit);
                if (user && onChange != null) onChange.set(v);
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        bars.add(s);
        parent.addView(t);
        parent.addView(s);
        return s;
    }

    /** Pantalla estándar: barra con "←" y título, contenido desplazable. Devuelve la columna. */
    protected LinearLayout screen(String title) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(18), dpi(18), dpi(18), dpi(28));
        col.addView(topBar(title), gapBelow(16));
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(col);
        setContentView(makeRoot(sv));
        return col;
    }

    protected LinearLayout topBar(String title) {
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(circleButton("←", v -> finish()), new LinearLayout.LayoutParams(dpi(46), dpi(46)));
        TextView t = neonText("  " + title, 22);
        top.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        return top;
    }

    /** Fila "dato: valor"; devuelve el TextView del valor para actualizarlo. */
    protected TextView kv(LinearLayout parent, String key) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dpi(4), 0, dpi(4));
        TextView k = text(key, 14);
        k.setTextColor(Color.rgb(160, 170, 190));
        TextView v = text("—", 15);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.END);
        row.addView(k, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(v, new LinearLayout.LayoutParams(0, -2, 1.3f));
        parent.addView(row);
        return v;
    }

    /** Etiqueta de color tipo "RECOMENDADO". */
    protected TextView tag(String s, int color) {
        TextView t = text(s, 11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(color);
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(dp(10));
        d.setStroke(dpi(1), color);
        t.setBackground(d);
        t.setPadding(dpi(8), dpi(2), dpi(8), dpi(2));
        return t;
    }

    protected void toast(String s) {
        android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show();
    }

    // ---------- Selectores de archivos (sin permiso de almacenamiento) ----------
    protected void pickSound() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        startActivityForResult(i, REQ_SOUND);
    }

    protected void pickBackground() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, REQ_BG);
    }

    protected String soundName() {
        return p.getString("sound_name", "Alarma del teléfono");
    }

    /** Se llama cuando cambia el sonido elegido, para refrescar textos. */
    protected void onSoundChanged() {}

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
        if (req == REQ_SOUND) {
            String name = "Sonido personalizado";
            try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) name = c.getString(0);
            } catch (Exception ignored) {}
            p.edit().putString("sound_uri", uri.toString()).putString("sound_name", name).apply();
            onSoundChanged();
        } else if (req == REQ_BG) {
            p.edit().putString("bg_uri", uri.toString()).apply();
            loadBackground();
        }
    }
}
