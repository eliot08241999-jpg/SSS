package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;

/** Colores del tema neón (estilo Pipox) y los dibujos propios: botón de encendido, medidor y puntos de aplausos. */
public class Neon {
    static final int DEFAULT_COLOR = Color.rgb(0, 229, 255); // cian neón

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
    }

    /** Color actual de los marcos: fijo (RGB) o cambiante si está activado. */
    static int color(Context c) {
        SharedPreferences p = prefs(c);
        if (p.getBoolean("cycle", false)) {
            int speed = p.getInt("cycle_speed", 4);           // 1..10
            long period = 24000L / speed;
            float hue = (SystemClock.uptimeMillis() % period) * 360f / period;
            return Color.HSVToColor(new float[]{hue, 0.9f, 1f});
        }
        return p.getInt("neon", DEFAULT_COLOR);
    }

    /** Relleno oscuro de paneles y botones, con la opacidad elegida en Skin. */
    static int fill(Context c) {
        int op = prefs(c).getInt("opacity", 70);              // 0..100
        return Color.argb(Math.round(op * 2.55f), 8, 10, 20);
    }

    static int withAlpha(int color, int a) {
        return Color.argb(a, Color.red(color), Color.green(color), Color.blue(color));
    }

    /** Escala para que los sonidos flojos también se vean en el medidor. */
    static float meter(int peak) {
        return (float) Math.sqrt(Math.max(0, Math.min(32767, peak)) / 32767.0);
    }

    static int threshold(int sens) {
        return (int) (32767 * (0.80 - 0.07 * sens));
    }

    static float dp(View v, float x) {
        return x * v.getResources().getDisplayMetrics().density;
    }

    // ---------- Botón de encendido grande ----------
    static class PowerButton extends View {
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int color = DEFAULT_COLOR;
        private boolean on;

        PowerButton(Context c) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null); // necesario para el brillo difuminado
            setClickable(true);
            glow.setStyle(Paint.Style.STROKE);
            glow.setMaskFilter(new BlurMaskFilter(dp(this, 16), BlurMaskFilter.Blur.NORMAL));
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            txt.setTextAlign(Paint.Align.CENTER);
            txt.setFakeBoldText(true);
            txt.setLetterSpacing(0.3f);
        }

        void set(int c, boolean isOn) {
            if (c != color || isOn != on) { color = c; on = isOn; invalidate(); }
        }

        @Override
        protected void onDraw(Canvas cv) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - dp(this, 24);
            int main = on ? color : withAlpha(color, 110);

            glow.setStrokeWidth(dp(this, on ? 14 : 6));
            glow.setColor(withAlpha(color, on ? 230 : 70));
            cv.drawCircle(cx, cy, r, glow);

            fillP.setColor(on ? withAlpha(color, 45) : Color.argb(150, 8, 10, 20));
            cv.drawCircle(cx, cy, r, fillP);

            stroke.setStrokeWidth(dp(this, 3));
            stroke.setColor(main);
            cv.drawCircle(cx, cy, r, stroke);

            // símbolo de encendido
            float ir = r * 0.36f;
            float oy = cy - r * 0.08f;
            stroke.setStrokeWidth(dp(this, 7));
            cv.drawArc(new RectF(cx - ir, oy - ir, cx + ir, oy + ir), -60, 300, false, stroke);
            cv.drawLine(cx, oy - ir * 1.35f, cx, oy - ir * 0.15f, stroke);

            txt.setColor(main);
            txt.setTextSize(dp(this, 18));
            cv.drawText(on ? "ON" : "OFF", cx, cy + r * 0.62f, txt);
        }
    }

    // ---------- Medidor del micrófono por segmentos ----------
    static class LevelBar extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float level, mark = -1;
        private int color = DEFAULT_COLOR;

        LevelBar(Context c) { super(c); }

        void set(float lvl, float thresholdMark, int c) {
            level = lvl; mark = thresholdMark; color = c; invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            int segs = 24;
            float gap = dp(this, 3);
            float w = (getWidth() - gap * (segs - 1)) / segs;
            float h = getHeight();
            int lit = Math.round(level * segs);
            for (int i = 0; i < segs; i++) {
                float x = i * (w + gap);
                boolean hot = i >= segs * 0.8f;
                int c = hot ? Color.rgb(255, 60, 120) : color;
                p.setColor(i < lit ? c : withAlpha(color, 35));
                cv.drawRoundRect(x, h * 0.2f, x + w, h * 0.8f, dp(this, 2), dp(this, 2), p);
            }
            if (mark >= 0) { // línea blanca = a partir de aquí cuenta como aplauso
                float x = mark * getWidth();
                p.setColor(Color.WHITE);
                cv.drawRect(x - dp(this, 1), 0, x + dp(this, 1), h, p);
            }
        }
    }

    // ---------- Puntos de aplausos (se encienden al aplaudir) ----------
    static class ClapDots extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int total = 5, count, color = DEFAULT_COLOR;

        ClapDots(Context c) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            g.setMaskFilter(new BlurMaskFilter(dp(this, 6), BlurMaskFilter.Blur.NORMAL));
        }

        void set(int t, int c, int col) {
            if (t != total || c != count || col != color) { total = t; count = c; color = col; invalidate(); }
        }

        @Override
        protected void onDraw(Canvas cv) {
            float r = Math.min(getHeight() / 2f - dp(this, 4), dp(this, 9));
            float step = getWidth() / (float) total;
            float cy = getHeight() / 2f;
            for (int i = 0; i < total; i++) {
                float cx = step * (i + 0.5f);
                if (i < count) {
                    g.setColor(color);
                    cv.drawCircle(cx, cy, r, g);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(color);
                } else {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(this, 2));
                    p.setColor(withAlpha(color, 120));
                }
                cv.drawCircle(cx, cy, r, p);
            }
        }
    }
}
