package com.aplauso.encuentra;

import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Info del sistema en vivo: batería, temperatura, CPU, RAM, almacenamiento y dispositivo. */
public class InfoActivity extends NeonActivity {
    TextView bPct, bTemp, bHealth, bCycles, bCap, bStatus, bCurrent, bVolt, bTime;
    TextView tState, tCpu;
    TextView cChip, cCores, cFreq, cLoad;
    TextView rUsed, sUsed;
    TextView dModel, dAndroid, dUptime;
    Meter bMeter, cMeter, rMeter, sMeter;
    int tick = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("INFO");

        LinearLayout bat = panel("◢ BATERÍA");
        bPct = kv(bat, "Carga");
        bMeter = new Meter(this, false);
        bat.addView(bMeter, meterLp());
        bStatus = kv(bat, "Estado");
        bTemp = kv(bat, "Temperatura");
        bHealth = kv(bat, "Salud");
        bCycles = kv(bat, "Ciclos de carga");
        bCap = kv(bat, "Capacidad actual");
        bCurrent = kv(bat, "Corriente");
        bVolt = kv(bat, "Voltaje");
        bTime = kv(bat, "Hasta carga completa");
        col.addView(bat, gapBelow(14));

        LinearLayout th = panel("◢ TEMPERATURA");
        tState = kv(th, "Estado térmico");
        tCpu = kv(th, "CPU");
        col.addView(th, gapBelow(14));

        LinearLayout cpu = panel("◢ CPU");
        cChip = kv(cpu, "Chip");
        cCores = kv(cpu, "Núcleos");
        cFreq = kv(cpu, "Frecuencia máx.");
        cLoad = kv(cpu, "Actividad");
        cMeter = new Meter(this, true);
        cpu.addView(cMeter, meterLp());
        col.addView(cpu, gapBelow(14));

        LinearLayout mem = panel("◢ MEMORIA RAM");
        rUsed = kv(mem, "En uso");
        rMeter = new Meter(this, true);
        mem.addView(rMeter, meterLp());
        col.addView(mem, gapBelow(14));

        LinearLayout st = panel("◢ ALMACENAMIENTO");
        sUsed = kv(st, "Ocupado");
        sMeter = new Meter(this, true);
        st.addView(sMeter, meterLp());
        col.addView(st, gapBelow(14));

        LinearLayout dev = panel("◢ DISPOSITIVO");
        dModel = kv(dev, "Modelo");
        dAndroid = kv(dev, "Android");
        dUptime = kv(dev, "Encendido desde hace");
        col.addView(dev);

        cChip.setText(SysInfo.chip());
        cCores.setText(String.valueOf(SysInfo.cores()));
        long mhz = SysInfo.maxFreqMhz();
        cFreq.setText(mhz > 0 ? String.format(Locale.US, "%.2f GHz", mhz / 1000f) : "No disponible");
        dModel.setText(Build.MANUFACTURER + " " + Build.MODEL);
        dAndroid.setText(Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
    }

    private LinearLayout.LayoutParams meterLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dpi(10));
        lp.topMargin = dpi(4);
        lp.bottomMargin = dpi(6);
        return lp;
    }

    @Override
    protected void onTick() {
        if (tick++ % 20 != 0) return; // una vez por segundo
        int c = Neon.color(this);

        SysInfo.Battery b = SysInfo.battery(this);
        bPct.setText(b.percent >= 0 ? b.percent + " %" : "—");
        bMeter.set(b.percent / 100f, c);
        bStatus.setText(b.status + " · " + b.plugged);
        bTemp.setText(Float.isNaN(b.tempC) ? "—" : String.format(Locale.US, "%.1f °C", b.tempC));
        bHealth.setText(b.health);
        bCycles.setText(b.cycles >= 0 ? String.valueOf(b.cycles) : "No disponible");
        bCap.setText(b.capacityMah > 0 ? "≈ " + b.capacityMah + " mAh" : "No disponible");
        bCurrent.setText(b.currentMa != Integer.MIN_VALUE ? b.currentMa + " mA" : "No disponible");
        bVolt.setText(b.voltageMv > 0 ? String.format(Locale.US, "%.2f V", b.voltageMv / 1000f) : "—");
        bTime.setText(b.chargeTimeLeftMs > 0 ? SysInfo.duration(b.chargeTimeLeftMs)
                : (b.charging ? "Calculando…" : "No está cargando"));

        tState.setText(SysInfo.thermalStatus(this));
        float ct = SysInfo.cpuTempC();
        tCpu.setText(Float.isNaN(ct) ? "Bloqueado por el fabricante" : String.format(Locale.US, "%.0f °C", ct));

        float load = SysInfo.cpuLoad();
        cLoad.setText(load >= 0 ? Math.round(load * 100) + " %" : "No disponible");
        cMeter.set(Math.max(0, load), c);

        long[] r = SysInfo.ram(this);
        long used = r[0] - r[1];
        rUsed.setText(SysInfo.bytes(used) + " / " + SysInfo.bytes(r[0]));
        rMeter.set(used / (float) r[0], c);

        long[] s = SysInfo.storage();
        long sused = s[0] - s[1];
        sUsed.setText(SysInfo.bytes(sused) + " / " + SysInfo.bytes(s[0]));
        sMeter.set(sused / (float) s[0], c);

        dUptime.setText(SysInfo.duration(SystemClock.elapsedRealtime()));
    }
}
