package com.aplauso.encuentra;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Menú de minijuegos y pantalla de juego. */
public class GamesActivity extends NeonActivity {
    static final String[][] GAMES = {
            {"snake", "🐍 CULEBRITA", "Desliza (o toca a un lado) para girar. Come y crece."},
            {"blocks", "🧱 BLOQUES", "Toca izquierda/derecha para mover, centro para girar, desliza abajo para soltar."},
            {"breakout", "🏓 ROMPELADRILLOS", "Arrastra el dedo para mover la barra. Rompe todos los ladrillos."},
            {"mines", "💣 BUSCAMINAS", "Toca para descubrir, mantén pulsado para poner bandera."},
    };
    TextView[] bests = new TextView[GAMES.length];

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("JUEGOS");
        for (int i = 0; i < GAMES.length; i++) {
            String[] g = GAMES[i];
            LinearLayout card = panel(null);
            TextView name = neonText(g[1], 20);
            card.addView(name);
            TextView desc = text(g[2], 13);
            desc.setTextColor(Color.rgb(170, 180, 200));
            desc.setPadding(0, dpi(4), 0, dpi(4));
            card.addView(desc);
            bests[i] = text("", 13);
            card.addView(bests[i]);
            card.setClickable(true);
            card.setOnClickListener(v -> startActivity(new Intent(this, Play.class).putExtra("game", g[0]).putExtra("title", g[1])));
            col.addView(card, gapBelow(14));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (int i = 0; i < GAMES.length; i++)
            bests[i].setText("🏆 Récord: " + p.getInt("best_" + GAMES[i][0], 0));
    }

    /** Pantalla de una partida. */
    public static class Play extends NeonActivity {
        Games.Base game;
        TextView score;

        @Override
        protected void onCreate(Bundle b) {
            super.onCreate(b);
            String id = getIntent().getStringExtra("game");
            if ("blocks".equals(id)) game = new Games.Blocks(this);
            else if ("breakout".equals(id)) game = new Games.Breakout(this);
            else if ("mines".equals(id)) game = new Games.Mines(this);
            else game = new Games.Snake(this);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dpi(12), dpi(18), dpi(12), dpi(12));
            String title = getIntent().getStringExtra("title");
            col.addView(topBar(title == null ? "JUEGO" : title), gapBelow(6));
            score = neonText("", 15);
            score.setGravity(Gravity.CENTER);
            col.addView(score, gapBelow(6));
            col.addView(game, new LinearLayout.LayoutParams(-1, 0, 1));
            setContentView(makeRoot(col));
        }

        @Override
        protected void onResume() {
            super.onResume();
            game.startLoop();
        }

        @Override
        protected void onPause() {
            super.onPause();
            game.stopLoop();
        }

        @Override
        protected void onTick() {
            game.color = Neon.color(this);
            score.setText("PUNTOS " + game.score + "   ·   RÉCORD " + game.best());
        }
    }
}
