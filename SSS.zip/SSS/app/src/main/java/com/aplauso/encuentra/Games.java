package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Los 4 minijuegos neón. Controles táctiles: toques y deslizamientos. */
public class Games {

    // ======================================================================
    // Base común: bucle, puntuación, récord y pantalla de "fin de partida"
    // ======================================================================
    abstract static class Base extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Handler h = new Handler(Looper.getMainLooper());
        final Random rnd = new Random();
        final String key;
        int color = Neon.DEFAULT_COLOR;
        int score;
        boolean over, started, won;
        long interval = 16;
        private float downX, downY;
        private long downAt;

        private final Runnable loop = new Runnable() {
            public void run() {
                if (started && !over) step();
                invalidate();
                h.postDelayed(this, interval);
            }
        };

        Base(Context c, String key) {
            super(c);
            this.key = key;
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            glow.setMaskFilter(new BlurMaskFilter(dp(6), BlurMaskFilter.Blur.NORMAL));
            txt.setTextAlign(Paint.Align.CENTER);
            txt.setFakeBoldText(true);
            txt.setColor(Color.WHITE);
        }

        float dp(float v) { return v * getResources().getDisplayMetrics().density; }

        void startLoop() { h.removeCallbacks(loop); h.post(loop); }
        void stopLoop() { h.removeCallbacks(loop); }

        SharedPreferences prefs() { return getContext().getSharedPreferences("cfg", Context.MODE_PRIVATE); }
        int best() { return prefs().getInt("best_" + key, 0); }

        void gameOver(boolean win) {
            over = true;
            won = win;
            if (score > best()) prefs().edit().putInt("best_" + key, score).apply();
        }

        void newGame() {
            score = 0;
            over = false;
            won = false;
            started = true;
            reset();
        }

        @Override
        protected void onSizeChanged(int w, int h0, int ow, int oh) {
            if (w > 0 && h0 > 0) newGame();
        }

        abstract void reset();
        abstract void step();
        abstract void render(Canvas c);
        void onTap(float x, float y, boolean longPress) {}
        void onSwipe(int dx, int dy) {}   // dx/dy: -1, 0 o 1
        void onDrag(float x, float y) {}

        @Override
        protected void onDraw(Canvas c) {
            render(c);
            if (over) {
                c.drawColor(Color.argb(170, 0, 0, 0));
                txt.setTextSize(dp(30));
                txt.setColor(color);
                c.drawText(won ? "¡GANASTE!" : "FIN DE PARTIDA", getWidth() / 2f, getHeight() / 2f - dp(30), txt);
                txt.setColor(Color.WHITE);
                txt.setTextSize(dp(18));
                c.drawText("Puntos: " + score + "   ·   Récord: " + best(), getWidth() / 2f, getHeight() / 2f + dp(6), txt);
                txt.setTextSize(dp(15));
                c.drawText("Toca para jugar otra vez", getWidth() / 2f, getHeight() / 2f + dp(40), txt);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX(); downY = e.getY(); downAt = SystemClock.uptimeMillis();
                    if (!over) onDrag(e.getX(), e.getY());
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!over) onDrag(e.getX(), e.getY());
                    return true;
                case MotionEvent.ACTION_UP:
                    if (over) { newGame(); return true; }
                    float dx = e.getX() - downX, dy = e.getY() - downY;
                    float min = dp(30);
                    if (Math.abs(dx) < min && Math.abs(dy) < min) {
                        onTap(e.getX(), e.getY(), SystemClock.uptimeMillis() - downAt > 400);
                    } else if (Math.abs(dx) > Math.abs(dy)) {
                        onSwipe(dx > 0 ? 1 : -1, 0);
                    } else {
                        onSwipe(0, dy > 0 ? 1 : -1);
                    }
                    return true;
            }
            return super.onTouchEvent(e);
        }

        /** Celda neón con brillo. */
        void cell(Canvas c, float l, float t, float r, float b, int col) {
            float pad = Math.max(1, (r - l) * 0.08f);
            glow.setColor(Neon.withAlpha(col, 160));
            c.drawRoundRect(l + pad, t + pad, r - pad, b - pad, pad * 2, pad * 2, glow);
            p.setStyle(Paint.Style.FILL);
            p.setColor(col);
            c.drawRoundRect(l + pad, t + pad, r - pad, b - pad, pad * 2, pad * 2, p);
        }

        void frame(Canvas c, float l, float t, float r, float b) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2));
            p.setColor(Neon.withAlpha(color, 140));
            c.drawRoundRect(l, t, r, b, dp(8), dp(8), p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    // ======================================================================
    // CULEBRITA: desliza para girar
    // ======================================================================
    static class Snake extends Base {
        static final int COLS = 18;
        int rows;
        float cs, ox, oy;
        final ArrayDeque<int[]> body = new ArrayDeque<>();
        int dirX = 1, dirY = 0, nextX = 1, nextY = 0;
        int foodX, foodY;

        Snake(Context c) { super(c, "snake"); }

        @Override void reset() {
            cs = getWidth() / (float) COLS;
            rows = Math.max(10, (int) (getHeight() / cs));
            ox = (getWidth() - cs * COLS) / 2f;
            oy = (getHeight() - cs * rows) / 2f;
            body.clear();
            int sx = COLS / 2, sy = rows / 2;
            for (int i = 0; i < 4; i++) body.addLast(new int[]{sx - i, sy});
            dirX = nextX = 1;
            dirY = nextY = 0;
            interval = 150;
            placeFood();
        }

        void placeFood() {
            while (true) {
                foodX = rnd.nextInt(COLS);
                foodY = rnd.nextInt(rows);
                boolean onBody = false;
                for (int[] s : body) if (s[0] == foodX && s[1] == foodY) { onBody = true; break; }
                if (!onBody) return;
            }
        }

        @Override void onSwipe(int dx, int dy) {
            if (dx != 0 && dirX == 0) { nextX = dx; nextY = 0; }
            if (dy != 0 && dirY == 0) { nextX = 0; nextY = dy; }
        }

        @Override void onTap(float x, float y, boolean lp) {
            // Toque: gira hacia el lado donde tocas
            int[] head = body.peekFirst();
            if (head == null) return;
            float hx = ox + (head[0] + 0.5f) * cs, hy = oy + (head[1] + 0.5f) * cs;
            if (dirX != 0) onSwipe(0, y > hy ? 1 : -1);
            else onSwipe(x > hx ? 1 : -1, 0);
        }

        @Override void step() {
            dirX = nextX;
            dirY = nextY;
            int[] head = body.peekFirst();
            int nx = head[0] + dirX, ny = head[1] + dirY;
            if (nx < 0 || ny < 0 || nx >= COLS || ny >= rows) { gameOver(false); return; }
            for (int[] s : body) if (s[0] == nx && s[1] == ny) { gameOver(false); return; }
            body.addFirst(new int[]{nx, ny});
            if (nx == foodX && ny == foodY) {
                score += 10;
                interval = Math.max(60, interval - 3);
                placeFood();
            } else {
                body.removeLast();
            }
        }

        @Override void render(Canvas c) {
            frame(c, ox, oy, ox + cs * COLS, oy + cs * rows);
            cell(c, ox + foodX * cs, oy + foodY * cs, ox + (foodX + 1) * cs, oy + (foodY + 1) * cs, Color.rgb(255, 45, 170));
            boolean first = true;
            for (int[] s : body) {
                int col = first ? Color.WHITE : color;
                cell(c, ox + s[0] * cs, oy + s[1] * cs, ox + (s[0] + 1) * cs, oy + (s[1] + 1) * cs, col);
                first = false;
            }
        }
    }

    // ======================================================================
    // BLOQUES QUE CAEN: toca izquierda/derecha para mover, centro para girar,
    // desliza abajo para dejar caer
    // ======================================================================
    static class Blocks extends Base {
        static final int W = 10, H = 20;
        static final int[][][] SHAPES = {
                {{0, 1}, {1, 1}, {2, 1}, {3, 1}},   // I
                {{0, 0}, {1, 0}, {0, 1}, {1, 1}},   // O
                {{1, 0}, {0, 1}, {1, 1}, {2, 1}},   // T
                {{1, 0}, {2, 0}, {0, 1}, {1, 1}},   // S
                {{0, 0}, {1, 0}, {1, 1}, {2, 1}},   // Z
                {{0, 0}, {0, 1}, {1, 1}, {2, 1}},   // J
                {{2, 0}, {0, 1}, {1, 1}, {2, 1}},   // L
        };
        static final int[] COLORS = {
                Color.rgb(0, 229, 255), Color.rgb(255, 230, 0), Color.rgb(170, 70, 255),
                Color.rgb(57, 255, 20), Color.rgb(255, 60, 90), Color.rgb(60, 120, 255), Color.rgb(255, 140, 0)};
        int[][] board = new int[H][W]; // 0 = vacío, si no índice de color + 1
        int[][] cur = new int[4][2];
        int curType, px, py, nextType;
        int lines;
        long fallMs, acc;
        float cs, ox, oy;

        Blocks(Context c) { super(c, "blocks"); }

        @Override void reset() {
            interval = 30;
            cs = Math.min(getWidth() * 0.78f / W, getHeight() * 0.96f / H);
            ox = (getWidth() - cs * W) / 2f - cs * 1.2f;
            if (ox < dp(4)) ox = dp(4);
            oy = (getHeight() - cs * H) / 2f;
            board = new int[H][W];
            lines = 0;
            fallMs = 600;
            acc = 0;
            nextType = rnd.nextInt(SHAPES.length);
            spawn();
        }

        void spawn() {
            curType = nextType;
            nextType = rnd.nextInt(SHAPES.length);
            for (int i = 0; i < 4; i++) { cur[i][0] = SHAPES[curType][i][0]; cur[i][1] = SHAPES[curType][i][1]; }
            px = 3;
            py = 0;
            if (!fits(cur, px, py)) gameOver(false);
        }

        boolean fits(int[][] s, int x, int y) {
            for (int[] b : s) {
                int bx = x + b[0], by = y + b[1];
                if (bx < 0 || bx >= W || by >= H) return false;
                if (by >= 0 && board[by][bx] != 0) return false;
            }
            return true;
        }

        void rotate() {
            if (curType == 1) return; // el cuadrado no gira
            int[][] r = new int[4][2];
            for (int i = 0; i < 4; i++) { r[i][0] = 2 - cur[i][1]; r[i][1] = cur[i][0]; }
            int[] kicks = {0, -1, 1, -2, 2};
            for (int k : kicks) if (fits(r, px + k, py)) { cur = r; px += k; return; }
        }

        void lock() {
            for (int[] b : cur) {
                int by = py + b[1];
                if (by < 0) { gameOver(false); return; }
                board[by][px + b[0]] = curType + 1;
            }
            int cleared = 0;
            for (int y = H - 1; y >= 0; y--) {
                boolean full = true;
                for (int x = 0; x < W; x++) if (board[y][x] == 0) { full = false; break; }
                if (full) {
                    for (int yy = y; yy > 0; yy--) board[yy] = board[yy - 1].clone();
                    board[0] = new int[W];
                    cleared++;
                    y++;
                }
            }
            int[] pts = {0, 100, 300, 500, 800};
            score += pts[cleared];
            lines += cleared;
            fallMs = Math.max(120, 600 - lines * 20L);
            spawn();
        }

        @Override void step() {
            acc += interval;
            if (acc < fallMs) return;
            acc = 0;
            if (fits(cur, px, py + 1)) py++;
            else lock();
        }

        @Override void onTap(float x, float y, boolean lp) {
            float third = getWidth() / 3f;
            if (x < third) { if (fits(cur, px - 1, py)) px--; }
            else if (x > third * 2) { if (fits(cur, px + 1, py)) px++; }
            else rotate();
            invalidate();
        }

        @Override void onSwipe(int dx, int dy) {
            if (dx != 0) { while (fits(cur, px + dx, py)) px += dx; }
            else if (dy > 0) { while (fits(cur, px, py + 1)) { py++; score += 1; } lock(); }
            else rotate();
            invalidate();
        }

        @Override void render(Canvas c) {
            frame(c, ox - dp(3), oy - dp(3), ox + cs * W + dp(3), oy + cs * H + dp(3));
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                    if (board[y][x] != 0)
                        cell(c, ox + x * cs, oy + y * cs, ox + (x + 1) * cs, oy + (y + 1) * cs, COLORS[board[y][x] - 1]);
            // sombra de dónde caerá
            int gy = py;
            while (fits(cur, px, gy + 1)) gy++;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.5f));
            p.setColor(Neon.withAlpha(COLORS[curType], 120));
            for (int[] b : cur)
                c.drawRect(ox + (px + b[0]) * cs + 2, oy + (gy + b[1]) * cs + 2, ox + (px + b[0] + 1) * cs - 2, oy + (gy + b[1] + 1) * cs - 2, p);
            p.setStyle(Paint.Style.FILL);
            for (int[] b : cur)
                if (py + b[1] >= 0)
                    cell(c, ox + (px + b[0]) * cs, oy + (py + b[1]) * cs, ox + (px + b[0] + 1) * cs, oy + (py + b[1] + 1) * cs, COLORS[curType]);
            // siguiente pieza
            float nx = ox + cs * W + dp(14), ny = oy + dp(20), ns = cs * 0.6f;
            txt.setTextSize(dp(12));
            txt.setColor(color);
            c.drawText("SIGUE", nx + ns * 2, ny, txt);
            for (int[] b : SHAPES[nextType])
                cell(c, nx + b[0] * ns, ny + dp(10) + b[1] * ns, nx + (b[0] + 1) * ns, ny + dp(10) + (b[1] + 1) * ns, COLORS[nextType]);
            c.drawText("LÍNEAS", nx + ns * 2, ny + dp(80), txt);
            txt.setColor(Color.WHITE);
            txt.setTextSize(dp(18));
            c.drawText(String.valueOf(lines), nx + ns * 2, ny + dp(104), txt);
        }
    }

    // ======================================================================
    // ROMPELADRILLOS: arrastra el dedo para mover la barra
    // ======================================================================
    static class Breakout extends Base {
        static final int BC = 8, BR = 7;
        boolean[][] bricks = new boolean[BR][BC];
        float padX, padW, padY, bx, by, vx, vy, r;
        int lives, left;
        boolean waiting;

        Breakout(Context c) { super(c, "breakout"); }

        @Override void reset() {
            interval = 16;
            for (int y = 0; y < BR; y++) for (int x = 0; x < BC; x++) bricks[y][x] = true;
            left = BR * BC;
            lives = 3;
            padW = getWidth() * 0.24f;
            padY = getHeight() - dp(70);
            padX = getWidth() / 2f;
            r = dp(7);
            serve();
        }

        void serve() {
            bx = padX;
            by = padY - r - dp(2);
            vx = 0;
            vy = 0;
            waiting = true;
        }

        void launch() {
            float speed = getHeight() / 110f;
            vx = speed * (rnd.nextBoolean() ? 0.6f : -0.6f);
            vy = -speed;
            waiting = false;
        }

        @Override void onDrag(float x, float y) {
            padX = Math.max(padW / 2, Math.min(getWidth() - padW / 2, x));
            if (waiting) bx = padX;
        }

        @Override void onTap(float x, float y, boolean lp) { if (waiting) launch(); }
        @Override void onSwipe(int dx, int dy) { if (waiting) launch(); }

        @Override void step() {
            if (waiting) return;
            bx += vx;
            by += vy;
            float w = getWidth();
            if (bx < r) { bx = r; vx = Math.abs(vx); }
            if (bx > w - r) { bx = w - r; vx = -Math.abs(vx); }
            float top = dp(10);
            if (by < top + r) { by = top + r; vy = Math.abs(vy); }
            // barra
            if (vy > 0 && by + r >= padY && by + r <= padY + dp(14) && Math.abs(bx - padX) < padW / 2 + r) {
                float off = (bx - padX) / (padW / 2);           // -1..1
                float speed = (float) Math.hypot(vx, vy) * 1.01f;
                vx = speed * off * 0.85f;
                vy = -(float) Math.sqrt(Math.max(0.1f, speed * speed - vx * vx));
            }
            if (by > getHeight()) {
                lives--;
                if (lives <= 0) { gameOver(false); return; }
                serve();
                return;
            }
            // ladrillos
            float bw = w / BC, bh = dp(22), boy = dp(60);
            int col = (int) (bx / bw), row = (int) ((by - boy) / bh);
            if (row >= 0 && row < BR && col >= 0 && col < BC && bricks[row][col]) {
                bricks[row][col] = false;
                left--;
                score += (BR - row) * 10;
                float cx = col * bw + bw / 2, cy = boy + row * bh + bh / 2;
                if (Math.abs(bx - cx) / bw > Math.abs(by - cy) / bh) vx = -vx; else vy = -vy;
                if (left == 0) gameOver(true);
            }
        }

        @Override void render(Canvas c) {
            float w = getWidth(), bw = w / BC, bh = dp(22), boy = dp(60);
            for (int y = 0; y < BR; y++) {
                float hue = (y * 360f / BR + 180) % 360;
                int col = Color.HSVToColor(new float[]{hue, 0.85f, 1f});
                for (int x = 0; x < BC; x++)
                    if (bricks[y][x]) cell(c, x * bw, boy + y * bh, (x + 1) * bw, boy + (y + 1) * bh, col);
            }
            cell(c, padX - padW / 2, padY, padX + padW / 2, padY + dp(14), color);
            glow.setColor(Color.WHITE);
            c.drawCircle(bx, by, r, glow);
            p.setColor(Color.WHITE);
            c.drawCircle(bx, by, r, p);
            txt.setTextSize(dp(14));
            txt.setColor(color);
            StringBuilder hearts = new StringBuilder();
            for (int i = 0; i < lives; i++) hearts.append("♥ ");
            c.drawText(hearts.toString(), w / 2, dp(36), txt);
            if (waiting && !over) {
                txt.setColor(Color.WHITE);
                c.drawText("Toca para lanzar · arrastra para mover", w / 2, padY + dp(44), txt);
            }
        }
    }

    // ======================================================================
    // BUSCAMINAS: toca para descubrir, mantén pulsado para poner bandera
    // ======================================================================
    static class Mines extends Base {
        static final int C = 9, R = 13, MINES = 18;
        boolean[][] mine = new boolean[R][C], open = new boolean[R][C], flag = new boolean[R][C];
        int[][] near = new int[R][C];
        boolean placed;
        int opened;
        long startAt;
        float cs, ox, oy;

        Mines(Context c) { super(c, "mines"); }

        @Override void reset() {
            interval = 200;
            mine = new boolean[R][C];
            open = new boolean[R][C];
            flag = new boolean[R][C];
            near = new int[R][C];
            placed = false;
            opened = 0;
            startAt = SystemClock.elapsedRealtime();
            cs = Math.min(getWidth() * 0.96f / C, (getHeight() - dp(50)) * 0.98f / R);
            ox = (getWidth() - cs * C) / 2f;
            oy = dp(44) + (getHeight() - dp(44) - cs * R) / 2f;
        }

        void place(int sr, int sc) {
            int n = 0;
            while (n < MINES) {
                int r = rnd.nextInt(R), c = rnd.nextInt(C);
                if (mine[r][c] || (Math.abs(r - sr) <= 1 && Math.abs(c - sc) <= 1)) continue;
                mine[r][c] = true;
                n++;
            }
            for (int r = 0; r < R; r++)
                for (int c = 0; c < C; c++) {
                    int k = 0;
                    for (int dr = -1; dr <= 1; dr++)
                        for (int dc = -1; dc <= 1; dc++) {
                            int rr = r + dr, cc = c + dc;
                            if (rr >= 0 && rr < R && cc >= 0 && cc < C && mine[rr][cc]) k++;
                        }
                    near[r][c] = k;
                }
            placed = true;
            startAt = SystemClock.elapsedRealtime();
        }

        void reveal(int r, int c) {
            List<int[]> stack = new ArrayList<>();
            stack.add(new int[]{r, c});
            while (!stack.isEmpty()) {
                int[] q = stack.remove(stack.size() - 1);
                int rr = q[0], cc = q[1];
                if (rr < 0 || rr >= R || cc < 0 || cc >= C || open[rr][cc] || flag[rr][cc]) continue;
                open[rr][cc] = true;
                opened++;
                if (near[rr][cc] == 0 && !mine[rr][cc])
                    for (int dr = -1; dr <= 1; dr++)
                        for (int dc = -1; dc <= 1; dc++)
                            if (dr != 0 || dc != 0) stack.add(new int[]{rr + dr, cc + dc});
            }
        }

        @Override void onTap(float x, float y, boolean longPress) {
            int c = (int) ((x - ox) / cs), r = (int) ((y - oy) / cs);
            if (x < ox || y < oy || r < 0 || r >= R || c < 0 || c >= C) return;
            if (longPress) {
                if (!open[r][c]) flag[r][c] = !flag[r][c];
            } else {
                if (flag[r][c] || open[r][c]) return;
                if (!placed) place(r, c);
                if (mine[r][c]) {
                    for (int rr = 0; rr < R; rr++) for (int cc = 0; cc < C; cc++) if (mine[rr][cc]) open[rr][cc] = true;
                    gameOver(false);
                } else {
                    reveal(r, c);
                    if (opened == R * C - MINES) {
                        long secs = (SystemClock.elapsedRealtime() - startAt) / 1000;
                        score = (int) Math.max(10, 1000 - secs * 5);
                        gameOver(true);
                    }
                }
            }
            invalidate();
        }

        @Override void step() {}

        @Override void render(Canvas c) {
            int flags = 0;
            for (int r = 0; r < R; r++) for (int cc = 0; cc < C; cc++) if (flag[r][cc]) flags++;
            long secs = placed && !over ? (SystemClock.elapsedRealtime() - startAt) / 1000 : 0;
            txt.setTextSize(dp(15));
            txt.setColor(color);
            c.drawText("💣 " + (MINES - flags) + "     ⏱ " + secs + " s     (mantén pulsado = 🚩)", getWidth() / 2f, dp(28), txt);
            int[] numCol = {0, Color.rgb(0, 229, 255), Color.rgb(57, 255, 20), Color.rgb(255, 60, 90),
                    Color.rgb(170, 70, 255), Color.rgb(255, 140, 0), Color.rgb(0, 200, 200), Color.WHITE, Color.GRAY};
            for (int r = 0; r < R; r++)
                for (int cc = 0; cc < C; cc++) {
                    float l = ox + cc * cs, t = oy + r * cs;
                    RectF rc = new RectF(l + 2, t + 2, l + cs - 2, t + cs - 2);
                    if (open[r][cc]) {
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(mine[r][cc] ? Color.rgb(160, 20, 50) : Color.argb(60, 255, 255, 255));
                        c.drawRoundRect(rc, dp(4), dp(4), p);
                        if (mine[r][cc]) {
                            txt.setTextSize(cs * 0.55f);
                            c.drawText("💣", l + cs / 2, t + cs * 0.7f, txt);
                        } else if (near[r][cc] > 0) {
                            txt.setTextSize(cs * 0.6f);
                            txt.setColor(numCol[near[r][cc]]);
                            c.drawText(String.valueOf(near[r][cc]), l + cs / 2, t + cs * 0.72f, txt);
                        }
                    } else {
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(Neon.withAlpha(color, 55));
                        c.drawRoundRect(rc, dp(4), dp(4), p);
                        p.setStyle(Paint.Style.STROKE);
                        p.setStrokeWidth(dp(1.5f));
                        p.setColor(Neon.withAlpha(color, 170));
                        c.drawRoundRect(rc, dp(4), dp(4), p);
                        p.setStyle(Paint.Style.FILL);
                        if (flag[r][cc]) {
                            txt.setTextSize(cs * 0.55f);
                            c.drawText("🚩", l + cs / 2, t + cs * 0.7f, txt);
                        }
                    }
                }
        }
    }
}
