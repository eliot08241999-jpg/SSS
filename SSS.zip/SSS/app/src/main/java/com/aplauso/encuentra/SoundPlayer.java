package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

/**
 * Reproduce el sonido elegido UNA vez por el canal de alarma (se oye aunque el móvil esté en silencio).
 * Mientras suena, se puede parar de 4 formas:
 *  1. Botón DETENER de la notificación (visible también con el móvil bloqueado).
 *  2. Tocando o deslizando esa notificación.
 *  3. Encendiendo la pantalla (botón de encendido).
 *  4. Abriendo la app.
 * Y nunca dura más de 10 segundos.
 */
public class SoundPlayer {
    static final long MAX_MS = 10_000;
    static final String CH_ALARM = "alarma";
    static final int NOTIF_ALARM = 2;

    private static MediaPlayer player;
    private static long startedAt;
    private static int prevVolume = -1;
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private static Context appCtx;
    private static final Runnable capStop = () -> { if (appCtx != null) stop(appCtx); };
    private static Runnable onFinished;
    private static BroadcastReceiver screenOn;
    /** true si la última vez lo paró una persona (botón, pantalla, abrir la app). */
    static volatile boolean stoppedByUser = false;

    /** Parada hecha por una persona: lo encontraste. */
    public static void stopByUser(Context c) {
        stoppedByUser = true;
        stop(c);
    }

    public static synchronized boolean isPlaying() { return player != null; }

    /** Milisegundos que lleva sonando (0 si no suena). */
    public static synchronized long elapsed() {
        return player == null ? 0 : SystemClock.elapsedRealtime() - startedAt;
    }

    public static synchronized void play(Context c, Runnable whenDone) {
        stop(c);
        stoppedByUser = false;
        Context app = c.getApplicationContext();
        appCtx = app;
        onFinished = whenDone;
        SharedPreferences p = app.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        int volPct = p.getInt("volume", 100);

        AudioManager am = app.getSystemService(AudioManager.class);
        try {
            prevVolume = am.getStreamVolume(AudioManager.STREAM_ALARM);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            am.setStreamVolume(AudioManager.STREAM_ALARM, Math.max(1, Math.round(max * volPct / 100f)), 0);
        } catch (Exception ignored) { prevVolume = -1; }

        String custom = p.getString("sound_uri", null);
        if (!start(app, custom != null ? Uri.parse(custom) : null)) {
            start(app, null); // si el sonido propio falla, usa el de por defecto
        }
        if (player == null) { finish(app); return; }

        startedAt = SystemClock.elapsedRealtime();
        handler.postDelayed(capStop, MAX_MS);
        showStopNotification(app);
        listenScreenOn(app);
    }

    private static boolean start(Context app, Uri uri) {
        MediaPlayer mp = new MediaPlayer();
        try {
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            mp.setDataSource(app, uri);
            mp.setOnCompletionListener(m -> stop(app));
            mp.prepare();
            // Los tonos de alarma traen una marca interna de "repetir siempre" que se activa
            // al preparar; por eso se desactiva DESPUÉS de prepare().
            mp.setLooping(false);
            mp.start();
            player = mp;
            return true;
        } catch (Exception e) {
            mp.release();
            return false;
        }
    }

    public static synchronized void stop(Context c) {
        handler.removeCallbacks(capStop);
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
        finish(c.getApplicationContext());
    }

    private static void finish(Context app) {
        if (prevVolume >= 0) {
            try {
                app.getSystemService(AudioManager.class)
                        .setStreamVolume(AudioManager.STREAM_ALARM, prevVolume, 0);
            } catch (Exception ignored) {}
            prevVolume = -1;
        }
        app.getSystemService(NotificationManager.class).cancel(NOTIF_ALARM);
        if (screenOn != null) {
            try { app.unregisterReceiver(screenOn); } catch (Exception ignored) {}
            screenOn = null;
        }
        Runnable r = onFinished;
        onFinished = null;
        if (r != null) r.run();
    }

    // ---------- Notificación grande con DETENER, visible en pantalla bloqueada ----------
    private static void showStopNotification(Context app) {
        NotificationManager nm = app.getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CH_ALARM, "Sonido sonando",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);          // el sonido ya lo pone la app
        ch.enableVibration(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        ch.setBypassDnd(true);
        nm.createNotificationChannel(ch);

        PendingIntent stopPi = PendingIntent.getBroadcast(app, 10,
                new Intent(app, StopReceiver.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(app, CH_ALARM)
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                .setContentTitle("🔊 ¡Aquí estoy!")
                .setContentText("Toca para DETENER el sonido")
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(stopPi)   // tocar la notificación lo para
                .setDeleteIntent(stopPi)    // deslizarla también
                .setAutoCancel(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(app, android.R.drawable.ic_media_pause),
                        "🛑 DETENER", stopPi).build())
                .build();
        try { nm.notify(NOTIF_ALARM, n); } catch (Exception ignored) {}
    }

    // ---------- Encender la pantalla también lo para ----------
    private static void listenScreenOn(Context app) {
        screenOn = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) { stopByUser(c); }
        };
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_ON);
        try {
            if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(screenOn, f, Context.RECEIVER_NOT_EXPORTED);
            else app.registerReceiver(screenOn, f);
        } catch (Exception ignored) { screenOn = null; }
    }

    /** Recibe el toque en DETENER (funciona aunque la escucha esté apagada). */
    public static class StopReceiver extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) { stopByUser(c); }
    }
}
