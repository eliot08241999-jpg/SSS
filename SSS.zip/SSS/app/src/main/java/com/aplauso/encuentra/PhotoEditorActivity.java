package com.aplauso.encuentra;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Editor de fotos: girar, voltear, recortar, filtros, brillo/contraste/saturación y zoom con dos dedos. */
public class PhotoEditorActivity extends NeonActivity {
    static final String[] FILTERS = {"Normal", "B/N", "Sepia", "Frío", "Cálido", "Neón", "Invertir"};
    static final String[] CROPS = {"Original", "1:1", "4:3", "3:4", "16:9", "9:16"};

    Bitmap orig, geo;
    int rot = 0, filter = 0, crop = 0;
    boolean flipH, flipV;
    int bright = 0, contrast = 100, sat = 100;
    ImageView img;
    float zoom = 1f;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = screen("FOTO");
        Uri uri = getIntent().getData();
        orig = uri == null ? null : load(uri);
        if (orig == null) {
            col.addView(text("No se pudo abrir la imagen.", 16));
            return;
        }

        // Vista previa con zoom (pellizca con dos dedos, arrastra para moverte)
        FrameLayout box = new FrameLayout(this);
        box.setBackground(frame(14));
        box.setClipChildren(true);
        img = new ImageView(this);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        box.addView(img, new FrameLayout.LayoutParams(-1, -1));
        int h = (int) (getResources().getDisplayMetrics().heightPixels * 0.42f);
        col.addView(box, new LinearLayout.LayoutParams(-1, h));
        setupZoom(box);
        TextView hint = text("Pellizca para hacer zoom · doble toque para volver", 12);
        hint.setPadding(0, dpi(4), 0, dpi(10));
        col.addView(hint);

        LinearLayout tools = panel("◢ GIRAR Y VOLTEAR");
        LinearLayout row = new LinearLayout(this);
        row.addView(button("↻ GIRAR", v -> { rot = (rot + 1) % 4; rebuild(); }), w(true));
        row.addView(button("⇋ ESPEJO", v -> { flipH = !flipH; rebuild(); }), w(true));
        row.addView(button("⇅ VOLTEAR", v -> { flipV = !flipV; rebuild(); }), w(false));
        tools.addView(row);
        col.addView(tools, gapBelow(12));

        LinearLayout cp = panel("◢ RECORTE");
        cp.addView(chips(CROPS, i -> { crop = i; rebuild(); }));
        col.addView(cp, gapBelow(12));

        LinearLayout fp = panel("◢ FILTROS");
        fp.addView(chips(FILTERS, i -> { filter = i; applyColor(); }));
        col.addView(fp, gapBelow(12));

        LinearLayout adj = panel("◢ AJUSTES");
        plainSlider(adj, "Brillo", -100, 100, 0, "", v -> { bright = v; applyColor(); });
        plainSlider(adj, "Contraste", 50, 200, 100, " %", v -> { contrast = v; applyColor(); });
        plainSlider(adj, "Saturación", 0, 200, 100, " %", v -> { sat = v; applyColor(); });
        col.addView(adj, gapBelow(12));

        col.addView(button("💾 GUARDAR COPIA", v -> save()), gapBelow(8));
        TextView where = text("Se guarda en Imágenes/SSS. La foto original no se toca.", 12);
        col.addView(where);

        rebuild();
    }

    private LinearLayout.LayoutParams w(boolean gap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        if (gap) lp.rightMargin = dpi(6);
        return lp;
    }

    /** Fila desplazable de botones; marca el elegido. */
    private HorizontalScrollView chips(String[] names, OnValue onPick) {
        HorizontalScrollView sv = new HorizontalScrollView(this);
        sv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        TextView[] all = new TextView[names.length];
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView t = button(names[i], null);
            t.setPadding(dpi(14), dpi(8), dpi(14), dpi(8));
            t.setAlpha(i == 0 ? 1f : 0.5f);
            t.setOnClickListener(v -> {
                for (TextView o : all) o.setAlpha(0.5f);
                t.setAlpha(1f);
                onPick.set(idx);
            });
            all[i] = t;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dpi(6);
            row.addView(t, lp);
        }
        sv.addView(row);
        return sv;
    }

    private Bitmap load(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 2560) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            Bitmap bm;
            try (InputStream in = getContentResolver().openInputStream(uri)) { bm = BitmapFactory.decodeStream(in, null, o); }
            if (bm == null) return null;
            // respeta la orientación de la cámara
            int deg = 0;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                ExifInterface ex = new ExifInterface(in);
                int or = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (or == ExifInterface.ORIENTATION_ROTATE_90) deg = 90;
                else if (or == ExifInterface.ORIENTATION_ROTATE_180) deg = 180;
                else if (or == ExifInterface.ORIENTATION_ROTATE_270) deg = 270;
            } catch (Exception ignored) {}
            if (deg != 0) {
                Matrix m = new Matrix();
                m.postRotate(deg);
                bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
            }
            return bm;
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
    }

    /** Aplica giro, espejo y recorte. */
    private void rebuild() {
        Matrix m = new Matrix();
        m.postRotate(rot * 90);
        m.postScale(flipH ? -1 : 1, flipV ? -1 : 1);
        Bitmap t = Bitmap.createBitmap(orig, 0, 0, orig.getWidth(), orig.getHeight(), m, true);
        float[] ratios = {0, 1f, 4f / 3, 3f / 4, 16f / 9, 9f / 16};
        float r = ratios[crop];
        if (r > 0) {
            int w = t.getWidth(), h = t.getHeight();
            int cw = w, ch = Math.round(w / r);
            if (ch > h) { ch = h; cw = Math.round(h * r); }
            t = Bitmap.createBitmap(t, (w - cw) / 2, (h - ch) / 2, cw, ch);
        }
        geo = t;
        img.setImageBitmap(geo);
        applyColor();
    }

    private ColorMatrix colorMatrix() {
        ColorMatrix cm = new ColorMatrix();
        ColorMatrix f = new ColorMatrix();
        switch (filter) {
            case 1: f.setSaturation(0); break;
            case 2: {
                f.setSaturation(0);
                ColorMatrix tint = new ColorMatrix();
                tint.setScale(1.07f, 0.95f, 0.78f, 1f);
                f.postConcat(tint);
                break;
            }
            case 3: f.setScale(0.9f, 1f, 1.15f, 1f); break;
            case 4: f.setScale(1.15f, 1f, 0.85f, 1f); break;
            case 5: f.setSaturation(1.9f); break;
            case 6: f.set(new float[]{-1, 0, 0, 0, 255, 0, -1, 0, 0, 255, 0, 0, -1, 0, 255, 0, 0, 0, 1, 0}); break;
            default: break;
        }
        cm.postConcat(f);
        ColorMatrix s = new ColorMatrix();
        s.setSaturation(sat / 100f);
        cm.postConcat(s);
        float c = contrast / 100f;
        float t = (1 - c) * 128 + bright * 1.27f;
        cm.postConcat(new ColorMatrix(new float[]{c, 0, 0, 0, t, 0, c, 0, 0, t, 0, 0, c, 0, t, 0, 0, 0, 1, 0}));
        return cm;
    }

    private void applyColor() {
        if (img != null) img.setColorFilter(new ColorMatrixColorFilter(colorMatrix()));
    }

    private void setupZoom(FrameLayout box) {
        ScaleGestureDetector sg = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                zoom = Math.max(1f, Math.min(6f, zoom * d.getScaleFactor()));
                img.setScaleX(zoom);
                img.setScaleY(zoom);
                return true;
            }
        });
        final float[] last = new float[2];
        final long[] lastTap = new long[1];
        box.setOnTouchListener((v, e) -> {
            sg.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    last[0] = e.getX(); last[1] = e.getY();
                    long now = System.currentTimeMillis();
                    if (now - lastTap[0] < 300) { // doble toque: restablecer
                        zoom = 1f;
                        img.setScaleX(1f); img.setScaleY(1f);
                        img.setTranslationX(0); img.setTranslationY(0);
                    }
                    lastTap[0] = now;
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (!sg.isInProgress() && zoom > 1f && e.getPointerCount() == 1) {
                        img.setTranslationX(img.getTranslationX() + e.getX() - last[0]);
                        img.setTranslationY(img.getTranslationY() + e.getY() - last[1]);
                    }
                    last[0] = e.getX(); last[1] = e.getY();
                    break;
            }
            v.getParent().requestDisallowInterceptTouchEvent(true);
            return true;
        });
    }

    private void save() {
        if (geo == null) return;
        try {
            Bitmap out = Bitmap.createBitmap(geo.getWidth(), geo.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(out);
            Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
            paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix()));
            c.drawBitmap(geo, 0, 0, paint);
            File tmp = new File(getCacheDir(), "edit_" + System.currentTimeMillis() + ".jpg");
            try (FileOutputStream fos = new FileOutputStream(tmp)) {
                out.compress(Bitmap.CompressFormat.JPEG, 95, fos);
            }
            Uri saved = Media.save(this, tmp, Media.TYPE_IMAGE, "SSS_" + Media.stamp() + ".jpg", "image/jpeg");
            toast(saved != null ? "Guardada en Imágenes/SSS ✓" : "No se pudo guardar");
        } catch (Exception | OutOfMemoryError e) {
            toast("No se pudo guardar");
        }
    }
}
