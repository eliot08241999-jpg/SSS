package com.aplauso.encuentra;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/** Acceso a fotos, videos y audios del teléfono (galería automática) y guardado de resultados. */
public class Media {
    static final int TYPE_IMAGE = 0, TYPE_VIDEO = 1, TYPE_AUDIO = 2;

    static class Item {
        Uri uri;
        String name;
        long size, dateSec, durationMs;
        int type;
    }

    // ---------- Permisos ----------
    static String[] permissions() {
        if (Build.VERSION.SDK_INT >= 33) return new String[]{
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO};
        return new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    }

    static boolean hasPermission(Context c) {
        for (String p : permissions())
            if (c.checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }

    static void request(Activity a, int code) {
        List<String> need = new ArrayList<>();
        for (String p : permissions()) need.add(p);
        if (Build.VERSION.SDK_INT <= 28) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        a.requestPermissions(need.toArray(new String[0]), code);
    }

    // ---------- Consultas ----------
    static Uri collection(int type) {
        if (type == TYPE_VIDEO) return MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        if (type == TYPE_AUDIO) return MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        return MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
    }

    static List<Item> query(Context c, int type, String selection, String[] args, int limit) {
        List<Item> out = new ArrayList<>();
        Uri col = collection(type);
        List<String> cols = new ArrayList<>();
        cols.add(MediaStore.MediaColumns._ID);
        cols.add(MediaStore.MediaColumns.DISPLAY_NAME);
        cols.add(MediaStore.MediaColumns.SIZE);
        cols.add(MediaStore.MediaColumns.DATE_MODIFIED);
        if (type == TYPE_VIDEO) cols.add(MediaStore.Video.Media.DURATION);
        if (type == TYPE_AUDIO) cols.add(MediaStore.Audio.Media.DURATION);
        try (Cursor cur = c.getContentResolver().query(col, cols.toArray(new String[0]), selection, args,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC")) {
            if (cur == null) return out;
            while (cur.moveToNext() && (limit <= 0 || out.size() < limit)) {
                Item it = new Item();
                long id = cur.getLong(0);
                it.uri = ContentUris.withAppendedId(col, id);
                it.name = cur.getString(1);
                it.size = cur.getLong(2);
                it.dateSec = cur.getLong(3);
                if (cols.size() > 4) it.durationMs = cur.getLong(4);
                it.type = type;
                out.add(it);
            }
        } catch (Exception ignored) {}
        return out;
    }

    static long totalSize(List<Item> items) {
        long s = 0;
        for (Item i : items) s += i.size;
        return s;
    }

    // ---------- Guardar resultados de los editores ----------
    /**
     * Copia un archivo temporal a la carpeta pública (Pictures/SSS, Movies/SSS o Music/SSS).
     * Devuelve la Uri del archivo guardado o null si falla.
     */
    static Uri save(Context c, File tmp, int type, String name, String mime) {
        String dir = type == TYPE_VIDEO ? Environment.DIRECTORY_MOVIES
                : type == TYPE_AUDIO ? Environment.DIRECTORY_MUSIC : Environment.DIRECTORY_PICTURES;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir + "/SSS");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri uri = c.getContentResolver().insert(collection(type), v);
                if (uri == null) return null;
                try (OutputStream os = c.getContentResolver().openOutputStream(uri);
                     InputStream is = new FileInputStream(tmp)) {
                    copy(is, os);
                }
                v.clear();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                c.getContentResolver().update(uri, v, null, null);
                return uri;
            } else {
                File folder = new File(Environment.getExternalStoragePublicDirectory(dir), "SSS");
                if (!folder.exists() && !folder.mkdirs()) return null;
                File dest = new File(folder, name);
                try (InputStream is = new FileInputStream(tmp); OutputStream os = new FileOutputStream(dest)) {
                    copy(is, os);
                }
                MediaScannerConnection.scanFile(c, new String[]{dest.getAbsolutePath()}, new String[]{mime}, null);
                return Uri.fromFile(dest);
            }
        } catch (Exception e) {
            return null;
        } finally {
            tmp.delete();
        }
    }

    static void copy(InputStream is, OutputStream os) throws java.io.IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
    }

    static String stamp() {
        return new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(new java.util.Date());
    }
}
