package com.aplauso.encuentra;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;

/**
 * Editor de sonido: grabar con el micrófono, recortar, subir/bajar volumen, fundidos,
 * guardar como WAV y usarlo directamente como sonido de SSS+ (¡la oveja!).
 */
public class AudioEditorActivity extends NeonActivity {
    static final int REQ_MIC = 40;

    Uri uri;
    String name = "Sonido";
    long durMs;
    int startT = 0, endT = 0;         // décimas de segundo
    int gainPct = 100, fadeIn = 0, fadeOut = 0; // fundidos en décimas de segundo

    LinearLayout col, editArea;
    TextView recBtn, recInfo, title, range, playBtn, status;
    SeekBar startBar, endBar;
    MediaRecorder recorder;
    File recFile;
    long recStart;
    MediaPlayer player;
    boolean busy;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        col = screen("SONIDO");

        LinearLayout rec = panel("◢ GRABADORA");
        recBtn = button("🎙 GRABAR", v -> toggleRecord());
        rec.addView(recBtn);
        recInfo = text("Graba con el micrófono y luego edítalo aquí abajo.", 13);
        recInfo.setPadding(0, dpi(6), 0, 0);
        rec.addView(recInfo);
        col.addView(rec, gapBelow(12));

        editArea = new LinearLayout(this);
        editArea.setOrientation(LinearLayout.VERTICAL);
        col.addView(editArea);

        uri = getIntent().getData();
        String n = getIntent().getStringExtra("name");
        if (n != null) name = n;
        if (uri != null) buildEditor();
        else if (getIntent().getBooleanExtra("record", false)) toggleRecord();
    }

    // ---------------- Grabadora ----------------
    private void toggleRecord() {
        if (recorder != null) { stopRecording(); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        stopPreview();
        try {
            recFile = new File(getCacheDir(), "grabacion_" + Media.stamp() + ".m4a");
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128_000);
            recorder.setAudioSamplingRate(44_100);
            recorder.setOutputFile(recFile.getPath());
            recorder.prepare();
            recorder.start();
            recStart = SystemClock.elapsedRealtime();
            recBtn.setText("■ PARAR GRABACIÓN");
        } catch (Exception e) {
            recorder = null;
            toast("No se pudo usar el micrófono");
        }
    }

    private void stopRecording() {
        try { recorder.stop(); } catch (Exception ignored) {}
        recorder.release();
        recorder = null;
        recBtn.setText("🎙 GRABAR OTRA VEZ");
        if (recFile != null && recFile.length() > 0) {
            uri = Uri.fromFile(recFile);
            name = "Grabación " + Media.stamp();
            recInfo.setText("Grabación lista ✓ — edítala abajo y guárdala.");
            buildEditor();
        } else {
            recInfo.setText("La grabación fue demasiado corta.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_MIC && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            toggleRecord();
    }

    // ---------------- Editor ----------------
    private void buildEditor() {
        editArea.removeAllViews();
        durMs = MediaTools.durationMs(this, uri);
        if (durMs <= 0) {
            editArea.addView(text("No se pudo leer este audio.", 15));
            return;
        }
        int total = (int) Math.max(1, durMs / 100);
        startT = 0;
        endT = total;
        gainPct = 100;
        fadeIn = fadeOut = 0;

        title = neonText("🎵 " + name, 15);
        editArea.addView(title, gapBelow(8));

        playBtn = button("▶ ESCUCHAR TRAMO", v -> togglePreview());
        editArea.addView(playBtn, gapBelow(12));

        LinearLayout cut = panel("◢ RECORTAR");
        range = text("", 15);
        cut.addView(range);
        startBar = plainSlider(cut, "Inicio (décimas de s)", 0, total, 0, "", v -> {
            startT = Math.min(v, endT - 1);
            if (startT != v) startBar.setProgress(startT);
            showRange();
        });
        endBar = plainSlider(cut, "Final (décimas de s)", 0, total, total, "", v -> {
            endT = Math.max(v, startT + 1);
            if (endT != v) endBar.setProgress(endT);
            showRange();
        });
        editArea.addView(cut, gapBelow(12));

        LinearLayout fx = panel("◢ VOLUMEN Y FUNDIDOS");
        plainSlider(fx, "Volumen", 10, 300, 100, " %", v -> gainPct = v);
        plainSlider(fx, "Fundido de entrada (décimas)", 0, 50, 0, "", v -> fadeIn = v);
        plainSlider(fx, "Fundido de salida (décimas)", 0, 50, 0, "", v -> fadeOut = v);
        TextView tip = text("Para la alarma de SSS+, mejor un tramo corto (1–5 s) y volumen alto.", 12);
        tip.setPadding(0, dpi(4), 0, 0);
        fx.addView(tip);
        editArea.addView(fx, gapBelow(12));

        editArea.addView(button("🐑 USAR COMO SONIDO DE SSS+", v -> process(true)), gapBelow(8));
        editArea.addView(button("💾 GUARDAR EN MÚSICA", v -> process(false)), gapBelow(8));
        status = text("Se guarda como WAV en Música/SSS. El original no se toca.", 12);
        editArea.addView(status);
        showRange();
    }

    private void showRange() {
        range.setText(String.format(java.util.Locale.US, "Tramo: %.1f s → %.1f s  (%.1f s)",
                startT / 10f, endT / 10f, (endT - startT) / 10f));
    }

    private void togglePreview() {
        if (player != null) { stopPreview(); return; }
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA).build());
            player.setDataSource(this, uri);
            player.prepare();
            float vol = Math.min(1f, gainPct / 100f);
            player.setVolume(vol, vol);
            player.seekTo(startT * 100);
            player.setOnCompletionListener(m -> stopPreview());
            player.start();
            playBtn.setText("■ PARAR");
        } catch (Exception e) {
            stopPreview();
            toast("No se puede reproducir");
        }
    }

    private void stopPreview() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
        if (playBtn != null) playBtn.setText("▶ ESCUCHAR TRAMO");
    }

    @Override
    protected void onTick() {
        if (player != null) {
            try { if (player.getCurrentPosition() >= endT * 100) stopPreview(); } catch (Exception ignored) {}
        }
        if (recorder != null) {
            long s = (SystemClock.elapsedRealtime() - recStart) / 1000;
            recInfo.setText("● Grabando… " + GalleryActivity.time(s * 1000));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopPreview();
        if (recorder != null) stopRecording();
    }

    /** Convierte el tramo a WAV con volumen y fundidos; lo guarda en Música o como alarma de SSS+. */
    private void process(boolean asAlarm) {
        if (busy) return;
        busy = true;
        stopPreview();
        long s = startT * 100_000L, e = endT * 100_000L;
        float g = gainPct / 100f;
        long fi = fadeIn * 100_000L, fo = fadeOut * 100_000L;
        status.setText("Procesando… 0 %");
        new Thread(() -> {
            String msg;
            try {
                if (asAlarm) {
                    File out = new File(getFilesDir(), "alarma_sss.wav");
                    File tmp = new File(getCacheDir(), "alarma_tmp.wav");
                    MediaTools.toWav(this, uri, tmp, s, e, g, fi, fo, f -> progress(f));
                    if (out.exists()) out.delete();
                    if (!tmp.renameTo(out)) throw new Exception("rename");
                    p.edit().putString("sound_uri", Uri.fromFile(out).toString())
                            .putString("sound_name", name + " (editado)").apply();
                    msg = "¡Listo! Ahora SSS+ suena con este sonido 🐑";
                } else {
                    File tmp = new File(getCacheDir(), "audio_" + System.currentTimeMillis() + ".wav");
                    MediaTools.toWav(this, uri, tmp, s, e, g, fi, fo, f -> progress(f));
                    Uri saved = Media.save(this, tmp, Media.TYPE_AUDIO, "SSS_" + Media.stamp() + ".wav", "audio/wav");
                    msg = saved != null ? "Guardado en Música/SSS ✓" : "No se pudo guardar";
                }
            } catch (Exception ex) {
                msg = "No se pudo procesar este audio";
            }
            String fm = msg;
            runOnUiThread(() -> {
                busy = false;
                status.setText(fm);
                toast(fm);
            });
        }).start();
    }

    private volatile int lastPct = -1;

    private void progress(float f) {
        int pct = Math.round(f * 100);
        if (pct == lastPct) return;
        lastPct = pct;
        runOnUiThread(() -> status.setText("Procesando… " + pct + " %"));
    }
}
