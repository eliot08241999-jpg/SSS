package com.aplauso.encuentra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

/** Servicio en primer plano: escucha el micrófono (también con la pantalla bloqueada) y cuenta aplausos. */
public class ClapService extends Service {
    public static final String ACTION_STOP_SOUND = "com.aplauso.STOP_SOUND";
    static final String CHANNEL = "escucha";
    static final int NOTIF_ID = 1;
    static volatile boolean running = false;
    static volatile int level = 0;      // nivel del micrófono para el panel en vivo
    static volatile int clapCount = 0;  // aplausos contados ahora mismo

    private volatile boolean listening = false;
    private volatile long ignoreUntil = 0;
    private Thread thread;
    private PowerManager.WakeLock wakeLock;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Escucha de aplausos",
                NotificationManager.IMPORTANCE_LOW));
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, buildNotif(false), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(NOTIF_ID, buildNotif(false));
            }
        } catch (Exception e) {
            stopSelf(); // Android no permite iniciar el micrófono en segundo plano
            return;
        }
        running = true;
        PowerManager pm = getSystemService(PowerManager.class);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SSS:escucha");
        wakeLock.acquire();
        startListening();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP_SOUND.equals(intent.getAction())) {
            SoundPlayer.stop(this);
        }
        return START_STICKY;
    }

    private Notification buildNotif(boolean sounding) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                .setContentTitle(sounding ? "¡Sonando! Aquí estoy" : "SSS+ activo")
                .setContentText(sounding ? "Toca \"Detener\" para callarlo"
                        : "Aplaude " + prefs().getInt("claps", 5) + " veces para encontrar el teléfono")
                .setContentIntent(open)
                .setOngoing(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        if (sounding) {
            Intent stop = new Intent(this, ClapService.class).setAction(ACTION_STOP_SOUND);
            PendingIntent pi = PendingIntent.getService(this, 1, stop,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            b.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Detener", pi).build());
        }
        return b.build();
    }

    private SharedPreferences prefs() { return getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    private void startListening() {
        listening = true;
        thread = new Thread(this::loop, "clap-listener");
        thread.start();
    }

    private void loop() {
        final int rate = 44100;
        int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioRecord rec;
        try {
            rec = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 8192));
            rec.startRecording();
        } catch (Exception e) {
            main.post(this::stopSelf);
            return;
        }

        short[] buf = new short[1024]; // ~23 ms
        double background = 300;
        long lastClap = 0;
        int count = 0;
        SharedPreferences p = prefs();

        while (listening) {
            int n = rec.read(buf, 0, buf.length);
            if (n <= 0) continue;
            int peak = 0;
            double sum = 0;
            for (int i = 0; i < n; i++) {
                int v = Math.abs((int) buf[i]);
                if (v > peak) peak = v;
                sum += (double) buf[i] * buf[i];
            }
            double rms = Math.sqrt(sum / n);
            level = peak;
            long now = SystemClock.elapsedRealtime();

            // Mientras suena (y un momento después) no escucha, para no activarse con su propio sonido
            if (SoundPlayer.isPlaying() || now < ignoreUntil) { count = 0; clapCount = 0; continue; }

            int sens = p.getInt("sens", 6);              // 1..10
            int needed = p.getInt("claps", 5);           // 2..8
            int threshold = (int) (32767 * (0.80 - 0.07 * sens));

            boolean clap = peak > threshold && rms > background * 3 && (now - lastClap) > 120;
            if (clap) {
                if (now - lastClap > 1500) count = 0;   // más de 1,5 s entre aplausos: empieza de nuevo
                count++;
                lastClap = now;
                if (count >= needed) {
                    count = 0;
                    main.post(this::ring);
                }
            } else {
                background = background * 0.95 + rms * 0.05;
                if (count > 0 && now - lastClap > 1500) count = 0;
            }
            clapCount = count;
        }
        try { rec.stop(); } catch (Exception ignored) {}
        rec.release();
    }

    private void ring() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify(NOTIF_ID, buildNotif(true));
        SoundPlayer.play(this, () -> {
            ignoreUntil = SystemClock.elapsedRealtime() + 1500;
            if (running) nm.notify(NOTIF_ID, buildNotif(false));
        });
    }

    @Override
    public void onDestroy() {
        running = false;
        listening = false;
        level = 0;
        clapCount = 0;
        if (thread != null) try { thread.join(500); } catch (InterruptedException ignored) {}
        SoundPlayer.stop(this);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
}
