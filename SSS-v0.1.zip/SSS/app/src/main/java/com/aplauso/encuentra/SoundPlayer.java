package com.aplauso.encuentra;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

/** Reproduce el sonido elegido UNA vez, por el canal de alarma (suena aunque el móvil esté en silencio). */
public class SoundPlayer {
    static final long MAX_MS = 10_000; // corte de seguridad: nunca más de 10 s
    private static MediaPlayer player;
    private static int prevVolume = -1;
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private static Runnable onFinished;

    public static synchronized boolean isPlaying() { return player != null; }

    public static synchronized void play(Context c, Runnable whenDone) {
        stop(c);
        onFinished = whenDone;
        Context app = c.getApplicationContext();
        SharedPreferences p = app.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        int volPct = p.getInt("volume", 100);

        AudioManager am = app.getSystemService(AudioManager.class);
        try {
            prevVolume = am.getStreamVolume(AudioManager.STREAM_ALARM);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            am.setStreamVolume(AudioManager.STREAM_ALARM, Math.max(1, Math.round(max * volPct / 100f)), 0);
        } catch (Exception ignored) { prevVolume = -1; }

        String custom = p.getString("sound_uri", null);
        if (!start(app, custom != null ? Uri.parse(custom) : null)) {
            start(app, null); // si el sonido propio falla, usa el de por defecto
        }
        if (player == null) { finish(app); return; }
        handler.postDelayed(() -> stop(app), MAX_MS);
    }

    private static boolean start(Context app, Uri uri) {
        try {
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            mp.setDataSource(app, uri);
            mp.setLooping(false);
            mp.setOnCompletionListener(m -> stop(app));
            mp.prepare();
            mp.start();
            player = mp;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static synchronized void stop(Context c) {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
        finish(c.getApplicationContext());
    }

    private static void finish(Context app) {
        if (prevVolume >= 0) {
            try {
                app.getSystemService(AudioManager.class)
                        .setStreamVolume(AudioManager.STREAM_ALARM, prevVolume, 0);
            } catch (Exception ignored) {}
            prevVolume = -1;
        }
        Runnable r = onFinished;
        onFinished = null;
        if (r != null) r.run();
    }
}
