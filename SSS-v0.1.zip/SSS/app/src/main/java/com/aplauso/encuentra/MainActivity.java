package com.aplauso.encuentra;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Pantalla principal estilo HUD: botón de encendido, panel de sistema en vivo y controles rápidos. */
public class MainActivity extends NeonActivity {
    static final int REQ_PERM = 1;
    static final int[] VOLUMES = {25, 50, 75, 100};

    Neon.PowerButton power;
    Neon.LevelBar level;
    Neon.ClapDots dots;
    TextView status, hint, soundLbl, testBtn, volBtn;
    boolean wasOn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpi(18), dpi(18), dpi(18), dpi(18));

        // --- Barra superior: título + ajustes ---
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = neonText("SSS+", 30);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView gear = circleButton("⚙", v -> startActivity(new Intent(this, SettingsActivity.class)));
        top.addView(gear, new LinearLayout.LayoutParams(dpi(46), dpi(46)));
        col.addView(top, gapBelow(14));

        // --- Panel de sistema en vivo ---
        LinearLayout hud = panel("◢ SISTEMA");
        status = neonText("", 17);
        hud.addView(status);
        hud.addView(text("Micrófono", 12));
        level = new Neon.LevelBar(this);
        hud.addView(level, new LinearLayout.LayoutParams(-1, dpi(22)));
        hud.addView(text("Aplausos", 12));
        dots = new Neon.ClapDots(this);
        hud.addView(dots, new LinearLayout.LayoutParams(-1, dpi(30)));
        soundLbl = text("", 13);
        soundLbl.setPadding(0, dpi(6), 0, 0);
        hud.addView(soundLbl);
        col.addView(hud, gapBelow(8));

        // --- Botón de encendido ---
        power = new Neon.PowerButton(this);
        power.setOnClickListener(v -> {
            if (ClapService.running) stopService(new Intent(this, ClapService.class));
            else enable();
        });
        col.addView(power, new LinearLayout.LayoutParams(-1, 0, 1));

        hint = text("", 14);
        hint.setGravity(Gravity.CENTER);
        col.addView(hint, gapBelow(14));

        // --- Controles rápidos ---
        LinearLayout quick = new LinearLayout(this);
        testBtn = button("▶ PROBAR", v -> {
            if (SoundPlayer.isPlaying()) SoundPlayer.stop(this);
            else SoundPlayer.play(this, null);
        });
        TextView soundBtn = button("♪ SONIDO", v -> pickSound());
        volBtn = button("", v -> {
            int cur = p.getInt("volume", 100), next = VOLUMES[0];
            for (int x : VOLUMES) if (x > cur) { next = x; break; }
            p.edit().putInt("volume", next).apply();
            refreshLabels();
        });
        quick.addView(testBtn, weighted(true));
        quick.addView(soundBtn, weighted(true));
        quick.addView(volBtn, weighted(false));
        col.addView(quick);

        setContentView(makeRoot(col));
    }

    private LinearLayout.LayoutParams weighted(boolean gapRight) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        if (gapRight) lp.rightMargin = dpi(8);
        return lp;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (SoundPlayer.isPlaying() && ClapService.running) SoundPlayer.stop(this); // ya lo encontraste
        refreshLabels();
    }

    @Override
    protected void onSoundChanged() { refreshLabels(); }

    private void refreshLabels() {
        soundLbl.setText("♪ " + soundName());
        volBtn.setText("🔊 " + p.getInt("volume", 100) + "%");
    }

    @Override
    protected void onTick() {
        int c = Neon.color(this);
        boolean on = ClapService.running;
        int needed = p.getInt("claps", 5);
        power.set(c, on);
        float mark = on ? Neon.meter(Neon.threshold(p.getInt("sens", 6))) : -1;
        level.set(on ? Neon.meter(ClapService.level) : 0, mark, c);
        dots.set(needed, on ? ClapService.clapCount : 0, c);

        boolean playing = SoundPlayer.isPlaying();
        status.setText(playing ? "● SONANDO" : on ? "● ESCUCHANDO" : "○ APAGADO");
        testBtn.setText(playing ? "■ PARAR" : "▶ PROBAR");
        if (on != wasOn || hint.getText().length() == 0) {
            wasOn = on;
            hint.setText(on ? "Aplaude " + needed + " veces para que suene"
                    : "Toca el botón para empezar a escuchar");
        }
    }

    private void enable() {
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (need.isEmpty()) startForegroundService(new Intent(this, ClapService.class));
        else requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code != REQ_PERM) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startForegroundService(new Intent(this, ClapService.class));
        } else {
            Toast.makeText(this, "Sin micrófono no puedo oír los aplausos", Toast.LENGTH_LONG).show();
        }
    }
}
